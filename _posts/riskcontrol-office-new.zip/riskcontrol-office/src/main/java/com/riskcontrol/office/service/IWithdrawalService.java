package com.riskcontrol.office.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cn.schema.request.WSQueryWithdrawalRequests;
import com.riskcontrol.common.entity.request.QueryLoginInfoReq;
import com.riskcontrol.common.entity.response.QueryLoginInfoRsp;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.withdrawal.req.QueryWithdrawalListReq;
import com.riskcontrol.office.domain.withdrawal.req.QueryWithdrawalRemarksReq;
import com.riskcontrol.office.domain.withdrawal.req.ReviewWithdrawalRequestReq;
import com.riskcontrol.office.domain.withdrawal.req.WithdrawalApproveReq;
import com.riskcontrol.office.domain.withdrawal.req.WithdrawalRequestReq;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;

public interface IWithdrawalService {


    Response queryList(HttpServletRequest request, QueryWithdrawalListReq req);

    Response<String> approve(HttpServletRequest request, WithdrawalApproveReq req);

    Response auditWithdrawalRequest(WithdrawalRequestReq req, boolean isReject) throws Exception;
    Response reviewWithdrawalRequest(ReviewWithdrawalRequestReq req) throws Exception;

    Response querySameIpCustomersByIp(QueryLoginInfoReq loginInfoReq);

    Response reviewWithdrawalRequestCancel(ReviewWithdrawalRequestReq req) throws Exception;


    Response queryWithdrawalRemarks(QueryWithdrawalRemarksReq req) throws Exception;

    int queryWithdrawalCount(WSQueryWithdrawalRequests query);

    Response getValidAccountAndWinOrLostAmount(ReviewWithdrawalRequestReq req);
}
