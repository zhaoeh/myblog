package com.riskcontrol.office.component;

import com.cn.schema.customers.WSCustomers;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequest;
import com.riskcontrol.office.domain.entity.TRiskBlack;
import com.riskcontrol.office.domain.entity.TRiskBlackOperationDetail;
import com.riskcontrol.office.domain.po.RiskBlackImportPO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @description: 转换器
 * @author: ErHu.Zhao
 * @create: 2024-09-24
 **/
@Mapper
public interface RiskBlackImportConvert {

    RiskBlackImportConvert INSTANT = Mappers.getMapper(RiskBlackImportConvert.class);

    /**
     * 将source转换为TRiskBlackOperationDetail
     *
     * @param source 源对象
     * @return 转换后的对象
     */
//    TRiskBlackOperationDetail convertImport(RiskBlackImportPO.ImportMode source);

    /**
     * 将sources转换为List<TRiskBlackOperationDetail>
     *
     * @param sources 源对象集
     * @return 转换后的对象集
     */
    List<TRiskBlackOperationDetail> convertImports(List<RiskBlackImportPO.ImportMode> sources);


    /**
     * 将source转换为TRiskBlackOperationDetail
     *
     * @param source 源对象
     * @return 转换后的对象
     */
//    TRiskBlackOperationDetail convertAssociation(RiskBlackImportPO.AssociationMode source);

    /**
     * 将sources转换为List<TRiskBlackOperationDetail>
     *
     * @param sources 源对象集
     * @return 转换后的对象集
     */
//    List<TRiskBlackOperationDetail> convertAssociations(List<RiskBlackImportPO.AssociationMode> sources);


    /**
     * 将source转换为TRiskBlackOperationDetail
     *
     * @param source 源对象
     * @return 转换后的对象
     */
//    @Mappings({
//            @Mapping(source = "loginName", target = "loginName"),
//            @Mapping(source = "firstName", target = "firstName"),
//            @Mapping(source = "middleName", target = "middleName"),
//            @Mapping(source = "lastName", target = "lastName"),
//            @Mapping(source = "birthday", target = "birthday"),
//            @Mapping(source = "ipAddress", target = "registerIp"),
//            @Mapping(source = "lastLoginIp", target = "loginIp"),
//            @Mapping(source = "firstIdType", target = "idType"),
//            @Mapping(source = "firstNoType", target = "idNo"),
//            @Mapping(source = "phone", target = "phoneNumber"),
//            @Mapping(source = "email", target = "email"),
//            @Mapping(source = "bankCardNo", target = "bankAccountNo")
//    })
//    TRiskBlackOperationDetail convertWsCustomer(WSCustomers source);

    /**
     * 将sources转换为List<TRiskBlackOperationDetail>
     *
     * @param sources 源对象集
     * @return 转换后的对象集
     */
//    List<TRiskBlackOperationDetail> convertWsCustomers(List<WSCustomers> sources);


    /**
     * 将source转换为TRiskBlackOperationDetail
     *
     * @param source 源对象
     * @return 转换后的对象
     */
    @Mappings({
            @Mapping(source = "loginName", target = "loginName"),
            @Mapping(source = "firstName", target = "firstName"),
            @Mapping(source = "middleName", target = "middleName"),
            @Mapping(source = "lastName", target = "lastName"),
            @Mapping(source = "birthday", target = "birthday"),
            @Mapping(source = "ipAddress", target = "registerIp"),
            @Mapping(source = "lastLoginIp", target = "loginIp"),
            @Mapping(source = "firstIdType", target = "idType", defaultValue = "0"),
            @Mapping(source = "firstNoType", target = "idNo"),
            @Mapping(source = "phone", target = "phoneNumber"),
            @Mapping(source = "email", target = "email"),
            @Mapping(source = "bankCardNo", target = "bankAccountNo")
    })
    TRiskBlack convert(WSCustomers source);

    /**
     * 将sources转换为List<TRiskBlackOperationDetail>
     *
     * @param sources 源对象集
     * @return 转换后的对象集
     */
//    List<TRiskBlack> converts(List<WSCustomers> sources);


    /**
     * 将source转换为TRiskBlackOperationDetail
     *
     * @param source 源对象
     * @return 转换后的对象
     */
    TRiskBlackOperationDetail convertRiskQuery(RiskQueryKycRequest source);

    /**
     * 将sources转换为List<TRiskBlackOperationDetail>
     *
     * @param sources 源对象集
     * @return 转换后的对象集
     */
//    List<TRiskBlackOperationDetail> convertRiskQueries(List<RiskQueryKycRequest> sources);


    /**
     * 将source转换为 TRiskBlackOperationDetail
     *
     * @param source 源对象
     * @return 转换后的对象
     */
    TRiskBlackOperationDetail convertBlack(TRiskBlack source);

    /**
     * 将sources转换为List<TRiskBlackOperationDetail>
     *
     * @param sources 源对象集
     * @return 转换后的对象集
     */
//    List<TRiskBlackOperationDetail> convertBlacks(List<TRiskBlack> sources);
}
