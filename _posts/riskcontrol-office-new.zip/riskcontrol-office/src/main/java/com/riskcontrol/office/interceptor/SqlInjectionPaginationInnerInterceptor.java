package com.riskcontrol.office.interceptor;

import cn.hutool.core.util.ReUtil;
import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.core.exceptions.MybatisPlusException;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import net.sf.jsqlparser.JSQLParserException;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.statement.select.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/4/25 11:46
 */
public class SqlInjectionPaginationInnerInterceptor extends PaginationInnerInterceptor {
    /**
     * 特殊字符正则匹配
     */
    String regEx = ".*[\\s`~!@#$%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？\\\\]+.*";
    /**
     * 关键字集合
     */
    Set<String> keyset = new HashSet<>(Arrays.asList("select ", " and "," or "," xor "," where "));
    public SqlInjectionPaginationInnerInterceptor(DbType dbType) {
        super(dbType);
    }

    @Override
    protected List<OrderByElement> addOrderByElements(List<OrderItem> orderlist, List<OrderByElement> orderByElements){
        List<OrderByElement> additionalOrderBy = orderlist.stream()
            .filter(item -> StringUtils.isNotBlank(item.getColumn()))
            .map(item ->{
                OrderByElement element = new OrderByElement();
                String column = item.getColumn();
                //正则匹配,抛出自定义异常
                if(ReUtil.isMatch(regEx, column)) {//存在特殊符号
                    throw new MybatisPlusException("There are special symbols in the sorting field");
                }
                //关键字匹配,抛出自定义异常
                String lowerCase = column.toLowerCase();
                for (String key : keyset) {
                    if (lowerCase.contains(key)) {//存在特殊关键字
                        throw new MybatisPlusException("There are special keywords in the sorting field");
                    }
                }
                element.setExpression(new Column(column));
                element.setAsc(item.isAsc());
                element.setAscDescPresent(true);
                return element;
            }).collect(Collectors.toList());
        if(CollectionUtils.isEmpty(orderByElements)) {
            return additionalOrderBy;
        }
        orderByElements.addAll(additionalOrderBy);
        return orderByElements;
    }

    @Override
    public String concatOrderBy(String originalSql, List<OrderItem> orderList) {
        try {
            Select select = (Select) CCJSqlParserUtil.parse(originalSql);
            SelectBody selectBody = select.getSelectBody();
            if (selectBody instanceof PlainSelect) {
                PlainSelect plainSelect = (PlainSelect) selectBody;
                List<OrderByElement> orderByElements = plainSelect.getOrderByElements();
                List<OrderByElement> orderByElementsReturn = addOrderByElements(orderList, orderByElements);
                plainSelect.setOrderByElements(orderByElementsReturn);
                return select.toString();
            } else if (selectBody instanceof SetOperationList) {
                SetOperationList setOperationlist = (SetOperationList) selectBody;
                List<OrderByElement> orderByElements = setOperationlist.getOrderByElements();
                List<OrderByElement> orderByElementsReturn = addOrderByElements(orderList, orderByElements);
                setOperationlist.setOrderByElements(orderByElementsReturn);
                return select.toString();
            } else if (selectBody instanceof WithItem) {
                return originalSql;
            } else {
                return originalSql;
            }
        } catch (JSQLParserException e) {
            logger.warn("failed to concat orderBy from IPage, exception:\n" + e.getCause());
        } catch (MybatisPlusException e) {
            throw e;
        } catch (Exception e) {
            logger.warn("failed to concat orderBy from IPage,exception:\n" + e);
        }
        return originalSql;
    }
}

