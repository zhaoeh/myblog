package com.riskcontrol.office.domain.rsp;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

/**
 * @description: 设备风控规则分页查询返回
 * @author: Yu.Guo
 * @create: 2024-11-13
 **/
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class DeviceRiskRuleResp {
    @ApiModelProperty("ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    @ApiModelProperty("规则校验类型（0：登录：1：注册）")
    private Integer rulesType;

    @ApiModelProperty("规则限制行为（0：ip ; 1：设备指纹；2：ip+设备指纹）")
    private Integer rulesAction;

    @ApiModelProperty("规则限制账号最大数量")
    private Integer rulesAccountMax;

    @ApiModelProperty("血缘标记（BP、AP、 GP、PG、OTHER）")
    private String tenant;

    @ApiModelProperty("可用状态")
    private String isEnable;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("创建人")
    private String createBy;

    @ApiModelProperty("创建时间")
    private String createDate;

    @ApiModelProperty("更新人")
    private String updateBy;

    @ApiModelProperty("更新时间")
    private String updateDate;

}
