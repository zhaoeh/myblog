package com.riskcontrol.office.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.office.common.constants.ConstantVars;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.domain.entity.RiskActionRuleEntity;
import com.riskcontrol.office.domain.entity.TLabelRuleRelationship;
import com.riskcontrol.office.domain.entity.TRiskBlack;
import com.riskcontrol.office.domain.entity.TRiskBlackOperation;
import com.riskcontrol.office.domain.req.DeviceRiskRuleEditReq;
import com.riskcontrol.office.domain.req.DeviceRiskRuleNewReq;
import com.riskcontrol.office.domain.req.DeviceRiskRuleQueryReq;
import com.riskcontrol.office.domain.req.DeviceRiskRuleUpdateReq;
import com.riskcontrol.office.domain.rsp.DeviceRiskRuleResp;
import com.riskcontrol.office.domain.rsp.black.RiskBlackRsp;
import com.riskcontrol.office.enums.RiskBlackOpStatusEnum;
import com.riskcontrol.office.mapper.DeviceRiskRuleMapper;
import com.riskcontrol.office.service.IDeviceRiskRuleService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import static com.riskcontrol.common.constants.Constant.DATE_TIME_FORMATTER;

@Service
@Slf4j
public class DeviceRiskRuleServiceImpl extends BaseServiceImpl<DeviceRiskRuleMapper, RiskActionRuleEntity> implements IDeviceRiskRuleService {
    @Autowired
    DeviceRiskRuleMapper deviceRiskRuleMapper;
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean deviceRiskRuleCreate(DeviceRiskRuleNewReq deviceRiskRuleNewReq)  throws BusinessException {
        log.info("创建风控行为规则配置，入参：{}", deviceRiskRuleNewReq);
        if(Objects.isNull(deviceRiskRuleNewReq)){
            throw new BusinessException("Parameter can't be null or empty", ResultEnum.BAD_REQUEST.getCode());
        }
        RiskActionRuleEntity riskActionRuleEntity=new RiskActionRuleEntity();
        BeanUtils.copyProperties(deviceRiskRuleNewReq,riskActionRuleEntity);
        //checkIsExist tenant+rulesAction+rulesType
        List<RiskActionRuleEntity> riskActionRuleList=deviceRiskRuleMapper.selectList(
                new LambdaQueryWrapper<RiskActionRuleEntity>()
                        .eq(RiskActionRuleEntity::getTenant,deviceRiskRuleNewReq.getTenant())
                        .eq(RiskActionRuleEntity::getRulesAction,deviceRiskRuleNewReq.getRulesAction())
                        .eq(RiskActionRuleEntity::getRulesType,deviceRiskRuleNewReq.getRulesType()));
        if (!CollectionUtils.isEmpty(riskActionRuleList)){
            log.error("{} exists db", riskActionRuleEntity);
            throw new BusinessException("RiskActionRule already in DB can't allowed duplicate", 111);
        }
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if(!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())){
            riskActionRuleEntity.setCreateBy(userInfoVO.getUserInfo().getUsername());
            riskActionRuleEntity.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        riskActionRuleEntity.setCreateDate(DateUtils.getCurrentDateTime());
        riskActionRuleEntity.setUpdateDate(DateUtils.getCurrentDateTime());
        riskActionRuleEntity.setRulesCheckDay(deviceRiskRuleNewReq.getRulesCheckday());
        riskActionRuleEntity.setIsEnable((byte) 0);
        riskActionRuleEntity.setRemark(StringUtils.isNotBlank(deviceRiskRuleNewReq.getRemark())?deviceRiskRuleNewReq.getRemark():"default");
        log.info("创建风控行为规则配置，riskActionRuleEntity：{}", JSON.toJSONString(riskActionRuleEntity));
        return this.save(riskActionRuleEntity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean deviceRiskRuleEdit(DeviceRiskRuleEditReq deviceRiskRuleEditReq) {
        log.info("修改风控行为规则配置，入参：{}", deviceRiskRuleEditReq);
        if(Objects.isNull(deviceRiskRuleEditReq)){
            throw new BusinessException("Parameter can't be null or empty", ResultEnum.BAD_REQUEST.getCode());
        }
        LambdaQueryWrapper<RiskActionRuleEntity> wrapper = buildWrapper(deviceRiskRuleEditReq);
        wrapper.eq(RiskActionRuleEntity::getId, deviceRiskRuleEditReq.getId());
        RiskActionRuleEntity riskActionRuleEntity = getOne(wrapper);
        if (ObjectUtils.isEmpty(riskActionRuleEntity)) {
            log.info("更新风控行为规则配置查询无数据,id:{}", deviceRiskRuleEditReq.getId());
            throw new BusinessException("RiskActionRule not exist",111);
        }
        riskActionRuleEntity.setRulesAccountMax(deviceRiskRuleEditReq.getRulesAccountMax());
        riskActionRuleEntity.setRulesCheckDay(deviceRiskRuleEditReq.getRulesCheckday());
        riskActionRuleEntity.setRemark(StringUtils.isNotBlank(deviceRiskRuleEditReq.getRemark())?deviceRiskRuleEditReq.getRemark():"default");
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if(!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())){
            riskActionRuleEntity.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        riskActionRuleEntity.setUpdateDate(DateUtils.getCurrentDateTime());
        return this.updateById(riskActionRuleEntity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean deviceRiskRuleUpdateStatus(DeviceRiskRuleUpdateReq deviceRiskRuleUpdateReq) {
        log.info("修改风控行为规则配置状态，入参：{}", deviceRiskRuleUpdateReq);
        if(Objects.isNull(deviceRiskRuleUpdateReq)){
            throw new BusinessException("Parameter can't be null or empty", ResultEnum.BAD_REQUEST.getCode());
        }
        LambdaQueryWrapper<RiskActionRuleEntity> wrapper = buildWrapper(deviceRiskRuleUpdateReq);
        wrapper.eq(RiskActionRuleEntity::getId, deviceRiskRuleUpdateReq.getId());
        RiskActionRuleEntity riskActionRuleEntity = getOne(wrapper);
        if (ObjectUtils.isEmpty(riskActionRuleEntity)) {
            log.info("更新风控行为规则配置状态查询无数据,id:{}", deviceRiskRuleUpdateReq.getId());
            throw new BusinessException("RiskActionRule not exist",111);
        }
        riskActionRuleEntity.setIsEnable(deviceRiskRuleUpdateReq.getIsEnable());
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if(!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())){
            riskActionRuleEntity.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        riskActionRuleEntity.setUpdateDate(DateUtils.getCurrentDateTime());
        return this.updateById(riskActionRuleEntity);
    }

    @Override
    public PageModel<DeviceRiskRuleResp> deviceRiskRulePageList(DeviceRiskRuleQueryReq deviceRiskRuleQueryReq) {
        LambdaQueryWrapper<RiskActionRuleEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(StringUtils.isNotBlank(deviceRiskRuleQueryReq.getTenant()), RiskActionRuleEntity::getTenant, deviceRiskRuleQueryReq.getTenant())
                .eq((Objects.nonNull(deviceRiskRuleQueryReq.getRulesAction())), RiskActionRuleEntity::getRulesAction, deviceRiskRuleQueryReq.getRulesAction())
                .eq((Objects.nonNull(deviceRiskRuleQueryReq.getRulesType())), RiskActionRuleEntity::getRulesType, deviceRiskRuleQueryReq.getRulesType());
        Page<RiskActionRuleEntity> riskActionRuleEntityPage = pageByWrapper(deviceRiskRuleQueryReq, wrapper);
        if (CollUtil.isEmpty(riskActionRuleEntityPage.getRecords())) {
            return new PageModel<>();
        }
        List<DeviceRiskRuleResp> list = riskActionRuleEntityPage.getRecords().stream().map(entity -> {
            DeviceRiskRuleResp rsp = new DeviceRiskRuleResp();
            BeanUtil.copyProperties(entity, rsp);
            return rsp;
        }).toList();
        PageModel<DeviceRiskRuleResp> pageResult = new PageModel<>();
        pageResult.setData(list);
        pageResult.setPageNo((int) riskActionRuleEntityPage.getCurrent());
        pageResult.setPageSize((int) riskActionRuleEntityPage.getSize());
        pageResult.setTotalRow((int) riskActionRuleEntityPage.getTotal());
        pageResult.setTotalPage((int) riskActionRuleEntityPage.getPages());
        return pageResult;
    }
}
