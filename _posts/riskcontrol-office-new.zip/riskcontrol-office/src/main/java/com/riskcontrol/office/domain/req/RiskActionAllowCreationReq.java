package com.riskcontrol.office.domain.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
@Schema(description = "白名单创建请求对象")
public class RiskActionAllowCreationReq {

    @Schema(description = "规则校验类型（0：ip ; 1：设备指纹） 必选")
    @JsonProperty("allowType")
    @NotBlank(message = "allowType can not be null")
    private Integer allowType;

    @Schema(description = "名单规则（0：白名单；1：黑名单）  必选")
    @JsonProperty("allowRule ")
    @NotBlank(message = "allowRule can not be null")
    private Integer allowRule ;

    @Schema(description = "规则校验名称")
    @JsonProperty("allowRecord")
    @NotBlank(message = "allowRecord can not be null")
    @Size(max = 10000, message = "allowRecord max length is 10000")
    private String allowRecord;

    @Schema(description = "备注")
    private String remark;

}