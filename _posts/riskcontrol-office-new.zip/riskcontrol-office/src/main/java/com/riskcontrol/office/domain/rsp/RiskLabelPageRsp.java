package com.riskcontrol.office.domain.rsp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @description: 风控分页标签响应体
 * @author: ErHu.Zhao
 * @create: 2024-10-16
 **/
@ApiModel(value = "风控分页标签响应体", description = "风控分页标签响应体")
@Data
public class RiskLabelPageRsp {

    @ApiModelProperty("用户ID")
    private String customerId;

    @ApiModelProperty("用户登录名")
    private String loginName;

    @ApiModelProperty("所属产品")
    private String productId;

    @ApiModelProperty("标签ID")
    private String riskLabelIds;

//    @ApiModelProperty("标签名称")
//    private String riskLabelName;
//
//    @ApiModelProperty("标签key")
//    private String riskLabelKey;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("操作人")
    private String updateBy;

    @ApiModelProperty("更新时间")
    private String updateTime;
}
