package com.riskcontrol.office.domain.enums;

    public enum RiskTenanEnum {
        BP("BP"),
        AP("AP"),
        GP("GP"),
        PG("PG"),
        SP("OTHER");

        private final String name;

        private RiskTenanEnum(final String name) {
            this.name = name;
        }

        public String getName() {
            return this.name;
        }
    }


