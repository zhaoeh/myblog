package com.riskcontrol.office.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Component
@Configuration
public class EncodeKeyConfig {
    @Autowired
    private NacosConfig config;

    public String getProductKey(String productId, String type) {
        String key = type + "." + productId + ".KEY";
        return config.getProperty(key, "");
    }

    public String getRealNameEncodeKey(String productId) {
        String key = "01." + productId + ".KEY";
        return config.getProperty(key, "");
    }

    public String getAddressEncodeKey(String productId) {
        String key = "02." + productId + ".KEY";
        return config.getProperty(key, "");
    }

    public String getPhoneEncodeKey(String productId) {
        String key = "03." + productId + ".KEY";
        return config.getProperty(key, "");
    }


    public String getEmailEncodeKey(String productId) {
        String key = "04." + productId + ".KEY";
        return config.getProperty(key, "");
    }

    public String getOnlineMessengerEnncodeKey(String productId) {
        String key = "05." + productId + ".KEY";
        return config.getProperty(key, "");
    }


    public String getBankAccountNameEncodeKey(String productId) {
        String key = "06." + productId + ".KEY";
        return config.getProperty(key, "");
    }

    public String getBankAccountNoEncodeKey(String productId) {
        String key = "07." + productId + ".KEY";
        return config.getProperty(key, "");
    }

    public String getDepositByEncodeKey(String productId) {
        String key = "08." + productId + ".KEY";
        return config.getProperty(key, "");
    }

    public String getSmsSystemkey(String productId) {
        String key = productId + ".SMS.KEY";
        return config.getProperty(key, "");
    }

    public String getEmailSystemkey(String productId) {
        String key = productId + ".EMAIL.KEY";
        return config.getProperty(key, "");
    }

}
