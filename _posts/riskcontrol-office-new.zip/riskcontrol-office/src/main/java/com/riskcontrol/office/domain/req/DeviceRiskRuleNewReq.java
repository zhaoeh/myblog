package com.riskcontrol.office.domain.req;

import com.riskcontrol.common.annotation.EnumValid;
import com.riskcontrol.office.domain.enums.RiskRulesActionEnum;
import com.riskcontrol.office.domain.enums.RiskRulesTypeEnum;
import com.riskcontrol.office.domain.enums.RiskTenanEnum;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@Schema(description="新增设备指纹风控规则对象")
public class DeviceRiskRuleNewReq {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty(required = true, value = "血缘标记（BP、AP、 GP、PG、OTHER）")
//    @EnumValid(enumClass = RiskTenanEnum.class, enumField = "name",message = "tenant must belong to {target}")
//    @NotBlank(message = "tenant cannot be blank")
    private String tenant;

    @ApiModelProperty(required = true, value = "规则限制行为（0：登录：1：注册）")
    @EnumValid(enumClass = RiskRulesActionEnum.class, enumField = "value",message = "rulesAction must belong to {target}")
    @NotNull(message = "rulesAction can not  be null")
    private Byte rulesAction;

    @ApiModelProperty(required = true, value = "规则限制类型（0：ip ; 1：设备指纹；2：ip+设备指纹）")
    @EnumValid(enumClass = RiskRulesTypeEnum.class, enumField = "value",message = "rulesType must belong to {target}")
    @NotNull(message = "rulesType can not  be null")
    private Byte rulesType;

    @ApiModelProperty(required = true, value = "规则限制账号最大数量")
    @NotNull(message = "rulesAccountMax cannot be null")
    @Max(value = 20,message = "rulesAccountMax vlue not more than 20")
    private Byte rulesAccountMax;

    @ApiModelProperty(required = true, value = "规则数据查询天数")
    @NotNull(message = "rulesCheckday cannot be null")
    @Max(value = 30,message = "rulesCheckday vlue not more than 30")
    @Min(value = 1,message = "rulesCheckday vlue not less than 1")
    private Byte rulesCheckday;

    @ApiModelProperty(required = true, value = "备注")
    private String remark;
}
