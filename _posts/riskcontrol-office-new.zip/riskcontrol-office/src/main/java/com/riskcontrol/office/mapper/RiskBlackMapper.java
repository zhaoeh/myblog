package com.riskcontrol.office.mapper;

import com.riskcontrol.office.domain.entity.TRiskBlack;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;


/**
 * @author Heng.zhang
 */
@Mapper
public interface RiskBlackMapper extends BaseMapperX<TRiskBlack> {


    @Insert({
            "<script>",
            "INSERT INTO t_risk_black (login_name, first_name, middle_name, last_name, birthday, register_ip, login_ip, id_type, id_no, phone_number, email, " +
                    "bank_account_no, status,phone_md5, create_by,source)",
            "VALUES ",
            "<foreach collection='list' item='item' separator=','>",
            "(#{item.loginName}, #{item.firstName}, #{item.middleName}, #{item.lastName}, #{item.birthday},",
            "#{item.registerIp}, #{item.loginIp}, #{item.idType}, #{item.idNo}, #{item.phoneNumber},",
            "#{item.email}, #{item.bankAccountNo}, #{item.status},#{item.phoneMd5}, #{item.createBy}, #{item.source})",
            "</foreach>",
            "ON DUPLICATE KEY UPDATE first_name = VALUES(first_name),middle_name = VALUES(middle_name),last_name = VALUES(last_name),birthday = VALUES(birthday)," +
                    "status = VALUES(status),register_ip = VALUES(register_ip),login_ip = VALUES(login_ip),id_type = VALUES(id_type)," +
                    "id_no = VALUES(id_no),phone_number = VALUES(phone_number),email = VALUES(email),bank_account_no = VALUES(bank_account_no),phone_md5 = VALUES(phone_md5)," +
                    "update_by = VALUES(update_by),update_date = NOW(),source = VALUES(source)",
            "</script>"
    })
    int insertOrUpdateBatch(@Param("list") List<TRiskBlack> list);
}
