package com.riskcontrol.office.service;

import com.gw.datacenter.vo.order.OrderReq;
import com.gw.datacenter.vo.order.OrderSummaryNew;
import com.gw.datacenter.vo.pagainate.QueryResult;
import com.gw.datacenter.vo.pagainate.QueryResultWrapper;

public interface DataCenterService {

    QueryResult<OrderSummaryNew> getSummaryNewByLoginName(String productId, String loginName, String beginTime, String endTime);

    QueryResultWrapper getCountTotalStrRecordAndSummaryV2(OrderReq orderReq);


}
