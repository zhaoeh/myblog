package com.riskcontrol.office.controller;

import com.digiplus.oms.aspect.annotation.PreAuthorize;
import com.riskcontrol.common.controller.BaseController;
import com.riskcontrol.common.entity.request.QueryLoginInfoReq;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.office.annotation.EnableOperationLog;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.enums.OpTypeEnum;
import com.riskcontrol.office.domain.withdrawal.req.*;
import com.riskcontrol.office.domain.withdrawal.rsp.ReviewWithdrawalRequestRsp;
import com.riskcontrol.office.domain.withdrawal.rsp.WithdrawalRemarksRsp;
import com.riskcontrol.office.service.IWithdrawalService;
import io.swagger.annotations.ApiOperation;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.List;

@Slf4j
@Tag(name = "门店取款", description = "取款相关接口")
@RestController
@RequestMapping(value = "/office/withdrawal", method = RequestMethod.POST)
public class WithdrawalController extends BaseController {
    private final String SUCCESS_CODE = "0000";
    @Resource
    private IWithdrawalService withdrawalService;

    @PreAuthorize("riskManage_withdraw_branch_approve")
    @Operation(tags = "审批取款提案", summary = "审批取款提案")
    @PostMapping(value = "approve")
    @EnableOperationLog(menuName = "风控管理", subMenuName = "门店取款", opLog = "审批取款提案", opLogType = OpTypeEnum.APPROVAL)
    @ResponseBody
    public R<Boolean> approve(HttpServletRequest request, @Valid @RequestBody WithdrawalApproveReq req) throws Exception {
        req.setIpAddress(getRequestIP(request));
        Response<String> resp = withdrawalService.approve(request, req);
        boolean isSuccess = SUCCESS_CODE.equals(resp.getHead().getErrCode());
        return isSuccess ? R.ok() : R.failed(resp.getHead().getErrMsg());
    }

    @PreAuthorize("riskManage_withdraw_approve")
    @Operation(tags = "门店取款", summary = "通过取款提案")
    @RequestMapping(value = "approveWithdrawalRequest")
    @EnableOperationLog(menuName = "风控管理", subMenuName = "取款", opLog = "通过", opLogType = OpTypeEnum.APPROVAL)
    public R<Boolean> approveWithdrawalRequest(HttpServletRequest request, @Valid @RequestBody WithdrawalRequestReq req) throws Exception {
        req.setIpAddress(getRequestIP(request));
        Response resp = withdrawalService.auditWithdrawalRequest(req, false);
        boolean isSuccess = SUCCESS_CODE.equals(resp.getHead().getErrCode());
        return isSuccess ? R.ok() : R.failed(resp.getHead().getErrMsg());
    }

    @PreAuthorize("riskManage_withdraw_approve")
    @Operation(tags = "门店取款", summary = "拒绝取款提案")
    @RequestMapping(value = "denyWithdrawalRequest")
    @EnableOperationLog(menuName = "风控管理", subMenuName = "取款", opLog = "拒绝", opLogType = OpTypeEnum.REJECTED)
    public R<Boolean> denyWithdrawalRequest(HttpServletRequest request, @Valid @RequestBody WithdrawalRequestReq req) throws Exception {
        req.setIpAddress(getRequestIP(request));
        Response resp = withdrawalService.auditWithdrawalRequest(req, true);
        boolean isSuccess = SUCCESS_CODE.equals(resp.getHead().getErrCode());
        return isSuccess ? R.ok() : R.failed(resp.getHead().getErrMsg());
    }

    @PreAuthorize("riskManage_withdraw_query")
    @Operation(tags = "门店取款", summary = "查询提款提案列表")
    @RequestMapping(value = "list")
    @ResponseBody
    public R queryWithdrawalList(HttpServletRequest request, @RequestBody QueryWithdrawalListReq req) throws Exception {
        req.setIpAddress(getRequestIP(request));
        Response resp = withdrawalService.queryList(request, req);
        boolean isSuccess = SUCCESS_CODE.equals(resp.getHead().getErrCode());
        return isSuccess ? R.ok(resp.getBody()) : R.failed(resp.getHead().getErrMsg());
    }

    @PreAuthorize("riskManage_withdraw_export")
    @Operation(tags = "门店取款", summary = "导出提款提案列表")
    @RequestMapping(value = "listExport")
    @ResponseBody
    @EnableOperationLog(menuName = "风控管理", subMenuName = "取款", opLog = "导出", opLogType = OpTypeEnum.EXPORT)
    public R queryWithdrawalListExport(HttpServletRequest request, @RequestBody QueryWithdrawalListReq req) throws Exception {
        req.setIpAddress(getRequestIP(request));
        Response resp = withdrawalService.queryList(request, req);
        boolean isSuccess = SUCCESS_CODE.equals(resp.getHead().getErrCode());
        return isSuccess ? R.ok(resp.getBody()) : R.failed(resp.getHead().getErrMsg());
    }

    @PreAuthorize("riskManage_withdraw_review")
    @Operation(tags = "门店取款", summary = "开始审核取款提案")
    @RequestMapping(value = "reviewWithdrawalRequest")
    public R<ReviewWithdrawalRequestRsp> reviewWithdrawalRequest(HttpServletRequest request, @Valid @RequestBody ReviewWithdrawalRequestReq req) throws Exception {
        req.setIpAddress(getRequestIP(request));
        Response<ReviewWithdrawalRequestRsp> resp = withdrawalService.reviewWithdrawalRequest(req);
        boolean isSuccess = SUCCESS_CODE.equals(resp.getHead().getErrCode());
        return isSuccess ? R.ok(resp.getBody()) : R.failed(resp.getHead().getErrMsg());
    }

    @PreAuthorize("riskManage_withdraw_review_cancel")
    @Operation(tags = "门店取款", summary = "取消审核取款提案")
    @RequestMapping(value = "reviewWithdrawalRequestCancel")
    public R<Boolean> reviewWithdrawalRequestCancel(HttpServletRequest request, @Valid @RequestBody ReviewWithdrawalRequestReq req) throws Exception {
        req.setIpAddress(getRequestIP(request));
        Response<Boolean> resp = withdrawalService.reviewWithdrawalRequestCancel(req);
        boolean isSuccess = SUCCESS_CODE.equals(resp.getHead().getErrCode());
        return isSuccess ? R.ok(resp.getBody()) : R.failed(resp.getHead().getErrMsg());
    }

    @PreAuthorize("riskManage_withdraw_check")
    @Operation(tags = "门店取款", summary = "查询取款审核备注<br/>Query withdrawal remarks")
    @RequestMapping(value = "queryWithdrawalRemarks")
    public R<List<WithdrawalRemarksRsp>> queryWithdrawalRemarks(HttpServletRequest request, @Valid @RequestBody QueryWithdrawalRemarksReq req) throws Exception {
        req.setIpAddress(getRequestIP(request));
        Response<List<WithdrawalRemarksRsp>> resp = withdrawalService.queryWithdrawalRemarks(req);
        boolean isSuccess = SUCCESS_CODE.equals(resp.getHead().getErrCode());
        return isSuccess ? R.ok(resp.getBody()) : R.failed(resp.getHead().getErrMsg());
    }

    @Operation(tags = "门店取款", summary = "通过IP查询登录信息<br/>Query withdrawal same IP record")
    @RequestMapping(value = "querySameIpCustomersByIp")
    public R querySameIpCustomersByIp(HttpServletRequest request, @Valid @RequestBody QueryLoginInfoReq req) throws Exception {
        Response resp = withdrawalService.querySameIpCustomersByIp(req);
        boolean isSuccess = SUCCESS_CODE.equals(resp.getHead().getErrCode());
        return isSuccess ? R.ok(resp.getBody()) : R.failed(resp.getHead().getErrMsg());
    }

    @ApiOperation(
            value = "获取投注额和盈利金额",
            httpMethod = "POST"
    )
    @RequestMapping(method = RequestMethod.POST, value = "/getValidAccountAndWinOrLostAmount")
    @ResponseBody
    public R getValidAccountAndWinOrLostAmount(@RequestBody ReviewWithdrawalRequestReq req) {
        Response resp = withdrawalService.getValidAccountAndWinOrLostAmount(req);
        boolean isSuccess = SUCCESS_CODE.equals(resp.getHead().getErrCode());
        return isSuccess ? R.ok(resp.getBody()) : R.failed(resp.getHead().getErrMsg());
    }
}
