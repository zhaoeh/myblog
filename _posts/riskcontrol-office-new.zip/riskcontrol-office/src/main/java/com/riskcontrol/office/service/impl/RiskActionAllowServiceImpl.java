package com.riskcontrol.office.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.gw.datacenter.vo.pagainate.PageModel;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.office.common.constants.ConstantVars;
import com.riskcontrol.office.component.LambdaQueryWrapperX;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.domain.entity.TRiskActionAllow;
import com.riskcontrol.office.domain.entity.TRiskActionAllowOperationLog;
import com.riskcontrol.office.domain.req.RiskActionAllowCreationReq;
import com.riskcontrol.office.domain.req.RiskActionAllowEditReq;
import com.riskcontrol.office.domain.req.RiskActionAllowPageQueryReq;
import com.riskcontrol.office.domain.req.RiskActionAllowpUdateStatusReq;
import com.riskcontrol.office.domain.rsp.RiskActionAllowPageQueryRsp;
import com.riskcontrol.office.mapper.RiskActionAllowMapper;
import com.riskcontrol.office.mapper.TRiskActionAllowOperationLogMapper;
import com.riskcontrol.office.service.RiskActionAllowService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @description: 白名单service impl
 * @author: ErHu.Zhao
 * @create: 2024-11-12
 **/
@Slf4j
@Service
public class RiskActionAllowServiceImpl extends BaseServiceImpl<RiskActionAllowMapper, TRiskActionAllow> implements RiskActionAllowService {

    @Resource
    private RiskActionAllowMapper actionAllowMapper;

    @Resource
    private TRiskActionAllowOperationLogMapper tRiskActionAllowOperationLogMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean create(RiskActionAllowCreationReq req) {
        return Optional.ofNullable(req.getAllowRecord()).filter(StringUtils::isNotBlank).map(name -> Arrays.asList(name.split(";"))).map(allows -> {
            List<String> distinctAllows = allows.stream().distinct().collect(Collectors.toList());
            List<TRiskActionAllow> exists = actionAllowMapper.selectList(new LambdaQueryWrapperX<TRiskActionAllow>().
                    eqIfPresent(TRiskActionAllow::getAllowType, req.getAllowType()).
                    inIfPresent(TRiskActionAllow::getAllowRecord, distinctAllows));
            Map<String, TRiskActionAllow> map = exists.stream().collect(Collectors.toMap(TRiskActionAllow::getAllowRecord, Function.identity()));
            List<TRiskActionAllow> allowList = distinctAllows.stream().map(allow -> map.containsKey(allow) ? map.get(allow) : TRiskActionAllow.builder().
                    allowRecord(allow).
                    allowType(req.getAllowType()).
                    remark(req.getRemark()).build()).collect(Collectors.toList());
            // true：表示需要新增的记录 false：表示已经存在的记录
            Map<Boolean, List<TRiskActionAllow>> results = allowList.stream().collect(Collectors.partitioningBy(allow -> Objects.isNull(allow.getId())));
            return results;
        }).map(mapping -> {
            List<TRiskActionAllow> existing = mapping.get(Boolean.FALSE);
            // 1选出入参req的allowType，和allowRule 与表中allow_rule和allowRule一致并且状态为禁用，做更新状态操作
            List<TRiskActionAllow> sameTRiskActionAllows=existing.stream().filter(item-> Objects.equals(item.getAllowType(), req.getAllowType())&&
                            Objects.equals(item.getAllowRule(), req.getAllowRule())&&
                    Objects.equals(item.getIsEnable(), 1)
            ).collect(Collectors.toList());

            UserInfoVO userInfoVO = CurrentUserUtil.get();
            if (CollectionUtils.isNotEmpty(sameTRiskActionAllows)) {
                sameTRiskActionAllows.forEach(r->{
                    if(!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())){
                        r.setUpdateBy(userInfoVO.getUserInfo().getUsername());
                    }
                    r.setUpdateDate(DateUtils.getCurrentDateTime());
                    r.setIsEnable(0);
                });
                log.info("white list 开始批量更新,entities size：{}", CollectionUtils.size(sameTRiskActionAllows));
                boolean insert =actionAllowMapper.updateBatch(sameTRiskActionAllows);
                log.info("white list 开始批量更新,entities size：{}，更新结果：{}", CollectionUtils.size(sameTRiskActionAllows), insert);

            }
            // 2选出入参req的allowType，和allowRule 与表中allow_rule和allowRule不一致并，做更新并且状态改为启用
            List<TRiskActionAllow> diffrenceTRiskActionAllows=existing.stream().filter(item-> !Objects.equals(item.getAllowRule(), req.getAllowRule()) &&
                    !Objects.equals(item.getAllowType(), req.getAllowType())
            ).collect(Collectors.toList());

            if (CollectionUtils.isNotEmpty(diffrenceTRiskActionAllows)) {
                diffrenceTRiskActionAllows.forEach(r->{
                    if(!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())){
                        r.setUpdateBy(userInfoVO.getUserInfo().getUsername());
                    }
                    r.setUpdateDate(DateUtils.getCurrentDateTime());
                    r.setAllowType(req.getAllowType());
                    r.setAllowRule(req.getAllowRule());
                    r.setIsEnable(0);
                });
                log.info("white list 开始批量更新,entities size：{}", CollectionUtils.size(diffrenceTRiskActionAllows));
                boolean insert =actionAllowMapper.updateBatch(diffrenceTRiskActionAllows);
                log.info("white list 开始批量更新,entities size：{}，更新结果：{}", CollectionUtils.size(diffrenceTRiskActionAllows), insert);

            }

            List<TRiskActionAllow> toInserting = mapping.get(Boolean.TRUE);
            if (CollectionUtils.isNotEmpty(toInserting)) {
                log.info("white list 开始创建,entities size：{}", CollectionUtils.size(toInserting));
                boolean insert = actionAllowMapper.insertBatch(toInserting);
                log.info("white list 开始创建,entities size：{}，插入结果：{}", CollectionUtils.size(toInserting), insert);
                return insert;
            }
            return false;
        }).orElse(false);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean edit(RiskActionAllowEditReq req) {
        boolean result=true;
        log.info("修改白名单，入参：{}", req);
        if(Objects.isNull(req)){
            throw new BusinessException("Parameter can't be null or empty", ResultEnum.BAD_REQUEST.getCode());
        }
        LambdaQueryWrapper<TRiskActionAllow> wrapper = buildWrapper(req);
        wrapper.eq(TRiskActionAllow::getId, req.getId());
        TRiskActionAllow tRiskActionAllow = getOne(wrapper);
        if (ObjectUtils.isEmpty(tRiskActionAllow)) {
            log.info("更新白名单查询无数据,id:{}", tRiskActionAllow.getId());
            throw new BusinessException("RiskActionRule not exist in DB",111);
        }
        //checkIsExistDuplicate rulesType+allowRecord
        LambdaQueryWrapper<TRiskActionAllow> wrapper1 = buildWrapper(req);
        wrapper1.eq(TRiskActionAllow::getAllowType, req.getAllowType());
        wrapper1.eq(TRiskActionAllow::getAllowRecord, req.getAllowRecord());
        TRiskActionAllow tRiskActionAllowIsExist = getOne(wrapper);
        if (ObjectUtils.isNotEmpty(tRiskActionAllowIsExist)){
            log.error("{} exists in db", tRiskActionAllowIsExist);
            throw new BusinessException("tRiskActionAllowIsExist can't allowed duplicate", 111);
        }
        tRiskActionAllow.setAllowType(req.getAllowType());
        tRiskActionAllow.setAllowRule(req.getAllowRule());
        tRiskActionAllow.setAllowRecord(req.getAllowRecord());
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if(!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())){
            tRiskActionAllow.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        tRiskActionAllow.setUpdateDate(DateUtils.getCurrentDateTime());

        // 记录操作日志
        TRiskActionAllowOperationLog tRiskActionAllowOperationLog = new TRiskActionAllowOperationLog();
        tRiskActionAllowOperationLog.setAllowRecord(tRiskActionAllow.getAllowRecord());
        tRiskActionAllowOperationLog.setAllowType(tRiskActionAllow.getAllowType());
        tRiskActionAllowOperationLog.setAllowRule(tRiskActionAllow.getAllowRule());
        tRiskActionAllowOperationLog.setIsEnable(tRiskActionAllow.getIsEnable());
        tRiskActionAllowOperationLog.setStatus(Integer.valueOf(ConstantVars.ONE));
        tRiskActionAllowOperationLog.setCreateDate(DateUtils.getCurrentDateTime());

        try {
            log.info("风控黑白名单操作历史明细，入参：{}", JSON.toJSONString(tRiskActionAllowOperationLog));
            this.updateById(tRiskActionAllow);
        } catch (Exception e) {
            log.error("{} 更新风控黑名单状态时异常! msg:{}", req.getId(), e.getMessage(), e);
            tRiskActionAllowOperationLog.setStatus(Integer.valueOf(ConstantVars.TWO));
            result=false;
        } finally {
            tRiskActionAllowOperationLogMapper.insert(tRiskActionAllowOperationLog);
        }
        return result;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean updateStatus(RiskActionAllowpUdateStatusReq req) {
        boolean result=true;
        log.info("修改白名单状态，入参：{}", req);
        if(Objects.isNull(req)){
            throw new BusinessException("Parameter can't be null or empty", ResultEnum.BAD_REQUEST.getCode());
        }
        LambdaQueryWrapper<TRiskActionAllow> wrapper = buildWrapper(req);
        wrapper.eq(TRiskActionAllow::getId, req.getId());
        TRiskActionAllow tRiskActionAllow = getOne(wrapper);
        if (ObjectUtils.isEmpty(tRiskActionAllow)) {
            log.info("更新白名单状态查询无数据,id:{}", tRiskActionAllow.getId());
            throw new BusinessException("TRiskActionAllow not exist in DB",111);
        }

        //如果表里TRiskActionAllow状态为传入的状态,则不可以修改
        if (Objects.equals(tRiskActionAllow.getIsEnable(),req.getIsEnable())){
            log.info("白名单数据,id:{}已经存在，无法修改", tRiskActionAllow.getId());
            throw new BusinessException("TRiskActionAllow already exist in DB,can not update status",111);
        }
        tRiskActionAllow.setIsEnable(req.getIsEnable());
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if(!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())){
            tRiskActionAllow.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        tRiskActionAllow.setUpdateDate(DateUtils.getCurrentDateTime());

        // 记录操作日志
        TRiskActionAllowOperationLog tRiskActionAllowOperationLog = new TRiskActionAllowOperationLog();
        tRiskActionAllowOperationLog.setAllowRecord(tRiskActionAllow.getAllowRecord());
        tRiskActionAllowOperationLog.setAllowType(tRiskActionAllow.getAllowType());
        tRiskActionAllowOperationLog.setAllowRule(tRiskActionAllow.getAllowRule());
        tRiskActionAllowOperationLog.setIsEnable(tRiskActionAllow.getIsEnable());
        tRiskActionAllowOperationLog.setStatus(Integer.valueOf(ConstantVars.ONE));
        tRiskActionAllowOperationLog.setCreateDate(DateUtils.getCurrentDateTime());

        try {
            log.info("风控黑白名单操作历史明细，入参：{}", JSON.toJSONString(tRiskActionAllowOperationLog));
            this.updateById(tRiskActionAllow);
        } catch (Exception e) {
            log.error("{} 更新风控黑名单状态时异常! msg:{}", req.getId(), e.getMessage(), e);
            tRiskActionAllowOperationLog.setStatus(Integer.valueOf(ConstantVars.TWO));
            result=false;
        } finally {
            tRiskActionAllowOperationLogMapper.insert(tRiskActionAllowOperationLog);
        }
        return result;
    }

    @Override
    public PageModel<RiskActionAllowPageQueryRsp> getPageList(RiskActionAllowPageQueryReq req) {
        //checkDateTime
        if (StringUtils.isNotBlank(req.getDateBegin())&&StringUtils.isNotBlank(req.getDateEnd())){
            LocalDateTime beginDateTime = DateUtils.stringToLocalDateTime(req.getDateBegin());
            LocalDateTime endDateTime = DateUtils.stringToLocalDateTime(req.getDateEnd());
            if (beginDateTime.isAfter(endDateTime)){
                throw new BusinessException("beginDateTime can not more than endDateTime",111);
            }
        }
        LambdaQueryWrapper<TRiskActionAllow> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(StringUtils.isNotBlank(req.getAllowRecord()), TRiskActionAllow::getAllowRecord, req.getAllowRecord())
                .eq(Objects.nonNull(req.getIsEnable()),TRiskActionAllow::getIsEnable, req.getIsEnable())
                .eq(Objects.nonNull(req.getAllowType()), TRiskActionAllow::getAllowType, req.getAllowType());
        //如果allowTypew为空，按时间查询的条件才生效
        if ((Objects.nonNull(req.getAllowType()))){
            wrapper.ge(TRiskActionAllow::getUpdateDate, req.getDateBegin());
            wrapper.le(TRiskActionAllow::getAllowType, req.getDateEnd());
        }
        Page<TRiskActionAllow> riskActionAllowPage = pageByWrapper(req, wrapper);
        if (CollUtil.isEmpty(riskActionAllowPage.getRecords())) {
            return new PageModel<>();
        }
        List<RiskActionAllowPageQueryRsp> list = riskActionAllowPage.getRecords().stream().map(entity -> {
            RiskActionAllowPageQueryRsp rsp = new RiskActionAllowPageQueryRsp();
            BeanUtil.copyProperties(entity, rsp);
            return rsp;
        }).toList();
        PageModel<RiskActionAllowPageQueryRsp> pageResult = new PageModel<>();
        pageResult.setData(list);
        pageResult.setPageNo((int) riskActionAllowPage.getCurrent());
        pageResult.setPageSize((int) riskActionAllowPage.getSize());
        pageResult.setTotalRow((int) riskActionAllowPage.getTotal());
        pageResult.setTotalPage((int) riskActionAllowPage.getPages());
        return pageResult;
    }


}
