package com.riskcontrol.office.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.core.lang.Opt;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cm.util.common.Constants;
import com.cn.schema.common.RabbitMQMessage;
import com.cn.schema.customers.WSCustomers;
import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.riskcontrol.common.client.MessageApiFeign;
import com.riskcontrol.common.config.UserCenterSwitch;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.pojo.Ekyc;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.request.message.PushContentReq;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.enums.EkycChannelEnum;
import com.riskcontrol.common.enums.EkycManualReasonEnum;
import com.riskcontrol.common.enums.EkycStatusEnum;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.service.UserCenterTemplate;
import com.riskcontrol.common.service.WsFeignTemplate;
import com.riskcontrol.common.utils.CopyWsCustomerUtil;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.common.utils.LogUtils;
import com.riskcontrol.common.utils.PHPDESEncrypt;
import com.riskcontrol.office.common.constants.ConstantVars;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.domain.entity.TEkyc;
import com.riskcontrol.office.domain.entity.TEkycRequest;
import com.riskcontrol.office.domain.req.ekyc.*;
import com.riskcontrol.office.domain.rsp.ekyc.EkycRequestInfoResponse;
import com.riskcontrol.office.domain.rsp.ekyc.EkycRequestQueryResponse;
import com.riskcontrol.office.kafka.KafkaTopic;
import com.riskcontrol.office.mapper.EkycDeduplicateMapper;
import com.riskcontrol.office.mapper.EkycRequestMapper;
import com.riskcontrol.office.service.EkycDoSaveService;
import com.riskcontrol.office.service.EkycRequestService;
import com.riskcontrol.office.service.EkycService;
import com.riskcontrol.office.template.SmsApiTemplate;
import com.riskcontrol.office.util.KafkaProductUtils;
import com.riskcontrol.office.util.RabbitMQUtils;
import com.riskcontrol.office.util.RedisUtils;
import com.riskcontrol.office.util.aws.AWSS3Util;
import com.ws.SmsContent;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.FastDateFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.math.BigInteger;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import static com.riskcontrol.common.constants.Constant.RISK_EKYC_STATUS_KEY;
import static com.riskcontrol.common.utils.BillNoUtil.getBillNo;
import static com.riskcontrol.common.utils.DateUtils.calcAgeByBirthday;
import static com.riskcontrol.office.common.constants.Constants.CALC_AGE_BY_BIRTHDAY;


/**
 * @author Heng.zhang
 */
@Service
@Slf4j
public class EkycRequestServiceImpl extends BaseServiceImpl<EkycRequestMapper, TEkycRequest> implements EkycRequestService {
    @Autowired
    @Lazy
    private EkycService ekycService;
    @Autowired
    private EkycDoSaveService ekycDoSaveService;

    @Resource
    private WsFeignTemplate wsFeignTemplate;

    @Resource
    private UserCenterTemplate userCenterTemplate;

    @Resource
    protected RedisUtils redisUtils;
    @Resource
    private MessageApiFeign messageApiFeign;

    @Value("${C66.push.exchange:exchange_template_job_message}")
    private String pushExchange;
    @Value("${C66.push.routing.key:C66.routing.template.job.message.queue}")
    private String pushRoutingKey;
    @Value("${kyc.test.img.url:}")
    private String testUrl;
    @Resource
    private SmsApiTemplate smsApiTemplate;
    @Resource
    private AWSS3Util awss3Util;

    @Resource
    private KafkaProductUtils kafkaProductUtils;
    private final ExecutorService executorService = Executors.newFixedThreadPool(5);

    @Override
    public PageModel<EkycRequestQueryResponse> pageEkycRequestList(EkycRequestQueryRequest req) {
        if(StringUtils.isNotBlank(req.getLoginName()) || StringUtils.isNotBlank(req.getBillNo())){
            req.setDateBegin(null);
            req.setDateEnd(null);
        }
        checkQueryDateCannotSpanDays(req);
        LambdaQueryWrapper<TEkycRequest> wrapper = buildWrapper(req);
        modifyWrapper(wrapper, req);
        wrapper.orderByDesc(TEkycRequest::getCreateDate);
        Page<TEkycRequest> page = pageByWrapper(req, wrapper);
        List<EkycRequestQueryResponse> ekycRequestList = page.getRecords().stream().map(p -> {
            EkycRequestQueryResponse rsp = new EkycRequestQueryResponse();
            BeanUtil.copyProperties(p, rsp);
            try {
                if (StringUtils.isNotBlank(testUrl)) {//返回测试默认图片
                    if (StringUtils.isNotBlank(p.getIdFrontImg())) {
                        rsp.setIdFrontUrl(testUrl);
                    }
                    if (StringUtils.isNotBlank(p.getIdBackImg())) {
                        rsp.setIdBackUrl(testUrl);
                    }
                    if (StringUtils.isNotBlank(p.getFaceImg())) {
                        rsp.setFaceUrl(testUrl);
                    }
                } else {
                    if (StringUtils.isNotBlank(p.getIdFrontImg())) {
                        rsp.setIdFrontUrl(p.getIdFrontImg().startsWith("http") ? p.getIdFrontImg() : p.getIdFrontImg().contains("_md5") ? awss3Util.s3GetTxtUrl(p.getIdFrontImg()) : awss3Util.s3GetUrl(p.getIdFrontImg()));
                    }
                    if (StringUtils.isNotBlank(p.getIdBackImg())) {
                        rsp.setIdBackUrl(p.getIdBackImg().startsWith("http") ? p.getIdBackImg() : p.getIdBackImg().contains("_md5") ? awss3Util.s3GetTxtUrl(p.getIdBackImg()) : awss3Util.s3GetUrl(p.getIdBackImg()));
                    }
                    if (StringUtils.isNotBlank(p.getFaceImg())) {
                        rsp.setFaceUrl(p.getFaceImg().startsWith("http") ? p.getFaceImg() : p.getFaceImg().contains("_md5") ? awss3Util.s3GetTxtUrl(p.getFaceImg()) : awss3Util.s3GetUrl(p.getFaceImg()));
                    }
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            return rsp;
        }).collect(Collectors.toList());
        PageModel<EkycRequestQueryResponse> ekycRequestRsp = new PageModel<>();
        ekycRequestRsp.setData(ekycRequestList);
        ekycRequestRsp.setPageNo((int) page.getCurrent());
        ekycRequestRsp.setPageSize((int) page.getSize());
        ekycRequestRsp.setTotalRow((int) page.getTotal());
        ekycRequestRsp.setTotalPage((int) page.getPages());
        return ekycRequestRsp;
    }

    /**
     * 更新warpper*
     *
     * @param wrapper
     * @param req
     */
    private void modifyWrapper(LambdaQueryWrapper<TEkycRequest> wrapper, EkycRequestQueryRequest req) {
        String firstName = req.getFirstName();
        String middleName = req.getMiddleName();
        String lastName = req.getLastName();
        if (StringUtils.isNotBlank(firstName) && StringUtils.isBlank(middleName) && StringUtils.isNotBlank(lastName)) {
            wrapper.eq(TEkycRequest::getMiddleName, "");
        }
    }

    @Override
    public EkycRequestInfoResponse getEkycRequestDetail(BigInteger id) {
        LambdaQueryWrapper<TEkycRequest> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(TEkycRequest::getId, id);
        return Optional.ofNullable(getOne(wrapper)).map(info -> {
            EkycRequestInfoResponse ekycRequestInfoResponse = new EkycRequestInfoResponse();
            BeanUtil.copyProperties(info, ekycRequestInfoResponse);
            try {
                if (StringUtils.isNotBlank(testUrl)) {
                    if (StringUtils.isNotBlank(info.getIdFrontImg())) {
                        ekycRequestInfoResponse.setIdFrontUrl(testUrl);
                    }
                    if (StringUtils.isNotBlank(info.getIdBackImg())) {
                        ekycRequestInfoResponse.setIdBackUrl(testUrl);
                    }
                    if (StringUtils.isNotBlank(info.getFaceImg())) {
                        ekycRequestInfoResponse.setFaceUrl(testUrl);
                    }
                    if (StringUtils.isNotBlank(info.getManualImg())) {
                        ekycRequestInfoResponse.setManualUrl(testUrl);
                    }
                } else {
                    if (StringUtils.isNotBlank(info.getIdFrontImg())) {
                        ekycRequestInfoResponse.setIdFrontUrl(info.getIdFrontImg().startsWith("http") ? info.getIdFrontImg() : info.getIdFrontImg().contains("_md5") ? awss3Util.s3GetTxtUrl(info.getIdFrontImg()) : awss3Util.s3GetUrl(info.getIdFrontImg()));
                    }
                    if (StringUtils.isNotBlank(info.getIdBackImg())) {
                        ekycRequestInfoResponse.setIdBackUrl(info.getIdBackImg().startsWith("http") ? info.getIdBackImg() : info.getIdBackImg().contains("_md5") ? awss3Util.s3GetTxtUrl(info.getIdBackImg()) : awss3Util.s3GetUrl(info.getIdBackImg()));
                    }
                    if (StringUtils.isNotBlank(info.getFaceImg())) {
                        ekycRequestInfoResponse.setFaceUrl(info.getFaceImg().startsWith("http") ? info.getFaceImg() : info.getFaceImg().contains("_md5") ? awss3Util.s3GetTxtUrl(info.getFaceImg()) : awss3Util.s3GetUrl(info.getFaceImg()));
                    }
                    if (StringUtils.isNotBlank(info.getManualImg())) {
                        ekycRequestInfoResponse.setManualUrl(info.getManualImg().startsWith("http") ? info.getManualImg() : info.getManualImg().contains("_md5") ? awss3Util.s3GetTxtUrl(info.getManualImg()) : awss3Util.s3GetUrl(info.getManualImg()));
                    }
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            return ekycRequestInfoResponse;
        }).orElseThrow(() -> {
            throw new BusinessException("user not found", 50010);
        });
    }

    @Override
    public boolean ekycRequestCreate(EkycRequestCreateRequest request) {
        log.info("创建ekyc提案，入参：{}", request);
        LambdaQueryWrapper<TEkycRequest> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(TEkycRequest::getLoginName, request.getLoginName());
        wrapper.eq(TEkycRequest::getStatus, EkycStatusEnum.PENDING.getEKycReqStatus());
        wrapper.last("LIMIT 1");
        TEkycRequest ekycStatus = getOne(wrapper);
        if(Objects.nonNull(ekycStatus)){
            throw new BusinessException(ResultEnum.EKYC_REQUEST_CREATE_STATUS_ERROR);
        }
        // 判断是否满21岁
        if (calcAgeByBirthday(request.getBirthday()) < CALC_AGE_BY_BIRTHDAY) {
            throw new BusinessException("Under 21 years of age", ResultEnum.BAD_REQUEST.getCode());
        }
        WSCustomers wsCustomers = getWsCustomer(request.getLoginName());
        if (Objects.isNull(wsCustomers)) {
            throw new BusinessException("login Name not exits", ResultEnum.BAD_REQUEST.getCode());
        }
        TEkycRequest ekycRequestEntity = new TEkycRequest();
        BeanUtil.copyProperties(request, ekycRequestEntity);
        ekycRequestEntity.setChannel(EkycChannelEnum.MANUAL.getChannelId());
        ekycRequestEntity.setBillNo(getBillNo());
        ekycRequestEntity.setCustomerId(wsCustomers.getCustomerId());
        ekycRequestEntity.setStatus(EkycStatusEnum.PENDING.getEKycReqStatus());
        // 默认转人工审核原因 是客服提交
        ekycRequestEntity.setManualReason(EkycManualReasonEnum.CS_SUBMISSION.getId());
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            ekycRequestEntity.setCreateBy(userInfoVO.getUserInfo().getUsername());
        }

        log.info("创建ekyc提案，ekycRequestEntity：{}", JSON.toJSONString(ekycRequestEntity));
        return ekycDoSaveService.doSave(ekycRequestEntity);
    }

    @Override
    public boolean ekycRequestUpdate(EkycRequestUpdateRequest request) {
        LambdaQueryWrapper<TEkycRequest> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(TEkycRequest::getId, request.getId());
        TEkycRequest info = getOne(wrapper);
        if (info == null) {
            throw new BusinessException("id not exist", ResultEnum.BAD_REQUEST.getCode());
        }
        if (!Objects.equals(EkycStatusEnum.PENDING.getEKycReqStatus(), info.getStatus())) {
            throw new BusinessException("The status is incorrect, and it cannot be modified", ResultEnum.BAD_REQUEST.getCode());
        }
        // 判断是否满21岁
        Integer age = DateUtils.calcAgeByBirthday(request.getBirthday());
        if (Objects.nonNull(age)) {
            if (age < CALC_AGE_BY_BIRTHDAY) {
                throw new BusinessException("Under 21 years of age", ResultEnum.BAD_REQUEST.getCode());
            }
        }
        TEkycRequest ekycRequestEntity = info;
        BeanUtil.copyProperties(request, ekycRequestEntity);
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            ekycRequestEntity.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        ekycRequestEntity.setUpdateDate(DateUtils.getCurrentDateTime());
        updateById(ekycRequestEntity);
        return true;
    }


    @Override
    public boolean ekycRequestApproved(EkycRequestApprovedRequest request) {
        LambdaQueryWrapper<TEkycRequest> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(TEkycRequest::getId, request.getId());
        TEkycRequest info = Optional.ofNullable(getOne(wrapper)).orElseThrow(() ->{
            throw new BusinessException("id not exist", ResultEnum.BAD_REQUEST.getCode());
        });
        if (!Objects.equals(EkycStatusEnum.PENDING.getEKycReqStatus(), info.getStatus())) {
            throw new BusinessException("The order status is incorrect", ResultEnum.BAD_REQUEST.getCode());
        }
        // 查询ws的用户信息
        WSCustomers wsCustomer = Optional.ofNullable(getWsCustomer(info.getLoginName())).orElseThrow(() -> {
            throw new BusinessException("customer not exist", ResultEnum.BAD_REQUEST.getCode());
        });
        log.info("Ekyc审批调用WS获取customer返回信息：{}", JSON.toJSONString(wsCustomer));
        try {
            // 保存到ekyc申请表和ekyc表
            TEkycRequest ekycRequestEntity = getEkycRequestBean(request, info);
            TEkyc ekycEntity = getEkycBean(ekycRequestEntity);
            log.info("Ekyc审批更新表的入参：ekyc_request:{},ekyc:{}", JSON.toJSONString(ekycRequestEntity), JSON.toJSONString(ekycEntity));
            // 更新ws 和ekyc表
            ekycDoSaveService.doUpdate(ekycRequestEntity, ekycEntity, wsCustomer);
            // 审批通过发送短信和推送消息
            if (Objects.equals(Objects.toString(EkycStatusEnum.APPROVAL.getEKycReqStatus()), request.getStatus())) {
                this.processSend(ekycRequestEntity, true, wsCustomer);
                this.sendApproveKycMq(wsCustomer,ekycEntity.getStatus().toString());
            }
            // 审批拒绝发送短信和推送消息
            if (Objects.equals(Objects.toString(EkycStatusEnum.REJECTED_MANUAL.getEKycReqStatus()), request.getStatus())) {
                this.processSend(ekycRequestEntity, false, wsCustomer);
            }
        }  finally {
            // 删除redis缓存
            clearCache(info.getLoginName());
        }
        return true;
    }

    @Override
    public Long getTopCount() {
        Date date = new Date();
        Date startDate = DateUtils.addDay(date, -3);
        String beginDateStr = DateUtils.dateToString(startDate) + " 00:00:00";
        String endDateStr = DateUtils.formatToDayEnding(date);
        LambdaQueryWrapper<TEkycRequest> wrapper = new LambdaQueryWrapper<>();
        wrapper.ge(TEkycRequest::getCreateDate, beginDateStr)
                .le(TEkycRequest::getCreateDate, endDateStr)
                .eq(TEkycRequest::getStatus, EkycStatusEnum.PENDING.getEKycReqStatus());
        return count(wrapper);
    }

    @Override
    public Map<String, String> upload(MultipartFile file) {
        try {
            byte[] contents = IoUtil.readBytes(file.getInputStream());
            String path = UUID.randomUUID().toString();
            awss3Util.s3PutObject(Base64.getEncoder().encodeToString(contents), path);
            return Map.of("path", path, "url", awss3Util.s3GetUrl(path));
        } catch (Exception e) {
            log.error("上传到S3服务失败", e);
            throw new BusinessException(ResultEnum.UPLOAD_TO_S3_ERROR);
        }
    }

    @Override
    public Boolean updateWsUserInfo(TEkyc ekyc, WSCustomers wsCustomers) {
        log.info("ekyc审批通过 更新T_CUSTOMERS start");
        WSCustomers result = null;
        Ekyc commEkyc = new Ekyc();
        BeanUtil.copyProperties(ekyc, commEkyc);
        CopyWsCustomerUtil.copy(commEkyc, wsCustomers);
        wsCustomers.setLastUpdate(ekyc.getUpdateDate());
        if (UserCenterSwitch.getSwitch()) {
            log.info("ekyc审批通过 userCenterTemplate更新T_CUSTOMERS,入参：{}", JSON.toJSONString(wsCustomers));
            result = userCenterTemplate.completeCustomer(wsCustomers);
        } else {
            log.info("ekyc审批通过 wsFeignTemplate更新T_CUSTOMERS,入参：{}", JSON.toJSONString(wsCustomers));
            result = wsFeignTemplate.completeCustomer(wsCustomers);
        }
        log.info("ekyc审批通过 更新T_CUSTOMERS end,result is {}", JSON.toJSONString(result));
        return Objects.nonNull(result);
    }

    /**
     * 获取ekyc申请表的更新数据
     *
     * @param approvedrequest
     * @return
     */
    private TEkycRequest getEkycRequestBean(EkycRequestApprovedRequest approvedrequest, TEkycRequest ekycRequest) {
        TEkycRequest ekycRequestEntity = ekycRequest;
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            ekycRequestEntity.setApprovedBy(userInfoVO.getUserInfo().getUsername());
            ekycRequestEntity.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        ekycRequestEntity.setApprovedDate(DateUtils.getCurrentDateTime());
        ekycRequestEntity.setUpdateDate(DateUtils.getCurrentDateTime());
        // 审批通过
        if (Objects.equals(Objects.toString(EkycStatusEnum.APPROVAL.getEKycReqStatus()), approvedrequest.getStatus())) {
            ekycRequestEntity.setStatus(EkycStatusEnum.APPROVAL.getEKycReqStatus());
        }
        // 拒绝
        if (Objects.equals(Objects.toString(EkycStatusEnum.REJECTED_MANUAL.getEKycReqStatus()), approvedrequest.getStatus())) {
            ekycRequestEntity.setStatus(EkycStatusEnum.REJECTED_MANUAL.getEKycReqStatus());
            ekycRequestEntity.setRejectReason(approvedrequest.getRejectReason());
        }
        if (StringUtils.isNotBlank(approvedrequest.getRemark())) {
            ekycRequestEntity.setRemark(approvedrequest.getRemark());
        }
        return ekycRequestEntity;
    }

    /**
     * 获取ekyc主表的更新数据
     *
     * @param request
     * @return
     */
    private TEkyc getEkycBean(TEkycRequest request) {
        TEkyc ekycEntity = ekycService.getEkycInfo(request.getLoginName());
        TEkyc newEkycEntity = new TEkyc();
        //如果审批是拒绝状态，主表状态是通过状态，不修改任何主表信息
        if(Objects.equals(EkycStatusEnum.REJECTED_MANUAL.getEKycReqStatus(), request.getStatus()) &&
                (Objects.equals(EkycStatusEnum.APPROVAL.getEkycStatus(), ekycEntity.getStatus())
                    || Objects.equals(EkycManualReasonEnum.CS_SUBMISSION.getId(), request.getManualReason()))){
            return null;
        }
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        // 审批通过
        if (Objects.equals(EkycStatusEnum.APPROVAL.getEKycReqStatus(), request.getStatus())) {
            BeanUtil.copyProperties(request,newEkycEntity);
            newEkycEntity.setStatus(EkycStatusEnum.APPROVAL.getEkycStatus());
        }
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            newEkycEntity.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        // 拒绝
        if (Objects.equals(EkycStatusEnum.REJECTED_MANUAL.getEKycReqStatus(), request.getStatus())) {
            newEkycEntity.setStatus(EkycStatusEnum.REJECTED_MANUAL.getEkycStatus());
            newEkycEntity.setRejectReason(request.getRejectReason());
        }
        newEkycEntity.setUpdateDate(DateUtils.getCurrentDateTime());
        newEkycEntity.setRemark(request.getRemark());
        newEkycEntity.setId(ekycEntity.getId());
        return newEkycEntity;
    }

    /**
     * 获取用户CustomerId
     *
     * @param loginName
     * @return
     */
    public WSCustomers getWsCustomer(String loginName) {
        WSCustomers wsCustomers;
        if (UserCenterSwitch.getSwitch()) {
            wsCustomers = userCenterTemplate.getSimpleCustomerByLoginName(Constants.C66, loginName);
        } else {
            wsCustomers = wsFeignTemplate.getCustomerByLoginName(Constants.C66, loginName);
        }
        return wsCustomers;
    }

    /**
     * 操作完成删除缓存*
     *
     * @param loginName
     */
    private void clearCache(String loginName) {
        RedisUtils.remove(String.format(RISK_EKYC_STATUS_KEY, loginName));
    }

    private Boolean processSend(TEkycRequest ekycRequest, boolean isApproval, WSCustomers wsCustomer) {
        //获取对应产线和短信模板Id
        Map<String, String> productSwitchMap = redisUtils.entries("r-0013");
        if (!productSwitchMap.isEmpty()) {
            log.info("人工创建Ekyc审核获取短信 产品：{}", JSON.toJSONString(productSwitchMap));
            String key;
            Map<String, String> contextMap = LogUtils.getMDCContextMap();
            if (isApproval) {
                key = ekycRequest.getTenant().concat(Constant.EKYC_SUCCESS_SMS_SUFFIX);
                if (productSwitchMap.containsKey(key) && StringUtils.isNotBlank(wsCustomer.getPhone())) {
                    String templateId = productSwitchMap.get(key);
                    CompletableFuture.runAsync(() -> {
                        LogUtils.setMDCContextMap(contextMap);
                        sendMessage(ekycRequest, true, wsCustomer, templateId);
                    }, executorService);
                }
                key = ekycRequest.getTenant().concat(Constant.EKYC_SUCCESS_PUSH_SUFFIX);
                if (productSwitchMap.containsKey(key)) {
                    String templateId = productSwitchMap.get(key);
                    CompletableFuture.runAsync(() -> {
                        LogUtils.setMDCContextMap(contextMap);
                        pushMessage(ekycRequest, true, templateId);
                    }, executorService);
                }
            } else {
                key = ekycRequest.getTenant().concat(Constant.EKYC_REJECT_SMS_SUFFIX);
                if (productSwitchMap.containsKey(key) && StringUtils.isNotBlank(wsCustomer.getPhone())) {
                    String templateId = productSwitchMap.get(key);
                    CompletableFuture.runAsync(() -> {
                        LogUtils.setMDCContextMap(contextMap);
                        sendMessage(ekycRequest, false, wsCustomer, templateId);
                    }, executorService);
                }
                key = ekycRequest.getTenant().concat(Constant.EKYC_REJECT_PUSH_SUFFIX);
                if (productSwitchMap.containsKey(key)) {
                    String templateId = productSwitchMap.get(key);
                    CompletableFuture.runAsync(() -> {
                        LogUtils.setMDCContextMap(contextMap);
                        pushMessage(ekycRequest, false, templateId);
                    }, executorService);
                }
            }

        }
        return true;
    }

    protected void sendMessage(TEkycRequest req, boolean isApproval, WSCustomers wsCustomer, String templateId) {
        try {
            log.info("人工创建Ekyc审核{}后发送短信 requestId:{}", isApproval ? "成功" : "失败", req.getBillNo());
            // 玩家信息
            SmsContent sendSMS = new SmsContent();
            // 开始发送短信
            sendSMS.setPhone(PHPDESEncrypt.getNewInstance(Constants.C66, "03").decrypt(wsCustomer.getPhone()));
            sendSMS.setLoginname(wsCustomer.getLoginName());
            if (!isApproval) {
                sendSMS.setParam1(req.getRejectReason());
            }
            //短信类型
            sendSMS.setSmstype(templateId);
            //是否使用模板:0使用，1不使用
            sendSMS.setUseTemplateFlag(ConstantVars.ZERO);
            sendSMS.setRequestId(req.getBillNo());
            sendSMS.setTenant(req.getTenant());
            sendSMS.setSendType(ConstantVars.getSiteIdByTenant(req.getTenant()));
            log.info("人工创建Ekyc审核,发送短信前入参:{}", JSON.toJSONString(sendSMS));
            smsApiTemplate.sendSMS(Constants.C66, sendSMS);
        } catch (Exception e) {
            log.error("人工创建Ekyc审核{}后发送短信报错", isApproval ? "成功" : "失败", e);
        }
    }

    private void pushMessage(TEkycRequest req, boolean isApproval, String typeValue) {
        try {
            log.info("人工创建Ekyc审核{}后推送push requestId:{}", isApproval ? "成功" : "失败", req.getBillNo());
            PushContentReq pushContentReq = new PushContentReq();
            JSONObject params = new JSONObject();
            if (!isApproval) {
                params.put("{0}", req.getRejectReason());
            }
            pushContentReq.setLoginName(req.getLoginName());
            pushContentReq.setBillNo(req.getBillNo());
            pushContentReq.setParamId(typeValue);
            pushContentReq.setData(params);
            log.info("人工创建Ekyc审核,推送消息前入参:{}", JSON.toJSONString(pushContentReq));
            messageApiFeign.pushMessage(pushExchange, pushRoutingKey, JSONObject.toJSONString(pushContentReq));
        } catch (Exception e) {
            log.error("人工创建Ekyc审核{}后推送push报错", isApproval ? "成功" : "失败", e);
        }
    }

    @SneakyThrows
    private void checkQueryDateCannotSpanDays(EkycRequestQueryRequest req){
        if(StringUtils.isNotBlank(req.getDateBegin()) || StringUtils.isNotBlank(req.getDateEnd())){
            if(StringUtils.isBlank(req.getDateBegin()) || StringUtils.isBlank(req.getDateEnd())){
                throw new BusinessException(ResultEnum.EKYC_QUERY_DATE_CANNOT_SPAN_DAYS_ERROR);
            }
            var fastDateFormatOne = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss");
            var fastDateFormatTwo = FastDateFormat.getInstance("yyyy-MM-dd");
            if(!fastDateFormatTwo.format(fastDateFormatOne.parse(req.getDateBegin())).equals(fastDateFormatTwo.format(fastDateFormatOne.parse(req.getDateEnd())))){
                throw new BusinessException(ResultEnum.EKYC_QUERY_DATE_CANNOT_SPAN_DAYS_ERROR);
            }
        }
    }

    /**
     * 发送消息到优惠
     * @param wsCustomers
     * @param kycStatus
     */
    private void sendApproveKycMq(WSCustomers wsCustomers,String kycStatus) {
        String mqSwitch = redisUtils.getHashValue("r-0004", "message-approve-kyc-switch", String.class);
        if("1".equals(mqSwitch)){
            RabbitMQUtils.sendCustomerUpdateKyc(RabbitMQUtils.buildCustomerKycStatusParams(wsCustomers, kycStatus));
        }else if("2".equals(mqSwitch)){
            RabbitMQMessage<JSONObject> message = new RabbitMQMessage<>(RabbitMQUtils.EXCHANGE_ENUM.CUSTOMER_UPDATE_KYC.getRoutingKey(),
                    RabbitMQUtils.buildCustomerKycStatusParams(wsCustomers, kycStatus));
            kafkaProductUtils.pushKafkaMsg(KafkaTopic.APPROVE_KYC_TOPIC,JSONObject.toJSONString(message));
        }else{
            log.info("sendCustomerUpdateKyc MESSAGE_PUSH_APPROVE_KYC_SWITCH is close");
        }
        //单独尝试一条风控自己消费的消息
        JSONObject selfObject = new JSONObject();
        selfObject.put("loginName",wsCustomers.getLoginName());
        selfObject.put("productId",wsCustomers.getProductId());
        selfObject.put("isOldKyc",false);//用来判断是否老kyc
        kafkaProductUtils.pushKafkaMsg(KafkaTopic.APPROVE_KYC_TOPIC_SELF,selfObject.toJSONString());
    }
}
