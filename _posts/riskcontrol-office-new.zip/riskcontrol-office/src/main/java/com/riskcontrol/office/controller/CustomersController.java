package com.riskcontrol.office.controller;

import com.cn.schema.customers.WSKycRequest;
import com.cn.schema.customers.WSKycSheetRequest;
import com.digiplus.oms.aspect.annotation.PreAuthorize;
import com.riskcontrol.common.entity.request.QueryPageByKycRequestId;
import com.riskcontrol.common.entity.request.api.QueryKycRequestReq;
import com.riskcontrol.common.entity.request.api.UpdateKycRequestReq;
import com.riskcontrol.common.entity.request.kyc.WSKycRequestGw;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelRsp;
import com.riskcontrol.office.annotation.EnableOperationLog;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.common.constants.Constants;
import com.riskcontrol.office.domain.constans.req.UpdateCustomerRiskLabelReq;
import com.riskcontrol.office.domain.customers.req.KycSheetRequest;
import com.riskcontrol.office.domain.customers.req.QueryCustomerByLoginNameReq;
import com.riskcontrol.office.domain.customers.req.QueryCustomersReq;
import com.riskcontrol.office.domain.customers.req.QueryParentAccountReq;
import com.riskcontrol.office.domain.customers.rsp.WsCustomer;
import com.riskcontrol.office.domain.entity.TLabelRuleRelationship;
import com.riskcontrol.office.domain.entity.TRiskLabelRelationship;
import com.riskcontrol.office.domain.enums.OpTypeEnum;
import com.riskcontrol.office.service.ICustomersService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterStyle;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * @author dante
 * @date 2024/03/11
 */
@Tag(name = "门店KYC&PBC风控审批", description = "会员业务接口")
@RestController
@RequestMapping(value = "office/customer")
public class CustomersController {
    private static final Logger logger = LoggerFactory.getLogger(CustomersController.class);
    @Resource
    private ICustomersService customersService;
    @PreAuthorize("riskManage_kycpbc_query")
    @Operation(tags ="门店KYC&PBC风控审批" ,summary = "查询玩家KYC信息")
    @PostMapping(value = "queryKycRequests")
    @ResponseBody
    public R<PageModel<WSKycRequestGw>> queryKycRequestsNew(@RequestBody QueryKycRequestReq req) {
        logger.info("queryKycRequestsNew queryKycRequestsNew 方法进来了 --------------------------------------------------------------------------- {}", new Date());
        Response<PageModel<WSKycRequestGw>> resp = customersService.queryKycRequestsNewRisk(req);
        boolean isSuccess = Constants.SUCCESS_CODE.equals(resp.getHead().getErrCode());
        return isSuccess ? R.ok(resp.getBody()) : R.failed(resp.getHead().getErrMsg());

    }
    @Deprecated
    @Operation(tags ="门店KYC&PBC风控审批" ,summary = "批量审核PBC")
    @PostMapping("/uploadPBCInfoBatch")
    @Parameters({@Parameter(style = ParameterStyle.FORM, required = true, name = "files", description = "上传Excel模板文件", schema = @Schema(type = "MultipartFile"))})
    @EnableOperationLog(menuName="风控管理",subMenuName="KYC&PBC",opLog = "批量审批KYC",opLogType= OpTypeEnum.APPROVAL)
    public R<List<WSKycRequest>> uploadPBCInfoBatchNew(HttpServletRequest request,
                                                       @RequestParam(value = "files") MultipartFile files) throws Exception {
        Response<List<WSKycRequest>> resp = new Response<>();
        try {
            if (Objects.nonNull(files)) {
                resp = customersService.uploadPBCInfoBatchNewRisk(files, request);
                logger.info(" uploadPBCInfoBatchNewRisk...  resp {}", resp);
            }
        } catch (Exception e) {
            logger.error("{}  批量审核PBC(uploadPBCInfoBatch) 出异常了，异常信息：{}", new Date(), e.getMessage());
        }
        boolean isSuccess = Constants.SUCCESS_CODE.equals(resp.getHead().getErrCode());
        return isSuccess ? R.ok(resp.getBody()) : R.failed(resp.getHead().getErrMsg());
    }
    @PreAuthorize("riskManage_kycpbc_export")
    @Operation(tags ="门店KYC&PBC风控审批" ,summary = "查询(导出)玩家KYC表单信息")
    @PostMapping(value = "queryKycSheetRequests")
    @ResponseBody
    @EnableOperationLog(menuName="风控管理",subMenuName="KYC&PBC",opLog = "导出",opLogType= OpTypeEnum.EXPORT)
    public R<PageModel<KycSheetRequest>> queryKycSheetList(@RequestBody QueryKycRequestReq req) throws Exception {

        logger.info("queryKycSheetList 进来了--------------------------------------------------------------------------------------");
        Response<PageModel<KycSheetRequest>> resp = customersService.queryKycSheetRequestsRisk(req);

        boolean isSuccess = Constants.SUCCESS_CODE.equals(resp.getHead().getErrCode());
        return isSuccess ? R.ok(resp.getBody()) : R.failed(resp.getHead().getErrMsg());
    }
    @PreAuthorize("riskManage_kycpbc_approveKyc")
    @Operation(tags ="门店KYC&PBC风控审批" ,summary = "审批玩家KYC信息")
    @PostMapping(value = "approveKYCInfo")
    @ResponseBody
    @EnableOperationLog(menuName="风控管理",subMenuName="KYC&PBC",opLog = "审批KYC",opLogType= OpTypeEnum.APPROVAL)
    public R approveKYCInfo(@RequestBody UpdateKycRequestReq req) throws Exception {
        logger.info("approveKYCInfo 进来了--------------------------------------------------------------------------------------");
        boolean isSuccess = customersService.updateKycRequestRisk(req);
        return isSuccess ? R.ok() : R.failed();
    }
    @PreAuthorize("riskManage_kycpbc_approvePbc")
    @Operation(tags ="门店KYC&PBC风控审批" ,summary = "审批玩家PBC信息")
    @PostMapping(value = "approvePBCInfo")
    @ResponseBody
    @EnableOperationLog(menuName="风控管理",subMenuName="KYC&PBC",opLog = "审批PBC",opLogType= OpTypeEnum.APPROVAL)
    public R approvePBCInfo(@RequestBody UpdateKycRequestReq req) throws Exception {
        logger.info("approvePBCInfo 进来了--------------------------------------------------------------------------------------");
        boolean isSuccess = customersService.updatePbcRequestRisk(req);
        return isSuccess ? R.ok() : R.failed();

    }
    @PreAuthorize("riskManage_kycpbc_query")
    @Operation(tags ="门店KYC&PBC风控审批" ,summary = "kycLog查询")
    @PostMapping(value = "queryPageByKycRequestId")
    @ResponseBody
    public R queryPageByKycRequestId( @RequestBody QueryPageByKycRequestId req) throws Exception {

        logger.info("queryPageByKycRequestId 进来了--------------------------------------------------------------------------------------");
        Response resp = customersService.queryPageByKycRequestIdRisk(req);
        boolean isSuccess = Constants.SUCCESS_CODE.equals(resp.getHead().getErrCode());
        return isSuccess ? R.ok(resp.getBody()) : R.failed(resp.getHead().getErrMsg());
    }
    @PreAuthorize("riskManage_kycpbc_query")
    @Operation(tags = "根据登录名查询玩家详细信息",summary = "根据登录名查询玩家详细信息")
    @PostMapping(value = "detail")
    @ResponseBody
    public Response<WsCustomer> queryCustomerByLoginName(@RequestBody QueryCustomerByLoginNameReq req) throws Exception {
        return customersService.queryCustomerByLoginName(req);
    }
    @PreAuthorize("riskManage_labelConfig_view")
    @Operation(tags ="门店KYC&PBC风控审批" ,summary = "查询玩家风控标签详细信息")
    @PostMapping(value = "riskLabel/detail")
    @ResponseBody
    public R<CustomerRiskLabelRsp> queryRiskLabel( @RequestBody QueryCustomersReq req) throws Exception {
        Response<CustomerRiskLabelRsp> resp = customersService.queryRiskLabel(req);
        boolean isSuccess = Constants.SUCCESS_CODE.equals(resp.getHead().getErrCode());
        return isSuccess ? R.ok(resp.getBody()) : R.failed(resp.getHead().getErrMsg());
    }
    @PreAuthorize("riskManage_labelConfig_modify")
    @Operation(tags ="门店KYC&PBC风控审批" ,summary = "修改玩家风控标签详细信息")
    @PostMapping(value = "riskLabel/modify")
    @ResponseBody
    @EnableOperationLog(menuName="风控管理",subMenuName="KYC&PBC",opLog = "修改标签",opLogType= OpTypeEnum.APPROVAL)
    public R<Boolean> modifyRiskLabel( @RequestBody UpdateCustomerRiskLabelReq req) throws Exception {
        Boolean bool = customersService.modifyRiskLabel(req);
        return bool ? R.ok() : R.failed();
    }
}
