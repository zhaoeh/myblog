package com.riskcontrol.office.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.domain.entity.RiskFilterLog;
import com.riskcontrol.office.domain.req.RiskFilterLogReq;
import com.riskcontrol.office.domain.withdrawal.req.WithdrawalApproveReq;

/**
 * 风控拦截日志表服务接口
 *
 * @author dante
 * @since 2024-04-18 16:45:29
 * @description 由 Mybatisplus Code Generator 创建
 */
public interface RiskFilterLogService extends IService<RiskFilterLog> {

    PageModel<RiskFilterLog> queryList(RiskFilterLogReq req);

    /**
     * 重走风控审批流程
     * @param req 请求
     */
    String retryRiskWithdrawApprove(WithdrawalApproveReq req);
}
