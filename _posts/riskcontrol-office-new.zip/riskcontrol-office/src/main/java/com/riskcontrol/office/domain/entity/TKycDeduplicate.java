package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;

/**
 * kyc证件去重表
 * @author dante
 * @TableName t_kyc_deduplicate
 */
@Schema(description="kyc证件去重表")
@TableName(value ="t_kyc_deduplicate")
@Data
public class TKycDeduplicate extends BaseEntity implements Serializable {

    /**
     * 证件类型
     */
    private Integer idType;

    /**
     * 证件号码
     */
    private String idNo;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}