package com.riskcontrol.office.domain.withdrawal.req;

import com.riskcontrol.common.entity.request.BaseQueryReq;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema
@Data
public class QueryWithdrawalListReq extends BaseQueryReq {
    @Schema(description = "开始时间", example = "2019-03-20 09:10:12")
    protected String createdDateBegin;

    @Schema(description = "结束时间", example = "2019-03-20 09:10:12")
    protected String createdDateEnd;

    @Schema(description = "取款人", example = "张三")
    private String customerName;

    @Schema(description = "建立人", example = "")
    private String createdBy;

    @Schema(description = "金額 begin", example = "")
    private String amountStart;

    @Schema(description = "金額 end", example = "")
    private String amountEnd;

    @Schema(description = "提案编号", example = "")
    private String requestId;

    @Schema(description = "process By", example = "")
    private String processedBy;

    @Schema(description = "process Begin", example = "")
    private String processedDateBegin;

    @Schema(description = "process End", example = "")
    private String processedDateEnd;

    @Schema(required = true, description = "門店代碼, 多個門店用;隔開", example = "")
    private String branchCode;

    @Schema(description = "取款状态：0  Waiting,2  Approve,-3 Denied")
    private String flag;

    @Schema(description = "取款类型: 0 线上取款, 99 门店端现金取款<br/>Withdrawal type: 0 online withdrawal, 99 offline withdrawal")
    private String catalog;

    @Schema(description = "上级,parent：a000001")
    private String[] parent;

    @Schema(description = "Market :01  Website :02 Store :03 ")
    private String chanelType;

    @Schema(description = "是否首次取款:1是,0否")
    private String firstWithdrawal;

    @Schema(description = "bingoplus :1  arenaplus :2 ")
    private Integer siteId;

    @Schema(description = "分配人")
    private String assigneeBy;

    @Schema(description = "assignee Begin", example = "")
    private String assigneeDateBegin;

    @Schema(description = "assignee End", example = "")
    private String assigneeDateEnd;

    @Schema(description = "assignee Begin", example = "")
    private String secondAssigneeTimeDateBegin;

    @Schema(description = "assignee End", example = "")
    private String secondAssigneeTimeDateEnd;

    @Schema(description = "bingoplus :1  arenaplus :2 ")
    private String transSiteId;

}
