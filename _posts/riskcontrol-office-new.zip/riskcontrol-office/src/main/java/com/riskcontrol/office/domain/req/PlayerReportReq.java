package com.riskcontrol.office.domain.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/8/7 14:57
 */
@ApiModel(value = "查询大数据存款、投注、取款报表请求对象", description = "查询大数据存款、投注、取款报表请求对象")
@Data
public class PlayerReportReq {
    @ApiModelProperty("用户名 选填")
    protected String username;
    @ApiModelProperty(value ="开始日期",required = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @NotNull(message = "sumDateBegin can't null")
    protected LocalDate sumDateBegin;
    @ApiModelProperty(value = "结束日期",required = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @NotNull(message = "sumDateEnd can't null")
    protected LocalDate sumDateEnd;
    @ApiModelProperty(value = "累计最小存款金额",required=true)
    @Min(value = 1,message = "deposit minimum 1")
    @NotNull(message = "depositAmountBegin can't null")
    protected BigDecimal depositAmountBegin;
    @ApiModelProperty(value ="累计最大存款金额")
    protected BigDecimal depositAmountEnd;
    @ApiModelProperty("最小投注比例")
    protected BigDecimal betAmountDepositRateBegin;
    @ApiModelProperty("最大投注比例")
    protected BigDecimal betAmountDepositRateEnd;
    @ApiModelProperty(value = "第几页（分页），默认 1", example = "1")
    protected Integer pageNo =1;
    @ApiModelProperty(value = "每页多少条（分页），默认 20", example = "20")
    protected Integer pageSize = 20;
    @ApiModelProperty(value = "排序条件", example = "betAmountDepositRate/deposit")
    protected String orderByFields;
    @ApiModelProperty(value = "排序条件", example = "asc/desc")
    protected boolean orderByAsc;
}
