package com.riskcontrol.office.domain.withdrawal.req;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
@Schema(title = "确认接受提现请求派单<br/>confirm request dispatch")
public class WithdrawalDispatchConfirmReq extends BaseReq {
    @Schema(required = true, description = "提案ID list, request id list", example = "")
    private List<String> requestIds;
}
