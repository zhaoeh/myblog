package com.riskcontrol.office.domain.req;

import com.riskcontrol.common.annotation.EnumValid;
import com.riskcontrol.common.annotation.StringValuesValid;
import com.riskcontrol.office.domain.enums.RiskRulesTypeEnum;
import com.riskcontrol.office.domain.enums.RiskTenanEnum;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;

@Data
@Schema(description="编辑设备指纹风控规则对象")
public class DeviceRiskRuleEditReq {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty(required = true, value = "主键id")
    @NotNull(message = "id cannot be null")
    private BigInteger id;

    @ApiModelProperty(required = true, value = "规则限制账号最大数量")
    @NotNull(message = "rulesAccountMax cannot be null")
    @Max(value = 20,message = "rulesAccountMax vlue not more than 20")
    private Byte rulesAccountMax;

    @ApiModelProperty(required = true, value = "规则数据查询天数")
    @NotNull(message = "rulesAccountMax cannot be null")
    @Max(value = 30,message = "rulesCheckday vlue not more than 30")
    @Min(value = 1,message = "rulesCheckday vlue not less than 1")
    private Byte rulesCheckday;

    @ApiModelProperty(required = true, value = "备注")
    private String remark;
}
