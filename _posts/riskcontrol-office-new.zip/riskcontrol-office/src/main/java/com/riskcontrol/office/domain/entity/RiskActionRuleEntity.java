package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigInteger;
import java.time.LocalDateTime;

/**
 * 风控行为规则配置表
 */
@Schema(description="风控行为规则配置表")
@Data
@TableName(value = "t_risk_action_rules")
public class RiskActionRuleEntity extends BaseEntity {

    @TableId(value = "id", type = IdType.ASSIGN_ID)
    @Schema(description = "id")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    /**
     * 规则校验类型（0：ip；1：设备指纹；2：ip+设备指纹）
     */
    @TableField("rules_type")
    @Schema(description = "规则校验类型（0：ip；1：设备指纹；2：ip+设备指纹）")
    private Byte rulesType;

    /**
     * 规则限制行为（0：登录；1：注册）
     */
    @TableField("rules_action")
    @Schema(description = "规则限制行为（0：登录；1：注册）")
    private Byte rulesAction;

    /**
     * 规则限制账号最大数量
     */
    @TableField("rules_account_max")
    @Schema(description = "规则限制账号最大数量")
    private Byte rulesAccountMax;

    /**
     * 规则数据查询天数（考虑废弃，使用统一配置）
     */
    @TableField("rules_check_day")
    @Schema(description = "规则数据查询天数（考虑废弃，使用统一配置）")
    private Byte rulesCheckDay;

    /**
     * 产品标识(BP/AP/GP/PG/OTHER)
     */
    @TableField("tenant")
    @Schema(description = "产品标识(BP/AP/GP/PG/OTHER)")
    private String tenant;

    /**
     * 是否启用（0：启用；1：禁用）
     */
    @TableField("is_enable")
    @Schema(description = "是否启用（0：启用；1：禁用）")
    private Byte isEnable;

    /**
     * 创建时间
     */
    @TableField("create_date")
    @Schema(description = "创建时间")
    private String createDate;

    /**
     * 更新时间
     */
    @TableField("update_date")
    @Schema(description = "更新时间")
    private String updateDate;

    /**
     * 创建人
     */
    @TableField("create_by")
    @Schema(description = "创建人")
    private String createBy;

    /**
     * 更新人
     */
    @TableField("update_by")
    @Schema(description = "更新人")
    private String updateBy;

    /**
     * 备注
     */
    @TableField("remark")
    @Schema(description = "备注")
    private String remark;
    
}
