package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigInteger;

/**
 * @author Heng.zhang
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_risk_action_login")
@ApiModel(value = "t_risk_action_login对象", description = "登录风控日志表")
public class TRiskActionLogin extends BaseEntity{

    @ApiModelProperty("ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    /** 设备指纹token */
    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "设备指纹token")
    private String deviceFingerprintToken;

    /** 设备指纹 */
    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "设备指纹")
    private String deviceFingerprint;

    /** 登陆IP地址 */
    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "登陆IP地址")
    private String loginIp;

    /** 登陆电话 */
    @TableField(fill = FieldFill.INSERT, exist = false)
    @ApiModelProperty(value = "登陆电话")
    private String phoneNumber;

    /** 业务名(C66) */
    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "业务名(C66)")
    private String productId;

    /** 用户名 */
    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "用户名")
    private String loginName;

    /** 产品标识(BP, AP, GP, PG, SP) */
    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "产品标识(BP, AP, GP, PG, SP)")
    private String tenant;

    /** 渠道(3:GLIFE, 4:GPO, 5:LAZADA, 6:MAYA, 7:PERYAGAME, 91:PC, 92:H5, 93:IOS, 94:Android) */
    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "渠道(3:GLIFE, 4:GPO, 5:LAZADA, 6:MAYA, 7:PERYAGAME, 91:PC, 92:H5, 93:IOS, 94:Android)")
    private String channel;

    /** 创建时间 */
    @ApiModelProperty(value = "创建时间")
    private String createDate;

    /** 创建人 */
    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "创建人")
    private String createBy;

    /** 更新时间 */
    @ApiModelProperty(value = "更新时间")
    private String updateDate;

    /** 更新人 */
    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "更新人")
    private String updateBy;

    /** 域名 */
    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "域名")
    private String domainName;

    /** 拦截类型（0：通过；1：ip；2：设备指纹；3：ip+设备指纹） */
    @ApiModelProperty(value = "拦截类型（0：通过；1：ip；2：设备指纹；3：ip+设备指纹）")
    private Integer interceptType;
}