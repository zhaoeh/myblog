package com.riskcontrol.office.common.req;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.v3.oas.annotations.media.Schema;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

public class ProxyReq extends BaseReq {
	
	private static final long serialVersionUID = -5301011319528730017L;

	@Schema(required = true, title = "代理请求地址", example = "")
	private String uri;
	
	@Schema(required = true, title = "代理参数对象", example = "")
	private Object paramObj;

	/**
	 * 实际请求来源的ip地址
	 */
	@Schema(required = true, title = "实际请求来源的ip地址", example = "")
	private String srcIpAddress;

	public Object getParamObj() {
		return paramObj;
	}

	public void setParamObj(Object paramObj) {
		this.paramObj = paramObj;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public String getSrcIpAddress() {
		return srcIpAddress;
	}

	public void setSrcIpAddress(String srcIpAddress) {
		this.srcIpAddress = srcIpAddress;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}