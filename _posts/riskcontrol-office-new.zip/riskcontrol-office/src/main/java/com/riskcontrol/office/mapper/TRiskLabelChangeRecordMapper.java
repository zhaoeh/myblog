package com.riskcontrol.office.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.riskcontrol.office.domain.entity.TRiskLabelChangeRecord;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 用户标签变更记录(TRiskLabelChangeRecord)表数据库访问层
 *
 * @author makejava
 * @since 2024-06-06 15:27:20
 */
@Mapper
public interface TRiskLabelChangeRecordMapper extends BaseMapper<TRiskLabelChangeRecord> {
    @Insert({
            "<script>",
            "INSERT INTO t_risk_label_change_record (product_id, customer_id, login_name, new_risk_label_id, new_risk_label_name, old_risk_label_id," +
                    " old_risk_label_name, create_by, create_time, operation_status, log_id,remark)",
            "VALUES ",
            "<foreach collection='list' item='item' separator=','>",
            "(#{item.productId}, #{item.customerId}, #{item.loginName}, #{item.newRiskLabelId}, #{item.newRiskLabelName},",
            "#{item.oldRiskLabelId}, #{item.oldRiskLabelName}, #{item.createBy}, #{item.createTime}, #{item.operationStatus},#{item.logId},#{item.remark})",
            "</foreach>",
            "</script>"
    })
    int insertBatch(@Param("list") List<TRiskLabelChangeRecord> list);
}

