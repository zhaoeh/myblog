package com.riskcontrol.office.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gw.datacenter.vo.pagainate.PageModel;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.domain.entity.TRiskActionAllowOperationLog;
import com.riskcontrol.office.domain.req.BlackOperationListPageQueryReq;
import com.riskcontrol.office.domain.rsp.BlcackOpertionLogListPageQueryRsp;
import com.riskcontrol.office.mapper.TRiskActionAllowOperationLogMapper;
import com.riskcontrol.office.service.TRiskActionAllowOperationLogService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@Slf4j
public class TRiskActionAllowOperationLogServiceImpl extends BaseServiceImpl<TRiskActionAllowOperationLogMapper, TRiskActionAllowOperationLog> implements TRiskActionAllowOperationLogService {
    @Override
    public PageModel<BlcackOpertionLogListPageQueryRsp> getPageBlackOperationList(BlackOperationListPageQueryReq req) {
        //获取日期，组装查询当天时间条件
        String beginDateTime=req.getDate()+"00:00:00";
        String endDateTime=req.getDate()+"23:59:59";

        LambdaQueryWrapper<TRiskActionAllowOperationLog> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(StringUtils.isNotBlank(req.getOperator()), TRiskActionAllowOperationLog::getOperator, req.getOperator());
        wrapper.ge(TRiskActionAllowOperationLog::getCreateDate, beginDateTime);
        wrapper.le(TRiskActionAllowOperationLog::getAllowType, endDateTime);

        Page<TRiskActionAllowOperationLog> tRiskActionAllowOperationLogPage = pageByWrapper(req, wrapper);
        if (CollUtil.isEmpty(tRiskActionAllowOperationLogPage.getRecords())) {
            return new PageModel<>();
        }
        List<BlcackOpertionLogListPageQueryRsp> list = tRiskActionAllowOperationLogPage.getRecords().stream().map(entity -> {
            BlcackOpertionLogListPageQueryRsp rsp = new BlcackOpertionLogListPageQueryRsp();
            BeanUtil.copyProperties(entity, rsp);
            return rsp;
        }).toList();
        PageModel<BlcackOpertionLogListPageQueryRsp> pageResult = new PageModel<>();
        pageResult.setData(list);
        pageResult.setPageNo((int) tRiskActionAllowOperationLogPage.getCurrent());
        pageResult.setPageSize((int) tRiskActionAllowOperationLogPage.getSize());
        pageResult.setTotalRow((int) tRiskActionAllowOperationLogPage.getTotal());
        pageResult.setTotalPage((int) tRiskActionAllowOperationLogPage.getPages());
        return pageResult;
    }
}
