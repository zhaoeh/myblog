package com.riskcontrol.office.controller;

import com.digiplus.oms.aspect.annotation.PreAuthorize;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.enums.RuleEnum;
import com.riskcontrol.common.enums.YesNoEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.office.annotation.EnableOperationLog;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.entity.TLabelRuleRelationship;
import com.riskcontrol.office.domain.entity.TRiskConstants;
import com.riskcontrol.office.domain.enums.OpTypeEnum;
import com.riskcontrol.office.domain.req.LabelRuleEditReq;
import com.riskcontrol.office.domain.req.LabelRuleQueryReq;
import com.riskcontrol.office.domain.validation.LabelRuleRelationshipReqValidator;
import com.riskcontrol.office.domain.vo.TLabelRuleRelationshipVo;
import com.riskcontrol.office.service.TLabelRuleRelationshipService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;
import java.util.Map;

/**
 * @author: sanji
 * @date: 2024/04/15 16:01
 */
@RestController
@RequestMapping("/labelRule")
@Tag(name = "风控标签-规则关联关系")
//@SecurityRequirement(name = HttpHeaders.AUTHORIZATION)
@Slf4j
public class LabelRuleRelationshipController {

    @Resource
    TLabelRuleRelationshipService labelRuleRelationshipService;
    @PreAuthorize("riskConfig_labelRules_query")
    @GetMapping("/getRuleEnumMap")
    @Operation(tags ="风控标签-规则关联关系" ,summary = "查询所有规则枚举")
    @ResponseBody
    public R<Map<String, String>> getRuleEnumMap() {
        return R.ok(RuleEnum.getAllRuleMap());
    }
    @PreAuthorize("riskConfig_labelRules_query")
    @PostMapping("/list")
    @Operation(tags ="风控标签-规则关联关系" ,summary = "查询标签规则绑定列表")
    @ResponseBody
    public R<PageModel<TLabelRuleRelationshipVo>> queryLabelRuleList(@RequestBody LabelRuleQueryReq req) {
        return R.ok(labelRuleRelationshipService.queryLabelRuleListVo(req));
    }
    @PreAuthorize("riskConfig_labelRules_create")
    @PostMapping("/create")
    @Operation(tags ="风控标签-规则关联关系" ,summary = "创建标签")
    @ResponseBody
//    @PreAuthorize("@pms.hasPermission('label_rule_create')")
    @EnableOperationLog(menuName="风控配置",subMenuName="标签规则引擎",opLog = "创建",opLogType= OpTypeEnum.CREATE,mapperClass = TLabelRuleRelationship.class)
    public R<Boolean> create(@RequestBody @Validated LabelRuleEditReq req) throws BusinessException {
        return R.ok(labelRuleRelationshipService.create(req));
    }

    @PreAuthorize("riskConfig_labelRules_modify")
    @PostMapping("/update")
    @Operation(tags ="风控标签-规则关联关系" ,summary = "根据id修改标签配置")
    @ResponseBody
//    @PreAuthorize("@pms.hasPermission('label_rule_update')")
    @EnableOperationLog(menuName="风控配置",subMenuName="标签规则引擎",opLog = "更新",opLogType= OpTypeEnum.UPDATE,mapperClass = TRiskConstants.class)
    public R<Boolean> update(@RequestBody @Validated(LabelRuleRelationshipReqValidator.class) LabelRuleEditReq req) {
        return R.ok(labelRuleRelationshipService.updateById(req));
    }
    @PreAuthorize("riskConfig_labelRules_delete")
    @PostMapping("/delete/{id}")
    @Operation(tags ="风控标签-规则关联关系" ,summary = "删除标签")
    @ResponseBody
//    @PreAuthorize("@pms.hasPermission('label_rule_delete')")
    @EnableOperationLog(menuName="风控配置",subMenuName="标签规则引擎",opLog = "删除",opLogType= OpTypeEnum.DELETE,mapperClass = TRiskConstants.class)
    public R<Boolean> delete(@PathVariable @NotNull @Validated BigInteger id) {
        return R.ok(labelRuleRelationshipService.deleteById(id));
    }
    @PreAuthorize("riskConfig_labelRules_status")
    @PostMapping("/enable/{id}")
    @Operation(tags ="风控标签-规则关联关系" ,summary = "启用标签")
    @ResponseBody
//    @PreAuthorize("@pms.hasPermission('label_rule_delete')")
    @EnableOperationLog(menuName="风控配置",subMenuName="标签规则引擎",opLog = "启用",opLogType= OpTypeEnum.ENABLE,mapperClass = TRiskConstants.class)
    public R<Boolean> enable(@PathVariable @NotNull @Validated BigInteger id) {
        LabelRuleEditReq req = new LabelRuleEditReq();
        req.setId(id);
        req.setStatus(YesNoEnum.YES.getIntCode());
        return R.ok(labelRuleRelationshipService.updateStatusById(req));
    }
    @PreAuthorize("riskConfig_labelRules_status")
    @PostMapping("/disable/{id}")
    @Operation(tags ="风控标签-规则关联关系" ,summary = "禁用标签")
    @ResponseBody
//    @PreAuthorize("@pms.hasPermission('label_rule_delete')")
    @EnableOperationLog(menuName="风控配置",subMenuName="标签规则引擎",opLog = "禁用",opLogType= OpTypeEnum.DISABLE,mapperClass = TRiskConstants.class)
    public R<Boolean> disable(@PathVariable @NotNull @Validated BigInteger id) {
        LabelRuleEditReq req = new LabelRuleEditReq();
        req.setId(id);
        req.setStatus(YesNoEnum.NO.getIntCode());
        return R.ok(labelRuleRelationshipService.updateStatusById(req));
    }

}
