package com.riskcontrol.office.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.datasource.DBSourceCheck;
import com.riskcontrol.office.datasource.DataSourceType;
import com.riskcontrol.office.domain.entity.TRiskActionLogin;
import com.riskcontrol.office.domain.req.RiskActionLoginQueryRequest;
import com.riskcontrol.office.domain.rsp.RiskActionLogInResponse;
import com.riskcontrol.office.mapper.RiskActionLoginMapper;
import com.riskcontrol.office.service.RiskActionLoginService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

import static com.riskcontrol.common.enums.ResultEnum.DEVICE_CROSS_SEVEN_DAYS;
import static com.riskcontrol.common.enums.ResultEnum.DEVICE_OTHER_EMPTY1;

/**
 * zhang heng
 */
@Slf4j
@Service
public class RiskActionLoginServiceImpl extends BaseServiceImpl<RiskActionLoginMapper, TRiskActionLogin> implements RiskActionLoginService {

    /**
     * 注册表分页查询
     * @param request
     * @return
     */
    @Override
    @DBSourceCheck(DataSourceType.SLAVE)
    public PageModel<RiskActionLogInResponse> pageLoginList(RiskActionLoginQueryRequest request){
        checkRequest(request);
        LambdaQueryWrapper<TRiskActionLogin> wrapper = buildWrapper(request);
        wrapper.orderByDesc(TRiskActionLogin::getCreateDate);
        Page<TRiskActionLogin> riskActionLoginPage = pageByWrapper(request, wrapper);
        if (CollUtil.isEmpty(riskActionLoginPage.getRecords())) {
            return new PageModel<>();
        }
        List<RiskActionLogInResponse> list = riskActionLoginPage.getRecords().stream().map(entity -> {
            RiskActionLogInResponse rsp = new RiskActionLogInResponse();
            BeanUtil.copyProperties(entity, rsp);
            return rsp;
        }).toList();
        PageModel<RiskActionLogInResponse> pageResult = new PageModel<>();
        pageResult.setData(list);
        pageResult.setPageNo((int) riskActionLoginPage.getCurrent());
        pageResult.setPageSize((int) riskActionLoginPage.getSize());
        pageResult.setTotalRow((int) riskActionLoginPage.getTotal());
        pageResult.setTotalPage((int) riskActionLoginPage.getPages());
        return pageResult;
    }

    /**
     * 校验请求*
     *
     * @param request
     */
    private void checkRequest(RiskActionLoginQueryRequest request) {
        if (Objects.nonNull(request)) {
            String begin = request.getDateBegin();
            String end = request.getDateEnd();
            // 开始日期和结束日期必须传递
            if (StringUtils.isBlank(begin) || StringUtils.isBlank(end)) {
                throw new BusinessException("dateBegin and dateEnd cannot be blank", 90222);
            }
            // 如果是同一天，忽略
            boolean isSameDay = DateUtils.isSameDay(begin, end);
            if (isSameDay) {
                return;
            }
            // 如果跨天，则最大查询范围不能超过7天，包含起始日计算在内
            begin = begin.substring(0, 10);
            end = end.substring(0, 10);
            boolean isSpan7Days = DateUtils.isSpanExceedingSettingDaysContainStart(begin, end, 7);
            if (isSpan7Days) {
                throw new BusinessException(DEVICE_CROSS_SEVEN_DAYS);
            }
            String deviceFingerprint = request.getDeviceFingerprint();
            String registerIp = request.getRegisterIp();
            List<Integer> interceptType = request.getInterceptType();
            String domainName = request.getDomainName();
            List<Integer> channel = request.getChannel();
            String loginName = request.getLoginName();
            if (StringUtils.isBlank(deviceFingerprint) &&
                    StringUtils.isBlank(registerIp) &&
                    CollUtil.isEmpty(interceptType) &&
                    StringUtils.isBlank(domainName) &&
                    CollUtil.isEmpty(channel) &&
                    StringUtils.isBlank(loginName)) {
                throw new BusinessException(DEVICE_OTHER_EMPTY1);
            }
        }
    }

}
