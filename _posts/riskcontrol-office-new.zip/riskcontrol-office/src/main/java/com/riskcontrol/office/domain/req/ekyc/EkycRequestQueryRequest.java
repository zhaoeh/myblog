package com.riskcontrol.office.domain.req.ekyc;

import com.riskcontrol.common.annotation.EnumValid;
import com.riskcontrol.common.annotation.ListEnumValid;
import com.riskcontrol.common.annotation.NotDuplicate;
import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.constants.SQLConstants;
import com.riskcontrol.common.entity.request.BasePageRequest;
import com.riskcontrol.common.enums.EkycChannelEnum;
import com.riskcontrol.common.enums.EkycManualReasonEnum;
import com.riskcontrol.common.enums.EkycStatusEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * @author Heng.zhang
 */
@Data
@ApiModel(value = "Ekyc申请表分页查询", description = "Ekyc申请表分页查询")
public class EkycRequestQueryRequest extends BasePageRequest {
    @ApiModelProperty("createDate Begin")
    @Query(field = "createDate", mt = SQLConstants.Query.GE)
    private String dateBegin;

    @ApiModelProperty("createDate End")
    @Query(field = "createDate", mt = SQLConstants.Query.LE)
    private String dateEnd;


    @ApiModelProperty(value = "status",required = true)
    @Query(mt = SQLConstants.Query.IN)
    @NotEmpty(message = "status cannot be empty")
    @ListEnumValid(enumClass = EkycStatusEnum.class, deduplicateEnumField = true, enumField = "eKycReqStatus", message = "status must belong to {target}")
    private List<Integer> status;

    @ApiModelProperty("账号")
    @Query
    private String loginName;

    @ApiModelProperty("tenants")
    @NotDuplicate(message = "tenant cannot be repeated")
    @Query(mt = SQLConstants.Query.IN, field = "tenant")
    private List<String> tenants;

    @ApiModelProperty("账单号")
    @Query
    private String billNo;

    @ApiModelProperty("名字")
    @Query
    private String firstName;

    @ApiModelProperty("中间名")
    @Query
    private String middleName;

    @ApiModelProperty("姓")
    @Query
    private String lastName;

    @ApiModelProperty("channels")
    @NotDuplicate(message = "channelId cannot be repeated")
    @ListEnumValid(enumClass = EkycChannelEnum.class, enumField = "channelId",message = "channelId must belong to {target}")
    @Query(mt = SQLConstants.Query.IN, field = "channel")
    private List<String> channels;

    @ApiModelProperty("人工处理原因")
    @EnumValid(enumClass = EkycManualReasonEnum.class, enumField = "id",message = "manualReason must belong to {target}")
    @Query
    private String manualReason;

}
