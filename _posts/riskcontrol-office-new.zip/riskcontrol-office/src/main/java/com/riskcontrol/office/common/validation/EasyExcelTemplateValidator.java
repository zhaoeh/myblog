package com.riskcontrol.office.common.validation;


import com.alibaba.excel.EasyExcel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@Slf4j
public class EasyExcelTemplateValidator {

    // 定义不同类型的模板列头
    private static final List<String> EXPECTED_HEADERS_FOR_TYPE_0 = Arrays.asList("Account");
    private static final List<String> EXPECTED_HEADERS_FOR_TYPE_1 = Arrays.asList("First name", "Middle name", "Last name", "Birthday");

    private static final List<String> EXPECTED_HEADERS_FOR_TYPE_2 = Arrays.asList("Account","Remark");

    // 校验模板列头的方法
    public static boolean validateTemplate(MultipartFile file, Integer type) throws IOException {
        boolean result=false;
        // 读取 Excel 文件，获取内容
        List<Map<Integer, String>> rows = EasyExcel.read(file.getInputStream())
                .headRowNumber(0) // 第一行作为表头
                .sheet(0)         // 读取第一个 sheet
                .doReadSync();    // 同步读取

        // 提取列头并转换为 List<String>
        List<String> actualHeaders = rows.get(0).entrySet().stream().filter(entry -> entry.getValue()!=null)
                .map(Map.Entry::getValue).collect(Collectors.toList());

        if (type == 0) {
            // 检查实际列头是否与预期列头匹配
            result= actualHeaders.containsAll(EXPECTED_HEADERS_FOR_TYPE_0) &&
                    EXPECTED_HEADERS_FOR_TYPE_0.containsAll(actualHeaders);
            log.info("文件列头："+actualHeaders+",常量："+EXPECTED_HEADERS_FOR_TYPE_0+",返回状态："+result);
        } else if (type == 1) {
            // 检查实际列头是否与预期列头匹配
            result= actualHeaders.containsAll(EXPECTED_HEADERS_FOR_TYPE_1) &&
                    EXPECTED_HEADERS_FOR_TYPE_1.containsAll(actualHeaders);
            log.info("文件列头："+actualHeaders+",常量："+EXPECTED_HEADERS_FOR_TYPE_1+",返回状态："+result);
        } else if (type == 2) {
            // 检查实际列头是否与预期列头匹配
            result= actualHeaders.containsAll(EXPECTED_HEADERS_FOR_TYPE_2) &&
                    EXPECTED_HEADERS_FOR_TYPE_2.containsAll(actualHeaders);
            log.info("文件列头："+actualHeaders+",常量："+EXPECTED_HEADERS_FOR_TYPE_2+",返回状态："+result);
        }
        return  result;
    }
}