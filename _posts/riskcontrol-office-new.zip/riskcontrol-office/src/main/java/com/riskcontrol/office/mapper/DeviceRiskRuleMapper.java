package com.riskcontrol.office.mapper;

import com.riskcontrol.office.domain.entity.RiskActionRuleEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author Yu.Guo
 */
@Mapper
public interface DeviceRiskRuleMapper extends BaseMapperX<RiskActionRuleEntity> {
}
