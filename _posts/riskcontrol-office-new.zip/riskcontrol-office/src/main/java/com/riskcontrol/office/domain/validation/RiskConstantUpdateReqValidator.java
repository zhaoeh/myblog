package com.riskcontrol.office.domain.validation;

public interface RiskConstantUpdateReqValidator {
}
