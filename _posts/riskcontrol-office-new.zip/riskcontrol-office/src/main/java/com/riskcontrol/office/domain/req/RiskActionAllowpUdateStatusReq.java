package com.riskcontrol.office.domain.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigInteger;

@Data
@Schema(description = "白名更新状态对象")
public class RiskActionAllowpUdateStatusReq {

    @Schema(description = "白名单主键")
    @JsonProperty("id")
    private BigInteger id;

    @Schema(description = "可用状态（0：可用；1：禁用）")
    @JsonProperty("isEnable")
    private Integer isEnable;
}