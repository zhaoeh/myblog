package com.riskcontrol.office.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.datasource.DBSourceCheck;
import com.riskcontrol.office.datasource.DataSourceType;
import com.riskcontrol.office.domain.entity.TRiskActionRegistration;
import com.riskcontrol.office.domain.req.RiskActionRegistrationQueryRequest;
import com.riskcontrol.office.domain.rsp.RiskActionRegistrationResponse;
import com.riskcontrol.office.mapper.RiskActionRegistrationMapper;
import com.riskcontrol.office.service.RiskActionRegistrationService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

import static com.riskcontrol.common.enums.ResultEnum.*;

/**
 * @description: 白名单service impl
 * @author: ErHu.Zhao
 * @create: 2024-11-12
 **/
@Slf4j
@Service
public class RiskActionRegistrationServiceImpl  extends BaseServiceImpl<RiskActionRegistrationMapper, TRiskActionRegistration> implements RiskActionRegistrationService {

    /**
     * 注册表分页查询
     * @param request
     * @return
     */
    @Override
    @DBSourceCheck(DataSourceType.SLAVE)
    public PageModel<RiskActionRegistrationResponse> pageRegistrationList(RiskActionRegistrationQueryRequest request){
        checkRequest(request);
        LambdaQueryWrapper<TRiskActionRegistration> wrapper = buildWrapper(request);
        wrapper.orderByDesc(TRiskActionRegistration::getCreateDate);
        Page<TRiskActionRegistration> riskActionRegistrationPage = pageByWrapper(request, wrapper);
        if (CollUtil.isEmpty(riskActionRegistrationPage.getRecords())) {
            return new PageModel<>();
        }
        List<RiskActionRegistrationResponse> list = riskActionRegistrationPage.getRecords().stream().map(entity -> {
            RiskActionRegistrationResponse rsp = new RiskActionRegistrationResponse();
            BeanUtil.copyProperties(entity, rsp);
            return rsp;
        }).toList();
        PageModel<RiskActionRegistrationResponse> pageResult = new PageModel<>();
        pageResult.setData(list);
        pageResult.setPageNo((int) riskActionRegistrationPage.getCurrent());
        pageResult.setPageSize((int) riskActionRegistrationPage.getSize());
        pageResult.setTotalRow((int) riskActionRegistrationPage.getTotal());
        pageResult.setTotalPage((int) riskActionRegistrationPage.getPages());
        return pageResult;
    }

    private void checkRequest(RiskActionRegistrationQueryRequest request) {
        if (Objects.nonNull(request)) {
            String loginName = request.getLoginName();
            if (StringUtils.isNotBlank(loginName)) {
                // loginName存在，则忽略日期查询
                request.setDateBegin(null);
                request.setDateEnd(null);
            } else {
                // loginName为空
                String begin = request.getDateBegin();
                String end = request.getDateEnd();
                // 如果loginName为空，开始日期和结束日期必须传递
                if (StringUtils.isBlank(begin) || StringUtils.isBlank(end)) {
                    throw new BusinessException(DEVICE_BEGIN_END_LOGIN);
                }
                // 如果是同一天，忽略
                boolean isSameDay = DateUtils.isSameDay(begin, end);
                if (isSameDay) {
                    return;
                }
                begin = begin.substring(0, 10);
                end = end.substring(0, 10);
                // 如果跨天，则最大查询范围不能超过7天，包含起始日计算在内
                boolean isSpan7Days = DateUtils.isSpanExceedingSettingDaysContainStart(begin, end, 7);
                if (isSpan7Days) {
                    throw new BusinessException(DEVICE_CROSS_SEVEN_DAYS);
                }
                String deviceFingerprint = request.getDeviceFingerprint();
                String registerIp = request.getRegisterIp();
                String domainName = request.getDomainName();
                List<Integer> channel = request.getChannel();
                if (StringUtils.isBlank(deviceFingerprint) &&
                        StringUtils.isBlank(registerIp) &&
                        StringUtils.isBlank(domainName) &&
                        CollUtil.isEmpty(channel)) {
                    throw new BusinessException(DEVICE_OTHER_EMPTY);
                }
            }
        }
    }

}
