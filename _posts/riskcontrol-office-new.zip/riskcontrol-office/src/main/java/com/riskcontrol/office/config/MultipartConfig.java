package com.riskcontrol.office.config;

import cn.hutool.core.io.FileUtil;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.MultipartConfigElement;

/**
 * 处理undertow没有默认临时文件路径问题
 * @author dante
 * @date 2024/03/19
 */
@Configuration
public class MultipartConfig {

    private static final String tmpLocation = "/home/tomcat";

    @Bean
    public MultipartConfigElement multipartConfigElement() {
        MultipartConfigFactory factory = new MultipartConfigFactory();
        if (!FileUtil.exist(tmpLocation)) {
            FileUtil.mkdir(tmpLocation);
        }
        factory.setLocation(tmpLocation);
        return factory.createMultipartConfig();
    }
}
