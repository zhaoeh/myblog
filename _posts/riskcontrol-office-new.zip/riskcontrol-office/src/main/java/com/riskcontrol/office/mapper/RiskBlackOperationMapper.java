package com.riskcontrol.office.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.riskcontrol.office.domain.entity.TRiskBlackOperation;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author Heng.zhang
 */
@Mapper
public interface RiskBlackOperationMapper extends BaseMapper<TRiskBlackOperation> {

}
