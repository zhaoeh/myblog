package com.riskcontrol.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.domain.entity.TRiskActionLogin;
import com.riskcontrol.office.domain.entity.TRiskActionRegistration;
import com.riskcontrol.office.domain.req.RiskActionLoginQueryRequest;
import com.riskcontrol.office.domain.req.RiskActionRegistrationQueryRequest;
import com.riskcontrol.office.domain.rsp.RiskActionLogInResponse;
import com.riskcontrol.office.domain.rsp.RiskActionRegistrationResponse;


/**
 * @author Heng.zhang
 */
public interface RiskActionLoginService extends IService<TRiskActionLogin> {

    /**
     * 登录表分页查询
     * @param request
     * @return
     */
    PageModel<RiskActionLogInResponse> pageLoginList(RiskActionLoginQueryRequest request);


}
