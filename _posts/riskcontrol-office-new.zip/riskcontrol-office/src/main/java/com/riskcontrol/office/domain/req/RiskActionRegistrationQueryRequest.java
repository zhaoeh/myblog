package com.riskcontrol.office.domain.req;

import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.constants.SQLConstants;
import com.riskcontrol.common.entity.request.BasePageRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Pattern;
import java.util.List;

/**
 * @author Heng.zhang
 */
@Data
@ApiModel(value = "用户登录注册日志", description = "用户注册明细分页查询")
public class RiskActionRegistrationQueryRequest extends BasePageRequest {

    @ApiModelProperty("createDate Begin")
    @Query(field = "createDate", mt = SQLConstants.Query.GE)
    @Pattern(regexp = "^\s*|^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}$", message = "dateBegin format error")
    private String dateBegin;

    @ApiModelProperty("createDate End")
    @Query(field = "createDate", mt = SQLConstants.Query.LE)
    @Pattern(regexp = "^\s*|^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}$", message = "dateEnd format error")
    private String dateEnd;

    @ApiModelProperty("设备指纹")
    @Query
    private String deviceFingerprint;

    @ApiModelProperty("注册IP地址")
    @Query
    private String registerIp;

    @ApiModelProperty("用户名")
    @Query
    private String loginName;

    @ApiModelProperty("拦截类型（0：通过；1：ip；2：设备指纹；3：ip+设备指纹）")
    private List<Integer> interceptType;

    @ApiModelProperty("域名")
    @Query
    private String domainName;

    @ApiModelProperty("渠道(3:GLIFE, 4:GPO, 5:LAZADA,6:MAYA, 7:PERYAGAME, 91:PC, 92:H5, 93:IOS, 94:Android)")
    @Query(mt = SQLConstants.Query.IN)
    private List<Integer> channel;

}
