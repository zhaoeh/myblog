package com.riskcontrol.office.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.fastjson.JSON;
import com.riskcontrol.common.utils.CommonUtil;
import com.riskcontrol.office.domain.entity.TRiskBlack;
import com.riskcontrol.office.domain.entity.TRiskBlackOperationAccountDetail;
import com.riskcontrol.office.domain.entity.TRiskBlackOperationDetail;
import com.riskcontrol.office.domain.po.RiskBlackImportPO;
import com.riskcontrol.office.mapper.RiskBlackMapper;
import com.riskcontrol.office.mapper.RiskBlackOperationAccountDetailMapper;
import com.riskcontrol.office.mapper.RiskBlackOperationDetailMapper;
import com.riskcontrol.office.mapper.RiskBlackOperationMapper;
import com.riskcontrol.office.service.RiskBlackDoImportService;
import com.riskcontrol.office.util.RedisUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import static com.riskcontrol.common.constants.Constant.RISK_IS_BLACK_KEY;

/**
 * @author Heng.zhang
 */
@Service
@Slf4j
public class RiskBlackDoImportServiceImpl implements RiskBlackDoImportService {
    @Resource
    private RiskBlackOperationDetailMapper detailMapper;

    @Resource
    private RiskBlackOperationAccountDetailMapper riskBlackOperationAccountDetailMapper;

    @Resource
    private RiskBlackOperationMapper riskBlackOperationMapper;

    @Resource
    private RiskBlackMapper riskBlackMapper;




    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean doImports(RiskBlackImportPO.BlackImportContext context) {
        if (Objects.isNull(context)) {
            return false;
        }
        // 导入模式下明细数据
        if (!CollectionUtils.isEmpty(context.getImLogDetails())) {
            log.info("导入模式下，导入日志明细表开始，导入总数：{}",  CollectionUtil.size(context.getImLogDetails()));
            // 插入用户日志明细
            detailMapper.insertBatch(CommonUtil.null2Emptys(context.getImLogDetails()));
            log.info("导入模式下，导入日志明细表结束");
        }
        // 关联模式下明细入库
        Map<TRiskBlackOperationDetail, List<TRiskBlackOperationAccountDetail>> reDetailListMap = context.getReLogDetails();
        if (!CollectionUtils.isEmpty(reDetailListMap)) {
            reDetailListMap.forEach((k, v) -> {
                // 循环插入日志明细表
                if (detailMapper.insert(CommonUtil.null2Empty(k)) > 0) {
                    log.info("关联模式下，导入日志明细开始,日志明细：{}",JSON.toJSONString(k));
                    // 插入一条日志明细成功，则批量插入关联表，并设置明细表id
                    if (!CollectionUtils.isEmpty(v)) {
                        log.info("关联模式下，导入日志明细{}后，开始导入账号关联表，导入总数：{}",k.getLoginName(),CollectionUtil.size(v));
                        riskBlackOperationAccountDetailMapper.insertBatch(CommonUtil.null2Emptys(v).stream().map(e -> {
                            e.setLogDetailId(k.getId());
                            return e;
                        }).collect(Collectors.toList()));
                        log.info("关联模式下，导入日志明细{}后，导入账号关联表结束",k.getLoginName());
                    }
                }
            });
            log.info("关联模式下，导入日志明细和账号关联表结束");
        }
        // 插入黑名单主表
        if (!CollectionUtils.isEmpty(context.getBlacks())) {
            log.info("导入黑名单列表开始，导入总数：{}", CollectionUtil.size(context.getBlacks()));
            riskBlackMapper.insertOrUpdateBatch(context.getBlacks().stream().distinct().collect(Collectors.toList()));
            log.info("导入黑名单列表结束");
            clearCache(context.getBlacks().stream().map(TRiskBlack::getLoginName).toList());
        }
        return true;
    }

    /**
     * 操作完成删除缓存*
     *
     * @param loginNameList
     */
    private void clearCache(List<String> loginNameList) {
        for (var loginName : loginNameList) {
            RedisUtils.remove(String.format(RISK_IS_BLACK_KEY, loginName));
        }
    }
}
