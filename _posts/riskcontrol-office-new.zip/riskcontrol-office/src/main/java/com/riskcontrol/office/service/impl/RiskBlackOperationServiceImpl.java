package com.riskcontrol.office.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.riskcontrol.office.domain.req.black.RiskBlackOperationPageRequest;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.domain.rsp.black.RiskBlackOperationRsp;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.domain.entity.TRiskBlackOperation;
import com.riskcontrol.office.mapper.RiskBlackOperationMapper;
import com.riskcontrol.office.service.RiskBlackOperationService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class RiskBlackOperationServiceImpl extends BaseServiceImpl<RiskBlackOperationMapper, TRiskBlackOperation> implements RiskBlackOperationService {

    @Override
    public PageModel<RiskBlackOperationRsp> getOperationPageList(RiskBlackOperationPageRequest req) {
        LambdaQueryWrapper<TRiskBlackOperation> wrapper = new LambdaQueryWrapper<>();
        wrapper.select(TRiskBlackOperation::getId,
                TRiskBlackOperation::getOperator,
                TRiskBlackOperation::getStatus,
                TRiskBlackOperation::getOpMode,
                TRiskBlackOperation::getTotalNo,
                TRiskBlackOperation::getSuccessNo,
                TRiskBlackOperation::getFailureNo,
                TRiskBlackOperation::getCreateDate,
                TRiskBlackOperation::getFinishDate,
                TRiskBlackOperation::getRemark
                );
        wrapper.ge(StringUtils.isNotBlank(req.getCreatedDateBegin()),TRiskBlackOperation::getCreateDate, req.getCreatedDateBegin());
        wrapper.le(StringUtils.isNotBlank(req.getCreatedDateEnd()),TRiskBlackOperation::getCreateDate, req.getCreatedDateEnd());
        wrapper.orderByDesc(TRiskBlackOperation::getCreateDate);
        Page<TRiskBlackOperation> page = pageByWrapper(req, wrapper);
        if (CollUtil.isEmpty(page.getRecords())) {
            return new PageModel<>();
        }
        List<RiskBlackOperationRsp> pageList = page.getRecords().stream().map(x -> {
            RiskBlackOperationRsp riskBlackOperationRsp = new RiskBlackOperationRsp();
            BeanUtil.copyProperties(x,riskBlackOperationRsp);
//            riskBlackOperationRsp.setOpMode(RiskBlackOpModeEnum.getDescriptionByCode(x.getOpMode()));
            return riskBlackOperationRsp;
        }).toList();
        PageModel<RiskBlackOperationRsp> pageResult = new PageModel<>();
        pageResult.setData(pageList);
        pageResult.setPageNo((int) page.getCurrent());
        pageResult.setPageSize((int) page.getSize());
        pageResult.setTotalRow((int) page.getTotal());
        pageResult.setTotalPage((int) page.getPages());
        return pageResult;
    }

}
