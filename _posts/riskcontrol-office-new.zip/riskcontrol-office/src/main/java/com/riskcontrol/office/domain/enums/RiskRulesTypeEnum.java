package com.riskcontrol.office.domain.enums;

public enum RiskRulesTypeEnum {
    ZERO((byte) 0),
    ONE((byte) 1),
    TWO((byte) 2);
    private final byte value;

    public byte getValue() {
        return value;
    }

    RiskRulesTypeEnum(byte value) {
        this.value = value;
    }
}
