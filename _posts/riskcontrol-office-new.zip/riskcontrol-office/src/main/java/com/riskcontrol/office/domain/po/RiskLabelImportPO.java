package com.riskcontrol.office.domain.po;

import com.alibaba.excel.annotation.ExcelProperty;
import com.riskcontrol.office.domain.entity.TRiskLabelChangeRecord;
import com.riskcontrol.office.domain.entity.TRiskLabelRelationship;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;


/**
 * @author Heng.zhang
 */
@Data
@Builder
@AllArgsConstructor
@Accessors
public class RiskLabelImportPO {

    /**
     * 导入模式实体
     */
    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors
    public static class ImportMode {
        @ExcelProperty("Account")
        private String loginName;
        private String remark;
    }



    /**
     * 用户标签导入上下文
     */
    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors
    public static class LabelImportContext {

        // 导入模式最终要录入的用户标签,true表示为增量关系，false表示为存量关系
        private Map<Boolean, List<TRiskLabelRelationship>> listMap;

        // 导入模式下用户标签的日志
        private List<TRiskLabelChangeRecord> labelLogDetails;

        private BigInteger totalCount;
    }

}
