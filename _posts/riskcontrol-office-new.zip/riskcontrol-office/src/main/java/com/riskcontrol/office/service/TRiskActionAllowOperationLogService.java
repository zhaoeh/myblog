package com.riskcontrol.office.service;

import com.gw.datacenter.vo.pagainate.PageModel;
import com.riskcontrol.office.domain.req.BlackOperationListPageQueryReq;
import com.riskcontrol.office.domain.rsp.BlcackOpertionLogListPageQueryRsp;


public interface TRiskActionAllowOperationLogService  {
    PageModel<BlcackOpertionLogListPageQueryRsp> getPageBlackOperationList(BlackOperationListPageQueryReq req);
}
