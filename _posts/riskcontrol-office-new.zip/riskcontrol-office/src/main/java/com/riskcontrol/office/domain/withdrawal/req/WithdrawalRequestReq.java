package com.riskcontrol.office.domain.withdrawal.req;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
@Schema(title = "取款提案审核参数<br/>Request parameters for auditing withdrawal")
public class WithdrawalRequestReq extends BaseReq {
    @NotBlank(message = "requestId can not be blank")
    @Schema(required = true, description = "取款提案单号<br/>Request ID of withdrawal")
    private String requestId;

    @Schema(required = true, description = "提案当前状态<br/>Current flag of withdrawal request")
    private String flag;

    @NotBlank(message = "remark can not be blank")
    @Schema(required = true, description = "审核备注<br/>The remark of audit")
    private String remark;

    @Schema(required = true, description = "打开审核弹框时间<br/>")
    private String reviewTime;

    @Schema(description = "拒绝原因")
    private String rejectionReason;

    @Schema(required = false, description = "血缘标<br/>")
    private String tenant;

}
