package com.riskcontrol.office.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.domain.entity.TRiskLabelOperationLog;
import com.riskcontrol.office.domain.req.RiskLabelOperationPageRequest;
import com.riskcontrol.office.mapper.TRiskLabelOperationLogMapper;
import com.riskcontrol.office.service.TRiskLabelOperationLogService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;


@Service
public class TRiskLabelOperationLogServiceImpl extends BaseServiceImpl<TRiskLabelOperationLogMapper, TRiskLabelOperationLog> implements TRiskLabelOperationLogService {


    @Override
    public PageModel<TRiskLabelOperationLog> getOperationList(RiskLabelOperationPageRequest req) {
        LambdaQueryWrapper<TRiskLabelOperationLog> wrapper = buildWrapper(req);
        wrapper.orderByDesc(TRiskLabelOperationLog::getCreateDate);
        Page<TRiskLabelOperationLog> page = pageByWrapper(req, wrapper);
        PageModel<TRiskLabelOperationLog> pageResult = new PageModel<>();
        List<TRiskLabelOperationLog> records = page.getRecords().stream().map(record -> {
            String finishDateDb = StringUtils.trim(record.getFinishDate());
            String finishDateExpect = "1900-01-01 00:00:00";
            if (finishDateExpect.equals(finishDateDb)) {
                record.setFinishDate(null);
            }
            return record;
        }).collect(Collectors.toList());
        pageResult.setData(records);
        pageResult.setPageNo((int) page.getCurrent());
        pageResult.setPageSize((int) page.getSize());
        pageResult.setTotalRow((int) page.getTotal());
        pageResult.setTotalPage((int) page.getPages());
        return pageResult;
    }
}
