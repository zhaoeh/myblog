package com.riskcontrol.office.domain.req;

import com.riskcontrol.common.annotation.EnumValid;
import com.riskcontrol.common.annotation.StringValuesValid;
import com.riskcontrol.common.entity.request.BasePageRequest;
import com.riskcontrol.office.domain.enums.RiskTenanEnum;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@Schema(description="设备指纹风控规则查询对象")
public class DeviceRiskRuleQueryReq extends BasePageRequest {

    @ApiModelProperty(required = true, value = "血缘标记（BP、AP、 GP、PG、OTHER）")
    private String tenant;

    @ApiModelProperty(required = true, value = "规则限制行为（0：ip ; 1：设备指纹；2：ip+设备指纹）")
    private Integer rulesAction;

    @ApiModelProperty(required = true, value = "规则校验类型（0：登录：1：注册）")
    private Integer rulesType;

}
