package com.riskcontrol.office.domain.withdrawal.req;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Schema
@Data
public class WithdrawalApproveReq extends BaseReq {

    @NotBlank(message = "requestId can not be blank")
    @Schema(required = true, description = "提案ID", example = "A03031902141042LA01")
    private String requestId;

    @Schema(required = true, description = "审批人", example = "system")
    private String approveBy;
    @NotBlank(message = "flag can not be blank")
    @Schema(description = "审批前状态;提案状态,拒绝(-3),Office取消(-2),客户取消(-1),批准(2),待审核(9),等待(0)", example = "0")
    private String flag;

    @Schema(description = "备注", example = "1")
    private String remarks;

    @Schema(required = true, description = "审批门店", example = "")
    private String branchCode;

    @Schema(required = true, description = "门店用户密码[必填]", example = "ADS85SAD")
    private String pwd;

    @Schema(description = "打开审核窗口时间")
    private String reviewTime;

}
