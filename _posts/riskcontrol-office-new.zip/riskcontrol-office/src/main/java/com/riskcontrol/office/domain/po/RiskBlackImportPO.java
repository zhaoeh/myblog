package com.riskcontrol.office.domain.po;

import com.alibaba.excel.annotation.ExcelProperty;
import com.riskcontrol.office.domain.entity.TRiskBlack;
import com.riskcontrol.office.domain.entity.TRiskBlackOperationAccountDetail;
import com.riskcontrol.office.domain.entity.TRiskBlackOperationDetail;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;
import java.util.Map;


/**
 * @description: 黑名单导入po
 * @author: ErHu.Zhao
 * @create: 2024-09-24
 **/
@Data
@Builder
@AllArgsConstructor
@Accessors
public class RiskBlackImportPO {

    /**
     * 导入模式实体
     */
    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors
    public static class ImportMode {
        @ExcelProperty("Account")
        private String loginName;
    }

    /**
     * 关联模式实体
     */
    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors
    public static class AssociationMode {
        @ExcelProperty("First name")
        private String firstName;

        @ExcelProperty("Middle name")
        private String middleName;

        @ExcelProperty("Last name")
        private String lastName;

        @ExcelProperty("Birthday")
        private String birthday;

    }

    /**
     * 黑名单导入上下文
     */
    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    @Accessors
    public static class BlackImportContext {

        // 导入模式/关联模式下，最终要录入的黑名单集
        private List<TRiskBlack> blacks;

        // 导入模式下黑名单用户集
        private List<TRiskBlackOperationDetail> imLogDetails;
//
//        // 导入模式下非法的黑名单用户集
//        private List<TRiskBlackOperationDetail> invalidatedDetails;

        // 关联模式下 黑名单日志明细:key 明细  value：当前明细关联账号
        private Map<TRiskBlackOperationDetail, List<TRiskBlackOperationAccountDetail>> reLogDetails;

        private int totalCount;
    }

}
