package com.riskcontrol.office.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.riskcontrol.office.domain.entity.TRiskLabelOperationLog;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TRiskLabelOperationLogMapper extends BaseMapper<TRiskLabelOperationLog> {

}