package com.riskcontrol.office.mapper;

import com.riskcontrol.office.domain.entity.TEkycRequest;
import org.apache.ibatis.annotations.Mapper;


/**
 * @author Heng.zhang
 */
@Mapper
public interface EkycRequestMapper extends BaseMapperX<TEkycRequest> {

}
