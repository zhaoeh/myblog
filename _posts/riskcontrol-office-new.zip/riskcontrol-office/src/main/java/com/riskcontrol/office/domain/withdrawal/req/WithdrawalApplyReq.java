package com.riskcontrol.office.domain.withdrawal.req;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Schema
@Data
public class WithdrawalApplyReq extends BaseReq {
    @Schema(required = true, description = "取款金额", example = "100.00")
    @NotBlank(message = "can't be empty")
    protected String amount;

    @Schema(required = true, description = "取款人", example = "kaili008")
    @NotBlank(message = "can't be empty")
    private String withdrawor;

    @Schema(description = "存款门店编码")
    protected String branchCode;

    @Schema(description = "玩家登录密码")
    protected String password;
}
