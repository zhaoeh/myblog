package com.riskcontrol.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.office.domain.req.black.RiskBlackOperationPageRequest;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.domain.rsp.black.RiskBlackOperationRsp;
import com.riskcontrol.office.domain.entity.TRiskBlackOperation;


/**
 * @author Heng.zhang
 */
public interface RiskBlackOperationService extends IService<TRiskBlackOperation> {
    /**
     * 风控黑名单历史操作记录主表分页列表 *
     *
     * @param req -
     * @return
     */
    PageModel<RiskBlackOperationRsp> getOperationPageList(RiskBlackOperationPageRequest req);
}
