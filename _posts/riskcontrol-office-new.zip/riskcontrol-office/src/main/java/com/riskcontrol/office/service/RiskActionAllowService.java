package com.riskcontrol.office.service;

import com.gw.datacenter.vo.pagainate.PageModel;
import com.riskcontrol.office.domain.req.RiskActionAllowCreationReq;
import com.riskcontrol.office.domain.req.RiskActionAllowEditReq;
import com.riskcontrol.office.domain.req.RiskActionAllowPageQueryReq;
import com.riskcontrol.office.domain.req.RiskActionAllowpUdateStatusReq;
import com.riskcontrol.office.domain.rsp.RiskActionAllowPageQueryRsp;

public interface RiskActionAllowService {

    Boolean create(RiskActionAllowCreationReq req);

    Boolean edit(RiskActionAllowEditReq req);

    Boolean updateStatus(RiskActionAllowpUdateStatusReq req);

    PageModel<RiskActionAllowPageQueryRsp> getPageList(RiskActionAllowPageQueryReq req);
}
