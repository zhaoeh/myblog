package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigInteger;

/**
 * @author Heng.zhang
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_risk_black_operation_log_detail")
@ApiModel(value = "t_risk_black_operation_log_detail对象", description = "黑名单历史操作记录明细")
public class TRiskBlackOperationDetail extends BaseEntity {

    @ApiModelProperty("ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    @ApiModelProperty(value = "操作日志主表id")
    private BigInteger blackId;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "账号")
    private String loginName;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "名")
    private String firstName;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "中间名")
    private String middleName;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "姓")
    private String lastName;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "生日")
    private String birthday;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "注册IP")
    private String registerIp;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "登陆IP")
    private String loginIp;

    @ApiModelProperty(value = "证件类型")
    private Integer idType;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "证件ID")
    private String idNo;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "电话号码")
    private String phoneNumber;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "邮箱")
    private String email;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "银行卡号")
    private String bankAccountNo;

    @ApiModelProperty(value = "状态 1：有效状态 0：无效状态")
    private Integer status;

    @ApiModelProperty("账户匹配状态 1：合法 0：非法")
    private Integer operationStatus;

    @ApiModelProperty(value = "创建日期")
    protected String createDate;

}