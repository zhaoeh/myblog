package com.riskcontrol.office.controller;

import com.gw.datacenter.vo.pagainate.PageModel;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.req.*;
import com.riskcontrol.office.domain.rsp.BlcackOpertionLogListPageQueryRsp;
import com.riskcontrol.office.domain.rsp.RiskActionAllowPageQueryRsp;
import com.riskcontrol.office.service.TRiskActionAllowOperationLogService;
import com.riskcontrol.office.service.RiskActionAllowService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @description: 黑白名单控制器
 * @author: ErHu.Zhao
 * @create: 2024-11-12
 **/
@RestController
@RequestMapping("/office/riskActionAllow")
@Tag(name = "风控黑白名单")
@Slf4j
public class RiskActionAllowController {

    @Autowired
    private RiskActionAllowService riskActionAllowService;

    @Resource
    private TRiskActionAllowOperationLogService tRiskActionAllowOperationLogService;
    @PostMapping("/create")
    @Operation(tags = "黑白名单", summary = "黑白名单创建")
    public R<Boolean> create( @Validated @RequestBody RiskActionAllowCreationReq req) throws Exception {
        return R.ok(riskActionAllowService.create(req));
    }

    @PostMapping("/edit")
    @Operation(tags = "黑白名单", summary = "黑白名单编辑")
    public R<Boolean> edit(@Validated @RequestBody RiskActionAllowEditReq req) throws Exception {
        return R.ok(riskActionAllowService.edit(req));
    }

    @PostMapping("/updateStatus")
    @Operation(tags = "黑白名单", summary = "黑白名单状态编辑")
    public R<Boolean> updateStatus(@Validated @RequestBody RiskActionAllowpUdateStatusReq req) throws Exception {
        return R.ok(riskActionAllowService.updateStatus(req));
    }

    @PostMapping("/getPageList")
    @Operation(tags = "黑白名单", summary = "黑白名单分页查询")
    public R<PageModel<RiskActionAllowPageQueryRsp>> getPageWhilteList(@Validated @RequestBody RiskActionAllowPageQueryReq req) throws Exception {
        return R.ok(riskActionAllowService.getPageList(req));
    }

    @PostMapping("/getOperationList")
    @Operation(tags = "黑白名单", summary = "查看黑白名单历史操作记录列表")
    public R<PageModel<BlcackOpertionLogListPageQueryRsp>> getPageBlackOperationList(@Validated @RequestBody BlackOperationListPageQueryReq req) throws Exception {
        return R.ok(tRiskActionAllowOperationLogService.getPageBlackOperationList(req));
    }


}
