package com.riskcontrol.office.domain.withdrawal.req;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
@Schema(title = "查询存款Remarks请求参数<br/>Request parameters for querying withdrawal remarks")
public class QueryWithdrawalRemarksReq extends BaseReq {
    @NotBlank(message = "requestId can not be blank")
    @Schema(required = true, description = "取款提案Id<br/>Withdrawal request Id")
    private String requestId;
}