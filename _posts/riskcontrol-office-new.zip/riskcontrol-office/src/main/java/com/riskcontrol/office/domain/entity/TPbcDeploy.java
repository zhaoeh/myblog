package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigInteger;
import java.util.Date;

import lombok.Data;

/**
    * pbc配置文件
    */
@Schema(description="pbc配置文件")
@Data
@TableName(value = "t_pbc_deploy")

public class TPbcDeploy extends BaseEntity {
    /**
     * id
     */
    @TableId(value = "id", type = IdType.AUTO)
    @Schema(description="id")
    private BigInteger id;

    /**
     * 抓取系统id
     */
    @TableField(value = "system_id")
    @Schema(description="抓取系统id")
    private String systemId;

    /**
     * 抓取系统名称
     */
    @TableField(value = "system_name")
    @Schema(description="抓取系统名称")
    private String systemName;

    /**
     * 域名地址
     */
    @TableField(value = "main_address")
    @Schema(description="域名地址")
    private String mainAddress;

    /**
     * 二级域名地址
     */
    @TableField(value = "sub_address")
    @Schema(description="二级域名地址")
    private String subAddress;

    /**
     * 用户名
     */
    @TableField(value = "user_name")
    @Schema(description="用户名")
    private String userName;

    /**
     * 密码
     */
    @TableField(value = "`password`")
    @Schema(description="密码")
    private String password;

    /**
     * 开始时间
     */
    @TableField(value = "start_time")
    @Schema(description="开始时间")
    private String startTime;

    /**
     * 停止时间
     */
    @TableField(value = "end_time")
    @Schema(description="停止时间")
    private String endTime;

    /**
     * 抓取频率
     */
    @TableField(value = "frequency")
    @Schema(description="抓取频率")
    private Integer frequency;

    /**
     * 配置状态 1 enable  0 disable
     */
    @TableField(value = "`status`")
    @Schema(description="配置状态 1 enable  0 disable")
    private Integer status;

    /**
     * 创建时间
     */
    @TableField(value = "create_date")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description="创建时间")
    private Date createDate;

    /**
     * 创建修改人
     */
    @TableField(value = "create_by")
    @Schema(description="创建修改人")
    private String createBy;

    /**
     * 修改时间
     */
    @TableField(value = "update_date")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description="修改时间")
    private Date updateDate;

    /**
     * 最后修改人
     */
    @TableField(value = "update_by")
    @Schema(description="最后修改人")
    private String updateBy;

    /**
     * 修改时间
     */
    @TableField(value = "delete_date")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description="修改时间")
    private Date deleteDate;

    /**
     * 删除人
     */
    @TableField(value = "delete_by")
    @Schema(description="删除人")
    private String deleteBy;

    /**
     * 是否有效Y 有效 N无效
     */
    @TableField(value = "is_valid")
    @Schema(description="是否有效Y 有效 N无效")
    private String isValid;

    private static final long serialVersionUID = 1L;
}