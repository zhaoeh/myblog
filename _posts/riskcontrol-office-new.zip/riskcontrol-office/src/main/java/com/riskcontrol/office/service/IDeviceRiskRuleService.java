package com.riskcontrol.office.service;

import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.domain.entity.RiskActionRuleEntity;
import com.riskcontrol.office.domain.entity.TLabelRuleRelationship;
import com.riskcontrol.office.domain.req.DeviceRiskRuleEditReq;
import com.riskcontrol.office.domain.req.DeviceRiskRuleNewReq;
import com.riskcontrol.office.domain.req.DeviceRiskRuleQueryReq;
import com.riskcontrol.office.domain.req.DeviceRiskRuleUpdateReq;
import com.riskcontrol.office.domain.rsp.DeviceRiskRuleResp;

/**
 * @author: Yu.Guo
 * @date: 2024/11/12
 * @description: 设备指纹风控规则接口
 */
public interface IDeviceRiskRuleService {

    /**
     * 创建设备指纹风控规则
     * @param deviceRiskRuleNewReq
     * @return
     */
    boolean deviceRiskRuleCreate(DeviceRiskRuleNewReq deviceRiskRuleNewReq);

    /**
     * 编辑设备指纹风控规则
     * @param deviceRiskRuleEditReq
     * @return
     */
    boolean deviceRiskRuleEdit(DeviceRiskRuleEditReq deviceRiskRuleEditReq);

    /**
     * 修改设备指纹风控规则状态
     * @param deviceRiskRuleUpdate
     * @return
     */
    boolean deviceRiskRuleUpdateStatus(DeviceRiskRuleUpdateReq deviceRiskRuleUpdate);

    /**
     * 分页查询设备指纹风控规则
     * @param deviceRiskRuleQueryReq
     * @return PageModel<TLabelRuleRelationship>
     */
    PageModel<DeviceRiskRuleResp> deviceRiskRulePageList(DeviceRiskRuleQueryReq deviceRiskRuleQueryReq);
}
