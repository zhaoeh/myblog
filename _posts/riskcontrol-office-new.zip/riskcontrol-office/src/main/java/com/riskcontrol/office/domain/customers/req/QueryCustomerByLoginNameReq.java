package com.riskcontrol.office.domain.customers.req;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("根据登录名查询玩家（玩家详细信息查询）")
public class QueryCustomerByLoginNameReq extends BaseReq {

    @ApiModelProperty(value = "玩家账号")
    private String customerName;

    @ApiModelProperty(value = "公共接口：此参数用于识别某处查询。默认为空，不作拓展性逻辑校验。取款：withdrawal，存款：deposit")
    private String queryFlag;
}
