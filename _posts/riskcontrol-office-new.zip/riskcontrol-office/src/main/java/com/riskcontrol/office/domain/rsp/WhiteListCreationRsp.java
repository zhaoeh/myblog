package com.riskcontrol.office.domain.rsp;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Schema(description = "白名单创建响应对象")
public class WhiteListCreationRsp {

    @Schema(description = "是否创建成功")
    @JsonProperty("createResult")
    private Boolean createResult;

    @Schema(description = "创建成功的条数")
    @JsonProperty("createSize")
    private Integer createSize;

    @Schema(description = "本次已经存在的规则名称，使用逗号拼接")
    @JsonProperty("existsName")
    private String existsName;


}