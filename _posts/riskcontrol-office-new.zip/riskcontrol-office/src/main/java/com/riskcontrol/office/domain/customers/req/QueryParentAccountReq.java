package com.riskcontrol.office.domain.customers.req;

import com.riskcontrol.common.entity.request.BaseQueryReq;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(title = "查询父级玩家账号")
@Data
public class QueryParentAccountReq extends BaseQueryReq {

    @Schema(description ="上级",example = "acc66")
    private String parentLoginName;
}
