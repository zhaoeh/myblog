package com.riskcontrol.office.domain.rsp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigInteger;

@ApiModel(value = "历史操作记录列表明细响应体", description = "历史操作记录列表明细响应体")
@Data
public class RiskLabelOperationDetailPageRsp {

    @ApiModelProperty("ID")
    private BigInteger id;

    @ApiModelProperty("用户名")
    private String loginName;

    @ApiModelProperty("新标签id")
    private String newRiskLabelId;

    @ApiModelProperty("账户匹配状态 1:合法 0:非法")
    private Integer operationStatus;

    @ApiModelProperty("remark")
    private String remark;

}
