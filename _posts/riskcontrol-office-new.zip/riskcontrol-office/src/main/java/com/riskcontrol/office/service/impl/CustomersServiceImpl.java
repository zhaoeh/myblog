package com.riskcontrol.office.service.impl;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.nacos.common.utils.CollectionUtils;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.cn.schema.customers.*;
import com.cn.schema.urf.*;
import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.google.common.base.Splitter;
import com.riskcontrol.common.config.C66Config;
import com.riskcontrol.common.config.UserCenterSwitch;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.request.CustomerActivationReq;
import com.riskcontrol.common.entity.request.QueryPageByKycRequestId;
import com.riskcontrol.common.entity.request.api.QueryKycRequestReq;
import com.riskcontrol.common.entity.request.api.UpdateKycRequestReq;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequest;
import com.riskcontrol.common.entity.request.kyc.WSKycRequestGw;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.kyc.RiskQueryKycRequestResponse;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelRsp;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.service.UserCenterTemplate;
import com.riskcontrol.common.service.WsFeignTemplate;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.common.utils.PHPDESEncrypt;
import com.riskcontrol.office.common.BaseService;
import com.riskcontrol.office.common.constants.Constants;
import com.riskcontrol.office.common.constants.RedisConstant;
import com.riskcontrol.office.common.enums.ChannelEnum;
import com.riskcontrol.office.common.enums.ErrorCodeEnum;
import com.riskcontrol.office.common.enums.KYCStatusEnum;
import com.riskcontrol.office.common.enums.PBCStatusEnum;
import com.riskcontrol.office.domain.constans.req.UpdateCustomerRiskLabelReq;
import com.riskcontrol.office.domain.customers.req.CreateCustomerRemarkReq;
import com.riskcontrol.office.domain.customers.req.KycSheetRequest;
import com.riskcontrol.office.domain.customers.req.QueryCustomerByLoginNameReq;
import com.riskcontrol.office.domain.customers.req.QueryCustomersReq;
import com.riskcontrol.office.domain.customers.rsp.BankAccountInfo;
import com.riskcontrol.office.domain.customers.rsp.WsCustomer;
import com.riskcontrol.office.domain.entity.TKycDeduplicate;
import com.riskcontrol.office.mapper.TKycDeduplicateMapper;
import com.riskcontrol.office.service.ICustomersService;
import com.riskcontrol.office.service.TRiskLabelRelationshipService;
import com.riskcontrol.office.template.RiskControlApiTemplate;
import com.riskcontrol.office.util.AESCrypt;
import com.riskcontrol.office.util.EncryptUtil;
import com.riskcontrol.office.util.RedisUtils;
import com.riskcontrol.office.util.aws.AWSS3Util;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.*;
import java.util.stream.Collectors;

import static com.riskcontrol.common.constants.Constant.DATE_TIME_FORMATTER;


/**
 * C66 office
 */
@Slf4j
@Service
public class CustomersServiceImpl extends BaseService implements ICustomersService {
    public static final String WS_PW_TIME_ERROR = "WS_202020";
    public static final String DEMO_IMAGE = "http://inter-csoffice-fat-c66.k8s-fat.com/static/img/C66.png";
    private static final String START_TIME = " 00:00:00";
    private static final String END_TIME = " 23:59:59";
    @Resource
    private HttpServletRequest request;
    @Resource
    private RiskControlApiTemplate riskControlApiTemplate;
    @Resource
    private C66Config c66Config;
    @Resource
    private WsFeignTemplate wsApiTemplate;
    @Resource
    private UserCenterTemplate userCenterTemplate;
    @Resource
    private AWSS3Util awss3Util;
    @Resource
    private EncryptUtil encryptUtil;
    @Resource
    private TRiskLabelRelationshipService riskLabelRelationshipService;
    @Value("${constant.gp.gli-gp-data}")
    private String gpData;
    @Resource
    private TKycDeduplicateMapper kycDeduplicateMapper;

    @Override
    public Response<PageModel<WSKycRequestGw>> queryKycRequestsNewRisk(QueryKycRequestReq req) {
        Response response = new Response();
        if (null == req.getPageNo())
            req.setPageNo(1);
        if (null == req.getPageSize())
            req.setPageSize(20);

        if(StringUtils.isAllBlank(req.getCustomerName(),req.getBillNo())
                && StringUtils.isAnyBlank(req.getCreatedDateBegin(),req.getCreatedDateEnd())){
            throw new BusinessException("querytime、loginName、billNo can't all be null",9999);
        }

        if(!StringUtils.isAllBlank(req.getCreatedDateBegin(),req.getCreatedDateEnd())){
            if(!req.getCreatedDateBegin().substring(0, 10).equals(req.getCreatedDateEnd().substring(0, 10))){
                throw new BusinessException("Time query can't exceed one full day",9999);
            }
        }
        RiskQueryKycRequest query = new RiskQueryKycRequest();
        BeanUtils.copyProperties(req, query);
        query.setPageNum(req.getPageNo());
        query.setPageSize(req.getPageSize());
        query.setLoginName(req.getCustomerName());
        query.setCreatedDateBegin(req.getCreatedDateBegin());
        query.setCreatedDateEnd(req.getCreatedDateEnd());
//        query.setAssigneeDateBegin(req.getAssigneeDateBegin());
//        query.setAssigneeDateEnd(req.getAssigneeDateEnd());
        query.setBillNo(req.getBillNo());

        WSQueryUsers wsQueryUsers = new WSQueryUsers();
        wsQueryUsers.setLoginName(req.getLoginName());
        wsQueryUsers.setProductId(req.getProductId());


        if (req.getProcessType() != null) {
            if (req.getProcessType() > 3) {
                query.setPbcStatus(String.valueOf(req.getProcessType() - 4));
                query.setStatusList("1;");
            }
            if (req.getProcessType() <= 3) {
                if (req.getProcessType() == 3) {
                    query.setStatusList(StringUtils.join(req.getProcessType(), ";", 2, ";"));
                } else {
                    query.setStatusList(StringUtils.join(req.getProcessType(), ";"));
                }
            }
        }
        int count = riskControlApiTemplate.countKycPbcRequest(query, req.getProductId());

        RiskQueryKycRequestResponse kycRequestResponse = riskControlApiTemplate.queryKycPbcRequest(query, req.getProductId());

        List<WSKycRequestGw> wsKycRequestGws = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(kycRequestResponse.getData())) {
            kycRequestResponse.getData().forEach(kycRequest -> {


                if (isSkipEnvironment(kycRequest.getProductId())) {
                    kycRequest.setIdScan(DEMO_IMAGE);
                } else {
                    try {
                        if (StringUtils.isNotBlank(kycRequest.getIdScan())) {
                            // 脏数据处理
                            if (JSON.isValid(kycRequest.getIdScan())) {
                                String imageKey = JSON.parseObject(kycRequest.getIdScan()).getString("imageKey");
                                //kycRequest.setIdScan(imageKey.startsWith("http")?imageKey:awss3Util.s3GetUrl(imageKey));DESUtil.encrypt(subIdScan.startsWith("http")?subIdScan:awss3Util.s3GetUrl(subIdScan),"jhs#%!fde")
                                kycRequest.setIdScanImagekey(imageKey);
                                kycRequest.setIdScan(imageKey.startsWith("http") ? imageKey : imageKey.contains("_md5") ? awss3Util.s3GetTxtUrl(imageKey) : awss3Util.s3GetUrl(imageKey));
                                //kycRequest.setIdScanV2(DESUtil.encrypt(imageKey.startsWith("http")?imageKey:awss3Util.s3GetUrl(imageKey),"jhs#%!fde"));
                                kycRequest.setIdScanV2(AESCrypt.encryptCBC(imageKey.startsWith("http") ? imageKey : imageKey.contains("_md5") ? awss3Util.s3GetTxtUrl(imageKey) : awss3Util.s3GetUrl(imageKey), "20230103aes00001", "aes0000120230103"));

                            } else {
                                // kycRequest.setIdScan(kycRequest.getIdScan().startsWith("http") ? kycRequest.getIdScan() : awss3Util.s3GetUrl(kycRequest.getIdScan()));
                                kycRequest.setIdScanImagekey(kycRequest.getIdScan());
                                kycRequest.setIdScan(kycRequest.getIdScan().startsWith("http") ? kycRequest.getIdScan() : kycRequest.getIdScan().contains("_md5") ? awss3Util.s3GetTxtUrl(kycRequest.getIdScan()) : awss3Util.s3GetUrl(kycRequest.getIdScan()));
                                //kycRequest.setIdScanV2(DESUtil.encrypt(kycRequest.getIdScan().startsWith("http") ? kycRequest.getIdScan() : awss3Util.s3GetUrl(kycRequest.getIdScan()),"jhs#%!fde"));
                                kycRequest.setIdScanV2(AESCrypt.encryptCBC(kycRequest.getIdScan().startsWith("http") ? kycRequest.getIdScan() : kycRequest.getIdScan().contains("_md5") ? awss3Util.s3GetTxtUrl(kycRequest.getIdScan()) : awss3Util.s3GetUrl(kycRequest.getIdScan()), "20230103aes00001", "aes0000120230103"));
                            }
                        }
                        if (StringUtils.isNotBlank(kycRequest.getImgUrl())) {
                            String imageKey = kycRequest.getImgUrl();
                            kycRequest.setImgUrl(imageKey.startsWith("http") ? imageKey : imageKey.contains("_md5") ? awss3Util.s3GetTxtUrl(imageKey) : awss3Util.s3GetUrl(imageKey));
                        }
                    } catch (Exception e) {
                        log.info("查询用户{}的证件照失败:{}", kycRequest.getLoginName(), e);
                    }
                }

                // PAY-27 增加产品和渠道
                if (StringUtils.isNotBlank(kycRequest.getChannel())) {
                    ChannelEnum channelEnum = ChannelEnum.getNameByType(kycRequest.getChannel());
                    log.info("CustomerServiceImpl 类里面  查询产品渠道为空,原始渠道为={}", kycRequest.getChannel());
                    if (channelEnum != null) {
                        kycRequest.setChannel(channelEnum.getName());
                    }
                }
                WSKycRequestGw wsKycRequestGw = new WSKycRequestGw();
                BeanUtils.copyProperties(kycRequest, wsKycRequestGw);
                if (StringUtils.equals("1", gpData)) {
                    WSCustomers wsCustomers = userCenterTemplate.getSimpleCustomerByLoginName(req.getProductId(), req.getLoginName());
                    wsKycRequestGw.setProvince(wsCustomers.getProvince());
                    wsKycRequestGw.setReserve2(wsCustomers.getReserve2());
                    wsKycRequestGw.setReserve4(wsCustomers.getReserve4());
                }
                wsKycRequestGws.add(wsKycRequestGw);
            });
        }

        PageModel<WSKycRequestGw> pageModel = new PageModel<>(count, req.getPageNo(), req.getPageSize());
        pageModel.setData(wsKycRequestGws);
        response.setBody(pageModel);

        return response;
    }

    @Override
    public Response<PageModel<KycSheetRequest>> queryKycSheetRequestsRisk(QueryKycRequestReq req) {
        Response response = new Response();
        if (null == req.getPageNo())
            req.setPageNo(1);
        if (null == req.getPageSize())
            req.setPageSize(100);

        Response<PageModel<KycRequest>> data = queryKycRequestsNew2(req);

        PageModel<KycSheetRequest> pages = new PageModel<>(0, req.getPageNo(), req.getPageSize());
        List<KycSheetRequest> result2 = new ArrayList<>();
        if (data.getBody().getData().size() > 0) {
            for (KycRequest wsKycRequest : data.getBody().getData()) {
                KycSheetRequest o = new KycSheetRequest();
                BeanUtils.copyProperties(wsKycRequest, o);
                o.setBillNo("\t" + o.getBillNo());
                o.setRealName(wsKycRequest.getFirstName() + (wsKycRequest.getMiddleName() == null ? " " : (" " + wsKycRequest.getMiddleName() + " ")) + wsKycRequest.getLastName());
                o.setFirstName(wsKycRequest.getFirstName());
                o.setMiddleName(wsKycRequest.getMiddleName());
                o.setLastName(wsKycRequest.getLastName());
                if ((wsKycRequest.getStatus().equals("1") && wsKycRequest.getPbcStatus() == 0) || wsKycRequest.getPbcStatus() == null) {
                    o.setPbcStatus("");
                } else {
                    o.setPbcStatus(PBCStatusEnum.getPbcEnumByStatus(wsKycRequest.getPbcStatus()).getPbcStatusString());
                }

                result2.add(o);
            }
            pages.setTotalRow(data.getBody().getTotalRow());
            pages.setTotalPage(data.getBody().getTotalPage());
        }
        pages.setData(result2);
        response.setBody(pages);
        return response;
    }

    private Response<PageModel<KycRequest>> queryKycRequestsNew2(QueryKycRequestReq req) {
        if(StringUtils.isAllBlank(req.getCustomerName(),req.getBillNo())
                && StringUtils.isAnyBlank(req.getCreatedDateBegin(),req.getCreatedDateEnd())){
            throw new BusinessException("querytime、loginName、billNo can't all be null",9999);
        }

        if(!StringUtils.isAllBlank(req.getCreatedDateBegin(),req.getCreatedDateEnd())){
            if(!req.getCreatedDateBegin().substring(0, 10).equals(req.getCreatedDateEnd().substring(0, 10))){
                throw new BusinessException("Time query can't exceed one full day",9999);
            }
        }
        Response<PageModel<KycRequest>> response = new Response<>();

        RiskQueryKycRequest query = new RiskQueryKycRequest();
        BeanUtils.copyProperties(req, query);
        query.setIsExport(true);//导出参数，影响排序效果
        query.setPageNum(req.getPageNo());
        query.setPageSize(req.getPageSize());
        query.setLoginName(req.getCustomerName());
        query.setCreatedDateBegin(req.getCreatedDateBegin());
        query.setCreatedDateEnd(req.getCreatedDateEnd());
//        query.setAssigneeDateBegin(req.getAssigneeDateBegin());
//        query.setAssigneeDateEnd(req.getAssigneeDateEnd());
        query.setBillNo(req.getBillNo());

        WSQueryUsers wsQueryUsers = new WSQueryUsers();
        wsQueryUsers.setLoginName(req.getLoginName());
        wsQueryUsers.setProductId(req.getProductId());


        if (req.getProcessType() != null) {
            if (req.getProcessType() > 3) {
                query.setPbcStatus(String.valueOf(req.getProcessType() - 4));
                query.setStatusList("1;");
            }
            if (req.getProcessType() <= 3) {
                if (req.getProcessType() == 3) {
                    query.setStatusList(StringUtils.join(req.getProcessType(), ";", 2, ";"));
                } else {
                    query.setStatusList(StringUtils.join(req.getProcessType(), ";"));
                }
            }
        }
        int count = riskControlApiTemplate.countKycPbcRequest(query, req.getProductId());

        RiskQueryKycRequestResponse kycRequestResponse = riskControlApiTemplate.queryKycPbcRequest(query, req.getProductId());


        if (CollectionUtils.isNotEmpty(kycRequestResponse.getData())) {
            kycRequestResponse.getData().forEach(kycRequest -> {
                if (isSkipEnvironment(kycRequest.getProductId())) {
                    kycRequest.setIdScan(DEMO_IMAGE);
                } else {
                    try {
                        if (!StringUtils.isBlank(kycRequest.getStatus())) {
                            if (kycRequest.getStatus().equals(String.valueOf(KYCStatusEnum.DISTRIBUTED.getKycStatus()))) {
//                                kycRequest.setStatus(null);
                            } else {
                                kycRequest.setStatus(KYCStatusEnum.getKYCEnumByStatus(Integer.valueOf(kycRequest.getStatus())).getKycStatusString());
                            }
                        }
                        if (StringUtils.isNotBlank(kycRequest.getIdScan())) {
                            // 脏数据处理
                            if (JSON.isValid(kycRequest.getIdScan())) {
                                String imageKey = JSON.parseObject(kycRequest.getIdScan()).getString("imageKey");
                                kycRequest.setIdScanImagekey(imageKey);
                                kycRequest.setIdScan(imageKey.startsWith("http") ? imageKey : imageKey.contains("_md5") ? awss3Util.s3GetTxtUrl(imageKey) : awss3Util.s3GetUrl(imageKey));
                                kycRequest.setIdScanV2(AESCrypt.encryptCBC(imageKey.startsWith("http") ? imageKey : imageKey.contains("_md5") ? awss3Util.s3GetTxtUrl(imageKey) : awss3Util.s3GetUrl(imageKey), "20230103aes00001", "aes0000120230103"));

                            } else {
                                kycRequest.setIdScanImagekey(kycRequest.getIdScan());
                                kycRequest.setIdScan(kycRequest.getIdScan().startsWith("http") ? kycRequest.getIdScan() : kycRequest.getIdScan().contains("_md5") ? awss3Util.s3GetTxtUrl(kycRequest.getIdScan()) : awss3Util.s3GetUrl(kycRequest.getIdScan()));
                                kycRequest.setIdScanV2(AESCrypt.encryptCBC(kycRequest.getIdScan().startsWith("http") ? kycRequest.getIdScan() : kycRequest.getIdScan().contains("_md5") ? awss3Util.s3GetTxtUrl(kycRequest.getIdScan()) : awss3Util.s3GetUrl(kycRequest.getIdScan()), "20230103aes00001", "aes0000120230103"));
                            }
                        }
                    } catch (Exception e) {
                        log.info("查询用户{}的证件照失败:{}", kycRequest.getLoginName(), e);
                    }
                }
            });
        }

        try {
            PageModel<KycRequest> pageModel = new PageModel<>(count, req.getPageNo(), req.getPageSize());
            pageModel.setData(kycRequestResponse.getData());
            response.setBody(pageModel);
        } catch (Exception e) {
            log.error("CustomerServiceImpl 类里面  queryKycRequestsNew方法出异常了");
        }
        return response;
    }

    public Boolean updatePbcRequestRisk(UpdateKycRequestReq req) {
        if (StringUtils.isEmpty(req.getLoginName())) {
            throw new BusinessException(ResultEnum.LOGIN_NAME_EMPTY_ERROR);
        }
        if (StringUtils.isBlank(req.getOperator())) {
            throw new BusinessException(ResultEnum.LOGIN_NAME_EMPTY_ERROR);

        }

        WSCustomers dbCustomer;
        if (StringUtils.equals(Constant.ONE_STR, c66Config.getUserCenterCallSwitch())) {
            dbCustomer = userCenterTemplate.getSimpleCustomerByLoginName(req.getProductId(), req.getLoginName());
        } else {
            dbCustomer = wsApiTemplate.getCustomerByLoginName(req.getProductId(), req.getLoginName());
        }
        if (Objects.isNull(dbCustomer)) {
            throw new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST_ERROR);

        }

        RiskQueryKycRequest query = new RiskQueryKycRequest();
        query.setCustomerId(dbCustomer.getCustomerId());
        query.setLoginName(dbCustomer.getLoginName());
        query.setProductId(dbCustomer.getProductId());
        query.setPageSize(1);
        query.setPageNum(1);
        query.setPbcStatus("0");
        query.setStatusList(StringUtils.join("1", ";"));

        /**
         * 新 cron 接口
         */
        RiskQueryKycRequestResponse kycRequestResponse = riskControlApiTemplate.queryKycRequestRisk(query, dbCustomer.getProductId());

        if (kycRequestResponse.getData().size() == 0) {
            throw new BusinessException(ResultEnum.CUSTOMER_MODIFY_FAILED_ERROR);

        }
        KycRequest dbKycRequest = kycRequestResponse.getData().get(0);

        if (!StringUtils.equals(dbKycRequest.getStatus(), Constant.ONE_STR)) {
            throw new BusinessException(ResultEnum.CUSTOMER_MODIFY_FAILED_ERROR);
        }
        KycRequest wsKycRequest = new KycRequest();
        wsKycRequest.setId(req.getId());
        wsKycRequest.setProductId(req.getProductId());
        wsKycRequest.setLoginName(req.getLoginName());
        wsKycRequest.setCustomerId(req.getCustomerId());
//            wsKycRequest.setUpdateBy(req.getOperator());
        wsKycRequest.setUpdateDate(DateUtils.getCurrentDateTime());
        wsKycRequest.setApprovedDate(DateUtils.getCurrentDateTime());
//            wsKycRequest.setApprovedBy(req.getOperator());
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            wsKycRequest.setApprovedBy(userInfoVO.getUserInfo().getUsername());
            wsKycRequest.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        wsKycRequest.setPbcStatus(Integer.parseInt(req.getPbcStatus()));

        if (StringUtils.isNotBlank(req.getFirstName())) {
            wsKycRequest.setFirstName(req.getFirstName());
        } else {
            throw new BusinessException(ResultEnum.FIRST_NAME_EMPTY_ERROR);
        }
        if (StringUtils.isNotBlank(req.getMiddleName())) {
            wsKycRequest.setMiddleName(req.getMiddleName());
        }
        if (StringUtils.isNotBlank(req.getLastName())) {
            wsKycRequest.setLastName(req.getLastName());
        } else {
            throw new BusinessException(ResultEnum.LAST_NAME_EMPTY_ERROR);
        }
        if (StringUtils.isNotBlank(req.getSex())) {
            wsKycRequest.setSex(req.getSex());
        }
        if (StringUtils.isNotBlank(req.getBirthday())) {
            try {
                LocalDate.parse(req.getBirthday());
            } catch (Exception e) {
                throw new BusinessException(ResultEnum.BIRTHDAY_INVALID_ERROR);
            }
            wsKycRequest.setBirthday(req.getBirthday());
        } else {
            throw new BusinessException(ResultEnum.BIRTHDAY_EMPTY_ERROR);
        }

        if (StringUtils.isNotBlank(req.getPbcStatus()) && ("1".equals(req.getPbcStatus()) || ("3".equals(req.getPbcStatus()) && !Strings.isBlank(req.getRemark())))) {
            wsKycRequest.setPbcStatus(Integer.parseInt(req.getPbcStatus()));
            wsKycRequest.setRemark(req.getRemark());
        } else {
            log.info("当前请求数据:{}", JSON.toJSONString(req));

            throw new BusinessException(ResultEnum.PBCSTATUS_REMARK_NOT_MATCH);

        }

        if (1 == wsKycRequest.getPbcStatus()) {
            // 通过,修改客户表证件信息,修改t_customers表
            dbCustomer.setPhone(null);
            dbCustomer.setEmail(null);
            if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
                dbCustomer.setLastUpdatedBy(userInfoVO.getUserInfo().getUsername());
            }
//                dbCustomer.setLastUpdatedBy(req.getOperator());
            dbCustomer.setLastUpdate(DateUtils.getCurrentDateTime());
            dbCustomer.setFirstName(wsKycRequest.getFirstName());
            dbCustomer.setLastName(wsKycRequest.getLastName());
            dbCustomer.setMiddleName(wsKycRequest.getMiddleName());
            dbCustomer.setSex(wsKycRequest.getSex());
            dbCustomer.setBirthDate(wsKycRequest.getBirthday());
            log.info("修改客户表信息 updatePbcRequest dbCustomer={}", JSON.toJSONString(dbCustomer));
            ModifyAccountResponse modifyAccountResponse = Optional.ofNullable(UserCenterSwitch.getSwitch()).filter(Boolean::booleanValue).
                    map(e -> userCenterTemplate.modifyAccount(dbCustomer, Constant.ONE_STR)).
                    orElseGet(() -> wsApiTemplate.modifyAccount(dbCustomer, Constant.ONE_STR));
            if (StringUtils.isNotBlank(modifyAccountResponse.getWsErrorMsg())) {
                throw new BusinessException(modifyAccountResponse.getWsErrorMsg(), modifyAccountResponse.getErrCode());
            }
        }
        riskControlApiTemplate.pbcModifyStatus(wsKycRequest, req.getProductId());
        return true;
    }

    @Override
    public Response queryPageByKycRequestIdRisk(QueryPageByKycRequestId req) {
        Response response = new Response();
        try {
            log.info("进入queryPageByKycRequestId={}", new Date());
            QueryKycRequestProcessLogResponse queryKycRequestProcessLogResponse = riskControlApiTemplate.queryPageByKycRequestId(req);

            List<WSKycRequestProcessLog> list = queryKycRequestProcessLogResponse.getData();
            Map<String, Object> bodys = new HashMap<>();
            List<Map<String, Object>> maps = new ArrayList<>();
            bodys.put("count", queryKycRequestProcessLogResponse.getCount());

            for (WSKycRequestProcessLog log : list) {
                Map<String, Object> map = new HashMap<>();
                map.put("kycRequestId", log.getKycRequestId());
                map.put("createTime", getDateString(log.getCreateTime()));
                map.put("dispatchBy", log.getDispatchBy());
                map.put("id", log.getId());
                map.put("lastStauts", log.getLastStauts());
                map.put("remark", log.getRemark());
                map.put("type", log.getType());
                maps.add(map);

            }
            bodys.put("data", maps);


            response.setBody(new JSONObject().fluentPut("data", bodys));
        } catch (Exception e) {
            log.error("queryPageByKycRequestIdRisk error", e);
            response.setHead(ErrorCodeEnum.ERROR_UPDATE_KYC_REQUEST_RISK.getErrCode(), "kyc RequestIdRisk error");
            response.setBody(false);
        }
        return response;
    }

    private String getDateString(Date createTime) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(createTime);
        return DateUtils.getDateString2(calendar.getTime(), "yyyy-MM-dd HH:mm:ss");
    }

    @Override
    public Boolean updateKycRequestRisk(UpdateKycRequestReq req) {
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        log.info("updateKycRequestRisk 请求：riskcontrol , req={}", req.toString());
        log.info("updateKycRequest req={}", req);
        if (StringUtils.isBlank(req.getOperator())) {
            throw new BusinessException(ResultEnum.LOGIN_NAME_EMPTY_ERROR);
        }

        WSCustomers dbCustomer;
        if (UserCenterSwitch.getSwitch()) {
            dbCustomer = userCenterTemplate.getSimpleCustomerByLoginName(req.getProductId(), req.getLoginName());
        } else {
            dbCustomer = wsApiTemplate.getCustomerByLoginName(req.getProductId(), req.getLoginName());
        }
        if (Objects.isNull(dbCustomer)) {
            throw new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST_ERROR);
        }
        KycRequest wsKycRequest = getWSKycRequest(req);

        RiskQueryKycRequest query = new RiskQueryKycRequest();
        query.setCustomerId(dbCustomer.getCustomerId());
        query.setLoginName(dbCustomer.getLoginName());
        query.setProductId(dbCustomer.getProductId());
        query.setId(req.getId());
        query.setPageSize(1);
        query.setPageNum(1);

        RiskQueryKycRequestResponse kycRequestResponse = riskControlApiTemplate.queryKycRequestRisk(query, dbCustomer.getProductId());
        log.info("  wsFeignTemplate.queryKycRequest  kycRequestResponse:{}", JSONObject.toJSONString(kycRequestResponse));
        KycRequest dbKycRequest = kycRequestResponse.getData().get(0);
        //这里是需要修改
        if (!StringUtils.equals(dbKycRequest.getStatus(), Constant.ZERO_STR)) {
            throw new BusinessException(ResultEnum.CUSTOMER_MODIFY_FAILED_ERROR);
        }
        if (StringUtils.equals(wsKycRequest.getStatus(), Constant.ONE_STR)) {
            if (StringUtils.isEmpty(req.getIdType()) || StringUtils.isEmpty(req.getIdNo())) {
                throw new BusinessException(ErrorCodeEnum.IDNO_IDTYPE_PARAM_EMPTY_ERROR.getErrMsg(), ErrorCodeEnum.IDNO_IDTYPE_PARAM_EMPTY_ERROR.getErrCode());
            }
            boolean exists = validKycIdAndTypeExist(Integer.valueOf(req.getIdType()), req.getIdNo());
            if (exists) {
                throw new BusinessException(ErrorCodeEnum.ERROR_VALID_KYC_ID_EXISTS.getErrMsg(), ErrorCodeEnum.ERROR_VALID_KYC_ID_EXISTS.getErrCode());
            }
            wsKycRequest.setIdType(req.getIdType());
            wsKycRequest.setIdNo(req.getIdNo());
            // 通过
            // 修改客户表证件信息
            dbCustomer.setPhone(null);
            dbCustomer.setEmail(null);
            if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
                dbCustomer.setLastUpdatedBy(userInfoVO.getUserInfo().getUsername());
            }
            dbCustomer.setLastUpdate(DateUtils.getCurrentDateTime());
            dbCustomer.setFirstIdScan(dbKycRequest.getIdScan());
            dbCustomer.setFirstNoType(wsKycRequest.getIdNo());
            //把idType存入到t_customers表中
            dbCustomer.setFirstIdType(wsKycRequest.getIdType());
            dbCustomer.setFirstName(wsKycRequest.getFirstName());
            dbCustomer.setLastName(wsKycRequest.getLastName());
            dbCustomer.setMiddleName(wsKycRequest.getMiddleName());
            dbCustomer.setSex(wsKycRequest.getSex());
            dbCustomer.setAddress(wsKycRequest.getAddress());
            dbCustomer.setNationality(wsKycRequest.getCountry());
            dbCustomer.setBirthDate(wsKycRequest.getBirthday());
            // 设置职业、收入来源 随机填入 + 年收入
            dbCustomer.setOccupation(Constant.OCCUPATION_ARRAY[(int) (Math.random() * Constant.OCCUPATION_ARRAY.length)]);
            dbCustomer.setSourceOfIncome(Constant.SOURCE_OF_INCOME_ARRAY[(int) (Math.random() * Constant.SOURCE_OF_INCOME_ARRAY.length)]);
            dbCustomer.setAnnualIncome(Constant.ANNUAL_INCOME_ARRAY[(int) (Math.random() * Constant.ANNUAL_INCOME_ARRAY.length)]);
            // SLDBUG-1228 【h5-pc-2.0】kyc-门店端待实现功能列表 - 根据门店 会获取 省市和邮编
            if (StringUtils.isAllBlank(dbCustomer.getCity(), dbCustomer.getProvince(), dbCustomer.getPostalCode())) {
                dbCustomer.getBranchName();
                WSQueryBranch queryBranch = new WSQueryBranch();
                queryBranch.setBranchCode(dbCustomer.getBranchCode());
                queryBranch.setPageNum(1);
                queryBranch.setPageSize(1);
                QueryBranchResponse branchResponse = wsApiTemplate.queryBranchList(dbCustomer.getProductId(), queryBranch);
                if (CollectionUtils.isNotEmpty(branchResponse.getData())) {
                    WSBranch branch = branchResponse.getData().get(0);
                    String city = branch.getCity();
                    dbCustomer.setCity(city);
                    Constant.CITY_POSTAL_CODE_JSON.keySet().forEach(province -> {
                        JSONObject cities = Constant.CITY_POSTAL_CODE_JSON.getJSONObject(province);
                        if (cities.keySet().contains(city)) {
                            dbCustomer.setProvince(province);
                            dbCustomer.setPostalCode(cities.getString(city));
                        }
                    });
                }
            }
            ModifyAccountResponse modifyAccountResponse;
            if (UserCenterSwitch.getSwitch()) {
                log.info("userCenterTemplate modifyAccount..........");
                modifyAccountResponse = userCenterTemplate.modifyAccount(dbCustomer, Constant.ONE_STR);
            } else {
                log.info("wsFeignTemplate modifyAccount.......");
                modifyAccountResponse = wsApiTemplate.modifyAccount(dbCustomer, Constant.ONE_STR);
            }

            if (StringUtils.isNotBlank(modifyAccountResponse.getWsErrorMsg())) {
                throw new BusinessException(modifyAccountResponse.getWsErrorMsg(), modifyAccountResponse.getErrCode());
            }
            // kyc审批通过时 如果客户 非激活 就给激活
            if (StringUtils.equals(dbCustomer.getActivation(), Constant.ZERO_STR)) {
                CustomerActivationReq activationReq = new CustomerActivationReq();
                BeanUtils.copyProperties(dbCustomer, activationReq);
                activationReq.setActivation(Constant.ONE_STR);
                activationReq.setCustomerName(dbCustomer.getLoginName());

                if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
                    activationReq.setLoginName(userInfoVO.getUserInfo().getUsername());
                }
                customerActivation(activationReq);
            }
            riskControlApiTemplate.updateKycRequest(wsKycRequest, req.getProductId());

            WSQueryFunctions wsQueryFunctions = new WSQueryFunctions();
            wsQueryFunctions.setFunctionId("635979");
            BatchActivateSuspendResponse batchActivateSuspendResponse = wsApiTemplate.queryUserByFunction(wsQueryFunctions, req.getProductId());
            if (batchActivateSuspendResponse != null && batchActivateSuspendResponse.getUsers() != null && batchActivateSuspendResponse.getUsers().size() > 0) {
                Random random = new Random();
                int index = random.nextInt(batchActivateSuspendResponse.getUsers().size());
                KycRequest wsPbcRequest = new KycRequest();
                wsPbcRequest.setId(req.getId());
                wsPbcRequest.setProductId(req.getProductId());
                wsPbcRequest.setLoginName(req.getLoginName());
                wsPbcRequest.setCustomerId(req.getCustomerId());
                wsPbcRequest.setDispatchStatus(4);
                wsPbcRequest.setAssigneeTime(this.buildTimeEx(new Date()));
                wsPbcRequest.setAssigneeBy(batchActivateSuspendResponse.getUsers().get(index).getLoginName());
                if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
                    wsPbcRequest.setApprovedBy(userInfoVO.getUserInfo().getUsername());
                }
                wsPbcRequest.setMiddleName(req.getMiddleName());
                riskControlApiTemplate.pbcDispatch(wsPbcRequest, req.getProductId());
            } else {
                log.error("没有pbc审核权限的用户，请配置");
            }
        } else if (StringUtils.equals(wsKycRequest.getStatus(), Constant.THREE_STR)) {
            // 拒绝
            riskControlApiTemplate.updateKycRequest(wsKycRequest, req.getProductId());
        }
        return true;
    }

    private void customerActivation(CustomerActivationReq req) {
        if (StringUtils.isEmpty(req.getCustomerName())) {
            throw new BusinessException(ResultEnum.LOGIN_NAME_EMPTY_ERROR);
        }

        WSCustomers dbCustomer = getWSCustomerInfo(req.getProductId(), req.getCustomerName());
        if (Objects.isNull(dbCustomer)) {
            throw new BusinessException(ResultEnum.LOGIN_NAME_NOT_EXIST_ERROR);
        }

        if (dbCustomer.getLoginName().contains(Constant.LOGIN_NAME_PREFIX) && StringUtils.isEmpty(dbCustomer.getLastGame())) {
            throw new BusinessException(ResultEnum.COMPLETE_PLAYER_INFORMATION_ERROR);
        }
        String dbPhone = null;
        try {
            dbPhone = PHPDESEncrypt.getNewInstance(req.getProductId(), "03").decrypt(dbCustomer.getPhone());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        // 激活短信实体
        WSCustomers wsCustomersSms = new WSCustomers();
        wsCustomersSms.setProductId(req.getProductId());
        wsCustomersSms.setLoginName(dbCustomer.getLoginName());
        wsCustomersSms.setPhone(dbPhone);

        int registerFromType = dbCustomer.getRegisterFromType();
        WSCustomers wsCustomer = new WSCustomers();
        if (registerFromType == 3) {  //官网过来
            wsCustomer.setFirstIdType(req.getFirstIdType());
            wsCustomer.setFirstNoType(req.getFirstNoType());
            if (StringUtils.isNotBlank(req.getFirstIdScan())) {
                wsCustomer.setFirstIdScan(req.getFirstIdScan()); // 证件1  前端先調用接口上傳圖片, 這邊僅儲存key
            }

            wsCustomer.setSecondIdType(req.getSecondIdType());
            wsCustomer.setSecondNoType(req.getSecondNoType());
            if (StringUtils.isNotBlank(req.getSecondIdScan())) {
                wsCustomer.setSecondIdScan(req.getSecondIdScan()); // 證件2 前端先調用接口上傳圖片, 這邊僅儲存key
            }

            if (StringUtils.isNotEmpty(req.getPhone())) {
                String decryptPhoneRsp = this.decrypt(req, req.getPhone());

                if (StringUtils.isNotBlank(req.getPhone()) && !dbPhone.equals(decryptPhoneRsp)) {
                    wsCustomer.setPhone(decryptPhoneRsp);
                    wsCustomer.setPhoneMd5(DigestUtils.md5Hex(decryptPhoneRsp));
                    ModifyAccountResponse res;
                    if (UserCenterSwitch.getSwitch()) {
                        wsCustomer.setCustomerId(dbCustomer.getCustomerId());
                        res = userCenterTemplate.modifyAccount(wsCustomer, "17");
                    } else {
                        res = wsApiTemplate.modifyAccount(wsCustomer, "17");
                    }

                    if (null != res.getWSCustomers()) {
                        wsCustomer.setPhone(null);
                        wsCustomer.setPhoneMd5(null);
                        wsCustomersSms.setPhone(decryptPhoneRsp);
                    }
                }
            }

        } else if (registerFromType == 1) {  // 既有门店导入
            wsCustomer.setNationality(req.getNationality());
            wsCustomer.setBranchCode(req.getBranchCode());
        }

        if (StringUtils.isNotBlank(req.getBirthDate())) {
            wsCustomer.setBirthDate(req.getBirthDate().trim());  // 生日
        }
        if (StringUtils.isNotBlank(req.getFirstName())) {
            wsCustomer.setFirstName(req.getFirstName().trim());
        }
        if (StringUtils.isNotBlank(req.getMiddleName())) {
            wsCustomer.setMiddleName(req.getMiddleName().trim());
        }
        if (StringUtils.isNotBlank(req.getLastName())) {
            wsCustomer.setLastName(req.getLastName().trim());
        }

        wsCustomer.setOccupation(req.getOccupation());
        wsCustomer.setSourceOfIncome(req.getSourceOfIncome());
        wsCustomer.setViber(req.getViber());
        wsCustomer.setMessager(req.getMessager());
        wsCustomer.setAddress(req.getAddress());  // 地址
        wsCustomer.setSex(req.getSex());  // 性別
        wsCustomer.setProvince(req.getProvince());
        wsCustomer.setCity(req.getCity());
        wsCustomer.setPostalCode(req.getPostalCode());
        wsCustomer.setLastUpdatedBy(req.getLoginName());
        wsCustomer.setActivation(req.getActivation());
        wsCustomer.setCurrency(req.getCurrency());
        if (Constant.ONE_STR.equalsIgnoreCase(req.getActivation())) {
            wsCustomer.setActivitionTime(DateUtils.getCurrentDateTime());
        }
        wsCustomer.setDomainName(req.getDomainName());
        wsCustomer.setIpAddress(req.getIpAddress());
        wsCustomer.setProductId(req.getProductId());
        wsCustomer.setLoginName(req.getCustomerName());
        wsCustomer.setPhonePrefix(req.getPhonePrefix());
        if (StringUtils.isNotBlank(req.getEmail()) && StringUtils.isBlank(dbCustomer.getEmail())) {  //邮箱
            String plainEmailNo = this.decrypt(req, req.getEmail());
            wsCustomer.setEmail(plainEmailNo);
            wsCustomer.setEmailMd5(DigestUtils.md5Hex(plainEmailNo));
        }

        // 更新faceId
        WSCustomerFace wsCustomerFace = new WSCustomerFace();
        wsCustomerFace.setLoginName(req.getCustomerName());
        wsCustomerFace.setLastUpdatedBy(req.getOperator());
        wsCustomerFace.setUpdateBranchCode(req.getBranchCode());
        wsCustomerFace.setProductId(req.getProductId());
        updateFaceIdByLocal(wsCustomerFace, req.getFaceId());

        //激活
        if (UserCenterSwitch.getSwitch()) {
            wsCustomer.setCustomerId(dbCustomer.getCustomerId());
            userCenterTemplate.modifyAccount(wsCustomer, Constant.ONE_STR);
        } else {
            wsApiTemplate.modifyAccount(wsCustomer, Constant.ONE_STR);
        }

        //添加截图
        String screenshot = req.getScreenshot();
        if (StringUtils.isNotEmpty(screenshot)) {
            CreateCustomerRemarkReq remarkReq = new CreateCustomerRemarkReq();
            remarkReq.setScreenshot(screenshot);
            remarkReq.setRemarks(req.getScreenshotRemarks());
            remarkReq.setCustomerName(req.getCustomerName());
            remarkReq.setProductId(req.getProductId());
            remarkReq.setLoginName(req.getLoginName());
            remarkReq.setIpAddress(req.getIpAddress());
            createCustomerRemark(remarkReq);
        }

        // 发送激活短信
        //redis 拆分，调研只有发送短信有用，但是短信发送功能已注释，且脱敏对象也不一致，注释此代码
//        Map<String, Integer> hidewaymap = new HashMap<>();
//        hidewaymap.put(SENSITIVE_TYPE.PHONE_NO.getCode(), 3);
//        hidewaymap.put(SENSITIVE_TYPE.EMAIL.getCode(), 3);
//        hidewaymap.put(SENSITIVE_TYPE.MSG_VIBER.getCode(), 3);
//        try {
//            encryptUtil.getHideSensitiveCustomers(dbCustomer, hidewaymap, req.getProductId());
//        } catch (Exception e) {
//            log.error("encryptUtil.getHideSensitiveCustomers");
//        }
        //激活短信 todo 暂时注释 发送短信功能
//        sendActivateAccountSms(wsCustomersSms);
    }

    /**
     * 更新fadeId 图片
     *
     * @param wsCustomerFace
     * @param newFaceId
     */
    private void updateFaceIdByLocal(WSCustomerFace wsCustomerFace, String newFaceId) {
        try {
//            String objectResponse = faceApiTemplate.faceRecognition(awss3Util.s3GetObject(newFaceId));
            String objectResponse = awss3Util.s3GetObject(newFaceId);
            if (objectResponse != null) {
                wsCustomerFace.setLastUpdate(LocalDateTime.now().format(DATE_TIME_FORMATTER));
                wsCustomerFace.setFacePicUrl(Constant.ONE_STR);
                ModifyCustomerFaceResponse res = wsApiTemplate.updateCustomerFace(wsCustomerFace);
                if (null != res.getWSCustomerFace()) {
                    awss3Util.s3PutObject(awss3Util.s3GetObject(newFaceId), wsCustomerFace.getLoginName());
                    awss3Util.s3PutObject(Base64.getDecoder().decode(objectResponse), wsCustomerFace.getLoginName() + "faceFeature");
                }
            } else {
                log.error("updateFaceIdByLocal未检测到人脸，loginName={}", wsCustomerFace.getLoginName());
                throw new BusinessException(ResultEnum.FACE_IMG_NOT_EXIST_ERROR);
            }
        } catch (Exception e) {
            log.error("上传到S3服务失败，loginName={}", wsCustomerFace.getLoginName(), e);
            throw new BusinessException(ResultEnum.UPLOAD_TO_S3_ERROR);
        }
    }

    private WSCustomers getWSCustomerInfo(String productId, String loginName) {
        WSQueryCustomers wsQueryCustomer = new WSQueryCustomers();
        wsQueryCustomer.setProductId(productId);
        wsQueryCustomer.setLoginName(loginName);
        wsQueryCustomer.setCustomerType(Constant.ONE_STR);
        List<WSCustomers>  wsCustomers=wsApiTemplate.queryCustomers(wsQueryCustomer);
        if (wsCustomers != null && !wsCustomers.isEmpty()) {
            return wsCustomers.get(0);
        }
        return null;
    }

    private void createCustomerRemark(CreateCustomerRemarkReq req) {
        WSCustomers wsCustomers;
        if (UserCenterSwitch.getSwitch()) {
            wsCustomers = userCenterTemplate.getSimpleCustomerByLoginName(req.getProductId(), req.getCustomerName());
        } else {
            wsCustomers =  wsApiTemplate.getCustomerByLoginName(req.getProductId(), req.getCustomerName());
        }
        if (Objects.isNull(wsCustomers)) {
            throw new BusinessException(ResultEnum.LOGIN_NAME_NOT_EXIST_ERROR);
        }

        if (StringUtils.equals(Constant.ZERO_STR, wsCustomers.getCustomerType())) {
            throw new BusinessException(ResultEnum.DEPOSIT_TRANS_TRAIL_FORBID_ERROR);
        }

        //黑名单判断
        if (isBlackDisallowed(wsCustomers, Constant.OperationType.DEPOSIT)) {
            throw new BusinessException(ResultEnum.LOGIN_NAME_BLACK_ERROR);
        }
        WSCustomersRemarks wsCustomersRemarks = new WSCustomersRemarks();
        wsCustomersRemarks.setProductId(req.getProductId());
        wsCustomersRemarks.setLoginName(req.getCustomerName());
        wsCustomersRemarks.setCustomerId(wsCustomers.getCustomerId());
        wsCustomersRemarks.setRemarks(req.getRemarks());
        wsCustomersRemarks.setOrderType(Constant.TWO_STR);
        wsCustomersRemarks.setCreatedBy(req.getLoginName());
        wsCustomersRemarks.setIpAddress(req.getIpAddress());

        // 测试环境上传静态图片, 其他环境上传备注照至OSS云存储
        if (isSkipEnvironment(req.getProductId())) {
            wsCustomersRemarks.setScreenshot(UUID.randomUUID().toString());
        } else {
            log.info("备注截图 ：{}", req.getScreenshot());
            // 前端先調用圖片上傳後返回key, 再將key傳回
            wsCustomersRemarks.setScreenshot(req.getScreenshot());
        }
        wsApiTemplate.createCustomerRemark(wsCustomersRemarks);
    }

    /**
     * 判断黑名单用户是否允许做特定操作
     *
     * @param operation 操作类型
     */
    protected boolean isBlackDisallowed(WSCustomers wsCustomer, Constant.OperationType operation) {
        String blackLevels = c66Config.getBlackDepositLevels();
        if (StringUtils.isBlank(blackLevels)) {
            return false;
        }
        if (Splitter.on(",").trimResults().omitEmptyStrings().splitToList(blackLevels).contains(wsCustomer.getDepositLevel())) {
            String disallowedOps = c66Config.getBlackDisallowedOps();
            if (StringUtils.isBlank(disallowedOps)) {
                return false;
            }
            return Splitter.on(",").trimResults().splitToList(disallowedOps).contains(operation.name());
        }
        return false;
    }

    /**
     * 获取kyc请求参数*
     *
     * @param req
     * @return WSKycRequest
     */
    private KycRequest getWSKycRequest(UpdateKycRequestReq req) {
        KycRequest wsKycRequest = new KycRequest();
        wsKycRequest.setId(req.getId());
        wsKycRequest.setProductId(req.getProductId());
        wsKycRequest.setLoginName(req.getLoginName());
        wsKycRequest.setCustomerId(req.getCustomerId());
        wsKycRequest.setUpdateBy(req.getOperator());
        wsKycRequest.setUpdateDate(DateUtils.getCurrentDateTime());
        wsKycRequest.setApprovedDate(DateUtils.getCurrentDateTime());
        wsKycRequest.setApprovedBy(req.getOperator());
        if (StringUtils.isNotBlank(req.getOpenDate())) {
            wsKycRequest.setOpenDate(req.getOpenDate());
        }
        if (StringUtils.isNotBlank(req.getStatus())) {
            wsKycRequest.setStatus(req.getStatus());
        }
        if (StringUtils.isNotBlank(req.getFirstName())) {
            wsKycRequest.setFirstName(req.getFirstName());
        } else {
            throw new BusinessException(ResultEnum.FIRST_NAME_EMPTY_ERROR);
        }
        if (StringUtils.isNotBlank(req.getMiddleName())) {
            wsKycRequest.setMiddleName(req.getMiddleName());
        }
        if (StringUtils.isNotBlank(req.getLastName())) {
            wsKycRequest.setLastName(req.getLastName());
        } else {
            throw new BusinessException(ResultEnum.LAST_NAME_EMPTY_ERROR);
        }
        if (StringUtils.isNotBlank(req.getSex())) {
            wsKycRequest.setSex(req.getSex());
        }
        log.info("px-gw-api  req.getSex()={}-------------------------------------------------------------------------", req.getSex());
        if (StringUtils.isNotBlank(req.getBirthday())) {
            try {
                LocalDate.parse(req.getBirthday());
            } catch (Exception e) {
                throw new BusinessException(ResultEnum.BIRTHDAY_INVALID_ERROR);
            }
            wsKycRequest.setBirthday(req.getBirthday());
        } else {
            throw new BusinessException(ResultEnum.BIRTHDAY_EMPTY_ERROR);
        }
        log.info("px-gw-api  req.getBirthday()={}-------------------------------------------------------------------------", req.getBirthday());
        if (StringUtils.isNotBlank(req.getRemark())) {
            wsKycRequest.setRemark(req.getRemark());
        }
        // kyc 年龄标记 start
        LocalDate birthDate = LocalDate.parse(req.getBirthday());
        // 获取当前日期，用于计算年龄
        LocalDate currentDateTemp = LocalDate.now();
        Period period = Period.between(birthDate, currentDateTemp);

        if (period.getYears() > Constant.KYC_FLAG_AGE_100 || (period.getYears() == Constant.KYC_FLAG_AGE_100 && period.getDays() > 0)) {
            wsKycRequest.setDoubtful(Constant.ONE_STR);
        } else {
            wsKycRequest.setDoubtful(null);
        }
        // kyc 年龄标记 end
        // kyc 重复标记 start 审核通过时标记是否重复
        if (StringUtils.equals(req.getStatus(), Constant.ONE_STR)) {
            // kyc重复标记
            if (checkWSKycRequestRepetition(req)) {
                wsKycRequest.setRepetation(Constant.ONE_STR);
            }
        }
        // kyc 重复标记 end
        return wsKycRequest;
    }

    /**
     * 根据姓名、生日、性别检查是否存在重复数据*
     *
     * @param req -
     * @return true：存在重复kyc信息，false：kyc不重复
     */
    private boolean checkWSKycRequestRepetition(UpdateKycRequestReq req) {
        RiskQueryKycRequest kycRequestQuery = new RiskQueryKycRequest();
        kycRequestQuery.setProductId(req.getProductId());
        kycRequestQuery.setSex(req.getSex());
        kycRequestQuery.setBirthday(req.getBirthday());
        kycRequestQuery.setFirstName(req.getFirstName());
        kycRequestQuery.setMiddleName(req.getMiddleName());
        kycRequestQuery.setLastName(req.getLastName());
        kycRequestQuery.setStatusList("1;");
//        int countKYC = FunctionHelper.doIt(switchFlag, cronFeignTemplate::countKycRequest, wsFeignTemplate::countKycRequest, kycRequestQuery, req.getProductId());
        int countKYC = riskControlApiTemplate.countKycRequest(kycRequestQuery, req.getProductId());
        return countKYC > 0;
    }

    @Override
    public Response uploadPBCInfoBatchNewRisk(MultipartFile files, HttpServletRequest request) {
        try {
            Map<String, String[]> maps = request.getParameterMap();
            Set<String> setKeys = maps.keySet();
            Map<String, String> parameterMap = new HashMap<>();
            for (String string : setKeys) {
                parameterMap.put(string, request.getParameter(string));
            }

            Response resp = new Response<>();
            //执行失败的数据添加到该list集合，然后返回到前端
            String redisCommonKey = this.generateRedisKeyByDate();
            if (files == null) {
                throw new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST_ERROR);

            }
            MultipartFile multipartFile = files;
            if (Objects.isNull(multipartFile)) {
                throw new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST_ERROR);
            }
            String fileSuffix = multipartFile.getOriginalFilename().substring(multipartFile.getOriginalFilename().lastIndexOf("."));
            if (!(".xlsx".equals(fileSuffix) || ".xls".equals(fileSuffix))) {
                throw new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST_ERROR);
            }
            String operator = "";//request.getParameter("operator");
            UserInfoVO userInfoVO = CurrentUserUtil.get();
            if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
                operator = userInfoVO.getUserInfo().getUsername();
            }
            if (StringUtils.isBlank(operator)) {
                throw new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST_ERROR);
            }
            InputStream input = null;
            Workbook book = null;
            try {
                input = multipartFile.getInputStream();
                book = new XSSFWorkbook(input);
            } catch (IOException e) {
                log.error("ERROR_UPLOAD_PBC_INFO_BATCH : getInputStream Something went wrong, The specific information is:{}", e.getMessage());
            } finally {
                if (input != null) {
                    input.close();
                }
            }
            Sheet sheet = book.getSheetAt(0);
            int physicalNumberOfRows = sheet.getPhysicalNumberOfRows();
            if (physicalNumberOfRows <= 1) {
                //行数据少于1行
                throw new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST_ERROR);
            } else if (physicalNumberOfRows > 10001) {
                //行数据不能多于10000行
                throw new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST_ERROR);
            }
            for (int j = 1; j < physicalNumberOfRows; j++) {
                Row row = sheet.getRow(j);// 获得当前行数据
                //提案编号（唯一）
                Cell billNo = row.getCell(1);
                if (billNo == null) {
                    //billNo不能为空
                    throw new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST_ERROR);
                }
            }
            String productId = request.getParameter("productId");
            log.info("{}  productId={}", new Date(), productId);
            if (StringUtils.isBlank(productId)) {
                productId = "C66";
            }
            try {
                //将要批量审核得数据
                List<WSKycSheetRequest> kycSheetList = new ArrayList<>();
                for (int j = 1; j < physicalNumberOfRows; j++) {
                    Row row = sheet.getRow(j);// 获得当前行数据
                    WSKycSheetRequest kycSheet = new WSKycSheetRequest();
                    kycSheet.setBillNo(row.getCell(1).getStringCellValue().replaceAll("\t", ""));  // 有换行去掉换行
                    Cell pbcOperation = row.getCell(17);  // 更新 选择第17列
                    PBCStatusEnum pbcStatusEnum = (pbcOperation == null ? null : PBCStatusEnum.getPbcEnumByStr(pbcOperation.getCellType() == Cell.CELL_TYPE_STRING ? pbcOperation.getStringCellValue().toLowerCase() : null));
                    kycSheet.setPbcStatus(pbcOperation == null ? null : pbcStatusEnum == null ? null : String.valueOf(pbcStatusEnum.getPbcStatus()));
                    // kycSheet.setProductId(productId);
                    kycSheet.setLoginName(row.getCell(2) == null ? null : row.getCell(2).getStringCellValue());
                    Cell idTypeCell = row.getCell(3);
                    /**
                     * 此处有修改 开始
                     */
                    String idType = null;
                    if (idTypeCell != null) {
                        switch (idTypeCell.getCellType()) {
                            case Cell.CELL_TYPE_NUMERIC: // 数字
                                idType = String.valueOf(idTypeCell.getNumericCellValue());
                                break;
                            default:
                                idType = idTypeCell.getStringCellValue();
                        }
                    }
/**
 * 此处有修改 结束
 */
                    kycSheet.setIdType(idType);
                    kycSheet.setIdScan(row.getCell(4) == null ? null : row.getCell(4).getStringCellValue());
                    //kycSheet.setBirthday(row.getCell(6)==null?null:String.valueOf(row.getCell(6).getDateCellValue()));
                    kycSheet.setAddress(row.getCell(8) == null ? null : row.getCell(8).getStringCellValue());
                    // kycSheet.setAssigneeTime(row.getCell(9)==null?null:String.valueOf(row.getCell(9).getDateCellValue()));
                    kycSheet.setAssigneeBy(row.getCell(9) == null ? null : row.getCell(9).getStringCellValue());
                    kycSheet.setAssigneeTime(row.getCell(10) == null ? null : row.getCell(10).getStringCellValue());
                    kycSheet.setCreatedDate(row.getCell(11) == null ? null : row.getCell(11).getStringCellValue());
                    kycSheet.setStatus(row.getCell(12) == null ? null : row.getCell(12).getStringCellValue());
                    kycSheet.setProcessLog(row.getCell(14) == null ? null : row.getCell(14).getStringCellValue());
                    kycSheetList.add(kycSheet);
                }
                BatchModifyPbcRequestResponse res = riskControlApiTemplate.bactchModifyPbcStatus(kycSheetList, productId, operator);
                if (res == null) {
                    return resp;
                } else {
                    int successTotalCount = res.getCount();
                    //如果成功执行得行数少于上传得行数据，则返回执行失败得数据
                    if (successTotalCount < physicalNumberOfRows - 1) {
                        resp.setBody(res.getFailKycSheetList());
                    } else {
                        resp.setBody(res.getCount());
                    }
                }

            } catch (Exception e) {
                log.error("{}   uploadPBCInfoBatch 出异常了. redisCommonKey={}, 异常信息:{}", new Date(), redisCommonKey, e.getMessage());
            }
            return resp;
        } catch (Exception e) {
            log.error("uploadPBCInfoBatchNewRisk error", e);
        }
        return null;
    }

    protected WSUsers getOfficeUser(String productId, String loginName) {
        WSUsers wsUsers = new WSUsers();
        wsUsers.setLoginName(loginName);
        wsUsers.setProductId(productId);
        return wsApiTemplate.userOfficeLogin(wsUsers, "1");
    }

    @Override
    public Response queryCustomerByLoginName(QueryCustomerByLoginNameReq req) throws Exception {
        Response<WsCustomer> response = new Response<>();
        WSQueryCustomers wsQueryCustomer = new WSQueryCustomers();
        wsQueryCustomer.setProductId(req.getProductId());
        wsQueryCustomer.setLoginName(req.getCustomerName());

        // 查詢需要排除掉其他類型賬號, 否則解密會報錯
        wsQueryCustomer.setCustomerType(Constants.FLAG_STR_ONE); // 客户类型,0-试玩,1-真钱,2-合作伙伴,3-代理,4-访客,5-推荐礼金
        WSCustomers wsCustomers = wsApiTemplate.queryCustomer(wsQueryCustomer);
        if (Objects.isNull(wsCustomers)) {
            response.setHead(ErrorCodeEnum.ERROR_ACCOUNT_NOTEXIST.getErrHead());
            return response;
        }

        // 取款查询时 校验用户证件二信息  合并后： 校验证件一就行
        if (StringUtils.equals(req.getQueryFlag(), Constants.BRANCH_CUST_DETAIL_DEPOSIT)) {
            if (StringUtils.isBlank(wsCustomers.getFirstIdScan()) || StringUtils.isBlank(wsCustomers.getFirstIdType())) {
                response.setHead(ErrorCodeEnum.ERROR_BRANCH_SECONDID_NO_EMPTY.getErrHead());
                return response;
            }
        }

        if (isNotStore(req)) {  //是门店端执行数据解析
            WSUsers wsUsers = this.getOfficeUser(req.getProductId(), req.getLoginName());
            if (Objects.isNull(wsUsers)) {
                response.setHead(ErrorCodeEnum.ERROR_ACCESS_DENIED.getErrHead());
                return response;
            }
            Map<String, Integer> hidewaymap = EncryptUtil.getCurrentUserShowStatusByType(wsUsers);
            String productId = req.getProductId();
            encryptUtil.getHideSensitiveCustomers(wsCustomers, hidewaymap, productId);
        }

        WsCustomer rsp = new WsCustomer();
        BeanUtils.copyProperties(wsCustomers, rsp);

        if (StringUtils.isEmpty(rsp.getMessager()))
            rsp.setMessager("");
        if (StringUtils.isEmpty(rsp.getViber()))
            rsp.setViber("");
        // real name
        String realName = StringUtils.EMPTY;
        if (StringUtils.isNoneEmpty(wsCustomers.getFirstName())) {
            realName = wsCustomers.getFirstName();
        }
        if (StringUtils.isNoneEmpty(wsCustomers.getMiddleName())) {
            realName = realName + " " + wsCustomers.getMiddleName();
        }
        if (StringUtils.isNoneEmpty(wsCustomers.getLastName())) {
            realName = realName + " " + wsCustomers.getLastName();
        }
        rsp.setRealName(realName);
        // 测试环境上传静态图片, 其他环境上传证件照至OSS云存储
        if (isSkipEnvironment(req.getProductId())) {
            rsp.setFirstIdScan(AESCrypt.encryptCBC(DEMO_IMAGE, "20230103aes00001", "aes0000120230103"));
            rsp.setSecondIdScan(AESCrypt.encryptCBC(DEMO_IMAGE, "20230103aes00001", "aes0000120230103"));
            rsp.setReserve3(AESCrypt.encryptCBC(DEMO_IMAGE, "20230103aes00001", "aes0000120230103"));
        } else {
            if (StringUtils.isNotBlank(wsCustomers.getFirstIdScan())) {
                // 处理https脏数据
                if (wsCustomers.getFirstIdScan().startsWith("https:")) {
                    String firstIdScan = wsCustomers.getFirstIdScan();
                    int i = firstIdScan.indexOf("?", firstIdScan.lastIndexOf("/") + 1);
                    if (i > -1) {
                        String subIdScan = firstIdScan.substring(firstIdScan.lastIndexOf("/") + 1, i);
                        rsp.setFirstImageKey(subIdScan);
                        rsp.setFirstIdScan(subIdScan.startsWith("http") ? subIdScan : subIdScan.contains("_md5") ? awss3Util.s3GetTxtUrl(subIdScan) : awss3Util.s3GetUrl(subIdScan));
                        rsp.setFirstIdScanV2(AESCrypt.encryptCBC(subIdScan.startsWith("http") ? subIdScan : subIdScan.contains("_md5") ? awss3Util.s3GetTxtUrl(subIdScan) : awss3Util.s3GetUrl(subIdScan), "20230103aes00001", "aes0000120230103"));
                    } else {
                        rsp.setFirstIdScan(firstIdScan.startsWith("http") ? firstIdScan : awss3Util.s3GetUrl(firstIdScan));
                        rsp.setFirstIdScanV2(AESCrypt.encryptCBC(firstIdScan.startsWith("http") ? firstIdScan : firstIdScan.contains("_md5") ? awss3Util.s3GetTxtUrl(firstIdScan) : awss3Util.s3GetUrl(firstIdScan), "20230103aes00001", "aes0000120230103"));
                        rsp.setFirstImageKey(firstIdScan);
                    }


                } else {
                    if (wsCustomers.getFirstIdScan().startsWith("{")) {
                        JSONObject jsonObject = JSONObject.parseObject(wsCustomers.getFirstIdScan());
                        String fidScan = jsonObject.getString("imageKey");
                        rsp.setFirstIdScan(fidScan.startsWith("http") ? fidScan : fidScan.contains("_md5") ? awss3Util.s3GetTxtUrl(fidScan) : awss3Util.s3GetUrl(fidScan));
                        rsp.setFirstIdScanV2(AESCrypt.encryptCBC(fidScan.startsWith("http") ? fidScan : fidScan.contains("_md5") ? awss3Util.s3GetTxtUrl(fidScan) : awss3Util.s3GetUrl(fidScan), "20230103aes00001", "aes0000120230103"));
                        rsp.setFirstImageKey(fidScan);
                    } else {
                        rsp.setFirstIdScan(wsCustomers.getFirstIdScan().startsWith("http") ? wsCustomers.getFirstIdScan() : wsCustomers.getFirstIdScan().contains("_md5") ? awss3Util.s3GetTxtUrl(wsCustomers.getFirstIdScan()) : awss3Util.s3GetUrl(wsCustomers.getFirstIdScan()));
                        rsp.setFirstIdScanV2(AESCrypt.encryptCBC(wsCustomers.getFirstIdScan().startsWith("http") ? wsCustomers.getFirstIdScan() : wsCustomers.getFirstIdScan().contains("_md5") ? awss3Util.s3GetTxtUrl(wsCustomers.getFirstIdScan()) : awss3Util.s3GetUrl(wsCustomers.getFirstIdScan()), "20230103aes00001", "aes0000120230103"));
                        rsp.setFirstImageKey(wsCustomers.getFirstIdScan());
                    }
                }
            }
            if (StringUtils.isNotBlank(wsCustomers.getSecondIdScan())) {
                // 处理https脏数据
                if (wsCustomers.getSecondIdScan().startsWith("https:")) {
                    String secondIdScan = wsCustomers.getSecondIdScan();
                    int i = secondIdScan.indexOf("?", secondIdScan.lastIndexOf("/") + 1);
                    if (i > -1) {
                        String subIdScan = secondIdScan.substring(secondIdScan.lastIndexOf("/") + 1, i);
                        rsp.setSecondIdScan(subIdScan.startsWith("http") ? subIdScan : subIdScan.contains("_md5") ? awss3Util.s3GetTxtUrl(subIdScan) : awss3Util.s3GetUrl(subIdScan));
                        rsp.setSecondIdScanV2(AESCrypt.encryptCBC(subIdScan.startsWith("http") ? subIdScan : subIdScan.contains("_md5") ? awss3Util.s3GetTxtUrl(subIdScan) : awss3Util.s3GetUrl(subIdScan), "20230103aes00001", "aes0000120230103"));
                        rsp.setSecondImageKey(subIdScan);
                    } else {
                        rsp.setSecondIdScan(secondIdScan.startsWith("http") ? secondIdScan : secondIdScan.contains("_md5") ? awss3Util.s3GetTxtUrl(secondIdScan) : awss3Util.s3GetUrl(secondIdScan));
                        rsp.setSecondIdScanV2(AESCrypt.encryptCBC(secondIdScan.startsWith("http") ? secondIdScan : secondIdScan.contains("_md5") ? awss3Util.s3GetTxtUrl(secondIdScan) : awss3Util.s3GetUrl(secondIdScan), "20230103aes00001", "aes0000120230103"));
                        rsp.setSecondImageKey(secondIdScan);
                    }

                } else {
                    rsp.setSecondIdScan(wsCustomers.getSecondIdScan().startsWith("http") ? wsCustomers.getSecondIdScan() : wsCustomers.getSecondIdScan().contains("_md5") ? awss3Util.s3GetTxtUrl(wsCustomers.getSecondIdScan()) : awss3Util.s3GetUrl(wsCustomers.getSecondIdScan()));
                    rsp.setSecondIdScanV2(AESCrypt.encryptCBC(wsCustomers.getSecondIdScan().startsWith("http") ? wsCustomers.getSecondIdScan() : wsCustomers.getSecondIdScan().contains("_md5") ? awss3Util.s3GetTxtUrl(wsCustomers.getSecondIdScan()) : awss3Util.s3GetUrl(wsCustomers.getSecondIdScan()), "20230103aes00001", "aes0000120230103"));
                    rsp.setSecondImageKey(wsCustomers.getSecondIdScan());
                }
            }
            if (StringUtils.isNotBlank(wsCustomers.getReserve3())) {
                rsp.setReserve3(wsCustomers.getReserve3().startsWith("http") ? wsCustomers.getReserve3() : wsCustomers.getReserve3().contains("_md5") ? awss3Util.s3GetTxtUrl(wsCustomers.getReserve3()) : awss3Util.s3GetUrl(wsCustomers.getReserve3()));
            }
        }

        if (StringUtils.isBlank(wsCustomers.getMiddleName())) {
            // 前端要返回空字串
            rsp.setMiddleName("");
        }

        rsp.setMarginSwitch(wsCustomers.getMarginSwitch());
        rsp.setRealNameMd5(null);
        rsp.setMobileNoMd5(null);
        rsp.setPhoneMd5(null);
        rsp.setPwd(null);
        rsp.setOldpwd(null);
        rsp.setCashCredit(StringUtils.isBlank(wsCustomers.getCredit()) ? new BigDecimal("0") : new BigDecimal(wsCustomers.getCredit()));
        rsp.setGameCredit(StringUtils.isBlank(wsCustomers.getGameCredit()) ? new BigDecimal("0") : new BigDecimal(wsCustomers.getGameCredit()));
        rsp.setCustomerLevel(Optional.ofNullable(wsCustomers.getClubLevel()).orElse(0).toString());
        //添加返回会员晋级优惠状态
        WSCustomersExt ext = wsCustomers.getWsCustomersExt();
        if (ext != null) rsp.setRaiseLevelFlag(ext.getRaiseLevelFlag());
        // 获取玩家银行卡列表
        WSQueryCustomersBank wsQueryCustomersBank = new WSQueryCustomersBank();
        wsQueryCustomersBank.setLoginName(wsQueryCustomer.getLoginName());
        wsQueryCustomersBank.setProductId(wsQueryCustomer.getProductId());
        wsQueryCustomersBank.setDeleteFlag("0");
        wsQueryCustomersBank.setFlag("0;1;9");
        wsQueryCustomersBank.setOrder("priority_order");
        log.info("查询用户{}的银行账号catalog:{}", wsQueryCustomersBank.getLoginName(), wsQueryCustomersBank.getCatalog());
        wsQueryCustomersBank.setCustomerId(wsCustomers.getCustomerId());
        List<WSCustomersBank> banks = wsApiTemplate.queryCustomerBanks(wsQueryCustomersBank);
        if (banks == null || banks.isEmpty()) {
            rsp.setBankAccountInfos(new ArrayList<>());
        } else {
            PHPDESEncrypt accountNoDecrypt = PHPDESEncrypt.getNewInstance(req.getProductId(), "07");
            List<BankAccountInfo> bankAccountInfos = banks.stream().map(bank -> {
                BankAccountInfo info = new BankAccountInfo();
                info.setBankName(bank.getBankName());
                try {
                    info.setBankAccountNo(accountNoDecrypt.decrypt(bank.getBankAccountNo()));
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                return info;
            }).collect(Collectors.toList());
            rsp.setBankAccountInfos(bankAccountInfos);
        }

        // 拉取人脸图片url
        try {
            rsp.setOriginal(awss3Util.s3GetUrl(rsp.getLoginName()));
        } catch (Exception e) {
            log.error("captchaList S3读取失败", e);
        }
        // 兼容旧数据
        if (StringUtils.isBlank(wsCustomers.getSocialMediaValue())) {
            if (StringUtils.isNotBlank(wsCustomers.getMessager())) {
                rsp.setSocialMediaType("Messenger");
                rsp.setSocialMediaValue(wsCustomers.getMessager());
            } else if (StringUtils.isNotBlank(wsCustomers.getViber())) {
                rsp.setSocialMediaType("Viber");
                rsp.setSocialMediaValue(wsCustomers.getViber());
            }
        } else {
            rsp.setSocialMediaValue(PHPDESEncrypt.getNewInstance(wsCustomers.getProductId(), "03").decrypt(wsCustomers.getSocialMediaValue()));
        }
        response.setBody(rsp);
        return response;
    }

    @Override
    public Response<CustomerRiskLabelRsp> queryRiskLabel(QueryCustomersReq req) {
        Response<CustomerRiskLabelRsp> response = new Response<>();
        if (StringUtils.isBlank(req.getCustomerId())) {
            response.setHead(ErrorCodeEnum.ERROR_ACCOUNT_EMPTY.getErrHead());
            return response;
        }
        CustomerRiskLabelRsp riskLabel = riskLabelRelationshipService.getRiskLabelDetail(Long.parseLong(req.getCustomerId()));
        response.setBody(riskLabel);
        return response;
    }

    @Override
    public Boolean modifyRiskLabel(UpdateCustomerRiskLabelReq req) {
        return riskControlApiTemplate.updateCustomerRiskLabel(req);
    }


    /**
     * 校验kyc id和type是否存在
     *
     * @param idType 证件类型
     * @param idNo   证件号码
     * @return true
     */
    private boolean validKycIdAndTypeExist(Integer idType, String idNo) {
        try {
            String key = String.format(RedisConstant.KYC_VALID_EXISTS, idType, idNo);
            Boolean bool = RedisUtils.get(key, Boolean.class);
            if (Objects.nonNull(bool)) {
                return bool;
            }
            LambdaQueryWrapper<TKycDeduplicate> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(TKycDeduplicate::getIdType, idType);
            queryWrapper.eq(TKycDeduplicate::getIdNo, idNo);
            boolean exists = kycDeduplicateMapper.exists(queryWrapper);
            if (exists) {
                //缓存时长5小时
                RedisUtils.set(key, true, 5 * 60 * 60L);
            }
            return exists;
        } catch (Exception e) {
            log.error("valid kyc exists error idType:{},idNo:{}", idType, idNo, e);
        }
        return false;
    }

    /**
     * 查询kyc汇总数量
     * @param req
     * @return
     */
    @Override
    public int queryKycRequestCount(RiskQueryKycRequest req) {
        return riskControlApiTemplate.countKycPbcRequest(req, req.getProductId());
    }
}