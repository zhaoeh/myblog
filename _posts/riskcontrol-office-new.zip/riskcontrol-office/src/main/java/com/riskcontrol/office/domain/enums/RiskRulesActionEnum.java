package com.riskcontrol.office.domain.enums;

public enum RiskRulesActionEnum {
    ZERO((byte) 0),
    ONE((byte) 1);

    private final byte value;

    public byte getValue() {
        return value;
    }

    RiskRulesActionEnum(byte value) {
        this.value = value;
    }
}
