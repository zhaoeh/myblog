package com.riskcontrol.office.domain.rsp;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

/**
 * @description: 黑名单操作历史明细分页查询返回
 * @author: Yu.Guo
 * @create: 2024-11-15
 **/
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class BlcackOpertionLogListPageQueryRsp {
    @Schema(description = "黑名单操作历史主键")
    @JsonProperty("id")
    private BigInteger id;

    @Schema(description = "操作人")
    @JsonProperty("operator")
    private String operator;

    @Schema(description = "ip地址")
    @JsonProperty("allowRecord")
    private String allowRecord;

    @Schema(description = "规则校验类型（0：ip ; 1：设备指纹；）")
    @JsonProperty("allowType")
    private Integer allowType;

    @Schema(description = "名单规则（0：白名单；1：黑名单）")
    @JsonProperty("allowRule")
    private Integer allowRule;


    @Schema(description = "可用状态（0：可用；1：禁用）")
    @JsonProperty("isEnable")
    private Integer isEnable;

    @Schema(description = "备注")
    @JsonProperty("remark")
    private String remark;

    @Schema(description = "创建时间")
    @ApiModelProperty("createDate")
    private String createDate;

}
