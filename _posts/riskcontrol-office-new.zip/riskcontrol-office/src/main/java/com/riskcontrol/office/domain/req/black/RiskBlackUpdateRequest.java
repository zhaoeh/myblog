package com.riskcontrol.office.domain.req.black;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;


/**
 * @author Heng.zhang
 */
@Data
@ApiModel(value = "风控黑名单更新请求", description = "风控黑名单更新请求")
public class RiskBlackUpdateRequest {

    @ApiModelProperty("id")
    private BigInteger id;

    @ApiModelProperty("status")
    @Max(value =1, message = "The status can only be filled in 0 or 1 (0-invalid, 1-in effect)")
    @Min(value = 0, message = "The status can only be filled in 0 or 1 (0-invalid, 1-in effect)")
    @NotNull(message = "status cannot be empty")
    private Integer status;

    @ApiModelProperty("最后一次最后修改的account")
    private String dataModifier;
}