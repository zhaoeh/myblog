package com.riskcontrol.office.domain.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import javax.validation.constraints.NotBlank;

@Data
@Schema(description = "PBC数据请求对象")
public class PbcCrawlerImportByFullNameReq {

    @Schema(description = "名字")
    @NotBlank(message = "fullName cannot be null")
    private String fullName;

}
