package com.riskcontrol.office.domain.rsp.ekyc;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

/**
 * @description: ekyc查询用户状态响应
 * @author: ErHu.Zhao
 * @create: 2024-10-07
 **/
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class EkycRequestQueryResponse {
    @ApiModelProperty("ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    @ApiModelProperty(value = "账单号")
    private String billNo;

    @ApiModelProperty(value = "账号")
    private String loginName;

    @ApiModelProperty(value = "渠道")
    private String channel;

    @ApiModelProperty(value = "注册时间")
    private String createDate;

    @ApiModelProperty(value = "证件类型")
    private Integer idType;

    @ApiModelProperty(value = "证件ID")
    private String idNo;

    @ApiModelProperty(value = "自拍照")
    private String faceImg;

    @ApiModelProperty("证件证明照")
    private String idFrontImg;

    @ApiModelProperty("证件背面照")
    private String idBackImg;

    @ApiModelProperty(value = "自拍照url")
    private String faceUrl;
    @ApiModelProperty("证件证明照url")
    private String idFrontUrl;

    @ApiModelProperty("证件背面照url")
    private String idBackUrl;

    @ApiModelProperty(value = "首名")
    private String firstName;

    @ApiModelProperty(value = "中间名")
    private String middleName;

    @ApiModelProperty(value = "尾名")
    private String lastName;

    @ApiModelProperty(value = "性别")
    private String sex;

    @ApiModelProperty(value = "产品")
    private String tenant;

    @ApiModelProperty(value = "现居地址")
    private String presentAddress;

    @ApiModelProperty(value = "出生地")
    private String birthPlace;

    @ApiModelProperty(value = "常住地（永久居住地）")
    private String address;

    @ApiModelProperty(value = "生日")
    private String birthday;

    @ApiModelProperty(value = "eKYC状态 -1待提交 0 待审核，1 通过，2 拒绝，3手动拒绝")
    private Integer status;

    @ApiModelProperty(value = "更新时间")
    private String updateDate;

    @ApiModelProperty(value = "更新人")
    private String updateBy;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "拒绝原因")
    private String rejectReason;

    @ApiModelProperty(value = "转人工审核原因")
    private Integer manualReason;

    @ApiModelProperty(value = "第三方业务id")
    private String ekycTransactionId;

    @ApiModelProperty(value = "第三方获取结果时间")
    private String ekycResultDate;

    @ApiModelProperty(value = "第三方返回结果")
    private String ekycResult;

    @ApiModelProperty(value = "审批时间")
    private String approvedDate;

    @ApiModelProperty(value = "审核人")
    private String approvedBy;
}
