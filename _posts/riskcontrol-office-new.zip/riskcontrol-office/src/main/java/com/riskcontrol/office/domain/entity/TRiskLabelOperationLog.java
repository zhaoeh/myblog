package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 风控用户标签历史操作记录表
 */
@ApiModel(description = "风控用户标签历史操作记录表")
@Data
@TableName(value = "t_risk_label_operation_log")
public class TRiskLabelOperationLog extends BaseEntity {

    @TableField(value = "operator")
    @ApiModelProperty("操作人")
    private String operator;

    @TableField(value = "op_mode")
    @ApiModelProperty("操作类型 0:导入模式 1:手动更新")
    private Long opMode;

    @TableField(value = "total_no")
    @ApiModelProperty("操作的账号量")
    private Long totalNo;

    @TableField(value = "success_no")
    @ApiModelProperty("成功数量")
    private String successNo;

    @TableField(value = "failure_no")
    @ApiModelProperty("失败数量")
    private String failureNo;

    @TableField(value = "remark")
    @ApiModelProperty("备注")
    private String remark;

    @TableField(value = "create_date")
    @ApiModelProperty("创建时间")
    private String createDate;

    @TableField(value = "finish_date")
    @ApiModelProperty("完成时间")
    private String finishDate;

    /**
     * 状态 0:执行中 1:执行完成 2:执行失败
     */
    @TableField(value = "status")
    @ApiModelProperty("状态")
    private Integer status;

    private static final long serialVersionUID = 1L;
}