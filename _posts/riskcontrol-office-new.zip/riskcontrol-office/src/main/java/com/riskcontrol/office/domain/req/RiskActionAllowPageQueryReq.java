package com.riskcontrol.office.domain.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.riskcontrol.common.entity.request.BasePageRequest;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Pattern;


@Data
@Schema(description = "白名分页查询请求对象")
public class RiskActionAllowPageQueryReq extends BasePageRequest {

    @Schema(description = "更新时间的起始时间")
    @JsonProperty("dateBegin")
    private String dateBegin;

    @ApiModelProperty("更新时间的结束时间")
    @JsonProperty("dateEnd")
    private String dateEnd;

    @Schema(description = "可用状态（0：可用；1：禁用）")
    @JsonProperty("isEnable")
    private Integer isEnable;

    @Schema(description = "ip")
    @JsonProperty("allowRecord")
    @Pattern(regexp = "^(?:[0-9]{1,3}\\.){3}[0-9]{1,3}$", message = "IP地址格式不正确或包含多条IP地址")
    private String allowRecord;

    @Schema(description = "规则校验类型（0：ip ; 1：设备指纹；）")
    @JsonProperty("allowType")
    private Integer allowType;

    @Schema(description = "名单规则（0：白名单；1：黑名单）")
    @JsonProperty("allowRule")
    private Integer allowRule;



}
