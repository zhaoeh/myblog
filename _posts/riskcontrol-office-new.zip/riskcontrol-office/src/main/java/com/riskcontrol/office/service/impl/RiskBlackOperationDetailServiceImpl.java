package com.riskcontrol.office.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cm.util.common.Constants;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.enums.SENSITIVE_TYPE;
import com.riskcontrol.common.utils.PHPDESEncrypt;
import com.riskcontrol.common.utils.SensitiveUtil;
import com.riskcontrol.office.common.constants.ConstantVars;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.domain.entity.TRiskBlackOperationAccountDetail;
import com.riskcontrol.office.domain.entity.TRiskBlackOperationDetail;
import com.riskcontrol.office.domain.req.black.RiskBlackOperationDetailRequest;
import com.riskcontrol.office.domain.rsp.black.RiskBlackOperationAccountDetailReRsp;
import com.riskcontrol.office.domain.rsp.black.RiskBlackOperationDetailImRsp;
import com.riskcontrol.office.mapper.RiskBlackOperationAccountDetailMapper;
import com.riskcontrol.office.mapper.RiskBlackOperationDetailMapper;
import com.riskcontrol.office.service.RiskBlackOperationAccountDetailService;
import com.riskcontrol.office.service.RiskBlackOperationDetailService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Heng.zhang
 */
@Service
@Slf4j
public class RiskBlackOperationDetailServiceImpl extends BaseServiceImpl<RiskBlackOperationDetailMapper, TRiskBlackOperationDetail> implements RiskBlackOperationDetailService {

    @Autowired
    private RiskBlackOperationAccountDetailMapper accountDetailMapper;

    @Autowired
    @Lazy
    private RiskBlackOperationAccountDetailService accountDetailService;

    @Override
    public PageModel<RiskBlackOperationDetailImRsp> getOperationDetailImPageList(RiskBlackOperationDetailRequest req) {
        LambdaQueryWrapper<TRiskBlackOperationDetail> wrapper = buildWrapper(req);
        wrapper.select(TRiskBlackOperationDetail::getId,
                TRiskBlackOperationDetail::getBlackId,
                TRiskBlackOperationDetail::getLoginName,
                TRiskBlackOperationDetail::getFirstName,
                TRiskBlackOperationDetail::getMiddleName,
                TRiskBlackOperationDetail::getLastName,
                TRiskBlackOperationDetail::getBirthday,
                TRiskBlackOperationDetail::getRegisterIp,
                TRiskBlackOperationDetail::getLoginIp,
                TRiskBlackOperationDetail::getIdType,
                TRiskBlackOperationDetail::getIdNo,
                TRiskBlackOperationDetail::getPhoneNumber,
                TRiskBlackOperationDetail::getEmail,
                TRiskBlackOperationDetail::getBankAccountNo,
                TRiskBlackOperationDetail::getStatus,
                TRiskBlackOperationDetail::getOperationStatus,
                TRiskBlackOperationDetail::getCreateDate);
        wrapper.orderByDesc(TRiskBlackOperationDetail::getCreateDate);
        Page<TRiskBlackOperationDetail> page = pageByWrapper(req, wrapper);
        if (CollUtil.isEmpty(page.getRecords())) {
            return new PageModel<>();
        }
        PHPDESEncrypt phoneEncrypt = PHPDESEncrypt.getNewInstance(Constants.C66, SENSITIVE_TYPE.PHONE_NO.getEncryptCode());
        PHPDESEncrypt bankCardNoEncrypt = PHPDESEncrypt.getNewInstance(Constants.C66, SENSITIVE_TYPE.BANK_NO.getEncryptCode());

        List<RiskBlackOperationDetailImRsp> pageList = page.getRecords().stream().map(x -> {
            RiskBlackOperationDetailImRsp riskBlackOperationDetailRsp = new RiskBlackOperationDetailImRsp();
            BeanUtil.copyProperties(x, riskBlackOperationDetailRsp);
            try {
                if(StringUtils.isNotBlank(riskBlackOperationDetailRsp.getPhoneNumber())){
                    riskBlackOperationDetailRsp.setPhoneNumber(SensitiveUtil.halfHideSensitive(SENSITIVE_TYPE.PHONE_NO.getDefaultHideType(), phoneEncrypt.decrypt(riskBlackOperationDetailRsp.getPhoneNumber())));
                }
                if(StringUtils.isNotBlank(riskBlackOperationDetailRsp.getBankAccountNo())){
                    StringBuilder sb = new StringBuilder();
                    String[] bankCardNos = riskBlackOperationDetailRsp.getBankAccountNo().split(ConstantVars.SEPARATOR_COMMA);
                    if (bankCardNos.length > 0) {
                        for (String bankCardNo : bankCardNos) {
                            sb.append(SensitiveUtil.halfHideSensitive(SENSITIVE_TYPE.BANK_NO.getDefaultHideType(), bankCardNoEncrypt.decrypt(bankCardNo)));
                            sb.append(ConstantVars.SEPARATOR_COMMA);
                        }
                        riskBlackOperationDetailRsp.setBankAccountNo(sb.substring(0, sb.length() - 1));
                    }
                }
            } catch (Exception e) {
                log.error("解密手机/银行卡号异常", e);
            }
            return riskBlackOperationDetailRsp;
        }).toList();
        PageModel<RiskBlackOperationDetailImRsp> pageResult = new PageModel<>();
        pageResult.setData(pageList);
        pageResult.setPageNo((int) page.getCurrent());
        pageResult.setPageSize((int) page.getSize());
        pageResult.setTotalRow((int) page.getTotal());
        pageResult.setTotalPage((int) page.getPages());
        return pageResult;
    }

    @Override
    public PageModel<RiskBlackOperationAccountDetailReRsp> getOperationDetailRePageList(RiskBlackOperationDetailRequest req) {
        LambdaQueryWrapper<TRiskBlackOperationDetail> wrapper = buildWrapper(req);
        wrapper.select(TRiskBlackOperationDetail::getId,
                TRiskBlackOperationDetail::getBlackId,
                TRiskBlackOperationDetail::getFirstName,
                TRiskBlackOperationDetail::getMiddleName,
                TRiskBlackOperationDetail::getLastName,
                TRiskBlackOperationDetail::getOperationStatus,
                TRiskBlackOperationDetail::getBirthday);
        wrapper.orderByDesc(TRiskBlackOperationDetail::getCreateDate);
        Page<TRiskBlackOperationDetail> page = pageByWrapper(req, wrapper);
        List<TRiskBlackOperationDetail> records = page.getRecords();
        if (CollUtil.isEmpty(records)) {
            return new PageModel<>();
        }
        List<BigInteger> list = records.stream().map(TRiskBlackOperationDetail::getId).toList();
        List<TRiskBlackOperationAccountDetail> accountLists = accountDetailService.getAccountList(list);
        Map<BigInteger, List<TRiskBlackOperationAccountDetail>> detailMap = accountLists.stream().collect(Collectors.groupingBy(TRiskBlackOperationAccountDetail::getLogDetailId));


        List<RiskBlackOperationAccountDetailReRsp> pageList = records.stream().map(x -> {
            RiskBlackOperationAccountDetailReRsp riskBlackOperationAccountDetailReRsp = new RiskBlackOperationAccountDetailReRsp();
            BeanUtil.copyProperties(x, riskBlackOperationAccountDetailReRsp);
            List<TRiskBlackOperationAccountDetail> accountList = detailMap.get(x.getId());
            if (accountList == null) {
                riskBlackOperationAccountDetailReRsp.setAllLoginName("");
                riskBlackOperationAccountDetailReRsp.setLoginNameCount(0);
            } else {
                riskBlackOperationAccountDetailReRsp.setAllLoginName(accountList.stream().map(TRiskBlackOperationAccountDetail::getLoginName).collect(Collectors.joining(",")));
                riskBlackOperationAccountDetailReRsp.setLoginNameCount(accountList.size());
            }
            return riskBlackOperationAccountDetailReRsp;
        }).toList();
        PageModel<RiskBlackOperationAccountDetailReRsp> pageResult = new PageModel<>();
        pageResult.setData(pageList);
        pageResult.setPageNo((int) page.getCurrent());
        pageResult.setPageSize((int) page.getSize());
        pageResult.setTotalRow((int) page.getTotal());
        pageResult.setTotalPage((int) page.getPages());
        return pageResult;
    }

    @Override
    public TRiskBlackOperationDetail getOperationDetailReInfo(BigInteger id) {
        LambdaQueryWrapper<TRiskBlackOperationDetail> wrapper = new LambdaQueryWrapper<>();
        wrapper.select(TRiskBlackOperationDetail::getId,
                TRiskBlackOperationDetail::getBlackId,
                TRiskBlackOperationDetail::getFirstName,
                TRiskBlackOperationDetail::getMiddleName,
                TRiskBlackOperationDetail::getLastName,
                TRiskBlackOperationDetail::getBirthday);
        wrapper.eq(TRiskBlackOperationDetail::getId, id);
        wrapper.orderByDesc(TRiskBlackOperationDetail::getCreateDate);
        TRiskBlackOperationDetail detail = getOne(wrapper);
        return Optional.ofNullable(detail).orElse(new TRiskBlackOperationDetail());
    }


}
