package com.riskcontrol.office.controller;

import cn.hutool.core.lang.Assert;
import com.digiplus.oms.aspect.annotation.PreAuthorize;
import com.riskcontrol.common.annotation.MultipartFileValidate;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.enums.EkycChannelEnum;
import com.riskcontrol.common.enums.EkycManualReasonEnum;
import com.riskcontrol.common.enums.EkycStatusEnum;
import com.riskcontrol.office.annotation.EnableOperationLog;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.common.constants.Constants;
import com.riskcontrol.office.domain.enums.OpTypeEnum;
import com.riskcontrol.office.domain.req.ekyc.*;
import com.riskcontrol.office.domain.rsp.ekyc.EkycQueryResponse;
import com.riskcontrol.office.domain.rsp.ekyc.EkycRequestInfoResponse;
import com.riskcontrol.office.domain.rsp.ekyc.EkycRequestQueryResponse;
import com.riskcontrol.office.service.EkycRequestService;
import com.riskcontrol.office.service.EkycService;
import com.riskcontrol.office.service.TSysConstantsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @program: riskcontrol-office
 * @description: ekyc 前端控制器
 */
@RestController
@Tag(name = "ekyc")
@SecurityRequirement(name = HttpHeaders.AUTHORIZATION)
@RequestMapping("/office")
@Validated
public class EkycController {

    @Autowired
    private EkycRequestService ekycRequestService;
    @Autowired
    private EkycService ekycService;

    @Resource
    private TSysConstantsService constantsService;


    @PreAuthorize("riskManage_eKycUsers_query,riskManage_eKycUsers_export")
    @PostMapping("/ekyc/queryList")
    @Operation(tags ="ekyc" ,summary = "ekyc用户列表查询")
    public R<PageModel<EkycQueryResponse>> pageEkycList(@Validated @RequestBody EkycQueryRequest req) {
        return R.ok(ekycService.pageEkycList(req));
    }

    @PreAuthorize("riskManage_ekyc_query,riskManage_ekyc_export")
    @PostMapping("/ekycRequest/queryList")
    @Operation(tags ="ekyc" ,summary = "ekyc申请列表查询")
    public R<PageModel<EkycRequestQueryResponse>> pageEkycRequestList(@Validated @RequestBody EkycRequestQueryRequest req) {
        return R.ok(ekycRequestService.pageEkycRequestList(req));
    }

    @PreAuthorize("riskManage_ekyc_view")
    @GetMapping(value = "/ekycRequest/detail/{id}")
    @Operation(tags ="ekyc" ,summary = "获取详情页")
    public R<EkycRequestInfoResponse> queryRiskLabel(@PathVariable @NotNull BigInteger id){
        return R.ok(ekycRequestService.getEkycRequestDetail(id));
    }

    @PreAuthorize("riskManage_ekyc_create")
    @PostMapping("/ekycRequest/create")
    @Operation(tags ="ekyc" ,summary = "创建提案")
    @EnableOperationLog(menuName = "风控配置", subMenuName = "风控EKYC", opLog = "创建", opLogType = OpTypeEnum.CREATE)
    public R<Boolean> create(@Validated @RequestBody EkycRequestCreateRequest createRequest) {
        return R.ok(ekycRequestService.ekycRequestCreate(createRequest));
    }

    //    @PreAuthorize("")
//    @PostMapping("/ekycRequest/update")
//    @Operation(tags ="ekyc" ,summary = "更新提案")
//    @EnableOperationLog(menuName = "风控配置", subMenuName = "风控EKYC", opLog = "创建", opLogType = OpTypeEnum.UPDATE)
//    public R<Boolean> update(@Validated @RequestBody EkycRequestUpdateRequest updateRequest) {
//        return R.ok(ekycRequestService.ekycRequestUpdate(updateRequest));
//    }
    @PreAuthorize("riskManage_ekyc_approval")
    @PostMapping("/ekycRequest/approved")
    @Operation(tags ="ekyc" ,summary = "审核提案")
    @EnableOperationLog(menuName = "风控配置", subMenuName = "风控EKYC", opLog = "创建", opLogType = OpTypeEnum.APPROVAL)
    public R<Boolean> approved(@Validated @RequestBody EkycRequestApprovedRequest approvedRequest) {
        return R.ok(ekycRequestService.ekycRequestApproved(approvedRequest));
    }

    @GetMapping("/ekyc/getChannelList")
    @Operation(tags ="ekyc" ,summary = "ekyc获取渠道接口")
    public R<List<EkycChannelEnum.EkycChannel>> getChannelList() {
        return R.ok(EkycChannelEnum.getAllChannel());
    }

    @GetMapping("/ekycRequest/getManualReasonList")
    @Operation(tags ="ekyc" ,summary = "ekyc获取人工原因接口")
    public R<List<EkycManualReasonEnum.EkycManualReason>> getManualReasonList() {
        return R.ok(EkycManualReasonEnum.getAllManualReason());
    }

    @GetMapping("/ekyc/getStatusList/{type}")
    @Operation(tags ="ekyc" ,summary = "ekyc获取当前状态接口")
    public R<List<EkycStatusEnum.EkycStatus>> getStatusList(@PathVariable @NotNull Long type) {
        Assert.checkBetween(type, 1, 2, "The value must be between {} and {}.", 1, 2);
        return R.ok(Objects.equals(1L,type)? EkycStatusEnum.getAllEkycStatus() :EkycStatusEnum.getAllEkycReqStatus());
    }

    @GetMapping("/ekycRequest/getTopCount")
    @Operation(tags ="ekyc" ,summary = "ekyc查询顶部计数器接口")
    public R<Long> getTopCount() {
        return R.ok(ekycRequestService.getTopCount());
    }

    @GetMapping("/ekycRequest/getRejectReason")
    @Operation(tags ="ekyc" ,summary = "ekyc获取拒绝原因类型")
    public R<List<Map<String, String>>> getRejectReason() {
        return R.ok(constantsService.queryConstantListByType(Constants.EKYC_REJECT_REASON));
    }

    /**
     * ekyc上传接口*
     *
     * @param file
     * @return
     */
    @PostMapping("/ekyc/upload")
    @Operation(tags = "ekyc", summary = "ekyc上传文件")
    public R<Map<String, String>> upload(@RequestParam(value = "file", required = false)
                                         @NotNull(message = "file cannot be null")
                                         @MultipartFileValidate(
                                                 extensions = {"JPG", "JPEG", "PNG", "BMP"},
                                                 ignoreExtensionsCase = true,
                                                 maxSize = 2621440,
                                                 message = "file extension must be {target}")
                                                 MultipartFile file) {
        return R.ok(ekycRequestService.upload(file));
    }
}

