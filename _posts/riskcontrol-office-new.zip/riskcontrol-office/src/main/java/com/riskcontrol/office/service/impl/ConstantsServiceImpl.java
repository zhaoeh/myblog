package com.riskcontrol.office.service.impl;

import com.cn.schema.products.WSProductConstants;
import com.cn.schema.products.WSQueryProductConstants;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.api.RiskConstantsRsp;
import com.riskcontrol.common.service.WsFeignTemplate;
import com.riskcontrol.office.domain.constans.req.QueryConstantsListReq;
import com.riskcontrol.office.service.IConstantsService;
import com.riskcontrol.office.template.RiskControlApiTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Service
public class ConstantsServiceImpl implements IConstantsService {
    private static final Logger logger = LoggerFactory.getLogger(ConstantsServiceImpl.class);
    @Resource
    private WsFeignTemplate wsTemplate;
    @Resource
    private RiskControlApiTemplate riskControlApiTemplate;

    @Override
    public Response queryList(HttpServletRequest request, QueryConstantsListReq req) {
        Response<PageModel<WSProductConstants>> rsp = new Response<>();
        WSQueryProductConstants query = new WSQueryProductConstants();
        BeanUtils.copyProperties(req, query);
        if(req.getPageNum()==0){
            query.setPageNum(req.getPageNo());
        }
        int count = wsTemplate.queryProductConstantsCount(req.getProductId(), query);
        PageModel<WSProductConstants> page = new PageModel<>(count, req.getPageNum(), req.getPageSize());
        page.setData(wsTemplate.queryProductConstantsList(req.getProductId(), query));
        rsp.setBody(page);
        //this.customerService.pushVerificationCode(req.getProductId());
        return rsp;
    }

}
