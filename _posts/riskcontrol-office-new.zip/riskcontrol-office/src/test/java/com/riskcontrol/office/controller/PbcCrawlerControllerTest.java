package com.riskcontrol.office.controller;

import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.riskcontrol.common.entity.request.PbcCrawlerUpdateStatusReq;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.enums.PbcBannedEnum;
import com.riskcontrol.common.enums.PbcSourceEnum;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.entity.TPbcCrawlerResultNew;
import com.riskcontrol.office.domain.req.PbcCrawlerPageRequest;
import com.riskcontrol.office.mapper.TPbcCrawlerResultNewMapper;
import org.apache.hc.core5.net.URIBuilder;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.test.annotation.DirtiesContext;
import javax.annotation.Resource;
import java.math.BigInteger;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DirtiesContext
public class PbcCrawlerControllerTest {

    @Autowired
    private TestRestTemplate testRestTemplate;

    @Resource
    private TPbcCrawlerResultNewMapper pbcCrawlerResultNewMapper;

    @Test
    void queryList() throws URISyntaxException, JsonProcessingException {
        var url = new URIBuilder("/office/pbcCrawler/queryList").build();
        var body = new PbcCrawlerPageRequest();
        body.setPageNum(1);
        body.setPageSize(10);
        var response = this.testRestTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(body), new ParameterizedTypeReference<R<PageModel<TPbcCrawlerResultNew>>>() {
        });
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(0, response.getBody().getCode());
        assertEquals(1, response.getBody().getData().getPageNo());
        assertEquals(10, response.getBody().getData().getPageSize());
        assertTrue(response.getBody().getData().getData().size() > 0);
        var result = response.getBody().getData().getData().get(0);
        assertNotNull(result.getId());
    }

    @Test
    void updateStatus() throws URISyntaxException, JsonProcessingException {
        // 获取一条数据的id
        BigInteger id;
        {
            var pbcCrawlerResultNewEntity = new TPbcCrawlerResultNew();
            pbcCrawlerResultNewEntity.setCreateDate(DateUtils.getCurrentDateTime());
            pbcCrawlerResultNewEntity.setUpdateDate(DateUtils.getCurrentDateTime());
            pbcCrawlerResultNewEntity.setFirstName(UUID.randomUUID().toString());
            pbcCrawlerResultNewEntity.setMiddleName("");
            pbcCrawlerResultNewEntity.setLastName("Tom");
            pbcCrawlerResultNewEntity.setBirthDate("1990-01-01");
            pbcCrawlerResultNewEntity.setSource(PbcSourceEnum.GOVT.getName());
            pbcCrawlerResultNewEntity.setGuestExtId(UUID.randomUUID().toString());
            pbcCrawlerResultNewEntity.setIsBanned(1);
            pbcCrawlerResultNewEntity.setDateCreated(DateUtils.getCurrentDateTime());
            pbcCrawlerResultNewEntity.setCreateBy("system");
            pbcCrawlerResultNewEntity.setUpdateBy("system");
            UserInfoVO userInfoVO = CurrentUserUtil.get();
            if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
                pbcCrawlerResultNewEntity.setCreateBy(userInfoVO.getUserInfo().getUsername());
                pbcCrawlerResultNewEntity.setUpdateBy(userInfoVO.getUserInfo().getUsername());
            }
            this.pbcCrawlerResultNewMapper.insert(pbcCrawlerResultNewEntity);
            id = pbcCrawlerResultNewEntity.getId();
        }
        // 解除/禁用PBC接口
        {
            var url = new URIBuilder("/office/pbcCrawler/updateStatus").build();
            var body = new PbcCrawlerUpdateStatusReq();
            body.setId(new BigInteger(String.valueOf(id)));
            body.setIsBanned(0);
            var response = this.testRestTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(body), new ParameterizedTypeReference<R<Boolean>>() {
            });
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(0, response.getBody().getCode());
            var result = response.getBody().getData();
            assertTrue(result);
            assertEquals(0, this.pbcCrawlerResultNewMapper.selectById(id).getIsBanned());
        }
    }

    @Test
    void getPbcBannedList() throws URISyntaxException, JsonProcessingException {
        var url = new URIBuilder("/office/pbcCrawler/getPbcBannedList").build();
        var response = this.testRestTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(null), new ParameterizedTypeReference<R<List<PbcBannedEnum.PbcBanned>>>() {
        });
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(0, response.getBody().getCode());
        assertEquals(2, response.getBody().getData().size());
    }

    @Test
    void getPbcSourceList() throws URISyntaxException, JsonProcessingException {
        var url = new URIBuilder("/office/pbcCrawler/getPbcSourceList").build();
        var response = this.testRestTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(null), new ParameterizedTypeReference<R<List<PbcSourceEnum.PbcSource>>>() {
        });
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(0, response.getBody().getCode());
        assertEquals(3, response.getBody().getData().size());
    }

}

