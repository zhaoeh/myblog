package com.riskcontrol.office.controller;

import com.riskcontrol.office.BaseTest;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.HashSet;
import java.util.Set;

import static com.riskcontrol.office.utils.AuthorityUtils.permissions;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;


/**
 * @author: sanji
 * @desc: TODO
 * @date: 2023/11/14 14:15
 */
@AutoConfigureMockMvc
@ActiveProfiles("dev")
public class BaseControllerTest extends BaseTest {


    @Autowired
    private WebApplicationContext context;

    protected MockMvc mockMvc;
    protected Authentication authentication;

    @BeforeEach
    void setUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.context).apply(springSecurity()).build();

        Set<GrantedAuthority> authorities = new HashSet<>();
        permissions.forEach(e -> authorities.add(new SimpleGrantedAuthority(e)));
        //todo
//        BPUser user = new BPUser(1L, 1L, "admin", "123456", "C66", "13333333333",
//                true, true, true, true, authorities);
//        this.authentication = new TestingAuthenticationToken(user, user.getPassword(), "ADMIN");
    }
}
