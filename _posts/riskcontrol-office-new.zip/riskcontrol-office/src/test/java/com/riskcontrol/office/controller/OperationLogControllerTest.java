package com.riskcontrol.office.controller;

import com.alibaba.fastjson.JSONObject;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.authentication;
import static org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers.authenticated;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2023/11/14 14:15
 */
public class OperationLogControllerTest extends BaseControllerTest{

    @Test
    @DisplayName("测试queryList接口")
    void queryList() throws Exception {
        JSONObject object = new JSONObject();
        object.put("beginDate","2023-11-01 00:00:00");
        object.put("endDate","2024-11-31 00:00:00");
        object.put("subMenuName","常量列表");
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/operationLog/queryList")
                        .with(authentication(authentication))
                        .content(object.toJSONString())
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data.totalRow", Matchers.greaterThanOrEqualTo(0)))
                .andReturn();
    }
}
