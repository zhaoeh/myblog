package com.riskcontrol.office;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.customers.WSCustomers;
import com.riskcontrol.common.client.MessageApiFeign;
import com.riskcontrol.common.config.UserCenterSwitch;
import com.riskcontrol.common.entity.request.message.PushContentReq;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.service.UserCenterTemplate;
import com.riskcontrol.common.service.WsFeignTemplate;
import com.riskcontrol.common.utils.PHPDESEncrypt;
import com.riskcontrol.office.common.constants.ConstantVars;
import com.riskcontrol.office.config.NacosConfig;
import com.riskcontrol.office.domain.enums.RejectReasonEnums;
import com.riskcontrol.office.template.SmsApiTemplate;
import com.riskcontrol.office.util.Convert;
import com.ws.SmsContent;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Objects;
import java.util.Optional;

@SpringBootTest(classes = {RiskControlApiApplication.class}, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
//@Transactional
//@Rollback
@ActiveProfiles("dev")
public class BaseTest {


    @Resource
    private WsFeignTemplate wsTemplate;
    @Resource
    private UserCenterTemplate userCenterTemplate;
    @Resource
    private SmsApiTemplate smsApiTemplate;
    @Resource
    private MessageApiFeign messageApiFeign;
    @Value("${C66.push.exchange:exchange_template_job_message}")
    private String pushExchange;
    @Value("${C66.push.routing.key:C66.routing.template.job.message.queue}")
    private String pushRoutingKey;

    @Test
    public void testMerchantMonitor() throws Exception {

    }
}
