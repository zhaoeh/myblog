package com.riskcontrol.office.controller;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.common.entity.request.api.*;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.authentication;
import static org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers.authenticated;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/03/15 14:15
 */
public class PhoneNumberBlacklistControllerTest extends BaseControllerTest{

    @Test
    @DisplayName("测试page接口")
    void queryList() throws Exception {
        PhoneNumberBlacklistPageRequest request = new PhoneNumberBlacklistPageRequest();
        request.setStatus(1);
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/office/phoneNumberBlacklist/page")
                        .with(authentication(authentication))
                        .content(JSONObject.toJSONString(request))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data.totalRow", Matchers.greaterThanOrEqualTo(0)))
                .andReturn();
    }

    @Test
    @DisplayName("测试list接口")
    void list() throws Exception {
        PhoneNumberBlacklistPageRequest request = new PhoneNumberBlacklistPageRequest();
        request.setStatus(1);
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/office/phoneNumberBlacklist/list")
                        .with(authentication(authentication))
                        .content(JSONObject.toJSONString(request))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.notNullValue()))
                .andReturn();
    }

    @Test
    @DisplayName("测试one接口")
    void one() throws Exception {
        PhoneNumberBlacklistGetOneRequest request = new PhoneNumberBlacklistGetOneRequest();
        request.setPhoneMd5("7004d5592d392afaa1bb37d2acec0ac3");
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/office/phoneNumberBlacklist/one")
                        .with(authentication(authentication))
                        .content(JSONObject.toJSONString(request))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.notNullValue()))
                .andReturn();
    }
    @Test
    @DisplayName("测试create接口")
    void create() throws Exception {
        PhoneNumberBlacklistCreateRequest request = new PhoneNumberBlacklistCreateRequest();
        request.setPhone("92531231321dsd");
        request.setStatus(1);
        request.setHistory("1231,32");
        request.setDataModifier("admin");
        request.setProductId("C66");
        request.setPhoneMd5("7004d5592d392121aa1bb37d2acec0ac3");
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/office/phoneNumberBlacklist/create")
                        .with(authentication(authentication))
                        .content(JSONObject.toJSONString(request))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }

    @Test
    @DisplayName("测试updateHistory接口")
    void updateHistory() throws Exception {
        PhoneNumberBlacklistUpdateHistoryRequest request = new PhoneNumberBlacklistUpdateHistoryRequest();
        request.setHistory("1231,3232,212");
        request.setDataModifier("admin");
        request.setPhoneMd5("7004d5592d392afaa1bb37d2acec0ac3");
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/office/phoneNumberBlacklist/updateHistory")
                        .with(authentication(authentication))
                        .content(JSONObject.toJSONString(request))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }

    @Test
    @DisplayName("测试updateStatus接口")
    void updateStatus() throws Exception {
        PhoneNumberBlacklistUpdateStatusRequest request = new PhoneNumberBlacklistUpdateStatusRequest();
        request.setStatus(0);
        request.setDataModifier("admin");
        request.setPhoneMd5("7004d5592d392afaa1bb37d2acec0ac3");
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/office/phoneNumberBlacklist/updateStatus")
                        .with(authentication(authentication))
                        .content(JSONObject.toJSONString(request))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }

    @Test
    @DisplayName("测试coolingDownPeriod接口")
    void coolingDownPeriod() throws Exception {
        PhoneCoolingDownPeriodRequest request = new PhoneCoolingDownPeriodRequest();
        request.setOldPhoneMd5("7004d5592d392afaa1bb37d2acec0ac3");
        request.setCustomerId("1231");
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/office/phoneNumberBlacklist/coolingDownPeriod")
                        .with(authentication(authentication))
                        .content(JSONObject.toJSONString(request))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.notNullValue()))
                .andReturn();
    }
}
