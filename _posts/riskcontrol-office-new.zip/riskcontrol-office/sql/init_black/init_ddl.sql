CREATE TABLE `t_risk_black` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `login_name` varchar(50)  NOT NULL DEFAULT '' COMMENT '账号',
    `first_name` varchar(64) NOT NULL COMMENT '名',
    `middle_name` varchar(64)  NOT NULL DEFAULT '' COMMENT '中间名',
    `last_name` varchar(64) NOT NULL COMMENT '姓',
    `birthday` varchar(50) NOT NULL DEFAULT '' COMMENT '生日',
    `register_ip` varchar(45)  NOT NULL DEFAULT '' COMMENT '注册IP',
    `login_ip` varchar(45)  NOT NULL DEFAULT '' COMMENT '登陆IP',
    `id_type` tinyint NOT NULL DEFAULT '0' COMMENT '证件类型',
    `id_no` varchar(64) NOT NULL DEFAULT '' COMMENT '证件ID',
    `phone_number` varchar(50)  NOT NULL DEFAULT '' COMMENT '电话号码',
    `phone_md5` varchar(50)  NOT NULL DEFAULT '' COMMENT '电话md5',
    `email` varchar(500)  NOT NULL DEFAULT '' COMMENT '邮箱',
    `bank_account_no` varchar(350)  NOT NULL DEFAULT '' COMMENT '银行卡号',
    `source` tinyint(1) NOT NULL DEFAULT '0' COMMENT '黑名单来源：0：人工、1：关联匹配、2：pagcor黑名单',
    `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态 1：有效状态 0：无效状态',
    `remark` varchar(500)  NOT NULL DEFAULT '' COMMENT '备注',
    `create_by` varchar(128)  NOT NULL COMMENT '创建人',
    `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_by` varchar(128)  NOT NULL DEFAULT '' COMMENT '更新人',
    `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_login_name` (`login_name`),
    KEY `idx_full_name_birthday` (`first_name`,`middle_name`,`last_name`,`birthday`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4  COMMENT='风控用户黑名单';

CREATE TABLE `t_risk_black_operation_log` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `operator` varchar(128)  NOT NULL DEFAULT '' COMMENT '操作人',
    `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态 0:执行中 1:执行完成 2:执行失败',
    `op_mode` tinyint(1) NOT NULL DEFAULT '0' COMMENT '操作类型 0:导入模式 1:关联模式 2:手动更新',
    `total_no` INT NOT NULL DEFAULT 0 COMMENT '操作的账号量',
    `success_no` INT NOT NULL DEFAULT 0 COMMENT '成功数量',
    `failure_no` INT NOT NULL DEFAULT 0 COMMENT '失败数量',
    `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `finish_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '完成时间',
    `remark` varchar(200)  NOT NULL DEFAULT '' COMMENT '备注',
    PRIMARY KEY (`id`),
    KEY `idx_create_date` (`create_date`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4  COMMENT='风控用户黑名单历史操作记录表';

CREATE TABLE `t_risk_black_operation_log_account_detail` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `log_detail_id` varchar(50) NOT NULL COMMENT '操作日志明细表id',
    `login_name` varchar(50) NOT NULL DEFAULT '' COMMENT '账号',
    `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    KEY `idx_log_detail_id` (`log_detail_id`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4  COMMENT='黑名单历史操作记录明细的关联账户表';

CREATE TABLE `t_risk_black_operation_log_detail` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `black_id` varchar(50) NOT NULL COMMENT '操作日志主表id',
    `login_name` varchar(50)  NOT NULL DEFAULT '' COMMENT '账号',
    `first_name` varchar(64)  NOT NULL DEFAULT '' COMMENT '名',
    `middle_name` varchar(64)  NOT NULL DEFAULT '' COMMENT '中间名',
    `last_name` varchar(64)  NOT NULL COMMENT '姓',
    `birthday` varchar(50) NOT NULL DEFAULT '' COMMENT '生日',
    `register_ip` varchar(45)  NOT NULL DEFAULT '' COMMENT '注册IP',
    `login_ip` varchar(45)  NOT NULL DEFAULT '' COMMENT '登陆IP',
    `id_type` tinyint NOT NULL DEFAULT '0' COMMENT '证件类型',
    `id_no` varchar(50)  NOT NULL DEFAULT '' COMMENT '证件ID',
    `phone_number` varchar(50)  NOT NULL DEFAULT '' COMMENT '电话号码',
    `email` varchar(500)  NOT NULL DEFAULT '' COMMENT '邮箱',
    `bank_account_no` varchar(350)  NOT NULL DEFAULT '' COMMENT '银行卡号',
    `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态 1：有效状态 0：无效状态',
    `operation_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '账户匹配状态 1：合法 0：非法',
    `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    KEY `idx_black_id` (`black_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='风控用户黑名单历史操作记录明细表';
