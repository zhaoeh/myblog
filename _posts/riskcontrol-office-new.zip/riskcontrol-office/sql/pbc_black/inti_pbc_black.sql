CREATE TABLE `t_pbc_crawler_result_new` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `first_name` varchar(64)  NOT NULL COMMENT '名字',
    `middle_name` varchar(64)  NOT NULL DEFAULT '' COMMENT '中间名',
    `last_name` varchar(64)  NOT NULL COMMENT '姓',
    `birth_date` varchar(12)  NOT NULL COMMENT '生日',
    `guest_ext_id` varchar(64)  NOT NULL COMMENT 'pogcor ID',
    `is_banned` tinyint NOT NULL COMMENT '禁用状态（0解除；1禁用）',
    `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
    `date_created` datetime DEFAULT NULL COMMENT 'pogcor 创建时间',
    `source` varchar(12)  NOT NULL DEFAULT '' COMMENT 'pogcor禁用来源:GOVT:政府官员，GEL：从业者；Banned：自主申请',
    `create_by` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'system' COMMENT '创建人',
    `update_by` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '更新人',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_guestid` (`guest_ext_id`),
    KEY `idx_name_brith_status` (`first_name`,`middle_name`,`last_name`,`birth_date`,`is_banned`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4  COMMENT='pagcor 黑名单表';