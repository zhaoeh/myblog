ALTER TABLE `t_ekyc_request`
    MODIFY COLUMN `manual_reason` tinyint NOT NULL DEFAULT -1 COMMENT '转人工审核原因(0:其他原因;1:账号重复使用证件信息;2:识别信息修改;3:客服提交;4相同人脸,-1未转人工)';