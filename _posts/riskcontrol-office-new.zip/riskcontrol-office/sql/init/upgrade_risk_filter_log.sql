-- 更新null值为0
DELIMITER $$
CREATE PROCEDURE `update_filter_log`()
BEGIN
	declare minId BIGINT;
	declare maxId BIGINT DEFAULT 0;
	declare flag BLOB DEFAULT true;
	while flag DO
		-- 查询批次更新id最小和最大值
        select min(t.id),max(t.id)INTO minId, maxId from(select id from t_risk_filter_log where id> maxId and retry_num is null order by id asc limit 2000) t;
        select CONCAT(flag);
        if minId = maxId or minId is null or maxId is null then set flag = false; ELSE set flag = true; end if;
        select CONCAT(flag);
        update t_risk_filter_log t set retry_num=0 where t.id >= minId and t.id <= maxId and retry_num is null;
    end while;
END$$
DELIMITER ;
--执行存储过程
call update_filter_log();
-- after call delete
DROP PROCEDURE IF EXISTS `update_filter_log`;
-- 执行修改语句
ALTER TABLE `t_risk_filter_log`
    MODIFY COLUMN `filter_type` varchar(10)  NOT NULL COMMENT '拦截类型',
    MODIFY COLUMN `status` tinyint NOT NULL DEFAULT 0 COMMENT '拦截状态 0初始 1已放行 2待审核 3已拦截',
    MODIFY COLUMN `risk_rule_action` varchar(200)  NOT NULL COMMENT '风控决策',
    MODIFY COLUMN `filter_reason` varchar(2500) NULL DEFAULT NULL COMMENT '拦截原因',
    MODIFY COLUMN `notify_status` tinyint NOT NULL DEFAULT 0 COMMENT '通知状态 0未通知 1已通知',
    MODIFY COLUMN `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    MODIFY COLUMN `retry_num` int NOT NULL DEFAULT 0 COMMENT '重试次数';

