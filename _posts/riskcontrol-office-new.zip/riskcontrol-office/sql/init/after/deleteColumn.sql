--兼容历史版本，升级完之后移除字段
ALTER TABLE `risk`.`t_risk_constants` DROP COLUMN `p_type`;