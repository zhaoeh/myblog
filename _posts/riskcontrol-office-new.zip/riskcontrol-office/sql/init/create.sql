CREATE TABLE `t_sys_constants` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `product_id` varchar(64) DEFAULT NULL COMMENT '所属产品',
    `s_key` varchar(30) DEFAULT NULL COMMENT '常量key',
    `s_value` varchar(255) DEFAULT NULL COMMENT '常量值',
    `s_type` varchar(20) DEFAULT NULL COMMENT '类型',
    `remarks` varchar(255) DEFAULT NULL COMMENT '描述',
    `is_enable` tinyint NOT NULL DEFAULT '0' COMMENT '标志:0-未启用；1-已启用',
    `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '是否删除：0-否 ；1-是',
    `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
    `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_by` varchar(64) DEFAULT NULL COMMENT '最后修改人',
    `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_type_key` (`s_type`,`s_key`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COMMENT='风控系统常量表';

CREATE TABLE `t_operation_log` (
    `id` bigint NOT NULL AUTO_INCREMENT COMMENT '序号',
    `product_id` varchar(10) DEFAULT NULL,
    `menu_name` varchar(25) NOT NULL DEFAULT '' COMMENT '父菜单名称',
    `sub_menu_name` varchar(25) NOT NULL DEFAULT '' COMMENT '子菜单名称',
    `op_type` tinyint NOT NULL DEFAULT '0' COMMENT '操作类型(0:未知操作,1:创建,2:修改,3:删除,4:发布,5:撤销,6:配置,7:复制,8:维护,9:启用,10:禁用）',
    `op_by` varchar(15) NOT NULL DEFAULT '' COMMENT '操作人',
    `op_log` varchar(64) NOT NULL COMMENT '操作日志',
    `op_ip` varchar(64) NOT NULL DEFAULT '' COMMENT '请求ip',
    `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '操作时间',
    `return_Str` varchar(2550) NOT NULL COMMENT '返回结果',
    `request_Str` varchar(2550) NOT NULL COMMENT '请求参数',
    PRIMARY KEY (`id`),
    KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='操作日志表';

CREATE TABLE `t_label_rule_relationship` (
   `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
   `rule_action` varchar(128) NOT NULL COMMENT '风控规则',
   `label_id` bigint NOT NULL COMMENT '标签id',
   `label_key` varchar(255) NOT NULL COMMENT '标签key',
   `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态 0-未启用；1-已启用',
   `remark` varchar(128) NOT NULL COMMENT '描述',
   `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
   `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
   `update_by` varchar(64) DEFAULT NULL COMMENT '最后修改人',
   `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
   PRIMARY KEY (`id`),
   UNIQUE KEY `uk_label_rule` (`rule_action`,`label_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4  COMMENT='标签-规则绑定表';

CREATE TABLE `t_risk_filter_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '拦截id',
  `filter_type` varchar(10) DEFAULT NULL COMMENT '拦截类型',
  `status` tinyint DEFAULT NULL COMMENT '拦截状态 0初始 1已放行 2待审核 3已拦截',
  `risk_rule_action` varchar(200)  DEFAULT NULL COMMENT '风控决策',
  `filter_reason` varchar(200)  DEFAULT NULL COMMENT '拦截原因',
  `source` varchar(20)  DEFAULT NULL COMMENT '拦截来源',
  `notify_status` tinyint DEFAULT NULL COMMENT '通知状态 0未通知 1已通知',
  `audit_time` datetime DEFAULT NULL COMMENT '审核时间',
  `auditor` varchar(62)  DEFAULT NULL COMMENT '审核人',
  `complete_time` datetime DEFAULT NULL COMMENT '通知完成时间',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `error_msg` varchar(255)  DEFAULT NULL COMMENT '异常信息',
  `request_json` varchar(2550)  COMMENT '拦截对象',
  `request_id` varchar(60)  NOT  NULL COMMENT '请求id',
  `retry_num` int DEFAULT NULL COMMENT '重试次数',
  PRIMARY KEY (`id`),
  KEY `idx_create_time` (`create_time`),
  KEY `idx_request_id` (`request_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='风控拦截日志表';