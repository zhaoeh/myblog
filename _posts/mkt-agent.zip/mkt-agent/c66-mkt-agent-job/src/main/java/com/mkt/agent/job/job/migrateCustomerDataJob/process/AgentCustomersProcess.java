package com.mkt.agent.job.job.migrateCustomerDataJob.process;

import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.jobapi.requests.AgentContractBindRequest;
import com.mkt.agent.common.entity.api.jobapi.requests.AgentCustomersTestRequest;
import com.mkt.agent.common.entity.api.jobapi.requests.CustomerLayerTestRequest;
import com.mkt.agent.common.entity.api.jobapi.responses.CustomerLayerResponse;
import com.mkt.agent.common.enums.AgentTypeEnum;
import com.mkt.agent.job.migration.MigrationConfig;
import com.mkt.agent.job.service.api.AgentContractBindService;
import com.mkt.agent.job.service.api.AgentService;
import com.mkt.agent.job.service.api.CustomerLayerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Map;

@Component
@Slf4j
@Transactional
public class AgentCustomersProcess {

    @Autowired
    private AgentService agentService;

    @Autowired
    private CustomerLayerService customerLayerService;

    @Autowired
    private AgentContractBindService agentContractBindService;

    @Resource
    private MigrationConfig migrationConfig;

    @Transactional
    public void processData(CustomerLayerResponse customerLayerResponse, Map<String, Long> contractMap, Map<String, String> contractPercentDetailMap, String initPercentDetailJson) {
        log.info("begin to process data,agent is :{}",customerLayerResponse.toString());
        Integer agentLevel = customerLayerService.getAgentLevelByLoginNameTest(customerLayerResponse.getLoginName());
        log.info("The agent:{} agent level is :{}",customerLayerResponse.getLoginName(),agentLevel);
        CustomerLayerTestRequest customerLayerTestRequest = new CustomerLayerTestRequest();
        customerLayerTestRequest.setLoginName(customerLayerResponse.getLoginName());
        customerLayerTestRequest.setUpdateBy(Constants.CREATED_BY_SYSTEM);
        // 层级小于等于5，新增代理并绑定佣金方案
        if (agentLevel <= 5) {
            log.info("The agent's level less than 5");
            AgentCustomersTestRequest agentCustomersTestRequest = new AgentCustomersTestRequest();
            agentCustomersTestRequest.setCustomersId(customerLayerResponse.getCustomerId());
            agentCustomersTestRequest.setLoginName(customerLayerResponse.getLoginName());
            agentCustomersTestRequest.setParentName(customerLayerResponse.getParentLoginName());
            agentCustomersTestRequest.setAgentLevel(agentLevel);
            agentCustomersTestRequest.setParentId(customerLayerResponse.getParentId());
            agentCustomersTestRequest.setProductId(Constants.C66);
            agentCustomersTestRequest.setIsEnable(1);
            agentCustomersTestRequest.setIsDeleted(0);
            agentCustomersTestRequest.setSiteId(customerLayerResponse.getSiteId());
            agentCustomersTestRequest.setRemarks(customerLayerResponse.getRemarks());
            agentCustomersTestRequest.setCreateBy(Constants.CREATED_BY_SYSTEM);
            agentCustomersTestRequest.setUpdateBy(Constants.CREATED_BY_SYSTEM);
            AgentContractBindRequest bindReq = new AgentContractBindRequest();
            bindReq.setLoginName(customerLayerResponse.getLoginName());
            // 无下级代理且父级代理为acc66，判定为普通代理
            Boolean hasSubAgent = customerLayerService.hasDevAgentTest(customerLayerResponse.getLoginName());
            if (!hasSubAgent && StringUtils.equals(customerLayerResponse.getParentLoginName(), BaseConstants.C66_ADMIN)) {
                log.info("The agent is general agent");
                agentCustomersTestRequest.setAgentType(AgentTypeEnum.GENERAL_LINE.getIndex());
                bindReq.setCommissionContractId(contractMap.get(migrationConfig.getGeneralContract()));
                if (agentLevel == 1) {
                    bindReq.setPercentageDetails(contractPercentDetailMap.get(migrationConfig.getGeneralContract()));
                } else {
                    bindReq.setPercentageDetails(initPercentDetailJson);
                }
            } else {
                log.info("The agent is professional agent");
                if (agentLevel == 1) {
                    bindReq.setPercentageDetails(contractPercentDetailMap.get(migrationConfig.getProfessionalContract()));
                } else {
                    bindReq.setPercentageDetails(initPercentDetailJson);
                }
                agentCustomersTestRequest.setAgentType(AgentTypeEnum.PROFESSIONAL_LINE.getIndex());
                bindReq.setCommissionContractId(contractMap.get(migrationConfig.getProfessionalContract()));
            }

            bindReq.setCreateBy(Constants.CREATED_BY_SYSTEM);
            // 绑定佣金方案
            Long tAgentContractBindId = agentContractBindService.insertAgentContractBindTest(bindReq);
            agentCustomersTestRequest.setCommissionContractBindId(tAgentContractBindId);
            // 发展层级
            Integer devLevel = customerLayerService.getDevLevelByLoginNameTest(customerLayerResponse.getLoginName());
            log.info("The development level is :{}",devLevel);
            if (1 == agentLevel && devLevel > 3) {
                agentCustomersTestRequest.setDevelopableLevel(4);
            } else if (2 == agentLevel && devLevel > 2) {
                agentCustomersTestRequest.setDevelopableLevel(3);
            } else if (3 == agentLevel && devLevel > 1) {
                agentCustomersTestRequest.setDevelopableLevel(2);
            } else if (4 == agentLevel && devLevel > 0) {
                agentCustomersTestRequest.setDevelopableLevel(1);
            } else if (5 == agentLevel) {
                agentCustomersTestRequest.setDevelopableLevel(0);
            } else {
                agentCustomersTestRequest.setDevelopableLevel(devLevel);
            }
            log.info("Insert agent customers!");
            agentService.insertAgentCustomersTest(agentCustomersTestRequest);
            log.info("Insert agent customers successfully!");

        } else {
            log.info("The agent level is more than 5!");
            // 更新t_customer_layer表flag=1 ,customer_type=1
            customerLayerService.updateFlagAndCustomerTypeTest(customerLayerTestRequest);
        }

    }

    @Transactional
    public void processDataForCheck(CustomerLayerResponse customerLayerResponse, Map<String, Long> contractMap, Map<String, String> contractPercentDetailMap, String initPercentDetailJson) {
        log.info("begin to process data,agent is :{}",customerLayerResponse.toString());
        Integer agentLevel = customerLayerService.getAgentLevelByLoginNameTest(customerLayerResponse.getLoginName());
        log.info("The agent:{} agent level is :{}",customerLayerResponse.getLoginName(),agentLevel);
        CustomerLayerTestRequest customerLayerTestRequest = new CustomerLayerTestRequest();
        customerLayerTestRequest.setLoginName(customerLayerResponse.getLoginName());
        customerLayerTestRequest.setUpdateBy(Constants.CREATED_BY_SYSTEM);
        // 层级小于等于5，新增代理并绑定佣金方案
        if (agentLevel <= 5) {
            log.info("The agent's level less than 5");
            AgentCustomersTestRequest agentCustomersTestRequest = new AgentCustomersTestRequest();
            agentCustomersTestRequest.setCustomersId(customerLayerResponse.getCustomerId());
            agentCustomersTestRequest.setLoginName(customerLayerResponse.getLoginName());
            agentCustomersTestRequest.setParentName(customerLayerResponse.getParentLoginName());
            agentCustomersTestRequest.setAgentLevel(agentLevel);
            agentCustomersTestRequest.setParentId(customerLayerResponse.getParentId());
            agentCustomersTestRequest.setProductId(Constants.C66);
            agentCustomersTestRequest.setIsEnable(1);
            agentCustomersTestRequest.setIsDeleted(0);
            agentCustomersTestRequest.setSiteId(customerLayerResponse.getSiteId());
            agentCustomersTestRequest.setRemarks(customerLayerResponse.getRemarks());
            agentCustomersTestRequest.setCreateBy(Constants.CREATED_BY_SYSTEM);
            agentCustomersTestRequest.setUpdateBy(Constants.CREATED_BY_SYSTEM);
            // 无下级代理且父级代理为acc66，判定为普通代理
            Boolean hasSubAgent = customerLayerService.hasDevAgentTest(customerLayerResponse.getLoginName());
            if (!hasSubAgent && StringUtils.equals(customerLayerResponse.getParentLoginName(), BaseConstants.C66_ADMIN)) {
                log.info("The agent is general agent");
                agentCustomersTestRequest.setAgentType(AgentTypeEnum.GENERAL_LINE.getIndex());
            } else {
                log.info("The agent is professional agent");

                agentCustomersTestRequest.setAgentType(AgentTypeEnum.PROFESSIONAL_LINE.getIndex());
            }
            agentCustomersTestRequest.setCommissionContractBindId(1L);
            // 发展层级
            Integer devLevel = customerLayerService.getDevLevelByLoginNameTest(customerLayerResponse.getLoginName());
            log.info("The development level is :{}",devLevel);
            if (1 == agentLevel && devLevel > 3) {
                agentCustomersTestRequest.setDevelopableLevel(4);
            } else if (2 == agentLevel && devLevel > 2) {
                agentCustomersTestRequest.setDevelopableLevel(3);
            } else if (3 == agentLevel && devLevel > 1) {
                agentCustomersTestRequest.setDevelopableLevel(2);
            } else if (4 == agentLevel && devLevel > 0) {
                agentCustomersTestRequest.setDevelopableLevel(1);
            } else if (5 == agentLevel) {
                agentCustomersTestRequest.setDevelopableLevel(0);
            } else {
                agentCustomersTestRequest.setDevelopableLevel(devLevel);
            }
            log.info("Insert agent customers!");
            agentService.insertAgentCustomersTestForCheck(agentCustomersTestRequest);
            log.info("Insert agent customers successfully!");

        } else {
            log.info("The agent level is more than 5!");
            // 更新t_customer_layer表flag=1 ,customer_type=1
            customerLayerService.updateFlagAndCustomerTypeTest(customerLayerTestRequest);
        }

    }
}
