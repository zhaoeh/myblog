package com.mkt.agent.job.mapper.api;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerContractQueryByPageRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerContractQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerContractQueryResponse;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentQueryByPageResponse;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface AgentContractMapper extends BaseMapper<TAgentContract> {

    AgentCustomerContractQueryResponse getOne(AgentCustomerContractQueryRequest req);

    List<AgentQueryByPageResponse> queryByPageAndCondition(AgentCustomerContractQueryByPageRequest rq);

    Long countQueryByPageAndCondition(AgentCustomerContractQueryByPageRequest rq);

    TAgentContract selectByAgentAccount(String loginName);

}
