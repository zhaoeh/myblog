package com.mkt.agent.job.service.impl;

import com.cn.schema.customers.QueryCustomersRequest;
import com.cn.schema.customers.QueryCustomersResponse;
import com.cn.schema.customers.WSCustomers;
import com.mkt.agent.integration.template.WsTemplate;
import com.mkt.agent.job.service.MigrateCustomerDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

/**
 * @Description TODO
 * @Classname MigrateCustomerDataServiceImpl
 * @Date 2023/8/28 15:09
 * @Created by TJSLucian
 */
@Service
@Slf4j
public class MigrateCustomerDataServiceImpl implements MigrateCustomerDataService {

    @Override
    @Retryable(value = RuntimeException.class, maxAttempts = 4, backoff = @Backoff(delay = 10000))
    public List<WSCustomers> callWsForData(WsTemplate wsTemplate,QueryCustomersRequest req){

        QueryCustomersResponse queryCustomersResponse = wsTemplate.queryCustomers(req);
        if(queryCustomersResponse!=null&&queryCustomersResponse.isSuccess()) {
            List<WSCustomers> wsCustomersList = queryCustomersResponse.getWSCustomers();
            log.info("call ws service successfully. The size of data is:{}",wsCustomersList.size());
            if(Objects.nonNull(wsCustomersList)&&wsCustomersList.size()>0) {
                return wsCustomersList;
            }
        }else {
            throw new RuntimeException("Failed to perform transfer after multiple attempts");
        }
        log.info("call ws service successfully. There is no more data.");
        return null;
    }
}
