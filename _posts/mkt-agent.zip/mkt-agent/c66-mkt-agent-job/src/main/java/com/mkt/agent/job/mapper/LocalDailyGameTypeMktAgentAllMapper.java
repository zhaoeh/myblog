package com.mkt.agent.job.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.jobapi.table.DailyGameTypeMktAgentAll;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface LocalDailyGameTypeMktAgentAllMapper extends BaseMapper<DailyGameTypeMktAgentAll> {

    Integer batchDailyGameTypeMktAgentAllInsert(@Param("list") List<DailyGameTypeMktAgentAll> dailyMktAgentAllList);

    void createTableIfNotExist();

}
