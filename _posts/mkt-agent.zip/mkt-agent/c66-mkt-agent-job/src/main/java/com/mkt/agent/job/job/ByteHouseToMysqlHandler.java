package com.mkt.agent.job.job;

import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.job.job.process.ByteHouseToMysqlHandlerProcess;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class ByteHouseToMysqlHandler extends IJobHandler {

    @Override
    @XxlJob(value = "byteHouseToMysqlHandler")
    public void execute() throws Exception {
        log.info("开始计算player数据 starting  开始时间={}", new Date().getTime());

        // 按月计算 ; 所有游戏类型
        String  param   = XxlJobHelper.getJobParam();

        log.info(param);

        JSONObject jsonObject = new JSONObject(param) ;

        String type   =      "0";  //默认跑 昨天和前天

        Calendar thisMonthFirstDateCal = Calendar.getInstance();



        thisMonthFirstDateCal.add(Calendar.DAY_OF_MONTH,-3);  //前天
        Date startDate = (thisMonthFirstDateCal.getTime());

        thisMonthFirstDateCal.add(Calendar.DAY_OF_MONTH,2);//昨天

//        thisMonthFirstDateCal.setTime(thisMonthFirstDateCal.);

        Date endDate =  thisMonthFirstDateCal.getTime();

        if(jsonObject.has("type")){
            type  =    jsonObject.getString("type") ;

            if (type.equals("1")) {
                // 标识当天的数据更新
                startDate    =    new Date();
                endDate    =    new Date();

            }else if(type.equals("2")){
                //跑指定日期到指定日期
                if (jsonObject.has("startDate")) {
                    startDate = DateUtils.stringToDate(jsonObject.get("startDate").toString());
                }

                if (jsonObject.has("endDate")) {
                    endDate = DateUtils.stringToDate(jsonObject.get("endDate").toString());
                }
            }

        }


        log.info("开始跑指定日期的数据,开始时间={},结束时间={}",DateUtils.dateToString(startDate),DateUtils.dateToString(endDate));

        byteHouseToMysqlHandlerProcess.tongBu(startDate,endDate);

        log.info("开始计算player数据 ending   开始时间={}", new Date().getTime());

    }

    @Autowired
    private ByteHouseToMysqlHandlerProcess byteHouseToMysqlHandlerProcess ;


}
