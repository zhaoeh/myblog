package com.mkt.agent.job.mapper.api;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentQueryByPageRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.OrgCodeUpdateRequest;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerQueryResponse;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentQueryByPageResponse;
import com.mkt.agent.common.entity.api.jobapi.requests.AgentCustomersTestRequest;
import com.mkt.agent.common.entity.api.jobapi.responses.AgentDetails;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface AgentMapper extends BaseMapper<TAgentCustomers> {


    List<AgentQueryByPageResponse> queryByPageAndCondition(AgentQueryByPageRequest rq);

    Long countQueryByPageAndCondition(AgentQueryByPageRequest rq);

    AgentCustomerQueryResponse getOne(AgentCustomerQueryRequest req);

    void updateAgentsByBatch(@Param(value = "req") List<OrgCodeUpdateRequest> req);

    List<AgentDetails> selectAgentTree(String topAgentAccount);

    TAgentCustomers getById(Long id);

    List<AgentDetails> selectTopAgents();

    List<String> listProAgentByAgentTypeZero();

    void insertAgentCustomersTest(AgentCustomersTestRequest req);

    void insertAgentCustomersTestForCheck(AgentCustomersTestRequest req);

    List<String> listTopAgentsLoginNameTest();

    Integer countDevAgentByTopAgentLoginNameTest(String loginName);

    List<TAgentCustomers> queryNeedHandledDate();

    Integer updateNLevelNeedHandledDate(@Param(value = "nLevelcustomers") TAgentCustomers nLevelcustomers);

    List<TAgentCustomers> selectAgentPNamesByLevel(@Param(value = "level") int level);

    TAgentCustomers getOneTopAgent();

    List<TAgentCustomers> queryUncheckedAgents(@Param(value = "recordDateStart") String recordDateStart, @Param(value = "recordDateEnd") String recordDateEnd, @Param(value = "level") int level);

    List<TAgentCustomers> queryAgentsByTimeNLevel(@Param(value = "recordDateStart") String recordDateStart, @Param(value = "recordDateEnd") String recordDateEnd, @Param(value = "level") int level);

    List<TAgentCustomers> queryUncheckedAgentsForLast2Month(@Param(value = "recordDateStart") String recordDateStart, @Param(value = "recordDateEnd") String recordDateEnd, @Param(value = "level") int level);

    List<String> selectDirectAgentNames(String parent);
}
