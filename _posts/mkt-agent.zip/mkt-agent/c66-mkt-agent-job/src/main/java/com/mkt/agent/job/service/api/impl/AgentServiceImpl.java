package com.mkt.agent.job.service.api.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentQueryByPageRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.OrgCodeUpdateRequest;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerQueryResponse;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentQueryByPageResponse;
import com.mkt.agent.common.entity.api.jobapi.requests.AgentCustomersTestRequest;
import com.mkt.agent.common.entity.api.jobapi.responses.AgentDetails;
import com.mkt.agent.job.mapper.api.AgentMapper;
import com.mkt.agent.job.service.api.AgentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Slf4j
@Service
public class AgentServiceImpl implements AgentService {


    @Autowired
    private AgentMapper agentMapper;

    /**
     * @param req
     * @return
     */
    @Override
    public Page<AgentQueryByPageResponse> queryListByPageAndCondition(AgentQueryByPageRequest req) {

        //分页数据初始化
        req.setPageParams(req.getCurrent(), req.getSize());

        // 查总记录数
        Long total = agentMapper.countQueryByPageAndCondition(req);
        // 查记录
        List<AgentQueryByPageResponse> resultList = agentMapper.queryByPageAndCondition(req);


        Page<AgentQueryByPageResponse> result = new Page<AgentQueryByPageResponse>();
        result.setRecords(resultList);
        result.setTotal(total);
        result.setCurrent(req.getCurrent());
        result.setSize(req.getSize());
        result.setPages(total / req.getSize());

        return result;
    }

    /**
     * @param req
     * @return
     */
    @Override
    public Long getAgentCount(AgentQueryByPageRequest req) {
        return agentMapper.countQueryByPageAndCondition(req);
    }

    /**
     * @param req
     * @return
     */
    @Override
    public AgentCustomerQueryResponse getOne(AgentCustomerQueryRequest req) {
        return agentMapper.getOne(req);
    }

    /**
     * @param req
     */
    @Override
    public void updateAgentsByBatch(List<OrgCodeUpdateRequest> req) {
        agentMapper.updateAgentsByBatch(req);
    }

    @Override
    public List<AgentDetails> selectAgentTree(String topAgentAccount) {
        return agentMapper.selectAgentTree(topAgentAccount);
    }

    @Override
    public List<AgentDetails> selectTopAgents() {
        return agentMapper.selectTopAgents();
    }

    @Override
    public void insertAgentCustomersTest(AgentCustomersTestRequest req) {
        agentMapper.insertAgentCustomersTest(req);
    }


    @Override
    public void insertAgentCustomersTestForCheck(AgentCustomersTestRequest req) {
        agentMapper.insertAgentCustomersTestForCheck(req);
    }

    @Override
    public List<String> listTopAgentsLoginNameTest() {
        return agentMapper.listTopAgentsLoginNameTest();
    }

    @Override
    public Integer countDevAgentByTopAgentLoginNameTest(String loginName) {
        return agentMapper.countDevAgentByTopAgentLoginNameTest(loginName);
    }


    //递归获取1级代理
    @Override
    public TAgentCustomers queryTopAgent(Long customersId) {
        TAgentCustomers tAgentCustomers = agentMapper.getById(customersId);
        log.info("current Agent:{},parentId:{}", tAgentCustomers, tAgentCustomers.getParentId());
        if (tAgentCustomers.getAgentLevel().equals(1)) {
            return tAgentCustomers;
        }
        return queryTopAgent(tAgentCustomers.getParentId());
    }

    @Override
    public TAgentCustomers queryTopAgentByName(String loginName){
        TAgentCustomers tAgentCustomers = agentMapper.selectOne(new LambdaQueryWrapper<TAgentCustomers>().eq(TAgentCustomers::getLoginName,loginName).eq(TAgentCustomers::getIsEnable,1)
                .eq(TAgentCustomers::getIsDeleted,0));
        log.info("current Agent:{},parentId:{}", tAgentCustomers, tAgentCustomers.getParentId());
        if (tAgentCustomers.getAgentLevel().equals(1)) {
            return tAgentCustomers;
        }
        return queryTopAgentByName(tAgentCustomers.getParentName());
    }

    @Override
    public List<TAgentCustomers> selectAgentPNamesByLevel(int level){return agentMapper.selectAgentPNamesByLevel(level);}

    @Override
    public TAgentCustomers getOneTopAgent(){return agentMapper.getOneTopAgent();}

    @Override
    public List<TAgentCustomers> queryDirectAgents(String loginName){return agentMapper.selectList(new LambdaQueryWrapper<TAgentCustomers>()
            .eq(TAgentCustomers::getParentName,loginName).eq(TAgentCustomers::getIsEnable, BaseConstants.AGENTS_IS_ABLE));}

    @Override
    public List<TAgentCustomers> queryUncheckedAgents(String recordDateStart, String recordDateEnd, int level){return agentMapper.queryUncheckedAgents(recordDateStart,recordDateEnd,level);}

    @Override
    public List<TAgentCustomers> queryAgentsByTimeNLevel(String recordDateStart, String recordDateEnd, int level){return agentMapper.queryAgentsByTimeNLevel(recordDateStart,recordDateEnd,level);}
    @Override
    public List<TAgentCustomers> queryUncheckedAgentsForLast2Month(String recordDateStart, String recordDateEnd, int level){return agentMapper.queryUncheckedAgentsForLast2Month(recordDateStart,recordDateEnd,level);}

    @Override
    public List<String> selectDirectAgentNames(String parent){
        return agentMapper.selectDirectAgentNames(parent);
    }

    @Override
    public List<TAgentCustomers> queryUncheckedAgentsForPlayers(String month, int level){return agentMapper.queryUncheckedAgentsForPlayers(month,level);}

    @Override
    public List<TAgentCustomers> queryAgentsByTimeNLevelIgnoreStatus(int level) {
        return agentMapper.queryAgentsByTimeNLevelIgnoreStatus(level);
    }

}


