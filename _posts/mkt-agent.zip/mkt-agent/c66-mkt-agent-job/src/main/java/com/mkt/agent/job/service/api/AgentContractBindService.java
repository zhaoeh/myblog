package com.mkt.agent.job.service.api;

import com.mkt.agent.common.entity.api.jobapi.requests.AgentContractBindRequest;
import com.mkt.agent.common.entity.api.jobapi.responses.AgentContractBindResponse;

import java.util.List;

/**
 * @author Colson
 * @date 8/14/2023 5:46 PM
 */
public interface AgentContractBindService {


    /**
     * 新增代理佣金方案*
     *
     * @param req 佣金方案绑定信息
     * @return 佣金方案绑定ID
     */
    Long insertAgentContractBindTest(AgentContractBindRequest req);

    /**
     * 查询所有绑定佣金方案的代理信息*
     *
     * @return
     */
    List<AgentContractBindResponse> listAgentContractBindTest();

}
