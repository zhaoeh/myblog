package com.mkt.agent.job.job.sql.handler;

import com.google.gson.Gson;
import com.mkt.agent.common.fast.pojo.QuerySqlParams;
import com.mkt.agent.job.job.sql.process.QuerySqlProcess;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

/**
 * @description: sql query handler
 * @author: ErHu.Zhao
 * @create: 2024-04-11
 **/
@Component
@Slf4j
@EnableScheduling
public class QuerySqlHandler extends IJobHandler {

    @Resource
    @Qualifier("bytehouseSqlSessionFactory")
    private SqlSessionFactory bytehouseSqlSessionFactory;

    @Resource
    @Qualifier("mysqlSqlSessionFactory")
    private SqlSessionFactory mysqlSqlSessionFactory;

    @Resource
    private Gson gson;


    @Resource
    private QuerySqlProcess sqlProcess;

    @PostConstruct
    public void check() {
        Assert.notNull(bytehouseSqlSessionFactory, "bytehouseSqlSessionFactory cannot be null");
        Assert.notNull(mysqlSqlSessionFactory, "mysqlSqlSessionFactory cannot be null");
    }

    @XxlJob(value = "QuerySqlHandler")
    @Override
    public void execute() throws Exception {

        String jobParam = XxlJobHelper.getJobParam();
        QuerySqlParams params;
        try {
            params = gson.fromJson(jobParam, QuerySqlParams.class);
        } catch (Exception e) {
            log.error("sql query参数格式错误");
            throw e;
        }
        String dataSourceType = params.getDataSourceType();
        Assert.isTrue(("byteHouse".equals(dataSourceType) || "mysql".equals(dataSourceType)), "dataSourceType 取值错误，只能取值 byteHouse 或者 mysql");
        String querySql = params.getQuerySql();
        Assert.isTrue(StringUtils.isNotBlank(querySql), "querySql cannot be blank");

        if ("byteHouse".equals(dataSourceType)) {
            sqlProcess.doQuery(querySql, bytehouseSqlSessionFactory);
        }
        if ("mysql".equals(dataSourceType)) {
            sqlProcess.doQuery(querySql, mysqlSqlSessionFactory);
        }

    }


}
