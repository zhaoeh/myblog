package com.mkt.agent.job.clickhouse.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse;
import com.mkt.agent.common.fast.pojo.DailyMktUserMapping;
import com.mkt.agent.common.fast.pojo.FastQueryModel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface FastByteHouseMapper extends BaseMapper<DailyMktUserMapping> {

    /**
     * 批量插入用户-代理映射关系
     *
     * @param list
     * @return
     */
    int insertUsersMapping(@Param("userMapping") List<DailyMktUserMapping> list);

    /**
     * 全量清空用户-代理映射关系
     */
    void clearUsersMapping();

    /**
     * 根据level和name查询用户-代理映射关系
     *
     * @param queryModel
     * @return
     */
    List<DailyMktUserMapping> queryUserMappingByName(@Param("model") FastQueryModel queryModel);

    /**
     * 查询某个level对应的某批代理的玩家-代理关系映射集
     *
     * @param agentLevel
     * @param agentNames
     * @return
     */
    List<DailyMktUserMapping> queryUserMappingByNames(@Param("agentLevel") Integer agentLevel, @Param("agentNames") List<String> agentNames);

    /**
     * 根据用户名称查询 玩家-代理 映射集
     *
     * @param userNames
     * @return
     */
    List<DailyMktUserMapping> queryUserMappingByUserNames(@Param("userNames") List<String> userNames);

    /**
     * 查询目标代理的团队用户明细数据count（包含目标代理自己）
     *
     * @param queryModel
     * @return
     */
    int queryTeamAndSelfDetailsWithLevelAgentCount(@Param("model") FastQueryModel queryModel);

    /**
     * 查询目标代理的团队用户明细数据（包含目标代理自己）
     *
     * @param queryModel
     * @return
     */
    List<PlayerReportResponse> queryTeamAndSelfDetailsWithLevelAgent(@Param("model") FastQueryModel queryModel);

    /**
     * 查询目标代理的团队用户明细数据（不包含目标代理自己）
     *
     * @param queryModel
     * @return
     */
    List<PlayerReportResponse> queryTeamDetailsWithLevelAgent(@Param("model") FastQueryModel queryModel);

    /**
     * 查询目标代理的所有直属用户详情（包含目标代理自己）
     *
     * @param queryModel
     * @return
     */
    List<PlayerReportResponse> queryDirectDetailsAndSeltWithAgent(@Param("model") FastQueryModel queryModel);


    int queryDirectDetailsWithAgentAndLevelCount(@Param("model") FastQueryModel queryModel);

    /**
     * 查询目标代理的所有直属用户详情（不包含目标代理自己）
     *
     * @param queryModel
     * @return
     */
    List<PlayerReportResponse> queryDirectDetailsWithAgentAndLevel(@Param("model") FastQueryModel queryModel);

    /**
     * 查询目标level的代理集的所有直属用户详情（包含目标level代理集）
     *
     * @param queryModel
     * @return
     */
    List<PlayerReportResponse> queryDirectDetailsAndSelfWithTargetLevel(@Param("model") FastQueryModel queryModel);


    /**
     * 查询指定玩家的交易明细数据count
     *
     * @param queryModel
     * @return
     */
    int queryPlayerDetailsCount(@Param("model") FastQueryModel queryModel);

    /**
     * 查询指定玩家的交易明细数据
     *
     * @param queryModel
     * @return
     */
    List<PlayerReportResponse> queryPlayerDetails(@Param("model") FastQueryModel queryModel);

    /**
     * 查询指定状态的玩家-用户关系转移总数
     *
     * @param queryModel
     * @return
     */
    int queryUserMappingCount(@Param("model") FastQueryModel queryModel);
}
