package com.mkt.agent.job.mapper;

import com.mkt.agent.common.entity.TByteHouseData;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface TByteHouseDataMapper  extends BatchBaseMapper<TByteHouseData> {
    List<TByteHouseData> selectByLogins(Map<String, Object> loginParame);

    void updateParent1(Map<String, Object> updatePar);

    List<String> getTop2Data(Map<String ,String>  parame);

    void updateParentLevel(Map<String, Object> updatePar);

    List<TByteHouseData> listTop10000(Map<String, String> parame2);

    void deleteByDate(Map<String, Object> parame);

    void updateLevals(Map<String, Object> parame);

    void updateSiteId(Map<String, Object> parame);

    List<TByteHouseData> selectListAll();
}
