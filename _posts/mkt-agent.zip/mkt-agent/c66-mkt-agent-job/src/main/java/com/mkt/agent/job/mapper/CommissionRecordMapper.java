package com.mkt.agent.job.mapper;

import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.DashBoardCommissionVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface CommissionRecordMapper extends CommonMapper<AgentCommissionRecord> {

    DashBoardCommissionVo queryCommissionByNameDate(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

}
