package com.mkt.agent.job.job.task.base;

import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.common.entity.api.integration.bi.requests.UserSummerRequest;
import com.mkt.agent.common.entity.api.integration.bi.responses.CustUserSummerResponse;
import com.mkt.agent.common.entity.api.integration.bi.responses.UserSummerResponse;
import com.mkt.agent.common.entity.api.jobapi.responses.AgentDetails;
import com.mkt.agent.common.enums.CommissionPlanTypeEnum;
import com.mkt.agent.common.enums.GameTypeEnum;
import com.mkt.agent.common.enums.SettlementPeriodEnum;
import com.mkt.agent.common.utils.BeanCopyUtil;
import com.mkt.agent.common.utils.CalculateCommissionUtils;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.job.service.api.AgentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Description: 佣金计算处理抽象类
 * @Author: PTMinnisLi
 * @Date: 2023/7/20
 */
@Component
public abstract class CommissionTaskOfReleaseMem {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private AgentService agentService;

    /**
     * 任务执行
     *
     * @param agents   目标计算代理用户
     * @param period   计算周期
     * @param gameType 游戏类型
     */
    public void execute(AgentDetails agents, SettlementPeriodEnum period, GameTypeEnum gameType) {

        AgentDetails agentDetails;
        List<TCustomerLayer> players;
        List<UserSummerResponse> gameData;
        List<CustUserSummerResponse> playersData;
        String commissionPlanType;
        List<AgentCommissionRecord> records = null;
        List<AgentDetails> agentDetailsList;
        Iterator<AgentDetails> iterator;
        List<TCustomerLayer> nextLevelPlayers;
        List<UserSummerResponse> nextLevelGameData;
        List<CustUserSummerResponse> nextLevelPlayersData;
        List<AgentCommissionRecord> nextLevelRecords = null;
        try {
            // 1.获取1级代理直属玩家
            players = readUserData(agents.getLoginName());

            logger.info("players:{}", Arrays.toString(players.toArray()));

            // 2.根据用户数据获取投注数据
            gameData = readBiData(players, period);
            if (null == gameData || gameData.size() <= 0) {
                logger.info("Get null from BI----------");
                return;
            }
            logger.info("gameData:{}", Arrays.toString(gameData.toArray()));

            // 3.bi数据转换
            playersData = convertData(players, gameData, agents);
            logger.info("playersData:{}", Arrays.toString(playersData.toArray()));
            if (null == playersData || playersData.size() <= 0) {
                logger.info("convert BI Data NULL----------");
                players = null;
                gameData = null;
                agents = null;
                System.gc();
                return;
            }

            commissionPlanType = agents.getCommissionPlanType();

            //实际活跃用户数
            int count = getActualUserCount(agents, playersData, commissionPlanType);

            //1级代理需要满足条件
            if (agents.getSettlementConditions() == 1) {
                logger.info("The Agent's actual active user count:{}, the limit count:{}", count, agents.getActiveUserHeadcount());
                if (count < agents.getActiveUserHeadcount()) {
                    logger.info("The level one agent doesn't hit the condition. Agent:{}, SettlementConditions:{}", agents, agents.getSettlementConditions());
                    players = null;
                    gameData = null;
                    agents = null;
                    playersData = null;
                    System.gc();
                    return;
                }
            }

            // 计算1级代理佣金
            if (commissionPlanType.equals(CommissionPlanTypeEnum.TURNOVER.getCode())) {
                records = CalculateCommissionUtils.commissionCalculateForTURNOVER(agents, playersData, count, agents.getLoginName());
            } else if (commissionPlanType.equals(CommissionPlanTypeEnum.GGR.getCode())) {
                //定时任务佣金计算，默认从1级开始算
                records = CalculateCommissionUtils.commissionCalculateForGGR(agents, playersData, count, agents.getLoginName(), 1);
            }

            // 计算1级代理佣金
//        List<AgentCommissionRecord> records = calculateCommission(agents, playersData,count,agents.getLoginName());

            if (null == records || records.size() <= 0) {
                players = null;
                gameData = null;
                agents = null;
                playersData = null;
                System.gc();
                logger.info("records Data NULL----------");
                return;
            }
            logger.info("records:{}", Arrays.toString(records.toArray()));

            // 1级代理佣金记录入库

            logger.info("Begin to save records---");
            saveRecords(records);
            records = null;
            System.gc();

            logger.info("topAgent saveRecords finish:{}", agents);

            //查询1级代理下的所有代理
            agentDetailsList = agentService.selectAgentTree(agents.getLoginName());


            //计算1级代理下的所有代理的佣金
            if (null != agentDetailsList && agentDetailsList.size() > 0) {
                iterator = agentDetailsList.iterator();
                while (iterator.hasNext()) {
                    agentDetails = iterator.next();

                    logger.info("The agent is:{}", agentDetails.toString());
                    //查询代理下所有直属玩家
                    nextLevelPlayers = readUserData(agentDetails.getLoginName());

                    logger.info("nextLevelPlayers:{}", Arrays.toString(nextLevelPlayers.toArray()));

                    // 根据用户数据获取投注数据
                    nextLevelGameData = readBiData(nextLevelPlayers, period);
                    if (null == nextLevelGameData || nextLevelGameData.size() <= 0) {
                        logger.info("Get null from BI----------");
                        iterator.remove();
                        agentDetails = null;
                        System.gc();
                        continue;
                    }
                    logger.info("nextLevelGameData:{}", Arrays.toString(nextLevelGameData.toArray()));

                    // bi数据转换
                    nextLevelPlayersData = convertData(nextLevelPlayers, nextLevelGameData, agentDetails);
                    logger.info("nextLevelPlayersData:{}", Arrays.toString(nextLevelPlayersData.toArray()));
                    if (null == nextLevelPlayersData || nextLevelPlayersData.size() <= 0) {
                        logger.info("convert BI Data NULL----------");
                        iterator.remove();
                        agentDetails = null;
                        System.gc();
                        continue;
                    }


                    if (commissionPlanType.equals(CommissionPlanTypeEnum.TURNOVER.getCode())) {
                        nextLevelRecords = CalculateCommissionUtils.commissionCalculateForTURNOVER(agentDetails, nextLevelPlayersData, 0, agents.getLoginName());
                    } else if (commissionPlanType.equals(CommissionPlanTypeEnum.GGR.getCode())) {
                        nextLevelRecords = CalculateCommissionUtils.commissionCalculateForGGR(agentDetails, nextLevelPlayersData, 0, agents.getLoginName(), 1);
                    }

                    if (null == nextLevelRecords || nextLevelRecords.size() <= 0) {
                        logger.info("nextLevelRecords Data NULL----------");
                        iterator.remove();
                        agentDetails = null;
                        System.gc();
                        continue;
                    }
                    logger.info("nextLevelRecords:{}", Arrays.toString(nextLevelRecords.toArray()));

                    // 4.佣金记录入库
                    saveRecords(nextLevelRecords);
                    logger.info("saveRecords finish");
                    iterator.remove();
                    agentDetails = null;
                    System.gc();
                }
            }

            logger.info("TopAgentTree:{},all finish", agents);
        } catch (Exception e) {
            logger.info("Failed to handle commission for agent:{}", agents.getLoginName());
            e.printStackTrace();
        }finally {
            agentDetails = null;
            players = null;
            gameData = null;
            playersData = null;
            commissionPlanType = null;
            records = null;
            agentDetailsList = null;
            iterator = null;
            nextLevelPlayers = null;
            nextLevelGameData = null;
            nextLevelPlayersData = null;
            nextLevelRecords = null;
            System.gc();
        }


    }


    protected abstract List<TCustomerLayer> readUserData(String customersId);

    protected List<UserSummerResponse> readBiData(List<TCustomerLayer> tCustomerLayers, SettlementPeriodEnum period) {

        // 获取代理玩家的loginName
        List<String> names = tCustomerLayers.stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList());

        // 配置bi查询参数
        UserSummerRequest req = new UserSummerRequest();
        req.setNames(names);
        names = null;
        System.gc();
        // 根据周期类型设置查询参数
        switch (period) {
            case MONTH:
                req.setMonthFlg(BaseConstants.MONTH_FLAG);
                req.setStartDate(DateUtils.getLastMonthFirstDay().toString());
                req.setEndDate(DateUtils.getLastMonthLastDayV1().toString());
                break;
            case DAY:
                // TODO
                req.setMonthFlg(BaseConstants.DAY_FLAG);
                req.setStartDate(DateUtils.getLastMonthFirstDay().toString());
                req.setEndDate(DateUtils.getLastMonthLastDayV1().toString());
                break;
            default:
                break;
        }
        return readBiData(req);
    }

    protected abstract List<UserSummerResponse> readBiData(UserSummerRequest userSummerRequest);

    /**
     * 转换BI数据
     *
     * @param players
     * @param gameData
     * @return
     */
    private List<CustUserSummerResponse> convertData(List<TCustomerLayer> players, List<UserSummerResponse> gameData, AgentDetails agents) {
        // map (id, 用户类型)
        Map<String, TCustomerLayer> userTypeMap = players.stream()
                .collect(Collectors.toMap(TCustomerLayer::getLoginName, c -> c));
        List<CustUserSummerResponse> custUsers = BeanCopyUtil.copyListProperties(gameData, CustUserSummerResponse::new);
        gameData = null;
        System.gc();
        custUsers.forEach(g -> {
            TCustomerLayer tCustomerLayer = userTypeMap.get(g.getName());
            g.setCustomerId(tCustomerLayer.getCustomerId());
            g.setParentId(tCustomerLayer.getParentId());
            if (tCustomerLayer.getCustomerType() == 3) {
                g.setAgentType(agents.getAgentType());
            } else {
                g.setAgentType(3);
            }
//            g.setCustomerType(tCustomerLayer.getCustomerType());
            g.setParentAccount(tCustomerLayer.getParentLoginName());
            g.setProductId("C66");
            g.setSiteId(tCustomerLayer.getSiteId());
        });

        logger.info("转换bi数据：{}", Arrays.toString(custUsers.toArray()));
        return custUsers;
    }

    /**
     * 计算佣金
     *
     * @param agents         当前处理代理
     * @param summerResponse 代理用户
     * @param count          实际活跃用户
     * @return 佣金记录
     */
    protected abstract List<AgentCommissionRecord> calculateCommission(AgentDetails agents, List<CustUserSummerResponse> summerResponse, int count, String levelOneAccount);

    protected abstract void saveRecords(List<AgentCommissionRecord> records);

    /**
     * description: 如果1级代理满足条件，则进行计算
     *
     * @param: [agent]
     * @return: boolean
     * @Date: 2023/7/20 16:38
     * @Version: 1.0.0
     * @Author: Lucian
     */
    private int getActualUserCount(AgentDetails agent, List<CustUserSummerResponse> directPlayers, String commissionPlanType) {

        BigDecimal activeUserTurnover = new BigDecimal(agent.getActiveUserTurnover());

        int count = 0;
        if (commissionPlanType.equals(CommissionPlanTypeEnum.TURNOVER.getCode())) {
            for (CustUserSummerResponse custUserSummerResponse : directPlayers) {
                if (custUserSummerResponse.getTurnoverSum().compareTo(activeUserTurnover) >= 0) {
                    count++;
                }
            }
        } else if (commissionPlanType.equals(CommissionPlanTypeEnum.GGR.getCode())) {
            for (CustUserSummerResponse custUserSummerResponse : directPlayers) {
                if (custUserSummerResponse.getGgrSum().compareTo(activeUserTurnover) >= 0) {
                    count++;
                }
            }
        }

        return count;

    }

}
