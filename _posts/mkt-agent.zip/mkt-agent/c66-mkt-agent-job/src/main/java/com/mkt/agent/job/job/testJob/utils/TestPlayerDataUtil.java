package com.mkt.agent.job.job.testJob.utils;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mkt.agent.common.config.DashBoardConfig;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.api.jobapi.responses.AgentDetails;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.*;
import com.mkt.agent.common.enums.CommissionPlanTypeEnum;
import com.mkt.agent.common.utils.DashBoardCommonUtil;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.RedisUtil;
import com.mkt.agent.common.utils.SerializationUti;
import com.mkt.agent.job.clickhouse.mapper.ClDashBoardV1Mapper;
import com.mkt.agent.job.clickhouse.mapper.TestClMapper;
import com.mkt.agent.job.job.testJob.entity.TestJobParams;
import com.mkt.agent.job.job.testJob.service.TestService;
import com.mkt.agent.job.mapper.CommissionRecordMapper;
import com.mkt.agent.job.mapper.DashBoardHistoryByDayMapper;
import com.mkt.agent.job.mapper.api.ContractBindMapper;
import com.mkt.agent.job.service.api.AgentService;
import com.mkt.agent.job.service.api.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @Description TODO
 * @Classname DashBoardUtil
 * @Date 2023/12/6 16:06
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class TestPlayerDataUtil {

    @Resource
    private TestClMapper testClMapper;

    @Autowired
    private DashBoardConfig dashBoardConfig;

    @Autowired
    private UserService userService;

    @Autowired
    private DashBoardCommonUtil dashBoardCommonUtil;

    @Autowired
    private AgentService agentService;

    @Resource
    private TestService testService;

    @Autowired
    private DashBoardHistoryByDayMapper dashBoardHistoryByDayMapper;

    @Resource
    private Gson gson;

    @Resource
    private RedisUtil redisUtil;



    public void handleByLevelByDay(int level, LocalDate recordDateStart, LocalDate recordDateEnd ,String handleType){

        log.info("[handleByLevelByDay]Begin to handle level:{}",level);

        List<TAgentCustomers> agentList = null;

        //获取所有代理
        agentList = agentService.queryAgentsByTimeNLevel(recordDateStart.toString(),recordDateEnd.toString(),level);

        log.info("The agentList size for level:{} is:{}",level,agentList.size());

        //获取每个代理每天产生的数据
        List<DashBoardHistoryEntity> dashBoardResponsesList = this.getResFromClByDay(agentList,recordDateStart,recordDateEnd,handleType);

        log.info("[handleByLevelByDay]finished to save data for level:{}",level);
        agentList = null;
        dashBoardResponsesList = null;
        level--;

        if(level>0){
            handleByLevelByDay(level,recordDateStart,recordDateEnd,handleType);
        }

    }


    public void handleByLevelByDayWithParams(int level, LocalDate recordDateStart, LocalDate recordDateEnd , String handleType, TestJobParams jobParams){

        log.info("[handleByLevelByDay]Begin to handle level:{}",level);

        List<TAgentCustomers> agentList = null;

        if(Objects.nonNull(jobParams)){
            agentList = testService.queryAgentsTest(jobParams.getAgentAccount(), Objects.isNull(jobParams.getLevel())||jobParams.getLevel()==0?level:jobParams.getLevel());
        }else {
            //获取所有代理
            agentList = agentService.queryAgentsByTimeNLevel(recordDateStart.toString(),recordDateEnd.toString(),level);

        }

        log.info("The agentList size for level:{} is:{}",level,agentList.size());

        //获取每个代理每天产生的数据
        List<DashBoardHistoryEntity> dashBoardResponsesList = this.getResFromClByDay(agentList,recordDateStart,recordDateEnd,handleType);

        log.info("[handleByLevelByDay]finished to save data for level:{},The data size is:{}",level,CollectionUtils.isEmpty(dashBoardResponsesList)? 0 : dashBoardResponsesList.size());
        agentList = null;
        dashBoardResponsesList = null;
        level--;

        if(level>0){
            handleByLevelByDayWithParams(level,recordDateStart,recordDateEnd,handleType,jobParams);
        }

    }



    private List<DashBoardHistoryEntity> getResFromClByDay(List<TAgentCustomers> agentList, LocalDate recordDateStartL, LocalDate recordDateEndL , String handleType){

        if(CollectionUtils.isEmpty(agentList)){
            return null;
        }

        List<DashBoardHistoryEntity> allAgentTeamDataList = new ArrayList<>();

        String recordDateStart = recordDateStartL.toString();
        String recordDateEnd = recordDateEndL.toString();


        agentList.forEach(agent -> {

            String agentAccount = agent.getLoginName();
            log.info("[handleByLevelByDay-getResFromClByDay]Begin to handle data for agent:{} for last month",agentAccount);
            try {

                //存储直属用户数据
                List<DashBoardHistoryEntity> userDataList = null;

                //查询直属用户
                List<String> usersNameList = userService.selectDirectUsersAgentsNameForPlayer(List.of(agentAccount));

                //查询直属用户的数据
                if(!CollectionUtils.isEmpty(usersNameList)){
                    log.info("[handleByLevelByDay]The userNameList size for agent:{} is:{}",agentAccount,usersNameList.size());

                    userDataList = this.queryDashBoardDataFromCl(ClDashBoardCreateQueryReq.builder()
                            .loginNameList(usersNameList).recordDateStart(recordDateStart).recordDateEnd(recordDateEnd)
                            .agentAccount(agentAccount).build());

                    log.info("[handleByLevelByDay]Finished to query direct user data for agent:{}",agentAccount);

                }

                if(!CollectionUtils.isEmpty(userDataList)){
                    log.info("[handleByLevelByDay]The userDataList size for agent:{} is:{}",agentAccount,userDataList.size());

                    allAgentTeamDataList.addAll(userDataList);
                }

            }catch (Exception e){
                log.info("[handleByLevelByDay]Failed to handle data for agent:{}",agentAccount,e);
            }

        });

        return allAgentTeamDataList;
    }


    private List<DashBoardHistoryEntity> queryDashBoardDataFromCl(ClDashBoardCreateQueryReq queryReq){

        log.info("Begin to query dashBoard data for agent:{}",queryReq.getAgentAccount());

        if (queryReq.getLoginNameList().size() <= dashBoardConfig.getBatchQuerySize()) {
            return testClMapper.testQueryPlayerDataByDay(queryReq);
        } else {

            List<List<String>> batches = Lists.partition(queryReq.getLoginNameList(), dashBoardConfig.getBatchQuerySize());

            Set<ClDashBoardCreateQueryReq> batchQuerys = batches.stream().map(b -> ClDashBoardCreateQueryReq.builder()
                    .loginNameList(b).recordDateStart(queryReq.getRecordDateStart()).recordDateEnd(queryReq.getRecordDateEnd())
                    .agentAccount(queryReq.getAgentAccount()).parentAgentAccount(queryReq.getParentAgentAccount()).build()).collect(Collectors.toSet());

            List<DashBoardHistoryEntity> response = batchQuerys.stream().map(q -> testClMapper.testQueryPlayerDataByDay(q))
                    .reduce((r1,r2) -> Stream.concat(r1.stream(),r2.stream()).collect(Collectors.toList())).orElse(Collections.emptyList());
            return response;
        }

    }


}
