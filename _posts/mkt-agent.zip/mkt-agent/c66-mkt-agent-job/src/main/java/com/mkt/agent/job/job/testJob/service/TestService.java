package com.mkt.agent.job.job.testJob.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentQueryByPageRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.OrgCodeUpdateRequest;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerQueryResponse;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentQueryByPageResponse;
import com.mkt.agent.common.entity.api.jobapi.requests.AgentCustomersTestRequest;
import com.mkt.agent.common.entity.api.jobapi.responses.AgentDetails;

import java.util.List;

/**
 * @ClassName AgentService
 * @Author Amida
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
public interface TestService {

    List<TAgentCustomers> queryAgentsTest(String agentAccount, int level);

}
