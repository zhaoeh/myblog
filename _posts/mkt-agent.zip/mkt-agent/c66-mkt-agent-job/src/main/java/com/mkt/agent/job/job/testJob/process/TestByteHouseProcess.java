package com.mkt.agent.job.job.testJob.process;


import com.google.common.collect.Lists;
import com.mkt.agent.common.config.DashBoardConfig;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;

import com.mkt.agent.job.clickhouse.mapper.ClDashBoardV1Mapper;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @Description TODO
 * @Classname DashBoardHistoryProcess
 * @Date 2023/12/6 16:30
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class TestByteHouseProcess {

    @Resource
    private ClDashBoardV1Mapper clDashBoardV1Mapper;

    @Resource
    private DashBoardConfig dashBoardConfig;

    public List<DashBoardHistoryEntity> queryDashBoardDataFromCl(ClDashBoardCreateQueryReq queryReq){

        log.info("Begin to query dashBoard data for agent:{}",queryReq.getAgentAccount());

        if (queryReq.getLoginNameList().size() <= dashBoardConfig.getBatchQuerySize()) {
            return clDashBoardV1Mapper.queryDashBoardTDataByDay(queryReq);
        } else {

            List<List<String>> batches = Lists.partition(queryReq.getLoginNameList(), dashBoardConfig.getBatchQuerySize());

            Set<ClDashBoardCreateQueryReq> batchQuerys = batches.stream().map(b -> ClDashBoardCreateQueryReq.builder()
                    .loginNameList(b).recordDateStart(queryReq.getRecordDateStart()).recordDateEnd(queryReq.getRecordDateEnd())
                    .agentAccount(queryReq.getAgentAccount()).parentAgentAccount(queryReq.getParentAgentAccount()).build()).collect(Collectors.toSet());

            List<DashBoardHistoryEntity> response = batchQuerys.stream().map(q -> clDashBoardV1Mapper.queryDashBoardTDataByDay(q))
                    .reduce((r1,r2) -> Stream.concat(r1.stream(),r2.stream()).collect(Collectors.toList())).orElse(Collections.emptyList());
            return response;
        }

    }

}
