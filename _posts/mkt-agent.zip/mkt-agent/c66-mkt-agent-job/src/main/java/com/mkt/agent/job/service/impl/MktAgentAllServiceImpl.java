package com.mkt.agent.job.service.impl;

import com.google.common.collect.Lists;
import com.mkt.agent.common.entity.api.jobapi.table.DailyMktAgentAll;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.job.clickhouse.mapper.ByteHouseDailyMktAgentAllMapper;
import com.mkt.agent.job.mapper.LocalDailyMktAgentAllMapper;
import com.mkt.agent.job.service.MktAgentAllService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
@Slf4j
public class MktAgentAllServiceImpl implements MktAgentAllService {

    @Resource
    private ByteHouseDailyMktAgentAllMapper byteHouseDailyMktAgentAllMapper;

    @Resource
    private LocalDailyMktAgentAllMapper localDailyMktAgentAllMapper;

    @Value("${dataMigration.asyncLimit:5000}")
    private Integer asyncLimit;

    @Value("${dataMigration.threadPoolSize:5}")
    private Integer threadPoolSize;

    @Value("${dataMigration.migratePageSize:1000000}")
    private Integer migratePageSize;

    @Value("${dataMigration.dailyInsertPatchSize:150000}")
    private Integer dailyInsertPatchSize;

    private static ExecutorService executorService;

    private static final String table = "t_daily_mkt_agent_all";


    @Override
    public void allDataMigration() {
        log.info("{} start migration ...", table);

        int totalPage = byteHouseDailyMktAgentAllMapper.selectTotalPageByPageSize(migratePageSize);

        log.info(" TotalPage : {}; MigratePageSize : {} ", totalPage, migratePageSize);

        Integer response = 0;
        CountDownLatch latch = new CountDownLatch(totalPage);
        try {
            log.info("The total page size is:{}", totalPage);
            List<Future<Integer>> futureRecords = IntStream.range(0, totalPage)
                    .mapToObj(i -> executorService.submit(() -> {
                        log.info("Begin to query the page:{}",i);
                        List<DailyMktAgentAll> pageList = byteHouseDailyMktAgentAllMapper.selectPageRecordByPage(i, migratePageSize);
                        try {
                            log.info("Begin to insert the page:{}",i);
                            List<List<DailyMktAgentAll>> partitionList = Lists.partition(pageList, asyncLimit);
                            Integer insertCount = 0;
                            for (List<DailyMktAgentAll> partition : partitionList) {
                                insertCount += localDailyMktAgentAllMapper.batchDailyMktAgentAllInsert(partition);
                            }
                            log.info("Insert the page {} Finish ",i);
                            latch.countDown();
                            return insertCount;
                        } catch (Exception e) {
                            log.error("Error!", e);
                            latch.countDown();
                            return null;
                        }

                    })).collect(Collectors.toList());
            latch.await();
            log.info("Async insert finish !");
            response = futureRecords.stream().map(f -> {
                try {
                    return f.get();
                } catch (InterruptedException | ExecutionException e) {
                    log.error("Error!", e);
                }
                return null;
            }).filter(Objects::nonNull).reduce(Integer::sum).orElse(null);

        }catch (Exception e){
            log.error("Failed to async insert from ByteHouse to Local !",e);
        }
        log.info(" Response : {} ", response);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void dataUpdatingByDayRange(String startDate, String endDate) {
        log.info("Query ByteHouse {} of {} - {} data begin ... ", table, startDate, endDate);
        if (StringUtils.isEmpty(startDate) || StringUtils.isEmpty(endDate))
            return;

        List<String> dateRangeAsStr = DateUtils.getDateRangeAsStr(DateUtils.stringToLocalDate(startDate), DateUtils.stringToLocalDate(endDate));

        for (String dayStr : dateRangeAsStr) {
            List<DailyMktAgentAll> dailyMktAgentAllList = byteHouseDailyMktAgentAllMapper.selectByDay(dayStr);
            log.info("ByteHouse {} {} count: {} ", table, dayStr, dailyMktAgentAllList.size());

            log.info("delete {} of {} starting ... ", table, dayStr);
            int deleteCount = localDailyMktAgentAllMapper.deleteByDay(dayStr);
            log.info("delete count : {} ", deleteCount);

            if (CollectionUtils.isEmpty(dailyMktAgentAllList)){
                log.info("ByteHouse {} of {} data size is 0, skip inserting. ", table, dayStr);
                return;
            }

            Integer count = 0;

            try {
                log.info("Begin to insert {} data", dayStr);
                List<List<DailyMktAgentAll>> partitionList = Lists.partition(dailyMktAgentAllList, dailyInsertPatchSize);
                for (List<DailyMktAgentAll> partition : partitionList) {
                    count += localDailyMktAgentAllMapper.batchDailyMktAgentAllInsert(partition);
                }

                log.info("Insert {} data finish", dayStr);
            } catch (Exception e) {
                log.error("Error! Insert Fail! ", e);
                /* 将报错信息插入表中 */

                throw e;
            }

            log.info(" Insert count: {} ", count);
        }
    }

    @Override
    public long count() {
        return localDailyMktAgentAllMapper.count();
    }

    @PostConstruct
    public void initTheadPool() {
        log.info("begin to init thread pool of {}", this.getClass().getName());
        executorService = Executors.newFixedThreadPool(this.threadPoolSize);
        log.info("end to init thread pool of {}, threadPoolSize is {}", this.getClass().getName(), this.threadPoolSize);    }

    @PreDestroy
    public void destroy(){
        executorService.shutdown();
    }
}
