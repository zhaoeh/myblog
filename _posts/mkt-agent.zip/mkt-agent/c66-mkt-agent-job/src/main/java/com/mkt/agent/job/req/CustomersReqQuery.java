package com.mkt.agent.job.req;


import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @Author Andy
 * @Date 2022/12/26 11:44
 **/
@Data
@ApiModel("用户查询")
public class CustomersReqQuery{
    @NotBlank(message = "startDate is required!")
    @ApiModelProperty("开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private String startDate;
    @NotBlank(message = "endDate is required!")
    @ApiModelProperty("结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private String endDate;


}
