package com.mkt.agent.job.job.process;

import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.job.util.DashBoardDataByDayV1Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDate;

/**
 * @Description 初始化仪表盘缓存 每天
 * @Classname DashBoardPreRedisHandlerProcess
 * @Date 2023/12/6 13:57
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class DashBoardPreCommissionV1Process {

    @Autowired
    private DashBoardDataByDayV1Util dashBoardV1Util;

    /**
     * description: 初始化缓存
     * @param:  []
     * @return: void
     * @Date: 2023/12/6 14:07
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public void process(){

        try {

            log.info("Begin to handle commission data for current day");
            //计算佣金
            dashBoardV1Util.handleCommission();

            log.info("Finished to handle today's data!");


        }catch (Exception e){
            log.info("Failed to cache today's data!",e);
        }


    }






}
