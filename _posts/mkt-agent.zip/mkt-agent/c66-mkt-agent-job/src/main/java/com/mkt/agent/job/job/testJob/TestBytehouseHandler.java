package com.mkt.agent.job.job.testJob;

import com.google.gson.Gson;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.job.job.testJob.process.TestByteHouseProcess;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;


@Component
@Slf4j
public class TestBytehouseHandler extends IJobHandler {

    @Resource
    private TestByteHouseProcess process;

    @Resource
    private Gson gson;

    @Override
    @XxlJob(value = "TestBytehouseHandler")
    public void execute() throws Exception {
        log.info("TestBytehouseHandler starting ...");
        ClDashBoardCreateQueryReq queryReq = new ClDashBoardCreateQueryReq();
        queryReq.setRecordDateStart("2023-12-01");
        queryReq.setRecordDateEnd("2023-12-30");
        queryReq.setAgentAccount("lucian");
        queryReq.setParentAgentAccount("luciann");
        queryReq.setLoginNameList(List.of("co007111111","bpzunn","luciana"));
        List<DashBoardHistoryEntity> result = process.queryDashBoardDataFromCl(queryReq);
        if(!CollectionUtils.isEmpty(result)){
            log.info("Success to query data from clickhouse and bytehouse!");
            log.info("The data is :{}",gson.toJson(result));
        }
        log.info("TestBytehouseHandler end ...");
    }



}
