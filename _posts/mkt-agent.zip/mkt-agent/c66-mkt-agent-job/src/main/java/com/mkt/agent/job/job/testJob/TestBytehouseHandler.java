package com.mkt.agent.job.job.testJob;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.mkt.agent.common.config.DashBoardConfig;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.ds.core.DataSourceConstants;
import com.mkt.agent.ds.finder.DSWeaver;
import com.mkt.agent.job.clickhouse.mapper.ClDashBoardV1Mapper;
import com.mkt.agent.job.handler.DashboardTeamSummaryJobHandler;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@Component
@Slf4j
public class TestBytehouseHandler extends IJobHandler {

    @Resource
    private ClDashBoardV1Mapper clDashBoardV1Mapper;

    @Autowired
    private DashBoardConfig dashBoardConfig;

    @Resource
    private Gson gson;

    @Override
    @XxlJob(value = "TestBytehouseHandler")
    public void execute() throws Exception {
        log.info("TestBytehouseHandler starting ...");
        ClDashBoardCreateQueryReq queryReq = new ClDashBoardCreateQueryReq();
        queryReq.setRecordDateStart("2024-01-01");
        queryReq.setRecordDateEnd("2024-01-23");
        queryReq.setAgentAccount("lucian");
        queryReq.setParentAgentAccount("luciann");
        queryReq.setLoginNameList(List.of("aappag2024011711","aappag2024011716"));
        List<DashBoardHistoryEntity> result = queryDashBoardDataFromCl(queryReq);
        if(!CollectionUtils.isEmpty(result)){
            log.info("Success to query data from clickhouse and bytehouse!");
            log.info("The data is :{}",gson.toJson(result));
        }
        log.info("TestBytehouseHandler end ...");
    }

    @DS(DataSourceConstants.NICO_PREFIX)
    @DSWeaver(dsHandler = DashboardTeamSummaryJobHandler.class)
    private List<DashBoardHistoryEntity> queryDashBoardDataFromCl(ClDashBoardCreateQueryReq queryReq){

        log.info("Begin to query dashBoard data for agent:{}",queryReq.getAgentAccount());

        if (queryReq.getLoginNameList().size() <= dashBoardConfig.getBatchQuerySize()) {
            return clDashBoardV1Mapper.queryDashBoardTDataByDay(queryReq);
        } else {

            List<List<String>> batches = Lists.partition(queryReq.getLoginNameList(), dashBoardConfig.getBatchQuerySize());

            Set<ClDashBoardCreateQueryReq> batchQuerys = batches.stream().map(b -> ClDashBoardCreateQueryReq.builder()
                    .loginNameList(b).recordDateStart(queryReq.getRecordDateStart()).recordDateEnd(queryReq.getRecordDateEnd())
                    .agentAccount(queryReq.getAgentAccount()).parentAgentAccount(queryReq.getParentAgentAccount()).build()).collect(Collectors.toSet());

            List<DashBoardHistoryEntity> response = batchQuerys.stream().map(q -> clDashBoardV1Mapper.queryDashBoardTDataByDay(q))
                    .reduce((r1,r2) -> Stream.concat(r1.stream(),r2.stream()).collect(Collectors.toList())).orElse(Collections.emptyList());
            return response;
        }

    }

}
