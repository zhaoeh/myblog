package com.mkt.agent.job.job.process;

import com.google.gson.Gson;
import com.mkt.agent.common.entity.api.jobapi.responses.AgentDetails;
import com.mkt.agent.common.enums.GameTypeEnum;
import com.mkt.agent.common.enums.SettlementPeriodEnum;
import com.mkt.agent.job.feign.CommissionApiGateClient;
import com.mkt.agent.job.job.task.CommissionMonthByAllTask;
import com.mkt.agent.job.mapper.api.UserMapper;
import com.mkt.agent.job.req.TAgentCustomers;
import com.mkt.agent.job.service.CommissionRecordService;
import com.mkt.agent.job.service.api.AgentService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

import javax.validation.Valid;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description: 佣金处理
 * @Author: PTMinnisLi
 * @Date: 2023/7/20
 */
@Component
public class CommissionProcessLadderVersion {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private CommissionApiGateClient commissionApiGateClient ;


    public void execute(Map<String,String> req) {
            Map<String, Object> result = new HashMap<>();

            String loginName = req.get("loginName");
//        String username  =  req .get("username") ;
            String isSave = req.get("isSave");
            String startDate = req.get("startDate");
            String endDate = req.get("endDate");

            Map<String, Object> parame = new HashMap<>();
            parame.put("startDate", startDate);
            parame.put("endDate", endDate);
            parame.put("isSave", isSave);



            if (!StringUtils.isBlank(loginName)) {
                //显示全部

                String[] names = loginName.split(",");

                for (String name : names) {
                    parame.put("name", name);
                    parame.put("agent_level", 1);
                    List< TAgentCustomers> customers = userMapper.listTopAgent(parame);


                    if (customers != null && customers.size() > 0) {

                         TAgentCustomers agentCustomers = customers.get(0);

                        if (agentCustomers.getCommissionContractBindId() != null) {
                            result = commissionRecordService.calcCommissionData(agentCustomers, parame);  //  开始计算佣金
                        }


                    } else {
//                    parame.put("agent_level", 1);
                        parame.remove("agent_level") ;
                        customers = userMapper.listTopAgent(parame);
                         if (customers != null && customers.size() > 0) {
                            TAgentCustomers agentCustomers = customers.get(0);

                            while ( agentCustomers.getAgentLevel() != 1) {
                                parame.put("name", agentCustomers.getParentName());
                                customers = userMapper.listTopAgent(parame);
                                if (customers != null && customers.size() > 0) {
                                    agentCustomers = customers.get(0);
                                }
                            }
                             result = commissionRecordService.calcCommissionData(agentCustomers, parame);  //  开始计算佣金

                        }
                    }


                }


            } else {
                parame.put("agent_level", 1);
                List<TAgentCustomers> customers = userMapper.listTopAgent(parame);

                for (TAgentCustomers agentCustomers : customers) {
                    if (agentCustomers.getCommissionContractBindId() != null) {
                        logger.info("开始计算customers={}",new Gson().toJson(agentCustomers));

                        commissionRecordService.calcCommissionData(agentCustomers, parame);  //  开始计算佣金
                    }

                }


            }

        }

        @Autowired
        private UserMapper userMapper;

    @Autowired
    private CommissionRecordService commissionRecordService ;


}
