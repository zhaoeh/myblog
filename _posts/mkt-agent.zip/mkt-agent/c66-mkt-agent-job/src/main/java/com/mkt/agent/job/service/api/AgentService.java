package com.mkt.agent.job.service.api;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentQueryByPageRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.OrgCodeUpdateRequest;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerQueryResponse;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentQueryByPageResponse;
import com.mkt.agent.common.entity.api.jobapi.requests.AgentCustomersTestRequest;
import com.mkt.agent.common.entity.api.jobapi.responses.AgentDetails;
import com.mkt.agent.common.entity.api.jobapi.responses.CustomerLayerResponse;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @ClassName AgentService
 * @Author Amida
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
public interface AgentService {


    Page<AgentQueryByPageResponse> queryListByPageAndCondition(AgentQueryByPageRequest req);

    Long getAgentCount(AgentQueryByPageRequest req);

    AgentCustomerQueryResponse getOne(AgentCustomerQueryRequest req);

    void updateAgentsByBatch(List<OrgCodeUpdateRequest> req);

    List<AgentDetails> selectAgentTree(String topAgentAccount);

    TAgentCustomers queryTopAgent(Long customersId);

    TAgentCustomers queryTopAgentByName(String loginName);

    List<AgentDetails> selectTopAgents();

    void insertAgentCustomersTest(AgentCustomersTestRequest req);

    void insertAgentCustomersTestForCheck(AgentCustomersTestRequest req);
    /**
     * 获取顶级代理用户名*
     *
     * @return 顶级代理用户名
     */
    List<String> listTopAgentsLoginNameTest();

    Integer countDevAgentByTopAgentLoginNameTest(String loginName);

    List<TAgentCustomers> selectAgentPNamesByLevel(int level);

    TAgentCustomers getOneTopAgent();

    List<TAgentCustomers> queryDirectAgents(String loginName);

    List<TAgentCustomers> queryUncheckedAgents(String recordDateStart, String recordDateEnd, int level);

    List<TAgentCustomers> queryAgentsByTimeNLevel(String recordDateStart, String recordDateEnd, int level);


    List<TAgentCustomers> queryUncheckedAgentsForLast2Month(String recordDateStart, String recordDateEnd, int level);

    List<String> selectDirectAgentNames(String parent);

}
