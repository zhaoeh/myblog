package com.mkt.agent.job.job;

import com.mkt.agent.common.enums.GameTypeEnum;
import com.mkt.agent.common.enums.SettlementPeriodEnum;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.job.job.process.CommissionProcess;
import com.mkt.agent.job.job.process.CommissionProcessLadderVersion;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @Description: 佣金计算(按月计算 ; 所有游戏类型)
 * @Author: PTMinnisLi
 * @Date: 2023/7/20
 */
@Component
@Slf4j
public class CommissionMonthLadderVersion extends IJobHandler {

    @Autowired
    private CommissionProcessLadderVersion commissionProcessLadderVersion;


    @Override
    @XxlJob(value = "commissionMonthLadderVersion")
    public void execute() {

        log.info("commissionMonthLadderVersion starting  开始时间={}", new Date().getTime());
        /**
         * {
         *     "loginName" : "bp20240311e",
         *     "isSave" : "1",
         *     "startDate" : "2024-03-01",
         *     "endDate" : "2024-03-13"
         * }
         */
        // 按月计算 ; 所有游戏类型
        String  param   = XxlJobHelper.getJobParam();

        log.info(param);

        JSONObject  jsonObject = new JSONObject(param) ;

        String loginName   =      "";//默认查询全部
        String isSave   =      "1"; //默认保存
        String startDate   = DateUtils.getLastMonthFirstDay().toString();
        String endDate   =     DateUtils.getLastMonthLastDayV1().toString() ;
        if (jsonObject.has("loginName")) {
            loginName  = jsonObject.getString("loginName") ;
        }
        if (jsonObject.has("isSave")) {
            isSave  = jsonObject.getString("isSave") ;
        } if (jsonObject.has("startDate")) {
            startDate  = jsonObject.getString("startDate") ;
        } if (jsonObject.has("endDate")) {
            endDate  = jsonObject.getString("endDate") ;
        }


        Map<String, String> parame  =  new HashMap<>();
        parame.put("loginName",loginName) ;
        parame.put("isSave",isSave) ;
        parame.put("startDate",startDate) ;
        parame.put("endDate",endDate) ;
        commissionProcessLadderVersion.execute(parame);

        log.info("commissionMonthLadderVersion end  结束时间={}", new Date().getTime());
    }

    public static void main(String[] args) {
        System.out.println(DateUtils.getLastMonthFirstDay().toString());
    }
}
