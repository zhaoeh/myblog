package com.mkt.agent.job.job;

import com.mkt.agent.common.enums.GameTypeEnum;
import com.mkt.agent.common.enums.SettlementPeriodEnum;
import com.mkt.agent.job.job.process.CommissionProcess;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @Description: 佣金计算(按月计算 ; 所有游戏类型)
 * @Author: PTMinnisLi
 * @Date: 2023/7/20
 */
@Component
@Slf4j
public class CommissionMonthByAllHandler extends IJobHandler {

    @Autowired
    private CommissionProcess commissionProcess;


    @Override
    @XxlJob(value = "commissionMonthByAllHandler")
    public void execute() {

        log.info("CommissionMonthByAllRecurveHandler starting");
        // 按月计算 ; 所有游戏类型
        commissionProcess.execute(SettlementPeriodEnum.MONTH, GameTypeEnum.All);

        log.info("CommissionMonthByAllRecurveHandler end");
    }
}
