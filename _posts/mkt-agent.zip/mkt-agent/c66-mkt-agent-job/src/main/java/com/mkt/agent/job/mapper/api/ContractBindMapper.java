package com.mkt.agent.job.mapper.api;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.jobapi.requests.AgentContractBindRequest;
import com.mkt.agent.common.entity.api.jobapi.responses.AgentContractBindResponse;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ContractBindMapper extends BaseMapper<TAgentContractBind> {


    Long insertContractBindTest(AgentContractBindRequest req);

    List<AgentContractBindResponse> listAgentContractBindTest();
}
