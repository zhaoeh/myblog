package com.mkt.agent.job.constants;

public class ComConstant {

    public static final String START_TIME=" 00:00:00";
    public static final String END_TIME=" 23:59:59";

}
