package com.mkt.agent.job.service.api.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.jobapi.requests.CustomerLayerTestRequest;
import com.mkt.agent.common.entity.api.jobapi.responses.CustomerLayerResponse;
import com.mkt.agent.common.enums.CustomerTypeEnum;
import com.mkt.agent.job.mapper.CustomerLayerMapper;
import com.mkt.agent.job.service.api.CustomerLayerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Colson
 * @date 8/21/2023 6:58 PM
 */
@Service
@Slf4j
public class CustomerLayerServiceImpl implements CustomerLayerService {

    @Autowired
    private CustomerLayerMapper customerLayerMapper;


    @Override
    public List<CustomerLayerResponse> listInitAgentCustomerLayerTest(CustomerLayerTestRequest req) {
        return customerLayerMapper.listInitAgentCustomerLayerTest(req);
    }

    @Override
    public Integer getAgentLevelByLoginNameTest(String loginName) {
        return customerLayerMapper.getAgentLevelByLoginNameTest(loginName);
    }

    @Override
    public Boolean hasDevAgentTest(String loginName) {
        return customerLayerMapper.countDevAgentTest(loginName) > 0;
    }

    @Override
    public void updateFlagAndCustomerTypeTest(CustomerLayerTestRequest req) {
        customerLayerMapper.updateFlagAndCustomerTypeTest(req);
    }

    @Override
    public Integer getDevLevelByLoginNameTest(String loginName) {
        return customerLayerMapper.getDevLevelByLoginNameTest(loginName);
    }
}
