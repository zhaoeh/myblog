package com.mkt.agent.job.req;

import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;

import java.math.BigDecimal;
import java.util.List;

public class CommissionValues {
    private   TAgentCustomers agentCustomers ;
    private String commissionResult ;
    private BigDecimal  turnover;

    private  BigDecimal ggr ;
    private TAgentContract agentContract ;

    private BigDecimal winOrLoss ;
    private  BigDecimal deposit ;
    private  BigDecimal withdrawal ;

    private  Integer  sumactiveUser ;

    private   BigDecimal  bl ;

    private List<TCustomerLayer> list ;

    public List<TCustomerLayer> getList() {
        return list;
    }

    public void setList(List<TCustomerLayer> list) {
        this.list = list;
    }

    public BigDecimal getBl() {
        return bl;
    }

    public void setBl(BigDecimal bl) {
        this.bl = bl;
    }

    public void setSumactiveUser(Integer sumactiveUser) {
        this.sumactiveUser = sumactiveUser;
    }

    public Integer getSumactiveUser() {
        return sumactiveUser;
    }

    private   BigDecimal   yj ;

    public BigDecimal getYj() {
        return yj;
    }

    public void setYj(BigDecimal yj) {
        this.yj = yj;
    }

    public void setAgentCustomers(TAgentCustomers agentCustomers) {
        this.agentCustomers = agentCustomers;
    }

    public void setCommissionResult(String commissionResult) {
        this.commissionResult = commissionResult;
    }

    public void setTurnover(BigDecimal turnover) {
        this.turnover = turnover;
    }

    public void setGgr(BigDecimal ggr) {
        this.ggr = ggr;
    }

    public void setAgentContract(TAgentContract agentContract) {
        this.agentContract = agentContract;
    }

    public void setWinOrLoss(BigDecimal winOrLoss) {
        this.winOrLoss = winOrLoss;
    }

    public void setDeposit(BigDecimal deposit) {
        this.deposit = deposit;
    }

    public void setWithdrawal(BigDecimal withdrawal) {
        this.withdrawal = withdrawal;
    }

    public TAgentCustomers getAgentCustomers() {
        return agentCustomers;
    }

    public String getCommissionResult() {
        return commissionResult;
    }

    public BigDecimal getTurnover() {
        return turnover;
    }

    public BigDecimal getGgr() {
        return ggr;
    }

    public TAgentContract getAgentContract() {
        return agentContract;
    }

    public BigDecimal getWinOrLoss() {
        return winOrLoss;
    }

    public BigDecimal getDeposit() {
        return deposit;
    }

    public BigDecimal getWithdrawal() {
        return withdrawal;
    }
}
