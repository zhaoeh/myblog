package com.mkt.agent.job.service.api.impl;

import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.OrgCodeUpdateRequest;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerQueryResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.job.mapper.api.UserMapper;
import com.mkt.agent.job.service.api.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Slf4j
@Service
public class UserServiceImpl implements UserService {


    @Autowired
    private UserMapper userMapper;

    @Override
    public List<TCustomerLayer> selectUserTree(String parent) {
        return userMapper.selectUserTree(parent);
    }

    @Override
    public List<String> selectDirectUsersAgentsName(String parent){
        return userMapper.selectDirectUsersAgentsName(parent);
    }

    @Override
    public List<String> selectDirectUsersAgentsNameForPlayer(List<String> parentList){
        return userMapper.selectDirectUsersAgentsNameForPlayer(parentList);
    }


    @Override
    public List<String> selectDirectUsersName(String parent){
        return userMapper.selectDirectUsersName(parent);
    }

    @Override
    public DashBoardHistoryEntity selectRegisterUserCountByDay(ClDashBoardCreateQueryReq queryReq){
        return userMapper.selectRegisterUserCountByDay(queryReq);
    }

    @Override
    public Long selectRegisterUserCount(String parent, String recordDateTimeStart, String recordDateTimeEnd){
        return userMapper.selectRegisterUserCount(parent,recordDateTimeStart,recordDateTimeEnd);
    }

    @Override
    public List<String> selectTeamUserNames(String parent){
        return userMapper.selectTeamUserNames(parent);
    }
}
