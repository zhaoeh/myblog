package com.mkt.agent.job.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractList;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TAgentContractListMapper extends BaseMapper<TAgentContractList> {


}
