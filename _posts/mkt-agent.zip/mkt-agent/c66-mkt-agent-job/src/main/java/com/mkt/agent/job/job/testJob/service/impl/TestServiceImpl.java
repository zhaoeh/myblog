package com.mkt.agent.job.job.testJob.service.impl;


import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.job.clickhouse.mapper.TestClMapper;
import com.mkt.agent.job.job.testJob.service.TestService;
import com.mkt.agent.job.mapper.test.TestMysqlMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Slf4j
@Service
public class TestServiceImpl implements TestService {


    @Autowired
    private TestClMapper testClMapper;

    @Resource
    private TestMysqlMapper testMysqlMapper;

    @Override
    public List<TAgentCustomers> queryAgentsTest(String agentAccount, int level){
        return testMysqlMapper.queryAgentsTest(agentAccount,level);
    }


}


