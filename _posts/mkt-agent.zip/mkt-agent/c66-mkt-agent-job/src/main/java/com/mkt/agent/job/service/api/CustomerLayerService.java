package com.mkt.agent.job.service.api;

import com.mkt.agent.common.entity.api.jobapi.requests.CustomerLayerTestRequest;
import com.mkt.agent.common.entity.api.jobapi.responses.CustomerLayerResponse;

import java.util.List;

public interface CustomerLayerService {

    /**
     * 查询初始状态为0且类型为3的代理用户
     * 使用 t_customer_layer_test 表
     *
     * @return 未初始化的用户
     */
    List<CustomerLayerResponse> listInitAgentCustomerLayerTest(CustomerLayerTestRequest req);


    /**
     * 根据代理名查询所属层级、
     * 使用 t_customer_layer_test 表
     * * @param loginName 代理名称
     *
     * @return 所属层级
     */
    Integer getAgentLevelByLoginNameTest(String loginName);

    /**
     * 根据代理名查询是否有下级代理
     * 使用 t_customer_layer_test 表*
     *
     * @param loginName 代理名
     * @return true=有下级代理，false=无下级代理
     */
    Boolean hasDevAgentTest(String loginName);


    /**
     * 更新初始化状态为1&用户类型为1：玩家*
     *
     * @param req
     */
    void updateFlagAndCustomerTypeTest(CustomerLayerTestRequest req);

    /**
     * 根据代理名查询发展层级
     * * @param loginName 代理名称
     *
     * @return 发展层级
     */
    Integer getDevLevelByLoginNameTest(String loginName);
}
