package com.mkt.agent.job.job.player.process;

import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.player.model.PlayerReportByMonthMapperHolder;
import com.mkt.agent.common.player.model.PlayerReportByMonthProcessorModel;
import com.mkt.agent.common.player.processor.PlayerReportByMonthProcessor;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.job.clickhouse.mapper.ClDashBoardV1Mapper;
import com.mkt.agent.job.mapper.TAgentCountGroupMonthMapper;
import com.mkt.agent.job.service.api.AgentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDate;

@Component
@Slf4j
public class SyncTransByMonthForAgentProcess {

    @Resource
    private PlayerReportByMonthForAgentProcessor processor;

    @Resource
    private AgentService agentService;

    @Resource
    private TAgentCountGroupMonthMapper tAgentCountGroupMonthMapper;

    @Resource
    private ClDashBoardV1Mapper clDashBoardV1Mapper;

    public void syncUsersGroupByMonth(String account) {

        log.info("Begin to handle player report data--");

        //当月
        LocalDate currentMonthFirstDay = DateUtils.getLastNMonthFirstDay(0);
        LocalDate currentMonthLastDay = DateUtils.getLastNMonthLastDay(0);
        String currentMonth = DateUtils.getFormattedMonth(0);

        //当月
        processor.preHandlePlayerReportByMonth(PlayerReportByMonthProcessorModel.builder().level(Constants.DASH_BOARD_DATA_START_LEVEL).startDate(currentMonthFirstDay.toString())
                .endDate(currentMonthLastDay.toString()).month(currentMonth).isCurrentMonth(true).operatorType(Constants.FROM_JOB).holder(buildMapper()).build(),account);

        log.info("Finished to handle player report for current month data");
        //上个月
        LocalDate lastMonthFirstDay = DateUtils.getLastNMonthFirstDay(1);
        LocalDate lastMonthLastDay = DateUtils.getLastNMonthLastDay(1);
        String lastMonth = DateUtils.getFormattedMonth(1);

        processor.preHandlePlayerReportByMonth(PlayerReportByMonthProcessorModel.builder().level(Constants.DASH_BOARD_DATA_START_LEVEL).startDate(lastMonthFirstDay.toString())
                .endDate(lastMonthLastDay.toString()).month(lastMonth).isCurrentMonth(false).operatorType(Constants.FROM_JOB).holder(buildMapper()).build(),account);

        log.info("Finished to handle player report for last month data");
        //上上个月
        LocalDate last2MonthFirstDay = DateUtils.getLastNMonthFirstDay(2);
        LocalDate last2MonthLastDay = DateUtils.getLastNMonthLastDay(2);
        String last2Month = DateUtils.getFormattedMonth(2);

        processor.preHandlePlayerReportByMonth(PlayerReportByMonthProcessorModel.builder().level(Constants.DASH_BOARD_DATA_START_LEVEL).startDate(last2MonthFirstDay.toString())
                .endDate(last2MonthLastDay.toString()).month(last2Month).isCurrentMonth(false).operatorType(Constants.FROM_JOB).holder(buildMapper()).build(),account);

        log.info("Finished to handle player report for last2 month data");

    }

    private PlayerReportByMonthMapperHolder buildMapper(){
        return PlayerReportByMonthMapperHolder.builder()
                .teamAgentsByLevelMapper(null).allAgentByLevelWithoutStatusMapper(agentService::queryAgentsByTimeNLevelIgnoreStatus)
                .uncheckedAgentsByLevelNMonth(agentService::queryUncheckedAgentsForPlayers)
                .groupInsertMapper(tAgentCountGroupMonthMapper::insertBatchSomeColumn)
                .deleteByLevelNMonth(tAgentCountGroupMonthMapper::deleteByLevelNMonth).downlineAgentCountMapper(tAgentCountGroupMonthMapper::getDownlineAgentsData)
                .queryDirectCountByMonthMapper(clDashBoardV1Mapper::queryDirectCountByMonth)
                .querySelfCountByMonthMapper(clDashBoardV1Mapper::querySelfCountByMonth).build();
    }

}
