package com.mkt.agent.job.fast;

import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.job.clickhouse.mapper.FastByteHouseMapper;
import com.mkt.agent.job.mapper.fast.FastMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-04-04
 **/
@Component
public class FastContextBuilder {

    @Autowired
    private FastMapper fastMapper;

    @Autowired
    private FastByteHouseMapper fastByteHouseMapper;

    private FastContext fastContext;

    @PostConstruct
    public void init() {
        fastContext = FastContext.builder().queryNotTransferPlayersCountWithJoin(fastMapper::queryNotTransferPlayersCountWithJoin).
                queryAgentsMapping(fastMapper::queryAgentsMapping).
                queryAgentsMappingOfLarge(fastMapper::queryAgentsMappingOfLarge).
                selectSuperAgentsByNames(fastMapper::selectSuperAgentsByNames).
                queryNotTransferPlayersWithLimit(fastMapper::queryNotTransferPlayersWithLimit).
                queryNotTransferPlayersWithJoin(fastMapper::queryNotTransferPlayersWithJoin).
                insertBatchSomeColumnWithAgentCustomersMapping(fastMapper::batchInsertAgentMapping).
                insertBatchSomeColumnWithIncrementCheckPoint(fastMapper::batchInsertCheckPoint).
                updateAgentsStatus(fastMapper::updateAgentsStatus).
                deleteIncrementCheckPoint(fastMapper::deleteIncrementCheckPoint).
                selectSuperAgentsByNamesOfLarge(fastMapper::selectSuperAgentsByNamesOfLarge).
                selectSimpleCustomers(fastMapper::selectSimpleCustomers).
                selectAgentWithCheckPoint(fastMapper::selectAgentWithCheckPoint).
                selectTargetCheckPoints(fastMapper::selectTargetCheckPoints).
                selectTargetCheckPointsOfCount(fastMapper::selectTargetCheckPointsOfCount).
                queryUserMappingByNames(fastByteHouseMapper::queryUserMappingByNames).
                queryUsersCountForAgent(fastMapper::queryUsersCountForAgent).
                queryPlayersByNames(fastMapper::queryPlayersByNames).
                updateUsersStatus(fastMapper::updateUsersStatus).
                queryAgentsCount(fastMapper::queryAgentsCount).
                queryPlayersCount(fastMapper::queryPlayersCount).
                queryUserMappingCount(fastByteHouseMapper::queryUserMappingCount).
                queryAgentsCountDone(fastMapper::queryAgentsCountDone).
                clearAgentsMapping(fastMapper::clearAgentsMapping).
                clearUsersMapping(fastByteHouseMapper::clearUsersMapping).
                fastAgentMapperStatement("com.mkt.agent.job.mapper.fast.FastMapper.selectSuperAgentsByNamesOfLarge").
                fastAgentMappingMapperStatement("com.mkt.agent.job.mapper.fast.FastMapper.queryAgentsMappingOfLarge").
                build();
    }

    public FastContext getFastContext() {
        return fastContext;
    }
}
