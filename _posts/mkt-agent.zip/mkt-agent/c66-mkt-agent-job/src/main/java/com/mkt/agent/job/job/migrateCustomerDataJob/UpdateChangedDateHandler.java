package com.mkt.agent.job.job.migrateCustomerDataJob;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.job.mapper.api.AgentMapper;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @Description 已过期，不再使用
 * @Classname UpdateChangedDateHandler
 * @Date 2023/9/29 21:35
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class UpdateChangedDateHandler  extends IJobHandler {

    @Resource
    private AgentMapper agentMapper;

    @Override
    @XxlJob(value = "UpdateChangedDateHandler")
    public void execute() {
        log.info("UpdateChangedDateHandler starting");
        // 第一步：查询出所有需要处理的代理
        List<TAgentCustomers> list = agentMapper.queryNeedHandledDate();

        if(null==list||list.size()==0){
            return;
        }

        handleNextLevel(list);
        log.info("UpdateChangedDateHandler ending");
    }

    public void handleNextLevel(List<TAgentCustomers> list){

        for(TAgentCustomers customers : list){
            int currentLevel = customers.getAgentLevel();
            int currentDevLevel = customers.getDevelopableLevel();
            if(currentLevel==5){
                break;
            }
            //获取下一级代理
            List<TAgentCustomers> nextLevelList = getNextLevelList(customers);

            if(null==nextLevelList||nextLevelList.size()==0){
                continue;
            }

            List<TAgentCustomers> nNList = new ArrayList<>();

            //更新下一级代理
            for(TAgentCustomers nLevelcustomers : nextLevelList){
                nLevelcustomers.setAgentLevel(currentLevel+1);
                nLevelcustomers.setDevelopableLevel(currentDevLevel-1);
                agentMapper.updateNLevelNeedHandledDate(nLevelcustomers);
                List<TAgentCustomers> nNNList = getNextLevelList(nLevelcustomers);
                if(null!=nNNList&&nNNList.size()>0){
                    nNList.addAll(nNNList);
                }
            }

            if(nNList.size()>0){
                handleNextLevel(nNList);
            }

        }

    }

    public List<TAgentCustomers> getNextLevelList(TAgentCustomers customers){
        List<TAgentCustomers> nextLevelList = agentMapper.selectList(new LambdaQueryWrapper<TAgentCustomers>()
                .eq(TAgentCustomers::getParentId,customers.getCustomersId()));
        return nextLevelList;
    }

}
