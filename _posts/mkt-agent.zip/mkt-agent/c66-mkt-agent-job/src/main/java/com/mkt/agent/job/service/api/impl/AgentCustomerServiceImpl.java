package com.mkt.agent.job.service.api.impl;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerContractQueryByPageRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerContractQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerContractQueryResponse;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentQueryByPageResponse;
import com.mkt.agent.common.entity.api.jobapi.requests.AgentContractBindUpdateRequest;
import com.mkt.agent.job.mapper.api.AgentContractMapper;
import com.mkt.agent.job.service.api.AgentContractService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;


@Slf4j
@Service
public class AgentCustomerServiceImpl implements AgentContractService {


    @Autowired
    private AgentContractMapper agentContractMapper;

    /**
     * @param req
     * @return
     */
    @Override
    public AgentCustomerContractQueryResponse getOne(AgentCustomerContractQueryRequest req) {
        return agentContractMapper.getOne(req);
    }

    /**
     * @param req
     * @return
     */
    @Override
    public Page<AgentQueryByPageResponse> queryByPageAndCondition(AgentCustomerContractQueryByPageRequest req) {
        //分页数据初始化
        req.setPageParams(req.getCurrent(), req.getSize());

        // 查总记录数
        Long total = agentContractMapper.countQueryByPageAndCondition(req);
        // 查记录
        List<AgentQueryByPageResponse> resultList = agentContractMapper.queryByPageAndCondition(req);


        Page<AgentQueryByPageResponse> result = new Page<AgentQueryByPageResponse>();
        result.setRecords(resultList);
        result.setTotal(total);
        result.setCurrent(req.getCurrent());
        result.setSize(req.getSize());
        result.setPages(total / req.getSize());

        return result;
    }

    /**
     * @param rq
     * @return
     */
    @Override
    public Long countQueryByPageAndCondition(AgentCustomerContractQueryByPageRequest rq) {
        return agentContractMapper.countQueryByPageAndCondition(rq);
    }

    @Override
    public List<TAgentContract> listContractByCommissionPlanNames(List<String> contractPlanNames) {
        if (CollectionUtils.isEmpty(contractPlanNames)) {
            return new ArrayList<>();
        }
        return agentContractMapper.selectList(Wrappers.lambdaQuery(TAgentContract.class).in(TAgentContract::getCommissionPlanName, contractPlanNames));
    }

    @Transactional
    @Override
    public void updateAgentCount(List<AgentContractBindUpdateRequest> req) {
        req.forEach(r -> {
            TAgentContract tAgentContract = new TAgentContract();
            tAgentContract.setId(r.getId());
            tAgentContract.setAgentCount(r.getAgentCount().intValue());
            agentContractMapper.updateById(tAgentContract);
        });
    }
}
