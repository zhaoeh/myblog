package com.mkt.agent.job.exception;

import com.cn.schema.customers.WSCustomers;
import com.mkt.agent.common.exception.BusinessException;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @Description TODO
 * @Classname MigrateCustomerDataException
 * @Date 2023/9/2 11:06
 * @Created by TJSLucian
 */
@Data
@Component
public class MigrateCustomerDataException extends BusinessException {

    private int pageNum;
    private List<WSCustomers> list;
    private String message;
    private int pageSize;
    private String date;

    public MigrateCustomerDataException(){
        super();
    }

    public MigrateCustomerDataException(int pageNum,List<WSCustomers> list,String message,int pageSize,String date){
        this.pageNum = pageNum;
        this.list = list;
        this.message = message;
        this.pageSize = pageSize;
        this.date = date;
    }


}
