package com.mkt.agent.job.job.process;

import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.job.util.DashBoardDataByDayV1Util;
import com.mkt.agent.job.util.DashBoardDataByPluralV1Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDate;

/**
 * @Description TODO
 * @Classname DashBoardHistoryProcess
 * @Date 2023/12/6 16:30
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class DashBoardHistoryV1Process {

    @Autowired
    private DashBoardDataByDayV1Util dashBoardDataByDayV1Util;

    @Resource
    private DashBoardDataByPluralV1Util dashBoardDataByPluralV1Util;

    /**
     * description: 同步历史数据
     * @param:  []
     * @return: void
     * @Date: 2023/12/6 16:31
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public void process(){

        log.info("Begin to handle last month data");

        //获取上个月第一天
        LocalDate lastMonthFirstDay = DateUtils.getLastNMonthFirstDay(1);
        LocalDate lastMonthLastDay = DateUtils.getLastNMonthLastDay(1);

        dashBoardDataByDayV1Util.handleByLevelByDay(Constants.DASH_BOARD_DATA_START_LEVEL,lastMonthFirstDay,lastMonthLastDay,Constants.HISTORY_DATA);

        log.info("Finished to handle last month data");

        String lastTwoMonthFirstDate = DateUtils.getLastNMonthFirstDay(2).toString();

        String lastTwoMonthLastDate = DateUtils.getLastNMonthLastDay(2).toString();

        //同步上上个月数据
        log.info("Begin to handle last two month data");
        dashBoardDataByPluralV1Util.handleByLevelByPlural(Constants.DASH_BOARD_DATA_START_LEVEL,lastTwoMonthFirstDate.toString(),lastTwoMonthLastDate.toString());
        log.info("Finished to handle last two month data");

    }

}
