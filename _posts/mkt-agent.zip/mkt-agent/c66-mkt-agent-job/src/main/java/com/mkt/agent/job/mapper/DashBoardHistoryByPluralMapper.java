package com.mkt.agent.job.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cn.schema.customers.WSCustomers;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.jobapi.requests.CustomerLayerTestRequest;
import com.mkt.agent.common.entity.api.jobapi.responses.CustomerLayerResponse;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverTopResp;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Mapper
@Transactional
public interface DashBoardHistoryByPluralMapper extends BatchBaseMapper<CommissionRecordDashBoardResponse> {

    /**
     * 排名前十的玩家账号柱状图
     * @return
     *  login_name      玩家名
     *  turnoverSum     投注额总计
     */
    List<ClTurnoverTopResp> topList(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    CommissionRecordDashBoardResponse getOneByStartNEnd(@Param("recordDateStart") String recordDateStart,@Param("recordDateEnd")String recordDateEnd);

    CommissionRecordDashBoardResponse querySumDownlineData(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

}
