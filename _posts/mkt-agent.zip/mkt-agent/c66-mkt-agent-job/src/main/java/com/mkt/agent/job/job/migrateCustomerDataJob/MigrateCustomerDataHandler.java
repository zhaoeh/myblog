package com.mkt.agent.job.job.migrateCustomerDataJob;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.customers.QueryCustomersRequest;
import com.cn.schema.customers.QueryCustomersResponse;
import com.cn.schema.customers.WSCustomers;
import com.cn.schema.customers.WSQueryCustomers;
import com.mkt.agent.common.config.SystemConfig;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.integration.config.WSConfig;
import com.mkt.agent.integration.template.WsTemplate;
import com.mkt.agent.job.constants.ComConstant;
import com.mkt.agent.job.exception.MigrateCustomerDataException;
import com.mkt.agent.job.mapper.CustomerLayerMapper;
import com.mkt.agent.job.service.MigrateCustomerDataService;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;


/**
 * @Description 同步用户使用，已过期不再使用
 * @Classname MigrateCustomerData
 * @Date 2023/8/23 18:03
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class MigrateCustomerDataHandler extends IJobHandler {

    @Resource
    private CustomerLayerMapper customerLayerMapper;

    @Resource
    @Qualifier("mysqlSqlSessionFactory")
    private SqlSessionFactory sqlSessionFactory;

    @Resource
    private WSConfig wsConfig;

    @Resource
    private SystemConfig systemConfig;

    @Resource
    private MigrateCustomerDataService migrateCustomerDataService;

    private final int pageSize = 3000;

    @Override
    @XxlJob("MigrateCustomerDataHandler")
    public void execute() {
        log.info("Begin to migrate Data");

        log.info("开始获取XXljob参数---");
        String migrateEndDate = XxlJobHelper.getJobParam();
        XxlJobHelper.log("AddCustomerLayerJop receive Param ", migrateEndDate);
        log.info("param---:{}",migrateEndDate);

        WSCustomers acc66Customer = callWsForAcc66();
        if(Objects.isNull(acc66Customer)){
            log.info("get acc66 data failed");
            return;
        }

        Calendar cd = Calendar.getInstance();
        cd.set(2023,9,1,23,59,59);
        Date dateTimeEnd = cd.getTime();
        log.info("The migrate Data end is:{}",dateTimeEnd);

        //拉数据入库
        firstStep(Integer.valueOf(pageSize),dateTimeEnd,migrateEndDate);
        log.info("End migrate Data");
    }

    /**
     * description: 分页查询，处理数据，入库
     * @param:  []
     * @return: void
     * @Date: 2023/8/23 18:22
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public void firstStep(int pageSize,Date dateTimeEnd,String migrateEndDate){
        log.info("Begin to do the firstStep-------pageSize:{},operateType:{},operateNum:{}",pageSize);
        QueryCustomersRequest req = new QueryCustomersRequest();
        WSQueryCustomers queryCustomers = new WSQueryCustomers();

        queryCustomers.setProductId(systemConfig.getProductId());
        queryCustomers.setPageSize(pageSize);
        queryCustomers.setFilterSearchType("customer_id,login_name,site_id,parent_id,customer_type,created_by,last_updated_by,created_date,remarks");
        req.setWSQueryCustomers(queryCustomers);
        req.setInfProductId(systemConfig.getProductId());
        req.setInfPwd(wsConfig.getPwd());
        req.setRequestUUID(UUID.randomUUID().toString().replace("-",""));

        int n = 0;

        while (true){
            int innerPageSize = 1;
            //设置天数
            String currentDate = DateUtils.getBeforeDate(dateTimeEnd,n);
            queryCustomers.setCreatedDateBegin(currentDate+ ComConstant.START_TIME);
            queryCustomers.setCreatedDateEnd(currentDate+ ComConstant.END_TIME);

            //设置出口 测试使用
            if(null!=migrateEndDate&&queryCustomers.getCreatedDateEnd().compareTo(migrateEndDate)==0){
                break;
            }

            while (true){
                queryCustomers.setPageNum(innerPageSize);
                Boolean innerFlag = saveBatch(req);
                if(innerFlag){
                    break;
                }
                innerPageSize = innerPageSize + 1;
            }

            if(innerPageSize == 1){
                break;
            }

            n = n -1;

        }
    }

    public Boolean saveBatch(QueryCustomersRequest req){
        List<WSCustomers> wsCustomersList = null;
        try {
            log.info("begin to call ws-----num:{},Begin Date:{}, End Date:{}",req.getWSQueryCustomers().getPageNum(),req.getWSQueryCustomers().getCreatedDateBegin(),req.getWSQueryCustomers().getCreatedDateEnd());

            wsCustomersList = callWsForData(req);

            if(null==wsCustomersList){
                log.info("The response from ws is null. AddCustomerData finished");
                return true;
            }

            log.info("begin to handle data-----,Date:{},pageNum:{}",req.getWSQueryCustomers().getCreatedDateEnd(),req.getWSQueryCustomers().getPageNum());

            log.info("The Data is :{}",Arrays.toString(wsCustomersList.toArray()));
            //入库
            SqlSession sqlSession=sqlSessionFactory.openSession();
            StopWatch stopWatch = new StopWatch();
            stopWatch.start();
            try {
                log.info("begin to save data----");
                customerLayerMapper.saveBatchTest(wsCustomersList);

            } catch (Exception e) {
                e.printStackTrace();
                log.error("saveBatch customerLayer data error,the date is:{},the pageNum is:{},the data is:{}",req.getWSQueryCustomers().getCreatedDateEnd(),req.getWSQueryCustomers().getPageNum(),Arrays.toString(wsCustomersList.toArray()));
            }
            sqlSession.commit();
            sqlSession.close();
            stopWatch.stop();
            log.info("add TCustomerLayer end. startDate:{},endDate:{},row:{},execution time:{}",req.getWSQueryCustomers().getCreatedDateBegin(),req.getWSQueryCustomers().getCreatedDateEnd(),wsCustomersList.size(),stopWatch.getTime());

        }catch (Exception e){
            log.info("service run failed,current data is:{},current pageNum is:{}",req.getWSQueryCustomers().getCreatedDateBegin()+"-"+req.getWSQueryCustomers().getCreatedDateEnd(),req.getWSQueryCustomers().getPageNum());
            throw new MigrateCustomerDataException(req.getWSQueryCustomers().getPageNum(),wsCustomersList,"导入数据异常，异常信息为："+e.getMessage(),req.getWSQueryCustomers().getPageSize(),req.getWSQueryCustomers().getCreatedDateBegin()+"-"+req.getWSQueryCustomers().getCreatedDateEnd());
        }
        return false;
    }

    /**
     * description: 调ws获取数据
     * @param:  [req]
     * @return: java.util.List<com.cn.schema.customers.WSCustomers>
     * @Date: 2023/8/22 14:22
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public List<WSCustomers> callWsForData(QueryCustomersRequest req){

        String url = wsConfig.getWsDefaultUrl() + "/rest/customers/queryCustomers";
        WsTemplate wsTemplate = new WsTemplate(url,wsConfig.getPwd());
        log.info("trying to get customer data from ws service by param:{}", JSONObject.toJSONString(req));
        List<WSCustomers> wsCustomersList = migrateCustomerDataService.callWsForData(wsTemplate,req);
        log.info("call ws service successfully");
        return wsCustomersList;
    }

    /**
     * description: 获取ACC66信息
     * @param:  []
     * @return: com.cn.schema.customers.WSCustomers
     * @Date: 2023/8/22 18:08
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public WSCustomers callWsForAcc66(){
        QueryCustomersRequest req = new QueryCustomersRequest();
        WSQueryCustomers queryCustomers = new WSQueryCustomers();
        queryCustomers.setLoginName(BaseConstants.C66_ADMIN);
        queryCustomers.setAllData(true);
        queryCustomers.setProductId(systemConfig.getProductId());
        req.setWSQueryCustomers(queryCustomers);
        req.setInfProductId(systemConfig.getProductId());
        req.setInfPwd(wsConfig.getPwd());
        req.setRequestUUID(UUID.randomUUID().toString().replace("-",""));
        try {
            String url = wsConfig.getWsDefaultUrl() + "/rest/customers/queryCustomers";
            WsTemplate wsTemplate = new WsTemplate(url,wsConfig.getPwd());
            log.info("trying to get acc66 from ws service by param:{}", JSONObject.toJSONString(req));
            QueryCustomersResponse queryCustomersResponse = wsTemplate.queryCustomers(req);
            if(queryCustomersResponse.isSuccess()) {
                List<WSCustomers> wsCustomersList = queryCustomersResponse.getWSCustomers();
                if(Objects.nonNull(wsCustomersList)&&wsCustomersList.size()>0) {
                    log.info("call ws service successfully. The size of data is:{}",wsCustomersList.size());
                    return wsCustomersList.get(0);
                }
            }
        }catch (Exception e){
            log.info("call ws service for acc66 failed");
            e.printStackTrace();
        }
        return null;
    }

}
