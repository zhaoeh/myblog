package com.mkt.agent.job.job.player.handler;

import com.mkt.agent.common.fast.core.FastConfig;
import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.common.fast.flow.FlowCenter;
import com.mkt.agent.common.fast.trigger.TimedTrigger;
import com.mkt.agent.job.fast.FastContextBuilder;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

/**
 * @description: 同步代理关系
 * @author: ErHu.Zhao
 * @create: 2024-04-11
 **/
@Component
@Slf4j
@EnableScheduling
public class SyncAgentRelationHandler extends IJobHandler {

    @Resource
    private FlowCenter flowCenter;

    @Autowired
    private TimedTrigger timedTrigger;

    @Autowired
    private FastContextBuilder fastContextBuilder;

    @Resource
    @Qualifier("bytehouseSqlSessionFactory")
    private SqlSessionFactory sqlSessionFactory;

    @Autowired
    private FastConfig fastConfig;

    private FastContext fastContext;

    @PostConstruct
    public void initFastContext() {
        fastContext = fastContextBuilder.getFastContext();
    }

    @XxlJob(value = "SyncAgentRelationHandler")
    @Override
    public void execute() throws Exception {
        if (BooleanUtils.isFalse(fastConfig.getFastSwitch())) {
            log.info("fast switch is close,stop do it");
            return;
        }
        log.info("begin doFlows");
        String jobParam = XxlJobHelper.getJobParam();
        boolean reRun = StringUtils.isBlank(jobParam) ? false : Boolean.valueOf(jobParam);
        log.info("SyncAgentRelationHandler rerun is {}", reRun);
        fastContext.setReRun(reRun);
        flowCenter.doFlows(fastContext, sqlSessionFactory);
        log.info("end doFlows");
    }

    @Scheduled(cron = "0 */5 * * * ?")
    public void triggerOnCheckPoint() {
        if (BooleanUtils.isFalse(fastConfig.getFastSwitch())) {
            log.info("fast switch is close,stop do it");
            return;
        }
        timedTrigger.triggerOnCheckPoint(fastContext, sqlSessionFactory);
    }

    @Scheduled(cron = "0 0 0-8/2 * * ?")
    public void triggerOnFlowCenter() {
        if (BooleanUtils.isFalse(fastConfig.getFastSwitch())) {
            log.info("fast switch is close,stop do it");
            return;
        }
        log.info("begin to triggerOnFlowCenter");
        timedTrigger.triggerOnFlowCenter(fastContext, sqlSessionFactory);
    }
}
