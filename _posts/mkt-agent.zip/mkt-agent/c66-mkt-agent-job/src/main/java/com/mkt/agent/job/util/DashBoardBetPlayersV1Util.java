package com.mkt.agent.job.util;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mkt.agent.common.config.DashBoardConfig;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.*;
import com.mkt.agent.common.enums.CommissionPlanTypeEnum;
import com.mkt.agent.common.utils.DashBoardCommonUtil;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.RedisUtil;
import com.mkt.agent.common.utils.SerializationUti;
import com.mkt.agent.job.clickhouse.mapper.ClDashBoardV1Mapper;
import com.mkt.agent.job.mapper.CommissionRecordMapper;
import com.mkt.agent.job.mapper.DashBoardHistoryByDayMapper;
import com.mkt.agent.job.mapper.api.AgentContractMapper;
import com.mkt.agent.job.mapper.api.ContractBindMapper;
import com.mkt.agent.job.service.api.AgentService;
import com.mkt.agent.job.service.api.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @Description TODO
 * @Classname DashBoardUtil
 * @Date 2023/12/6 16:06
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class DashBoardBetPlayersV1Util {

    @Resource
    private ClDashBoardV1Mapper clDashBoardV1Mapper;

    @Autowired
    private DashBoardConfig dashBoardConfig;

    @Autowired
    private UserService userService;

    @Autowired
    private DashBoardCommonUtil dashBoardCommonUtil;

    @Autowired
    private AgentService agentService;

    @Autowired
    private DashBoardHistoryByDayMapper dashBoardHistoryByDayMapper;

    @Resource
    private Gson gson;

    @Resource
    private RedisUtil redisUtil;


    public void handleBetPlayers(int level){

        //当月
        LocalDate currentMonthFirstDay = DateUtils.getLastNMonthFirstDay(0);
        LocalDate currentMonthLastDay = DateUtils.getLastNMonthLastDay(0);

        //上个月
        LocalDate lastMonthFirstDay = DateUtils.getLastNMonthFirstDay(1);
        LocalDate lastMonthLastDay = DateUtils.getLastNMonthLastDay(1);
        //上上个月
        LocalDate last2MonthFirstDay = DateUtils.getLastNMonthFirstDay(2);
        LocalDate last2MonthLastDay = DateUtils.getLastNMonthLastDay(2);
        //当周
        LocalDate currentWeekFirstDay = DateUtils.getNWeeksAgoMonday(0);
        LocalDate currentWeekLastDay = DateUtils.getNWeeksAgoSunday(0);
        //上周
        LocalDate lastWeekFirstDay = DateUtils.getNWeeksAgoMonday(1);
        LocalDate lastWeekLastDay = DateUtils.getNWeeksAgoSunday(1);
        //上上周
        LocalDate last2WeekFirstDay = DateUtils.getNWeeksAgoMonday(2);
        LocalDate last2WeekLastDay = DateUtils.getNWeeksAgoSunday(2);

        //今天
        LocalDate currentDay = DateUtils.getNDaysAgo(0);
        //昨天
        LocalDate yesterday = DateUtils.getNDaysAgo(1);
        //前天
        LocalDate last2Day = DateUtils.getNDaysAgo(2);

        doHandleBetPlayersByLevel(level,currentMonthFirstDay,currentMonthLastDay,lastMonthFirstDay,lastMonthLastDay,last2MonthFirstDay,last2MonthLastDay,currentWeekFirstDay,currentWeekLastDay,lastWeekFirstDay,lastWeekLastDay,last2WeekFirstDay,last2WeekLastDay,currentDay,yesterday,last2Day);
    }

    public void doHandleBetPlayersByLevel(int level, LocalDate currentMonthFirstDay,LocalDate currentMonthLastDay,LocalDate lastMonthFirstDay,LocalDate lastMonthLastDay,LocalDate last2MonthFirstDay,LocalDate last2MonthLastDay,LocalDate currentWeekFirstDay,LocalDate currentWeekLastDay,LocalDate lastWeekFirstDay,LocalDate lastWeekLastDay,LocalDate last2WeekFirstDay,LocalDate last2WeekLastDay,LocalDate currentDay,LocalDate yesterday,LocalDate last2Day){

        List<TAgentCustomers> agentList = agentService.selectAgentPNamesByLevel(level);

        if(!CollectionUtils.isEmpty(agentList)){

            List<DashBoardBetPlayersVo> list = new ArrayList<>();

            for (TAgentCustomers agent : agentList) {
                try {

                    if(Objects.isNull(agent)){
                        continue;
                    }
                    String agentAccount = agent.getLoginName();

                    //1.月类型 当月
                    DashBoardBetPlayersVo currentMonthVo = doHandleBetPlayers(agentAccount,currentMonthFirstDay,currentMonthLastDay);
                    if(!Objects.isNull(currentMonthVo)){
                        list.add(currentMonthVo);
                    }
                    //1.月类型 上月
                    DashBoardBetPlayersVo lastMonthVo = doHandleBetPlayers(agentAccount,lastMonthFirstDay,lastMonthLastDay);
                    if(!Objects.isNull(lastMonthVo)){
                        list.add(lastMonthVo);
                    }
                    //1.月类型 上上月
                    DashBoardBetPlayersVo last2MonthVo = doHandleBetPlayers(agentAccount,last2MonthFirstDay,last2MonthLastDay);
                    if(!Objects.isNull(last2MonthVo)){
                        list.add(last2MonthVo);
                    }
                    //1.周类型 当周
                    DashBoardBetPlayersVo currentWeekVo = doHandleBetPlayers(agentAccount,currentWeekFirstDay,currentWeekLastDay);
                    if(!Objects.isNull(currentWeekVo)){
                        list.add(currentWeekVo);
                    }
                    //1.周类型 上周
                    DashBoardBetPlayersVo lastWeekVo = doHandleBetPlayers(agentAccount,lastWeekFirstDay,lastWeekLastDay);
                    if(!Objects.isNull(lastWeekVo)){
                        list.add(lastWeekVo);
                    }
                    //1.周类型 上上周
                    DashBoardBetPlayersVo last2WeekVo = doHandleBetPlayers(agentAccount,last2WeekFirstDay,last2WeekLastDay);
                    if(!Objects.isNull(last2WeekVo)){
                        list.add(last2WeekVo);
                    }
                    //1.天类型 当天
                    DashBoardBetPlayersVo currentDayVo = doHandleBetPlayers(agentAccount,currentDay,currentDay);
                    if(!Objects.isNull(currentDayVo)){
                        list.add(currentDayVo);
                    }
                    //1.天类型 昨天
                    DashBoardBetPlayersVo LastDayVo = doHandleBetPlayers(agentAccount,yesterday,yesterday);
                    if(!Objects.isNull(LastDayVo)){
                        list.add(LastDayVo);
                    }
                    //1.天类型 前天
                    DashBoardBetPlayersVo Last2DayVo = doHandleBetPlayers(agentAccount,last2Day,last2Day);
                    if(!Objects.isNull(Last2DayVo)){
                        list.add(Last2DayVo);
                    }

                }catch (Exception e){
                    log.error("doHandleBetPlayers failed!",e);
                }

            }

            try {
                if(!CollectionUtils.isEmpty(list)){
                    list.forEach(betPlayersVo -> {
                        String key = Constants.BETPLAYERS_CACHE_PREFIX + betPlayersVo.getAgentAccount() + betPlayersVo.getRecordDateStart()+betPlayersVo.getRecordDateEnd();
                        String value = gson.toJson(betPlayersVo.getBetPlayers());
                        log.info("[doHandleBetPlayers]The cache key is:{},value is:{}",key,value);
                        redisUtil.setByTimeUnit(key, value, 61, TimeUnit.DAYS);
                    });
                }

            }catch (Exception e){
                log.error("[doHandleBetPlayers]Failed to save betPlayers data for level:{}",level,e);
            }

            log.info("[doHandleBetPlayers]finished to save betPlayers data for level:{}",level);
            level--;

            if(level > 0){
                doHandleBetPlayersByLevel(level,currentMonthFirstDay,currentMonthLastDay,lastMonthFirstDay,lastMonthLastDay,last2MonthFirstDay,last2MonthLastDay,currentWeekFirstDay,currentWeekLastDay,lastWeekFirstDay,lastWeekLastDay,last2WeekFirstDay,last2WeekLastDay,currentDay,yesterday,last2Day);
            }
        }

    }


    private DashBoardBetPlayersVo doHandleBetPlayers(String agentAccount, LocalDate recordDateStart, LocalDate recordDateEnd){

        log.info("doHandleBetPlayers for agent:{}, The params is recordDateStart:{},recordDateEnd:{}",agentAccount,recordDateStart.toString(),recordDateEnd.toString());

        List<String> agentTeam = userService.selectTeamUserNames(agentAccount);

        Long betPlayers = 0L;
        if(!CollectionUtils.isEmpty(agentTeam)){
            betPlayers = this.getBetPlayersFromCl(ClDashBoardCreateQueryReq.builder().agentAccount(agentAccount).loginNameList(agentTeam).recordDateStart(recordDateStart.toString())
                    .recordDateEnd(recordDateEnd.toString()).build());
        }

        if(null!=betPlayers && betPlayers > 0L){
            return DashBoardBetPlayersVo.builder().agentAccount(agentAccount).betPlayers(betPlayers).recordDateStart(recordDateStart.toString()).recordDateEnd(recordDateEnd.toString()).build();
        }
        log.info("[doHandleBetPlayers]The betPlayers for agent:{} from {} to {}  is:{} ", agentAccount,recordDateStart,recordDateEnd,betPlayers);
        return null;

    }

    private Long getBetPlayersFromCl(ClDashBoardCreateQueryReq queryReq){
        if(Objects.isNull(queryReq) || CollectionUtils.isEmpty(queryReq.getLoginNameList())){
            return null;
        }

        log.info("Begin to query BetPlayers for agent:{}",queryReq.getAgentAccount());

        List<String> userNames = queryReq.getLoginNameList();

        if (userNames.size() <= dashBoardConfig.getBatchQuerySize()) {
            return clDashBoardV1Mapper.getBetPlayersFromCl(queryReq);
        } else {

            List<List<String>> batches = Lists.partition(userNames, dashBoardConfig.getBatchQuerySize());

            Set<ClDashBoardCreateQueryReq> batchQuerys = batches.stream().map(b -> ClDashBoardCreateQueryReq.builder()
                    .loginNameList(b).recordDateStart(queryReq.getRecordDateStart()).recordDateEnd(queryReq.getRecordDateEnd())
                    .build()).collect(Collectors.toSet());

            Long response = batchQuerys.stream().map(q -> clDashBoardV1Mapper.getBetPlayersFromCl(q)).filter(a -> !Objects.isNull(a))
                    .reduce((r1, r2) -> r1 + r2).orElse(0L);
            return response;
        }
    }






}
