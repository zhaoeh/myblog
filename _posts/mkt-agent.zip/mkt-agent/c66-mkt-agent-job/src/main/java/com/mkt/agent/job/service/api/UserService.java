package com.mkt.agent.job.service.api;

import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.OrgCodeUpdateRequest;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerQueryResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @ClassName AgentService
 * @Author Amida
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
public interface UserService {

    List<TCustomerLayer> selectUserTree (String parent);

    List<String> selectDirectUsersAgentsName(String parent);

    DashBoardHistoryEntity selectRegisterUserCountByDay(ClDashBoardCreateQueryReq queryReq);

    Long selectRegisterUserCount(String parent, String recordDateTimeStart, String recordDateTimeEnd);

    List<String> selectTeamUserNames(String parent);
}
