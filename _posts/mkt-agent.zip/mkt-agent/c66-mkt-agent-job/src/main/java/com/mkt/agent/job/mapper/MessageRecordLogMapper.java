package com.mkt.agent.job.mapper;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.TAgentMessageRecord;
import com.mkt.agent.common.entity.TAgentMessageRecordLog;
import org.apache.ibatis.annotations.Mapper;

@Mapper
@TableName("message_record_log")
public interface MessageRecordLogMapper extends BaseMapper<TAgentMessageRecordLog> {
}
