package com.mkt.agent.job.job.task;

import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.common.entity.api.integration.bi.requests.UserSummerRequest;
import com.mkt.agent.common.entity.api.integration.bi.responses.CustUserSummerResponse;
import com.mkt.agent.common.entity.api.integration.bi.responses.UserSummerResponse;
import com.mkt.agent.common.entity.api.jobapi.responses.AgentDetails;
import com.mkt.agent.common.enums.GameTypeEnum;
import com.mkt.agent.common.enums.SettlementPeriodEnum;
import com.mkt.agent.job.job.process.CalculateCommissionHandler;
import com.mkt.agent.job.job.task.base.CommissionTask;
import com.mkt.agent.job.service.CommissionRecordService;
import com.mkt.agent.job.service.api.UserService;
import com.mkt.agent.job.service.task.customerplayinfo.base.CustomerPlayInfoCommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @Description: 佣金计算任务(按月计算 ; 所有游戏类型)
 * @Author: PTMinnisLi
 * @Date: 2023/7/20
 */
@Component
public class CommissionMonthByAllTask extends CommissionTask {

    @Autowired
    private CustomerPlayInfoCommonUtil customerPlayInfoCommonUtil;

    @Autowired
    private UserService userService;

    @Autowired
    private CalculateCommissionHandler calculateCommissionHandler;

    @Autowired
    private CommissionRecordService commissionRecordService;


    public synchronized Boolean call(AgentDetails currentAgent, SettlementPeriodEnum period, GameTypeEnum gameType) throws Exception {
        execute(currentAgent, period, gameType);
        return true;
    }

    @Override
    protected List<TCustomerLayer> readUserData(String loginName) {
        return userService.selectUserTree(loginName);
    }

    /**
     * 根据用户获取bi投注数据
     *
     * @param userSummerRequest bi请求体
     * @return 投注数据
     */
    @Override
    protected List<UserSummerResponse> readBiData(UserSummerRequest userSummerRequest) {
        return customerPlayInfoCommonUtil.getCustomerPlayInfo(userSummerRequest);
    }

    @Override
    protected List<AgentCommissionRecord> calculateCommission(AgentDetails agents, List<CustUserSummerResponse> summerResponse,int count,String levelOneAccount){
        return calculateCommissionHandler.commissionCalculate(agents,summerResponse,count,levelOneAccount);
    }

    @Override
    protected void saveRecords(List<AgentCommissionRecord> records) {
        try {
            commissionRecordService.saveCommissionRecordsByBatch(records);
        }catch (Exception e){
            e.printStackTrace();
        }

    }


}
