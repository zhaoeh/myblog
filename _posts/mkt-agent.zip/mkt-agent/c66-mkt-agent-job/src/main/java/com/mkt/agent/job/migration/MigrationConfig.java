package com.mkt.agent.job.migration;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @author Colson
 * @date 8/14/2023 11:11 AM
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Component
@RefreshScope
public class MigrationConfig {

    @Value("${mkt.agent.migration.generalContract}")
    private String generalContract;

    @Value("${mkt.agent.migration.professionalContract}")
    private String professionalContract;

}
