package com.mkt.agent.job.service.api.impl;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.jobapi.requests.AgentContractBindRequest;
import com.mkt.agent.common.entity.api.jobapi.responses.AgentContractBindResponse;
import com.mkt.agent.job.mapper.api.ContractBindMapper;
import com.mkt.agent.job.service.api.AgentContractBindService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Colson
 * @date 8/14/2023 5:46 PM
 */
@Slf4j
@Service
public class AgentContractBindServiceImpl implements AgentContractBindService {

    @Autowired
    private ContractBindMapper contractBindMapper;


    @Override
    public Long insertAgentContractBindTest(AgentContractBindRequest req) {
        contractBindMapper.insertContractBindTest(req);
        return req.getId();
    }

    @Override
    public List<AgentContractBindResponse> listAgentContractBindTest() {
       return contractBindMapper.listAgentContractBindTest();

    }

}
