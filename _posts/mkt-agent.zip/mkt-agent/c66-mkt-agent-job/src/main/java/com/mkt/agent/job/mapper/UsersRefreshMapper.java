package com.mkt.agent.job.mapper;

import com.baomidou.mybatisplus.annotation.TableName;
import com.mkt.agent.common.entity.TAgentRefreshLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
@TableName("t_agent_refresh_log")
public interface UsersRefreshMapper {

    int insertUsersGroupLog(@Param(value = "list") List<TAgentRefreshLog> list);

    String queryDateRangeList(@Param("param") TAgentRefreshLog queryReq);

    List<TAgentRefreshLog> queryLastTimeFailedRecords(@Param("param") TAgentRefreshLog queryReq);

    List<TAgentRefreshLog> queryList(@Param("param") TAgentRefreshLog queryReq);

    /**
     * 删除指定时间区间内的数据
     *
     * @param param
     * @return
     */
    int deleteUsersGroupLog(@Param("param") TAgentRefreshLog param);

    /**
     * 物理删除
     *
     * @param param
     * @return
     */
    int deleteUsersGroupLogWithForce(@Param("param") TAgentRefreshLog param);
}
