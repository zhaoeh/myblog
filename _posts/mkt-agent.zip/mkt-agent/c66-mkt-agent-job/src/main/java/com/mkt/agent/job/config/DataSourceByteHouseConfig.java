package com.mkt.agent.job.config;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.core.MybatisConfiguration;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import com.baomidou.mybatisplus.extension.spring.MybatisSqlSessionFactoryBean;
import com.mkt.agent.common.config.JdbcParamsConfig;
import com.mkt.agent.common.sql.LogOfSqlImpl;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import javax.annotation.Resource;
import java.util.Objects;

/**
 * @Description TODO
 * @Classname bytehouseConfig
 * @Date 2023/11/22 12:22
 * @Created by TJSLucian
 */
@Configuration
@MapperScan(sqlSessionFactoryRef = "bytehouseSqlSessionFactory", basePackages = {"com.mkt.agent.job.clickhouse.mapper"})
public class DataSourceByteHouseConfig {

    @Resource
    private JdbcParamsConfig jdbcParamsConfig ;

    @Value("${spring.datasource.third.username}")
    private String userName;
    @Value("${spring.datasource.third.apiKey}")
    private String apiKey;
    @Value("${spring.datasource.third.url}")
    private String url;
    @Value("${spring.datasource.third.poolName}")
    private String poolName;
    @Value("${spring.datasource.third.driver-class-name}")
    private String driverClassName;
    @Value("${sqlLog.agent-job.bytehouse:0}")
    private Integer bLogImpl;

    @Bean("bytehouseMybatisPlusInterceptor")
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor mybatisPlusInterceptor = new MybatisPlusInterceptor();
        mybatisPlusInterceptor.addInnerInterceptor(new PaginationInnerInterceptor(DbType.CLICK_HOUSE));
        return mybatisPlusInterceptor;
    }

    @Bean("byteHouseDataSource")
    public HikariDataSource hikariDataSource(){
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setDriverClassName(driverClassName);
        hikariConfig.setJdbcUrl(url);
        hikariConfig.setUsername(userName);
        hikariConfig.setPassword(apiKey);
        hikariConfig.setConnectionTimeout(jdbcParamsConfig.getConnectionTimeout());
        hikariConfig.setIdleTimeout(jdbcParamsConfig.getIdleTimeout());
        hikariConfig.setMaximumPoolSize(jdbcParamsConfig.getMaxPoolSize());
        hikariConfig.setMinimumIdle(jdbcParamsConfig.getMinIdle());
        hikariConfig.setMaxLifetime(jdbcParamsConfig.getMaxLifetime());
        hikariConfig.setPoolName(poolName);
        return new HikariDataSource(hikariConfig);
    }

    @Bean("bytehouseSqlSessionFactory")
    public SqlSessionFactory clickhouseSqlSessionFactory(@Qualifier("byteHouseDataSource")HikariDataSource hikariDataSource, @Qualifier("bytehouseMybatisPlusInterceptor") MybatisPlusInterceptor bytehouseMybatisPlusInterceptor) throws Exception {
        MybatisSqlSessionFactoryBean bean = new MybatisSqlSessionFactoryBean();
        bean.setDataSource(hikariDataSource);
        bean.setTypeAliasesPackage("com.mkt.agent.common.entity.clickhouse.**");
        bean.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:clickhouseMapper/*.xml"));
        bean.setPlugins(bytehouseMybatisPlusInterceptor);

        MybatisConfiguration configuration = new MybatisConfiguration();
        configuration.setMapUnderscoreToCamelCase(true);

        if(Objects.nonNull(bLogImpl) && bLogImpl.equals(1)){
            LogOfSqlImpl.setLogger("com.mkt.agent.job.clickhouse.mapper");
            configuration.setLogImpl(LogOfSqlImpl.class);
        }
        configuration.setCacheEnabled(false);
        bean.setConfiguration(configuration);

        SqlSessionFactory factory = bean.getObject();

        return factory;
    }
}
