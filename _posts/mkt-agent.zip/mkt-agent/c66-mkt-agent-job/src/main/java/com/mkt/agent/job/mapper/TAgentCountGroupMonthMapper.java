package com.mkt.agent.job.mapper;


import com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonth;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description TODO
 * @Classname TAgentCountGroupMonthMapper
 * @Date 2024/2/1 16:58
 * @Created by TJSLucian
 */
@Mapper
public interface TAgentCountGroupMonthMapper extends BatchBaseMapper<TAgentCountGroupMonth> {

    List<TAgentCountGroupMonth> getDownlineAgentsData(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    Integer deleteByLevelNMonth(@Param("level") Integer level, @Param("month") String month);

}
