package com.mkt.agent.job.mapper;

import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.transaction.annotation.Transactional;


@Mapper
@Transactional
public interface DashBoardHistoryByDayMapper extends BatchBaseMapper<DashBoardHistoryEntity> {


    DashBoardHistoryEntity getOneByDate(String date);

    int isNeedHandledForLastMonth(@Param("recordDateStart") String recordDateStart, @Param("recordDateEnd")String recordDateEnd);


    DashBoardHistoryEntity queryLocalDataByPeriod(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

}
