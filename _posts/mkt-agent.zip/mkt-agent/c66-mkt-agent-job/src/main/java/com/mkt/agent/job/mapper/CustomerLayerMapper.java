package com.mkt.agent.job.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cn.schema.customers.WSCustomers;
import com.mkt.agent.common.entity.TAgentMessageRecordLog;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.jobapi.requests.CustomerLayerTestRequest;
import com.mkt.agent.common.entity.api.jobapi.responses.CustomerLayerResponse;
import com.mkt.agent.job.entity.AgentCustomerDBA;
import com.mkt.agent.job.req.BasePageQuery;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Mapper
@Transactional
public interface CustomerLayerMapper extends BaseMapper<TCustomerLayer> {

    void saveBatchTest(@Param("list") List<WSCustomers> WSCustomersList);


    Integer getAgentLevelByLoginNameTest(String loginName);

    Integer getDevLevelByLoginNameTest(String loginName);

    /**
     * 查询未初始化的代理Test表*
     *
     * @return
     */
    List<CustomerLayerResponse> listInitAgentCustomerLayerTest(@Param("req") CustomerLayerTestRequest req);

    /**
     * *
     *
     * @param loginName
     * @return 用户名
     */
    Integer countDevAgentTest(String loginName);


    void updateFlagAndCustomerTypeTest(CustomerLayerTestRequest req);

}
