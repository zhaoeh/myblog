package com.mkt.agent.job.req;

import com.baomidou.mybatisplus.annotation.TableName;
import com.mkt.agent.common.entity.BaseOperationEntity;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;

/**
 * @ClassName TAgentCustomers
 * @Description 代理客户
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@EqualsAndHashCode(callSuper = true)
@TableName("t_agent_customers")
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@SuperBuilder
@Data
public class TAgentCustomers extends BaseOperationEntity {

    /*
        客户id
    */
    @Column(name="CUSTOMERS_ID",nullable = false)
    private Long customersId;

    /*
        登录名
    */
    @Column(name="LOGIN_NAME",nullable = false)
    private String loginName;

    /*
        产品
   */
    @Column(name="PRODUCT_ID",nullable = false)
    private String productId;

    /*
        佣金方案code
    */
    @Column(name="COMMISSION_CONTRACT_BIND_ID",nullable = false)
    private Long commissionContractBindId;

    /*
        父级代理
   */
    @Column(name="PARENT_ID",nullable = false)
    private Long parentId;

    /*
         创建人
    */
    @Column(name="PARENT_NAME",nullable = false)
    private String parentName;

    /*
        代理类型 0:普通 1:专业代理
    */
    @Column(name="AGENT_TYPE")
    private Integer agentType;

    /*
        代理级别
    */
    @Column(name="AGENT_LEVEL",nullable = false)
    private Integer agentLevel = 1;

    /*
        代理可以发展最大下级代理层数
    */
    @Column(name="DEVELOPABLE_LEVEL",nullable = false)
    private Integer developableLevel;

    /*
        是否启用标识 0禁用，1启用
    */
    @Column(name="is_enable",nullable = false)
    private Integer isEnable=1;


    /*
        siteId 1:Bingoplus  2:Arenaplus
    */
    @Column(name="site_id")
    private Integer siteId;


    @Override
    public String toString() {
        return "TAgentCustomers{" +
                "id=" + getId() +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", createBy='" + createBy + '\'' +
                ", updateBy='" + updateBy + '\'' +
                ", isDeleted=" + isDeleted +
                ", remarks='" + remarks + '\'' +
                ", customersId=" + customersId +
                ", loginName='" + loginName + '\'' +
                ", productId='" + productId + '\'' +
                ", commissionContractBindId=" + commissionContractBindId +
                ", parentId=" + parentId +
                ", parentName='" + parentName + '\'' +
                ", agentType=" + agentType +
                ", agentLevel=" + agentLevel +
                ", developableLevel=" + developableLevel +
                ", isEnable=" + isEnable +
                ", remarks='" + remarks + '\'' +
                ", siteId=" + siteId +
                '}';
    }
}
