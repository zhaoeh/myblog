package com.mkt.agent.job.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import com.mkt.agent.common.entity.api.jobapi.table.DailyMktAgentAll;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface LocalDailyMktAgentAllMapper extends BaseMapper<DailyMktAgentAll> {

    Integer batchDailyMktAgentAllInsert(@Param("list") List<DailyMktAgentAll> dailyMktAgentAllList);

    int selectPartitionCount(@Param("partitionName") String partitionName);

    int deleteByDay(@Param("dayStr") String dayStr);

    long count();
}
