package com.mkt.agent.job.service.impl.commission;

import com.alibaba.nacos.common.utils.MD5Utils;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.gson.Gson;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractList;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.common.entity.clickhouse.resp.ClDashBoardDataRes;
import com.mkt.agent.common.enums.CommissionRecordStatusEnum;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.NumberUtils;
import com.mkt.agent.common.utils.RedisUtil;
import com.mkt.agent.job.clickhouse.mapper.TDailyOrderMapper;
import com.mkt.agent.job.mapper.CommissionRecordMapper;
import com.mkt.agent.job.mapper.TAgentContractBindMapper;
import com.mkt.agent.job.mapper.TAgentContractListMapper;
import com.mkt.agent.job.mapper.TAgentContractMapper;
import com.mkt.agent.job.mapper.api.UserMapper;
import com.mkt.agent.job.req.CommissionValues;
import com.mkt.agent.job.req.TAgentCustomers;
import com.mkt.agent.job.service.CommissionRecordService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;


@Service
@Slf4j
public class CommissionRecordServiceImpl extends ServiceImpl<CommissionRecordMapper, AgentCommissionRecord> implements CommissionRecordService {

    @Autowired
    private TAgentContractMapper agentContractMapper ;
    @Autowired
    private CommissionRecordMapper commissionRecordMapper;
@Autowired
    private RedisUtil redisUtil;

    /**
     * @param entityList
     */
    @Override
    public Integer saveCommissionRecordsByBatch(List<AgentCommissionRecord> entityList) {

        if (CollectionUtils.isEmpty(entityList)) {
            return 0;
        }
        return commissionRecordMapper.insertBatchSomeColumn(entityList);
    }

    private CommissionValues calcCommissionDataByGgr( TAgentCustomers agentCustomers, TAgentContract agentContract, List<TAgentContractList> lists,Map<String,Object> parame) {


        CommissionValues commissionValues = new CommissionValues()  ;
        commissionValues.setYj(BigDecimal.ZERO);

        String  isFd =   agentContract.getIsFd();
        int settlementConditions =   agentContract.getSettlementConditions();


        Map<String,Object>  byteHouseData  =   new HashMap<>();

        byteHouseData  =    getByteHouseData1(agentCustomers.getLoginName(),agentContract, parame );

        commissionValues.setTurnover(new BigDecimal(byteHouseData.get("turnover").toString()));
        commissionValues.setDeposit(new BigDecimal(byteHouseData.get("depositAmount").toString()));
        commissionValues.setGgr(new BigDecimal(byteHouseData.get("ggr").toString()));
        commissionValues.setWinOrLoss(new BigDecimal(byteHouseData.get("winOrLoss").toString()));
        commissionValues.setWithdrawal(new BigDecimal(byteHouseData.get("withdrawalAmount").toString()));
        commissionValues.setSumactiveUser(Integer.valueOf(byteHouseData.get("sumactiveUser").toString()));
        commissionValues.setList((List<TCustomerLayer>) byteHouseData.get("customerLayers"));

        BigDecimal ggr  =    new BigDecimal(byteHouseData.get("ggr").toString());

        BigDecimal  yj  =  BigDecimal.ZERO ;
        if(ggr.doubleValue() <=0) {
            return  commissionValues  ;
        }
        if(!StringUtils.isBlank(isFd) && isFd.equals("1")  ){

            //勾选 FD 和活跃用户指标  需要获取 Turnover  ,active User 满足情况
            int fdCount  =agentContract.getFdCount();
            int  sc =    Integer.valueOf(byteHouseData.get("sc").toString());

            if(sc <= fdCount) {
                //
                commissionValues.setBl(agentContract.getFdCommission());
                yj  =  ggr.multiply(agentContract.getFdCommission()).divide(new BigDecimal(100));
            }else if(      settlementConditions  ==  1){

                int activeUser =    agentContract.getActiveUserHeadcount() ;
                int sumactiveUser  = Integer.valueOf(byteHouseData.get("sumactiveUser").toString()) ;

                if(sumactiveUser >=   activeUser  ){
                    //开始 计算佣金
                    commissionValues.setBl(agentContract.getActiveUserCommission());

                    yj  =  ggr.multiply(agentContract.getActiveUserCommission()).divide(new BigDecimal(100));

                }else {

                }
            }else if(lists.size() >  0   &&   lists.get(0).getIsChecked().equals("1")){

                TAgentContractList getIndex =   getIndexData(lists,ggr);

                if (getIndex != null ) {
                    commissionValues.setBl(getIndex.getCommission());

                    yj  =  ggr.multiply(getIndex.getCommission()).divide(new BigDecimal(100));

                }
            }


        } else  if(settlementConditions  ==  1) {
            //  仅勾选active user

            int activeUser =    agentContract.getActiveUserHeadcount() ;
            int sumactiveUser  = Integer.valueOf(byteHouseData.get("sumactiveUser").toString()) ;

            if(sumactiveUser >=   activeUser  ){
                //开始 计算佣金
                commissionValues.setBl(agentContract.getActiveUserCommission());

                yj  =  ggr.multiply(agentContract.getActiveUserCommission()).divide(new BigDecimal(100));

            }

        }else if(lists.size() >  0   &&   lists.get(0).getIsChecked().equals("1")){
            TAgentContractList getIndex =   getIndexData(lists,ggr);

            if (getIndex != null ) {

                commissionValues.setBl(getIndex.getCommission());

                yj  =  ggr.multiply(getIndex.getCommission()).divide(new BigDecimal(100));

            }
        }

        yj  = NumberUtils.twoScaleFormat(yj);

        commissionValues.setYj(yj);


        return  commissionValues ;

    }


    private String getHashCode(String loginName, String startDate) {
        String res = loginName + startDate;
        try {
            return MD5Utils.md5Hex(res.getBytes()) ;
        }catch (Exception e) {
            return   res  ;
        }
    }


    @Override
    public Map<String, Object> calcCommissionData(TAgentCustomers agentCustomers, Map<String, Object> parame) {

            // 获取佣金需求
            Map<String,Object> result =  new HashMap<>() ;

//        Map<String,String> parame = new HashMap<>();
            parame.put("id",agentCustomers.getCommissionContractBindId() + "") ;

            String  startDate =   parame.get("startDate").toString() ;
            String  endDate =   parame.get("endDate").toString() ;
            String sutff  = startDate + endDate;
            String  sutffLost =  startDate + endDate + "_lost";

            String topKey =    agentCustomers.getLoginName() +  sutff;
            String topKeyLost =    agentCustomers.getLoginName() +  sutffLost;

            if (redisUtil.get(topKeyLost) != null  &&  parame.get("isSave").equals("-1") ){
                 return   result  ;
            }



            TAgentContract agentContract   =  agentContractMapper.selectByIdParame(parame) ;

            log.info("佣金明细为={},参数为={}",agentContract,parame);

            if(agentContract!= null)  {
                //获取佣金明细
                Map<String, Object> parame2 =new HashMap<>();
                parame2.put("contract_id",agentContract.getId() +"" );
                List<TAgentContractList>  lists   =  tAgentContractListMapper.selectByMap(parame2) ;



                CommissionValues  commissionValues  = new CommissionValues() ;
                if(agentContract.getCommissionPlanType().equals("TURNOVER")){
                    commissionValues = calcCommissionDataByTurnover(agentCustomers,agentContract,lists,parame);
                }else {

                    commissionValues =   calcCommissionDataByGgr(agentCustomers,agentContract,lists,parame);

                }

                log.info("佣金为={}",new Gson().toJson(commissionValues));

                // 开始 一级保存佣金

//        commissionRecordMapper.insert(obj);

                if(commissionValues.getYj().doubleValue() >  0) {
                    AgentCommissionRecord tops = new AgentCommissionRecord();
                    tops.setCustomerId(agentCustomers.getCustomersId());
                    tops.setParentId(agentCustomers.getParentId());
                    tops.setAgentAccount(agentCustomers.getLoginName());
                    tops.setLevel1AgentAccount(agentCustomers.getLoginName());
                    tops.setAgentType(agentCustomers.getAgentType());
                    tops.setParentAccount(agentCustomers.getParentName());
                    tops.setSiteId(agentCustomers.getSiteId());
                    tops.setHashCode(getHashCode(agentCustomers.getLoginName(),parame.get("startDate").toString().substring(0,7)));
                    tops.setAgentLevel(agentCustomers.getAgentLevel());
                    tops.setSettlementConditions(agentContract.getSettlementConditions());
                    tops.setActiveUserTurnover(agentContract.getActiveUserTurnover1());
                    tops.setActiveUserHeadcount(agentContract.getActiveUserHeadcount());
//        tops.seto
                    tops.setActualUserCount(commissionValues.getSumactiveUser());
                    tops.setCommissionValues("ALL_GAME_TYPES");
                    tops.setPercentageDetails(agentContract.getPercentageDetails());
//        commission_plan_name
                    tops.setCommissionPlanName(agentContract.getCommissionPlanName());
                    tops.setCommissionPlanId(agentContract.getId());
                    tops.setCommissionType(agentContract.getCommissionPlanType());
                    tops.setCommissionValue(NumberUtils.twoScaleFormat(commissionValues.getBl().divide(new BigDecimal(100))));
                    //settlement_period
                    tops.setSettlementPeriod(agentContract.getSettlementPeriod());
                    tops.setStatus(agentCustomers.getAgentLevel() == 1 ? CommissionRecordStatusEnum.FIRST_PENDING.getValue() : CommissionRecordStatusEnum.UNPAID.getValue());
                    tops.setCommissionAmount(commissionValues.getYj());
                    tops.setActualCommissionAmount(BigDecimal.ZERO);
                    tops.setAppendCommissionAmount(BigDecimal.ZERO);
                    tops.setCurrency(BaseConstants.PHP);
                    tops.setGGR(commissionValues.getGgr());
                    tops.setTurnover(commissionValues.getTurnover());
                    tops.setWinOrLoss(commissionValues.getWinOrLoss());
                    tops.setDeposit(commissionValues.getDeposit());
                    tops.setWithdrawal(commissionValues.getWithdrawal());
                    tops.setSettleDateStart(DateUtils.getLastMonthFirstDay());
                    tops.setSettleDateEnd(DateUtils.getLastMonthLastDayV1());

                    redisUtil.set(topKey,tops.getCommissionAmount()) ;
                    redisUtil.set(topKeyLost,tops.getCommissionAmount()) ;
                    redisUtil.setExpire(topKeyLost,expireLongTime);



                    tops.setCreatedBy(BaseConstants.SYSTEM);
                    if (!parame.get("isSave").equals("-1")) {
                        commissionRecordMapper.insert(tops);

                    }

                    saveDailiData(agentContract,parame,agentCustomers);

                    if (!parame.get("isSave").equals("-1")) {

                        //查找 符合条件玩家记录
                        savePalyerUser(commissionValues.getList(), agentContract, parame, agentCustomers);
                    }
                    // 开始保存代理数据

                    //查询 我的代理数据




                }else {
                    redisUtil.set(topKey,0) ;
                    redisUtil.set(topKeyLost,0) ;
                    redisUtil.setExpire(topKeyLost,expireLongTime);
                }
            }





            return  result ;




     }


    private void savePalyerUser(List<TCustomerLayer> list, TAgentContract agentContract, Map<String, Object> parame,  TAgentCustomers tAgentCustomers) {
        String startDate  = parame.get("startDate").toString() ;
        String endDate  = parame.get("endDate").toString() ;

        Map<String,TCustomerLayer> tempData = new HashMap<>() ;
        for(TCustomerLayer customerLayer : list){

            tempData.put(customerLayer.getLoginName(),customerLayer) ;
        }

        Map<String,Object> map = new HashMap<>() ;
        map.put("min", startDate);
        map.put("max", endDate);
        if (agentContract.getSettlementConditions() ==1 ){
            //显示活跃数据 按要求显示数据
            map.put("activeUserTurnover", agentContract.getActiveUserTurnover());
        }


        List<String> payers = list.stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList());


        List<List<String>> splitLists = splitArrayList(payers, splitRow);



        for (List<String> sublist : splitLists) {
            map.put("loginName", sublist);

            List<ClDashBoardDataRes> listData = tDailyOrderMapper.getNewAllDataNew2(map);   //  查询 bytehouse 数据

            if(listData.size() >  0 ) {

                for(ClDashBoardDataRes dashBoardDataRes : listData){

                    TCustomerLayer  tCustomerLayer  =  tempData.get(dashBoardDataRes.getLoginName());

                    AgentCommissionRecord tops = new AgentCommissionRecord();
                    tops.setCustomerId(tCustomerLayer.getCustomerId());
                    tops.setParentId(tCustomerLayer.getParentId());
                    tops.setAgentAccount(tCustomerLayer.getLoginName());
                    tops.setLevel1AgentAccount(tAgentCustomers.getLoginName());
                    tops.setAgentType(3);
                    tops.setParentAccount(tCustomerLayer.getParentLoginName());
                    tops.setSiteId(tCustomerLayer.getSiteId());
                    tops.setHashCode(getHashCode(tCustomerLayer.getLoginName(),parame.get("startDate").toString().substring(0,7)));
                    tops.setCommissionValues("ALL_GAME_TYPES");
//        commission_plan_name
                    tops.setCurrency(BaseConstants.PHP);
                    tops.setGGR(dashBoardDataRes.getGgr());
                    tops.setTurnover(dashBoardDataRes.getTurnover1());
                    tops.setWinOrLoss(dashBoardDataRes.getWinOrLoss());
                    tops.setDeposit(dashBoardDataRes.getDepositAmount());
                    tops.setWithdrawal(dashBoardDataRes.getWithdrawalAmount());
                    tops.setSettleDateStart(DateUtils.getLastMonthFirstDay());
                    tops.setSettleDateEnd(DateUtils.getLastMonthLastDayV1());
                    tops.setCreatedBy(BaseConstants.SYSTEM);
                    try {
                        commissionRecordMapper.insert(tops);
                    }catch (Exception e) {

                    }

                }




            }




        }



    }

    @Autowired
    private TAgentContractBindMapper tAgentContractBindMapper  ;

     @Autowired
     private UserMapper userMapper ;

    private void saveDailiData(TAgentContract agentContract, Map<String, Object> parame,  TAgentCustomers agentCustomers) {

        // 先找2级



        Map<String, Object> maps   = new HashMap<>();
        maps.put("parent_id",  agentCustomers.getCustomersId()) ;
        List< TAgentCustomers> list=    userMapper.listTopAgent(maps) ;

        //  开始计算下级数据
        for( TAgentCustomers customers :  list) {
            //查看佣金比例
            Map<String, Object> parame2  =   new HashMap<>();

            String  startDate =   parame.get("startDate").toString() ;
            String  endDate =   parame.get("endDate").toString() ;
            String sutff  = startDate + endDate;
            String  sutffLost =  startDate + endDate + "_lost";

            String topKey =    customers.getLoginName() +  sutff;
            String topKeyLost =    customers.getLoginName() +  sutffLost;

            parame2.put("login_name",customers.getLoginName());
            List<TAgentContractBind> contractBindList =    tAgentContractBindMapper.selectByMap(parame2) ;

            if(contractBindList.size() >   0 ) {
                TAgentContractBind tAgentContractBind   =  contractBindList.get(0) ;

                if(StringUtils.isBlank(tAgentContractBind.getPercentageDetails())){
                    continue;
                }
                JSONArray jsonArray =    new JSONArray(tAgentContractBind.getPercentageDetails()) ;

                if(jsonArray.length() >  0 ) {
                    JSONObject object =  jsonArray.getJSONObject(0) ;

                    if(!object.has("allGamesPercentage")){
                        continue;
                    }

                    BigDecimal  allGamesPercentage  =  object.getBigDecimal("allGamesPercentage") ;
                    // 开始计算

                    Map<String, Object> byteHouseData = getByteHouseData1(customers.getLoginName(), null, parame);


                    AgentCommissionRecord tops = new AgentCommissionRecord();
                    tops.setCustomerId(customers.getCustomersId());
                    tops.setParentId(customers.getParentId());
                    tops.setAgentAccount(customers.getLoginName());
                    tops.setLevel1AgentAccount(agentCustomers.getLoginName());
                    tops.setAgentType(1);
                    tops.setParentAccount(customers.getParentName());
                    tops.setSiteId(customers.getSiteId());
                    tops.setHashCode(getHashCode(customers.getLoginName(),parame.get("startDate").toString().substring(0,7)));
                    tops.setAgentLevel(customers.getAgentLevel());
                    tops.setSettlementConditions(agentContract.getSettlementConditions());
                    tops.setActiveUserTurnover(agentContract.getActiveUserTurnover1());
                    tops.setActiveUserHeadcount(agentContract.getActiveUserHeadcount());
//        tops.seto
                    tops.setCommissionValues("ALL_GAME_TYPES");
                    tops.setPercentageDetails(agentContract.getPercentageDetails());
//        commission_plan_name
                    tops.setCommissionPlanName(agentContract.getCommissionPlanName());
                    tops.setCommissionPlanId(agentContract.getId());
                    tops.setCommissionType(agentContract.getCommissionPlanType());
                    tops.setCommissionValue(NumberUtils.twoScaleFormat(allGamesPercentage.divide(new BigDecimal(100))));
                    //settlement_period
                    tops.setSettlementPeriod(agentContract.getSettlementPeriod());
                    tops.setStatus(customers.getAgentLevel() == 1 ? CommissionRecordStatusEnum.FIRST_PENDING.getValue() : CommissionRecordStatusEnum.UNPAID.getValue());
                    tops.setGGR(new BigDecimal(byteHouseData.get("ggr").toString()));
                    tops.setTurnover(new BigDecimal(byteHouseData.get("turnover").toString()));
                    tops.setWinOrLoss(new BigDecimal(byteHouseData.get("winOrLoss").toString()));
                    tops.setDeposit(new BigDecimal(byteHouseData.get("depositAmount").toString()));
                    tops.setWithdrawal(new BigDecimal(byteHouseData.get("withdrawalAmount").toString()));
                    tops.setSettleDateStart(DateUtils.getLastMonthFirstDay());
                    tops.setSettleDateEnd(DateUtils.getLastMonthLastDayV1());
                    if(agentContract.getCommissionPlanType().equals("TURNOVER")){
                        tops.setCommissionAmount(NumberUtils.twoScaleFormat(tops.getTurnover().multiply(allGamesPercentage).divide(new BigDecimal(100))));
                    }else {
                        //查看上级佣金
                        String parentKey =  customers.getParentName() +  sutff ;
                        Object money = redisUtil.get(parentKey);//上级佣金
                        Double m = 0D;
                        if(money != null   &&  !StringUtils.isBlank(money.toString())){
                            m  = Double.valueOf(money.toString()) ;
                        }


                        if(tops.getGGR().doubleValue() > 0  &&  m >  0  ) {


                            tops.setCommissionAmount(NumberUtils.twoScaleFormat(tops.getGGR().multiply(allGamesPercentage).divide(new BigDecimal(100))));
                        }else {
                            tops.setCommissionAmount((BigDecimal.ZERO));
                        }
                    }
                    redisUtil.set(topKey,tops.getCommissionAmount()) ;
                    redisUtil.set(topKeyLost,tops.getCommissionAmount()) ;
                    redisUtil.setExpire(topKeyLost,expireLongTime);
                    tops.setActualCommissionAmount(BigDecimal.ZERO);
                    tops.setAppendCommissionAmount(BigDecimal.ZERO);
                    tops.setCurrency(BaseConstants.PHP);

                    tops.setCreatedBy(BaseConstants.SYSTEM);


                    if (!parame.get("isSave").equals("-1")) {

                        commissionRecordMapper.insert(tops);
                    }
                    if(customers.getAgentLevel() != 5   ){
                        maps   = new HashMap<>();
                        maps.put("parent_id",  customers.getCustomersId()) ;

                        saveDailiData(agentContract,parame,customers);

                    }

                }

            }


        }




    }

    @Autowired
    private TAgentContractListMapper tAgentContractListMapper;


    @Value("${tempReport.expireLongTime:900}") //半小时
    private Long expireLongTime;


    @Override
    public void updatePlayerStatus(Map<String, String> req) {

    }

    private <T> List<List<T>> splitArrayList(List<T> list, int splitSize) {
        List<List<T>> subLists = new ArrayList<>();
        for (int i = 0; i < list.size(); i += splitSize) {
            int endIndex = Math.min(i + splitSize, list.size());
            subLists.add(list.subList(i, endIndex));
        }
        return subLists;
    }

    @Autowired
    private TDailyOrderMapper tDailyOrderMapper ;


    @Value("${tempReport.splitRow:6500}") //
    private Integer splitRow;

    private Map<String, Object> getByteHouseData1(String loginName, TAgentContract agentContract, Map<String, Object> parame) {
        Map<String, Object> data  =  new HashMap<>() ;
        List<ClDashBoardDataRes> subData = new ArrayList<>();


        String startDate  = parame.get("startDate").toString() ;
        String endDate  = parame.get("endDate").toString() ;
        int  sumactiveUser = 0  ;

        try{
            List<TCustomerLayer>  list = userMapper.selectUserTreeByParentNTime(loginName,null,null) ;

            data.put("customerLayers",list);

            List<String> payers = list.stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList());


            List<List<String>> splitLists = splitArrayList(payers, splitRow);



            for (List<String> sublist : splitLists) {

                Map<String,Object>  p = new HashMap<>() ;

                p.put("loginName", sublist);
                p.put("min", startDate);
                p.put("max", endDate);


                List<ClDashBoardDataRes> listData = tDailyOrderMapper.getNewAllDataNew33(p);   //  查询 bytehouse 数据

                subData.addAll(listData);

                if(agentContract != null     &&  agentContract.getSettlementConditions() ==1){
                    p.put("activeUserTurnover", agentContract.getActiveUserTurnover1());
                    sumactiveUser   =  sumactiveUser +      tDailyOrderMapper.getActiveUserTurnoverCount(p);
                }

            }





        }catch (Exception e) {
            e.printStackTrace();
        }


        BigDecimal turnover   =   (BigDecimal.ZERO) ;
        BigDecimal ggr   =   (BigDecimal.ZERO) ;
        int  sc =   0;
        BigDecimal  winOrLoss  = BigDecimal.ZERO ;
        BigDecimal depositAmount   =   BigDecimal.ZERO ;
        BigDecimal withdrawalAmount  =  BigDecimal.ZERO ;

        for(ClDashBoardDataRes res :  subData){
            turnover  =  turnover.add(res.getTurnover1());
            ggr   =  ggr.add(res.getGgr()) ;
            winOrLoss   =  winOrLoss.add(res.getWinOrLoss()) ;
            depositAmount   =  depositAmount.add(res.getDepositAmount()) ;
            withdrawalAmount   =  withdrawalAmount.add(res.getWithdrawalAmount()) ;
            sc = sc +  res.getFirstDeposit().intValue();
        }


        data.put("turnover",turnover) ;
        data.put("ggr",ggr) ;
        data.put("sc",sc) ;
        data.put("winOrLoss",winOrLoss) ;
        data.put("depositAmount",depositAmount) ;
        data.put("withdrawalAmount",withdrawalAmount) ;
        data.put("sumactiveUser",sumactiveUser) ;


        return  data;
    }

    private CommissionValues calcCommissionDataByTurnover( TAgentCustomers agentCustomers, TAgentContract agentContract, List<TAgentContractList> lists,Map<String,Object> parame) {


        CommissionValues commissionValues =new CommissionValues();

        commissionValues.setYj(BigDecimal.ZERO);

        String  isFd =   agentContract.getIsFd();
        int settlementConditions =   agentContract.getSettlementConditions();

//        commissionValues

        Map<String,Object>  byteHouseData;

         byteHouseData  =    getByteHouseData1(agentCustomers.getLoginName(),agentContract, parame );

        /**
         * data.put("turnover",turnover) ;
         *         data.put("ggr",ggr) ;
         *         data.put("sc",sc) ;
         *         data.put("winOrLoss",winOrLoss) ;
         *         data.put("depositAmount",depositAmount) ;
         *         data.put("withdrawalAmount",withdrawalAmount) ;
         */
        commissionValues.setTurnover(new BigDecimal(byteHouseData.get("turnover").toString()));
        commissionValues.setDeposit(new BigDecimal(byteHouseData.get("depositAmount").toString()));
        commissionValues.setGgr(new BigDecimal(byteHouseData.get("ggr").toString()));
        commissionValues.setWinOrLoss(new BigDecimal(byteHouseData.get("winOrLoss").toString()));
        commissionValues.setWithdrawal(new BigDecimal(byteHouseData.get("withdrawalAmount").toString()));
        commissionValues.setSumactiveUser(Integer.valueOf(byteHouseData.get("sumactiveUser").toString()));
        BigDecimal turnover  =    new BigDecimal(byteHouseData.get("turnover").toString());
        commissionValues.setList((List<TCustomerLayer>) byteHouseData.get("customerLayers"));

        BigDecimal  yj  =  BigDecimal.ZERO ;
        if(!StringUtils.isBlank(isFd) && isFd.equals("1")  ){
            int fdCount  =agentContract.getFdCount();
            int  sc =    Integer.valueOf(byteHouseData.get("sc").toString());



             if(sc <= fdCount) {
                //
                commissionValues.setBl(agentContract.getFdCommission());

                yj  =  turnover.multiply(agentContract.getFdCommission()).divide(new BigDecimal(100));

            }else if(   settlementConditions  ==  1){

                int activeUser =    agentContract.getActiveUserHeadcount() ;
                int sumactiveUser  = Integer.valueOf(byteHouseData.get("sumactiveUser").toString()) ;

                if(sumactiveUser >=   activeUser  ){
                    //开始 计算佣金
                    commissionValues.setBl(agentContract.getActiveUserCommission());

                    yj  =  turnover.multiply(agentContract.getActiveUserCommission()).divide(new BigDecimal(100));

                }
            }else if(lists.size() >  0   &&   lists.get(0).getIsChecked().equals("1")){

                TAgentContractList getIndex =   getIndexData(lists,turnover);

                if (getIndex != null ) {
                    commissionValues.setBl(getIndex.getCommission());

                    yj  =  turnover.multiply(getIndex.getCommission()).divide(new BigDecimal(100));

                }
            }


        } else  if(settlementConditions  ==  1) {
            //  仅勾选active user

            int activeUser =    agentContract.getActiveUserHeadcount() ;
            int sumactiveUser  = Integer.valueOf(byteHouseData.get("sumactiveUser").toString()) ;

            if(sumactiveUser >=   activeUser  ){
                //开始 计算佣金
                commissionValues.setBl(agentContract.getActiveUserCommission());

                yj  =  turnover.multiply(agentContract.getActiveUserCommission()).divide(new BigDecimal(100));

            }

        }else if(lists.size() >  0   &&   lists.get(0).getIsChecked().equals("1")){
             TAgentContractList getIndex =   getIndexData(lists,turnover);

            if (getIndex != null ) {
                commissionValues.setBl(getIndex.getCommission());

                yj  =  turnover.multiply(getIndex.getCommission()).divide(new BigDecimal(100));

            }
        }
        yj  = NumberUtils.twoScaleFormat(yj);

         commissionValues.setYj(yj);
        return   commissionValues  ;

    }

    private TAgentContractList getIndexData(List<TAgentContractList> lists, BigDecimal turnover) {

        TAgentContractList result = null ;

        Collections.sort(lists, new Comparator<TAgentContractList>() {
            @Override
            public int compare(TAgentContractList o1, TAgentContractList o2) {
                return o1.getTurnoverGgr().intValue() -  o2.getTurnoverGgr().intValue();
            }
        });


        for(TAgentContractList tAgentContractList : lists){

            if(turnover.doubleValue() <=  tAgentContractList.getTurnoverGgr().doubleValue()) {
                result     =    tAgentContractList ;

                break;
            }
        }


        return   result ;
    }

}
