package com.mkt.agent.job.service.impl.commission;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.job.mapper.CommissionRecordMapper;
import com.mkt.agent.job.service.CommissionRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;


@Service
public class CommissionRecordServiceImpl extends ServiceImpl<CommissionRecordMapper, AgentCommissionRecord> implements CommissionRecordService {

    @Autowired
    private CommissionRecordMapper commissionRecordMapper;

    /**
     * @param entityList
     */
    @Override
    public Integer saveCommissionRecordsByBatch(List<AgentCommissionRecord> entityList) {

        if (CollectionUtils.isEmpty(entityList)) {
            return 0;
        }
        return commissionRecordMapper.insertBatchSomeColumn(entityList);
    }
}
