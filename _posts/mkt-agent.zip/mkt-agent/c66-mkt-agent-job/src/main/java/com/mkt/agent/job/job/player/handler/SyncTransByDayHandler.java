package com.mkt.agent.job.job.player.handler;

import com.google.gson.Gson;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.player.model.SyncTransByDayParams;
import com.mkt.agent.job.job.player.process.SyncTransByDayProcess;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Objects;

/**
 * @description: 同步玩家数据定时任务
 * @author: ErHu.Zhao
 * @create: 2024-01-30
 **/
@Component
@Slf4j
public class SyncTransByDayHandler extends IJobHandler {
    private static final String NUMBER = "^\\d*$";

    @Resource
    private SyncTransByDayProcess syncTransByDayProcess;

    @Resource
    private Gson gson;

    @XxlJob(value = "SyncTransByDayHandler")
    @Override
    public void execute() throws Exception {
        String params = XxlJobHelper.getJobParam();
        log.info("job params is {}", params);
        SyncTransByDayParams syncTransByDayParams;
        try {
            syncTransByDayParams = gson.fromJson(params, SyncTransByDayParams.class);
        } catch (Exception e) {
            throw new BusinessException("job param input error");
        }

        if (Objects.nonNull(syncTransByDayParams) && Objects.nonNull(syncTransByDayParams.getClearDays()) && Objects.nonNull(syncTransByDayParams.getClearCache())) {
            log.info("xxljob定时任务同步执行开始");
            syncTransByDayProcess.handleUsersGroupByDay(Constants.FROM_JOB, Constants.DASH_BOARD_DATA_START_LEVEL, syncTransByDayParams);
            log.info("xxljob定时任务同步执行结束");
        } else {
            throw new BusinessException("job param input error");
        }

    }
}
