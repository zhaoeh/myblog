package com.mkt.agent.job.job.player.handler;

import com.mkt.agent.job.job.player.process.SyncTransByMonthForAgentProcess;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @description: 同步玩家数据定时任务--月
 * @author: Lucian
 * @create: 2024-02-01
 **/
@Component
@Slf4j
public class SyncTransByMonthForAgentHandler extends IJobHandler {

    @Resource
    private SyncTransByMonthForAgentProcess syncTransByMonthForAgentProcess;

    @XxlJob(value = "SyncTransByMonthForAgentHandler")
    @Override
    public void execute() throws Exception {

        String params = XxlJobHelper.getJobParam();

        if(StringUtils.isBlank(params)){
            log.info("The param is null!");
            return;
        }

        syncTransByMonthForAgentProcess.syncUsersGroupByMonth(params);
    }
}
