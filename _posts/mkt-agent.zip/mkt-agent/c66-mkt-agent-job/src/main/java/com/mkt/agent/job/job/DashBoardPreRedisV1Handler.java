package com.mkt.agent.job.job;

import com.mkt.agent.job.job.process.DashBoardPreRedisV1Process;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @Description 为仪表盘功能初始化缓存 --当天数据
 * @Classname DashBoardPreRedisHandler
 * @Date 2023/12/6 13:46
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class DashBoardPreRedisV1Handler extends IJobHandler {

    @Autowired
    private DashBoardPreRedisV1Process redisHandlerV1Process;

    @Override
    @XxlJob(value = "DashBoardPreRedisV1Handler")
    public void execute() {

        log.info("DashBoardPreRedisHandler starting");

        redisHandlerV1Process.process();

        log.info("DashBoardPreRedisHandler end");
    }

}
