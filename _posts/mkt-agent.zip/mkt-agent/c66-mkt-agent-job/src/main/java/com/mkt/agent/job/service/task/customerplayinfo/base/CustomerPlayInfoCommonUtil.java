package com.mkt.agent.job.service.task.customerplayinfo.base;

import com.mkt.agent.common.entity.api.integration.bi.requests.UserSummerRequest;

import com.mkt.agent.common.entity.api.integration.bi.responses.UserSummerResponse;

import com.mkt.agent.integration.template.BiApiTemplate;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


@Service
@Slf4j
@RefreshScope
public class CustomerPlayInfoCommonUtil {


    @Value("${BI.user_data_url:http://127.0.0.1:1066/forMarketPlatform/userUnionAllSummary}")
    private String userDataUrl;


    // 分别获取每个客户的玩家信息
    public List<UserSummerResponse> getCustomerPlayInfo(UserSummerRequest userSummerRequest) {

        log.info("begin to call BI to get data Param:{}",userSummerRequest);
        BiApiTemplate biApiTemplate = new BiApiTemplate(userDataUrl);
        List<UserSummerResponse> customerPlayInfoList = null;
        try {
            if(null==userSummerRequest.getNames()||userSummerRequest.getNames().size()<=0){
                return null;
            }
            customerPlayInfoList = biApiTemplate.queryUserSummary(userSummerRequest);
            log.info("分别获取每个客户的玩家信息为------------------------------------------：{}",Arrays.toString(customerPlayInfoList.toArray()));
            if (CollectionUtils.isEmpty(customerPlayInfoList)) {
                log.error("分别获取每个客户的玩家信息为：{}，执行参数日期为：{}，执行入参为：{}，Bi返回玩家信息为空", Thread.currentThread().getName() + Thread.currentThread().getId(), userSummerRequest.getStartDate(), userSummerRequest);
                return new ArrayList<>();
            }
        } catch (Exception e) {
            log.error("分别获取每个客户的玩家信息为：{}，执行参数日期为：{}，执行入参为：{}，异常信息：{}", Thread.currentThread().getName() + Thread.currentThread().getId(), userSummerRequest.getStartDate(), userSummerRequest, e.getMessage());
        }

        return customerPlayInfoList;

    }



}
