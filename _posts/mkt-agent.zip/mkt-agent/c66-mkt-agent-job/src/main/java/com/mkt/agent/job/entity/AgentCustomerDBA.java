package com.mkt.agent.job.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @Description TODO--
 * @Classname AgentCustomerDBA
 * @Date 2023/9/7 16:56
 * @Created by TJSLucian
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_agent_customer_dba")
public class AgentCustomerDBA {

    private int loginFlag;
    private Long customerId;
    private String loginName;



}
