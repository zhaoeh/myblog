package com.mkt.agent.job.job.process;

import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.job.util.DashBoardDataByDayV1Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * @Description 初始化仪表盘缓存 每天
 * @Classname DashBoardPreRedisHandlerProcess
 * @Date 2023/12/6 13:57
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class DashBoardPreDistriNTopProcess {

    @Autowired
    private DashBoardDataByDayV1Util dashBoardV1Util;

    /**
     * description: 初始化缓存
     * @param:  []
     * @return: void
     * @Date: 2023/12/6 14:07
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public void process(){

        try {

            //把柱状图存入缓存
            dashBoardV1Util.handleTopData(Constants.DASH_BOARD_DATA_START_LEVEL);

            //把饼状图存入缓存
            dashBoardV1Util.handleDistriData(Constants.DASH_BOARD_DATA_START_LEVEL);


            log.info("Finished to handle today's data!");


        }catch (Exception e){
            log.info("Failed to cache today's data!",e);
        }


    }




}
