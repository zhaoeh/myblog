package com.mkt.agent.job.job;

import com.mkt.agent.job.job.process.DashBoardHistoryV1Process;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @Description 同步仪表盘历史数据
 * @Classname DashBoardHistoryHandler
 * @Date 2023/12/6 16:27
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class DashBoardHistoryV1Handler extends IJobHandler {

    @Autowired
    private DashBoardHistoryV1Process process;

    @Override
    @XxlJob(value = "DashBoardHistoryV1Handler")
    public void execute() {

        log.info("DashBoardHistoryV1Handler starting");
        process.process();

        log.info("DashBoardHistoryV1Handler end");
    }

}
