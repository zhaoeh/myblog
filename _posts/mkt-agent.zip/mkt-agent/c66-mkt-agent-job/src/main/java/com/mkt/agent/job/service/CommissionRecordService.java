package com.mkt.agent.job.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.job.req.TAgentCustomers;

import java.util.List;
import java.util.Map;

public interface CommissionRecordService extends IService<AgentCommissionRecord> {

    Integer saveCommissionRecordsByBatch(List<AgentCommissionRecord> entityList);

    Map<String,Object> calcCommissionData(TAgentCustomers agentCustomers, Map<String,Object> parame);

    void updatePlayerStatus(Map<String, String> req);
}
