package com.mkt.agent.job.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;

import java.util.List;

public interface CommissionRecordService extends IService<AgentCommissionRecord> {

    Integer saveCommissionRecordsByBatch(List<AgentCommissionRecord> entityList);

}
