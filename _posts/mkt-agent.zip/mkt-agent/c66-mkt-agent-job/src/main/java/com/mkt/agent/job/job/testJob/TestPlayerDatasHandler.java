package com.mkt.agent.job.job.testJob;

import cn.hutool.core.convert.Convert;
import cn.hutool.core.lang.TypeReference;
import cn.hutool.json.JSONUtil;
import com.google.common.base.Stopwatch;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.job.constants.ComConstant;
import com.mkt.agent.job.job.testJob.entity.TestJobParams;
import com.mkt.agent.job.job.testJob.utils.TestPlayerDataUtil;
import com.mkt.agent.job.req.CustomersReqQuery;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import com.xxl.job.core.util.GsonTool;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.util.Objects;


/**
 * @Description TODO
 * @Classname TestPlayerDatasHandler
 * @Date 2024/1/29 10:09
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class TestPlayerDatasHandler extends IJobHandler {

    @Resource
    private TestPlayerDataUtil testPlayerDataUtil;

    @Override
    @XxlJob(value = "TestPlayerDatasHandler")
    public void execute() throws Exception {
        log.info("TestPlayerDatasHandler start ...");

        // 获取当前日期
        LocalDate currentDate = LocalDate.now();

        log.info("Begin to handle data for current day:{}",currentDate);

        LocalDate recordDateStart = DateUtils.getLastNMonthFirstDay(2);

        Stopwatch stopwatch = Stopwatch.createStarted();

        TestJobParams jobParams = getParams();

        if(Objects.nonNull(jobParams)){
            testPlayerDataUtil.handleByLevelByDayWithParams(Constants.DASH_BOARD_DATA_START_LEVEL, recordDateStart,currentDate,Constants.CURRENT_DATA,jobParams);

        }else {
            testPlayerDataUtil.handleByLevelByDay(Constants.DASH_BOARD_DATA_START_LEVEL, recordDateStart,currentDate,Constants.CURRENT_DATA);
        }


        stopwatch.stop();

        log.info("TestPlayerDatasHandler end ... Time elapsed:" + stopwatch);
    }

    private TestJobParams getParams(){

        String param = XxlJobHelper.getJobParam();
        XxlJobHelper.log("TestPlayerDatasHandler receive Param ", param);

        TestJobParams jobParams = null;

        try {
            if (StringUtils.isNotEmpty(param)) {
            /*TestJobParams params = Convert.convert(new TypeReference<TestJobParams>() {
            }, JSONUtil.parseObj(param));*/
                jobParams = GsonTool.fromJson(param,TestJobParams.class);

            }
        }catch (Exception e){
            log.info("Failed to parse parameters for job: TestPlayerDatasHandler");
        }
        return jobParams;
    }



}
