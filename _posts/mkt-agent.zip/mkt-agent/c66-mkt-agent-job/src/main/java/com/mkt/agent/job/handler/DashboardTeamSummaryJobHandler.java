package com.mkt.agent.job.handler;

import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.utils.DashBoardCommonUtil;
import com.mkt.agent.ds.finder.DataSourceHandler;
import com.mkt.agent.ds.finder.DataSourceRequest;
import com.mkt.agent.ds.finder.DataSourceResponse;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * @Description 聚合来自clickhouse和bytehouse的数据
 * @Classname dashboardDataSumHandler
 * @Date 2024/1/22 12:23
 * @Created by TJSLucian
 */
public class DashboardTeamSummaryJobHandler implements DataSourceHandler {

    @Resource
    private DashBoardCommonUtil commonUtil;

    @Override
    public List<DataSourceRequest> handleRequestWithDataSource(Object[] args) {

        if(Objects.nonNull(args)&&Objects.nonNull(args[0])){
            ClDashBoardCreateQueryReq originalQueryReq = (ClDashBoardCreateQueryReq)args[0];

            List<DataSourceRequest> list = commonUtil.splitQueryReq(originalQueryReq);
            return list;
        }

        return null;
    }

    @Override
    public Object handleResponseWithDataSource(List<DataSourceResponse> dataSourceResponses) {

        if(CollectionUtils.isEmpty(dataSourceResponses)){
            return null;
        }

        DashBoardHistoryEntity entity = dataSourceResponses.stream().filter(l -> Objects.nonNull(l)).map(d -> (DashBoardHistoryEntity)d.getNewResponse())
                .reduce((d1,d2) -> commonUtil.sumDataResultV2(d1,d2)).orElse(null);

        if(Objects.nonNull(entity)){
            return entity;
        }
        return null;
    }



}
