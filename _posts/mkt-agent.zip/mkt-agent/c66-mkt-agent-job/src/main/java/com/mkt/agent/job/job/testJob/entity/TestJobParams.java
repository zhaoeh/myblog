package com.mkt.agent.job.job.testJob.entity;

import lombok.Data;

/**
 * @Description TODO
 * @Classname TestJobParams
 * @Date 2024/1/29 11:37
 * @Created by TJSLucian
 */
@Data
public class TestJobParams {

    private String agentAccount;

    private String recordDateStart;

    private String recordDateEnd;

    private Integer level;


}
