package com.mkt.agent.job.job.player.process;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonth;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.player.core.PlayerReportByMonthPersist;
import com.mkt.agent.common.player.model.PlayerReportByMonthMapperHolder;
import com.mkt.agent.common.player.model.PlayerReportByMonthProcessorModel;
import com.mkt.agent.common.player.processor.AgentTransByMonthProcessor;
import com.mkt.agent.job.mapper.api.AgentMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.Future;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @Description TODO
 * @Classname PlayerReportByMonthProcessor
 * @Date 2024/3/13 14:40
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class PlayerReportByMonthForAgentProcessor {

    @Resource
    private AgentMapper agentMapper;

    private final PlayerReportByMonthPersist playerReportByMonthPersist;

    public PlayerReportByMonthForAgentProcessor(PlayerReportByMonthPersist playerReportByMonthPersist) {
        this.playerReportByMonthPersist = playerReportByMonthPersist;
    }


    public void preHandlePlayerReportByMonth(PlayerReportByMonthProcessorModel model,String account){
        if(Objects.isNull(model) || Objects.isNull(model.getHolder())){
            return;
        }

        if(model.getOperatorType().equals(Constants.FROM_ASYNC)){
            TAgentCustomers parent = model.getHolder().getQueryAgentByNameMapper().apply(model.getParent());
            if(Objects.isNull(parent)){
                return;
            }

            model.setParentLevel(parent.getAgentLevel());
        }
        TAgentCustomers agentCustomers = agentMapper.selectOne(new LambdaQueryWrapper<TAgentCustomers>().eq(TAgentCustomers::getLoginName,account));
        if(Objects.isNull(agentCustomers)){
            log.error("There is no such agent!");
            return;
        }
        handlePlayerReportData(model,agentCustomers);
    }

    /**
     * description: 递归处理某月的player report数据
     * @param:  [model]
     * @return: void
     * @Date: 2024/3/13 15:20
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public void handlePlayerReportData(PlayerReportByMonthProcessorModel model,TAgentCustomers agentCustomers){

        this.submitTaskForPlayerByMonth(buildQueryReq(agentCustomers,model),model);

    }


    private void submitTaskForPlayerByMonth(ClDashBoardCreateQueryReq queryReq, PlayerReportByMonthProcessorModel model){
        if(Objects.isNull(queryReq) || CollectionUtils.isEmpty(queryReq.getAgentAccountList())){
            return;
        }

        Function<ClDashBoardCreateQueryReq,List<TAgentCountGroupMonth>> queryDirectCountByMonthMapper = model.getHolder().getQueryDirectCountByMonthMapper();
        Function<ClDashBoardCreateQueryReq,List<TAgentCountGroupMonth>> querySelfCountByMonthMapper = model.getHolder().getQuerySelfCountByMonthMapper();
        Function<ClDashBoardCreateQueryReq,List<TAgentCountGroupMonth>> downlineAgentCountMapper = model.getHolder().getDownlineAgentCountMapper();
        try {

            List<TAgentCountGroupMonth> agentCountGroupMonthList = new ArrayList<>();
            //直属用户数据 directCount totalCount
            List<TAgentCountGroupMonth> directRes = playerReportByMonthPersist.queryDirectCountFromCH(queryReq,queryDirectCountByMonthMapper);

            if(!CollectionUtils.isEmpty(directRes)){
                agentCountGroupMonthList.addAll(directRes);
            }
            //自身数据 selfCount
            List<TAgentCountGroupMonth> selfRes = playerReportByMonthPersist.querySelfCountFromCH(queryReq,querySelfCountByMonthMapper);
            if(!CollectionUtils.isEmpty(selfRes)){
                agentCountGroupMonthList.addAll(selfRes);
            }

            List<TAgentCountGroupMonth> downlineRes = null;

            //下级代理数据 totalCount
            if(model.getLevel() != Constants.DASH_BOARD_DATA_START_LEVEL){
                downlineRes = downlineAgentCountMapper.apply(queryReq);
            }

            if(!CollectionUtils.isEmpty(downlineRes)){
                agentCountGroupMonthList.addAll(downlineRes);
            }

            if(!CollectionUtils.isEmpty(agentCountGroupMonthList)){
                Map<String,TAgentCustomers> agentMap = queryReq.getAgentCustomersList().stream().collect(Collectors.toMap(TAgentCustomers::getLoginName, t -> t));
                log.info("[submitTaskForPlayerByMonth]The month is:{}, the level is:{}",model.getMonth(),model.getLevel());
                List<TAgentCountGroupMonth> response = agentCountGroupMonthList.stream().collect(Collectors.groupingBy(TAgentCountGroupMonth::getAgentName)).values().stream()
                        .map(pList -> pList.stream().reduce((r1,r2) -> {
                            r1.setTotalCount(r1.getTotalCount() + r2.getTotalCount());
                            r1.setDirectCount(r1.getDirectCount() + r2.getDirectCount());
                            r1.setSelfCount(r1.getSelfCount() + r2.getSelfCount());
                            log.info("[submitTaskForPlayerByMonth]The agent is:{},the month is:{}, the level is:{}",r1.getAgentName(),r1.getAgentMonth(),r1.getAgentLevel());
                            return r1;
                        }).orElse(null)).map(b -> handleInfoForData(b,model,agentMap.get(b.getAgentName()))).filter(Objects::nonNull).collect(Collectors.toList());
                log.info("[PlayerReportByMonthForAgentProcessor]The response for agent:{} on month:{} is:{}",queryReq.getAgentAccount(),queryReq.getAgentMonth(), Arrays.toString(response.toArray()));

            }else {
                log.info("[PlayerReportByMonthForAgentProcessor]The response for agent:{} on month:{} is null!",queryReq.getAgentAccount(),queryReq.getAgentMonth());
            }

        } catch (Exception failedE) {
            log.error("Failed to submit task:{}",queryReq,failedE);
        }
        log.info("Finished to update the agent:{}",queryReq.getAgentAccount());
    }


    private TAgentCountGroupMonth handleInfoForData(TAgentCountGroupMonth data, PlayerReportByMonthProcessorModel model, TAgentCustomers agent){

        if(Objects.isNull(data)){
            return null;
        }

        data.setAgentMonth(model.getMonth());
        data.setAgentLevel(model.getLevel());
        data.setParentAgentName(agent.getParentName());
        data.setIsEnable(agent.getIsEnable());
        data.setIsDeleted(agent.getIsDeleted());

        return data;
    }


    public ClDashBoardCreateQueryReq buildQueryReq(TAgentCustomers agent, PlayerReportByMonthProcessorModel model){
        return ClDashBoardCreateQueryReq.builder().agentAccount(agent.getLoginName()).agentCustomersList(List.of(agent)).agentAccountList(List.of(agent.getLoginName())).recordDateStart(model.getStartDate()).recordDateEnd(model.getEndDate())
                .agentMonth(model.getMonth()).build();
    }



}
