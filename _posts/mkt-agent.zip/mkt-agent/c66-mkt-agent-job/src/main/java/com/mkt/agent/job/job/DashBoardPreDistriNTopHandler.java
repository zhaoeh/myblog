package com.mkt.agent.job.job;

import com.mkt.agent.job.job.process.DashBoardPreDistriNTopProcess;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @Description 为仪表盘功能初始化缓存  当天数据
 * @Classname DashBoardPreRedisHandler
 * @Date 2023/12/6 13:46
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class DashBoardPreDistriNTopHandler extends IJobHandler {

    @Autowired
    private DashBoardPreDistriNTopProcess distriNTopProcess;

    @Override
    @XxlJob(value = "DashBoardPreDistriNTopHandler")
    public void execute() {

        log.info("DashBoardPreDistriNTopHandler starting");

        distriNTopProcess.process();

        log.info("DashBoardPreDistriNTopHandler end");
    }

}
