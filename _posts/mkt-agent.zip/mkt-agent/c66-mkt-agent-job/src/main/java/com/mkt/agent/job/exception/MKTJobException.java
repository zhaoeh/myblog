package com.mkt.agent.job.exception;

import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;
import lombok.Getter;

/**
 * @ClassName BusinessException
 * @Description 自定义业务异常
 * @Author TJSAlex
 * @Date 2023/5/19 12:11
 * @Version 1.0
 **/
@Getter
public class MKTJobException extends BusinessException {

    public MKTJobException() {
        super();
    }

    public MKTJobException(String message) {
        super(message);
    }

    public MKTJobException(String message, Integer code) {
        super(message);
        this.code = code;
    }

    public MKTJobException(String message, Throwable cause) {
        super(message, cause);
    }


    public MKTJobException(ResultEnum resultEnum) {
        super(resultEnum);
    }
}
