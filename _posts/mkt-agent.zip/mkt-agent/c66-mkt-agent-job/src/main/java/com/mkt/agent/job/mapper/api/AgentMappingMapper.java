package com.mkt.agent.job.mapper.api;

import com.mkt.agent.common.entity.api.commissionapi.table.AgentCustomersMapping;
import com.mkt.agent.job.mapper.CommonMapper;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface AgentMappingMapper extends CommonMapper<AgentCustomersMapping> {

    List<AgentCustomersMapping> queryAgentsMapping();

}
