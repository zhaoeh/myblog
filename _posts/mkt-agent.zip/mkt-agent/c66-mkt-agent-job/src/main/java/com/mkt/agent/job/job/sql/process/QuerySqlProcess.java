package com.mkt.agent.job.job.sql.process;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.stereotype.Component;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @description: sql查询处理器
 * @author: ErHu.Zhao
 * @create: 2024-04-18
 **/
@Component
@Slf4j
public class QuerySqlProcess {

    public void doQuery(String querySql, SqlSessionFactory sqlSessionFactory) throws SQLException {
        log.info("begin to execute query sql of \"{} \"", querySql);
        List<Map<String, Object>> result = new ArrayList<>();

        try (Connection connection = sqlSessionFactory.openSession().getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(querySql)) {
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
            int columnCount = resultSetMetaData.getColumnCount();
            while (resultSet.next()) {
                Map<String, Object> row = new HashMap<>();
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = resultSetMetaData.getColumnName(i);
                    Object value = resultSet.getObject(i);
                    row.put(columnName, value);
                }
                result.add(row);
                // 最多从游标中循环读取1000条数据到内存
                if (result.size() > 1000) {
                    break;
                }
            }
        }
        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        log.info("result is : {}", gson.toJson(result));
    }
}
