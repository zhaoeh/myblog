package com.mkt.agent.job.job;

import com.mkt.agent.job.service.MktAgentAllService;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;


@Component
@Slf4j
public class DailyMktAgentAllMigrationHandler extends IJobHandler {

    @Resource
    private MktAgentAllService mktAgentAllService;

    @Override
    @XxlJob(value = "DailyMktAgentAllMigrationHandler")
    public void execute() throws Exception {
        /* 判断是否已有数据，有数据则取消全量迁移 */
        long count = mktAgentAllService.count();
        log.info("t_daily_mkt_agent_all data size is:{}",count);
        if (count == 0){
            mktAgentAllService.allDataMigration();
        } else {
            log.info("t_daily_mkt_agent_all already has data, skip migration");
        }
    }

}
