package com.mkt.agent.job.job.process;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.RedisUtil;
import com.mkt.agent.job.mapper.api.AgentMapper;
import com.mkt.agent.job.util.DashBoardDataByDayV1Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.util.List;

/**
 * @Description 初始化仪表盘缓存 每天
 * @Classname DashBoardPreRedisHandlerProcess
 * @Date 2023/12/6 13:57
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class DashBoardRemoveRedisV1Process {

    @Resource
    private AgentMapper agentMapper;

    @Resource
    private RedisUtil redisUtil;

    /**
     * description: 清除缓存
     * @param:  []
     * @return: void
     * @Date: 2023/12/6 14:07
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public void process(){

        removeBetPlayers();
        removeCommission();
        removeTeamSummary();

    }



    private void removeBetPlayers(){
        try {

            //当月
            LocalDate currentMonthFirstDay = DateUtils.getLastNMonthFirstDay(0);
            LocalDate currentMonthLastDay = DateUtils.getLastNMonthLastDay(0);

            //上个月
            LocalDate lastMonthFirstDay = DateUtils.getLastNMonthFirstDay(1);
            LocalDate lastMonthLastDay = DateUtils.getLastNMonthLastDay(1);
            //上上个月
            LocalDate last2MonthFirstDay = DateUtils.getLastNMonthFirstDay(2);
            LocalDate last2MonthLastDay = DateUtils.getLastNMonthLastDay(2);
            //当周
            LocalDate currentWeekFirstDay = DateUtils.getNWeeksAgoMonday(0);
            LocalDate currentWeekLastDay = DateUtils.getNWeeksAgoSunday(0);
            //上周
            LocalDate lastWeekFirstDay = DateUtils.getNWeeksAgoMonday(1);
            LocalDate lastWeekLastDay = DateUtils.getNWeeksAgoSunday(1);
            //上上周
            LocalDate last2WeekFirstDay = DateUtils.getNWeeksAgoMonday(2);
            LocalDate last2WeekLastDay = DateUtils.getNWeeksAgoSunday(2);

            //今天
            LocalDate currentDay = DateUtils.getNDaysAgo(0);
            //昨天
            LocalDate yesterday = DateUtils.getNDaysAgo(1);
            //前天
            LocalDate last2Day = DateUtils.getNDaysAgo(2);



            List<TAgentCustomers> agentCustomersList = agentMapper.selectList(new LambdaQueryWrapper<TAgentCustomers>().eq(TAgentCustomers::getIsEnable,1).eq(TAgentCustomers::getIsDeleted,0));

            log.info("The agentList size is:{}",agentCustomersList.size());

            int removeCount = 0;

            for(int i=0; i < agentCustomersList.size(); i++){

                String key1 = Constants.BETPLAYERS_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + currentMonthFirstDay + currentMonthLastDay;
                redisUtil.remove(key1);
                String key2 = Constants.BETPLAYERS_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + lastMonthFirstDay + lastMonthLastDay;
                redisUtil.remove(key2);
                String key3 = Constants.BETPLAYERS_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + last2MonthFirstDay + last2MonthLastDay;
                redisUtil.remove(key3);

                String key4 = Constants.BETPLAYERS_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + currentWeekFirstDay + currentWeekLastDay;
                redisUtil.remove(key4);
                String key5 = Constants.BETPLAYERS_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + lastWeekFirstDay + lastWeekLastDay;
                redisUtil.remove(key5);
                String key6 = Constants.BETPLAYERS_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + last2WeekFirstDay + last2WeekLastDay;
                redisUtil.remove(key6);

                String key7 = Constants.BETPLAYERS_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + currentDay + currentDay;
                redisUtil.remove(key7);
                String key8 = Constants.BETPLAYERS_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + yesterday + yesterday;
                redisUtil.remove(key8);
                String key9 = Constants.BETPLAYERS_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + last2Day + last2Day;
                redisUtil.remove(key9);

                removeCount++;

            }

            log.info("The betPlayers remove count is:{}",removeCount);

        }catch (Exception e){
            log.info("Failed to remove today's cache betPlayers data!",e);
        }
    }

    private void removeCommission(){
        try {

            //当月
            LocalDate currentMonthFirstDay = DateUtils.getLastNMonthFirstDay(0);
            LocalDate currentMonthLastDay = DateUtils.getLastNMonthLastDay(0);

            //上个月
            LocalDate lastMonthFirstDay = DateUtils.getLastNMonthFirstDay(1);
            LocalDate lastMonthLastDay = DateUtils.getLastNMonthLastDay(1);
            //上上个月
            LocalDate last2MonthFirstDay = DateUtils.getLastNMonthFirstDay(2);
            LocalDate last2MonthLastDay = DateUtils.getLastNMonthLastDay(2);
            //当周
            LocalDate currentWeekFirstDay = DateUtils.getNWeeksAgoMonday(0);
            LocalDate currentWeekLastDay = DateUtils.getNWeeksAgoSunday(0);
            //上周
            LocalDate lastWeekFirstDay = DateUtils.getNWeeksAgoMonday(1);
            LocalDate lastWeekLastDay = DateUtils.getNWeeksAgoSunday(1);
            //上上周
            LocalDate last2WeekFirstDay = DateUtils.getNWeeksAgoMonday(2);
            LocalDate last2WeekLastDay = DateUtils.getNWeeksAgoSunday(2);

            //今天
            LocalDate currentDay = DateUtils.getNDaysAgo(0);
            //昨天
            LocalDate yesterday = DateUtils.getNDaysAgo(1);
            //前天
            LocalDate last2Day = DateUtils.getNDaysAgo(2);



            List<TAgentCustomers> agentCustomersList = agentMapper.selectList(new LambdaQueryWrapper<TAgentCustomers>().eq(TAgentCustomers::getIsEnable,1).eq(TAgentCustomers::getIsDeleted,0));

            log.info("The agentList size is:{}",agentCustomersList.size());

            int removeCount = 0;

            for(int i=0; i < agentCustomersList.size(); i++){

                String key1 = Constants.COMMISSION_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + currentMonthFirstDay + currentMonthLastDay;
                redisUtil.remove(key1);
                String key2 = Constants.COMMISSION_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + lastMonthFirstDay + lastMonthLastDay;
                redisUtil.remove(key2);
                String key3 = Constants.COMMISSION_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + last2MonthFirstDay + last2MonthLastDay;
                redisUtil.remove(key3);

                String key4 = Constants.COMMISSION_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + currentWeekFirstDay + currentWeekLastDay;
                redisUtil.remove(key4);
                String key5 = Constants.COMMISSION_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + lastWeekFirstDay + lastWeekLastDay;
                redisUtil.remove(key5);
                String key6 = Constants.COMMISSION_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + last2WeekFirstDay + last2WeekLastDay;
                redisUtil.remove(key6);

                String key7 = Constants.COMMISSION_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + currentDay + currentDay;
                redisUtil.remove(key7);
                String key8 = Constants.COMMISSION_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + yesterday + yesterday;
                redisUtil.remove(key8);
                String key9 = Constants.COMMISSION_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + last2Day + last2Day;
                redisUtil.remove(key9);

                removeCount++;

            }

            log.info("The commission remove count is:{}",removeCount);

        }catch (Exception e){
            log.info("Failed to remove today's cache commission data!",e);
        }
    }

    private void removeTeamSummary(){
        try {

            // 获取当前日期
            LocalDate currentDate = LocalDate.now();

            log.info("Begin to handle data for current day:{}",currentDate);

            LocalDate recordDateStart = DateUtils.getLastNMonthFirstDay(0);

            List<String> dateList = DateUtils.getDateRangeAsStr(recordDateStart,currentDate);

            List<TAgentCustomers> agentCustomersList = agentMapper.selectList(new LambdaQueryWrapper<TAgentCustomers>().eq(TAgentCustomers::getIsEnable,1).eq(TAgentCustomers::getIsDeleted,0));

            log.info("The agentList size is:{}",agentCustomersList.size());

            int removeCount = 0;

            for(int i=0; i < agentCustomersList.size(); i++){

                for(int j=0; j < dateList.size(); j++){
                    String key = Constants.CURRENT_USER_DASH_BOARD_CACHE_PREFIX + agentCustomersList.get(i).getLoginName() + dateList.get(j);
                    redisUtil.remove(key);
                    removeCount++;
                }

            }

            log.info("The TeamSummary remove count is:{}",removeCount);

        }catch (Exception e){
            log.info("Failed to remove today's TeamSummary cache data!",e);
        }
    }



}
