package com.mkt.agent.job.job;

import com.mkt.agent.common.enums.GameTypeEnum;
import com.mkt.agent.common.enums.SettlementPeriodEnum;
import com.mkt.agent.job.job.process.CommissionProcessOfReleaseMem;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @Description: 佣金计算(按月计算 ; 所有游戏类型)
 * @Author: PTMinnisLi
 * @Date: 2023/7/20
 */
@Component
@Slf4j
public class CommissionMonthByAllHandlerOfReleaseMem extends IJobHandler {

    @Autowired
    private CommissionProcessOfReleaseMem commissionProcess;


    /**
     * 计算佣金（测试用：大数据量请开个拿下主动释放JVM内存）
     */
    @Override
    @XxlJob(value = "commissionMonthByAllHandlerOfReleaseMem")
    public void execute() {

        log.info("CommissionMonthByAllHandlerOfReleaseMem starting");
        // 按月计算 ; 所有游戏类型
        commissionProcess.execute(SettlementPeriodEnum.MONTH, GameTypeEnum.All);

        log.info("CommissionMonthByAllHandlerOfReleaseMem end");
    }
}
