package com.mkt.agent.job.mapper.api;

import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.OrgCodeUpdateRequest;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerQueryResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserMapper {


    List<AgentCustomerQueryResponse> getDirectCustomers(AgentCustomerQueryRequest req);

    List<TCustomerLayer> selectUserTree (String parent);

    List<String> selectDirectUsersAgentsName(String parent);

    DashBoardHistoryEntity selectRegisterUserCountByDay(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    Long selectRegisterUserCount(@Param("parent") String parent, @Param("recordDateTimeStart")String recordDateTimeStart, @Param("recordDateTimeEnd")String recordDateTimeEnd);

    List<String> selectTeamUserNames(String parent);
}
