package com.mkt.agent.job.mapper.api;

import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.OrgCodeUpdateRequest;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerQueryResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.job.req.TAgentCustomers;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface UserMapper {


    List<AgentCustomerQueryResponse> getDirectCustomers(AgentCustomerQueryRequest req);

    List<TCustomerLayer> selectUserTree (String parent);

    List<String> selectDirectUsersAgentsName(String parent);

    List<String> selectDirectUsersAgentsNameForPlayer(@Param("parentList")List<String> parentList);

    List<String> selectDirectUsersName(String parent);

    DashBoardHistoryEntity selectRegisterUserCountByDay(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    Long selectRegisterUserCount(@Param("parent") String parent, @Param("recordDateTimeStart")String recordDateTimeStart, @Param("recordDateTimeEnd")String recordDateTimeEnd);

    List<String> selectTeamUserNames(String parent);

    List<TAgentCustomers> listTopAgent(Map<String, Object> parame);

    List<TCustomerLayer> listDirectUser(Map<String, String> parame);

    List<TCustomerLayer> selectUserTreeByParentNTime (
            @Param("parent") String parent, @Param("createTimeStart") String createTimeStart, @Param("createTimeEnd") String createTimeEnd);

    List<TCustomerLayer> queryAllValidatedPlayers();

    List<TCustomerLayer> selectUserParents(Map<String, Object> parame);

    com.mkt.agent.job.entity.TAgentCustomers getAgentData(Map<String, String> parame2);

    void delByDateLoginNameBP(Map<String, String> parame2);

    void delByDateLoginNameAP(Map<String, String> parame2);

    void delByDateLoginNameGP(Map<String, String> parame2);

    void insertTopBP(Map<String, String> parame2);

    void insertTopAP(Map<String, String> parame2);

    void insertTopGP(Map<String, String> parame2);

    List<com.mkt.agent.job.entity.TAgentCustomers> getAgentDataList(Map<String, Object> ag);

    void delByDateLoginNameBP2(Map<String, Object> parame24);

    void delByDateLoginNameAP2(Map<String, Object> parame24);

    void delByDateLoginNameGP2(Map<String, Object> parame24);

    void insertTopBP2(Map<String, Object> parame24);

    void insertTopAP2(Map<String, Object> parame24);

    void insertTopGP2(Map<String, Object> parame24);
}
