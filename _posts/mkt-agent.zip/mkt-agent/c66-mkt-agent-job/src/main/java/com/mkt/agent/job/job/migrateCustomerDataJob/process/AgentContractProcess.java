package com.mkt.agent.job.job.migrateCustomerDataJob.process;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.mkt.agent.common.entity.BaseEntity;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.jobapi.requests.AgentContractBindUpdateRequest;
import com.mkt.agent.common.entity.api.jobapi.responses.AgentContractBindResponse;
import com.mkt.agent.job.migration.MigrationConfig;
import com.mkt.agent.job.service.api.AgentContractBindService;
import com.mkt.agent.job.service.api.AgentContractService;
import com.mkt.agent.job.service.api.AgentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * * *
 *
 * @author Colson
 * @date 8/28/2023 3:48 PM
 */

@Component
@Slf4j
public class AgentContractProcess {

    @Resource
    private MigrationConfig migrationConfig;

    @Autowired
    private AgentContractService agentContractService;

    @Autowired
    private AgentService agentService;

    @Autowired
    private AgentContractBindService agentContractBindService;

    /**
     * 更新佣金方案绑定的代理数量 *
     * 区分专业和普通代理后，分别统计总数
     */
    public void updateAgentCount() {
        List<String> contractPlanNameList = new ArrayList<>();
        contractPlanNameList.add(migrationConfig.getGeneralContract());
        contractPlanNameList.add(migrationConfig.getProfessionalContract());
        // 根据佣金方案名称查询佣金方案id
        List<TAgentContract> agentContractList = agentContractService.listContractByCommissionPlanNames(contractPlanNameList);
        if (CollectionUtils.isEmpty(agentContractList)) {
            log.info("updateAgentCount 没有查到佣金方案名称，plan name={}", contractPlanNameList);
            return;
        }
        Map<String, Long> contractMap = agentContractList.stream()
                .collect(Collectors.toMap(TAgentContract::getCommissionPlanName, BaseEntity::getId));
        // 查询所有代理佣金方案绑定数据
        List<AgentContractBindResponse> agentContractBindList = agentContractBindService.listAgentContractBindTest();
        // 根据佣金方案ID分组，key=t_agent_contract id,value=代理总数
        Map<Long, Long> groupAgentCountMap = agentContractBindList.stream()
                .collect(Collectors.groupingBy(AgentContractBindResponse::getCommissionContractId,
                        Collectors.counting()));

        List<AgentContractBindUpdateRequest> agentContractBindUpdateRequestList = new ArrayList<>();
        AgentContractBindUpdateRequest updateReq = new AgentContractBindUpdateRequest();
        updateReq.setAgentCount(groupAgentCountMap.get(contractMap.get(migrationConfig.getGeneralContract())));
        updateReq.setId(contractMap.get(migrationConfig.getGeneralContract()));
        agentContractBindUpdateRequestList.add(updateReq);
        updateReq = new AgentContractBindUpdateRequest();
        updateReq.setAgentCount(groupAgentCountMap.get(contractMap.get(migrationConfig.getProfessionalContract())));
        updateReq.setId(contractMap.get(migrationConfig.getProfessionalContract()));
        agentContractBindUpdateRequestList.add(updateReq);
        agentContractService.updateAgentCount(agentContractBindUpdateRequestList);
    }
}
