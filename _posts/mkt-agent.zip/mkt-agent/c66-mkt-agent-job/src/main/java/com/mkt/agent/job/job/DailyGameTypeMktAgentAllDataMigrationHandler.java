package com.mkt.agent.job.job;

import com.google.common.collect.Lists;
import com.mkt.agent.common.entity.api.jobapi.table.DailyGameTypeMktAgentAll;
import com.mkt.agent.job.clickhouse.mapper.ByteHouseDailyGameTypeMktAgentAllMapper;
import com.mkt.agent.job.mapper.LocalDailyGameTypeMktAgentAllMapper;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;


@Component
@Slf4j
public class DailyGameTypeMktAgentAllDataMigrationHandler extends IJobHandler {

    @Resource
    private ByteHouseDailyGameTypeMktAgentAllMapper byteHouseDailyGameTypeMktAgentAllMapper;

    @Resource
    private LocalDailyGameTypeMktAgentAllMapper localDailyGameTypeMktAgentAllMapper;

    @Value("${dataMigration.asyncLimit:5000}")
    private Integer asyncLimit;

    @Value("${dataMigration.threadPoolSize:5}")
    private Integer threadPoolSize;

    @Value("${dataMigration.migratePageSize:1000000}")
    private Integer migratePageSize;

    private static ExecutorService executorService;

    private static final String table = "t_daily_game_type_mkt_agent_all";

    private static final String XxlJob = "DailyGameTypeMktAgentAllDataMigrationHandler";

    @PostConstruct
    public void initTheadPool() {
        log.info("begin to init thread pool of {}", XxlJob);
        executorService = Executors.newFixedThreadPool(this.threadPoolSize);
        log.info("end to init thread pool of {}, threadPoolSize is {}", XxlJob, this.threadPoolSize);
    }

    @Override
    @XxlJob(value = XxlJob)
    public void execute() throws Exception {
        log.info("{} start migration ...", table);
        /* 生产环境的表字符集！确保测试环境已经建好表 */
        localDailyGameTypeMktAgentAllMapper.createTableIfNotExist();
        // createPartitions();
        dataMigration();
    }

//    private void createPartitions() {
//        List<PartitionEntity> partitionEntityList = new ArrayList<>();
//        for (int i = -364; i <= 1; i++){
//            PartitionEntity partitionEntity = new PartitionEntity();
//            Date date = new Date();
//            partitionEntity.setPartitionDate(DateUtils.format(DateUtils.addDay(date, i), DateUtils.DATE_FORMAT));
//            partitionEntity.setPartitionName("p" + DateUtils.format(DateUtils.addDay(date, i), DateUtils.DATE_FORMAT_MONTH));
//            partitionEntityList.add(partitionEntity);
//        }
//        log.info("Add {} partition by day of last year starting ...", table);
//        int daysOfPartition =  localDailyGameTypeMktAgentAllMapper.alterPartitionByDayList(partitionEntityList);
//        log.info("Add {} partition by day of last year finished : {} ", table, daysOfPartition);
//    }

    private void dataMigration() {
        int totalPage = byteHouseDailyGameTypeMktAgentAllMapper.selectTotalPageByPageSize(migratePageSize);

        log.info(" TotalPage : {}; MigratePageSize : {} ", totalPage, migratePageSize);

        Integer response = 0;
        CountDownLatch latch = new CountDownLatch(totalPage);
        try {
            log.info("The total page size is:{}", totalPage);
            List<Future<Integer>> futureRecords = IntStream.range(0, totalPage)
                    .mapToObj(i -> executorService.submit(() -> {
                        log.info("Begin to query the page:{}",i);
                        List<DailyGameTypeMktAgentAll> pageList = byteHouseDailyGameTypeMktAgentAllMapper.selectPageRecordByPage(i, migratePageSize);
                        try {
                            log.info("Begin to insert the page:{}",i);
                            List<List<DailyGameTypeMktAgentAll>> partitionList = Lists.partition(pageList, asyncLimit);
                            Integer insertCount = 0;
                            for (List<DailyGameTypeMktAgentAll> partition : partitionList) {
                                insertCount += localDailyGameTypeMktAgentAllMapper.batchDailyGameTypeMktAgentAllInsert(partition);
                            }
                            log.info("Insert the page {} Finish ",i);
                            latch.countDown();
                            return insertCount;
                        } catch (Exception e) {
                            log.error("Error!", e);
                            latch.countDown();
                            return null;
                        }

                    })).collect(Collectors.toList());
            latch.await();
            log.info("Async insert finish !");
            response = futureRecords.stream().map(f -> {
                try {
                    return f.get();
                } catch (InterruptedException | ExecutionException e) {
                    log.error("Error!", e);
                }
                return null;
            }).filter(Objects::nonNull).reduce(Integer::sum).orElse(null);

        }catch (Exception e){
            log.error("Failed to async insert from ByteHouse to Local !",e);
        }
        log.info(" Response : {} ", response);
    }

}
