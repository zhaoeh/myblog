package com.mkt.agent.job;

import com.mkt.agent.ds.annotation.EnableDS;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.annotation.Transactional;

@EnableDiscoveryClient
@EnableFeignClients
@EnableRetry
@EnableAsync(proxyTargetClass = true)
@SpringBootApplication(scanBasePackages = {"com.mkt.agent.job", "com.mkt.agent.common", "com.mkt.agent.integration"},exclude = {
        JpaRepositoriesAutoConfiguration.class,
        HibernateJpaAutoConfiguration.class
})
@EnableDS
public class AgentJobApplication {
    public static void main(String[] args) {
        SpringApplication.run(AgentJobApplication.class);
    }
}
