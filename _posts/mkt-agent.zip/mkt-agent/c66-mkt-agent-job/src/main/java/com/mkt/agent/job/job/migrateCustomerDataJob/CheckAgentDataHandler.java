package com.mkt.agent.job.job.migrateCustomerDataJob;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.mkt.agent.common.entity.BaseEntity;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.entity.api.jobapi.requests.CustomerLayerTestRequest;
import com.mkt.agent.common.entity.api.jobapi.responses.CustomerLayerResponse;
import com.mkt.agent.common.utils.SerializationUti;
import com.mkt.agent.job.job.migrateCustomerDataJob.process.AgentCustomersProcess;
import com.mkt.agent.job.migration.MigrationConfig;
import com.mkt.agent.job.service.api.AgentContractService;
import com.mkt.agent.job.service.api.CustomerLayerService;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 同步用户使用，已过期不再使用
 */

@Component
@Slf4j
public class CheckAgentDataHandler extends IJobHandler {

    @Autowired
    private AgentCustomersProcess agentCustomersProcess;

    @Autowired
    private AgentContractService agentContractService;

    @Resource
    private MigrationConfig migrationConfig;

    @Autowired
    private CustomerLayerService customerLayerService;

    @Override
    @XxlJob(value = "CheckAgentDataHandler")
    public void execute() {
        log.info("CheckAgentDataHandler starting");
        initAgentInfo();
        log.info("CheckAgentDataHandler ending");
    }

    /**
     * 初始化代理用户并绑定佣金方案
     */
    public void initAgentInfo() {
        int pageSize = 1000;
        int pageNum = 1;

        List<String> contractPlanNameList = new ArrayList<>();
        contractPlanNameList.add(migrationConfig.getGeneralContract());
        contractPlanNameList.add(migrationConfig.getProfessionalContract());
        // 根据佣金方案名称查询佣金方案id
        List<TAgentContract> agentContractList = agentContractService.listContractByCommissionPlanNames(contractPlanNameList);
        if (CollectionUtils.isEmpty(agentContractList)) {
            log.info("updateAgentTypeAndBindContract 没有查到佣金方案名称，plan name={}", contractPlanNameList);
            return;
        }
        log.info("search default contract finished");
        Map<String, Long> contractMap = agentContractList.stream().collect(Collectors.toMap(TAgentContract::getCommissionPlanName, BaseEntity::getId));
        Map<String, String> contractPercentDetailMap = agentContractList.stream().collect(Collectors.toMap(TAgentContract::getCommissionPlanName, TAgentContract::getPercentageDetails));
        // 初始化佣金方案详情
        List<SettlementPercentageReq> initList = new ArrayList<>();
        initList.add(new SettlementPercentageReq());
        String initPercentDetailJson = SerializationUti.serializeToString(initList);

        CustomerLayerTestRequest customerLayerTestPageRequest = new CustomerLayerTestRequest();
        customerLayerTestPageRequest.setPageSize(pageSize);
        nextPage(customerLayerTestPageRequest,pageNum, contractMap, contractPercentDetailMap, initPercentDetailJson);
    }

    private void nextPage(CustomerLayerTestRequest request,int pageNum,Map<String, Long> contractMap,Map<String, String> contractPercentDetailMap,String initPercentDetailJson) {

        while (true){
            request.setPageNum(pageNum);
            log.info("The current page is:{}",pageNum);
            // 未初始化代理
            List<CustomerLayerResponse> initAgentList = customerLayerService.listInitAgentCustomerLayerTest(request);
            log.info("initAgentInfo initAgentList size={}, pageSize={}", initAgentList.size(),  request.getPageSize());
            if (CollectionUtils.isEmpty(initAgentList)) {
                log.info("initAgentInfo 没有未初始化的代理");
                break;
            }
            initAgentList.forEach(initAgent -> agentCustomersProcess.processDataForCheck(initAgent, contractMap, contractPercentDetailMap, initPercentDetailJson));
            pageNum++;
        }
        log.info("Handle agent data successfully!");
    }
}
