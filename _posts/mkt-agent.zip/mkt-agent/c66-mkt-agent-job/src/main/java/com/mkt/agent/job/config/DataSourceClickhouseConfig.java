package com.mkt.agent.job.config;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.core.MybatisConfiguration;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import com.baomidou.mybatisplus.extension.spring.MybatisSqlSessionFactoryBean;
import com.mkt.agent.common.config.JdbcParamsConfig;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.logging.stdout.StdOutImpl;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import ru.yandex.clickhouse.BalancedClickhouseDataSource;
import ru.yandex.clickhouse.settings.ClickHouseProperties;

import javax.annotation.Resource;

/**
 * @Description TODO--
 * @Classname DataSourceClickhouseConfig
 * @Date 2023/11/22 12:22
 * @Created by TJSLucian
 */
//@Configuration
//@MapperScan(sqlSessionFactoryRef = "clickhouseSqlSessionFactory", basePackages = {"com.mkt.agent.job.clickhouse.mapper"})
public class DataSourceClickhouseConfig {

    /*@Resource
    private JdbcParamsConfig jdbcParamsConfig ;

    @Value("${spring.datasource.secondary.username}")
    private String userName;
    @Value("${spring.datasource.secondary.password}")
    private String password;
    @Value("${spring.datasource.secondary.driver-class-name}")
    private String driverClassName;
    @Value("${spring.datasource.secondary.url}")
    private String url;

    @Bean("clickhouseMybatisPlusInterceptor")
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor mybatisPlusInterceptor = new MybatisPlusInterceptor();
        mybatisPlusInterceptor.addInnerInterceptor(new PaginationInnerInterceptor(DbType.CLICK_HOUSE));
        return mybatisPlusInterceptor;
    }

    @Bean("clickHouseDataSource")
    public HikariDataSource clickhouseDataSource(){
        ClickHouseProperties properties = new ClickHouseProperties();

        properties.setUseServerTimeZone(false);
        properties.setUseTimeZone(jdbcParamsConfig.getUseTimeZone());
        if(StringUtils.isNotEmpty(userName) && StringUtils.isNotEmpty(password)){
            properties.setUser(userName);
            properties.setPassword(password);
        }

        properties.setSocketTimeout(jdbcParamsConfig.getSocketTimeout());

        BalancedClickhouseDataSource balancedClickhouseDataSource = new BalancedClickhouseDataSource(url, properties);
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setDriverClassName(driverClassName);
        hikariConfig.setConnectionTimeout(jdbcParamsConfig.getConnectionTimeout());
        hikariConfig.setIdleTimeout(jdbcParamsConfig.getIdleTimeout());
        hikariConfig.setMaximumPoolSize(jdbcParamsConfig.getMaxPoolSize());
        hikariConfig.setMinimumIdle(jdbcParamsConfig.getMinIdle());
        hikariConfig.setMaxLifetime(jdbcParamsConfig.getMaxLifetime());
        hikariConfig.setDataSource(balancedClickhouseDataSource);
        return new HikariDataSource(hikariConfig);
    }

    @Bean("clickhouseSqlSessionFactory")
    public SqlSessionFactory clickhouseSqlSessionFactory(@Qualifier("clickHouseDataSource")HikariDataSource hikariDataSource,@Qualifier("clickhouseMybatisPlusInterceptor") MybatisPlusInterceptor clickhouseMybatisPlusInterceptor) throws Exception {
        MybatisSqlSessionFactoryBean bean = new MybatisSqlSessionFactoryBean();
        bean.setDataSource(hikariDataSource);
        bean.setTypeAliasesPackage("com.mkt.agent.common.entity.clickhouse.**");
        bean.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:clickhouseMapper/*.xml"));
        bean.setPlugins(clickhouseMybatisPlusInterceptor);

        MybatisConfiguration configuration = new MybatisConfiguration();
        configuration.setMapUnderscoreToCamelCase(true);
        //打印sql语句
        configuration.setLogImpl(StdOutImpl.class);
        configuration.setCacheEnabled(false);
        bean.setConfiguration(configuration);

        SqlSessionFactory factory = bean.getObject();

        return factory;
    }*/


}
