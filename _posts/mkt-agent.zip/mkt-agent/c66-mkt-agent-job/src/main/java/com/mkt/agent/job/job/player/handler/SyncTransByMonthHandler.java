package com.mkt.agent.job.job.player.handler;

import com.mkt.agent.job.job.player.process.SyncTransByMonthProcess;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @description: 同步玩家数据定时任务--月
 * @author: Lucian
 * @create: 2024-02-01
 **/
@Component
@Slf4j
public class SyncTransByMonthHandler extends IJobHandler {

    @Resource
    private SyncTransByMonthProcess syncTransByMonthProcess;

    @XxlJob(value = "SyncTransByMonthHandler")
    @Override
    public void execute() throws Exception {
        syncTransByMonthProcess.syncUsersGroupByMonth();
    }
}
