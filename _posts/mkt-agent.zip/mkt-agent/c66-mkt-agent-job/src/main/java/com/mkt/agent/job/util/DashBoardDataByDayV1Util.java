package com.mkt.agent.job.util;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mkt.agent.common.config.DashBoardConfig;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.api.jobapi.responses.AgentDetails;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.*;
import com.mkt.agent.common.enums.CommissionPlanTypeEnum;
import com.mkt.agent.common.utils.*;
import com.mkt.agent.job.clickhouse.mapper.ClDashBoardV1Mapper;
import com.mkt.agent.job.mapper.CommissionRecordMapper;
import com.mkt.agent.job.mapper.DashBoardHistoryByDayMapper;
import com.mkt.agent.job.mapper.api.AgentContractMapper;
import com.mkt.agent.job.mapper.api.ContractBindMapper;
import com.mkt.agent.job.service.api.AgentService;
import com.mkt.agent.job.service.api.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @Description TODO
 * @Classname DashBoardUtil
 * @Date 2023/12/6 16:06
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class DashBoardDataByDayV1Util {

    @Resource
    private ClDashBoardV1Mapper clDashBoardV1Mapper;

    @Autowired
    private DashBoardConfig dashBoardConfig;

    @Autowired
    private UserService userService;

    @Autowired
    private DashBoardCommonUtil dashBoardCommonUtil;

    @Autowired
    private AgentService agentService;

    @Autowired
    private DashBoardHistoryByDayMapper dashBoardHistoryByDayMapper;

    @Resource
    private Gson gson;

    @Resource
    private RedisUtil redisUtil;

    @Resource
    private CommissionRecordMapper commissionRecordMapper;

    @Resource
    private ContractBindMapper contractBindMapper;


    public void handleByLevelByDay(int level, LocalDate recordDateStart, LocalDate recordDateEnd ,String handleType){

        log.info("[handleByLevelByDay]Begin to handle level:{}",level);

        List<TAgentCustomers> agentList = null;
        if(handleType.equals(Constants.HISTORY_DATA)){
            //获取某天未同步的代理
            agentList = agentService.queryUncheckedAgents(recordDateStart.toString(),recordDateEnd.toString(),level);
        }else {
            //获取所有代理
            agentList = agentService.queryAgentsByTimeNLevel(recordDateStart.toString(),recordDateEnd.toString(),level);
        }

        log.info("The agentList size for level:{} is:{}",level,agentList.size());

        //获取每个代理每天产生的数据
        List<DashBoardHistoryEntity> dashBoardResponsesList = this.getResFromClByDay(agentList,recordDateStart,recordDateEnd,handleType);

        try {

            if(!CollectionUtils.isEmpty(dashBoardResponsesList)){
                log.info("[handleByLevelByDay]The data needed for level:{} to save is :{}",level,gson.toJson(dashBoardResponsesList));
                if(handleType.equals(Constants.HISTORY_DATA)){
                    log.info("[handleByLevelByDay]Begin to save data to database");
                    //存入历史表
                    dashBoardHistoryByDayMapper.insertBatchSomeColumn(dashBoardResponsesList);
                }else if(handleType.equals(Constants.CURRENT_DATA)){
                    log.info("[handleByLevelByDay]Begin to save data to redis");
                    //存入缓存
                    dashBoardCommonUtil.saveRedisForDashBoard(dashBoardResponsesList);
                }
            }

        }catch (Exception e){
            log.error("[handleByLevelByDay]Failed to save data for level:{}",level,e);
        }

        log.info("[handleByLevelByDay]finished to save data for level:{}",level);
        agentList = null;
        dashBoardResponsesList = null;
        level--;

        if(level>0){
            handleByLevelByDay(level,recordDateStart,recordDateEnd,handleType);
        }

    }


    private List<DashBoardHistoryEntity> getResFromClByDay(List<TAgentCustomers> agentList, LocalDate recordDateStartL, LocalDate recordDateEndL , String handleType){

        if(CollectionUtils.isEmpty(agentList)){
            return null;
        }

        List<DashBoardHistoryEntity> allAgentDataList = new ArrayList<>();

        List<String> dateList = DateUtils.getDateRangeAsStr(recordDateStartL,recordDateEndL);

        String recordDateStart = recordDateStartL.toString();
        String recordDateEnd = recordDateEndL.toString();


        agentList.forEach(agent -> {

            String agentAccount = agent.getLoginName();
            log.info("[handleByLevelByDay-getResFromClByDay]Begin to handle data for agent:{} for last month",agentAccount);
            try {

                List<DashBoardHistoryEntity> response = new ArrayList<>();

                String parentAgentAccount = agent.getParentName();

                //存储直属用户数据
                List<DashBoardHistoryEntity> userDataList = null;

                //查询直属用户
                List<String> usersNameList = userService.selectDirectUsersAgentsName(agentAccount);

                //查询直属用户的数据
                if(!CollectionUtils.isEmpty(usersNameList)){
                    log.info("[handleByLevelByDay]The userNameList size for agent:{} is:{}",agentAccount,usersNameList.size());

                    ClDashBoardCreateQueryReq registerQueryReq = ClDashBoardCreateQueryReq.builder().agentAccount(agentAccount).parentAgentAccount(parentAgentAccount).build();

                    dateList.forEach(date -> {
                        registerQueryReq.setRecordDateStart(date);
                        registerQueryReq.setRecordDateEnd(date);
                        registerQueryReq.setRecordDateTimeStart(date + Constants.START_TIME);
                        registerQueryReq.setRecordDateTimeEnd(date + Constants.END_TIME);
                        DashBoardHistoryEntity userCountEntity = userService.selectRegisterUserCountByDay(registerQueryReq);
                        if(!Objects.isNull(userCountEntity)){
                            log.info("[handleByLevelByDay]The registerNumber for agent:{} from:{} to:{} is:{}",agentAccount,date,userCountEntity.getDashDate(),userCountEntity.getRegistrationNumber());
                            response.add(userCountEntity);
                        }
                    });


                    userDataList = this.queryDashBoardDataFromCl(ClDashBoardCreateQueryReq.builder().agentAccount(agentAccount)
                            .loginNameList(usersNameList).recordDateStart(recordDateStart).recordDateEnd(recordDateEnd)
                            .parentAgentAccount(parentAgentAccount).build());

                    log.info("[handleByLevelByDay]Finished to query direct user data for agent:{}",agentAccount);

                    if(!CollectionUtils.isEmpty(userDataList)){
                        log.info("[handleByLevelByDay]The userDataList size for agent:{} is:{}",agentAccount,userDataList.size());
                        response.addAll(userDataList);
                    }

                }

                if(agent.getAgentLevel()!=5){

                    //存储下级代理的数据
                    List<DashBoardHistoryEntity> downlineAgentsDataList = new ArrayList<>();

                    if(handleType.equals(Constants.HISTORY_DATA)){
                        downlineAgentsDataList = dashBoardHistoryByDayMapper.selectList(new LambdaQueryWrapper<DashBoardHistoryEntity>()
                                .ge(DashBoardHistoryEntity::getDashDate,recordDateStart).le(DashBoardHistoryEntity::getDashDate,recordDateEnd).eq(DashBoardHistoryEntity::getParentLoginName,agentAccount));
                    }else if(handleType.equals(Constants.CURRENT_DATA)){

                        List<String> directAgentNames = agentService.selectDirectAgentNames(agentAccount);

                        if(!CollectionUtils.isEmpty(directAgentNames)){
                            log.info("[handleByLevelByDay]The downline agent size is:{}",directAgentNames.size());

                            for(int i=0; i< dateList.size();i++){
                                List<DashBoardHistoryEntity> list = dashBoardCommonUtil.getRedisForDashBoardByDay(directAgentNames,dateList.get(i));
                                if(!CollectionUtils.isEmpty(list)){
                                    downlineAgentsDataList.addAll(list);
                                }
                            }
                        }

                    }


                    if(!CollectionUtils.isEmpty(downlineAgentsDataList)){
                        log.info("[handleByLevelByDay]The downlineAgentsDataList size for agent:{} is:{}",agentAccount,downlineAgentsDataList.size());
                        response.addAll(downlineAgentsDataList);
                    }
                }

                List<DashBoardHistoryEntity> respList = null;
                if(!CollectionUtils.isEmpty(response)){
                    log.info("[handleByLevelByDay]The response for agent:{} is:{}",agentAccount,gson.toJson(response));

                    respList = response.stream().filter(a -> !Objects.isNull(a)).collect(Collectors.groupingBy(DashBoardHistoryEntity::getDashDate)).values().stream()
                            .map(list -> list.stream().reduce((l1,l2) -> sumDataResultV2(l1,l2)).orElseGet(DashBoardHistoryEntity::new)).filter(d -> dashBoardCommonUtil.isNeededSave2(d))
                            .map(e -> this.handleAgentInfo(e,agentAccount,parentAgentAccount))
                            .collect(Collectors.toList());
                }

                log.info("[handleByLevelByDay]Finished to handle data for agent:{}",agentAccount);
                if(!CollectionUtils.isEmpty(respList)){
                    log.info("[handleByLevelByDay]Save data for agent:{} , the current month data is:{}",agentAccount,gson.toJson(respList));
                    allAgentDataList.addAll(respList);
                }

            }catch (Exception e){
                log.info("[handleByLevelByDay]Failed to handle data for agent:{}",agentAccount,e);
            }

        });

        return allAgentDataList;
    }

    private DashBoardHistoryEntity handleAgentInfo(DashBoardHistoryEntity source,String agentAccount,String parentAgentAccount){
        if(!Objects.isNull(source)){
            source.setLoginName(agentAccount);
            source.setParentLoginName(parentAgentAccount);
        }
        return source;
    }

    private List<DashBoardHistoryEntity> queryDashBoardDataFromCl(ClDashBoardCreateQueryReq queryReq){

        log.info("Begin to query dashBoard data for agent:{}",queryReq.getAgentAccount());

        if (queryReq.getLoginNameList().size() <= dashBoardConfig.getBatchQuerySize()) {
            return clDashBoardV1Mapper.queryDashBoardTDataByDay(queryReq);
        } else {

            List<List<String>> batches = Lists.partition(queryReq.getLoginNameList(), dashBoardConfig.getBatchQuerySize());

            Set<ClDashBoardCreateQueryReq> batchQuerys = batches.stream().map(b -> ClDashBoardCreateQueryReq.builder()
                    .loginNameList(b).recordDateStart(queryReq.getRecordDateStart()).recordDateEnd(queryReq.getRecordDateEnd())
                    .agentAccount(queryReq.getAgentAccount()).parentAgentAccount(queryReq.getParentAgentAccount()).build()).collect(Collectors.toSet());

            List<DashBoardHistoryEntity> response = batchQuerys.stream().map(q -> clDashBoardV1Mapper.queryDashBoardTDataByDay(q))
                    .reduce((r1,r2) -> Stream.concat(r1.stream(),r2.stream()).collect(Collectors.toList())).orElse(Collections.emptyList());
            return response;
        }

    }

    private DashBoardHistoryEntity sumDataResultV2(DashBoardHistoryEntity source,DashBoardHistoryEntity increment){
        if(!Objects.isNull(increment)&&!Objects.isNull(source)){
            source.setRegistrationNumber(source.getRegistrationNumber()+increment.getRegistrationNumber());
            source.setFirstDepositPlayers(source.getFirstDepositPlayers()+increment.getFirstDepositPlayers());
            source.setTurnover(source.getTurnover().add(increment.getTurnover()));
            source.setGgr(source.getGgr().add(increment.getGgr()));
            source.setFirstDepositAmount(source.getFirstDepositAmount().add(increment.getFirstDepositAmount()));
            source.setDeposit(source.getDeposit().add(increment.getDeposit()));
            source.setWithdraw(source.getWithdraw().add(increment.getWithdraw()));
        }
        return source;
    }

    public void handleTopData(int level){

        log.info("[handleTopData]Begin to handle topData for level:{}",level);

        //获取级当前层级代理
        List<TAgentCustomers> agentList = agentService.selectAgentPNamesByLevel(level);

        //获取每个代理的turnoverTop数据
        List<ClTurnoverTopRespVo> turnoverTopVoList = this.handleTurnoverTopForAgent(agentList);

        log.info("[handleTopData]finished to query turnover top data level:{}, begin to save data to redis",level);

        try {
            if(!CollectionUtils.isEmpty(turnoverTopVoList)){
                turnoverTopVoList.forEach(turnoverTopVo -> {
                    String topKey = Constants.CURRENT_USER_TURNOVER_TOP_CACHE_PREFIX + turnoverTopVo.getAgentAccount();
                    String topValue = gson.toJson(turnoverTopVo.getTurnoverTopRespList());
                    redisUtil.setByTimeUnit(topKey, topValue, 1, TimeUnit.DAYS);
                });
            }

        }catch (Exception e){
            log.error("[handleTopData]Failed to save data for level:{}",level,e);
        }

        log.info("[handleTopData]finished to save data for level:{}",level);
        level--;

        if(level>0){
            handleTopData(level);
        }

    }

    private List<ClTurnoverTopRespVo> handleTurnoverTopForAgent(List<TAgentCustomers> agentList){

        if(CollectionUtils.isEmpty(agentList)){
            return null;
        }

        List<ClTurnoverTopRespVo> responseList = new ArrayList<>();


        agentList.forEach(agent -> {

            String agentAccount = agent.getLoginName();
            try {

                List<ClTurnoverTopResp> directList = null;
                List<ClTurnoverTopResp> downlineList = null;
                        //查询直属用户
                List<String> usersNameList = userService.selectDirectUsersAgentsName(agentAccount);

                if(!CollectionUtils.isEmpty(usersNameList)){
                    log.info("[handleTurnoverTopForAgent]Begin to handle turnover top data for agent:{}",agentAccount);
                    //查询该代理的turnoverTop
                    directList = getTurnoverTopFromCl(ClDashBoardCreateQueryReq.builder()
                            .loginNameList(usersNameList).agentAccount(agentAccount).build());
                }

                if(agent.getAgentLevel()!=5){

                    log.info("[handleTopData]Begin to sum direct users and downline agents for agent:{}",agentAccount);

                    //获取直属下级代理
                    List<TAgentCustomers> agentCustomersList = agentService.queryDirectAgents(agentAccount);

                    //从缓存中取直属下级的柱状图
                    downlineList = getTurnoverTopFromRedis(agentCustomersList);

                }

                if(!CollectionUtils.isEmpty(directList) || !CollectionUtils.isEmpty(downlineList)){

                    ClTurnoverTopRespVo turnoverTopRespVo = new ClTurnoverTopRespVo();
                    turnoverTopRespVo.setAgentAccount(agentAccount);

                    if(!CollectionUtils.isEmpty(directList)){
                        turnoverTopRespVo.getTurnoverTopRespList().addAll(directList);
                    }

                    if(!CollectionUtils.isEmpty(downlineList)){
                        turnoverTopRespVo.getTurnoverTopRespList().addAll(downlineList);
                    }

                    log.info("[handleTurnoverTopForAgent]The response before handle all topList is:{}",gson.toJson(turnoverTopRespVo.getTurnoverTopRespList()));

                    turnoverTopRespVo.setTurnoverTopRespList(turnoverTopRespVo.getTurnoverTopRespList().stream()
                            .sorted(Comparator.comparing(ClTurnoverTopResp::getTurnoverSum).reversed()).limit(10).collect(Collectors.toList()));
                    log.info("[handleTurnoverTopForAgent]The response before handle all topList is:{}",gson.toJson(turnoverTopRespVo.getTurnoverTopRespList()));
                    responseList.add(turnoverTopRespVo);

                }

            }catch (Exception e){
                log.error("[handleTopData]Query clickhouse failded for agent:{}!",agentAccount,e);
            }

        });

        return responseList;

    }


    private List<ClTurnoverTopResp> getTurnoverTopFromCl(ClDashBoardCreateQueryReq queryReq){

        log.info("/dashBoard/turnoverTop 入参loginName：{}", queryReq.getAgentAccount());

        List<String> userNameList = queryReq.getLoginNameList();

        if (userNameList.size() <= dashBoardConfig.getBatchQuerySize()) {
            return clDashBoardV1Mapper.topList(queryReq);
        } else{
            List<List<String>> batches = Lists.partition(userNameList, dashBoardConfig.getBatchQuerySize());

            Set<ClDashBoardCreateQueryReq> batchQuerys = batches.stream().map(b -> ClDashBoardCreateQueryReq.builder()
                    .loginNameList(b)
                    .build()).collect(Collectors.toSet());

            List<ClTurnoverTopResp> turnoverTopList = batchQuerys.stream().map(q -> clDashBoardV1Mapper.topList(q))
                    .reduce((d1,d2) -> {
                        d1 = Stream.concat(d1.stream(),d2.stream())
                                .sorted((t1,t2) -> t2.getTurnoverSum().compareTo(t1.getTurnoverSum()))
                                .limit(10)
                                .collect(Collectors.toList());
                        return d1;
                    }).orElse(Collections.emptyList());
            return turnoverTopList;
        }
    }

    //从缓存中取每个代理的柱状图数据
    public List<ClTurnoverTopResp> getTurnoverTopFromRedis(List<TAgentCustomers> agentCustomersList){

        if(CollectionUtils.isEmpty(agentCustomersList)){
            return null;
        }

        List<ClTurnoverTopResp> list = new ArrayList<>();

        try {

            agentCustomersList.forEach(agent -> {
                Object value = redisUtil.get(Constants.CURRENT_USER_TURNOVER_TOP_CACHE_PREFIX + agent.getLoginName());
                if(!Objects.isNull(value)){
//                    List<ClTurnoverTopResp> cacheList = gson.fromJson(value.toString(), List.class);
                    List<ClTurnoverTopResp> cacheList = gson.fromJson(value.toString(), new TypeToken<List<ClTurnoverTopResp>>(){}.getType());
                    if(!CollectionUtils.isEmpty(cacheList)){
                        list.addAll(cacheList);
                    }
                }

            });

        }catch (Exception e){
            log.info("Get turnover top 10 from redis Failed!");
            return null;
        }
        return list;
    }


    public void handleDistriData(int level){

        log.info("[handleDistriData]Begin to handle DistriData for level:{}",level);

        //获取级当前层级代理
        List<TAgentCustomers> agentList = agentService.selectAgentPNamesByLevel(level);

        //获取每个代理的turnoverTop数据
        List<ClTurnoverDistriRespVo> turnoverDistriVoList = this.handleTurnoverDistriForAgent(agentList);

        log.info("[handleDistriData]finished to query DistriData top data level:{}, begin to save data to redis",level);

        try {
            if(!CollectionUtils.isEmpty(turnoverDistriVoList)){
                turnoverDistriVoList.forEach(turnoverDistriVo -> {
                    String distriKey = Constants.CURRENT_USER_TURNOVER_DSITRI_CACHE_PREFIX + turnoverDistriVo.getAgentAccount();
                    String distriValue = gson.toJson(turnoverDistriVo.getClTurnoverDistriList());
                    log.info("[save distri data] The distriKey is:{}, the distriValue is:{}", distriKey,distriValue);
                    redisUtil.setByTimeUnit(distriKey, distriValue, 1, TimeUnit.DAYS);
                });
            }

        }catch (Exception e){
            log.error("[handleDistriData]Failed to save data for level:{}",level,e);
        }

        log.info("[handleDistriData]finished to save data for level:{}",level);
        level--;

        if(level>0){
            handleDistriData(level);
        }

    }

    private List<ClTurnoverDistriRespVo> handleTurnoverDistriForAgent(List<TAgentCustomers> agentList){

        if(CollectionUtils.isEmpty(agentList)){
            return null;
        }

        List<ClTurnoverDistriRespVo> responseList = new ArrayList<>();

        agentList.forEach(agent -> {

            String agentAccount = agent.getLoginName();

            try {

                List<ClTurnoverDistriResp> directList = null;
                List<ClTurnoverDistriResp> downlineList = null;

                //查询直属用户
                List<String> usersNameList = userService.selectDirectUsersAgentsName(agentAccount);

                if(!CollectionUtils.isEmpty(usersNameList)){
                    log.info("[handleDistriData]Begin to handle turnover Distri data for agent:{}",agentAccount);

                    directList = getTurnoverDistriFromCl(ClDashBoardCreateQueryReq.builder()
                            .loginNameList(usersNameList).agentAccount(agentAccount).build());
                }

                if(agent.getAgentLevel()!=5){

                    log.info("[handleDistriData]Begin to sum direct users and downline agents for agent:{}",agentAccount);

                    //获取直属下级代理
                    List<TAgentCustomers> agentCustomersList = agentService.queryDirectAgents(agentAccount);

                    downlineList = getTurnoverDistriFromRedis(agentCustomersList);
                }

                if(!CollectionUtils.isEmpty(directList) || !CollectionUtils.isEmpty(downlineList)){

                    ClTurnoverDistriRespVo turnoverDistriRespVo = new ClTurnoverDistriRespVo();
                    turnoverDistriRespVo.setAgentAccount(agentAccount);
                    if(!CollectionUtils.isEmpty(directList)){
                        turnoverDistriRespVo.getClTurnoverDistriList().addAll(directList);
                    }

                    if(!CollectionUtils.isEmpty(downlineList)){
                        turnoverDistriRespVo.getClTurnoverDistriList().addAll(downlineList);
                    }

                    if(!CollectionUtils.isEmpty(turnoverDistriRespVo.getClTurnoverDistriList())){

                        log.info("[handleDistriData]The distri data before sum for agent:{} is:{}",agentAccount,gson.toJson(turnoverDistriRespVo.getClTurnoverDistriList()));

                        turnoverDistriRespVo.setClTurnoverDistriList(Optional.ofNullable(turnoverDistriRespVo.getClTurnoverDistriList())
                                .map(list -> list.stream().collect(Collectors.groupingBy(ClTurnoverDistriResp::getGameType)).values().stream().
                                        map(listItem -> listItem.stream().reduce((d1,d2) -> {
                                            d1.setTurnoverSum(d1.getTurnoverSum().add(d2.getTurnoverSum()));
                                            return d1;
                                        }).orElseGet(ClTurnoverDistriResp::new)).collect(Collectors.toList())).orElseGet(ArrayList::new));
                    }

                    log.info("[handleDistriData]The distri data after sum for agent:{} is:{}",agentAccount,gson.toJson(turnoverDistriRespVo.getClTurnoverDistriList()));

                    responseList.add(turnoverDistriRespVo);

                }

            }catch (Exception e){
                log.info("[handleDistriData]Failed to handle turnoverDistriData for agent:{}",agentAccount);
            }

        });

        return responseList;
    }

    private List<ClTurnoverDistriResp> getTurnoverDistriFromCl(ClDashBoardCreateQueryReq queryReq){

        log.info("/dashBoard/getTurnoverDistriFromCl 入参loginName：{}", queryReq.getAgentAccount());

        List<String> userNameList = queryReq.getLoginNameList();

        try {
            if (userNameList.size() <= dashBoardConfig.getBatchQuerySize()) {
                return clDashBoardV1Mapper.distriList(queryReq);
            } else{
                List<List<String>> batches = Lists.partition(userNameList, dashBoardConfig.getBatchQuerySize());

                Set<ClDashBoardCreateQueryReq> batchQuerys = batches.stream().map(b -> ClDashBoardCreateQueryReq.builder()
                        .loginNameList(b)
                        .build()).collect(Collectors.toSet());

                List<ClTurnoverDistriResp> turnoverDistriList = batchQuerys.stream().map(q -> clDashBoardV1Mapper.distriList(q))
                        .reduce((l1, l2) -> Stream.concat(l1.stream(), l2.stream())
                                .collect(Collectors.toList())).orElse(Collections.emptyList());
                return turnoverDistriList;
            }
        }catch (Exception e){
            log.error("[handleDistriData]Query turnoverTop failed",e);
        }
        return null;
    }

    //从缓存中取每个代理的柱状图数据
    public List<ClTurnoverDistriResp> getTurnoverDistriFromRedis(List<TAgentCustomers> agentCustomersList){

        if(CollectionUtils.isEmpty(agentCustomersList)){
            return null;
        }

        List<ClTurnoverDistriResp> list = new ArrayList<>();

        try {

            agentCustomersList.forEach(agent -> {
                Object value = redisUtil.get(Constants.CURRENT_USER_TURNOVER_DSITRI_CACHE_PREFIX + agent.getLoginName());
                if(!Objects.isNull(value)){
                    List<ClTurnoverDistriResp> cacheList = gson.fromJson(value.toString(), new TypeToken<List<ClTurnoverDistriResp>>(){}.getType());
                    if(!CollectionUtils.isEmpty(cacheList)){
                        list.addAll(cacheList);
                    }
                }

            });

        }catch (Exception e){
            log.info("[handleDistriData]Get turnover top 10 from redis Failed!");
            return null;
        }
        return list;
    }

    public void handleCommission(){

        //当月
        LocalDate currentMonthFirstDay = DateUtils.getLastNMonthFirstDay(0);
        LocalDate currentMonthLastDay = DateUtils.getLastNMonthLastDay(0);

        //上个月
        LocalDate lastMonthFirstDay = DateUtils.getLastNMonthFirstDay(1);
        LocalDate lastMonthLastDay = DateUtils.getLastNMonthLastDay(1);
        //上上个月
        LocalDate last2MonthFirstDay = DateUtils.getLastNMonthFirstDay(2);
        LocalDate last2MonthLastDay = DateUtils.getLastNMonthLastDay(2);
        //当周
        LocalDate currentWeekFirstDay = DateUtils.getNWeeksAgoMonday(0);
        LocalDate currentWeekLastDay = DateUtils.getNWeeksAgoSunday(0);
        //上周
        LocalDate lastWeekFirstDay = DateUtils.getNWeeksAgoMonday(1);
        LocalDate lastWeekLastDay = DateUtils.getNWeeksAgoSunday(1);
        //上上周
        LocalDate last2WeekFirstDay = DateUtils.getNWeeksAgoMonday(2);
        LocalDate last2WeekLastDay = DateUtils.getNWeeksAgoSunday(2);

        //今天
        LocalDate currentDay = DateUtils.getNDaysAgo(0);
        //昨天
        LocalDate yesterday = DateUtils.getNDaysAgo(1);
        //前天
        LocalDate last2Day = DateUtils.getNDaysAgo(2);

        doHandleCommissionByTop(currentMonthFirstDay,currentMonthLastDay,lastMonthFirstDay,lastMonthLastDay,last2MonthFirstDay,last2MonthLastDay,currentWeekFirstDay,currentWeekLastDay,lastWeekFirstDay,lastWeekLastDay,last2WeekFirstDay,last2WeekLastDay,currentDay,yesterday,last2Day);
    }

    private void doHandleCommissionByTop(LocalDate currentMonthFirstDay,LocalDate currentMonthLastDay,LocalDate lastMonthFirstDay,LocalDate lastMonthLastDay,LocalDate last2MonthFirstDay,LocalDate last2MonthLastDay,LocalDate currentWeekFirstDay,LocalDate currentWeekLastDay,LocalDate lastWeekFirstDay,LocalDate lastWeekLastDay,LocalDate last2WeekFirstDay,LocalDate last2WeekLastDay,LocalDate currentDay,LocalDate yesterday,LocalDate last2Day){

        //获取顶级代理
        List<AgentDetails> agentList = agentService.selectTopAgents();

        if(!CollectionUtils.isEmpty(agentList)){

            for (AgentDetails agent : agentList) {

                List<DashBoardCommissionVo> list = new ArrayList<>();
                String agentAccount = agent.getLoginName();
                List<String> topAgentTeam = null;
                try {

                    if(Objects.isNull(agent)){
                        continue;
                    }

                    if(agent.getSettlementConditions() == 1){
                        //有条件
                        topAgentTeam = userService.selectTeamUserNames(agentAccount);

                    }

                    //获取下级代理
                    List<AgentDetails> downLineAgentDetailsList = agentService.selectAgentTree(agentAccount);

                    handleTeamCommission(agentAccount, currentMonthFirstDay,currentMonthLastDay,lastMonthFirstDay,
                            lastMonthLastDay,last2MonthFirstDay,last2MonthLastDay,currentWeekFirstDay,
                            currentWeekLastDay,lastWeekFirstDay,lastWeekLastDay,last2WeekFirstDay,
                            last2WeekLastDay,currentDay,yesterday,last2Day, agent,topAgentTeam,downLineAgentDetailsList,list);

                    if(!CollectionUtils.isEmpty(list)){
                        list.forEach(commissionRespVo -> {
                            String key = Constants.COMMISSION_CACHE_PREFIX + commissionRespVo.getAgentAccount() + commissionRespVo.getRecordDateStart()+commissionRespVo.getRecordDateEnd();
                            BigDecimal value = commissionRespVo.getCommission();
                            log.info("The cache key is:{},value is:{}",key,value);
                            redisUtil.setByTimeUnit(key, value, 61, TimeUnit.DAYS);
                        });
                    }

                }catch (Exception e){
                    log.info("HandleCommission failed for topAgent:{}!",agentAccount,e);
                }

            }

            log.info("finished to save commission data");

        }

    }

    private void handleTeamCommission(String agentAccount, LocalDate currentMonthFirstDay,LocalDate currentMonthLastDay,LocalDate lastMonthFirstDay,
                                                             LocalDate lastMonthLastDay,LocalDate last2MonthFirstDay,LocalDate last2MonthLastDay,LocalDate currentWeekFirstDay,
                                                             LocalDate currentWeekLastDay,LocalDate lastWeekFirstDay,LocalDate lastWeekLastDay,LocalDate last2WeekFirstDay,
                                                             LocalDate last2WeekLastDay,LocalDate currentDay,LocalDate yesterday,LocalDate last2Day,
                                                             AgentDetails agent,List<String> topAgentTeam,List<AgentDetails> downLineAgentDetailsList,List<DashBoardCommissionVo> list){



        //1.月类型 当月
        List<DashBoardCommissionVo> currentMonthVo = beforeHandleCommission(agentAccount,currentMonthFirstDay,currentMonthLastDay,Constants.CURRENT_MONTH,agent,topAgentTeam,downLineAgentDetailsList);
        if(!CollectionUtils.isEmpty(currentMonthVo)){
            list.addAll(currentMonthVo);
        }
        //1.月类型 上月
        List<DashBoardCommissionVo> lastMonthVo = beforeHandleCommission(agentAccount,lastMonthFirstDay,lastMonthLastDay,Constants.LAST_MONTH,agent,topAgentTeam,downLineAgentDetailsList);
        if(!CollectionUtils.isEmpty(lastMonthVo)){
            list.addAll(lastMonthVo);
        }
        //1.月类型 上上月
        List<DashBoardCommissionVo> last2MonthVo = beforeHandleCommission(agentAccount,last2MonthFirstDay,last2MonthLastDay,Constants.LAST2_MONTH,agent,topAgentTeam,downLineAgentDetailsList);
        if(!CollectionUtils.isEmpty(last2MonthVo)){
            list.addAll(last2MonthVo);
        }
        //1.周类型 当周
        List<DashBoardCommissionVo> currentWeekVo = beforeHandleCommission(agentAccount,currentWeekFirstDay,currentWeekLastDay,Constants.CURRENT_WEEK,agent,topAgentTeam,downLineAgentDetailsList);
        if(!CollectionUtils.isEmpty(currentWeekVo)){
            list.addAll(currentWeekVo);
        }
        //1.周类型 上周
        List<DashBoardCommissionVo> lastWeekVo = beforeHandleCommission(agentAccount,lastWeekFirstDay,lastWeekLastDay,Constants.LAST_WEEK,agent,topAgentTeam,downLineAgentDetailsList);
        if(!CollectionUtils.isEmpty(lastWeekVo)){
            list.addAll(lastWeekVo);
        }
        //1.周类型 上上周
        List<DashBoardCommissionVo> last2WeekVo = beforeHandleCommission(agentAccount,last2WeekFirstDay,last2WeekLastDay,Constants.LAST2_WEEK,agent,topAgentTeam,downLineAgentDetailsList);
        if(!CollectionUtils.isEmpty(last2WeekVo)){
            list.addAll(last2WeekVo);
        }
        //1.天类型 当天
        List<DashBoardCommissionVo> currentDayVo = beforeHandleCommission(agentAccount,currentDay,currentDay,Constants.CURRENT_DAY,agent,topAgentTeam,downLineAgentDetailsList);
        if(!CollectionUtils.isEmpty(currentDayVo)){
            list.addAll(currentDayVo);
        }
        //1.天类型 昨天
        List<DashBoardCommissionVo> LastDayVo = beforeHandleCommission(agentAccount,yesterday,yesterday,Constants.LAST_DAY,agent,topAgentTeam,downLineAgentDetailsList);
        if(!CollectionUtils.isEmpty(LastDayVo)){
            list.addAll(LastDayVo);
        }
        //1.天类型 前天
        List<DashBoardCommissionVo> Last2DayVo = beforeHandleCommission(agentAccount,last2Day,last2Day,Constants.LAST2_DAY,agent,topAgentTeam,downLineAgentDetailsList);
        if(!CollectionUtils.isEmpty(Last2DayVo)){
            list.addAll(Last2DayVo);
        }


    }

    private List<DashBoardCommissionVo> beforeHandleCommission(String agentAccount, LocalDate recordDateStart, LocalDate recordDateEnd, String type, AgentDetails agentDetails,List<String> topAgentTeam, List<AgentDetails> downLineAgentDetailsList){

        log.info("[beforeHandleCommission]beforeHandleCommission for agent:{}, type:{}",agentAccount,type);


        if(!(type.equals(Constants.LAST_MONTH) || type.equals(Constants.LAST2_MONTH))){
            if(agentDetails.getSettlementConditions() == 1){
                //有条件
                Long realActiveCount = 0L;

                if(!CollectionUtils.isEmpty(topAgentTeam)){
                    realActiveCount = this.getRealUsersFromCl(ClDashBoardCreateQueryReq.builder().agentAccount(agentAccount).loginNameList(topAgentTeam).recordDateStart(recordDateStart.toString())
                            .recordDateEnd(recordDateEnd.toString()).activeAmount(agentDetails.getActiveUserTurnover()).planType(agentDetails.getCommissionPlanType()).build());
                    log.info("The realActiveCount for top agent:{} is:{}",agentAccount,realActiveCount);
                }

                if(realActiveCount < agentDetails.getActiveUserHeadcount()){
                    log.info("[doHandleCommission-checkTopAgent] The agent:{} or the level one agent doesn't have enough real active users!",agentAccount);
                    return null;
                }

            }
        }

        return doHandleCommission(agentDetails,recordDateStart,recordDateEnd,type,downLineAgentDetailsList);

    }


    private List<DashBoardCommissionVo> doHandleCommission(AgentDetails topAgentDetails, LocalDate recordDateStart, LocalDate recordDateEnd, String type, List<AgentDetails> downLineAgentDetailsList){

        String topAgentAccount = topAgentDetails.getLoginName();

        log.info("doHandleCommission for agent:{}, The params is recordDateStart:{},recordDateEnd:{},type:{}",topAgentAccount,recordDateStart.toString(),recordDateEnd.toString(),type);

        List<DashBoardCommissionVo> response = new ArrayList<>();

        List<AgentDetails> handledAgentDetails = new ArrayList<>();
        handledAgentDetails.add(topAgentDetails);

        if(!CollectionUtils.isEmpty(downLineAgentDetailsList)){
            handledAgentDetails.addAll(downLineAgentDetailsList);
        }

        for(AgentDetails perAgent : handledAgentDetails){

            String commissionType = perAgent.getCommissionPlanType();
            String perAgentAccount = perAgent.getLoginName();

            List<String> currentDateList = null;

            List<String> historyDateList = null;

            BigDecimal turnoverSum = BigDecimal.ZERO;
            BigDecimal ggrSum = BigDecimal.ZERO;

            if(type.equals(Constants.LAST_MONTH) || type.equals(Constants.LAST2_MONTH)){
                //上个月 上上个月
                DashBoardCommissionVo historyCommission = commissionRecordMapper.queryCommissionByNameDate(ClDashBoardCreateQueryReq.builder().agentAccount(perAgentAccount)
                        .recordDateStart(recordDateStart.toString()).recordDateEnd(recordDateEnd.toString()).build());
                if(Objects.isNull(historyCommission)){
                    historyCommission = DashBoardCommissionVo.builder().commission(BigDecimal.ZERO.setScale(2,RoundingMode.DOWN)).agentAccount(perAgentAccount).build();
                }
                historyCommission.setRecordDateStart(recordDateStart.toString());
                historyCommission.setRecordDateEnd(recordDateEnd.toString());

                log.info("The last2month commission for agent:{} is :{}",perAgentAccount,gson.toJson(historyCommission));
                response.add(historyCommission);
            }else {
                //当月、当天
                if(type.equals(Constants.CURRENT_MONTH) || type.equals(Constants.CURRENT_DAY)){

                    currentDateList = DateUtils.getDateRangeAsStr(recordDateStart,recordDateEnd);

                }else {
                    //当周，上周，上上周，昨天，前天
                    if(DateUtils.isSameMonth(recordDateStart,recordDateEnd)){

                        if(recordDateStart.getMonth() == LocalDate.now().getMonth()){
                            //当月数据
                            currentDateList = DateUtils.getDateRangeAsStr(recordDateStart,recordDateEnd);
                        }else {
                            //上月数据
                            historyDateList = DateUtils.getDateRangeAsStr(recordDateStart,recordDateEnd);
                        }

                    }else {
                        //跨月
                        currentDateList = DateUtils.getDateRangeAsStr(DateUtils.getLastNMonthFirstDay(0),recordDateEnd);
                        historyDateList = List.of(recordDateStart.toString(),DateUtils.getLastNMonthLastDay(1).toString());

                    }
                }

                if(!CollectionUtils.isEmpty(currentDateList)){

                    for(String date : currentDateList){
                        String cacheKey = Constants.CURRENT_USER_DASH_BOARD_CACHE_PREFIX + perAgentAccount + date;
                        if(redisUtil.hasKey(cacheKey)){
                            Object value = redisUtil.get(cacheKey);
                            if(!Objects.isNull(value)){
                                DashBoardHistoryEntity entity = Optional.ofNullable(value).map(v -> gson.fromJson(v.toString(), DashBoardHistoryEntity.class)).
                                        orElseGet(DashBoardHistoryEntity::new);

                                if(commissionType.equals(CommissionPlanTypeEnum.TURNOVER.getCode())){
                                    turnoverSum = turnoverSum.add(entity.getTurnover());
                                }else if(commissionType.equals(CommissionPlanTypeEnum.GGR.getCode())){
                                    ggrSum = ggrSum.add(entity.getGgr());
                                }
                            }
                        }
                    }

                }

                log.info("[doHandleCommission-getCurrentDateListData] Finished to getCurrentDateListData for agent:{}",perAgentAccount);

                if(!CollectionUtils.isEmpty(historyDateList)){

                    DashBoardHistoryEntity entity = dashBoardHistoryByDayMapper.queryLocalDataByPeriod(ClDashBoardCreateQueryReq.builder().agentAccount(perAgentAccount).recordDateStart(recordDateStart.toString())
                            .recordDateEnd(DateUtils.getLastNMonthLastDay(1).toString()).build());

                    if(!Objects.isNull(entity)){
                        if(commissionType.equals(CommissionPlanTypeEnum.TURNOVER.getCode())){
                            turnoverSum = turnoverSum.add(entity.getTurnover());
                        }else if(commissionType.equals(CommissionPlanTypeEnum.GGR.getCode())){
                            ggrSum = ggrSum.add(entity.getGgr());
                        }
                    }

                }

                log.info("[doHandleCommission-getTurnoverNGgr]The data for agent:{}, turnoverSum is:{}, the ggrSum is:{}",perAgentAccount,turnoverSum,ggrSum);

                if((commissionType.equals(CommissionPlanTypeEnum.GGR.getCode()) && ggrSum.compareTo(BigDecimal.ZERO) > 0) || (commissionType.equals(CommissionPlanTypeEnum.TURNOVER.getCode()) && turnoverSum.compareTo(BigDecimal.ZERO) > 0)){
                    log.info("[check ggrSum] The ggrSum is: {} for agent:{}",perAgentAccount,ggrSum);
                    DashBoardCommissionVo vo = calculateCommission(perAgentAccount,recordDateStart,recordDateEnd,commissionType,turnoverSum,ggrSum);
                    if(!Objects.isNull(vo)){
                        response.add(vo);
                    }
                }

                log.info("[doHandleCommission-handleTopAgentCommission] Finished to handle downline agent Commission:{},type:{}",perAgentAccount,type);
            }

        }
        log.info("[doHandleCommission-handleTopAgentCommission] Finished to handle top agent Commission:{},type:{},response:{}",topAgentAccount,type,gson.toJson(response));
        handledAgentDetails = null;
        return response;
    }


    private DashBoardCommissionVo calculateCommission(String agentAccount, LocalDate recordDateStart, LocalDate recordDateEnd, String commissionType,BigDecimal turnoverSum, BigDecimal ggrSum){

        //查询佣金比例
        TAgentContractBind bind = contractBindMapper.selectOne(new LambdaQueryWrapper<TAgentContractBind>().eq(TAgentContractBind::getLoginName,agentAccount));

        List<SettlementPercentageReq> settlementPercentageList = SerializationUti.deserializeFromString(bind.getPercentageDetails(), SettlementPercentageReq.class);

        //佣金比例 暂时选择第一阶段
        SettlementPercentageReq percentageReq = settlementPercentageList.get(0);

        //佣金费率 选择 allGameType
        BigDecimal commissionValue = new BigDecimal(String.valueOf(percentageReq.getAllGamesPercentage())).divide(new BigDecimal(100));

        log.info("[doHandleCommissionByLevel]The commission detail for agent:{} is: commission rate is:{},commission type is:{},ggrSum is:{}, turnoverSum is:{}",agentAccount,commissionValue,commissionType,ggrSum,turnoverSum);

        DashBoardCommissionVo vo = new DashBoardCommissionVo();
        vo.setAgentAccount(agentAccount);
        vo.setRecordDateStart(recordDateStart.toString());
        vo.setRecordDateEnd(recordDateEnd.toString());
        if(commissionType.equals(CommissionPlanTypeEnum.TURNOVER.getCode())){
            vo.setCommission(turnoverSum.multiply(commissionValue).setScale(2, RoundingMode.DOWN));
        }else if(commissionType.equals(CommissionPlanTypeEnum.GGR.getCode())){
            vo.setCommission(ggrSum.multiply(commissionValue).setScale(2, RoundingMode.DOWN));
        }else {
            vo.setCommission(BigDecimal.ZERO.setScale(2));
        }

        log.info("[doHandleCommissionByLevel]The commission is:{} for agent:{} from {} to {}",vo.getCommission(),agentAccount,recordDateStart,recordDateEnd);

        return vo;
    }

    private Long getRealUsersFromCl(ClDashBoardCreateQueryReq queryReq){
        if(Objects.isNull(queryReq) || CollectionUtils.isEmpty(queryReq.getLoginNameList())){
            return null;
        }

        log.info("Begin to query dashBoard data for agent:{}",queryReq.getAgentAccount());

        List<String> userNames = queryReq.getLoginNameList();

        if (userNames.size() <= dashBoardConfig.getBatchQuerySize()) {
            return clDashBoardV1Mapper.queryTurnoverActivePlayerCount(queryReq);
        } else {

            List<List<String>> batches = Lists.partition(userNames, dashBoardConfig.getBatchQuerySize());

            Set<ClDashBoardCreateQueryReq> batchQuerys = batches.stream().map(b -> ClDashBoardCreateQueryReq.builder()
                    .loginNameList(b).recordDateStart(queryReq.getRecordDateStart()).recordDateEnd(queryReq.getRecordDateEnd())
                    .build()).collect(Collectors.toSet());

            Long response = batchQuerys.stream().map(q -> clDashBoardV1Mapper.queryTurnoverActivePlayerCount(q))
                    .reduce((r1, r2) -> r1 + r2).orElse(0L);
            return response;
        }

    }






}
