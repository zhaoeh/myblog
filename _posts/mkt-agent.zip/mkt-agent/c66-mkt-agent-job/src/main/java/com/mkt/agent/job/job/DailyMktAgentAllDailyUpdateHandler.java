package com.mkt.agent.job.job;

import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.job.service.MktAgentAllService;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;


@Component
@Slf4j
public class DailyMktAgentAllDailyUpdateHandler extends IJobHandler {

    @Resource
    private MktAgentAllService mktAgentAllService;

    @Override
    @XxlJob(value = "DailyMktAgentAllDailyUpdateHandler")
    public void execute() throws Exception {
        String dateStr = StringUtils.isEmpty(XxlJobHelper.getJobParam()) ? DateUtils.getCurrentDate() : XxlJobHelper.getJobParam();
        mktAgentAllService.dataUpdatingByDayRange(dateStr, dateStr);
    }

}
