package com.mkt.agent.job.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.TAgentWallet;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @ClassName AgentMapper
 * @Author JOJO
 * @Date 2023/8/4 10:00
 * @Version 1.0
 **/
@Mapper
public interface EmptyWalletAgentMapper extends BaseMapper<TAgentWallet> {

    // 查询代理用户信息表存在但代理佣金钱包表不存在的 用户客户id、登录名 列表
    public List<TAgentWallet> agentList();

    // 查询用户_test表数据
    public List<TAgentWallet> agentTestList();

    // 查询用户_test表数据未同步至钱包_test表的数据条数
    public Integer agentTestCount();

    // 钱包_test表新增代理用户的钱包记录
    public int insertWalletTest(@Param(value = "list") List<TAgentWallet> list);

}
