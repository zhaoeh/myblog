package com.mkt.agent.job.job.migrateCustomerDataJob;

import com.mkt.agent.job.job.migrateCustomerDataJob.process.AgentContractProcess;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 同步用户使用，已过期不再使用
 */
@Component
@Slf4j
public class UpdateAgentCountHandler extends IJobHandler {

    @Autowired
    private AgentContractProcess agentContractProcess;


    @Override
    @XxlJob(value = "UpdateAgentCountHandler")
    public void execute() {
        log.info("UpdateAgentCountHandler starting");
        agentContractProcess.updateAgentCount();
        log.info("UpdateAgentCountHandler ending");
    }
}
