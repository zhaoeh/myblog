package com.mkt.agent.job.job.process;

import com.alibaba.fastjson.JSONObject;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.api.agentapi.responses.SettlementPercentageResp;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.common.entity.api.integration.bi.responses.CustUserSummerResponse;
import com.mkt.agent.common.entity.api.jobapi.responses.AgentDetails;
import com.mkt.agent.common.enums.CommissionRecordStatusEnum;
import com.mkt.agent.common.enums.ContractKeysEnum;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.NumberUtils;
import com.mkt.agent.common.utils.SignatureUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 * @Description 佣金计算
 * @Classname Lucian
 * @Date 2023/7/20 11:57
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class CalculateCommissionHandler {

    public List<AgentCommissionRecord> commissionCalculate(AgentDetails agent, List<CustUserSummerResponse> directPlayers,int count,String levelOneAccount) {

        if(null==directPlayers||directPlayers.size()<=0){
            log.info("end commissionCalculate cause directPlayers is null--- the agent:{}",agent);
            return null;
        }

        log.info("start to  commissionCalculate params agent:{}, directPlayers:{}",agent, Arrays.toString(directPlayers.toArray()));

        //获取佣金方案  没有佣金方案则返回
        List<SettlementPercentageResp> settlementPercentageRespList = agent.getSettlementPercentageResp();
        if(settlementPercentageRespList.size()<=0){
            return null;
        }

        BigDecimal sumTurnover = new BigDecimal(0);
        BigDecimal sumDeposit = new BigDecimal(0);
        BigDecimal sumGgr = new BigDecimal(0);
        BigDecimal sumWinOrLose = new BigDecimal(0);
        BigDecimal sumWithdraw = new BigDecimal(0);

        //计算投注额
        for(CustUserSummerResponse custUserSummerResponse : directPlayers){

            sumTurnover = sumTurnover.add(custUserSummerResponse.getTurnoverSum()!=null?custUserSummerResponse.getTurnoverSum():new BigDecimal(0));
            sumDeposit = sumDeposit.add(custUserSummerResponse.getDepositAmount()!=null?custUserSummerResponse.getDepositAmount():new BigDecimal(0));
            sumGgr = sumGgr.add(custUserSummerResponse.getGgrSum()!=null?custUserSummerResponse.getGgrSum():new BigDecimal(0));
            sumWinOrLose = sumWinOrLose.add(custUserSummerResponse.getOutcomeSum()!=null?custUserSummerResponse.getOutcomeSum():new BigDecimal(0));
            sumWithdraw = sumWithdraw.add(custUserSummerResponse.getWithdrawAmount()!=null?custUserSummerResponse.getWithdrawAmount():new BigDecimal(0));

        }

        log.info("agentName:{},计算出的总佣金：sumTurnover:{},sumDeposit:{},sumWithdraw{},sumGgr{},sumWinOrLose{}",agent.getLoginName(),sumTurnover,sumDeposit,sumWithdraw,sumGgr,sumWinOrLose);

        BigDecimal sumTurnoverScale = NumberUtils.twoScaleFormat(sumTurnover);
        BigDecimal sumDepositScale = NumberUtils.twoScaleFormat(sumDeposit);
        BigDecimal sumGgrScale = NumberUtils.twoScaleFormat(sumGgr);
        BigDecimal sumWinOrLoseScale = NumberUtils.twoScaleFormat(sumWinOrLose);
        BigDecimal sumWithdrawScale = NumberUtils.twoScaleFormat(sumWithdraw);

        log.info("agentName:{},保留两位小数的总佣金：sumTurnoverScale:{},sumDepositScale:{},sumWithdrawScale{},sumGgrScale{},sumWinOrLoseScale{}",agent.getLoginName(),sumTurnoverScale,sumDepositScale,sumWithdrawScale,sumGgrScale,sumWinOrLoseScale);

        //一期直接取第一个，后续可能会有多个，根据金额区间不同，佣金比例不同
        SettlementPercentageResp percentageResp = settlementPercentageRespList.get(0);
        //佣金费率  一期直接取AllGamesPercentage，后续可能会加根据游戏类型比例不同的需求
        BigDecimal commissionValue = new BigDecimal(String.valueOf(percentageResp.getAllGamesPercentage()));
        //实际佣金
        BigDecimal commissionAmount = sumTurnover.multiply(commissionValue);

        log.info("实际计算的佣金为：{}",commissionAmount);

        List<AgentCommissionRecord> saveRecordList = new ArrayList<>();

        //设置代理佣金记录字段
        AgentCommissionRecord saveRecord = new AgentCommissionRecord();
        saveRecord.setSettleDateStart(DateUtils.getLastMonthFirstDay());
        saveRecord.setSettleDateEnd(DateUtils.getLastMonthLastDayV1());
        saveRecord.setActualUserCount(count);

        saveRecord.setLevel1AgentAccount(levelOneAccount);

        //设置代理和佣金方案信息
        setAgentAndContractInfo(agent,saveRecord);
        //设置金额信息
        saveRecord.setCommissionValue(commissionValue);
        //佣金金额保留两位小数
        saveRecord.setCommissionAmount(NumberUtils.twoScaleFormat(commissionAmount));

        saveRecord.setTurnover(sumTurnoverScale);
        saveRecord.setGGR(sumGgrScale);
        saveRecord.setWinOrLoss(sumWinOrLoseScale);
        saveRecord.setDeposit(sumDepositScale);
        saveRecord.setWithdrawal(sumWithdrawScale);

        saveRecord.setActualCommissionAmount(new BigDecimal(BaseConstants.DEFAULT_AMOUNT));
        saveRecord.setAppendCommissionAmount(new BigDecimal(BaseConstants.DEFAULT_AMOUNT));

        // 佣金方案覆盖命中佣金方案
        saveRecord.setPercentageDetails(agent.getBindPercentageDetails());

        //其他赋值
        JSONObject percentInfo = new JSONObject();
        percentInfo.put(ContractKeysEnum.All.getDes(), saveRecord.getCommissionAmount());
        percentInfo.put(ContractKeysEnum.All.getDes(), saveRecord.getCommissionValue());
        saveRecord.setPercentInfo(percentInfo.toJSONString());

        saveRecordList.add(saveRecord);

        //设置直属玩家记录
        if (!CollectionUtils.isEmpty(directPlayers)) {
            if(agent.getAgentLevel()==1){
                List<AgentCommissionRecord> directCommissionRecords = directPlayerProcess(directPlayers,levelOneAccount);
                saveRecordList.addAll(directCommissionRecords);
            }
        }
        log.info("commissionCalculate finished :{}",Arrays.toString(saveRecordList.toArray()));
        return saveRecordList;
    }


    /**
     * description: 设置代理信息和佣金方案信息
     * @param:  [agent, saveRecord]
     * @return: void
     * @Date: 2023/7/20 15:40
     * @Version: 1.0.0
     * @Author: Lucian
     */
    private void setAgentAndContractInfo(AgentDetails agent, AgentCommissionRecord saveRecord) {

        // 代理信息
        saveRecord.setAgentAccount(agent.getLoginName());
        saveRecord.setCustomerId(agent.getCustomersId());

        saveRecord.setParentId(agent.getParentId());
        saveRecord.setAgentType(agent.getAgentType());
        saveRecord.setAgentLevel(agent.getAgentLevel());
        saveRecord.setParentAccount(agent.getParentName());

        // 佣金方案信息
        saveRecord.setSettlementPeriod(agent.getSettlementPeriod());
        saveRecord.setCommissionPlanId(agent.getId());
        saveRecord.setCommissionPlanName(agent.getCommissionPlanName());
        saveRecord.setCommissionType(agent.getCommissionPlanType());

        saveRecord.setPercentageDetails(agent.getBindPercentageDetails());
        saveRecord.setCommissionValues(agent.getCommissionValues());

        // 判断顶级代理是否计算佣金参数赋值
        saveRecord.setActiveUserHeadcount(agent.getActiveUserHeadcount());
//        saveRecord.setActiveUserTurnover(agent.getActiveUserTurnover());

        saveRecord.setSettlementConditions(agent.getSettlementConditions());

        // 其他参数赋值
//        saveRecord.setProductId(agent.getProductId());
        saveRecord.setSiteId(agent.getSiteId());
        saveRecord.setCurrency(BaseConstants.PHP);

        saveRecord.setCreateTime(DateUtils.getCurrentDateTime());
        saveRecord.setUpdateTime(DateUtils.getCurrentDateTime());

        saveRecord.setCreatedBy(BaseConstants.SYSTEM);
        saveRecord.setStatus(agent.getAgentLevel()==1?CommissionRecordStatusEnum.FIRST_PENDING.getValue():CommissionRecordStatusEnum.UNPAID.getValue());

        String hashCode = this.hashCodeGenerate(saveRecord);
        saveRecord.setHashCode(hashCode);

    }


    private List<AgentCommissionRecord> directPlayerProcess(List<CustUserSummerResponse> directPlayers,String levelOneAccount) {

        log.info("directPlayerProcess params:{}",directPlayers);
        List<AgentCommissionRecord> directPlayerSaveRecords = new ArrayList<>();
        directPlayers.forEach(custUserSummerResponse -> {

            if(custUserSummerResponse.getAgentType()==3){
                AgentCommissionRecord saveRecord = new AgentCommissionRecord();
                saveRecord.setSettleDateStart(DateUtils.getLastMonthFirstDay());
                saveRecord.setSettleDateEnd(DateUtils.getLastMonthLastDayV1());

                saveRecord.setLevel1AgentAccount(levelOneAccount);

                saveRecord.setAgentAccount(custUserSummerResponse.getName());
                saveRecord.setCustomerId(custUserSummerResponse.getCustomerId());

                saveRecord.setParentId(custUserSummerResponse.getParentId());
                saveRecord.setAgentType(custUserSummerResponse.getAgentType());
                saveRecord.setParentAccount(custUserSummerResponse.getParentAccount());

//                saveRecord.setProductId(custUserSummerResponse.getProductId());
                saveRecord.setSiteId(custUserSummerResponse.getSiteId());
                saveRecord.setCurrency(BaseConstants.PHP);

                saveRecord.setCreateTime(DateUtils.getCurrentDateTime());
                saveRecord.setUpdateTime(DateUtils.getCurrentDateTime());

                saveRecord.setCreatedBy(BaseConstants.SYSTEM);

                //设置金额信息
                saveRecord.setCommissionValue(new BigDecimal(BaseConstants.DEFAULT_AMOUNT));
                saveRecord.setCommissionAmount(new BigDecimal(BaseConstants.DEFAULT_AMOUNT));

                saveRecord.setTurnover(custUserSummerResponse.getTurnoverSum());
                saveRecord.setGGR(custUserSummerResponse.getGgrSum());
                saveRecord.setWinOrLoss(custUserSummerResponse.getOutcomeSum());
                saveRecord.setDeposit(custUserSummerResponse.getDepositAmount());
                saveRecord.setWithdrawal(custUserSummerResponse.getWithdrawAmount());

                saveRecord.setActualCommissionAmount(new BigDecimal(BaseConstants.DEFAULT_AMOUNT));
                saveRecord.setAppendCommissionAmount(new BigDecimal(BaseConstants.DEFAULT_AMOUNT));

                directPlayerSaveRecords.add(saveRecord);
            }

        });

        return directPlayerSaveRecords;
    }

    // 生成唯一标识
    private String hashCodeGenerate(AgentCommissionRecord saveRecord) {

        String settleStartDateString = DateUtils.localDateToString(saveRecord.getSettleDateStart());
        String settleEndDateString = DateUtils.localDateToString(saveRecord.getSettleDateEnd());
        String signBuilder = saveRecord.getAgentAccount() +
                saveRecord.getPercentageDetails() +
                settleStartDateString +
                settleEndDateString +
                saveRecord.getActiveUserTurnover() +
                saveRecord.getActiveUserHeadcount() +
                saveRecord.getCommissionValues();

        String hashCode = SignatureUtil.generateSignature(signBuilder, BaseConstants.ShaSignFormatX);
        return hashCode;

    }


}
