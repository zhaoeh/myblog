package com.mkt.agent.job.job.freshRedis;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mkt.agent.common.constants.AuthConstants;
import com.mkt.agent.common.constants.CacheConstants;
import com.mkt.agent.common.enums.ResultEnum;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Set;

/**
 * @Description 清除redis的key
 * @Classname FreshRedisKeyHandler
 * @Date 2024/4/2 12:23
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class FreshRedisKeyHandler extends IJobHandler {

//    @Resource
//    private RedisTemplate<String, Object> redisTemplate;

    @Resource
    private StringRedisTemplate stringRedisTemplate;

    @Override
    @XxlJob(value = "FreshRedisKeyHandler")
    public void execute() throws Exception {

        String pattern = XxlJobHelper.getJobParam();

        if(StringUtils.isBlank(pattern)){
            log.info("The param is null!");
            return;
        }

        String key = CacheConstants.FRONTEND_JWT_CACHE_KEY + pattern;

        String tokenFromCache = (String) stringRedisTemplate.opsForHash().get(key, AuthConstants.REFRESH_TOKEN);

        if(StringUtils.isNotBlank(tokenFromCache)){
            log.info("[调试]开始清除登录信息：{}",key);
            stringRedisTemplate.delete(key);
            log.info("[调试]登录信息已清除: {}", key);
        }else {
            log.info("[调试]登录信息不存在: {}", key);
        }

    }


}