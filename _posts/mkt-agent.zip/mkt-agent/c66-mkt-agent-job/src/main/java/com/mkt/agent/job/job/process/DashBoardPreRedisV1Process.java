package com.mkt.agent.job.job.process;

import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.job.util.DashBoardBetPlayersV1Util;
import com.mkt.agent.job.util.DashBoardDataByDayV1Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDate;

/**
 * @Description 初始化仪表盘缓存 每天
 * @Classname DashBoardPreRedisHandlerProcess
 * @Date 2023/12/6 13:57
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class DashBoardPreRedisV1Process {

    @Autowired
    private DashBoardDataByDayV1Util dashBoardV1Util;

    @Resource
    private DashBoardRemoveRedisV1Process removeRedisV1Process;

    @Resource
    private DashBoardBetPlayersV1Util betPlayersV1Util;

    /**
     * description: 初始化缓存
     * @param:  []
     * @return: void
     * @Date: 2023/12/6 14:07
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public void process(){

        try {

            //清除缓存
//            removeRedisV1Process.process();

            // 获取当前日期
            LocalDate currentDate = LocalDate.now();

            log.info("Begin to handle data for current day:{}",currentDate);

            LocalDate recordDateStart = DateUtils.getLastNMonthFirstDay(0);

            //把数据存入缓存
            dashBoardV1Util.handleByLevelByDay(Constants.DASH_BOARD_DATA_START_LEVEL, recordDateStart,currentDate,Constants.CURRENT_DATA);

            //把投注数据存入缓存
            betPlayersV1Util.handleBetPlayers(Constants.DASH_BOARD_DATA_START_LEVEL);

            log.info("Finished to handle today's data!");


        }catch (Exception e){
            log.info("Failed to cache today's data!",e);
        }


    }






}
