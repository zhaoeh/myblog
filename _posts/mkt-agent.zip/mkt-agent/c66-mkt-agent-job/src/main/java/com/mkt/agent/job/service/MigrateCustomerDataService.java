package com.mkt.agent.job.service;

import com.cn.schema.customers.QueryCustomersRequest;
import com.cn.schema.customers.WSCustomers;
import com.mkt.agent.integration.template.WsTemplate;

import java.util.List;

/**
 * @Description TODO
 * @Classname MigrateCustomerDataService
 * @Date 2023/8/28 15:07
 * @Created by TJSLucian
 */
public interface MigrateCustomerDataService {

    List<WSCustomers> callWsForData(WsTemplate wsTemplate, QueryCustomersRequest req);
}
