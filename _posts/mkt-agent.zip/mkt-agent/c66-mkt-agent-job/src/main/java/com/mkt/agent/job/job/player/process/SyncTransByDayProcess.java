package com.mkt.agent.job.job.player.process;

import com.google.gson.Gson;
import com.mkt.agent.common.config.PlayerReportConfig;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.core.TiConsumer;
import com.mkt.agent.common.entity.TAgentRefreshLog;
import com.mkt.agent.common.player.core.LogHolder;
import com.mkt.agent.common.player.model.PlayerMapperHolder;
import com.mkt.agent.common.player.model.SyncTransByDayParams;
import com.mkt.agent.common.player.model.TAgentCountGroup;
import com.mkt.agent.common.player.processor.AgentTransProcessor;
import com.mkt.agent.common.task.AsyncTasks;
import com.mkt.agent.job.clickhouse.mapper.ClDashBoardV1Mapper;
import com.mkt.agent.job.mapper.UsersRefreshMapper;
import com.mkt.agent.job.mapper.UsersGroupMapper;
import com.mkt.agent.job.service.api.AgentService;
import com.mkt.agent.job.service.api.UserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @description: sync player process
 * @author: ErHu.Zhao
 * @create: 2024-01-30
 **/
@Component
@Slf4j
@EnableScheduling
public class SyncTransByDayProcess {

    @Autowired
    private AgentService agentService;

    @Autowired
    private UserService userService;

    @Resource
    private ClDashBoardV1Mapper clDashBoardV1Mapper;

    @Resource
    private UsersGroupMapper usersGroupMapper;

    @Resource
    private UsersRefreshMapper usersRefreshMapper;

    @Resource
    private AgentTransProcessor agentTransProcessor;

    @Resource
    private AsyncTasks asyncTasks;

    @Resource
    private PlayerReportConfig playerReportConfig;

    private Gson gson = new Gson();

    /**
     * 每天凌晨4点半定时执行
     */
//    @Scheduled(cron = "0 30 5 * * ?")
//    public void taskAtNight() {
//        log.info("job应用级定时任务异步执行[兜底策略]");
//        LogHolder.addLogContainer(LogHolder.LogContainer.builder().logStatement("job应用级定时任务异步执行[兜底策略]").build());
//        // 兜底scheduled不会暴力清除表，只会根据配置清除指定天数前的数据
//        Integer clearDays = playerReportConfig.getClearDays() > playerReportConfig.getSyncDays() ? -1 : playerReportConfig.getClearDays();
//        TiConsumer<String, Integer, SyncTransByDayParams> consumer = this::handleUsersGroupByDay;
//        asyncTasks.asyncTask(consumer, Constants.FROM_SCHEDULED, Constants.DASH_BOARD_DATA_START_LEVEL,
//                SyncTransByDayParams.builder().clearDays(clearDays).clearCache(Boolean.FALSE).build());
//    }

    public void handleUsersGroupByDay(String dataSourceType, int level, SyncTransByDayParams syncTransByDayParams) {
//        PlayerMapperHolder mapperHolder = buildMapper();
//        if (onlyWatchNico(mapperHolder, syncTransByDayParams)) {
//            return;
//        }
//        agentTransProcessor.handleUsersGroupByDay(mapperHolder, dataSourceType, level, syncTransByDayParams);
    }

    /**
     * 构建mapper
     *
     * @return
     */
    private PlayerMapperHolder buildMapper() {
        return PlayerMapperHolder.builder().
                agentsMapper(agentService::queryAgentsByTimeNLevelIgnoreStatus).
                agentsByLevelMapper(agentTransProcessor::obtainAgentsByLevel).
                lowerDirectsMapper(this::selectLowerDirects).
//                targetAgentsTransCountMapper(clDashBoardV1Mapper::getTransCountByAgents).
                targetAgentsTransCountMapper(clDashBoardV1Mapper::getTransCountByAgentsNew).
                lowerAgentsMapper(this::selectLowerAgents).
                transCountsMapper(usersGroupMapper::queryDownLineCount).
                groupInsertMapper(usersGroupMapper::insertUsersGroup).
                agentTotalCountMapper(usersGroupMapper::queryCountUsersGroup).
                groupDeleteMapper(usersGroupMapper::deleteUsersGroup).
                biDateRangeMapper(clDashBoardV1Mapper::queryAgentDateRange).
                countDateRangeMapper(usersGroupMapper::queryDashDateRange).
                countLogRangeMapper(usersRefreshMapper::queryDateRangeList).
                countLogFailedRecordsMapper(usersRefreshMapper::queryLastTimeFailedRecords).
                countLogInsertMapper(usersRefreshMapper::insertUsersGroupLog).
                countLogDeleteMapper(usersRefreshMapper::deleteUsersGroupLog).
                countLogForceDeleteMapper(usersRefreshMapper::deleteUsersGroupLogWithForce).
                countLogDetailsMapper(usersRefreshMapper::queryList).build();
    }

    /**
     * 查询目标代理用户集的下级直属用户
     *
     * @param request
     * @return
     */
    List<String> selectLowerDirects(TAgentCountGroup request) {
        Assert.notNull(request, "request cannot be null");
        List<String> targetAgents = request.getTargetAgents();
        Assert.notEmpty(targetAgents, "targetAgents cannot be empty");
        return userService.selectDirectUsersAgentsNameForPlayer(targetAgents);
    }

    /**
     * 查询目标代理用户集的下级代理用户
     *
     * @param request
     * @return
     */
    List<String> selectLowerAgents(TAgentCountGroup request) {
        Assert.notNull(request, "request cannot be null");
        List<String> targetAgents = request.getTargetAgents();
        Assert.notEmpty(targetAgents, "targetAgents cannot be empty");
        return agentService.selectDirectAgentNames(targetAgents.get(0));
    }

    /**
     * 处理only watch
     *
     * @param holder
     * @param syncTransByDayParam
     * @return
     */
    private boolean onlyWatchNico(PlayerMapperHolder holder, SyncTransByDayParams syncTransByDayParam) {
        if (BooleanUtils.isTrue(BooleanUtils.isTrue(syncTransByDayParam.getOnlyWatchNico()))) {
            Map<String, Object> params = syncTransByDayParam.getParams();
            Integer isDeleted = null;
            Integer limit = 100;
            if (MapUtils.isNotEmpty(params)) {
                isDeleted = Integer.valueOf(Objects.toString(params.getOrDefault("isDeleted", 0)));
                limit = Integer.valueOf(Objects.toString(params.getOrDefault("limit", 100)));
            }
            List<TAgentRefreshLog> details = holder.getCountLogDetailsMapper().apply(TAgentRefreshLog.builder().handlerName(Constants.SYNC_TRANS_BY_DAY_HANDLER).isDeleted(isDeleted).limit(limit).build());
            LogHolder.addLogContainer(LogHolder.LogContainer.builder().logStatement("log details is {}").log(List.of(gson.toJson(details))).build());
            Integer totalCount = holder.getAgentTotalCountMapper().get();
            LogHolder.addLogContainer(LogHolder.LogContainer.builder().logStatement("t_agent_count_group_day total count is {}").log(List.of(totalCount)).build());
            LogHolder.printLog();
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }
}
