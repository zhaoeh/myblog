package com.mkt.agent.job.service;

public interface MktAgentAllService {

    void allDataMigration();

    void dataUpdatingByDayRange(String startDate, String endDate);

    long count();
}
