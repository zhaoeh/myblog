package com.mkt.agent.job.mapper.test;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentQueryByPageRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.OrgCodeUpdateRequest;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerQueryResponse;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentQueryByPageResponse;
import com.mkt.agent.common.entity.api.jobapi.requests.AgentCustomersTestRequest;
import com.mkt.agent.common.entity.api.jobapi.responses.AgentDetails;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface TestMysqlMapper extends BaseMapper<TAgentCustomers> {

    List<TAgentCustomers> queryAgentsTest(@Param("agentAccount")String agentAccount, @Param("level")int level);

}
