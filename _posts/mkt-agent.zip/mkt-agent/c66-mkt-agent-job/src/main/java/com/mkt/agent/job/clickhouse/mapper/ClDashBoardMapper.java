package com.mkt.agent.job.clickhouse.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.ClDashBoardDataRes;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverDistriResp;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverTopResp;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.List;
import java.util.Map;

/**
 * @Description TODO
 * @Classname DashBoardMapper
 * @Date 2023/11/22 14:42
 * @Created by TJSLucian
 */
@Mapper
public interface ClDashBoardMapper extends BaseMapper<ClDashBoardDataRes> {

    /*List<ClDashBoardDataRes> queryDashBoardData(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    CommissionRecordDashBoardResponse queryFirstPlayerAndAmountData(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    *//**
     * 排名前十的玩家账号柱状图
     * @return
     *  login_name      玩家名
     *  turnoverSum     投注额总计
     *//*
    List<ClTurnoverTopResp> topList(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    Long queryTurnoverActivePlayerCount(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    Long queryGgrActivePlayerCount(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    CommissionRecordDashBoardResponse querySumAgentGgrTData(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);*/



    List<ClDashBoardDataRes> queryDashBoardData(String whereStr);

    CommissionRecordDashBoardResponse queryFirstPlayerAndAmountData(String whereStr);

    /**
     * 排名前十的玩家账号柱状图
     *
     * @return login_name      玩家名
     * turnoverSum     投注额总计
     */
    List<ClTurnoverTopResp> topListOld(String whereStr);

    Long queryTurnoverActivePlayerCount(String whereStr);

    Long queryGgrActivePlayerCount(String whereStr);

    CommissionRecordDashBoardResponse querySumAgentGgrTData(String whereStr);

 //===================================查询原表===========================================

    //表2
    DashBoardHistoryEntity querySumAgentGgrTDataByDayNew(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    DashBoardHistoryEntity querySumAgentDepositDataByDayNew(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    DashBoardHistoryEntity querySumAgentWithdrawDataByDayNew(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    DashBoardHistoryEntity queryFirstPlayerAndAmountDataByDayNew(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    DashBoardHistoryEntity querybetPlayersCountByDayNew(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);



    /**
     * 投注额占比饼状图
     * @return
     *  game_type       游戏类型
     *  turnoverSum     该类型游戏的投注额总计
     *  turnoverDistribution    该类型游戏的投注额占比(该类型游戏的投注额总计/全部投注额总计)
     */
    List<ClTurnoverDistriResp> distributionList(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    /**
     * 排名前十的玩家账号柱状图
     * @return
     *  login_name      玩家名
     *  turnoverSum     投注额总计
     */
    List<ClTurnoverTopResp> topList(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    //表1
    CommissionRecordDashBoardResponse querySumAgentGgrTDataNew(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    CommissionRecordDashBoardResponse querySumAgentDepositDataNew(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    CommissionRecordDashBoardResponse querySumAgentWithdrawDataNew(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    CommissionRecordDashBoardResponse queryFirstPlayerAndAmountDataNew(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    CommissionRecordDashBoardResponse querybetPlayersCountNew(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);


    Long queryTurnoverActivePlayerCountNew(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    Long queryGgrActivePlayerCountNew(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);


}
