package com.mkt.agent.job.util;

import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.mkt.agent.common.config.DashBoardConfig;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.utils.*;
import com.mkt.agent.job.clickhouse.mapper.ClDashBoardV1Mapper;
import com.mkt.agent.job.mapper.DashBoardHistoryByPluralMapper;
import com.mkt.agent.job.service.api.AgentService;
import com.mkt.agent.job.service.api.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Description TODO
 * @Classname DashBoardUtil
 * @Date 2023/12/6 16:06
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class DashBoardDataByPluralV1Util {

    @Autowired
    private DashBoardConfig dashBoardConfig;

    @Resource
    private ClDashBoardV1Mapper clDashBoardV1Mapper;

    @Autowired
    private UserService userService;

    @Autowired
    private DashBoardCommonUtil dashBoardCommonUtil;

    @Autowired
    private AgentService agentService;

    @Autowired
    private DashBoardHistoryByPluralMapper dashBoardHistoryByPluralMapper;


    @Resource
    private Gson gson;



    public void handleByLevelByPlural(int level,String recordDateStart,String recordDateEnd){

        log.info("[handleByLevelByPlural]Begin to handle Last2Month level:{}",level);

        //获取上上个月未同步的代理
        List<TAgentCustomers> agentList = agentService.queryUncheckedAgentsForLast2Month(recordDateStart,recordDateEnd,level);

        //获取每个代理某段时间内直属用户产生的数据
        List<CommissionRecordDashBoardResponse> dashBoardResponsesList = this.getResFromClByPlural(agentList,recordDateStart,recordDateEnd);

        log.info("[handleByLevelByPlural]finished to handle Last2Month level:{}, begin to save data",level);

        try {

            if(!CollectionUtils.isEmpty(dashBoardResponsesList)){
                log.info("[handleByLevelByPlural]The Last2Month data needed to save is :{}",Arrays.toString(dashBoardResponsesList.toArray()));

                //入历史表1
                dashBoardHistoryByPluralMapper.insertBatchSomeColumn(dashBoardResponsesList);
            }

        }catch (Exception e){
            log.error("[handleByLevelByPlural]Failed to save Last2Month data for level:{}",level);
            e.printStackTrace();
        }

        log.info("[handleByLevelByPlural]finished to save Last2Month data for level:{}",level);
        level--;

        if(level>0){
            handleByLevelByPlural(level,recordDateStart,recordDateEnd);
        }

    }



    private List<CommissionRecordDashBoardResponse> getResFromClByPlural(List<TAgentCustomers> agentList, String recordDateStart, String recordDateEnd){

        if(CollectionUtils.isEmpty(agentList)){
            log.info("The agentList is null!");
            return null;
        }

        List<CommissionRecordDashBoardResponse> responseList = new ArrayList<>();

        agentList.forEach(agent -> {

            String agentAccount = agent.getLoginName();
            String parentAgentAccount = agent.getParentName();
            log.info("[handleByLevelByPlural]Begin to handle agent last2month data for:{}. The date is:{},{}",agentAccount,recordDateStart,recordDateEnd);

            try {

                CommissionRecordDashBoardResponse response = new CommissionRecordDashBoardResponse();
                response.setLoginName(agentAccount);
                response.setParentLoginName(parentAgentAccount);
                response.setRecordDateStart(recordDateStart);
                response.setRecordDateEnd(recordDateEnd);

                //存储直属用户数据
                CommissionRecordDashBoardResponse userDataRes = null;

                //查询直属用户
                List<String> usersNameList = userService.selectDirectUsersAgentsName(agentAccount);

                //查询直属用户的数据
                if(!CollectionUtils.isEmpty(usersNameList)){
                    userDataRes = this.queryDashBoardDataFromCl(ClDashBoardCreateQueryReq.builder()
                            .loginNameList(usersNameList).recordDateStart(recordDateStart).recordDateEnd(recordDateEnd).agentAccount(agentAccount).build());
                }else {
                    log.info("[handleByLevelByPlural]Last2Month userList is null for agent:{}",agentAccount);
                }

                //把用户和代理的数据累加
                if(!Objects.isNull(userDataRes)){
                    log.info("[handleByLevelByPlural]The userData for agent:{} is:{} from {} to {}",agentAccount,gson.toJson(userDataRes),recordDateStart,recordDateEnd);
                    dashBoardCommonUtil.sumDataResultV1(response,userDataRes);
                }

                //存储下级代理的数据
                CommissionRecordDashBoardResponse downlineAgentsData = null;
                //直属用户的数据 + 下级代理的数据
                if(agent.getAgentLevel()!=5){
                    downlineAgentsData = dashBoardHistoryByPluralMapper.querySumDownlineData(ClDashBoardCreateQueryReq.builder()
                            .parentAgentAccount(agentAccount).recordDateStart(recordDateStart).recordDateEnd(recordDateEnd).build());
                }

                if(!Objects.isNull(downlineAgentsData)){
                    dashBoardCommonUtil.sumDataResultV1(response,downlineAgentsData);
                }

                //注册人数
                response.setRegistrationNumber(userService.selectRegisterUserCount(agentAccount,recordDateStart+Constants.START_TIME,recordDateEnd+Constants.END_TIME));

                log.info("[handleByLevelByPlural]The response for agent:{} is:{}",agentAccount,gson.toJson(response));

                if(dashBoardCommonUtil.isNeededSave(response)){
                    responseList.add(response);
                }

            }catch (Exception e){
                log.error("[handleByLevelByPlural]Error happened while handling data for agent:{} from {} to {}",agentAccount,recordDateStart,recordDateEnd);
            }

        });

        return responseList;

    }

    private CommissionRecordDashBoardResponse queryDashBoardDataFromCl(ClDashBoardCreateQueryReq queryReq){

        if (queryReq.getLoginNameList().size() <= dashBoardConfig.getBatchQuerySize()) {
            return clDashBoardV1Mapper.queryDashBoardDataByPlural(queryReq);
        } else {

            List<List<String>> batches = Lists.partition(queryReq.getLoginNameList(), dashBoardConfig.getBatchQuerySize());

            Set<ClDashBoardCreateQueryReq> batchQuerys = batches.stream().map(b -> ClDashBoardCreateQueryReq.builder()
                    .loginNameList(b).recordDateStart(queryReq.getRecordDateStart()).recordDateEnd(queryReq.getRecordDateEnd())
                    .build()).collect(Collectors.toSet());

            CommissionRecordDashBoardResponse response = batchQuerys.stream().map(q -> clDashBoardV1Mapper.queryDashBoardDataByPlural(q))
                    .reduce((source,increment) -> dashBoardCommonUtil.sumDataResultV1(source,increment)).orElseGet(CommissionRecordDashBoardResponse::new);
            return response;
        }

    }


}
