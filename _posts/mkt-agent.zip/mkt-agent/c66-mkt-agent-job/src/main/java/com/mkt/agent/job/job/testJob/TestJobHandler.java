package com.mkt.agent.job.job.testJob;


import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Component;


//todo --
@Component
@Slf4j
public class TestJobHandler extends IJobHandler {

    @Override
    @XxlJob(value = "testJobHandler")
    public void execute() throws Exception {
        log.info("testJobHandler starting ...");


        log.info("testJobHandler end ...");
    }


}
