package com.mkt.agent.job.job.testJob;

import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.mkt.agent.common.config.DashBoardConfig;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.utils.DashBoardCommonUtil;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.RedisUtil;
import com.mkt.agent.job.clickhouse.mapper.ClDashBoardMapper;
import com.mkt.agent.job.clickhouse.mapper.ClDashBoardV1Mapper;
import com.mkt.agent.job.job.process.DashBoardHistoryV1Process;
import com.mkt.agent.job.mapper.CommissionRecordMapper;
import com.mkt.agent.job.mapper.DashBoardHistoryByDayMapper;
import com.mkt.agent.job.mapper.api.AgentContractMapper;
import com.mkt.agent.job.mapper.api.AgentMapper;
import com.mkt.agent.job.mapper.api.ContractBindMapper;
import com.mkt.agent.job.service.api.AgentService;
import com.mkt.agent.job.service.api.UserService;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@Component
@Slf4j
public class TestJobHandler extends IJobHandler {

    @Override
    @XxlJob(value = "testJobHandler")
    public void execute() throws Exception {
        log.info("testJobHandler starting ...");


        log.info("testJobHandler end ...");
    }


}
