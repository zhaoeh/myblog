package com.mkt.agent.job.clickhouse.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.jobapi.table.DailyGameTypeMktAgentAll;
import com.mkt.agent.common.entity.api.jobapi.table.DailyMktAgentAll;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ByteHouseDailyGameTypeMktAgentAllMapper extends BaseMapper<DailyGameTypeMktAgentAll> {

    List<DailyGameTypeMktAgentAll> selectDailyGameTypeMktAgentAllList(@Param("agentDateStart")String agentDateStart, @Param("agentDateEnd")String agentDateEnd);

    int selectTotalPageByPageSize(@Param("pageSize") Integer pageSize);

    List<DailyGameTypeMktAgentAll> selectPageRecordByPage(@Param("pageNum") Integer pageNum, @Param("pageSize") Integer pageSize);

}
