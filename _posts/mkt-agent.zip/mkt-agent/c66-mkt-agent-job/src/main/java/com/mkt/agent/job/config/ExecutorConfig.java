package com.mkt.agent.job.config;


import com.alibaba.nacos.api.config.annotation.NacosConfigurationProperties;
import com.mkt.agent.common.constants.BaseConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

@Configuration
@NacosConfigurationProperties(dataId = "mkt-share-config.yml", prefix = "executor", autoRefreshed = true)
@EnableAsync
@Slf4j
@RefreshScope
public class ExecutorConfig {


    @Value("${executor.corePoolSize:6}")
    private int corePoolSize;

    @Value("${executor.maxPoolSize:12}")
    private int maxPoolSize;

    @Value("${executor.queueCapacity:50}")
    private int queueCapacity;

    @Value("${executor.threadPrefix:mkt-executor-}")
    private String threadPrefix;


    @Bean(name = "jobExecutor")
    public Executor jobExecutor() {
        threadPrefix = threadPrefix + BaseConstants.ExecutorJob;
        log.info(BaseConstants.ExecutorJob + "线程池初始化参数为：{},{},{},{}", corePoolSize, maxPoolSize, queueCapacity, threadPrefix);
        ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
        taskExecutor.setCorePoolSize(corePoolSize);
        taskExecutor.setMaxPoolSize(maxPoolSize);
        taskExecutor.setQueueCapacity(queueCapacity);
        taskExecutor.setThreadNamePrefix(threadPrefix);

        taskExecutor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        taskExecutor.initialize();
        log.info(BaseConstants.ExecutorJob + "线程池初始化结束");
        return taskExecutor;

    }


}
