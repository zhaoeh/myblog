package com.mkt.agent.job.job.process;

import com.mkt.agent.common.entity.api.jobapi.responses.AgentDetails;
import com.mkt.agent.common.enums.GameTypeEnum;
import com.mkt.agent.common.enums.SettlementPeriodEnum;
import com.mkt.agent.job.job.task.CommissionMonthByAllTask;
import com.mkt.agent.job.service.api.AgentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * @Description: 佣金处理
 * @Author: PTMinnisLi
 * @Date: 2023/7/20
 */
@Component
public class CommissionProcess {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private AgentService agentService;

    @Autowired
    private CommissionMonthByAllTask task;

    public void execute(SettlementPeriodEnum period, GameTypeEnum gameType) {
        // 获取job处理对象:所有1级代理
        List<AgentDetails> agents = agentService.selectTopAgents();
        logger.info("level one agents:{}", Arrays.toString(agents.toArray()));

        // 开启线程
//        List<Future<Boolean>> futureList = new ArrayList<>();
//        ExecutorService executor = Executors.newFixedThreadPool(20);
        for (AgentDetails agent : agents) {
            try {
                task.call(agent, period, gameType);
            }catch (Exception e){
                e.printStackTrace();
            }

//            Future<Boolean> future = executor.submit(task);
//            futureList.add(future);
        }

//        executor.shutdown();

        // 处理各线程分页查询结果
        /*for (Future<Boolean> future : futureList) {
            try {
                future.get();
                // 处理每一页的查询结果
            } catch (Exception e) {
                throw new MKTJobException("佣金计算子任务异常结束，具体错误信息为:" + e.getMessage());
            }
        }*/
    }
}
