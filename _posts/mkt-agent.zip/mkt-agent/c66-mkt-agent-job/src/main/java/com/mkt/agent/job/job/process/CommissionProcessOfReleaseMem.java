package com.mkt.agent.job.job.process;

import com.mkt.agent.common.entity.api.jobapi.responses.AgentDetails;
import com.mkt.agent.common.enums.GameTypeEnum;
import com.mkt.agent.common.enums.SettlementPeriodEnum;
import com.mkt.agent.job.job.task.CommissionMonthByAllTaskOfReleaseMem;
import com.mkt.agent.job.service.api.AgentService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * @Description: 佣金处理
 * @Author: PTMinnisLi
 * @Date: 2023/7/20
 */
@Component
@Slf4j
public class CommissionProcessOfReleaseMem {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private AgentService agentService;

    @Autowired
    private CommissionMonthByAllTaskOfReleaseMem task;

    public void execute(SettlementPeriodEnum period, GameTypeEnum gameType) {
        // 获取job处理对象:所有1级代理
        List<AgentDetails> agents = agentService.selectTopAgents();
        logger.info("level one agents:{}", Arrays.toString(agents.toArray()));

        Iterator<AgentDetails> iterator = agents.iterator();
        while (iterator.hasNext()) {
            AgentDetails agent = iterator.next();
            try {
                task.call(agent, period, gameType);
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                iterator.remove();
                agent = null;
                period = null;
                gameType = null;
                System.gc();
            }
        }

        agents = null;
        iterator = null;
        System.gc();
    }
}
