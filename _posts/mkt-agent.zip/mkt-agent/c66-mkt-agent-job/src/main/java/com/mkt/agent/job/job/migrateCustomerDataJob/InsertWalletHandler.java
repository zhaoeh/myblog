package com.mkt.agent.job.job.migrateCustomerDataJob;


import com.alibaba.fastjson.JSONObject;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.TAgentWallet;
import com.mkt.agent.common.enums.GameTypeEnum;
import com.mkt.agent.common.enums.SettlementPeriodEnum;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.UserContext;
import com.mkt.agent.job.mapper.EmptyWalletAgentMapper;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Description: 增补钱包---已过期，不再使用
 * @Author: Jojo
 * @Date: 2023/8/3
 */
@Component
@Slf4j
public class InsertWalletHandler extends IJobHandler {
    @Resource
    private EmptyWalletAgentMapper emptyWalletAgentMapper;

    public void emptyWalletAgent() {
        // 查询用户_test表数据
        List<TAgentWallet> tAgentCustomerList = emptyWalletAgentMapper.agentTestList();
        if (null != tAgentCustomerList && !tAgentCustomerList.isEmpty()) {
            insert(tAgentCustomerList);
        } else {
            log.info("tAgentCustomerList为空!");
            return;
        }
        int total = emptyWalletAgentMapper.agentTestCount();
        log.info("未同步至钱包_test表的数据条数为" + total + "条");
    }

    public void insert(List<TAgentWallet> tAgentCustomerList) {
        // 钱包_test表新增代理用户的钱包记录
        emptyWalletAgentMapper.insertWalletTest(tAgentCustomerList);
        log.info("time :{}", DateUtils.getCurrentDateTime());
    }

    @Override
    @XxlJob(value = "insertWalletHandler")
    public void execute() throws Exception {
        log.info("InsertWalletHandler starting ...");
        // 执行增补钱包定时任务
        emptyWalletAgent();
        log.info("InsertWalletHandler end ...");
    }
}
