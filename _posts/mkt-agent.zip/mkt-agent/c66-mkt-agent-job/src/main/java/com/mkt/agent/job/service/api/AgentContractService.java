package com.mkt.agent.job.service.api;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerContractQueryByPageRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerContractQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerContractQueryResponse;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentQueryByPageResponse;
import com.mkt.agent.common.entity.api.jobapi.requests.AgentContractBindUpdateRequest;

import java.util.List;

/**
 * @ClassName AgentCustomerContractService
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
public interface AgentContractService {

    AgentCustomerContractQueryResponse getOne(AgentCustomerContractQueryRequest req);

    Page<AgentQueryByPageResponse> queryByPageAndCondition(AgentCustomerContractQueryByPageRequest rq);

    Long countQueryByPageAndCondition(AgentCustomerContractQueryByPageRequest rq);

    List<TAgentContract> listContractByCommissionPlanNames(List<String> contractPlanNames);

    void updateAgentCount(List<AgentContractBindUpdateRequest> req);
}
