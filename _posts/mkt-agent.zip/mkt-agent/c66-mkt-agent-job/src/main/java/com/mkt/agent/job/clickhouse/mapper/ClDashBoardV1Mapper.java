package com.mkt.agent.job.clickhouse.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonth;
import com.mkt.agent.common.player.model.TAgentCountGroup;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverDistriResp;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverTopResp;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @Description TODO
 * @Classname DashBoardMapper
 * @Date 2023/11/22 14:42
 * @Created by TJSLucian
 */
@Mapper
public interface ClDashBoardV1Mapper extends BaseMapper<DashBoardHistoryEntity> {

    List<DashBoardHistoryEntity> queryDashBoardTDataByDay(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    Long queryTurnoverActivePlayerCount(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    Long getBetPlayersFromCl(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    CommissionRecordDashBoardResponse queryDashBoardDataByPlural(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    List<ClTurnoverTopResp> topList(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    List<ClTurnoverDistriResp> distriList(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    List<TAgentCountGroup> getTransCountByAgents(@Param("queryReq") TAgentCountGroup queryReq);

    List<TAgentCountGroup> getTransCountByAgentsNew(@Param("queryReq") TAgentCountGroup queryReq);

    List<TAgentCountGroupMonth> queryDirectCountByMonth(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    List<TAgentCountGroupMonth> querySelfCountByMonth(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    /**
     * 查询t_daily_mkt_agent_all表最大最小日期
     *
     * @return
     */
    Map<String, Object> queryAgentDateRange();

}
