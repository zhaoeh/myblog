package com.mkt.agent.job.controller;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.job.service.MktAgentAllService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@Slf4j
public class TDailyMktAgentAllUpdateController {

    @Resource
    private MktAgentAllService mktAgentAllService;

    @ApiOperation(value = "检查服务是否健康运行", notes = "检查服务是否健康运行")
    @GetMapping(value = "/updateTDailyMktAgentAll")
    public Result<String> updateTDailyMktAgentAll(String startDate, String endDate) {
        log.info("update t_daily_mkt_agent_all from ByteHouse to Mysql: {} - {}", startDate, endDate);
        new Thread(() -> {
            mktAgentAllService.dataUpdatingByDayRange(startDate, endDate);

        });
        return Result.success();
    }

}
