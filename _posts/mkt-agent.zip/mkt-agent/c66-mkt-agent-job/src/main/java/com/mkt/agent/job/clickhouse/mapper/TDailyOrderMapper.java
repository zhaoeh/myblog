package com.mkt.agent.job.clickhouse.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.TByteHouseData;
import com.mkt.agent.common.entity.clickhouse.DailyOrderAll;
import com.mkt.agent.common.entity.clickhouse.resp.ClDashBoardDataRes;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface TDailyOrderMapper extends BaseMapper<DailyOrderAll> {
    List<ClDashBoardDataRes> getNewAllDataNew(Map<String, Object> p);

    int getActiveUserTurnoverCount(Map<String, Object> p);

    List<ClDashBoardDataRes> getNewAllDataNew2(Map<String, Object> map);

    List<ClDashBoardDataRes> getNewAllDataNew33(Map<String, Object> p);

    List<TByteHouseData> findListAllByDayOrHour(Map<String, Object> parame);

    List<TByteHouseData> findListAllByDayOrHourNew(Map<String, Object> parame);
}
