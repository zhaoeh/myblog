package com.mkt.agent.job.clickhouse.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.jobapi.table.DailyMktAgentAll;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ByteHouseDailyMktAgentAllMapper extends BaseMapper<DailyMktAgentAll> {

    int selectTotalPageByPageSize(@Param("pageSize") Integer pageSize);

    List<DailyMktAgentAll> selectPageRecordByPage(@Param("pageNum") Integer pageNum, @Param("pageSize") Integer pageSize);

    List<DailyMktAgentAll> selectByDay(@Param("dayStr") String dayStr);
}
