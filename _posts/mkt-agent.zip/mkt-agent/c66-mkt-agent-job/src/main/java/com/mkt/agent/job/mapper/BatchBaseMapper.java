package com.mkt.agent.job.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description mybatis plus -批量插入 继承该mapper即可使用
 * @Classname BatchBaseMapper
 * @Date 2023/12/6 20:18
 * @Created by TJSLucian
 */
public interface BatchBaseMapper<T> extends BaseMapper<T> {

    // 批量插入
    int insertBatchSomeColumn(@Param("list") List<T> batchList);


}
