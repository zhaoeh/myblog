package com.mkt.agent.job.feign;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.commissionapi.requests.*;
import com.mkt.agent.common.entity.api.commissionapi.responses.*;
import com.mkt.agent.common.entity.api.commissionapi.responses.base.CommissionRecordPageResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.dashboard.DashboardTopNDistriVo;
import io.swagger.annotations.ApiOperation;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

/**
 * @interfaceName: 佣金模块api
 * @Description:
 * @Author: Amida
 * @Date: 2023/5/30
 */
//@FeignClient(name = "${feign.mkt-agent-commission}", url = "127.0.0.1:18081")
@FeignClient(name = "${feign.mkt-agent-commission}")
public interface CommissionApiGateClient {
    @PostMapping("/commissionRecord-pay/queryByPageAndCondition")
    @ApiOperation("query commission records detail by page and conditions")
    Result<CommissionRecordPageResponse<CommissionRecordPayResponse>> queryByPageAndCondition(@RequestBody CommissionRecordPayRequest req);

    @PostMapping("/commissionRecord-pay/exportCommissionRecord")
    @ApiOperation("export Commission Record")
    Result<List<CommissionRecordPayResponse>> exportCommissionRecord(@RequestBody CommissionRecordPayRequest req);

    @PostMapping("/commissionRecord/commissionRecordSecondPayById")
    Result<Boolean> commissionRecordSecondPayById(@RequestBody @Valid CommissionRecordUpdateRequest req);

    @PostMapping("/commissionRecord-list/queryByPageAndCondition")
    Result<CommissionRecordPageResponse<CommissionRecordListResponse>> queryListByPageAndCondition(@RequestBody CommissionRecordListRequest req);

    @PostMapping("/commissionRecord-list/exportCommissionRecord")
    Result<List<CommissionRecordListResponse>> exportListCommissionRecord(@RequestBody CommissionRecordListRequest req);

    @PostMapping("/commissionRecord-detail/queryByPageAndCondition")
    Result<CommissionRecordPageResponse<CommissionRecordDetailResponse>> queryDetailByPageAndCondition(@RequestBody CommissionRecordDetailRequest req);

    @PostMapping("/commissionRecord-detail/exportCommissionRecord")
    Result<List<CommissionRecordDetailResponse>> exportCommissionRecord(@RequestBody CommissionRecordDetailRequest req);


    @PostMapping("/commissionRecord/queryByCommissionRecordId")
    Result<CommissionRecordSingleResponse> queryByCommissionRecordId(@RequestParam("id") Long id);

    @PostMapping("/commissionRecord/queryCommissionPlanByCommissionRecordId")
    Result<CommissionRecordPlanResponse> queryCommissionPlanByCommissionRecordId(@RequestParam("id") Long id);

    @PostMapping(value = "/dashBoard/teamSummaryQuery")
    Result<CommissionRecordDashBoardResponse> dashBoardQuery(@RequestBody CommissionRecordDashBoardRequest req);

    @PostMapping("/dashBoard/getTurnoverTopNDistriData")
    Result<DashboardTopNDistriVo> getTurnoverTopNDistriData(@RequestParam("loginName") String loginName);

    ///

    @PostMapping("/commissionRecord/commissionGen")
    Result<Map<String, Object>> commissionGen(@RequestBody Map<String, String> req);

}
