package com.mkt.agent.job.job;

import com.mkt.agent.job.job.process.DashBoardPreCommissionV1Process;
import com.mkt.agent.job.job.process.DashBoardPreRedisV1Process;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @Description 初始化佣金
 * @Classname DashBoardPreRedisHandler
 * @Date 2023/12/6 13:46
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class DashBoardPreCommissionV1Handler extends IJobHandler {

    @Autowired
    private DashBoardPreCommissionV1Process preCommissionV1Process;

    @Override
    @XxlJob(value = "DashBoardPreCommissionV1Handler")
    public void execute() {

        log.info("DashBoardPreCommissionV1Handler starting");

        preCommissionV1Process.process();

        log.info("DashBoardPreCommissionV1Handler end");
    }

}
