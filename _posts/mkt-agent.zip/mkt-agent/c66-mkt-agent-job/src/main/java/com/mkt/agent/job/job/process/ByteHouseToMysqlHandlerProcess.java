package com.mkt.agent.job.job.process;

import com.google.gson.Gson;
import com.mkt.agent.common.entity.TByteHouseData;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.clickhouse.resp.ClDashBoardDataRes;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.job.clickhouse.mapper.TDailyOrderMapper;
import com.mkt.agent.job.mapper.TByteHouseDataMapper;
import com.mkt.agent.job.mapper.api.UserMapper;
import com.mkt.agent.job.req.TAgentCustomers;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

@Component
@Slf4j
public class ByteHouseToMysqlHandlerProcess {

    @Value("${tempReport.splitRow:10000}") //
    private Integer splitRow;


    @Value("${tempReport.insertSplitRow:50000}") //
    private int insertSplitRow ;


    public void execute(Map<String, String> dateLine) {
        Map reportPageResponse = new HashMap();


    }

    private <T> List<List<T>> splitArrayList(List<T> list, int splitSize) {
        List<List<T>> subLists = new ArrayList<>();
        for (int i = 0; i < list.size(); i += splitSize) {
            int endIndex = Math.min(i + splitSize, list.size());
            subLists.add(list.subList(i, endIndex));
        }
        return subLists;
    }

    @Autowired
    private TByteHouseDataMapper byteHouseDataMapper;

    @Resource
    private TDailyOrderMapper tDailyOrderMapper;


    @Autowired
    private UserMapper userMapper;

    public void tongBu(Date startDate, Date endDate) {


        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);

        long i = 0;

        while (startDate.getTime() <= endDate.getTime()) {

            Map<String, Object> parame = new HashMap<>();
            parame.put("date", DateUtils.dateToString(calendar.getTime()));
            List<TByteHouseData> list = tDailyOrderMapper.findListAllByDayOrHour(parame);

            List<List<TByteHouseData>> lists = splitArrayList(list, splitRow);

            byteHouseDataMapper.deleteByDate(parame);


            for (List<TByteHouseData> data : lists) {
                byteHouseDataMapper.insertBatchSomeColumn(data);
            }

            List<String> payers = list.stream().map(TByteHouseData::getLoginName).collect(Collectors.toList());


            List<List<String>> splitArrayList = splitArrayList(payers, insertSplitRow);

            for (List<String> pp2 : splitArrayList) {
                parame = new HashMap<>();
                parame.put("loginName", pp2);
                List<TCustomerLayer> teams = userMapper.selectUserParents(parame);
                Map<String, List<TCustomerLayer>> stringListMap = new HashMap<>();

                for (TCustomerLayer customerLayer : teams) {

                    String names = customerLayer.getParentLoginName();

                    List<TCustomerLayer> pp = stringListMap.get(names);

                    if (pp == null || pp.size() == 0) {
                        pp = new ArrayList<>();
                    }
                    pp.add(customerLayer);

                    stringListMap.put(names, pp);


                }

                Set<String> kyes = stringListMap.keySet();

                for (String key : kyes) {


                    List<TCustomerLayer> player = stringListMap.get(key);

                    List<String> pp = player.stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList());

                    //开始批量更新
                    Map<String, Object> updatePar = new HashMap<>();
                    updatePar.put("loginName", pp);
                    updatePar.put("parentname1", key);
                    //删除
                    byteHouseDataMapper.updateParent1(updatePar);   //更新上级数据

                }


            }

//                log.info("开始更新 level2数据");
//                updateParentData("2") ;
//                log.info("开始更新 level3数据");
//
//                updateParentData("3") ;
//                updateParentData("4") ;
//                updateParentData("5") ;


            log.info("-----结束时间={}", new Date().getTime());


            // 开始计算相关联的代理数据

            Map<String, String> parame2 = new HashMap<>();
            parame2.put("level", 2 + "");

            List<String> top2 = byteHouseDataMapper.getTop2Data(parame2);

            for (String loginName : top2) {
                parame2 = new HashMap<>();
                parame2.put("loginName", loginName);
                com.mkt.agent.job.entity.TAgentCustomers customers = userMapper.getAgentData(parame2);
                if (customers != null) {
                    //开始按需保存数据

                    //先删除之前的数据

                    parame2.put("agentLevel", customers.getAgentLevel() + "");
                    parame2.put("date", DateUtils.dateToString(calendar.getTime()));


                    //删除原先的数据

                    Integer siteId = customers.getSiteId();

                    if (siteId == 2) {
                        userMapper.delByDateLoginNameBP(parame2);
                        userMapper.insertTopBP(parame2);   //走AP
                    } else if (siteId == 1) {
                        userMapper.delByDateLoginNameAP(parame2);
                        userMapper.insertTopAP(parame2);   //走AP
                    } else if (siteId == 3) {
                        userMapper.delByDateLoginNameGP(parame2);
                        userMapper.insertTopGP(parame2);   //走AP
                    }
                }

            }

            calendar.add(Calendar.DAY_OF_MONTH, 1);
            startDate = calendar.getTime();

        }


    }


    /**
     * 新的同步算法
     *
     * @param startDate
     * @param endDate
     */

    public void tongBu2(Date startDate, Date endDate) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);


        log.info("同步开始时间为={},结束时间为={}", DateUtils.dateToString(startDate), DateUtils.dateToString(endDate));

        long i = 0;

        while (startDate.getTime() <= endDate.getTime()) {

            Map<String, Object> parame = new HashMap<>();
            parame.put("date", DateUtils.dateToString(calendar.getTime()));
            List<TByteHouseData> list = tDailyOrderMapper.findListAllByDayOrHourNew(parame);

            if (list.size() > 0) {


                List<List<TByteHouseData>> lists = splitArrayList(list, 50000);


                byteHouseDataMapper.deleteByDate(parame);


                for (List<TByteHouseData> data : lists) {
                    byteHouseDataMapper.insertBatchSomeColumn(data);
                }


                Map<String, String> parame2 = new HashMap<>();
                parame2.put("level", 2 + "");

                List<String> top2 = byteHouseDataMapper.getTop2Data(parame2);

                log.info("代理数={}", top2.size());

                //开始获取用户的级别
                Map<String, Object> ag = new HashMap<>();
                ag.put("loginNames", top2);
                List<com.mkt.agent.job.entity.TAgentCustomers> customers = userMapper.getAgentDataList(ag);

                log.info("代理数customers={}", customers.size());

                Map<String, List<String>> listMap = new HashMap<>();
                Map<String, List<String>> siteIdsMaps = new HashMap<>();


                for (com.mkt.agent.job.entity.TAgentCustomers tAgentCustomers : customers) {

                    List<String> temp = listMap.get(tAgentCustomers.getAgentType() + "");

                    if (temp == null) {
                        temp = new ArrayList<>();
                    }

                    temp.add(tAgentCustomers.getLoginName());

                    listMap.put(tAgentCustomers.getAgentType() + "", temp);


                    List<String> siteIds = listMap.get(tAgentCustomers.getSiteId() + "");

                    if (siteIds == null) {
                        siteIds = new ArrayList<>();
                    }

                    siteIds.add(tAgentCustomers.getLoginName());

                    siteIdsMaps.put(tAgentCustomers.getSiteId() + "", temp);

                }

//           log.info("计算后的数据",   new Gson().toJson(listMap));

                Set<String> keys = listMap.keySet();
                //计算leval 开始
                log.info("计算leval开始 ={}", listMap);

                for (String key : keys) {
                    List<String> logins = listMap.get(key);

                    List<List<String>> logs2 = splitArrayList(logins, 50000);


                    for (List<String> data : logs2) {

                        log.info("jibie={},账号为={}", key, new Gson().toJson(data));

                        parame = new HashMap<>();

                        parame.put("key", key);
                        parame.put("loginName", logins);

                        byteHouseDataMapper.updateLevals(parame);
                    }
                }

                log.info("计算leval结束 ={}", listMap);


                //计算siteid开始
                keys = siteIdsMaps.keySet();
                //计算leval 开始

                for (String key : keys) {
                    List<String> logins = siteIdsMaps.get(key);

                    List<List<String>> logs2 = splitArrayList(logins, 50000);


                    for (List<String> data : logs2) {


                        parame = new HashMap<>();

                        parame.put("key", key);
                        parame.put("loginName", logins);

                        byteHouseDataMapper.updateSiteId(parame);
                    }
                }


                List<TByteHouseData>  allData   =   byteHouseDataMapper.selectListAll();

                //开始分割  10000

                List<List<TByteHouseData>>  splitTempList =    splitArrayList(allData,40000);

                for(List<TByteHouseData> lastTemp : splitTempList){

                    Map<String,List<String>>   siteMaps    =  new HashMap<>();

                    for(TByteHouseData tempData  :    lastTemp) {
                        List<String>  logins =   siteMaps.get(tempData.getParentname2()) ;
                        
                        if (logins   ==  null  ){
                            logins = new ArrayList<>() ; 
                        }
                        logins.add(tempData.getLoginName()) ;
                        siteMaps.put(tempData.getParentname2(),logins);

                    }

                    Set<String>  sets  =    siteMaps.keySet();

                    log.info("很多siteid={}",sets);

                    for(String  string  :  sets){

                    Map<String,Object>     parame24   =  new HashMap<>() ;

                        parame24.put("logins", siteMaps.get(string));
                        parame24.put("date", DateUtils.dateToString(calendar.getTime()));

                        if (string .equals("2")) {
                            userMapper.delByDateLoginNameBP2(parame24);
                            userMapper.insertTopBP2(parame24);   //走AP
                        } else if (string .equals("1")) {
                            userMapper.delByDateLoginNameAP2(parame24);
                            userMapper.insertTopAP2(parame24);   //走AP
                        } else if (string .equals("3")) {
                            userMapper.delByDateLoginNameGP2(parame24);
                            userMapper.insertTopGP2(parame24);   //走AP
                        }
                    }




                }



            }


            calendar.add(Calendar.DAY_OF_MONTH, 1);
            startDate = calendar.getTime();

        }
    }
}
