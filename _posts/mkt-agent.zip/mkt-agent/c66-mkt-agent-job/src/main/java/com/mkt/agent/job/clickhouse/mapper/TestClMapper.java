package com.mkt.agent.job.clickhouse.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverDistriResp;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverTopResp;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description TODO
 * @Classname DashBoardMapper
 * @Date 2023/11/22 14:42
 * @Created by TJSLucian
 */
@Mapper
public interface TestClMapper extends BaseMapper<DashBoardHistoryEntity> {

    List<DashBoardHistoryEntity> testQueryPlayerDataByDay(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

}
