package com.mkt.agent.integration.entities.request;

import com.mkt.agent.common.enums.CustomizedValidationContents;
import com.mkt.agent.common.valid.EnumValid;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel
@Data
public class QueryWithdrawalListReq extends BasePageQueryReq {
    @ApiModelProperty(value = "开始时间", example = "2019-03-20 09:10:12")
    protected String createdDateBegin;

    @ApiModelProperty(value = "结束时间", example = "2019-03-20 09:10:12")
    protected String createdDateEnd;

    @ApiModelProperty(value = "取款人", example = "张三")
    private String customerName;

    @ApiModelProperty(value = "建立人", example = "")
    private String createdBy;

    @ApiModelProperty(value = "金額 begin", example = "")
    private String amountStart;

    @ApiModelProperty(value = "金額 end", example = "")
    private String amountEnd;

    @ApiModelProperty(value = "提案编号", example = "")
    private String requestId;

    @ApiModelProperty(value = "process By", example = "")
    private String processedBy;

    @ApiModelProperty(value = "process Begin", example = "")
    private String processedDateBegin;

    @ApiModelProperty(value = "process End", example = "")
    private String processedDateEnd;

    @ApiModelProperty(required = true, value = "門店代碼, 多個門店用;隔開", example = "", position = 0)
    private String branchCode;

    @ApiModelProperty(value = "取款状态：0  Waiting,2  Approve,-3 Denied")
    private String flag;

    @ApiModelProperty(value = "取款类型: 0 线上取款, 99 门店端现金取款<br/>Withdrawal type: 0 online withdrawal, 99 offline withdrawal")
    private String catalog;

    @ApiModelProperty(value = "上级,parent：a000001")
    private String[] parent;

    @ApiModelProperty(value = "Market :01  Website :02 Store :03 ")
    private String chanelType;

    @ApiModelProperty(value = "是否首次取款:1是,0否")
    private String firstWithdrawal;

    @ApiModelProperty(value = "siteId 1:Bingoplus  2:Arenaplus  3:Gameplus")
    @EnumValid(contents = CustomizedValidationContents.site_id_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class} )
    private Integer siteId;

    @ApiModelProperty("分配人")
    private String assigneeBy;

    @ApiModelProperty(value = "assignee Begin", example = "")
    private String assigneeDateBegin;

    @ApiModelProperty(value = "assignee End", example = "")
    private String assigneeDateEnd;

    @ApiModelProperty(value = "assignee Begin", example = "")
    private String secondAssigneeTimeDateBegin;

    @ApiModelProperty(value = "assignee End", example = "")
    private String secondAssigneeTimeDateEnd;


}
