package com.mkt.agent.integration.entities.ws;

import com.cn.schema.customers.WSCustomers;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class InterWSCustomers extends WSCustomers {

    private String locale;

}