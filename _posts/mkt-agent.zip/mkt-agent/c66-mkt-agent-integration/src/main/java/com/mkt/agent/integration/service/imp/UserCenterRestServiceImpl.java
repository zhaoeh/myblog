package com.mkt.agent.integration.service.imp;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.customers.CreateNewAccountResponse;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.helper.ThirdResponseHelper;
import com.mkt.agent.integration.config.UserCenterConfig;
import com.mkt.agent.integration.data.ProductInfo;
import com.mkt.agent.integration.entities.ws.InterWSCustomers;
import com.mkt.agent.integration.service.UserCenterRestInter;
import com.mkt.agent.integration.utils.HttpClientUtil;
import com.mkt.agent.integration.utils.ProductInfoUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * @program: UserCenterRestServiceImpl
 * @description: 新增userCenter路径
 * @author: Jojo
 * @create: 2023/9/25-17:33
 **/
@Service
public class UserCenterRestServiceImpl implements UserCenterRestInter {

    @Autowired
    private UserCenterConfig userCenterConfig;

//    private static final String QUERY_BRANCHES_URL = "/rest/urf/branch/query_branch_list";

    public static final String TRACE_ID = "traceId";

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public CreateNewAccountResponse createInterNewAccount(InterWSCustomers wsCustomers, String url, String infFlag) {
        return requestUserCenter(url, "创建用户", wsCustomers, CreateNewAccountResponse.class, "wsCustomers", wsCustomers.getProductId(), infFlag);
    }

    public <T1, T2> T2 requestUserCenter(String uri, String uriNote, T1 requestBody, Class<T2> response, String paraName, String productId, String infFlag) {
        String url = "";
        Map<String, Object> dataMap = new HashMap<>();
        try {
            if (StringUtils.isBlank(productId)) {
                productId = requestBody.getClass().getMethod("getProductId", null).invoke(requestBody).toString();
            }
            ProductInfo productInfo = ProductInfoUtils.get(productId);

            url = userCenterConfig.getUserCenterDefaultUrl() + uri;
            dataMap.put("infProductId", productInfo.getProductId());
            dataMap.put("infPwd", productInfo.getProductPwd());
            if (infFlag != null) {
                dataMap.put("infFlag", infFlag);
            } else {
                dataMap.put("infFlag", "0");
            }
            dataMap.put(TRACE_ID, UUID.randomUUID().toString());
            dataMap.put(paraName, requestBody);
            logger.info("请求{}接口{}，完整的接口url：{}，参数：{}", uriNote, uri, url, JSONObject.toJSONString(dataMap));
            StopWatch stopWatch = new StopWatch();
            stopWatch.start();
            String respBody = HttpClientUtil.postJson(url, JSONObject.toJSONString(dataMap));
            stopWatch.stop();
            logger.info("请求{}接口{}userCenterRest耗时情况:{} 秒", uriNote, uri, stopWatch.getTime(TimeUnit.SECONDS));
            logger.info("userCenter creates respBody:{}", respBody);
            return ThirdResponseHelper.pullDataIfExistsDefaultError(respBody, "UserCenter", response);
        } catch (Exception e) {
            logger.error("请求{}接口{}，完整的接口url：{}，参数：{}，返回值：{}，接口请求异常！",
                    uriNote, uri, url, JSONObject.toJSONString(dataMap), e);
            StringBuilder sb = new StringBuilder();
            sb.append("请求").append(uriNote).append("接口").append(uri).append("异常");
            throw ThirdResponseHelper.businessException(e, sb.toString(), ResultEnum.WS_EXCEPTION);
        }
    }

    private String getExecuteTimeDescpition(long lastTime){
        StringBuilder bd = new StringBuilder("");
        if( lastTime/1000.0>10L ){
            bd.append("大于10秒");
        }else if( lastTime/1000.0>8L ){
            bd.append("大于8秒");
        }else if( lastTime/1000.0>6L ){
            bd.append("大于6秒");
        }else if( lastTime/1000.0>4L ){
            bd.append("大于4秒");
        }else if( lastTime/1000.0>2L ){
            bd.append("大于2秒");
        }else if( lastTime/1000.0>1L ){
            bd.append("大于1秒");
        }else {
            bd.append("小于1秒");
        }
        return bd.append("  ").append(lastTime).toString();
    }
}
