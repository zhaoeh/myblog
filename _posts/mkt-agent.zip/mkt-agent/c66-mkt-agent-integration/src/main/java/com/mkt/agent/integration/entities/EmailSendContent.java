package com.mkt.agent.integration.entities;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;


/**
 * @description:
 * @author: Condi
 * @create: 2019-05-24 18:24
 **/
@ApiModel(value="EmailSendContent", description="邮件参数明细")
public class EmailSendContent implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = " 产品id",required = true,example = "DEL01")
    private String productId;
    @ApiModelProperty(value = " 邮件类型",required = true,example = "30000")
    private String emailType;
    @ApiModelProperty(value = " 收件人邮箱,多个邮箱以“;”分隔",required = true,example = "hh@163.com")
    private String toEmails;
    @ApiModelProperty(value = " 抄送人邮箱，多个邮箱以“;”分隔",example = "bb@163.com")
    private String ccEmails;
    @ApiModelProperty(value = " 暗送人邮箱，多个邮箱以“;”分隔",example = "cc@163.com")
    private String accEmails;
    @ApiModelProperty(value = " 邮件主题",required = true,example = "测试")
    private String subject;
    @ApiModelProperty(value = " 用户名",example = "测试")
    private String loginName;
    @ApiModelProperty(value = " 模板参数[key value格式的参数,目前只有新的msg模板支持]",example = "{\"loginName\":\"test\",\"amount\":\"500\"}")
    private String params;
    @ApiModelProperty(value = " 模板参数1",example = "param1")
    private String param1;
    @ApiModelProperty(value = " 模板参数2",example = "param2")
    private String param2;
    @ApiModelProperty(value = " 模板参数3",example = "param3")
    private String param3;
    @ApiModelProperty(value = " 邮件内容[不使用模板情况下，必填]",example = "尊敬的客户:游戏账号2015已成功登录,请查询确认!")
    private String sendContent;
    @ApiModelProperty(value = " 是否使用模板:0使用，1不使用",required = true,example = "0")
    private String useTemplateFlag;
    @ApiModelProperty(value = " 加密key:加密规则MD5(productId+productKey+toEmails+emailType)",required = true,example = "6cadb812fbfbfeb96a44a7a4d14653")
    private String key;
    @ApiModelProperty(value = "模板id[需要指定模板情况下填写]",example = "12")
    private Long templateId;
    @ApiModelProperty(value = "邮件模板类型,默认0:0:普通文本;1:outlook msg模板文件",example = "1")
    private Integer templateType;


    public Integer getTemplateType() {
        return templateType;
    }

    public void setTemplateType(Integer templateType) {
        this.templateType = templateType;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getEmailType() {
        return emailType;
    }

    public void setEmailType(String emailType) {
        this.emailType = emailType;
    }

    public String getToEmails() {
        return toEmails;
    }

    public void setToEmails(String toEmails) {
        this.toEmails = toEmails;
    }

    public String getCcEmails() {
        return ccEmails;
    }

    public void setCcEmails(String ccEmails) {
        this.ccEmails = ccEmails;
    }

    public String getAccEmails() {
        return accEmails;
    }

    public void setAccEmails(String accEmails) {
        this.accEmails = accEmails;
    }


    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getParam1() {
        return param1;
    }

    public void setParam1(String param1) {
        this.param1 = param1;
    }

    public String getParam2() {
        return param2;
    }

    public void setParam2(String param2) {
        this.param2 = param2;
    }

    public String getParam3() {
        return param3;
    }

    public void setParam3(String param3) {
        this.param3 = param3;
    }

    public String getSendContent() {
        return sendContent;
    }

    public void setSendContent(String sendContent) {
        this.sendContent = sendContent;
    }

    public String getUseTemplateFlag() {
        return useTemplateFlag;
    }

    public void setUseTemplateFlag(String useTemplateFlag) {
        this.useTemplateFlag = useTemplateFlag;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Long getTemplateId() {
        return templateId;
    }

    public void setTemplateId(Long templateId) {
        this.templateId = templateId;
    }

    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params;
    }

    @Override
    public String toString() {
        return "EmailSendContent{" +
                "productId='" + productId + '\'' +
                ", emailType='" + emailType + '\'' +
                ", toEmails='" + toEmails + '\'' +
                ", ccEmails='" + ccEmails + '\'' +
                ", accEmails='" + accEmails + '\'' +
                ", subject='" + subject + '\'' +
                ", loginName='" + loginName + '\'' +
                ", params='" + params + '\'' +
                ", param1='" + param1 + '\'' +
                ", param2='" + param2 + '\'' +
                ", param3='" + param3 + '\'' +
                ", sendContent='" + sendContent + '\'' +
                ", useTemplateFlag='" + useTemplateFlag + '\'' +
                ", key='" + key + '\'' +
                ", templateId=" + templateId +
                ", templateType=" + templateType +
                '}';
    }
}

    
