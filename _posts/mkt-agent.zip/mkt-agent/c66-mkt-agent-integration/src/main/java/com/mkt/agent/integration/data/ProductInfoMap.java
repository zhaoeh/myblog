package com.mkt.agent.integration.data;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Created by Angelie.F on 2018/6/4.
 */
@Component
//@PropertySource(value = "classpath:saconfig/fixed/fixed.properties")
@ConfigurationProperties(prefix = "fixed")
public class ProductInfoMap {
    private Map<String, ProductInfo> map ;

    public Map<String, ProductInfo> getMap() {
        return map;
    }

    public void setMap(Map<String, ProductInfo> map) {
        this.map = map;
    }
}
