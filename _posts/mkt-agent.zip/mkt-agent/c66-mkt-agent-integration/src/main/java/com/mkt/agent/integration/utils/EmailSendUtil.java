package com.mkt.agent.integration.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.nacos.shaded.com.google.gson.Gson;
import com.mkt.agent.integration.config.EmailConfig;
import com.mkt.agent.integration.entities.EmailSendContent;
import com.ws.EmailContent;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@Slf4j
public class EmailSendUtil {

    public static final String EMAIL_DOMAIN_CHANGE = "20013";// 域名变更
    public static final String EMAIL_EMERGENCY_NOTICE = "20014";// 紧急通知
    public static final String EMAIL_WEBSITE_CHANGE_BANKACCOUNTNO = "20015";// 网站更改收款帐号
    public static final String EMAIL_WEBSITE_REGARDS = "20016";// 网站问候
    public static final String EMAIL_ESPECIAL_HOLIDAY_MAIL = "20017";// 特殊节日邮件
    public static final String EMAIL_ESPECIAL_MAIL = "20018";// 特殊邮件
    public static final String EMAIL_MODIFY_PERSONAL_INFO = "20019";// 修改基本资料
    public static final String EMAIL_BIND_EMAIL = "20020";// 手机绑定
    public static final String EMAIL_FORGET_PASSWORD = "20021";// 密码找回

    /**
     * 调用邮件平台接口
     *
     * @param emailType     邮件类型,是优惠邮件还是存款邮件 必须
     * @param productid    产品id号 必须
     * @param loginname    loginname
     * @param toEmails     收件人邮箱
     * @param params       模板参数
     * @param subject      主题 必须
     * @param templateFlag 是否使用模板 1：不使用，0：使用
     * @param sendContent  发送内容(使用模板时不需要，不使用模板时设置)
     * @param sendType     0表示纯文本 1表示带html文本 2带附件html方本
     * @param ccEmails     抄送人邮箱 可选
     * @param accEmails    暗送人邮箱 可选
     * @param emailConfig  邮件系统配置
     * @return 系统调用返回值
     */
    public static String callEmailRestApi(String emailType, String productid, String loginname, String toEmails,
                                          String[] params, String subject, String templateFlag, String sendContent,
                                          String sendType, String ccEmails, String accEmails, EmailConfig emailConfig) {
        String msg = "-999";
        String productKey = emailConfig.getProductKey();
        List<EmailSendContent> emailSendContentList = new ArrayList<>();
        EmailSendContent content = new EmailSendContent();
        content.setProductId(productid);// 产品id号 必须
        content.setLoginName(loginname);
        content.setEmailType(emailType);// 邮件类型,是优惠邮件还是存款邮件 必须
        content.setToEmails(toEmails);// 收件人邮箱 必须
        content.setSubject(subject);// 主题 必须
        content.setSendContent(sendContent);// 发送内容
        content.setTemplateType(Integer.parseInt(sendType));// 0表示纯文本 1表示带html文本 2带附件html方本

        if (StringUtils.isNotBlank(ccEmails)) {
            content.setCcEmails(ccEmails);// 抄送人邮箱 可选
        }
        if (StringUtils.isNotBlank(accEmails)) {
            content.setAccEmails(accEmails);// 暗送人邮箱 可选
        }

        content.setUseTemplateFlag(templateFlag);// 0表示自动发送邮件套用模板 1表示后台手动添加内容,不需要邮件模板

        String key = content.getProductId() + productKey + content.getToEmails() + content.getEmailType();// 加密方法
        String enkey = Convert.MD5Encode(key);
        content.setKey(enkey);

        // 模板参数
        if (null != params) {
            if (params.length >= 1) {
                content.setParam1(params[0]);
            }
            if (params.length >= 2) {
                content.setParam2(params[1]);
            }
            if (params.length >= 3) {
                content.setParam3(params[2]);
            }
        }
        emailSendContentList.add(content);
        String restURL = emailConfig.getEmailServerApiUrl() + "/rest/sendEmail";
//        String restURL = "http://localhost:80/rest/sendEmail";
        JSONObject object = new JSONObject();
        object.put("content", JSONArray.parse(new Gson().toJson(emailSendContentList)));
        log.info("调用邮件系统参数:{}", object.toJSONString());
        Object resultStr = HttpClientUtil.postJson(restURL, object.toJSONString());
        if (resultStr != null) {
            log.info("SMS 发送邮件返回数据: {}", resultStr);
            JSONObject jsonObject = JSONObject.parseObject(resultStr.toString());
            msg = jsonObject.getString("body");
        }
        log.info("发送邮件成功,产品ID {},登录名 {}, 邮件标题 {},发送结果 {}", productid, loginname, subject, msg);
        return msg;
    }


    /**
     * 调用邮件平台接口
     *
     * @param list
     * @return String
     * @author @author Spark.W
     */
    public String callEmailRestApi(List<EmailContent> list, EmailConfig emailConfig) {
        String msg = "-999";
        try {
            List<EmailSendContent> emailSendContentList = new ArrayList<>();
            for (EmailContent emailContent : list) {
                EmailSendContent content = new EmailSendContent();
                content.setLoginName(emailContent.getLoginname());
                content.setProductId(emailContent.getProductid());// 产品id号 必须
                content.setEmailType(emailContent.getEmailtype());// 邮件类型,是优惠邮件还是存款邮件 必须
                content.setToEmails(emailContent.getToEmails());// 收件人邮箱 必须
                content.setSubject(emailContent.getSubject());// 主题 必须
                content.setSendContent(emailContent.getSendcontent());// 发送内容
                content.setTemplateType(Integer.parseInt(emailContent.getSendType()));// 0表示纯文本 1表示带html文本 2带附件html方本
                content.setUseTemplateFlag(emailContent.getUseTemplateFlag());
                content.setKey(emailContent.getKey());
                emailSendContentList.add(content);
            }
            String restURL = emailConfig + "/rest/sendEmail";
            JSONObject object = new JSONObject();
//            log.info("sendEmail 调用邮件系统参数:{},url:{}", LoggingInterceptorCommon.hideParam(emailSendContentList),restURL);
            object.put("content", JSONArray.parse(new Gson().toJson(emailSendContentList)));
            Object resultStr = HttpClientUtil.postJson(restURL, object.toJSONString());
            if (resultStr != null) {
                log.info("sendEmail 发送邮件返回数据: {}", resultStr);
                JSONObject jsonObject = JSONObject.parseObject(resultStr.toString());
                msg = jsonObject.getString("body");
            }
            log.info("sendEmail 发送邮件成功,产品ID {},发送结果 {}", emailSendContentList.get(0).getProductId(), msg);
        } catch (Exception ex) {
            log.error("sendEmail call email interface fail! msg:" + ex.getMessage());
        }
        return msg;
    }

}
