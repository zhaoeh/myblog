package com.mkt.agent.integration.exception;

import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;

/**
 * @Description TODO
 * @Classname ATransferException
 * @Date 2023/6/22 15:52
 * @Created by TJSLucian
 */
public class ATransferException extends BusinessException {

    public ATransferException() {
        super();
    }

    public ATransferException(String message) {
        super(message);
    }

    public ATransferException(ResultEnum resultEnum) {
        super(resultEnum);
    }

    public ATransferException(String message, Integer code) {
        super(message, code);
    }

    public ATransferException(String message, Throwable cause) {
        super(message, cause);
    }
}
