package com.mkt.agent.integration.data;

import com.mkt.agent.integration.utils.ProductInfoUtils;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductInfo {

    private String productId;

    private String productPwd;

    private boolean isChecked;
    private String promotionApiUrl;

    private Map<String, Object> wsconfig = new HashMap<String, Object>();

    public boolean isChecked() {
        return isChecked;
    }

    public void setChecked(boolean isChecked) {
        this.isChecked = isChecked;
    }

    public String getPromotionApiUrl() {
        return promotionApiUrl;
    }

    public void setPromotionApiUrl(String promotionApiUrl) {
        this.promotionApiUrl = promotionApiUrl;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductPwd() {
        return productPwd;
    }

    public void setProductPwd(String productPwd) {
        this.productPwd = productPwd;
    }

    private String skynetUrl;

    private String skynetSettingUrl;

    private Map<String, Object> skynetConfig = new HashMap<String, Object>();

    public Map<String, Object> getSkynetConfig() {
        return skynetConfig;
    }

    public void setSkynetConfig(Map<String, Object> skynetConfig) {
        this.skynetConfig = skynetConfig;
    }

    public String getSkynetUrl() {
        return skynetUrl;
    }

    public void setSkynetUrl(String skynetUrl) {
        this.skynetUrl = skynetUrl;
    }

    public String getSkynetSettingUrl() {
        return skynetSettingUrl;
    }

    public void setSkynetSettingUrl(String skynetSettingUrl) {
        this.skynetSettingUrl = skynetSettingUrl;
    }

    public Map<String, Object> getWsconfig() {
        if (wsconfig == null || wsconfig.isEmpty()) {
            List<ProductInfo> productInfos = ProductInfoUtils.getProductInfos();
            for (ProductInfo productInfo : productInfos) {
                if (productInfo.getProductId().equals(this.getProductId())) {
                    wsconfig = productInfo.getWsconfig();
                }
            }
        }
        return wsconfig;
    }

    public void setWsconfig(Map<String, Object> wsconfig) {
        this.wsconfig = wsconfig;
    }

    public void refreshField(String configKey, String fieldName, Object value) throws Exception {
        try {
            if (configKey.contains("wsconfig")) {
                if (null != this.wsconfig.get(fieldName)) {
                    this.wsconfig.put(fieldName, value);
                }
                return;
            }
            Field field = this.getClass().getDeclaredField(fieldName);
            if (null != field) {
                Method method = this.getClass().getMethod("set" + StringUtils.capitalize(fieldName), field.getType());
                if (null != method) {
                    method.invoke(this, value);
                }
            }
        } catch (Exception e) {
            throw e;
        }
    }
}
