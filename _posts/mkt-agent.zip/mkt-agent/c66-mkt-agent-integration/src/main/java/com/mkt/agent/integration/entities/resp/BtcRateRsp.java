package com.mkt.agent.integration.entities.resp;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.math.BigDecimal;

public class BtcRateRsp implements Serializable {
	
	@ApiModelProperty(value = "比特币uuid")
	private String btcUuid;
	
	@ApiModelProperty(value = "payid")
	private String payid;
	
	@ApiModelProperty(value = "兑换币种")
	private String currency;
	
	@ApiModelProperty(value = "兑换金额")
	private BigDecimal amount;
	
	@ApiModelProperty(value = "比特币币种代码")
	private String btcCurrency;
	
	@ApiModelProperty(value = "比特币个数")
	private BigDecimal btcAmount;
	
	@ApiModelProperty(value = "比特币汇率")
	private BigDecimal btcRate;
	
	public String getBtcUuid() {
		return btcUuid;
	}

	public void setBtcUuid(String btcUuid) {
		this.btcUuid = btcUuid;
	}

	public BigDecimal getBtcRate() {
		return btcRate;
	}

	public void setBtcRate(BigDecimal btcRate) {
		this.btcRate = btcRate;
	}

	public BigDecimal getBtcAmount() {
		return btcAmount;
	}

	public void setBtcAmount(BigDecimal btcAmount) {
		this.btcAmount = btcAmount;
	}

	public String getPayid() {
		return payid;
	}

	public void setPayid(String payid) {
		this.payid = payid;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getBtcCurrency() {
		return btcCurrency;
	}

	public void setBtcCurrency(String btcCurrency) {
		this.btcCurrency = btcCurrency;
	}

	@Override
	public String toString() {
		return "BtcRateRsp [" + (btcUuid != null ? "btcUuid=" + btcUuid + ", " : "") + (payid != null ? "payid=" + payid + ", " : "") + (currency != null ? "currency=" + currency + ", " : "") + (amount != null ? "amount=" + amount + ", " : "")
				+ (btcCurrency != null ? "btcCurrency=" + btcCurrency + ", " : "") + (btcAmount != null ? "btcAmount=" + btcAmount + ", " : "") + (btcRate != null ? "btcRate=" + btcRate : "") + "]";
	}
}