package com.mkt.agent.integration.entities.request;

import com.google.common.base.MoreObjects;
import io.swagger.annotations.ApiModelProperty;

public class BasePageQueryReq extends BaseReq {

    @ApiModelProperty(value = "页码[若不传，则默认1]", example = "1")
    private Integer pageNo = 1;

    @ApiModelProperty(value = "每页显示条数[若不传，则默认20]", example = "10")
    private Integer pageSize = 20;

    @ApiModelProperty(value = "是否只查询总数[0:否; 1:是]", example = "1")
    private int onlyCount;
    
    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public boolean isOnlyCount() {
        return onlyCount == 1;
    }

    public void setOnlyCount(int onlyCount) {
        this.onlyCount = onlyCount;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper("")
                .add("pageNo", pageNo)
                .add("pageSize", pageSize)
                .add("onlyCount", onlyCount)
                .addValue(super.toString())
                .omitNullValues()
                .toString();
    }
}
