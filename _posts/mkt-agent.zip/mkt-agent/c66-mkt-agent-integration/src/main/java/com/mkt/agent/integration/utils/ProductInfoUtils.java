package com.mkt.agent.integration.utils;

import com.mkt.agent.integration.data.ProductInfo;
import com.mkt.agent.integration.data.ProductInfoMap;
import com.mkt.agent.integration.data.SecureProductInfoMap;
import org.apache.commons.logging.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.*;

@Component
public class ProductInfoUtils {
	private static ProductInfoUtils productInfoUtils; //  步骤1  静态初使化 一个工具类  这样是为了在spring初使化之前
	@Autowired
	private ProductInfoMap productInfoMap;
	@Autowired
	private SecureProductInfoMap secureProductInfoMap;


	@PostConstruct
	public void init() {
		productInfoUtils = this;
		productInfoUtils.productInfoMap = this.productInfoMap; //步骤2 初使化时将已静态化的productInfoList实例化，即可以使用 productInfoUtils.productInfoList 来调用service服务
		productInfoUtils.secureProductInfoMap = this.secureProductInfoMap;
	}
	static List<ProductInfo> productInfos = null;

	protected static final Logger logger = LoggerFactory.getLogger(ProductInfoUtils.class);

	public static List<ProductInfo> getProductInfos() {
		List<ProductInfo> list = new ArrayList<>();
		if(productInfos==null){
		try {
			if (productInfoUtils==null){
				return new ArrayList<>();
			}
			Map<String, ProductInfo> map = productInfoUtils.productInfoMap.getMap();
			Map<String,ProductInfo> secureMap = productInfoUtils.secureProductInfoMap.getMap();
			for (Map.Entry<String, ProductInfo> entry : map.entrySet()) {
				for (Map.Entry<String, ProductInfo> entry2 : secureMap.entrySet()){
					if (entry.getKey().equalsIgnoreCase(entry2.getKey())) {
						ProductInfo info = entry.getValue();
						ProductInfo secureInfo = entry2.getValue();
						info.setProductPwd(secureInfo.getProductPwd());
						Map<String,Object>transMap = new HashMap<String,Object>();
						transMap.putAll(secureInfo.getWsconfig());
						info.setWsconfig(transMap);
                        info.getSkynetConfig().putAll(secureInfo.getSkynetConfig());
						list.add(info);
					}
				}
			}
			//按产品排序
			list.sort(Comparator.comparing(ProductInfo::getProductId));
		} catch (Exception e) {
			logger.error("初始化getProductInfos异常:{}",e);
			return new ArrayList<ProductInfo>();
		}
		productInfos = list;
		}
		return productInfos;
	}

	public static ProductInfo get(String productId) {
		List<ProductInfo> productInfos = ProductInfoUtils.getProductInfos();
		for (ProductInfo productInfo : productInfos) {
			if (productInfo.getProductId().equals(productId)) {
				return productInfo;
			}
		}
		return null;
	}

	/**	 * 转换特殊字符，将json串转换为JS能直接识别的json	 * @param oldJson	 * @return	 */
	public static String getJsonForJS(String oldJson)
	{
		String newJson = oldJson;
		newJson = newJson.replaceAll("'", "\"");
		return newJson;
	}

}
