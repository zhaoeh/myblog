package com.mkt.agent.integration.entities.request;

import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

public class CreateOnlineOrderReq extends BaseReq {

	@ApiModelProperty(required = true, value = "支付额度", example = "100")
	@NotNull
	private BigDecimal amount;

	@ApiModelProperty(value = "payid, 使用V4接口这个参数可以不传，其他必传", example = "101862")
	private String payid;

	@ApiModelProperty(required = true,
			value = "支付类型[1:在线支付; 5:支付宝扫码; 6:微信扫码; 7:QQ扫码; 8:微信WAP; 9:支付宝WAP; 11:QQWAP; " +
					"15:银联扫码; 16:京东扫码; 17:京东WAP; 18:网银快捷支付PC; 19:网银快捷支付MOB; 20:比特币; " +
					"21:银联WAP; 23:微信条码]; 25=USDT支付; 31=mobi支付", example = "1")
	@NotNull
	private Integer payType;

	@ApiModelProperty(value = "网赚优先标志[1:是; 0:否], 缺省0", example = "0")
	private Integer netEarnPrior;

	@ApiModelProperty(value = "bankNo[在线网银支付有值]", example = "BANK_CARD-B2C-SPDB-P2P")
	private String bankNo;

	@ApiModelProperty(value = "ngamluong网银支付必传,  NL:电子钱包; ATM_ONLINE: 网上ATM转帐; QRCODE:扫码方式")
	private String paymentMethod;

	@ApiModelProperty(required = false,value = "支付来源[1:币商存款小助手; 0:未知], 默认0", example = "0")
	private Integer paySource = 0;

    @ApiModelProperty(value = "存款币种,payType为25 31应必传USDT,如果不传默认使用本币", example = "PHP")
	private String currency;

	@ApiModelProperty(value = "usdt存款协议，非必填（默认OMNI）,此值通过queryDepositBankInfos接口获得", example = "OMNI")
	private String usdtProtocol;

	@ApiModelProperty(value = "目标厅", example = "")
	private String transferPlatform;

	@ApiModelProperty(value = "是否将返回参数payUrl改为二维码地址，注意此参数只对币付宝支付才可以传.1=返回二维码地址，0或不传默认返回支付跳转地址", example = "1")
	private String showQRCode;

	@ApiModelProperty(value = "支付渠道商户的code",example = "GrabPay",required = false)
	private String channelCode;

	@ApiModelProperty(value = "支付类型code")
	private String payTypeCode;

	@ApiModelProperty(value="小程序Id")
	private String miniProgramId;


	@ApiModelProperty(value="客户账号")
	private String dripBankAccountNo;


	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getUsdtProtocol() {
		return usdtProtocol;
	}

	public void setUsdtProtocol(String usdtProtocol) {
		this.usdtProtocol = usdtProtocol;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getPayid() {
		return payid;
	}

	public void setPayid(String payid) {
		this.payid = payid;
	}

	public String getBankNo() {
		return bankNo;
	}

	public void setBankNo(String bankNo) {
		this.bankNo = bankNo;
	}

    public Integer getPayType() {
		return payType;
	}

	public void setPayType(Integer payType) {
		this.payType = payType;
	}

	public Integer getNetEarnPrior() {
		return netEarnPrior;
	}

	public void setNetEarnPrior(Integer netEarnPrior) {
		this.netEarnPrior = netEarnPrior;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public Integer getPaySource() {
		return paySource;
	}

	public void setPaySource(Integer paySource) {
		this.paySource = paySource;
	}

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

	public String getTransferPlatform() {
		return transferPlatform;
	}

	public void setTransferPlatform(String transferPlatform) {
		this.transferPlatform = transferPlatform;
	}

	public String getShowQRCode() {
		return showQRCode;
	}

	public void setShowQRCode(String showQRCode) {
		this.showQRCode = showQRCode;
	}

	public String getPayTypeCode() {
		return payTypeCode;
	}

	public void setPayTypeCode(String payTypeCode) {
		this.payTypeCode = payTypeCode;
	}


	public String getMiniProgramId() {
		return miniProgramId;
	}

	public void setMiniProgramId(String miniProgramId) {
		this.miniProgramId = miniProgramId;
	}

	public String getDripBankAccountNo() {
		return dripBankAccountNo;
	}

	public void setDripBankAccountNo(String dripBankAccountNo) {
		this.dripBankAccountNo = dripBankAccountNo;
	}


}
