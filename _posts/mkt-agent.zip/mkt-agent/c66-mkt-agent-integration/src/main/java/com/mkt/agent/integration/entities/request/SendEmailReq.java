package com.mkt.agent.integration.entities.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("发送邮件请求参数")
public class SendEmailReq extends BaseReq {
    @ApiModelProperty(value = "服务商编码")
    private String providerCode;

    @ApiModelProperty(value = "账号/手机/邮箱列表")
    private String accountList;

    @ApiModelProperty(value = "标题")
    private String title;

    @ApiModelProperty(value = "接收类型：0手机号,1邮箱,2账号")
    private String receiveType;

    @ApiModelProperty(value = "内容")
    private String content;

    @ApiModelProperty(value = "发送类型：0 SMS(短信), 1 Email(邮件)")
    private String sendType;

    @ApiModelProperty(value = "发送方式：0 Instant(立即发送), 1 Scheduled(定时发送)")
    private String sendMode;

    @ApiModelProperty(value = "任务时间： yyyy-MM-dd HH:mm:ss ")
    private String scheduleTime;

    @ApiModelProperty( value = "模板编号")
    private String templateNumber;

    @ApiModelProperty( value = "用户名")
    private String customerName;
}