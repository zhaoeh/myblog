package com.mkt.agent.integration.entities.resp;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.math.BigDecimal;

public class QueryDepositTranRsp implements Serializable {

    @ApiModelProperty("交易单号")
    private String requestId;

    @ApiModelProperty("金额")
    private BigDecimal amount;

    @ApiModelProperty(required = true, value = "创建人")
    private String createdBy;

    @ApiModelProperty(required = true, value = "创建日期")
    private String createdDate;

    @ApiModelProperty(required = true, value = "审批人")
    private String lastUpdatedBy;

    @ApiModelProperty(required = true, value = "审批时间")
    private String lastUpdate;

    @ApiModelProperty(required = true, value = "备注")
    private String remarks;

    @ApiModelProperty("可催单标志")
    private int remindFlag;

    @ApiModelProperty("名称")
    private String title;

    @ApiModelProperty("图片")
    private String itemIcon;

    @ApiModelProperty("银行名称")
    private String bankName;

    @ApiModelProperty("状态[0:等待; 2:批准; -3:拒绝; 97:等待支付; 98:取消; 99:超时]")
    private Integer flag;

    @ApiModelProperty("状态描述")
    private String flagDesc;



    @ApiModelProperty("存款类型码[WS]")
    private Integer transCode;

    @ApiModelProperty("审核时间")
    private String auditDate;

    @ApiModelProperty(value = "可删除标志[true-可以删除;false-不能删除]",example = "true")
    private boolean deleteFlag;

    @ApiModelProperty("支付别名")
    private String typeNameEx;

    @ApiModelProperty("银行卡号")
    private String bankAccountNo;

    @ApiModelProperty("手续费")
    private String fee;

    @ApiModelProperty("手续费费率")
    private String feeRate;

    @ApiModelProperty("到账金额，扣除手续费后的金额")
    private String arrivalAmount;



    @ApiModelProperty("支付渠道图标")
    private String payTypeIcon;


    @ApiModelProperty("币种")
    private String currency;

    @ApiModelProperty("汇率")
    private String rate;

    @ApiModelProperty("源币种对应额度")
    private String transAmount;

    @ApiModelProperty("源币种")
    private String sourceCurrency;

    @ApiModelProperty("协议")
    private String protocol;

    @ApiModelProperty("是否被催单，1是，0否")
    private String appealFlag;

    @ApiModelProperty("订单来源，0网站收款，1收银台收款")
    private Integer orderSource;

    private String  customerName;

    private String channelCode;

    @ApiModelProperty("門店編號")
    private String branchCode;

    @ApiModelProperty("門店名稱")
    private String branchName;

    @ApiModelProperty("存款门店")
    private String depositBranchName;

    @ApiModelProperty("注册门店")
    private String registerBranchName;


    @ApiModelProperty(value = "当前处理人")
    private String processingBy;

    @ApiModelProperty(value = "当前处理时间")
    private String processingTime;

    @ApiModelProperty(value = "用户存款收据/图片地址")
    private String receipt;

    @ApiModelProperty("Branch、Online banking")
    private String type;

    @ApiModelProperty("Waiting Approved Denied Processing")
    private String status;


    @ApiModelProperty(required = true, value = "用户名称")
    private String loginName;

    private String parent;

    @ApiModelProperty(value = "是否首次存款:1是,0否")
    protected String firstDeposit;

    @ApiModelProperty(value = "IP")
    private String ipAddress;

    @ApiModelProperty(value = "终端")
    private String endPoint;

    @ApiModelProperty(value = "newFirstDeposit")
    private String newFirstDeposit;

    @ApiModelProperty(value = "customerId")
    private String customerId;


    @ApiModelProperty(value = "用作⻔店充值预警")
    private String reserve2;


    @ApiModelProperty(value = "bingoplus/arenaplus")
    private String product;

    @ApiModelProperty(value = "Market :01  Website :02 Store :03 glife:4  blue chip:5")
    private String chanelType;

    public String getChanelType() {
        return chanelType;
    }

    public void setChanelType(String chanelType) {
        this.chanelType = chanelType;
    }


    public boolean isDeleteFlag() {
        return deleteFlag;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getSourceCurrency() {
        return sourceCurrency;
    }

    public void setSourceCurrency(String sourceCurrency) {
        this.sourceCurrency = sourceCurrency;
    }

    public String getArrivalAmount() {
        return arrivalAmount;
    }

    public void setArrivalAmount(String arrivalAmount) {
        this.arrivalAmount = arrivalAmount;
    }

    public String getFee() {
        return fee;
    }

    public void setFee(String fee) {
        this.fee = fee;
    }

    public String getFeeRate() {
        return feeRate;
    }

    public void setFeeRate(String feeRate) {
        this.feeRate = feeRate;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }



    public int getRemindFlag() {
        return remindFlag;
    }

    public void setRemindFlag(int remindFlag) {
        this.remindFlag = remindFlag;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getItemIcon() {
        return itemIcon;
    }

    public void setItemIcon(String itemIcon) {
        this.itemIcon = itemIcon;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    public String getFlagDesc() {
        return flagDesc;
    }

    public void setFlagDesc(String flagDesc) {
        this.flagDesc = flagDesc;
    }

    public Integer getTransCode() {
        return transCode;
    }

    public void setTransCode(Integer transCode) {
        this.transCode = transCode;
    }

    public String getAuditDate() {
        return auditDate;
    }

    public void setAuditDate(String auditDate) {
        this.auditDate = auditDate;
    }

    public boolean getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(boolean deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public String getTypeNameEx() {  return typeNameEx; }

    public void setTypeNameEx(String typeNameEx) {  this.typeNameEx = typeNameEx; }

    public String getBankAccountNo() {
        return bankAccountNo;
    }

    public void setBankAccountNo(String bankAccountNo) {
        this.bankAccountNo = bankAccountNo;
    }

    public void setLastUpdate(String lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getLastUpdate() {
        return lastUpdate;
    }

    public String getPayTypeIcon() {
        return payTypeIcon;
    }

    public void setPayTypeIcon(String payTypeIcon) {
        this.payTypeIcon = payTypeIcon;
    }

    public String getRate() {
        return rate;
    }

    public void setRate(String rate) {
        this.rate = rate;
    }

    public String getTransAmount() {
        return transAmount;
    }

    public void setTransAmount(String transAmount) {
        this.transAmount = transAmount;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public String getAppealFlag() {
        return appealFlag;
    }

    public void setAppealFlag(String appealFlag) {
        this.appealFlag = appealFlag;
    }

    public Integer getOrderSource() {
        return orderSource;
    }

    public void setOrderSource(Integer orderSource) {
        this.orderSource = orderSource;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }


    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public String getDepositBranchName() {
        return depositBranchName;
    }

    public void setDepositBranchName(String depositBranchName) {
        this.depositBranchName = depositBranchName;
    }

    public String getRegisterBranchName() {
        return registerBranchName;
    }

    public void setRegisterBranchName(String registerBranchName) {
        this.registerBranchName = registerBranchName;
    }

    public String getProcessingBy() {
        return processingBy;
    }

    public void setProcessingBy(String processingBy) {
        this.processingBy = processingBy;
    }

    public String getProcessingTime() {
        return processingTime;
    }

    public void setProcessingTime(String processingTime) {
        this.processingTime = processingTime;
    }

    public String getReceipt() {
        return receipt;
    }

    public void setReceipt(String receipt) {
        this.receipt = receipt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getParent() {
        return parent;
    }

    public void setParent(String parent) {
        this.parent = parent;
    }

    public String getFirstDeposit() {
        return firstDeposit;
    }

    public void setFirstDeposit(String firstDeposit) {
        this.firstDeposit = firstDeposit;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(String endPoint) {
        this.endPoint = endPoint;
    }

    public String getNewFirstDeposit() {
        return newFirstDeposit;
    }

    public void setNewFirstDeposit(String newFirstDeposit) {
        this.newFirstDeposit = newFirstDeposit;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getReserve2() {
        return reserve2;
    }

    public void setReserve2(String reserve2) {
        this.reserve2 = reserve2;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }
}
