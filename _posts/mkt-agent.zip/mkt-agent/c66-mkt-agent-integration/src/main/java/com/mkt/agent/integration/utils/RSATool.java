package com.mkt.agent.integration.utils;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Objects;

public class RSATool {

	private static final int KEY_SIZE = 1024;

	private static final String algorithm = "RSA";// jdk实际上是RSA/ECB/PKCS1Padding

	private static final Logger logger = LoggerFactory.getLogger(RSATool.class);
	
	private static BouncyCastleProvider bouncyCastleProvider = null;// 默认RSA/None/NoPadding

	/**
	 * 加密公钥，后端传给前端数据需要加密 时使用
	 */
	public static String publicKeyBase64 = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC8OIF8Z0mCekFBdltIsvlbAZGnddb6lheGZWjdY+qyl4hThuPej3+1Id57Y0KWb5PCSpWo7bM5xtVV8GC+vGPwNTwEzrReRQ1SkL+qxw/5BGYKNfhGAfAQBxBJdWafksdlhzgbCzcr7ySE6qxRrqzfS8qNCeTHVmijLA5Jca3q6QIDAQAB";

	public static synchronized BouncyCastleProvider getBouncyCastleInstance() {
		if (bouncyCastleProvider == null) {
			bouncyCastleProvider = new BouncyCastleProvider();
		}
		return bouncyCastleProvider;
	}

	public static String encrypt(String data){
		return encrypt(data,null);
	}

	public static String encrypt(String data, String publicKey) {
		return encrypt(data,publicKey,0);
	}

    public static String encrypt(String data, String inputPublicKey, int type) {
		String publicKey = inputPublicKey;
		if(StringUtils.isBlank(publicKey)){
			publicKey = publicKeyBase64;
		}
        try {
            X509EncodedKeySpec pubX509 = new X509EncodedKeySpec(Base64.decodeBase64(publicKey.getBytes()));
            KeyFactory keyf = KeyFactory.getInstance(algorithm);
            Cipher cipher;
            if (1 == type) {
                // android解密方式需要指定bouncyCastleProvider
                cipher = Cipher.getInstance(algorithm, getBouncyCastleInstance());
            } else {
                cipher = Cipher.getInstance(algorithm);
            }
            cipher.init(Cipher.ENCRYPT_MODE, keyf.generatePublic(pubX509));
            byte[] resultBytes;
            byte[] srcBytes = data.getBytes();
            int segmentSize = KEY_SIZE / 8 - 11;
			resultBytes = cipherDoFinal(cipher, srcBytes, segmentSize); // 分段加密
			return Base64.encodeBase64String(resultBytes);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

	public static String decrypt(String data, String privateKey) {
		try {
			PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec(Base64.decodeBase64(privateKey.getBytes()));
			KeyFactory keyf = KeyFactory.getInstance(algorithm);
			PrivateKey privKey = keyf.generatePrivate(priPKCS8);
			Cipher cipher = Cipher.getInstance(algorithm);
			cipher.init(Cipher.DECRYPT_MODE, privKey);
			int segmentSize = KEY_SIZE / 8;
			byte[] srcBytes = Base64.decodeBase64(data);
			byte[] decBytes;
			decBytes = cipherDoFinal(cipher, srcBytes, segmentSize);
			if(Objects.nonNull(decBytes)){
				return new String(decBytes, StandardCharsets.UTF_8);
			}
		} catch (Exception e) {
			logger.error("解密失败:{}",e.getMessage(), e);
		}
		return null;
	}

	public static String decrypt(String data, String privateKey, int type) {
		try {
			PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec(Base64.decodeBase64(privateKey.getBytes()));
			KeyFactory keyf = KeyFactory.getInstance(algorithm);
			PrivateKey privKey = keyf.generatePrivate(priPKCS8);
			Cipher cipher;
			if (1 == type) {
				// android解密方式需要指定bouncyCastleProvider
				cipher = Cipher.getInstance(algorithm, getBouncyCastleInstance());
			} else {
				cipher = Cipher.getInstance(algorithm);
			}
			cipher.init(Cipher.DECRYPT_MODE, privKey);
			int segmentSize = KEY_SIZE / 8;
			byte[] srcBytes = Base64.decodeBase64(data);
			byte[] decBytes;
			decBytes = cipherDoFinal(cipher, srcBytes, segmentSize);
			return new String(decBytes, StandardCharsets.UTF_8);
		} catch (Exception e) {
			logger.error("解密失败", e);
		}
		return null;
	}

	public static void createKeyPairs() {
		try {
			KeyPairGenerator generator = KeyPairGenerator.getInstance(algorithm);
			generator.initialize(KEY_SIZE, new SecureRandom());
			KeyPair pair = generator.generateKeyPair();
			PublicKey pubKey = pair.getPublic();
			PrivateKey privKey = pair.getPrivate();
			byte[] pk = pubKey.getEncoded();
			byte[] privk = privKey.getEncoded();
			String strpk = new String(Base64.encodeBase64(pk));
			String strprivk = new String(Base64.encodeBase64(privk));
			System.out.println("公钥Base64编码:" + strpk);
			System.out.println("私钥Base64编码:" + strprivk);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static byte[] cipherDoFinal(Cipher cipher, byte[] srcBytes, int segmentSize) {
		try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			int len = srcBytes.length;
			int offSet = 0;
			byte[] x;
			int i = 0;
			while (len - offSet > 0) {
				if (len - offSet > segmentSize) {
					x = cipher.doFinal(srcBytes, offSet, segmentSize);
				} else {
					x = cipher.doFinal(srcBytes, offSet, len - offSet);
				}
				out.write(x, 0, x.length);
				i++;
				offSet = i * segmentSize;
			}
			return out.toByteArray();
		} catch (Exception ex) {
			logger.error("加密失败", ex);
		}
		return null;
	}

//	public static void main(String[] args) {
//		 createKeyPairs();
//		String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCvJltNFRfVWYk+FSwcgvqZBGx/JrtwsZ27i2mfu2TuELD2CMEm6qS9oCXzx8vUN25l7EB7wam851/Xaff3f/dbv5G4sYqxmXu09Na6LOL7iHumMI4CCatGeWFruGMRl4j1zAW6VYc5fY2kJZIYa52wsfFfHVLEiormntMM8+CBvwIDAQAB";
////		String publicKey = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAK8mW00VF9VZiT4VLByC+pkEbH8mu3CxnbuLaZ+7ZO4QsPYIwSbqpL2gJfPHy9Q3bmXsQHvBqbznX9dp9/d/91u/kbixirGZe7T01ros4vuIe6YwjgIJq0Z5YWu4YxGXiPXMBbpVhzl9jaQlkhhrnbCx8V8dUsSKiuae0wzz4IG/AgMBAAECgYAcZqjZZ/k0ZE9n3MEJYofGNjxtpdcxH+wG1EVtXFKyc8xuKN9BMz1Bbm2ZCSXZJJ/nMRcHulCOzCnzYUCPRpXSak9QSPXM9mTqbqv3xO/Il6+OnPlv9Pf1FR4pioaPzqYRXXgXsgXqR2l2RPlbjuNnVi5hjWQvpl7w2V/WdqE9qQJBAPc7G13voKpKFdEeeeM6CAlo54GruxsbQ5Lbhqi3DVV1OxQEUZSScAdVCI9E2Se6JWhBpKMsriS9p/Wl9Z5uqzsCQQC1XL458sEMcQeT61vM4v6KzR5m/9Yuz8BKfSiRV/vxL/AcyQkdhIvbWv3ECGLjRDXNzO5xoJsqgMd1Px0zSvNNAkEA2dM8A4GznxXzLvKZFbj1h8Tj5H34NqPI38WHWXMezmKhkLtVXX/AMNWc2w4f/j6l4rujYRlmvXxUVbzJMbP0LQJAa7RQJAnOK51UarvzIJINqFB4JaL5h4NJJvN9DBO8Q1e8uNuK1kTI6dP3sFtqnpz7duSlFkXS4ELqMO7yYGu6YQJBAOb91FGkm3ZrS+lUretCrEaiqqJbuGD4hBX3vNGOMictAOBdkTZSW5ySWMMLet/0mdHgMN7cwOo7E5FKQhHEatU=";
//		String privateKey = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAK8mW00VF9VZiT4VLByC+pkEbH8mu3CxnbuLaZ+7ZO4QsPYIwSbqpL2gJfPHy9Q3bmXsQHvBqbznX9dp9/d/91u/kbixirGZe7T01ros4vuIe6YwjgIJq0Z5YWu4YxGXiPXMBbpVhzl9jaQlkhhrnbCx8V8dUsSKiuae0wzz4IG/AgMBAAECgYAcZqjZZ/k0ZE9n3MEJYofGNjxtpdcxH+wG1EVtXFKyc8xuKN9BMz1Bbm2ZCSXZJJ/nMRcHulCOzCnzYUCPRpXSak9QSPXM9mTqbqv3xO/Il6+OnPlv9Pf1FR4pioaPzqYRXXgXsgXqR2l2RPlbjuNnVi5hjWQvpl7w2V/WdqE9qQJBAPc7G13voKpKFdEeeeM6CAlo54GruxsbQ5Lbhqi3DVV1OxQEUZSScAdVCI9E2Se6JWhBpKMsriS9p/Wl9Z5uqzsCQQC1XL458sEMcQeT61vM4v6KzR5m/9Yuz8BKfSiRV/vxL/AcyQkdhIvbWv3ECGLjRDXNzO5xoJsqgMd1Px0zSvNNAkEA2dM8A4GznxXzLvKZFbj1h8Tj5H34NqPI38WHWXMezmKhkLtVXX/AMNWc2w4f/j6l4rujYRlmvXxUVbzJMbP0LQJAa7RQJAnOK51UarvzIJINqFB4JaL5h4NJJvN9DBO8Q1e8uNuK1kTI6dP3sFtqnpz7duSlFkXS4ELqMO7yYGu6YQJBAOb91FGkm3ZrS+lUretCrEaiqqJbuGD4hBX3vNGOMictAOBdkTZSW5ySWMMLet/0mdHgMN7cwOo7E5FKQhHEatU=";
//		String data = "SNew485HWhb/p7Qp959uyuwYYrBFL1RnVvRMdu1p8NatRoYMpWQeC9xAg+O6/NkcYQ4jxiv/lPzqxs0lXVCaEl4GEToW8k0lHNd4s0pGamK73LT0Gxcux19tt/CQo2LphfCS6Xsc63btu0XiNaT1DQ5GAEeWMY2aisSV2Qwj8UQ=";
////		String x1 = RSATool.encrypt(data,publicKey);
////		String x2= RSATool.decrypt("huKavASCFSrI3WE/o9ZZy+GHFFTxbmjI/oa4+/vpSPI/YQDEpjwjs7EaY6qO7sSS/ZwKa7I5ktaZ11w4uQXZAr3DtnVACvMYxWCcgiHb3jna4nwfvz98QIfFSd2jHICmGuXpa8JtoHJV3r5S5irOCJwu1bNbFgtRTy7u3ASYJRk=",privateKey);
//		String x3= RSATool.decrypt(data,privateKey);
////		System.out.println(x1);
////		System.out.println(x2);
//		System.out.println(x3);
//
//		// String publicKey =
//		// "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBALUbNw4VfU/EHCLqcnsyw22QJG8HGnpXo3nnbOqzk09HGF+KXwO6NdXof9u5+MHaPD+cZZN0kaJkzSwyhs6FAocCAwEAAQ==";
//		// String privateKey =
//		// "MIIBVAIBADANBgkqhkiG9w0BAQEFAASCAT4wggE6AgEAAkEAtRs3DhV9T8QcIupyezLDbZAkbwcaelejeeds6rOTT0cYX4pfA7o11eh/27n4wdo8P5xlk3SRomTNLDKGzoUChwIDAQABAkABHXNH02sLmC4CKwZcatIYNRh8VINduHdpszqQ8V0ZUliSpoamhNZT7UQig3IFichgrdkMYHepuBAgmaaeGbGtAiEA7RntXrF6eSx/J1fBB3X97igMqw3PPd8FRqS/SEJey8UCIQDDirSaJYc1rIYsj6ipnTGxFxnk4zeK14g6Sq8PwY/92wIhAN6M5pRqjGXu0U9RfFsPcpE3wGRSqwMNMjuT6gPeYHJtAiB5w6PW4UujBr2+fe6/QB2zcvky6LKriK9R7TO6EgSCRQIgeDL26rJTIGz5RIWsYterPpllCir7YOo/qugNpASU8TU=";
//		// String x1 = DESUtil.encrypt(privateKey,
//		// "c34d23bd0fdd4f79ae6f7815412681e1");
//		// System.out.println(x1);
//		// String x2 = DESUtil.decrypt(x1, "c34d23bd0fdd4f79ae6f7815412681e1");
//		// System.out.println(x2.equals(privateKey));
//		// long i = System.currentTimeMillis();
////		String x = "aa888888";
////		x = RSATool.encrypt(x, publicKey);
////		System.out.println(x);
//		//System.out.println(RSATool.decrypt("05XBeaPdHFA3DMqkgnaJ4LmkA==0nPJ", privateKey));
//		// System.out.println(System.currentTimeMillis()-i);
//		// System.out.println(x);
//		// String x =
//		// "LE+Xldxit9FrsSh+R8Q25yRD7P2n+NFt2cFAL+hohIeoluFr1gydGTqx9j8f001z3KHDRrajhhPMjhP/3unl8cKaoiSTN1/YZmjUSqwssdbtp6qXRivxWMQox3nNciW5vQb8uxUpdBMeIozsogWqjr7oAP+3tHyiwDDasW91MVM=";
//		// String x =
//		// "eQWt3fttCv1vInFlJ1jDuBLpw8LfrGPTE4WnmPBOF8BBMi/yFfgCO6tt0wY7EOhm0bm5UYder+xLfBpakkaNq7VyI4Zv+NKrNyoxO6c8MQTRw618z20OTEYIB5pgPMgMEmEps1oOJUFbJTfYD7sET6aFlPjt3D41T3jDLhi7uMI=";
//		// System.out.println(RSATool2.decrypt(x, privateKey));
//		// System.out.println(System.currentTimeMillis()-i);
//		// System.out.println(RSATool.decrypt("cp3ry4r2yPN1UqJKw1wXsudkZX4VpTYZNVZUl9g+3BSy9X8pQSOeu/K0pN3bsgyf2GPh/9aXMQfkqlAJYcG+MeGkriDH6IW/mkbV56ccDV6x+kqwrHEDmm3ifj4pHd20gwZRcDQ/6Z7WaMECe+OMtc7O5t3Acwi3MBRrVJYL8eY=",
//		// privateKey));
//		// String publicKey =
//		// "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDJ82gerVTCAbTSUC36CaBfu20+eb+Zb68ENPK+wNe0BtLRGBfEYRdr+QL5bgoJdVeoriQi9uEl1/Mn7/JPSBWpezFE/dhz3fCX3q5ZjJCz9PtdCXt7Z4E7QRJ0gDSR18knLcm2u2ilcd+TjIdY+rDjYoa/b3mregqypNLrx9BY8wIDAQAB";
//		// String
//		// privateKey="MIICWwIBAAKBgQDJ82gerVTCAbTSUC36CaBfu20+eb+Zb68ENPK+wNe0BtLRGBfEYRdr+QL5bgoJdVeoriQi9uEl1/Mn7/JPSBWpezFE/dhz3fCX3q5ZjJCz9PtdCXt7Z4E7QRJ0gDSR18knLcm2u2ilcd+TjIdY+rDjYoa/b3mregqypNLrx9BY8wIDAQABAoGACcZCL9nr1EgI3HUNBKEapgeIThHOeDqzmdyGMz1aM1hxM7Wa0OJyI8O1pSTyT2rih0OGdDrGwvIkzrYKYFP42Fj5N5arbfQNGSmmwp4DHXF/RO54d6OBwx3V4IWUKFaI9Xxxd8Ee2LQT0hOhtz4m6T6PhAJJVnCwZM3YjOcfQSECQQD/cvCRaGXunk56jTvVEP/5ywDQWjMToCj+XZb/JZZraefzH2BtipyNYUwK8Occtk04U2xYaiHexYcLf0M0KrOdAkEAymLszlU1ryfmD+DaLyCDghJ24JAp+/Uyk1Ueb5I3kwGgSUbkI14Mh8zf7HWbhayC/9lfNkQZbDtddL0AFrOBzwJABuAtIXzR4Y5ZRmsuxRlkCnEwYGtNHKYe9FnIiq2UUufS2nRpwAkPFa8cwN6jGd6+TVnRfL++kaR3chPG10ye8QJAJLVivF4KObXj7bdb+7ZLBBmzRDIB23hy7vQ+bAA6YkimOQRJtvyFC1CmwO3oAovyytMziNU7Qz1VSypIzNVMUwJAcZ3eX8M93AHC/Z2OLQHf06iWSKzSWZsHIE590Di8heO02DTVOB0P9CxiCuhAzs31lovWrVAshBXCuHmXEozmng==";
//		// System.out.println(privateKey.length());
////		 String x = RSATool.encrypt("666888bbb", publicKey);
////		 System.out.println(x);
//		// x="ZErETx5ChIXYplL7yY+snJoXpNAkNImyI0XWpTAmOco1qifausN59nHZ4IBx/R+s96Pmh35lLnBhI9Pn/hHaoQ58anBzTJW1c6YjaFils5LKRJghKgiNpuTRdC02GM4yO50keFCq/2CUHDQzTC1aW70I61zG7Cmw2Ku205Dc5Ts=";
//		// x = RSATool.decrypt(x, privateKey);
//		// System.out.println(x);
////		String x = "eyJkZXZpY2VJZCI6ImFmZmU4MDg3NzM4MzQ3M2ZhZGQ1OTNiYjY2ZDJlMjU2IiwidG9rZW4iOiI2c052Z3Y0d3UwSlkrWXF3cHNJNHdCSnBNU2xtYmg3U3YxaGREYmlISzhPUDhvUkpCcmtkRVNDWC9KbzdSSXQvT0xiajBjMnJmRE1EY1BEMEt5NjVGUUhmNE0yckVyU2tUMHJYclJzczhVampFUlhNQ3FWTGpEczZ5TTh1SWQ0TnhFa1NpczBJeFBNWHlMWXBGSmhkVmRpRnNiZTZGQUFjMmVGWmJCQTFNRGtCUUxnbi9CdTNiK0lNL0hRbkZPSW9rdDVJZldLVm1MYz0ifQ\\u003d\\u003d";
////		String s = new String(Base64.decodeBase64(x));
////		System.out.println(s);
//		// System.out.println(Base64.encodeBase64String("123456789".getBytes()));
////		String x = "}{zutrpoonnmliihgeddccbaaNIA::620,\"\"\"\"\"\"\"\"9102328ca9d124e38bb556e38de56be1A06H5011.0.0M0GRK0DAoVhkklLLldJpDCQu+mJFzpnMDhjKCUHATxKq0Bb0vXTy+tExzC1ckJ1vQkyPbbkL6NLOenKn35gTheZQlTcyxX9VanjRHoyCiEQhPMZiwOxzpNvRbyXD5HUjQtp4HfcUdj7ATiFdlfnn4fZqjHKWc1h0e71955dbc284462194e2db6a6c40601c";
////		String x2 = "}{zutrpoonnmliihgeddccbaaNIA::620,\"\"\"\"\"\"\"\"9102328ca9d124e38bb556e38de56be1A06H5011.0.0M0GRK0DAoVhkklLLldJpDCQu+mJFzpnMDhjKCUHATxKq0Bb0vXTy+tExzC1ckJ1vQkyPbbkL6NLOenKn35gTheZQlTcyxX9VanjRHoyCiEQhPMZiwOxzpNvRbyXD5HUjQtp4HfcUdj7ATiFdlfnn4fZqjHKWc1h0e71955dbc284462194e2db6a6c40601c";
////		System.out.println(x.equals(x2));
////		System.out.println(DigestUtils.md5Hex(x));
//	}
}