package com.mkt.agent.integration.entities.request;

import io.swagger.annotations.ApiModelProperty;

public class QueryPayWayReq extends BaseReq {
	
	@ApiModelProperty(value = "会员星级[传此参数会有更好的性能]", required = false, example = "1")
	private Integer customerLevel;
	
	@ApiModelProperty(value = "信用级别[传此参数会有更好的性能]", required = false, example = "1")
	private Integer depositLevel;

	@ApiModelProperty(value = "返回数据的布局格式，0表示平铺（LINE），1表示按大类分组(GROUP)", required = false, example = "1")
	private Integer layout;

	private String isAgent;

	public Integer getCustomerLevel() {
		return customerLevel;
	}

	public void setCustomerLevel(Integer customerLevel) {
		this.customerLevel = customerLevel;
	}

	public Integer getDepositLevel() {
		return depositLevel;
	}

	public void setDepositLevel(Integer depositLevel) {
		this.depositLevel = depositLevel;
	}

	public Integer getLayout() {
		return layout;
	}

	public void setLayout(Integer layout) {
		this.layout = layout;
	}

	public String getIsAgent() {
		return isAgent;
	}

	public void setIsAgent(String isAgent) {
		this.isAgent = isAgent;
	}

}
