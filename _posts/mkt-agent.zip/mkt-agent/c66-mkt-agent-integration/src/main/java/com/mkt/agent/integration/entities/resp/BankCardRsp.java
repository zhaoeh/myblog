package com.mkt.agent.integration.entities.resp;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

public class BankCardRsp implements Serializable {
    @ApiModelProperty(value = "银行卡前缀")
    private String cardBin;

    @ApiModelProperty(value = "银行名称")
    private String bankName;

    @ApiModelProperty(value = "银行编号")
    private String bankNo;

    @ApiModelProperty(value = "银行代码")
    private String bankCode;

    @ApiModelProperty(value = "银行图标")
    private String bankIcon;

    @ApiModelProperty(value = "卡名称")
    private String cardName;

    @ApiModelProperty(value = "卡号长度")
    private Integer cardNoLength;

    @ApiModelProperty(value = "卡类型[1:借记卡; 2:贷记卡]")
    private Integer cardType;

    @ApiModelProperty(value = "卡类型描述")
    private String cardTypeDesc;
    
	public String getCardBin() {
		return cardBin;
	}

	public void setCardBin(String cardBin) {
		this.cardBin = cardBin;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankNo() {
		return bankNo;
	}

	public void setBankNo(String bankNo) {
		this.bankNo = bankNo;
	}

	public String getCardName() {
		return cardName;
	}

	public void setCardName(String cardName) {
		this.cardName = cardName;
	}

	public Integer getCardNoLength() {
		return cardNoLength;
	}

	public void setCardNoLength(Integer cardNoLength) {
		this.cardNoLength = cardNoLength;
	}

	public Integer getCardType() {
		return cardType;
	}

	public void setCardType(Integer cardType) {
		this.cardType = cardType;
	}

	public String getCardTypeDesc() {
		return cardTypeDesc;
	}

	public void setCardTypeDesc(String cardTypeDesc) {
		this.cardTypeDesc = cardTypeDesc;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankIcon() {
		return bankIcon;
	}

	public void setBankIcon(String bankIcon) {
		this.bankIcon = bankIcon;
	}

	@Override
	public String toString() {
		return "BankCardRsp [" + (cardBin != null ? "cardBin=" + cardBin + ", " : "") + (bankName != null ? "bankName=" + bankName + ", " : "") + (bankNo != null ? "bankNo=" + bankNo + ", " : "") + (bankCode != null ? "bankCode=" + bankCode + ", " : "")
				+ (bankIcon != null ? "bankIcon=" + bankIcon + ", " : "") + (cardName != null ? "cardName=" + cardName + ", " : "") + (cardNoLength != null ? "cardNoLength=" + cardNoLength + ", " : "") + (cardType != null ? "cardType=" + cardType + ", " : "")
				+ (cardTypeDesc != null ? "cardTypeDesc=" + cardTypeDesc : "") + "]";
	}
}