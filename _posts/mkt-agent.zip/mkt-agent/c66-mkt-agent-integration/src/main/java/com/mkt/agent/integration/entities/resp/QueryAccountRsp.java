package com.mkt.agent.integration.entities.resp;

import com.google.common.base.MoreObjects;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class QueryAccountRsp  implements Serializable  {
	@ApiModelProperty("绑定账号列表")
	private List<Account> accounts;
	
	@ApiModelProperty("比特币汇率")
	private BigDecimal btcRate;
	
	@ApiModelProperty("银行卡Bin信息")
	private BankCardRsp carnBin;

	@ApiModelProperty(value = "取款协议列表", example = "[\"OMNI\",\"ERC20\"]")
	private List<String> protocols;
	@ApiModelProperty("上次取款成功账号")
	private Account lastAccount;
	@ApiModelProperty(value = "返回取款账号列表的大类顺序", example = "8,7,6,4,3,1,0")
	private String accountOrder;

	public List<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}

	public BigDecimal getBtcRate() {
		return btcRate;
	}

	public void setBtcRate(BigDecimal btcRate) {
		this.btcRate = btcRate;
	}

	public BankCardRsp getCarnBin() {
		return carnBin;
	}

	public void setCarnBin(BankCardRsp carnBin) {
		this.carnBin = carnBin;
	}

	public List<String> getProtocols() {
		return protocols;
	}

	public void setProtocols(List<String> protocols) {
		this.protocols = protocols;
	}

	public Account getLastAccount() {
		return lastAccount;
	}

	public void setLastAccount(Account lastAccount) {
		this.lastAccount = lastAccount;
	}

	public String getAccountOrder() {
		return accountOrder;
	}

	public void setAccountOrder(String accountOrder) {
		this.accountOrder = accountOrder;
	}

//	@Override
//	public String toString() {
//		return MoreObjects.toStringHelper(this)
//				.add("accounts", accounts)
//				.add("btcRate", btcRate)
//				.add("carnBin", carnBin)
//				.add("protocols", protocols)
//				.add("lastAccount", lastAccount)
//				.add("accountOrder", accountOrder)
//				.omitNullValues()
//				.toString();
//	}
}
