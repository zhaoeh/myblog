package com.mkt.agent.integration.service.imp;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.customers.*;
import com.cn.schema.urf.QueryBranchRequest;
import com.cn.schema.urf.QueryBranchResponse;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.helper.ThirdResponseHelper;
import com.mkt.agent.integration.config.WSConfig;
import com.mkt.agent.integration.data.ProductInfo;
import com.mkt.agent.integration.entities.ws.InterWSCustomers;
import com.mkt.agent.integration.service.WsRestInter;
import com.mkt.agent.integration.utils.HttpClientUtil;
import com.mkt.agent.integration.utils.ProductInfoUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class WsRestServiceImpl implements WsRestInter {

    /*@Value(value="${ws-rest-root-url-C66}")
    private String wsUrl;*/

    @Autowired
    private WSConfig wsConfig;

    private static final String QUERY_BRANCHES_URL = "/rest/urf/branch/query_branch_list";


    public static final String TRACE_ID = "traceId";

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public CreateNewAccountResponse createInterNewAccount(InterWSCustomers wsCustomers,String url,String infFlag) {
        return requestWs(url,"创建用户", wsCustomers, CreateNewAccountResponse.class,"wscustomers",wsCustomers.getProductId(),infFlag);
    }

    @Override
    public QueryCustomersBasicResponse getCustomer(WSQueryCustomers wsQueryCustomers,String url) {
        return requestWs(url,"查询客户基本信息", wsQueryCustomers,QueryCustomersBasicResponse.class,"wsqueryCustomers",wsQueryCustomers.getProductId(),null);
    }

    @Override
    public QueryCustomerDownlineResponse queryAllPlayerByParentPage(WSQueryCustomerDownline wsQueryCustomerDownline, String url) {
        return requestWs(url,"查询客户集基本信息", wsQueryCustomerDownline,QueryCustomerDownlineResponse.class,"queryCustomerDownline",wsQueryCustomerDownline.getProductId(),null);
    }

    @Override
    public QueryBranchResponse queryBranches(QueryBranchRequest request, String product) {
        QueryBranchResponse response = requestWs(QUERY_BRANCHES_URL,"查询ws门店", request,QueryBranchResponse.class,"wsdictItemEntity", product,null);
        return response;
    }

    @Override
    public QueryCountCustomersResponse countCustomers(WSQueryCustomers wsQueryCustomers,String url) {
        QueryCountCustomersResponse response = requestWs(url,"查询ws客户count", wsQueryCustomers,QueryCountCustomersResponse.class,"wsQueryCustomers", wsQueryCustomers.getProductId(),null);
        return response;
    }

    @Override
    public QueryCustomersResponse queryCustomersSingleTable(WSQueryCustomers wsQueryCustomers, String url) {
        QueryCustomersResponse response = requestWs(url,"查询ws客户", wsQueryCustomers,QueryCustomersResponse.class,"wsQueryCustomers", wsQueryCustomers.getProductId(),null);
        return response;
    }

    public  <T1,T2> T2 requestWs(String uri, String uriNote, T1 requestBody, Class<T2> response,String paraName,String productId,String infFlag)   {
        String url = "";
        Map<String,Object> dataMap = new HashMap<>();

        try {
            if(StringUtils.isBlank(productId)){
                productId = requestBody.getClass().getMethod("getProductId",null).invoke(requestBody).toString();
            }
            ProductInfo productInfo = ProductInfoUtils.get(productId);
            logger.info("userCenter===queryBranches-1");
             url = wsConfig.getWsDefaultUrl() + uri;
            logger.info("userCenter===queryBranches-2, url: {}", url);
            dataMap.put("infProductId",productInfo.getProductId());
            dataMap.put("infPwd",productInfo.getProductPwd());
            if (infFlag!=null){
                dataMap.put("infFlag",infFlag);
            }else {
                dataMap.put("infFlag","0");
            }
            dataMap.put(TRACE_ID, UUID.randomUUID().toString());
            dataMap.put(paraName,requestBody);
            logger.info("请求{}接口{}，完整的接口url：{}，参数：{}", uriNote,uri,url, JSONObject.toJSONString(dataMap));
            long inTime = System.currentTimeMillis();
            String respBody = HttpClientUtil.postJson(url, JSONObject.toJSONString(dataMap) );
            long  lastTime = (System.currentTimeMillis()-inTime);
            logger.info("请求{}接口{}WsRest耗时情况:{}", uriNote,uri,getExecuteTimeDescpition(lastTime) );
            return ThirdResponseHelper.pullDataIfExistsDefaultError(respBody, "WS", response);
        } catch (Exception e) {
            logger.error("请求{}接口{}，完整的接口url：{}，参数：{}，返回值：{}，接口请求异常！",
                    uriNote, uri, url, JSONObject.toJSONString(dataMap),  e);
            StringBuilder sb = new StringBuilder();
            sb.append("请求").append(uriNote).append("接口").append(uri).append("异常");
            throw ThirdResponseHelper.businessException(e, sb.toString(), ResultEnum.WS_EXCEPTION);
        }
    }

    private String getExecuteTimeDescpition(long lastTime){
        StringBuilder bd = new StringBuilder("");
        if( lastTime/1000.0>10L ){
            bd.append("大于10秒");
        }else if( lastTime/1000.0>8L ){
            bd.append("大于8秒");
        }else if( lastTime/1000.0>6L ){
            bd.append("大于6秒");
        }else if( lastTime/1000.0>4L ){
            bd.append("大于4秒");
        }else if( lastTime/1000.0>2L ){
            bd.append("大于2秒");
        }else if( lastTime/1000.0>1L ){
            bd.append("大于1秒");
        }else {
            bd.append("小于1秒");
        }
        return bd.append("  ").append(lastTime).toString();
    }
}
