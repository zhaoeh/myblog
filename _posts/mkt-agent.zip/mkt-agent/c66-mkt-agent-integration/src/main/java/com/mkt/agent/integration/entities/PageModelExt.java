package com.mkt.agent.integration.entities;

import com.google.common.base.MoreObjects;
import com.mkt.agent.integration.exception.BizException;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.List;

public class PageModelExt<T> implements Serializable {
    public static final int DEFAULT_PAGE_NO = 1;
    public static final int DEFAULT_PAGE_SIZE = 20;
    public static final int MAX_PAGE_SIZE = 2000;
    @ApiModelProperty("当前页[默认1]")
    private int pageNo = 1;
    @ApiModelProperty("每页显示条数[默认20]")
    private int pageSize = 20;
    @ApiModelProperty("总页数[默认0]")
    private int totalPage = 0;
    @ApiModelProperty("总行数[默认0]")
    private int totalRow = 0;
    @ApiModelProperty("开始行数[默认0]")
    private int startRow = 0;
    @ApiModelProperty("结束行数[默认0]")
    private int endRow = 0;
    @ApiModelProperty("返回数据集[无数据时不返回或返回空数组]")
    private List<T> data;
    private Object statistics;

    public PageModelExt() {
    }

    public PageModelExt(int pageNo, int pageSize) {
        if (pageNo <= 0) {
            this.pageNo = 1;
        } else {
            this.pageNo = pageNo;
        }

        if (pageSize <= 0) {
            this.pageSize = 20;
        } else {
            if (pageSize > 2000) {
                throw new BizException("GW_000008", "More than max page size");
            }

            this.pageSize = pageSize;
        }

    }

    public PageModelExt(int totalRow, int pageNo, int pageSize) {
        if (pageNo <= 0) {
            this.pageNo = 1;
        } else {
            this.pageNo = pageNo;
        }

        if (pageSize <= 0) {
            this.pageSize = 20;
        } else {
            if (pageSize > 5000) {
                throw new BizException("GW_000008", "More than max page size");
            }

            this.pageSize = pageSize;
        }

        this.totalRow = totalRow;
        this.totalPage = this.totalRow / this.pageSize + (this.totalRow % this.pageSize == 0 ? 0 : 1);
        if (pageNo <= this.totalPage) {
            this.startRow = this.pageSize * (this.pageNo - 1);
        } else {
            this.startRow = this.pageSize * (this.totalPage - 1);
        }

        if (this.pageNo * this.pageSize < this.totalRow) {
            this.endRow = this.pageNo * this.pageSize;
        } else {
            this.endRow = this.totalRow;
        }

    }

    public List<T> getData() {
        return this.data;
    }

    public void setData(List<T> data) {
        this.data = data;
    }

    public int getPageNo() {
        return this.pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return this.pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPage() {
        return this.totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getTotalRow() {
        return this.totalRow;
    }

    public int startRow() {
        return this.startRow;
    }

    public int endRow() {
        return this.endRow;
    }

    public void setTotalRow(int totalRow) {
        this.totalRow = totalRow;
        this.totalPage = totalRow / this.pageSize + (this.totalRow % this.pageSize == 0 ? 0 : 1);
        if (this.pageNo <= this.totalPage) {
            this.startRow = this.pageSize * (this.pageNo - 1);
        } else {
            this.startRow = this.pageSize * (this.totalPage - 1);
        }

    }

    public String toString() {
        return MoreObjects.toStringHelper("").add("pageNo", this.pageNo).add("pageSize", this.pageSize).add("totalPage", this.totalPage).add("totalRow", this.totalRow).add("startRow", this.startRow).add("data", this.data).omitNullValues().toString();
    }

    public Object getStatistics() {
        return statistics;
    }

    public void setStatistics(Object statistics) {
        this.statistics = statistics;
    }
}
