package com.mkt.agent.integration.template;

import com.fasterxml.jackson.databind.JsonNode;
import com.mkt.agent.common.entity.api.integration.bi.requests.UserGameSummerRequest;
import com.mkt.agent.common.entity.api.integration.bi.requests.UserSummerRequest;
import com.mkt.agent.common.entity.api.integration.bi.responses.UserGameSummerResponse;
import com.mkt.agent.common.entity.api.integration.bi.responses.UserSummerResponse;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.JsonUtil;
import com.mkt.agent.integration.exception.MKTIntegrationException;
import com.mkt.agent.integration.utils.HttpClientUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.StopWatch;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * bi 接口封装
 */
@Slf4j
public class BiApiTemplate extends ApiTemplate{

    public BiApiTemplate(String biUrl) {
        super(biUrl);
        log.info("bi api uri:{}",biUrl);
    }
    /**
     * 查询用户游戏报表
     * @param param
     * @return
     */
    public List<UserGameSummerResponse> queryUserGameSummary(UserGameSummerRequest param) {
        String paramJson = JsonUtil.toJson(param);
        log.info("bi 获取玩家游戏维度汇总请求入参：{}", paramJson);
        String result = null;
        try {
            long timeStart = System.currentTimeMillis();
            StopWatch stopWatch = new StopWatch();
            stopWatch.start();
            result = HttpClientUtil.postJson(getUrl(), paramJson);
            stopWatch.stop();
            long timeEnd = System.currentTimeMillis();
            log.info("bi获取玩家游戏维度汇总请求 接口耗时:{}秒",stopWatch.getTime(TimeUnit.SECONDS));
            log.info("bi bi 获取玩家投注信息汇总请求 接口耗时:{}秒",(timeEnd-timeStart)/1000);
        } catch (Exception e) {
            throw new MKTIntegrationException(ResultEnum.OUT_SYSTEM_ERROR);
        }
        // 结果处理
        JsonNode data = super.responseAccess(result);
        log.info("bi 获取玩家游戏维度汇总请求回参：{}", data);
        if(null == data){
            return null;
        }
        List<UserGameSummerResponse> gameSummerResponses = parseList(data.toPrettyString(), UserGameSummerResponse.class);
        return gameSummerResponses;
    }

    /**
     * 查询用户报表
     * @param param
     * @return
     */
    public List<UserSummerResponse> queryUserSummary(UserSummerRequest param) {
        String paramJson = JsonUtil.toJson(param);
        log.info("bi 获取玩家投注信息汇总请求入参：{}", paramJson);
        String result = null;
        try {
            long timeStart = System.currentTimeMillis();
            StopWatch stopWatch = new StopWatch();
            stopWatch.start();
            result = HttpClientUtil.postJson(getUrl(), paramJson);
            stopWatch.stop();
            long timeEnd = System.currentTimeMillis();
            log.info("bi bi 获取玩家投注信息汇总请求 接口耗时:{}秒",stopWatch.getTime(TimeUnit.SECONDS));
            log.info("bi bi 获取玩家投注信息汇总请求 接口耗时:{}秒",(timeEnd-timeStart)/1000);
        } catch (Exception e) {
            throw new MKTIntegrationException(ResultEnum.OUT_SYSTEM_ERROR);
        }
        // 结果处理
        JsonNode data = super.responseAccess(result);
        log.info("bi 获取玩家投注信息汇总请求回参：{}", data);
        List<UserSummerResponse> userSummerResponses = parseList(data.toPrettyString(), UserSummerResponse.class);
        return userSummerResponses;
    }


    public static void main(String[] args) {
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        try {
            Thread.sleep(1500L);
        }catch (Exception e){

        }

        stopWatch.stop();
        System.out.println(stopWatch.getTime(TimeUnit.SECONDS));
    }
}
