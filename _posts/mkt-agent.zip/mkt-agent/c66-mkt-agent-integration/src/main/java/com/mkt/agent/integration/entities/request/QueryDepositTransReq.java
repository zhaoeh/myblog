package com.mkt.agent.integration.entities.request;

import com.mkt.agent.common.enums.CustomizedValidationContents;
import com.mkt.agent.common.valid.EnumValid;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;

public class QueryDepositTransReq extends BasePageQueryReq {

    @ApiModelProperty(value = "开始时间", example = "2019-03-20 09:10:12")
    protected String createdDateBegin;

    @ApiModelProperty(value = "结束时间", example = "2019-03-20 09:10:12")
    protected String createdDateEnd;

    @ApiModelProperty(value = "存款人", example = "张三")
    private String depositor;

    @ApiModelProperty(value = "是否首次存款:1是,0否")
    protected String firstDeposit;

    @ApiModelProperty(value = "建立人", example = "")
    private String createdBy;

    @ApiModelProperty(value = "金額 begin", example = "")
    private String amountStart;

    @ApiModelProperty(value = "金額 end", example = "")
    private String amountEnd;

    @ApiModelProperty(value = "process By", example = "")
    private String processedBy;

    @ApiModelProperty(value = "process Begin", example = "")
    private String processedDateBegin;

    @ApiModelProperty(value = "process End", example = "")
    private String processedDateEnd;

    @ApiModelProperty(value = "提案编号", example = "")
    private String requestId;

    @ApiModelProperty(required = true, value = "門店代碼, 多個門店用;隔開", example = "", position = 0)
    private String branchCode;

    @ApiModelProperty(value = "排序，可选", example = "", position = 0)
    private String order;

    @ApiModelProperty(value = "存款状态：0  Waiting,1 processing,2  Approve,-3 Denied,10-pending")
    private String flag;

    @ApiModelProperty(value = "类型,0：online Banking  99：Branch")
    private String type;

    @ApiModelProperty(value = "类型,0：online Banking  99：Branch")
    private String[] typeList;

    @ApiModelProperty(value = "上级,parent：a000001")
    private String[] parent;


    @ApiModelProperty(value = "存款状态：0  Waiting,1 processing,2  Approve,-3 Denied,10-pending")
    private String[] flagList;

    @ApiModelProperty(value = "Market :01  Website :02 Store :03 glife:4  blue chip:5")
    private String chanelType;

    @ApiModelProperty(value = "27: Android, 10: Ios, 11: H5, 9: H5, 3: H5, 1: H5, 8: Pc ,7: Pc ,6: Pc ,5: Pc, 4: Pc, 2: Pc")
    private String endPoint;

    @ApiModelProperty(value = "1234567890")
    private String customerId;

    @ApiModelProperty(value = "siteId 1:Bingoplus  2:Arenaplus  3:Gameplus")
    @EnumValid(contents = CustomizedValidationContents.site_id_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class} )
    private Integer siteId;

    public String getCreatedDateBegin() {
        return createdDateBegin;
    }

    public void setCreatedDateBegin(String createdDateBegin) {
        this.createdDateBegin = createdDateBegin;
    }

    public String getCreatedDateEnd() {
        return createdDateEnd;
    }

    public void setCreatedDateEnd(String createdDateEnd) {
        this.createdDateEnd = createdDateEnd;
    }

    public String getDepositor() {
        return depositor;
    }

    public void setDepositor(String depositor) {
        this.depositor = depositor;
    }

    public String getFirstDeposit() {
        return firstDeposit;
    }

    public void setFirstDeposit(String firstDeposit) {
        this.firstDeposit = firstDeposit;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getAmountStart() {
        return amountStart;
    }

    public void setAmountStart(String amountStart) {
        this.amountStart = amountStart;
    }

    public String getAmountEnd() {
        return amountEnd;
    }

    public void setAmountEnd(String amountEnd) {
        this.amountEnd = amountEnd;
    }

    public String getProcessedBy() {
        return processedBy;
    }

    public void setProcessedBy(String processedBy) {
        this.processedBy = processedBy;
    }

    public String getProcessedDateBegin() {
        return processedDateBegin;
    }

    public void setProcessedDateBegin(String processedDateBegin) {
        this.processedDateBegin = processedDateBegin;
    }

    public String getProcessedDateEnd() {
        return processedDateEnd;
    }

    public void setProcessedDateEnd(String processedDateEnd) {
        this.processedDateEnd = processedDateEnd;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String[] getParent() {
        return parent;
    }

    public void setParent(String[] parent) {
        this.parent = parent;
    }

    public String[] getTypeList() {
        return typeList;
    }

    public void setTypeList(String[] typeList) {
        this.typeList = typeList;
    }

    public String[] getFlagList() {
        return flagList;
    }

    public void setFlagList(String[] flagList) {
        this.flagList = flagList;
    }

    public void setChanelType(String chanelType){
        this.chanelType=chanelType;
    }

    public String getChanelType(){
        return chanelType;
    }

    public String getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(String endPoint) {
        this.endPoint = endPoint;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public Integer getSiteId() {
        return siteId;
    }

    public void setSiteId(Integer siteId) {
        this.siteId = siteId;
    }
}
