package com.mkt.agent.integration.service;

import com.cn.schema.customers.CreateNewAccountResponse;
import com.mkt.agent.integration.entities.ws.InterWSCustomers;

public interface UserCenterRestInter {

    // 创建新的客户
    public CreateNewAccountResponse createInterNewAccount(InterWSCustomers wsCustomers, String url, String infFlag);
}
