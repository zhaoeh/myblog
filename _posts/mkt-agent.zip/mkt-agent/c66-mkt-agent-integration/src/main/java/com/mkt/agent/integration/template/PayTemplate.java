package com.mkt.agent.integration.template;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.integration.pay.BankListResponse;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.JsonUtil;
import com.mkt.agent.integration.config.PaycenterConfig;
import com.mkt.agent.integration.exception.MKTIntegrationException;
import com.mkt.agent.integration.utils.HttpClientUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description: 支付系统调用Api
 * @Author: PTMinnisLi
 * @Date: 2023/6/14
 */
@Slf4j
@Component
public class PayTemplate extends ApiTemplate {


    private final PaycenterConfig paycenterConfig;

    public PayTemplate(@Autowired PaycenterConfig paycenterConfig) {
        super(paycenterConfig.getPayDefaultUrl());
        this.paycenterConfig = paycenterConfig;
        log.info("paycenter url:{} key:{}", paycenterConfig.getPayDefaultUrl(), paycenterConfig.getPayKey());
    }


    public List<BankListResponse> getBanks(String productId, String loginName, String type) {
        Map<String, String> xp = new HashMap<>();
        xp.put("product", productId);
        String key = DigestUtils.md5Hex(productId + paycenterConfig.getPayKey());
        xp.put("keyCode", key);
        xp.put("type", type);

        String response;
        try {
            String url = paycenterConfig.getPayDefaultUrl() + "/bank.do";
            response = HttpClientUtil.post(url, xp);
            log.info("{}调用支付系统bank返回结果:{}", loginName, response);
        } catch (Exception e) {
            log.error("bank请求异常:{}", e.getMessage(), e);
            throw new MKTIntegrationException(ResultEnum.OUT_SYSTEM_ERROR);
        }

        if (StringUtils.isBlank(response)) {
            throw new MKTIntegrationException(ResultEnum.OUT_SYSTEM_ERROR);
        }
        JSONObject object = JSONObject.parseObject(response);
        String success = object.getString("success");
        String data = object.getString("bankList");
        if (StringUtils.isEmpty(success) || StringUtils.isEmpty(data) || !StringUtils.equals(success, "0")) {
            log.error("{}调用bank支付系统返回失败", loginName);
            throw new MKTIntegrationException(ResultEnum.OUT_SYSTEM_ERROR);
        }

        return JsonUtil.toList(data, BankListResponse.class);
    }

    public Result<List<JSONObject>> getWithdrawSwitch() {
        String s;
        try {
            // todo 换成新的地址
            s = HttpClientUtil.get(paycenterConfig.getPayDefaultUrl() + "/queryAgentWithdrawSwitch.do");
        } catch (Exception e) {
            log.info("queryWithdrawSwitch请求异常:{}", e.getMessage(), e);
            return Result.fail();
        }
        if (StringUtils.isBlank(s)) {
            return Result.fail();
        }
        List<JSONObject> jsonObjects = JSONArray.parseArray(s, JSONObject.class);
        if (CollectionUtils.isEmpty(jsonObjects)) {
            log.error("queryWithdrawSwitch请求返回空:{}", jsonObjects);
        }
//        resp.setBody(jsonObjects);
        return Result.success(jsonObjects);
    }


//    public JSONObject queryMerchantPaymentTranLast(String loginName, String productId) throws Exception {
//        Map<String, Object> xp = new HashMap<>();
//        xp.put("loginName", loginName);
//        xp.put("product", productId);
//
//
//        String key = DigestUtils.md5Hex(loginName + productId + paycenterConfig.getPayKey());
//        xp.put("keycode", key);
//        String url = paycenterConfig.getPayDefaultUrl() + "/merchant/queryMerchantPaymentTranLast";
////        String url = "http://10.62.12.55:80" + "/AllPayChannels.do";
//        String s = HttpClientUtil.post(url, xp);
//        log.info("{}调用支付系统接口queryMerchantPaymentTranLast返回:{}", loginName, s);
//
//        Response<JSONObject> resp = JSONObject.parseObject(s, Response.class);
//        if (!resp.success()) {
//            resp.setHead(r2.getHead());
//            return resp;
//        }
//
//        return resp.getBody();
//    }
}
