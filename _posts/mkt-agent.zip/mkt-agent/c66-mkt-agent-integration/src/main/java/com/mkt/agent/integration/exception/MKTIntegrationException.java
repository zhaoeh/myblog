package com.mkt.agent.integration.exception;

import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;

public class MKTIntegrationException extends BusinessException {

    public MKTIntegrationException() {
        super();
    }

    public MKTIntegrationException(String message) {
        super(message);
    }

    public MKTIntegrationException(ResultEnum resultEnum) {
        super(resultEnum);
    }

    public MKTIntegrationException(String message, Integer code) {
        super(message, code);
    }

    public MKTIntegrationException(String message, Throwable cause) {
        super(message, cause);
    }
}
