package com.mkt.agent.integration.entities.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel
@Data
public class ValidatePwdReq extends BaseReq {

    @ApiModelProperty(required = true, value = "玩家登入名", example = "ptest01")
    private String customerName;

    @ApiModelProperty(required = true, value = "玩家密碼[加密]", example = "")
    private String password;

    @ApiModelProperty(value = "密码校验类型[1:登陆密码(默认); 2:PT密码;3:取款密码,4:提现密码] 类型为4的时候，只需要传新密码", example = "2")
    private int type = 1;

    @ApiModelProperty(value = "产品类型",example = "C66")
    private String productId = "C66";
}
