package com.mkt.agent.integration.utils;

import org.apache.commons.lang3.StringUtils;

/**
 * @ClassName MaskUtil
 * @Author TJSAlex
 * @Date 2023/6/5 14:45
 * @Version 1.0
 **/
public class MaskUtil {

    public static String mask(String s, int prefixLen, int suffixLen) {
        try {
            if (StringUtils.isBlank(s)) {
                return null;
            }
            if (s.length() <= prefixLen + suffixLen) {
                return s;
            }
            return s.substring(0, prefixLen) + StringUtils.repeat("*", s.length() - (prefixLen + suffixLen)) + s.substring(s.length() - suffixLen);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public static String maskBankCardNo(String s) {
        try {
            if (null == s) {
                return null;
            }
            if (s.length() <= 4) {
                return s;
            }
            int lenth = s.length();
            return "**** **** **** " + s.substring(lenth - 4, lenth);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    public static String maskRealName(String s) {
        if (StringUtils.isBlank(s)) {
            return null;
        }
        return StringUtils.repeat("*", Math.min(2, Math.max(s.length() - 1, 1))) + s.substring(s.length() - 1);
    }

}
