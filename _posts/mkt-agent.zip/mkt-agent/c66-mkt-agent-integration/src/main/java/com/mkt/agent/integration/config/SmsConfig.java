package com.mkt.agent.integration.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @Description: 短信服务配置
 * @Author: PTMinnisLi
 * @Date: 2023/6/5
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Component
@RefreshScope
public class SmsConfig {

    @Value("${C66.sms.url}")
    private String url;

    @Value("${C66.sms.product-key}")
    private String productKey;

    /**
     * 短信验证码失效时间：默认5分钟（300秒）
     */
    @Value("${C66.sms.expire-time:5}")
    private Long smsOtpExpireTime;

}
