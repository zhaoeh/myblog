package com.mkt.agent.integration.utils;

import com.mkt.agent.common.config.ProductKeyConfig;
import com.mkt.agent.common.constants.ATransferConstants;
import org.apache.commons.codec.binary.Base64;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import java.security.SecureRandom;
import java.util.Random;

/**
 * @ClassName PHPDESEncrypt
 * @Description TODO
 * @Author TJSAlex
 * @Date 2023/6/5 11:43
 * @Version 1.0
 **/
@Component
public class PHPDESEncrypt {

    private String key;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public PHPDESEncrypt() {

    }

    /**
     * 根据类型实例化加密类
     *
     * @author sky.x
     * @param  productId
     * @param
     *            type 01:真实姓名 02:地址 03:电话 04:邮件 05:网络联系方式 06:帐户名 07:帐号 08:存款人
     *            (预留校验码以真实姓名加密,身份证以电话加密,问题答案以地址加密)
     */
    public PHPDESEncrypt(String productId, String type) {
        StringBuilder tempKey = new StringBuilder();
        if (null == type || "".equals(type)) {
            tempKey.append(productId).append(productId).append(productId);
        }

        String productKey = "BANK_ACCOUNT_NO";
        // 07:帐号
        if ("07".equals(type)) {
            tempKey.append(productId).append("AN_07").append(productKey, 2, productKey.length() - 1);
        }
        this.key = tempKey.toString();
    }

    /**
     * 加密
     *
     * @author sky.x
     * @param
     *            input
     * @return String
     */
    public String encrypt(String input) throws Exception {
        if (null == input || "".equals(input.trim())) {
            return input;
        }
        String str1 = getRandomNum(1);
        String str2 = getRandomStr(str1, 2);
        String str3 = getRandomStr(str1, 3);
        StringBuilder sb = new StringBuilder(str2);
        sb.append(base64Encode(desEncrypt(input.getBytes())).replaceAll("\r|\n", ""));
        sb.append(str3);
        return sb.toString();
    }

    public String base64Encode(byte[] s) {
        if (s == null) {
            return null;
        }
        return Base64.encodeBase64String(s);
    }

    public byte[] desEncrypt(byte[] plainText) throws Exception {
        SecureRandom sr = new SecureRandom();
        DESKeySpec dks = new DESKeySpec(key.getBytes());
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
        SecretKey key = keyFactory.generateSecret(dks);
        Cipher cipher = Cipher.getInstance("DES");
        cipher.init(Cipher.ENCRYPT_MODE, key, sr);
        return cipher.doFinal(plainText);
    }

    /**
     * 生成随机字符串
     *
     * @param prefix
     *            前缀
     * @param bodyLength
     *            前缀后 字符串长度
     * @return 帐号
     */
    public String getRandomStr(String prefix, int bodyLength) {
        char[] c = { '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', 'a', 's', 'd', 'f', 'g',
                'h', 'j', 'k', 'l', 'z', 'x', 'c', 'b', 'n', 'm', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', 'A', 'S', 'D', 'F', 'G', 'H',
                'J', 'K', 'L', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '=' };
        Random random = new Random(); // 初始化随机数产生器
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < bodyLength; i++) {
            sb.append(c[Math.abs(random.nextInt()) % c.length]);
        }
        return prefix + sb.toString();
    }

    /**
     * 生成随机由数字组成的字符串
     *
     * @param bodyLength
     *            字符串长度
     * @return
     */
    public String getRandomNum(int bodyLength) {
        Random random = new Random();
        StringBuilder sRand = new StringBuilder();
        for (int i = 0; i < bodyLength; i++) {
            String rand = String.valueOf(random.nextInt(10));
            sRand.append(rand);
        }
        return sRand.toString();
    }

    /**
     * 解密
     *
     * @author sky.x
     * @param
     *            input
     * @return String
     */
    public String decrypt(String input) {
        if (null == input || "".equals(input.trim())) {
            return input;
        }
        input = input.substring(3, input.length() - 4);
        byte[] result = base64Decode(input);
        return new String(desDecrypt(result));
    }

    public byte[] base64Decode(String s) {
        if (s == null) {
            return null;
        }
        return Base64.decodeBase64(s);
    }

    public byte[] desDecrypt(byte[] encryptText) {
        try {
            SecureRandom sr = new SecureRandom();
            DESKeySpec dks = new DESKeySpec(key.getBytes());
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
            SecretKey key = keyFactory.generateSecret(dks);
            Cipher cipher = Cipher.getInstance("DES");
            cipher.init(Cipher.DECRYPT_MODE, key, sr);
            return cipher.doFinal(encryptText);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
