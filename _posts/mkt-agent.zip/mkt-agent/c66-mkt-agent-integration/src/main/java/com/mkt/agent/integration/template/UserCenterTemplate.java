package com.mkt.agent.integration.template;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cn.schema.customers.*;
import com.cn.schema.request.*;
import com.cn.schema.request.WSResultObj;
import com.cn.schema.urf.QueryBranchRequest;
import com.cn.schema.urf.QueryBranchResponse;
import com.cn.schema.urf.WSBranch;
import com.google.common.collect.Lists;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.enums.CustomerFlagEnum;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.helper.ThirdResponseHelper;
import com.mkt.agent.common.utils.AesEncode;
import com.mkt.agent.common.utils.CommonUtil;
import com.mkt.agent.integration.config.WSConfig;
import com.mkt.agent.integration.entities.ws.InterWSCustomers;
import com.mkt.agent.integration.exception.BizException;
import com.mkt.agent.integration.exception.MKTIntegrationException;
import com.mkt.agent.integration.service.UserCenterRestInter;
import com.mkt.agent.integration.service.WsRestInter;
import com.mkt.agent.integration.utils.Convert;
import com.mkt.agent.integration.utils.HttpClientUtil;
import lombok.extern.slf4j.Slf4j;
import net.logstash.logback.encoder.com.lmax.disruptor.BusySpinWaitStrategy;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.slf4j.MDC;

import java.lang.reflect.Field;
import java.util.UUID;

import java.util.UUID;

import java.util.*;

/**
 * @program: UserCenterTemplate
 * @description: 新增userCenter路径
 * @author: Jojo
 * @create: 2023/9/25-17:31
 **/

@Slf4j
@Component
public class UserCenterTemplate extends ApiTemplate {

    private String infPwd;

    private UserCenterRestInter userCenterRestInter;

    private WsRestInter wsRestInter;

    public UserCenterTemplate() {
        super();
    }

    public UserCenterTemplate(String url, UserCenterRestInter userCenterRestInter) {
        super(url);
        this.userCenterRestInter = userCenterRestInter;
    }

    public UserCenterTemplate(String url, UserCenterRestInter userCenterRestInter, WsRestInter wsRestInter) {
        super(url);
        this.userCenterRestInter = userCenterRestInter;
        this.wsRestInter = wsRestInter;
    }

    public UserCenterTemplate(WSConfig wsConfig) {
        super(wsConfig.getWsDefaultUrl());
        this.infPwd = wsConfig.getPwd();
    }

    public UserCenterTemplate(String uri, String infPwd) {
        super(uri);
        this.infPwd = infPwd;
    }

    /**
     * userCenter登录接口调用
     *
     * @param wsCustomer  登录request
     * @param flag        flag
     * @param loginMethod loginMethod
     * @return response
     */
    public WSCustomers loginByLoginName(WSCustomers wsCustomer, String flag, String loginMethod) {
        LoginWebRequest request = new LoginWebRequest();
        request.setInfProductId(wsCustomer.getProductId());
        request.setInfPwd(infPwd);
        request.setInfFlag(Objects.requireNonNullElse(flag, "0"));
        request.setLoginMethod(loginMethod);
        request.setWSCustomers(wsCustomer);
        String requestUUID = CommonUtil.genRequestUUID();
        request.setRequestUUID(requestUUID);
        String url = getUrl() + "/customer/account/login_web";
        String resp="";
        try {
            log.info("userCenter接口loginByLoginName:{}", JSONObject.toJSONString(request));
            resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            log.info("userCenter登录接口/customer/account/login_web 返回值：{}", resp);
            LoginWebResponse response = JSONObject.parseObject(resp, LoginWebResponse.class);
            if(Objects.isNull(response)||Objects.isNull(response.getWSCustomers())){
                log.info("userCenter登录接口/customer/account/login_web返回为null");
                //下面会报空指针被捕获
            }
            log.info("loginByLoginName登录名：{} wsCustomer:{},loginMethod:{},flag:{},uuid:{}", wsCustomer.getLoginName(),
                    response.getWSCustomers().getLoginName(), "loginMethod", "flag", request.getRequestUUID());
            return response.getWSCustomers();
        } catch (Exception ex) {
            log.error("userCenter接口调用异常：loginByLoginName登录名：{} ,loginMethod:{},flag:{},uuid:{}", wsCustomer.getLoginName(),
                    "loginMethod", "flag", requestUUID, ex);
            throw new MKTIntegrationException(ResultEnum.USERNAME_OR_PASSWORD_ERROR);
        }
    }

    /**
     * 根据登录名查询用户信息
     *
     * @param productId
     * @param loginName
     * @return 用户信息
     */
    public WSCustomers queryCustomerByLoginName(String productId, String loginName) {
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("requestUUID", UUID.randomUUID().toString().replace("-", "").toLowerCase());
            params.put("infProductId", productId);
            params.put("loginName", loginName);
            params.put("infPwd", infPwd);
            //增加是否门店标识
            params.put("onlyOpenUser", false);
            String req = JSONObject.toJSONString(params);
            String url = getUrl() + "/customer/account/getCustomerByLoginName";
            String resp = HttpClientUtil.postJson(url, req);
            log.info("/customer/account/getCustomerByLoginName 请求用户中心-queryCustomerByLoginName，url:{} 入参：{} 返回值：{}", url, req, resp);
            if (StringUtils.isBlank(resp)) {
                log.info("userCenter返回结果为空");
                return null;
            }
            QueryCustomersBasicByLoginNameResponseV3 result = JSONObject.parseObject(resp, QueryCustomersBasicByLoginNameResponseV3.class);
            WSCustomers wsCustomers = result.getWsCustomer();
            return wsCustomers;
        } catch (Exception e) {
            log.error("/customer/account/getCustomerByLoginName 调用用户中心-queryCustomerByLoginName接口异常， 异常信息：{}", e.getMessage());
            e.printStackTrace();
            throw new MKTIntegrationException(ResultEnum.USER_CENTER_EXCEPTION);
        }
    }

    /**
     * 根据手机号查询用户信息
     *
     * @param productId
     * @param phone(明文)
     * @return 用户信息
     */
    public WSCustomers queryCustomerByPhone(String productId, String phone) {
        try {
            Map<String, Object> params = new HashMap<>();
            params.put("requestUUID", UUID.randomUUID().toString().replace("-", "").toLowerCase());
            params.put("infProductId", productId);
            params.put("infPwd", infPwd);
            params.put("phone", Convert.MD5Encode(phone));
            String req = JSONObject.toJSONString(params);
            String url  = getUrl() + "/customer/account/queryCustomerByPhone";
            String resp = HttpClientUtil.postJson(url, req);
            log.info("/customer/account/queryCustomerByPhone 请求用户中心-queryCustomerByPhone，url:{} 入参：{} 返回值：{}", url, req, resp);
            if (StringUtils.isBlank(resp)) {
                log.info("userCenter返回结果为空");
                return null;
            }
            QueryCustomersBasicByLoginNameResponseV3 result = JSONObject.parseObject(resp, QueryCustomersBasicByLoginNameResponseV3.class);
            WSCustomers wsCustomers = result.getWsCustomer();
            return wsCustomers;
        } catch (Exception e) {
            log.error("/customer/account/queryCustomerByPhone 调用用户中心-queryCustomerByPhone接口异常，异常信息：{}", e.getMessage());
            e.printStackTrace();
            throw new MKTIntegrationException(ResultEnum.USER_CENTER_EXCEPTION);
        }
    }

    /**
     * 根据邮箱查询用户信息
     *
     * @param productId
     * @param email
     * @return 用户信息
     */
    public List<WSBond> queryCustomerByEmail(WSQueryBondRequests wsQueryBondRequest) {
        try {
            QueryBondRequest request = new QueryBondRequest();
            request.setInfProductId(wsQueryBondRequest.getProductId());
            request.setInfPwd(infPwd);
            request.setRequestUUID(UUID.randomUUID().toString().replace("-", "").toLowerCase());
            request.setWSQueryBondRequests(wsQueryBondRequest);
            String url  = getUrl() + "/customer/bind/queryPhoneOREmail";
            String resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            log.info("/customer/bind/queryPhoneOREmail 请求用户中心-queryCustomerByEmail，url:{} 入参：{} 返回值：{}", url, JSONObject.toJSONString(request), resp);
            if (StringUtils.isBlank(resp)) {
                log.info("userCenter返回结果为空");
                return null;
            }
            QueryBondResponse response = JSONObject.parseObject(resp, QueryBondResponse.class);
            return response.getWSBond();
        } catch (Exception e) {
            log.error("/customer/bind/queryPhoneOREmail 调用用户中心-queryCustomerByEmail接口异常，异常信息：{}", e.getMessage());
            e.printStackTrace();
            throw new MKTIntegrationException(ResultEnum.USER_CENTER_EXCEPTION);
        }
    }

    /**
     * 创建新用户
     *
     * @param wsCustomers
     * @param infFlag
     * @return 用户信息
     */
    public Result<CreateNewAccountResponse> createNewAccount(InterWSCustomers wsCustomers, String infFlag) {
        log.info("调用UserCenter分支创建用户===");
        QueryBranchRequest queryBraches = new QueryBranchRequest();
        queryBraches.setInfProductId(wsCustomers.getProductId());
        QueryBranchResponse response = wsRestInter.queryBranches(queryBraches, wsCustomers.getProductId());
        List<WSBranch> branches = response == null ? null : response.getData();
        WSBranch branch = branchElectionByDefault(branches);
        wsCustomers.setBranchCode(branch == null ? null : branch.getBranchCode());
        CreateNewAccountResponse createNewAccountResponse = userCenterRestInter.createInterNewAccount(wsCustomers, getUrl(), infFlag);
        log.info("UserCenterTemplate创建新代理 入参：{} 返回值：{}", wsCustomers, createNewAccountResponse);
        if (Objects.isNull(createNewAccountResponse)) {
            return Result.fail("远程调用userCenter创建客户返回为null");
        } else if (null == createNewAccountResponse.getWSCustomers()) {
            return Result.fail(createNewAccountResponse.getWsErrorMsg());
        } else {
            return Result.success(createNewAccountResponse);
        }
    }

    protected List<String> testBranch = Arrays.asList("SLS", "SLS1");
    protected List<String> allGames = Arrays.asList("5", "21", "27");
    protected List<String> allGames1 = Arrays.asList("5", "21");
    protected List<String> allGames2 = Arrays.asList("5", "27");

    protected WSBranch branchElectionByDefault(List<WSBranch> branches) {
        log.info("branchElectionByDefault allGames={}", allGames);

        if(CollectionUtils.isEmpty(branches)){
            return null;
        }

        List<WSBranch> allGamesBranchs = new ArrayList<>();
        branches.stream().filter(b -> StringUtils.isNoneBlank(b.getSupportGames()) && b.getSupportGames().split(",").length >= 2 && !testBranch.contains(b.getBranchName().toUpperCase())).forEach(b -> {
            List<String> games = Lists.newArrayList(b.getSupportGames().split(","));
            if (games.containsAll(allGames)) {
                allGamesBranchs.add(b);
            } else if (games.containsAll(allGames1)) {
                allGamesBranchs.add(b);
            } else if (games.containsAll(allGames2)) {
                allGamesBranchs.add(b);
            }
        });
        if (allGamesBranchs.size() > 0) {
            Collections.shuffle(allGamesBranchs);
            return allGamesBranchs.get(0);
        }
        log.info("混合门店列表为空");
        return null;
    }

    /**
     * 邮箱/手机绑定接口
     *
     * @param userCenterBond 邮箱绑定
     * @return response
     */
    public Boolean bindMobileNoOrEmail(WSBond wsBond) {
        try {
            CreateBondRequest request = new CreateBondRequest();
            request.setInfProductId(wsBond.getProductId());
            request.setRequestUUID(UUID.randomUUID().toString().replace("-", "").toLowerCase());
            request.setInfPwd(infPwd);
            request.setWSBond(wsBond);
            String url = getUrl() + "/customer/bind/createPhoneOREmail";
            String resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            if (StringUtils.isBlank(resp)) {
                log.info("userCenter返回结果为空");
                return Boolean.FALSE;
            }
            log.info(":{},入参：{}，响应：{}", url, JSONObject.toJSONString(request), resp);
            try {
                JSONObject result = JSON.parseObject(resp);
                if(!Objects.isNull(result)&&result.getBoolean("result")){
                    return Boolean.TRUE;
                }
            }catch (Exception e){
                Result response = JSONObject.parseObject(resp, Result.class);
                throw new BusinessException(response.getMessage());
            }
            return Boolean.FALSE;
        } catch (Exception ex) {
            log.error("调用用户中心接口异常，bindMobileNoOrEmail 错误", ex);
            throw ex;
        }
    }

    /**
     * 校验用户信息
     *
     * @param productId
     * @param checkType
     * @param checkValue
     * @return
     */
    public boolean checkCustomerInfo(String productId, int checkType, String checkValue) {
        try {
            JSONObject request = new JSONObject();
            WSCustomers wsCustomer = new WSCustomers();
            CustomerFlagEnum flagEnum = CustomerFlagEnum.findEnumByFlag(checkType);
            if(Objects.nonNull(flagEnum)){
                String setField = flagEnum.getField();
                Field field =  wsCustomer.getClass().getDeclaredField(setField);
                field.setAccessible(true);
                field.set(wsCustomer, checkValue);
            }else{
                return false;
            }
            request.put("infProductId",productId);
            request.put("infPwd",infPwd);
            request.put("infFlag",checkType);
            request.put("wsCustomers",wsCustomer);
            request.put("requestUUID",UUID.randomUUID().toString().replace("-", "").toLowerCase());
            String url = getUrl() + "/customer/account/checkCustomerInfo";
            String resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            log.info("请求用户中心-checkCustomerInfo，url:{},入参：{}，响应：{}",url,JSONObject.toJSONString(request),resp);
            JSONObject response = JSONObject.parseObject(resp, JSONObject.class);
            return response.getBoolean("result");
        } catch (Exception ex) {
            log.error("调用用户中心接口异常，checkCustomerInfo 错误", ex);
            if(ex != null){
                throw new BizException(ex.getMessage());
            }else{
                throw new BizException();
            }

        }
    }

    /**
     * C66 修改玩家详细信息（包括修改密码、状态等详细信息）
     * 所有调用已改
     * @param wsCustomers <pre>
     */
    public ModifyAccountResponse modifyAccount(WSCustomers wsCustomers, String infFlag) {
        try {
            //note：以防更新用户出错，需要先查用户信息，获取正确的用户id
            if(Objects.isNull(wsCustomers)){
                throw new BusinessException(ResultEnum.ERROR_ACCOUNT_NOTEXIST.getMessage(), ResultEnum.ERROR_ACCOUNT_NOTEXIST.getCode());
            }
            //查询用户信息获取customerId
            if(StringUtils.isNotBlank(wsCustomers.getLoginName()) && StringUtils.isNotBlank(wsCustomers.getProductId())){
                WSCustomers queryCustomers = this.queryCustomerByLoginName(wsCustomers.getProductId(),wsCustomers.getLoginName());
                if(Objects.nonNull(queryCustomers)){
                    wsCustomers.setCustomerId(queryCustomers.getCustomerId());
                }
            }
            ModifyAccountRequest request = new ModifyAccountRequest();
            request.setInfProductId(wsCustomers.getProductId());
            request.setRequestUUID(UUID.randomUUID().toString().replace("-", "").toLowerCase());
            request.setInfPwd(infPwd);
            request.setWSCustomers(wsCustomers);
            request.setInfFlag(infFlag);

            String url = getUrl() + "/customer/account/modify";
            String resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            log.info("请求用户中心-modifyAccount，url:{},入参：{}，响应：{}",url,JSONObject.toJSONString(request),resp);
            ModifyAccountResponse response = JSONObject.parseObject(resp, ModifyAccountResponse.class);
            if(StringUtils.isNotBlank(response.getWsErrorMsg())){
                log.error("调用用户中心接口异常，modifyAccount 错误:{}", response.getWsErrorMsg());
                throw new Exception(response.getWsErrorMsg());
            }
            return response;
        }catch (Exception ex) {
            log.error("调用用户中心接口异常，modifyAccount 错误", ex);
            throw new BusinessException(ex.getMessage(), ResultEnum.USER_CENTER_EXCEPTION.getCode());
        }
    }

    /**
     * 查询绑定请求
     * @param wsQueryBondRequest
     * @return
     */
    public List<WSBond> queryBondRequest(WSQueryBondRequests wsQueryBondRequest) {
        try {
            QueryBondRequest request = new QueryBondRequest();
            request.setInfProductId(wsQueryBondRequest.getProductId());
            request.setInfPwd(infPwd);
            request.setRequestUUID(UUID.randomUUID().toString().replace("-", "").toLowerCase());
            request.setWSQueryBondRequests(wsQueryBondRequest);
            String url = getUrl() + "/customer/bind/queryPhoneOREmail";
            String resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            log.info("请求用户中心-queryBondRequest，url:{},入参：{}，响应：{}",url,JSONObject.toJSONString(request),resp);
            QueryBondResponse response = JSONObject.parseObject(resp, QueryBondResponse.class);
            return response.getWSBond();
        } catch (Exception ex) {
            log.error("调用用户中心接口异常，queryBondRequest 错误", ex);
            throw ex;
        }
    }

    /**
     * 银行卡查询
     *
     * @param customersBank 邮箱绑定
     * @return response
     */
    public List<WSCustomersBank> getFoundDetail(WSQueryCustomersBank customersBank) {
        QueryCustomersBankRequest request = new QueryCustomersBankRequest();
        request.setInfProductId(customersBank.getProductId());
        request.setInfPwd(infPwd);
        String requestUUID = CommonUtil.genRequestUUID();
        request.setRequestUUID(requestUUID);
        request.setWSQueryCustomersBank(customersBank);
        String url = getUrl() + "/customers/customerBank/query";
        String resp="";
        try {
            resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            log.info("请求用户中心-getFoundDetail，url:{},入参：{}，响应：{}",url,JSONObject.toJSONString(request),resp);
            QueryCustomersBankResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp,"UserCenter",  QueryCustomersBankResponse.class);
            if (response == null || response.getWSCustomersBank() == null) {
                throw new MKTIntegrationException(ResultEnum.ERROR_ACCOUNT_NOTEXIST);
            }
            return response.getWSCustomersBank();
        } catch (Exception ex) {
            log.error("调用用户中心接口异常：查询资金账户用户名：{},uuid:{}", customersBank.getLoginName(), requestUUID, ex);
            throw ThirdResponseHelper.businessException(ex,"调用用户中心接口异常：",ResultEnum.ERROR_ACCOUNT_NOTEXIST);
        }
    }

    /**
     * 创建银行卡(绑卡)
     *
     * @param bankInfo 银行卡信息
     * @return 添加结果
     */
    public WSResultObj updateCustomerBank(BankCardInfo bankInfo) {
        String resp="";
        try {
            UpdateCustomerBankCardRequest request = new UpdateCustomerBankCardRequest();
            request.setInfProductId(bankInfo.getProductId());
            request.setInfPwd(infPwd);
            request.setBankCardInfo(bankInfo);
            String url = getUrl() + "/customers/customerBank/modify";
            resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            log.info("/rest/request/bank_request/modify 调用UserCenter绑定银行卡，url:{},入参：{}，响应：{}", url, JSONObject.toJSONString(request), resp);
            UpdateCustomerBankCardResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "UserCenter", UpdateCustomerBankCardResponse.class);
            return response.getWSResultObj();
        } catch (Exception ex) {
            log.error("调用用户中心接口异常，updateCustomerBank错误：" + ex.getMessage(), ex);
            throw ThirdResponseHelper.businessException(ex,"调用用户中心接口异常，updateCustomerBank错误：",ResultEnum.ERROR_ACCOUNT_NOTEXIST);
        }
    }

}
