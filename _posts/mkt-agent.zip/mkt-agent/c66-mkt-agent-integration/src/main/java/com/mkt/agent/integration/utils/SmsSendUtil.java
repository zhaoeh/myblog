package com.mkt.agent.integration.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.nacos.shaded.com.google.gson.Gson;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.integration.config.SmsConfig;
import com.ws.SmsContent;
import com.ws.SmsContentRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.ThreadContext;
import org.slf4j.MDC;
import org.springframework.scheduling.concurrent.DefaultManagedAwareThreadFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 发送短信工具类，代码抄的ws调用短信平台sms-api
 */
@Component
@Slf4j
public class SmsSendUtil {

    /**
     * 60004 修改密码
     */
    public static final String UPDATE_PASSWORD_SMS_TYPE = "60004";

    /**
     * 修改取款密码
     */
    public static final String UPDATE_WITHDRAWAL_PASS_SMS_TYPE = "60018";

    /**
     * 验证码
     */
    public static final String SMS_VERDIFY_CODE = "60025";

    /**
     * 验证码-手机绑定
     */
    public static final String SMS_VERDIFY_CODE_1 = "60030";
    /**
     * 验证码-邮箱绑定
     */
    public static final String SMS_VERDIFY_CODE_2 = "60031";
    /**
     * 验证码-手机修改
     */
    public static final String SMS_VERDIFY_CODE_3 = "60032";
    /**
     * 验证码-邮箱修改
     */
    public static final String SMS_VERDIFY_CODE_4 = "60033";
    /**
     * 验证码-密码修改
     */
    public static final String SMS_VERDIFY_CODE_5 = "60034";
    /**
     * 验证码-帐号注册
     */
    public static final String SMS_VERDIFY_CODE_6 = "60035";
    /**
     * 验证码-资料修改
     */
    public static final String SMS_VERDIFY_CODE_7 = "60036";
    /**
     * 验证码-银行卡修改
     */
    public static final String SMS_VERDIFY_CODE_8 = "60037";
    /**
     * 验证码-找回密码
     */
    public static final String SMS_VERDIFY_CODE_9 = "60038";

    /**
     * 申请活动资格
     */
    public static final String SMS_VERDIFY_CODE_13 = "60039";

    /**
     * 语音验证  A04
     */
    public static final String SMS_VERDIFY_CODE_17 = "60057";

    static String className = SmsSendUtil.class.getName();

    /**
     * 四种拒绝策略：
     * 1.AbortPolicy=线程满了, 抛异常；
     * 2.CallerRunsPolicy=线程满了,使用主线程执行
     * 3.DiscardOldestPolicy=线程满了,直接终止执行
     * 4.DiscardPolicy=线程满了,直接拒绝处理
     */
    protected static final ThreadPoolExecutor execuctor;

    static {
        // 初始化线程池
        DefaultManagedAwareThreadFactory factory = new DefaultManagedAwareThreadFactory();
        factory.setThreadNamePrefix("SMS ThreadPoolExecutor");
        execuctor = new ThreadPoolExecutor(
                10, 30, 5000, TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<>(2048), factory, new ThreadPoolExecutor.AbortPolicy());
    }

    @PostConstruct
    public void init() {
    }


    /**
     * 发送短信api
     *
     * @param smsType 短信模板 使用模板时必须
     * @param productid productid 必须
     * @param loginname loginname 必须
     * @param mobileNo 手机号 必须
     * @param patams 参数
     * @param TemplateFlag 是否使用模板 1：不使用，0：使用
     * @param sendContent 短信内容(使用模板时为拼接参数：验证码/..  ；不使用模板时自定义内容)
     * @param customerLevel "1"
     * @param smsConfig sms配置(url和productKey)
     */
    public static void callSmsApi(String smsType, String productid, String loginname,
                                  String mobileNo, String[] patams, String TemplateFlag,
                                  String sendContent, String customerLevel, SmsConfig smsConfig) {
        String uuid = ThreadContext.get("ticket");
        String spanId = MDC.get("spanId");
        String traceId = MDC.get("traceId");
        execuctor.submit(() -> {
            ThreadContext.put("ticket", uuid);
            MDC.put("spanId", spanId);
            MDC.put("traceId", traceId);
            sendSms(smsType, productid, loginname, mobileNo, patams,
                    TemplateFlag, sendContent, customerLevel, null, smsConfig);
        });
    }


    public static String callSmsApiWithResult(String typecode, String productid, String loginname,
                                              String phone, String[] patams, String templateFlag,
                                              String sendContent, String customerLevel,
                                               String sendMethod, SmsConfig smsConfig) {
        return sendSms(typecode, productid, loginname, phone, patams,
                templateFlag, sendContent, customerLevel, sendMethod, smsConfig);
    }


    private static String sendSms(String smsType, String productid, String loginname, String phone, String[] patams,
                                  String templateFlag, String sendContent, String customerLevel,
                                  String sendMethod,  SmsConfig smsConfig) {
        try {
            String countryCode = "0063";
            log.info("Start sms utils");
            String productKey = smsConfig.getProductKey();// (0\!)1@@
            SmsContentRequest request = new SmsContentRequest();
            List<SmsContent> list = request.getSmsContents();
            SmsContent content = new SmsContent();
            // 必须，需要加密用到
            if (null == loginname || "".equals(loginname.trim())) {
                content.setLoginname("anonymous");
            } else {
                content.setLoginname(loginname);
            }
            content.setCountryCode(countryCode);
            content.setProductid(productid);
            content.setSmstype(smsType);
            content.setPhone(phone);
            content.setUseTemplateFlag(templateFlag);
            content.setCustomerLevel(customerLevel);
            content.setSendType("0"); // 短信类型
            String key = content.getLoginname() + productid + productKey + phone + smsType;
            String enkey = Convert.MD5Encode(key);
            content.setKey(enkey);
            if (null != patams) {
                if (patams.length == 1) {
                    content.setParam1(patams[0]);
                }
                if (patams.length == 2) {
                    content.setParam1(patams[0]);
                    content.setParam2(patams[1]);
                }
                if (patams.length == 3) {
                    content.setParam1(patams[0]);
                    content.setParam2(patams[1]);
                    content.setParam3(patams[2]);
                }
            }
            log.info("SMS 发送内容 产品：" + content.getProductid() + " 对象：" + content.getLoginname()
                    + " 内容：" + content.getParam1() + "," + content.getParam2() + "," + content.getParam3()
                    + ",smstype:" + content.getSmstype() + ",useTemplateFlag:" + content.getUseTemplateFlag() + ",key:"
                    + content.getKey() + ",customerLevel:" + content.getCustomerLevel());
            if (StringUtils.isNotEmpty(sendMethod)) {
                content.setSendMethod(sendMethod);
            }

            if (null != sendContent) {
                content.setSendcontent(sendContent);
            }
            list.add(content);
            String code = sendSms(list, smsConfig.getUrl());
            log.info("SMS 发送结果状态码,Code={}", code);
            return code;
        } catch (Exception ex) {
            log.error(className + " - " + productid + " call sms interface fail! msg:", ex);
            return "-999";
        }
    }


    /**
     * 调用短信平台接口
     *
     * @return String
     * @author sky.x
     */
    public static String sendSms(List<SmsContent> list, String url) {
        String code = "-999";
        try {
            if (CollectionUtils.isEmpty(list)) {
                log.info("SMS 发送内容list为空,不进行发送");
                return code;
            }

            //开关开启走Rest接口,关闭走soap接口
            String restURL = url + "/rest/sendSMS";
            JSONObject object = new JSONObject();
            object.put("smsContents", JSONArray.parse(new Gson().toJson(list)));
            log.info("SMS 发送短信请求数据: {}", object.toJSONString());
            Object resultStr = HttpClientUtil.postJson(restURL, object.toJSONString());
            if (resultStr != null) {
                log.info("SMS 发送短信返回数据: {}", resultStr);
                JSONObject jsonObject = JSONObject.parseObject(resultStr.toString());
                code = jsonObject.getString("body");
            }

            return code;
        } catch (Exception ex) {
            log.error(className + " call sms interface fail! msg", ex);
            return code;
        }
    }
}
