package com.mkt.agent.integration.entities.request;

import com.mkt.agent.common.annotation.DecryptField;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
@ApiModel
public class CreateWithdrawalReq extends BaseReq {
    @NotBlank(message = "bankAccountId can not be blank")
    @ApiModelProperty(required = true, value = "玩家银行账号Id<br/>Bank account ID")
    private String bankAccountId;

    @NotBlank(message = "amount can not be blank")
    @ApiModelProperty(required = true, value = "取款金额<br/>Withdrawal amount")
    private String amount;

    @NotBlank(message = "withdrawalPassword can not be blank")
    @ApiModelProperty(required = true, value = "取款密码，RSA加密<br/>Withdrawal password, RSA encrypt")
    @DecryptField
    private String withdrawalPassword;
}