package com.mkt.agent.integration.exception;

public class BizException extends RuntimeException {

    private String errCode;

    private Object body;
    
    private static final String ERROR_UNKNOWN_CODE = "GW_999999";
    private static final String ERROR_UNKNOWN_DESC = "系统繁忙, 请稍后再试";

    public BizException() {
        super(ERROR_UNKNOWN_DESC);
        this.errCode = ERROR_UNKNOWN_CODE;
    }
    
    public BizException(String message) {
        super(message);
    }
    
    public BizException(String errCode, String message) {
        super(message);
        this.errCode = errCode;
    }

    public BizException(String message, Throwable cause) {
        super(message, cause);
        this.errCode = ERROR_UNKNOWN_CODE;
    }

    public BizException(String errCode, String message, Throwable cause) {
        super(message, cause);
        this.errCode = errCode;
    }

    public String getErrCode() {
        return errCode;
    }

    public Object getBody() {
		return body;
	}

	public void setBody(Object body) {
		this.body = body;
	}

	@Override
	public String toString() {
		return "BizException [" + (errCode != null ? "errCode=" + errCode + ", " : "") + (body != null ? "body=" + body : "") + "]";
	}
}
