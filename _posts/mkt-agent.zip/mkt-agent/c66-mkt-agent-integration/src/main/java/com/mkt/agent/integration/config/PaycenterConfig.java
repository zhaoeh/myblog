package com.mkt.agent.integration.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@Data
@Component
@AllArgsConstructor
@NoArgsConstructor
@RefreshScope
public class PaycenterConfig {

    @Value("${C66.paycenter.defaultUrl}")
    private String payDefaultUrl;

    @Value("${C66.paycenter.paymentUrl}")
    private String paymentUrl;

    @Value("${C66.paycenter.payKey}")
    private String payKey;

    @Value("${C66.paycenter.amountList}")
    private String amountList;
}
