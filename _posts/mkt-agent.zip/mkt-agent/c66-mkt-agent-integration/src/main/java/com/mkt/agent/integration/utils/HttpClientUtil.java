package com.mkt.agent.integration.utils;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.*;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.config.RequestConfig.Builder;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeaderElementIterator;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StreamUtils;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.GeneralSecurityException;
import java.util.*;
import java.util.Map.Entry;
import java.util.function.Consumer;

/**
 * 依赖的jar包有：commons-lang-2.6.jar、httpclient-4.3.2.jar、httpcore-4.3.1.jar、commons
 * -io-2.4.jar
 *
 * @author tony
 *
 */
@Component
public class HttpClientUtil {

	private static final Logger logger = LoggerFactory.getLogger(HttpClientUtil.class);

	public static final int connTimeout = 600000;

	public static final int readTimeout = 600000;

	public static final int requestTimeout = 600000;

//	public static final int connTimeout = 15000;
//
//	public static final int readTimeout = 60000;
//
//	public static final int requestTimeout = 15000;

	public static final String charset = "UTF-8";

	// 注意不能使用final ，给底层对该client进行增强提供便利
	private static HttpClient client;

	private static final String mimeType = "application/x-www-form-urlencoded";

	private static final String contentType = "application/json";

	static {
		PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager();
		cm.setMaxTotal(1024);
		cm.setDefaultMaxPerRoute(512);
		cm.setValidateAfterInactivity(120000);
		ConnectionKeepAliveStrategy myStrategy = (response, context) -> {
			HeaderElementIterator it = new BasicHeaderElementIterator (response.headerIterator(HTTP.CONN_KEEP_ALIVE));
			while (it.hasNext()) {
				HeaderElement he = it.nextElement();
				String param = he.getName();
				String value = he.getValue();
				if (value != null && param.equalsIgnoreCase("timeout")) {
					return Long.parseLong(value) * 1000;
				}
			}
			return 60 * 1000;//如果没有约定，则默认定义时长为60s
		};

		client = HttpClients.custom()
				.setConnectionManager(cm)
				.setKeepAliveStrategy(myStrategy)
				.build();
	}

	// 只在开发环境打印日志
	private static final Consumer<String> printResult = result -> {
		if (logger.isDebugEnabled()) {
			logger.info("result:{}", result);
		}
	};

	public static String postParameters(String url, String parameterStr) throws Exception {
		return post(url, parameterStr, "application/x-www-form-urlencoded", charset, connTimeout, readTimeout);
	}

	public static String postParameters2(String url, String parameterStr) throws Exception {
		return post(url, parameterStr, "application/json", charset, connTimeout, readTimeout);
	}

	public static String postParameters(String url, String parameterStr, String charset, Integer connTimeout, Integer readTimeout) throws Exception {
		return post(url, parameterStr, "application/x-www-form-urlencoded", charset, connTimeout, readTimeout);
	}

	public static String postParameters(String url, Map<String, String> params) throws Exception {
		return postForm(url, params, null, connTimeout, readTimeout);
	}

	public static String postParameters(String url, Map<String, String> params, Integer connTimeout, Integer readTimeout) throws Exception {
		return postForm(url, params, null, connTimeout, readTimeout);
	}

	public static String get(String url) throws Exception {
		return get(url, charset, null, null,null);
	}

	public  String getUnStatic(String url) throws Exception {
		return get(url, charset, null, null,null);
	}

	public static String get(String url, Integer connTimeout, Integer readTimeout,Integer requestTimeout) throws Exception {
		return get(url, charset, connTimeout, readTimeout,requestTimeout);
	}

	public static String get(String url, Map param) throws Exception {
		if (null != param && !param.isEmpty()) {
			StringBuilder sb = new StringBuilder();
			for (Object o : param.entrySet()) {
				Entry ety = (Entry) o;
				sb.append("&").append(ety.getKey()).append("=").append(ety.getValue());
			}
			sb.deleteCharAt(0);
			if (url.indexOf("?") > 0)
				url = url + sb;
			else
				url = url + "?" + sb;
		}
		return get(url, charset, null, null,null);
	}

	public static String get(String url, String charset) throws Exception {
		return get(url, charset, connTimeout, readTimeout, requestTimeout);
	}

	/**
	 * 发送一个 Post 请求, 使用指定的字符集编码.
	 *
	 * @param url
	 * @param body
	 *            RequestBody
	 * @param mimeType
	 *            例如 application/xml "application/x-www-form-urlencoded"
	 *            a=1&b=2&c=3
	 * @param charset
	 *            编码
	 * @param connTimeout
	 *            建立链接超时时间,毫秒.
	 * @param readTimeout
	 *            响应超时时间,毫秒.
	 * @return ResponseBody, 使用指定的字符集编码.
	 * @throws ConnectTimeoutException
	 *             建立链接超时异常
	 * @throws SocketTimeoutException
	 *             响应超时
	 * @throws Exception
	 */
	public static String post(String url, String body, String mimeType, String charset, Integer connTimeout, Integer readTimeout) throws ConnectTimeoutException, SocketTimeoutException, Exception {
		HttpClient client = null;
		HttpPost post = new HttpPost(url);
		String result;
		try {
			if (StringUtils.isNotBlank(body)) {
				HttpEntity entity = new StringEntity(body, ContentType.create(mimeType, charset));
				post.setEntity(entity);
			}
			// 设置参数
			Builder customReqConf = RequestConfig.custom();
			if (connTimeout != null) {
				customReqConf.setConnectTimeout(connTimeout);
			}
			if (readTimeout != null) {
				customReqConf.setSocketTimeout(readTimeout);
			}
			post.setConfig(customReqConf.build());

			HttpResponse res;
			if (url.startsWith("https")) {
				// 执行 Https 请求.
				client = createSSLInsecureClient();
				res = client.execute(post);
			} else {
				// 执行 Http 请求.
				client = HttpClientUtil.client;
				res = client.execute(post);
			}
			result = EntityUtils.toString(res.getEntity(), charset);
			printResult.accept(result);
		} finally {
			post.releaseConnection();
			if (url.startsWith("https") && client instanceof CloseableHttpClient) {
				((CloseableHttpClient) client).close();
			}
		}
		return result;
	}

	/**
	 * 发送一个 Post 请求, 使用指定的字符集编码.
	 *
	 * @param url
	 * @param body
	 *            RequestBody
	 * @return ResponseBody, 使用指定的字符集编码.
	 * @throws ConnectTimeoutException
	 *             建立链接超时异常
	 * @throws SocketTimeoutException
	 *             响应超时
	 * @throws Exception
	 */
	public static String post(String url, String body) throws ConnectTimeoutException, SocketTimeoutException, Exception {
		HttpClient client = null;
		HttpPost post = new HttpPost(url);
		String result;
		try {
			if (StringUtils.isNotBlank(body)) {
				HttpEntity entity = new StringEntity(body, ContentType.create(mimeType, charset));
				post.setEntity(entity);
			}
			// 设置参数
			Builder customReqConf = RequestConfig.custom();
			customReqConf.setConnectTimeout(connTimeout);
			customReqConf.setSocketTimeout(readTimeout);
			post.setConfig(customReqConf.build());

			HttpResponse res;
			if (url.startsWith("https")) {
				// 执行 Https 请求.
				client = createSSLInsecureClient();
				res = client.execute(post);
			} else {
				// 执行 Http 请求.
				client = HttpClientUtil.client;
				res = client.execute(post);
			}
			result = EntityUtils.toString(res.getEntity(), charset);
			printResult.accept(result);
		} finally {
			post.releaseConnection();
			if (url.startsWith("https") && client instanceof CloseableHttpClient) {
				((CloseableHttpClient) client).close();
			}
		}
		return result;
	}



	public static String post(String url, Map param) throws Exception {
		HttpClient client = null;
		HttpPost post = new HttpPost(url);
		String result;
		try {
			if (null != param && !param.isEmpty()) {
				StringBuilder sb = new StringBuilder();
				for (Object o : param.entrySet()) {
					Entry ety = (Entry) o;
					sb.append("&").append(ety.getKey()).append("=").append(ety.getValue());
				}
				sb.deleteCharAt(0);
				HttpEntity entity = new StringEntity(sb.toString(), ContentType.create(mimeType, charset));
				post.setEntity(entity);
			}
			// 设置参数
			Builder customReqConf = RequestConfig.custom();
			customReqConf.setConnectTimeout(connTimeout);
			customReqConf.setSocketTimeout(readTimeout);
			post.setConfig(customReqConf.build());

			HttpResponse res;
			if (url.startsWith("https")) {
				// 执行 Https 请求.
				client = createSSLInsecureClient();
				res = client.execute(post);
			} else {
				// 执行 Http 请求.
				client = HttpClientUtil.client;
				res = client.execute(post);
			}
			result = EntityUtils.toString(res.getEntity(), charset);
			printResult.accept(result);
		} finally {
			post.releaseConnection();
			if (url.startsWith("https") && client instanceof CloseableHttpClient) {
				((CloseableHttpClient) client).close();
			}
		}
		return result;
	}

	public String postUnstatic(String url, String body, Map<String, String> headers) throws Exception {
		return post(url,body,headers);
	}
	public static String post(String url, String body, Map<String, String> headers) throws Exception {
		HttpClient client = null;
		HttpPost post = new HttpPost(url);
		String result;
		try {
			if (StringUtils.isNotBlank(body)) {
				HttpEntity entity = new StringEntity(body, ContentType.create(mimeType, charset));
				post.setEntity(entity);
			}
			// 设置参数
			Builder customReqConf = RequestConfig.custom();
			customReqConf.setConnectTimeout(connTimeout);
			customReqConf.setSocketTimeout(readTimeout);
			customReqConf.setConnectionRequestTimeout(connTimeout);
			post.setConfig(customReqConf.build());
			if (headers != null && !headers.isEmpty()) {
				for (Entry<String, String> entry : headers.entrySet()) {
					post.addHeader(entry.getKey(), entry.getValue());
				}
			}
			HttpResponse res;
			if (url.startsWith("https")) {
				// 执行 Https 请求.
				client = createSSLInsecureClient();
				res = client.execute(post);
			} else {
				// 执行 Http 请求.
				client = HttpClientUtil.client;
				res = client.execute(post);
			}

			result = EntityUtils.toString(res.getEntity(), charset);
			printResult.accept(result);
		} finally {
			post.releaseConnection();
			if (url.startsWith("https") && client instanceof CloseableHttpClient) {
				((CloseableHttpClient) client).close();
			}
		}
		return result;
	}



	/**
	 * 提交form表单
	 *
	 * @param url
	 * @param params
	 * @param connTimeout
	 * @param readTimeout
	 * @return
	 * @throws ConnectTimeoutException
	 * @throws SocketTimeoutException
	 * @throws Exception
	 */
	public static String postForm(String url, Map<String, String> params, Map<String, String> headers, Integer connTimeout, Integer readTimeout) throws ConnectTimeoutException, SocketTimeoutException, Exception {

		HttpClient client = null;
		HttpPost post = new HttpPost(url);
		try {
			if (params != null && !params.isEmpty()) {
				List<NameValuePair> formParams = new ArrayList<>();
				Set<Entry<String, String>> entrySet = params.entrySet();
				for (Entry<String, String> entry : entrySet) {
					formParams.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
				}
				UrlEncodedFormEntity entity = new UrlEncodedFormEntity(formParams, Consts.UTF_8);
				post.setEntity(entity);
			}

			if (headers != null && !headers.isEmpty()) {
				for (Entry<String, String> entry : headers.entrySet()) {
					post.addHeader(entry.getKey(), entry.getValue());
				}
			}
			// 设置参数
			Builder customReqConf = RequestConfig.custom();
			if (connTimeout != null) {
				customReqConf.setConnectTimeout(connTimeout);
			}
			if (readTimeout != null) {
				customReqConf.setSocketTimeout(readTimeout);
			}
			post.setConfig(customReqConf.build());
			HttpResponse res;
			if (url.startsWith("https")) {
				// 执行 Https 请求.
				client = createSSLInsecureClient();
				res = client.execute(post);
			} else {
				// 执行 Http 请求.
				client = HttpClientUtil.client;
				res = client.execute(post);
			}
			return EntityUtils.toString(res.getEntity(), charset);
		} finally {
			post.releaseConnection();
			if (url.startsWith("https") && client instanceof CloseableHttpClient) {
				((CloseableHttpClient) client).close();
			}
		}
	}

	/**
	 * 发送一个 GET 请求
	 *
	 * @param url
	 * @param charset
	 * @param connTimeout
	 *            建立链接超时时间,毫秒.
	 * @param readTimeout
	 *            响应超时时间,毫秒.
	 * @return
	 * @throws ConnectTimeoutException
	 *             建立链接超时
	 * @throws SocketTimeoutException
	 *             响应超时
	 * @throws Exception
	 */
	public static String get(String url, String charset, Integer connTimeout, Integer readTimeout,Integer requestTimeout) throws ConnectTimeoutException, SocketTimeoutException, Exception {

		HttpClient client = null;
		HttpGet get = new HttpGet(url);
		String result;
		try {
			// 设置参数
			Builder customReqConf = RequestConfig.custom();
			if(requestTimeout != null){
				customReqConf.setConnectionRequestTimeout(requestTimeout);
			}else{
				customReqConf.setConnectionRequestTimeout(HttpClientUtil.requestTimeout);
			}
			if (connTimeout != null) {
				customReqConf.setConnectTimeout(connTimeout);
			} else {
				customReqConf.setConnectTimeout(HttpClientUtil.connTimeout);
			}
			if (readTimeout != null) {
				customReqConf.setSocketTimeout(readTimeout);
			} else {
				customReqConf.setSocketTimeout(HttpClientUtil.readTimeout);
			}
			get.setConfig(customReqConf.build());

			HttpResponse res;

			if (url.startsWith("https")) {
				// 执行 Https 请求.
				client = createSSLInsecureClient();
				res = client.execute(get);
			} else {
				// 执行 Http 请求.
				client = HttpClientUtil.client;
				res = client.execute(get);
			}

			result = EntityUtils.toString(res.getEntity(), charset);
		} finally {
			get.releaseConnection();
			if (url.startsWith("https") && client instanceof CloseableHttpClient) {
				((CloseableHttpClient) client).close();
			}
		}
		return result;
	}



	public static ResponseEntity<String> redirect(HttpServletRequest request, HttpServletResponse response, String url) {
		try {
			RequestEntity requestEntity = createRequestEntity(request, url);
			return route(requestEntity);
		} catch (Exception e) {
			return new ResponseEntity("REDIRECT ERROR", org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private static RequestEntity createRequestEntity(HttpServletRequest request, String url) throws URISyntaxException, IOException {
		String method = request.getMethod();
		HttpMethod httpMethod = HttpMethod.resolve(method);
		MultiValueMap<String, String> headers = parseRequestHeader(request);
		byte[] body = parseRequestBody(request);
		return new RequestEntity<>(body, headers, httpMethod, new URI(url));
	}

	private static ResponseEntity<String> route(RequestEntity requestEntity) {
		RestTemplate restTemplate = new RestTemplate();
		return restTemplate.exchange(requestEntity, String.class);
	}


	private static byte[] parseRequestBody(HttpServletRequest request) throws IOException {
		InputStream inputStream = request.getInputStream();
		return StreamUtils.copyToByteArray(inputStream);
	}

	private static MultiValueMap<String, String> parseRequestHeader(HttpServletRequest request) {
		org.springframework.http.HttpHeaders headers = new org.springframework.http.HttpHeaders();
		List<String> headerNames = Collections.list(request.getHeaderNames());
		for (String headerName : headerNames) {
			List<String> headerValues = Collections.list(request.getHeaders(headerName));
			for (String headerValue : headerValues) {
				headers.add(headerName, headerValue);
			}
		}
		return headers;
	}

	/**
	 * 从 response 里获取 charset
	 *
	 * @param ressponse
	 * @return
	 */
	@SuppressWarnings("unused")
	private static String getCharsetFromResponse(HttpResponse ressponse) {
		// Content-Type:text/html; charset=GBK
		if (ressponse.getEntity() != null && ressponse.getEntity().getContentType() != null && ressponse.getEntity().getContentType().getValue() != null) {
			String contentType = ressponse.getEntity().getContentType().getValue();
			if (contentType.contains("charset=")) {
				return contentType.substring(contentType.indexOf("charset=") + 8);
			}
		}
		return null;
	}

	/**
	 * 创建 SSL连接
	 *
	 * @return
	 * @throws GeneralSecurityException
	 */
	private static CloseableHttpClient createSSLInsecureClient() throws GeneralSecurityException {
		SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, (chain, authType) -> true).build();
		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, (arg0, arg1) -> true);
		return HttpClients.custom().setSSLSocketFactory(sslsf).build();
	}

	public static String postJson(String url,String body){
		logger.info("http url:{}, httpClient params:{}", url, body);
		CloseableHttpClient client = null;
		String result = "";
		CloseableHttpResponse res = null;
		try {
			HttpPost post = new HttpPost(url);
			if (StringUtils.isNotBlank(body)) {
				HttpEntity entity = new StringEntity(body, ContentType.create(contentType, charset));
				post.setEntity(entity);
			}
			// 设置参数
			Builder customReqConf = RequestConfig.custom();
			customReqConf.setConnectTimeout(connTimeout);
			customReqConf.setConnectionRequestTimeout(requestTimeout);
			customReqConf.setSocketTimeout(readTimeout);
			post.setConfig(customReqConf.build());

			if (url.startsWith("https")) {
				// 执行 Https 请求.
				client = createSSLInsecureClient();
				res = client.execute(post);
			} else {
				// 执行 Http 请求.
				client = (CloseableHttpClient)HttpClientUtil.client;
				res = client.execute(post);
			}
			logger.info("CloseableHttpResponse res:{}", res);
			result = EntityUtils.toString(res.getEntity(), charset);
			logger.info("http response result:{}",result);
			printResult.accept(result);
		} catch (Exception e){
			logger.error("url: "+url +" ,请求失败",e);
		}
		logger.info("url: "+url +" ,请求响应：" + result);
		return result;
	}


	public static String postJson(String url,String body, Integer connTimeout, Integer requestTimeout, Integer readTimeout){
		CloseableHttpClient client = null;
		String result = "";
		CloseableHttpResponse res = null;
		try {
			HttpPost post = new HttpPost(url);
			if (StringUtils.isNotBlank(body)) {
				HttpEntity entity = new StringEntity(body, ContentType.create(contentType, charset));
				post.setEntity(entity);
			}
			// 设置参数
			Builder customReqConf = RequestConfig.custom();
			customReqConf.setConnectTimeout(connTimeout);
			customReqConf.setConnectionRequestTimeout(requestTimeout);
			customReqConf.setSocketTimeout(readTimeout);
			post.setConfig(customReqConf.build());


			if (url.startsWith("https")) {
				// 执行 Https 请求.
				client = createSSLInsecureClient();
				res = client.execute(post);
			} else {
				// 执行 Http 请求.
				client = (CloseableHttpClient)HttpClientUtil.client;
				res = client.execute(post);
			}
			result = EntityUtils.toString(res.getEntity(), charset);
			printResult.accept(result);
		} catch (Exception e){
			logger.error("url: "+url +" ,请求失败",e);
		}
		return result;
	}

}
