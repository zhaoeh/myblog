package com.mkt.agent.integration.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * @ClassName NetMaskUtil
 * @Author TJSAlex
 * @Date 2023/6/5 14:43
 * @Version 1.0
 **/
@Slf4j
public class NepMaskUtil {

    private static Pattern emailPattern = Pattern.compile("^(\\w)+(\\.\\w+)*@(\\w)+((\\.\\w+)+)$");

    private static Pattern numberPattern = Pattern.compile("^\\d+,\\d+$");

    /**
     * 脱敏处理要求的最小长度
     */
    private static final int maskLessLengthForMobile = 3;
    private static final int maskLessLengthForBank = 3;

    /**
     * 脱敏字符
     */
    private static final String hide = "****";


    /**
     * 通过配置的规则对银行卡进行掩码处理
     * @param productId
     * @param bankNo
     * @return
     */
    public static String maskBankNoByRule(String productId, String bankNo) {
//        String rule = ConfigVars.getValueWithBlank(productId, "MASK_RULE_BANK_NO");
        String rule = null;
        if (StringUtils.isBlank(rule)) {
            return MaskUtil.maskBankCardNo(Objects.isNull(bankNo) ? bankNo : bankNo.trim());
        }
        return maskByRule(bankNo, rule);
    }

    /**
     *  对明文按照规则做掩码处理
     * @param plainText
     * @param ruleStr
     * @return
     */
    private static String maskByRule(String plainText, String ruleStr) {
        if (StringUtils.isBlank(plainText)) {
            return "";
        }
        if(emailPattern.matcher(plainText).matches()){
            List<Integer> rule = Arrays.stream(ruleStr.split(",")).map(Integer::valueOf).collect(Collectors.toList());
            if (plainText.length() > rule.get(0) + rule.get(1)) {
                return  MaskUtil.mask(plainText, rule.get(0), plainText.indexOf("@")+rule.get(1));
            }
        }
        if (numberPattern.matcher(ruleStr).matches()){
            List<Integer> rule = Arrays.stream(ruleStr.split(",")).map(Integer::valueOf).collect(Collectors.toList());
            if (plainText.length() > rule.get(0) + rule.get(1)) {
                return MaskUtil.mask(plainText, rule.get(0), rule.get(1));
            }
        }  else {
            log.warn("掩码规则配置为:^\\d+,\\d+$,当前配置[{}]不正确", ruleStr);
        }
        return plainText;
    }

    /**
     * 通过配置的规则对用户名进行掩码处理
     * @param productId
     * @param loginName
     * @return
     */
    public static String maskLoginNameByRule(String productId, String loginName) {
//        String rule = ConfigVars.getValue(productId, "MASK_RULE_LOGINNAME");
        String rule = "";
        if (StringUtils.isBlank(rule)) {
            return loginName;
        }
        return maskByRule(loginName, rule);
    }
    public static String maskRealNameByRule(String productId, String realName) {
//        String rule = ConfigVars.getValueWithBlank(productId, "MASK_RULE_REAL_NAME");
        String rule = "";
        if (StringUtils.isBlank(rule)) {
            return MaskUtil.maskRealName(realName);
        }
        return maskByRule(realName, rule);
    }

    /**
     * @Description: 币付宝帐号掩码处理
     * @Author: Ziv.Y
     * @Date: 2020/4/25 11:54
     */
    public static String maskBitollNoByRule(String productId, String bitollNo) {
//        String rule = ConfigVars.getValueWithBlank(productId, "MASK_RULE_BITOLL_NO");
        String rule = "";
        if (StringUtils.isBlank(rule)) {
            return MaskUtil.maskBankCardNo(Objects.isNull(bitollNo) ? bitollNo : bitollNo.trim());
        }
        return maskByRule(bitollNo, rule);
    }

    public static String maskAlipayAccountByRule(String productId, String accountNo){
        String rule =null;
        if(emailPattern.matcher(accountNo).matches()){
//            rule = ConfigVars.getValueWithBlank(productId, "MASK_RULE_ALIPAY_EMAIL");
            if (StringUtils.isBlank(rule)) {
                return  MaskUtil.mask(accountNo, 1, accountNo.indexOf("@"));
            }else{
                List<Integer> rules = Arrays.stream(rule.split(",")).map(Integer::valueOf).collect(Collectors.toList());
                // 开头显示的位数
                int prefixLex = rules.get(0);
                // 结尾显示的位数
                int suffixLen = accountNo.length() - accountNo.indexOf("@") + rules.get(1);
                // 负数时，表示只显示结尾rules.get(1)位数；正数或0，表示显示@符号前rules.get(1)位数
                if(rules.get(1) < 0){
                    return  MaskUtil.mask(accountNo, prefixLex, Math.abs(rules.get(1)));
                }else if (accountNo.length() > prefixLex + suffixLen) {
                    return  MaskUtil.mask(accountNo, prefixLex, suffixLen);
                }else{
                    return  MaskUtil.mask(accountNo, prefixLex, accountNo.length() - accountNo.indexOf("@"));
                }
            }
        }else{
//            rule = ConfigVars.getValueWithBlank(productId, "MASK_RULE_ALIPAY_NUMBER");
            if (StringUtils.isBlank(rule)) {
                return MaskUtil.mask(accountNo, 1, 2);
            }else if(StringUtils.equals(rule, "#")){
                return MaskUtil.maskBankCardNo(accountNo.trim());
            }else{
                return maskByRule(accountNo, rule);
            }
        }
    }

    /**
     * only use for C66
     * @param s
     * @return
     */
    public static String maskMobileNoC66(String s) {
        if(StringUtils.isBlank(s)){
            return s;
        }
        if(s.length() <= maskLessLengthForMobile){
            return hide;
        }
        try {
            // 頭尾保留三位, 中間皆隱蔽
            String s1 = s.substring(0, 3);
            String s2 = s.substring(s.length() - 3);
            return s1 + hide + s2;
        } catch (Exception var4) {
            var4.printStackTrace();
            return null;
        }
    }

    /**
     * only use for C66
     * @param s
     * @return
     */
    public static String maskBankCardNoC66(String s) {
        if(StringUtils.isBlank(s)){
            return s;
        }
        if(s.length() <= maskLessLengthForBank){
            return hide;
        }
        try {
            // 頭尾保留四位, 中間皆隱蔽
            String s1 = s.substring(0, 4);
            String s2 = s.substring(s.length() - 4);
            String hide = " **** **** ";
            return s1 + hide + s2;
        } catch (Exception var4) {
            var4.printStackTrace();
            return null;
        }
    }
}
