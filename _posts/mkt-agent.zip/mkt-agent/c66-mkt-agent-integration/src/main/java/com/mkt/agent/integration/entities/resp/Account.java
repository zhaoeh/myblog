package com.mkt.agent.integration.entities.resp;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.List;

public class Account implements Serializable  {
    
	@ApiModelProperty(required = true, value = "会员银登录名")
    private String loginName;
    
	@ApiModelProperty(value = "账户编号")
    private String accountId;
    
    @ApiModelProperty(value = "银行账号名称/比特币钱包名称[掩码]", example = "**莲")
    private String accountName;
    
    @ApiModelProperty(required = true , value = "银行卡号/BTC账号地址[掩码]", example = "**** **** **** 1314")
    private String accountNo;
    
    @ApiModelProperty(required = true , value = "银行名称")
    private String bankName;

	@ApiModelProperty(value = "银行别名/钱包名称", example = "工商/我的钱包")
	private String bankAlias;
    
    @ApiModelProperty(value = "账号类型[借记卡/信用卡/存折/BTC]")
    private String accountType;
    
    @ApiModelProperty(value = "银行开户省份")
    private String province;
    
    @ApiModelProperty(value = "银行开户城市")
    private String city;
    
    @ApiModelProperty(value = "开户支行名称银行")
    private String bankBranchName;
    
    @ApiModelProperty(value = "账号状态，默认0或1，可返回所有状态（开关：MODIFY_BANK_REQUEST_FLAG_ALL）")
    private String flag;

	@ApiModelProperty(value = "银行代码")
	private String bankCode;
    
    @ApiModelProperty(value = "银行Icon")
    private String bankIcon;
    
    @ApiModelProperty(value = "银行背景图")
    private String backgroundColor;

	@ApiModelProperty(value = "是否为默认银行卡[true-是默认银行卡]", example = "true")
	private Boolean isDefault;

	@ApiModelProperty(value = "是否为默认钱包地址[1-是默认银行卡,其他不是]", example = "true")
	private String priorityOrder;

	@ApiModelProperty(value = "备注信息")
	private String remarks;

	@ApiModelProperty(value ="最后修改时间，无最后修改时间（待定，待审核等），则返回创建时间" )
	private String lastUpdate;

	@ApiModelProperty(value = "创建时间")
	private String createdDate;

	@ApiModelProperty(value = "账号绑定的对应协议,返回USDT钱包时此字段有值", example = "OMNI")
	private String protocol;

	@ApiModelProperty(value = "账号是否启用 0=禁用，1=启用，默认为1,如果网关禁止此类型取款，则为0")
	private String isOpen;

	@ApiModelProperty(value = "取款最小金额")
	private String minWithdraw;

	@ApiModelProperty(value = "取款最大金额")
	private String maxWithdraw;

    @ApiModelProperty(value = "账号类型[0:银行卡,1:比特币，3:USDT,4:MBTC,5:ETH,6:ALIPAY_A,7:ALIPAY_Q,8:BITOLL]", example = "1")
	private String catalog;

	public String getPriorityOrder() {
		return priorityOrder;
	}

	public void setPriorityOrder(String priorityOrder) {
		this.priorityOrder = priorityOrder;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getAccountName() { return accountName; }

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getBankBranchName() {
		return bankBranchName;
	}

	public void setBankBranchName(String bankBranchName) {
		this.bankBranchName = bankBranchName;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankIcon() {
		return bankIcon;
	}

	public void setBankIcon(String bankIcon) {
		this.bankIcon = bankIcon;
	}

	public String getBackgroundColor() {
		return backgroundColor;
	}

	public void setBackgroundColor(String backgroundColor) {
		this.backgroundColor = backgroundColor;
	}

	public Boolean getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(Boolean aDefault) {
		isDefault = aDefault;
	}

	public String getRemarks() { return remarks; }

	public void setRemarks(String remarks) { this.remarks = remarks; }

	public String getLastUpdate() { return lastUpdate; }

	public void setLastUpdate(String lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public String getBankAlias() {
		return bankAlias;
	}

	public void setBankAlias(String bankAlias) {
		this.bankAlias = bankAlias;
	}

	public Boolean getDefault() {
		return isDefault;
	}

	public void setDefault(Boolean aDefault) {
		isDefault = aDefault;
	}

	public String getCreatedDate() { return createdDate; }

	public void setCreatedDate(String createdDate) { this.createdDate = createdDate; }

	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public String getIsOpen() {
		return isOpen;
	}

	public void setIsOpen(String isOpen) {
		this.isOpen = isOpen;
	}

	public String getMinWithdraw() {
		return minWithdraw;
	}

	public void setMinWithdraw(String minWithdraw) {
		this.minWithdraw = minWithdraw;
	}

	public String getMaxWithdraw() {
		return maxWithdraw;
	}

	public void setMaxWithdraw(String maxWithdraw) {
		this.maxWithdraw = maxWithdraw;
	}

    public String getCatalog() {
        return catalog;
    }

    public void setCatalog(String catalog) {
        this.catalog = catalog;
    }

	@Override
	public String toString() {
		return "Account{" +
				"loginName='" + loginName + '\'' +
				", accountId='" + accountId + '\'' +
				", accountName='" + accountName + '\'' +
				", accountNo='" + accountNo + '\'' +
				", bankName='" + bankName + '\'' +
				", bankAlias='" + bankAlias + '\'' +
				", accountType='" + accountType + '\'' +
				", province='" + province + '\'' +
				", city='" + city + '\'' +
				", bankBranchName='" + bankBranchName + '\'' +
				", flag='" + flag + '\'' +
				", bankCode='" + bankCode + '\'' +
				", bankIcon='" + bankIcon + '\'' +
				", backgroundColor='" + backgroundColor + '\'' +
				", isDefault=" + isDefault +
				", priorityOrder='" + priorityOrder + '\'' +
				", remarks='" + remarks + '\'' +
				", lastUpdate='" + lastUpdate + '\'' +
				", createdDate='" + createdDate + '\'' +
				", protocol='" + protocol + '\'' +
				", isOpen='" + isOpen + '\'' +
				", minWithdraw='" + minWithdraw + '\'' +
				", maxWithdraw='" + maxWithdraw + '\'' +
				", catalog='" + catalog + '\'' +
				'}';
	}
}
