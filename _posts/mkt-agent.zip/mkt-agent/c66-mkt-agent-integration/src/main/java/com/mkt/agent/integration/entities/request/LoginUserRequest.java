package com.mkt.agent.integration.entities.request;

import com.mkt.agent.common.annotation.DecryptField;
import com.mkt.agent.common.enums.CustomizedValidationContents;
import com.mkt.agent.common.valid.EnumValid;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "用户登录(代理前台)")
public class LoginUserRequest {

    @ApiModelProperty(value = "产品编号[必填]", example = "C66",hidden = true)
    private String productId;

    @ApiModelProperty(value = "登录名/登录手机号码/登录邮箱", required = true ,example = "ivan01", position = 1)
    @NotEmpty(message = "Login name cannot be empty")
    @DecryptField
    private String loginName;

    @ApiModelProperty(required = true, value = "会员登录密码",example = "1234qwer1")
    @NotEmpty(message = "ERROR_PWD_EMPTY")
    @DecryptField
    private String password;

    @ApiModelProperty(value = "siteId 1:Bingoplus  2:Arenaplus  3:Gameplus")
    @EnumValid(contents = CustomizedValidationContents.site_id_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class} )
    private Integer siteId;

    @ApiModelProperty(hidden = true, required = false, value = "请求域名[app必填, web端不传]", example = "www.hygame03.com")
    private String domainName;

    @ApiModelProperty(hidden = true, required = false, value = "IP地址[不传]", example = "127.0.0.1")
    private String ipAddress;

}
