package com.mkt.agent.integration.template;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.JsonUtil;
import com.mkt.agent.integration.exception.MKTIntegrationException;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

@AllArgsConstructor
@NoArgsConstructor
@Component
public class ApiTemplate {

    private String uri;


    protected <T> T getResponse(String json, Class<T> clazz) {
        return JsonUtil.toObject(json, clazz);
    }

    protected String getUrl(String path) {
        return uri + path;
    }

    protected String getUrl() {
        return uri;
    }

    protected JsonNode parseJsonNode(String json) {
        try {
            return JsonUtil.JSON_MAPPER.readTree(json);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    protected <T> List<T> parseList(String json, Class<T> tClass) {
        return JsonUtil.toList(json, tClass);
    }

    protected <T> T parseObject(String json, Class<T> tClass) {
        return JsonUtil.toObject(json, tClass);
    }


    protected JsonNode responseAccess(String result) {

        JsonNode jsonNode = parseJsonNode(result);
        JsonNode jsonNodeData = jsonNode.get(BaseConstants.DATA);
        if (Objects.nonNull(jsonNodeData)) {
            return jsonNodeData;
        }

        Integer status = Integer.valueOf(String.valueOf(jsonNode.get(BaseConstants.STATUS)));
        if (Objects.equals(ResultEnum.NOT_EXIST.getCode(), status)) {
            throw new MKTIntegrationException(ResultEnum.NOT_EXIST);
        }
        if (Objects.equals(ResultEnum.FAIL.getCode(), status)) {
            throw new MKTIntegrationException(ResultEnum.FAIL);
        }
        if (Objects.equals(ResultEnum.BAD_REQUEST.getCode(), status)) {
            throw new MKTIntegrationException(ResultEnum.BAD_REQUEST);
        }
        if (Objects.equals(ResultEnum.FORBIDDEN.getCode(), status)) {
            throw new MKTIntegrationException(ResultEnum.FORBIDDEN);
        }
        if (Objects.equals(ResultEnum.UNAUTHORIZED.getCode(), status)) {
            throw new MKTIntegrationException(ResultEnum.UNAUTHORIZED);
        }

        return jsonNode;

    }

}
