package com.mkt.agent.integration.template;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cn.schema.customers.WSCustomers;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.helper.ThirdResponseOfNoRulesHelper;
import com.mkt.agent.integration.entities.Response;
import com.mkt.agent.integration.entities.request.BaseReq;
import com.mkt.agent.integration.entities.resp.BtcRateRsp;
import com.mkt.agent.integration.utils.HttpClientUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * @ClassName FundTemplate
 * @Author TJSAlex
 * @Date 2023/6/1 16:21
 * @Version 1.0
 **/
@Slf4j
public class FundTemplate extends ApiTemplate{

    public FundTemplate(String uri) {
        super(uri);
    }

    public Response<JSONObject> allPayTypes(WSCustomers wsCustomer, BaseReq baseReq, String sourceCurrency,String payKey) throws Exception {
        Response<JSONObject> resp = new Response<>();
        Map<String, Object> xp = new HashMap<>();
        xp.put("loginname", wsCustomer.getLoginName());
        xp.put("product", wsCustomer.getProductId());
        xp.put("grade", wsCustomer.getDepositLevel());
        xp.put("cuslevel", wsCustomer.getCustomerLevel());
        String currency = wsCustomer.getCurrency();
        if (StringUtils.isNotBlank(sourceCurrency)) {
            currency = sourceCurrency;
        }
        xp.put("currency", currency);
        xp.put("requestid", baseReq.getQid());
//        String key = DigestUtils.md5Hex(wsCustomer.getLoginName() + wsCustomer.getProductId() + currency + ConfigVars.getProductConfig(wsCustomer.getProductId()).getPayKey());
        String key = DigestUtils.md5Hex(wsCustomer.getLoginName() + wsCustomer.getProductId() + currency + payKey);
        xp.put("keycode", key);
        String url = getUrl() + "/findAgentAllPayTypes.do";
        log.info("request paycenter-api sys url findAgentAllPayTypes.do body {} url：{}", xp, url);
        String s = HttpClientUtil.post(url, xp);
        JSONObject data = ThirdResponseOfNoRulesHelper.pullDataOfFindAgentAllPayTypes(s, url, wsCustomer.getLoginName(), JSONObject.class);
        resp.setBody(data);
        return resp;
    }

    public Result<JSONObject> onlinePaymentSecondInternal(WSCustomers wsCustomer, BaseReq baseReq,
                                                          BigDecimal amount, String bankNo, String payid,
                                                          String paymentMethod, Integer paySource, String handleAmount,
                                                          Integer payType, String sourceCurrency, String usdtProtocol,
                                                          String transferPlatform,String paymentUrl,String payKey) throws Exception {

        Map<String, String> xp = new HashMap<>();
        xp.put("newaccount", "0");
        xp.put("product", wsCustomer.getProductId());
        xp.put("amount", amount.toPlainString());
        xp.put("loginname", wsCustomer.getLoginName());
        xp.put("backurl", paymentUrl); //第三方下单url
        xp.put("grade", wsCustomer.getDepositLevel());
        xp.put("priorityLevel", wsCustomer.getPriorityLevel());
        String currency = wsCustomer.getCurrency();
        if (StringUtils.isNotBlank(sourceCurrency)) {
            currency = sourceCurrency;
        }
        xp.put("currency", currency);
        xp.put("remark", "支付请求");
        xp.put("bankCode", bankNo);
        xp.put("siteId", wsCustomer.getSiteId()+"");
        xp.put("payId", payid);

        if (StringUtils.isNotBlank(paymentMethod)) {
            xp.put("paymentmethod", paymentMethod);
            //兼容新资金系统
            xp.put("payWay", paymentMethod);
        }

        xp.put("ip", baseReq.getIpAddress());
        xp.put("cuslevel", wsCustomer.getCustomerLevel());
        String key="";
//        key = DigestUtils.md5Hex(wsCustomer.getLoginName() + wsCustomer.getProductId() + amount.toPlainString() + wsCustomer.getDepositLevel() + ConfigVars.getProductConfig(wsCustomer.getProductId()).getPayKey());
        key = DigestUtils.md5Hex(wsCustomer.getLoginName() + wsCustomer.getProductId() + amount.toPlainString() + wsCustomer.getDepositLevel() + payKey);
        xp.put("keycode", key);
//        xp.put("endPoint", ConfigVars.getWsEndPointType(baseReq).toString());
        xp.put("endPoint", "9");
        xp.put("requestdomain", baseReq.getDomainName());
        xp.put("requestid", baseReq.getQid());
        xp.put("paySource", String.valueOf(paySource));
        if (StringUtils.isNotBlank(handleAmount)) {
            xp.put("handleAmount", handleAmount);
        }

        if (payType != null) {
            xp.put("type", payType.toString());
        }
        if (StringUtils.isNotBlank(usdtProtocol)) {
            xp.put("usdtProtocol", usdtProtocol);
        }

        if (StringUtils.isNotBlank(transferPlatform)) {
            xp.put("transferPlatform", transferPlatform);
        }
        if (StringUtils.isNotBlank(wsCustomer.getCurrency())) {
            xp.put("targetCurrency", wsCustomer.getCurrency());
        }

        String url = getUrl() + "/OnlineAgentPaymentSecondEx.do";
        log.info("request paycenter-api sys url OnlineAgentPaymentSecondEx.do body {}",xp);
        String s = HttpClientUtil.post(url, xp);
        log.info("{}调用onlinePaymentSecondInternal支付系统返回结果:{}", wsCustomer.getLoginName(), s);

        Response<JSONObject> r2 = this.parseObject(s);
        if (!r2.success()) {
            return Result.fail();
        }
        JSONObject obj = r2.getBody();
        Integer status = obj.getInteger("status");
        /*if (4 == status) {
            return  Result.fail();
        } else if (0 != status) {
            log.error("{}调用onlinePaymentSecondInternal返回status:{}", wsCustomer.getLoginName(), status);
//            resp.setHead(ConstantVars.CODE_PREFIX_PAY + status, obj.getString("message"));
            return Result.fail();
        }*/
        if (0 != status) {
            log.error("{}调用onlinePaymentSecondInternal返回status:{}", wsCustomer.getLoginName(), status);
            return Result.fail();
        }
        return Result.success(obj);
    }

    public Response<JSONObject> queryPayTypes(WSCustomers wsCustomer, BaseReq baseReq, String payKey) throws Exception {
        Response<JSONObject> resp = new Response<>();
        Map<String, Object> xp = new HashMap<>();
        xp.put("loginname", wsCustomer.getLoginName());
        xp.put("product", wsCustomer.getProductId());
        xp.put("requestid", baseReq.getQid());

        String key = DigestUtils.md5Hex(wsCustomer.getLoginName() + wsCustomer.getProductId() + payKey);
        xp.put("keycode", key);
        String url = getUrl() + "/findPayTypes.do";
        String s = HttpClientUtil.post(url, xp);

        log.info("{}调用支付系统接口findPayTypes返回:{}", wsCustomer.getLoginName(), s);
        if (StringUtils.isBlank(s)) {
            resp.getHead().setErrCode(ResultEnum.OUT_SYSTEM_ERROR.getCode()+"");
            resp.getHead().setErrMsg(ResultEnum.OUT_SYSTEM_ERROR.getMessage());
            return resp;
        }

        resp = this.parseObject(s);
        if (!resp.success()) {
            resp.getHead().setErrCode("400");
            return resp;
        }
        com.alibaba.fastjson.JSONObject obj = resp.getBody();
        Integer status = obj.getInteger("status");
        if (0 != status) {
            log.error("{}调用findPayTypes支付系统status:{}", wsCustomer.getLoginName(), status);
            resp.getHead().setErrCode("400");
            resp.getHead().setErrMsg(obj.getString("message"));
            return resp;
        }
        resp.setBody(obj);
        return resp;
    }


    private Response<JSONObject> parseObject(String x) {
        Response<JSONObject> resp = new Response<>();
        try {
            resp.setBody(JSON.parseObject(x));
            return resp;
        } catch (Exception ex) {
            log.error("解析支付系统报文失败:{}", ex.getMessage(), ex);
            resp.setHead("1111","解析支付系统报文失败: "+ex.getMessage());
        }
        return resp;
    }

    /*public Response<JSONObject> queryAlipayWithdrawSwitch(BaseReq baseReq) {
        Response<JSONObject> resp = new Response<>();
        Map<String, String> xp = new HashMap<>(2);
        xp.put("productId", baseReq.getProductId());
        String sign = "";
//        String sign = DigestUtils.md5Hex(baseReq.getProductId() + ConfigVars.getProductConfig(baseReq.getProductId()).getPayKey());
        xp.put("sign", sign);

        String s = null;
        try {
            s = HttpClientUtil.post(getUrl(), xp);
            log.info("{}获取支付系统queryAlipayWithdrawSwitch返回信息:{}", baseReq.getLoginName(), s);
        } catch (Exception e) {
            log.error("queryAlipayWithdrawSwitch请求异常:{}", e.getMessage(), e);
//            throw new BizException(ErrorCode.ErrKey.ERROR_PAY_FAILED.getErrHead().getErrCode(), ErrorCode.ErrKey.ERROR_PAY_FAILED.getErrHead().getErrMsg());
        }

        if (StringUtils.isBlank(s)) {
//            throw new BizException(ErrorCode.ErrKey.ERROR_PAY_EMPTY.getErrHead().getErrCode(), ErrorCode.ErrKey.ERROR_PAY_EMPTY.getErrHead().getErrMsg());
        }
        Response<JSONObject> jsonObject = this.parseObject(s);
        if (!jsonObject.success()) {
            resp.setHead(jsonObject.getHead());
            return resp;
        }
        JSONObject head = jsonObject.getBody().getJSONObject("head");
        if (!StringUtils.equals("0000", head.getString("code"))) {
            log.error("{}调用支付系统查询支付宝开关失败:{}", baseReq.getLoginName(), head.getString("message"));
//            throw new BizException(ErrorCode.ErrKey.ERROR_PAY_FAILED.getErrHead().getErrCode(), ErrorCode.ErrKey.ERROR_PAY_FAILED.getErrHead().getErrMsg());
        }

        JSONObject obj = jsonObject.getBody();
        resp.setBody(obj);
        return resp;
    }*/

    public Result<BtcRateRsp> getBtcRate(WSCustomers wsCustomer, BigDecimal amount, BaseReq baseReq, String querytype) {
        Response<BtcRateRsp> resp = new Response<>();
        try {
            BtcRateRsp r9 = new BtcRateRsp();
            Result<JSONObject> r2 = this.btcRateCheck(wsCustomer, baseReq, amount, querytype);
            if (!r2.isSuccess()) {
//                resp.setHead(r2.getHead());
                return Result.fail(r2.getMessage());
            }
            JSONObject obj = r2.getData();
            r9.setBtcAmount(new BigDecimal(obj.getString("btcamount")));
            r9.setBtcUuid(obj.getString("uuid"));
            r9.setBtcRate(new BigDecimal(obj.getString("btcrate")));
            r9.setCurrency(obj.getString("currency"));
            r9.setAmount(new BigDecimal(obj.getString("amount")));
            r9.setBtcCurrency(obj.getString("btccurrency"));
            r9.setPayid(obj.getString("payid"));
            resp.setBody(r9);
            return Result.success(r9);
        } catch (Exception ex) {
            log.error("调用在线支付系统异常:", ex);
//            resp.setHead(ErrorCode.ErrKey.ERROR_PAY_FAILED.getErrHead());
            return Result.fail();
        }
    }

    public Result<JSONObject> btcRateCheck(WSCustomers wsCustomer, BaseReq baseReq, BigDecimal amount, String querytype) throws Exception {
        Map<String, Object> xp = new HashMap<>();
        xp.put("product", wsCustomer.getProductId());
        xp.put("loginname", wsCustomer.getLoginName());
        xp.put("currency", wsCustomer.getCurrency());
        xp.put("amount", amount);
        xp.put("grade", wsCustomer.getDepositLevel());
        xp.put("cuslevel", wsCustomer.getCustomerLevel());
//        xp.put("endpoint", ConfigVars.getWsEndPointType(baseReq).toString());
        xp.put("querytype", querytype);
        String key = DigestUtils.md5Hex(wsCustomer.getLoginName() + wsCustomer.getProductId() + wsCustomer.getDepositLevel() + amount);
        xp.put("keycode", key);
        String s = HttpClientUtil.post(getUrl(), xp);
        log.info("{}调用btcRateCheck支付系统返回结果:{}", wsCustomer.getLoginName(), s);
        if (StringUtils.isBlank(s)) {
//            resp.setHead(ErrorCode.ErrKey.ERROR_PAY_EMPTY.getErrHead());
            return Result.fail();
        }
        Response<JSONObject> r2 = this.parseObject(s);
        if (!r2.success()) {
//            resp.setHead(r2.getHead());
            return Result.fail(r2);
        }
        JSONObject obj = r2.getBody();
        Integer status = obj.getInteger("status");
        if (0 != status) {
            log.error("{}调用btcRateCheck支付系统返回status:{}", wsCustomer.getLoginName(), status);
//            resp.setHead(ErrorCode.ErrKey.ERROR_PAY_INFO.getErrHead());
            return Result.fail();
        }
//        resp.setBody(obj);
        return Result.success(obj);
    }



}
