package com.mkt.agent.integration.template;


import com.alibaba.fastjson.JSONObject;
import com.cn.schema.agent.SaveAgentTransRequest;
import com.cn.schema.agent.SaveAgentTransResponse;
import com.cn.schema.agent.WSAgentTrans;
import com.cn.schema.creditlogs.CreateCreditLogsForCommToCreditRequest;
import com.cn.schema.creditlogs.CreateCreditLogsForCommToCreditResponse;
import com.cn.schema.creditlogs.WSCreditLogs;
import com.cn.schema.customers.*;
import com.cn.schema.other.*;
import com.cn.schema.request.WSResultObj;
import com.cn.schema.request.*;
import com.cn.schema.urf.*;
import com.google.common.collect.Lists;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.helper.ThirdResponseHelper;
import com.mkt.agent.common.utils.CommonUtil;
import com.mkt.agent.integration.config.WSConfig;
import com.mkt.agent.integration.entities.ws.InterWSCustomers;
import com.mkt.agent.integration.enums.SearchTypeEnum;
import com.mkt.agent.integration.exception.MKTIntegrationException;
import com.mkt.agent.integration.service.WsRestInter;
import com.mkt.agent.integration.utils.HttpClientUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * 调用ws 接口封装
 */
@Slf4j
@Component
public class WsTemplate extends ApiTemplate{

    private String infPwd;

    private WsRestInter wsRestInter;

    public WsTemplate() {
        super();
    }

    @Autowired
    public WsTemplate(WSConfig wsConfig){
        super(wsConfig.getWsDefaultUrl());
        this.infPwd = wsConfig.getPwd();
    }

    public WsTemplate(String url) {
        super(url);
        log.info("ws api uri:{}",url);
    }

    public WsTemplate(String url,WsRestInter wsRestInter) {
        super(url);
        this.wsRestInter=wsRestInter;
    }

    public WsTemplate(String uri, String infPwd) {
        super(uri);
        this.infPwd = infPwd;
    }

    private String encryptedPasswordOf(String plainPwd, String loginName) {
        return DigestUtils.md5Hex(plainPwd + "{" + loginName + "}");
    }


    private static final String WS_RESPONSE_SUCCESS = "SUCCESS";

    /**
     * ws t_customers及t_branch表关联查询，会返回密文敏感信息
     *
     * @param productId 产品id
     * @param loginName 登录名
     * @return response 用户信息
     */
    public WSCustomers getSimpleCustomer(String productId, String loginName) {
        QueryCustomersBasicByLoginNameRequestV3 request = new QueryCustomersBasicByLoginNameRequestV3();
        request.setInfProductId(productId);
        request.setInfPwd(infPwd);
        String requestUUID = CommonUtil.genRequestUUID();
        request.setRequestUUID(requestUUID);
        request.setLoginName(loginName);
        String url = getUrl() + "/rest/customers/query_basic_by_login_nameV3";
        String resp="";
        try {
            resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            log.info("getSimpleCustomer call ws result:{}",resp);
            QueryCustomersBasicByLoginNameResponseV3 response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "WS", QueryCustomersBasicByLoginNameResponseV3.class);
            if (ObjectUtils.isEmpty(response) || ObjectUtils.isEmpty(response.getWsCustomer())) {
                throw new MKTIntegrationException(ResultEnum.GET_CUSTOMER_FAIL);
            }
            return response.getWsCustomer();
        } catch (Exception ex) {
            log.error("WS接口调用异常：查询用户用户名：{},uuid:{}", loginName, requestUUID, ex);
            String errorMessage = parseWSError(resp);
            throw ThirdResponseHelper.businessException(ex,"调用WS接口异常：",ResultEnum.WS_EXCEPTION);
        }
    }

    /**
     * ws登录接口调用
     *
     * @param wsCustomer  登录request
     * @param flag        flag
     * @param loginMethod loginMethod
     * @return response
     */
    public WSCustomers loginByLoginName(WSCustomers wsCustomer, String flag, String loginMethod) {
        LoginWebRequest request = new LoginWebRequest();
        request.setInfProductId(wsCustomer.getProductId());
        request.setInfPwd(infPwd);
        request.setInfFlag(Objects.requireNonNullElse(flag, "0"));
        request.setLoginMethod(loginMethod);
        request.setWSCustomers(wsCustomer);
        String requestUUID = CommonUtil.genRequestUUID();
        request.setRequestUUID(requestUUID);
        String url = getUrl() + "/rest/customer/login_web";
        String resp="";
        try {
            log.info("ws接口loginByLoginName:{}", JSONObject.toJSONString(request));
            resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            log.info("ws登录接口/rest/customer/login_web 返回值：{}", resp);
            LoginWebResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "WS", LoginWebResponse.class);
            if(Objects.isNull(response)||Objects.isNull(response.getWSCustomers())){
                log.info("ws登录接口/rest/customer/login_web返回为null");
                throw new BusinessException(ResultEnum.SYSTEM_BUSY);
            }
            log.info("loginByLoginName登录名：{} wsCustomer:{},loginMethod:{},flag:{},uuid:{}", wsCustomer.getLoginName(),
                    response.getWSCustomers().getLoginName(), "loginMethod", "flag", request.getRequestUUID());
            return response.getWSCustomers();
        } catch (Exception ex) {
            log.error("WS接口调用异常：loginByLoginName登录名：{} ,loginMethod:{},flag:{},uuid:{}", wsCustomer.getLoginName(),
                    "loginMethod", "flag", requestUUID, ex);
            throw ThirdResponseHelper.businessException(ex, "调用WS接口异常：" + ResultEnum.USERNAME_OR_PASSWORD_ERROR.getMessage(), ResultEnum.USERNAME_OR_PASSWORD_ERROR.getCode());
        }
    }

    /**
     * 批量查询用户信息
     *
     * @param productId productId
     * @param keyType   搜索类型，1: loginName; 2: customerId; 3:phone(明文); 4:email; 5:nickName
     * @param keys 查询项
     * @return 用户信息
     */
    public List<WSCustomers> batchQueryCustomersV2(String productId, SearchTypeEnum keyType, List<String> keys) {
        try {
            BatchQueryCustomersRequest request = new BatchQueryCustomersRequest();
            request.setInfProductId(productId);
            request.setInfPwd(infPwd);
            request.setInfFlag(keyType.getSearchType());
            if (SearchTypeEnum.LOGIN_NAME.equals(keyType)) {
                request.setLoginNames(keys);
            } else if (SearchTypeEnum.CUSTOMER_ID.equals(keyType)) {
                request.setCustomerIds(keys);
            } else if (SearchTypeEnum.PHONE.equals(keyType)) {
                request.setPhones(keys);
            } else if (SearchTypeEnum.EMAIL.equals(keyType)) {
                request.setEmails(keys);
            } else if (SearchTypeEnum.NICK_NAME.equals(keyType)) {
                request.setNickNames(keys);
            }else {
                log.warn("无效查询主键类型[{}], 忽略..", keyType);
                return null;
            }
            String url = getUrl() + "/rest/customers/batch/batchQueryCustomersRequestV2";
            String resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            log.info("ws接口/rest/customers/batch/batchQueryCustomersRequestV2 返回值:{}",resp);
            BatchQueryCustomersResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "WS", BatchQueryCustomersResponse.class);
            if (org.apache.commons.collections.CollectionUtils.isEmpty(response.getWSCustomers())) {
                log.info("ws接口/rest/customers/batch/batchQueryCustomersRequestV2 返回值:{}",resp);
                return null;
            } else {
                return response.getWSCustomers();
            }
        } catch (Exception ex) {
            log.error("调用WS接口异常，BatchQueryCustomersResponse错误", ex);
            throw ThirdResponseHelper.businessException(ex,"调用WS接口异常：",ResultEnum.WS_EXCEPTION);
        }
    }

    public Result<CreateNewAccountResponse> createNewAccount(InterWSCustomers wsCustomers,String infFlag) {
        log.info("调用WS分支创建用户===");
        QueryBranchRequest queryBraches = new QueryBranchRequest();
        queryBraches.setInfProductId(wsCustomers.getProductId());
        if(StringUtils.isBlank(wsCustomers.getBranchCode())){
            List<WSBranch> branches = wsRestInter.queryBranches(queryBraches, wsCustomers.getProductId()).getData();
            WSBranch branch = branchElectionByDefault(branches);
            wsCustomers.setBranchCode(branch == null ? null : branch.getBranchCode());
        }
        CreateNewAccountResponse createNewAccountResponse=wsRestInter.createInterNewAccount(wsCustomers,getUrl(),infFlag);
        log.info("call ws to create new account response:{}",createNewAccountResponse);
        if(Objects.isNull(createNewAccountResponse)){
            return Result.fail("远程调用ws创建客户返回为null");
        } else if(null==createNewAccountResponse.getWSCustomers()){
            return Result.fail(createNewAccountResponse.getWsErrorMsg());
        }else {
            return Result.success(createNewAccountResponse);
        }
    }


    public Result<QueryCountCustomersResponse>  countCustomers(WSQueryCustomers wsQueryCustomers) {
        QueryCountCustomersResponse queryCountCustomersResponse=wsRestInter.countCustomers(wsQueryCustomers,getUrl());
        if(Objects.isNull(queryCountCustomersResponse)){
            return Result.fail("远程调用ws异常");
        } else {
            return Result.success(queryCountCustomersResponse);
        }
    }

    public Result<QueryCustomersResponse>  queryCustomersSingleTable(WSQueryCustomers wsQueryCustomers) {
        QueryCustomersResponse queryCustomersResponse=wsRestInter.queryCustomersSingleTable(wsQueryCustomers,getUrl());
        if(Objects.isNull(queryCustomersResponse)){
            return Result.fail("远程调用ws异常");
        } else {
            return Result.success(queryCustomersResponse);
        }
    }


    public Result<QueryCustomerDownlineResponse> queryAllPlayerByParentPage(WSQueryCustomerDownline wsQueryCustomerDownline) {
        QueryCustomerDownlineResponse queryCustomerDownlineResponse=wsRestInter.queryAllPlayerByParentPage(wsQueryCustomerDownline,getUrl());
        if(Objects.isNull(queryCustomerDownlineResponse)){
            return Result.fail("远程调用ws创建客户返回为null");
        }else{
            return Result.success(queryCustomerDownlineResponse);
        }
    }

    public Result<WSCustomers> getCustomer(WSQueryCustomers wsQueryCustomers) {
        QueryCustomersBasicResponse queryCustomersBasicResponse=wsRestInter.getCustomer(wsQueryCustomers,getUrl());
        if(Objects.isNull(queryCustomersBasicResponse)){
            return Result.success("远程调用ws创建客户返回为null");
        }else{
            List<WSCustomers> wsCustomers=queryCustomersBasicResponse.getWsCustomers();
            if(CollectionUtils.isEmpty(wsCustomers)){
                log.error("查无此人");
                return Result.fail();
            }
            return Result.success(wsCustomers.get(0));
        }
    }



    /**
     * 修改用户状态
     *
     * @param wsCustomer 用户参数
     * @param flag  0=web修改用户密码/1=web修改用户信息/3=修改用户状态/46=修改is_market/47=修改downline_arbit/48=downline_dis_xm/49=downline_promotion_dis/51=修改取款密码
     * @return response
     */
    public Boolean modifyAccount(WSCustomers wsCustomer, String flag) {
        ModifyAccountRequest request = new ModifyAccountRequest();
        request.setInfProductId(wsCustomer.getProductId());
        request.setInfPwd(infPwd);
        request.setInfFlag(flag);
        String requestUUID = CommonUtil.genRequestUUID();
        request.setRequestUUID(requestUUID);
        request.setWSCustomers(wsCustomer);
        String url = getUrl() + "/rest/customers/account/modify";
        String resp="";
        try {
            resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            ModifyAccountResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "WS", ModifyAccountResponse.class);
            if (ObjectUtils.isEmpty(response) || ObjectUtils.isEmpty(response.getWSCustomers())) {
                throw new MKTIntegrationException(response.getWsErrorMsg());
            }
            return true;
        } catch (Exception ex) {
            log.error("WS接口调用异常：修改用户状态用户名：{},uuid:{}", wsCustomer.getLoginName(), requestUUID, ex);
            throw ThirdResponseHelper.businessException(ex,"WS接口调用异常：",ResultEnum.WS_EXCEPTION);
        }
    }

    /**
     * ws邮箱/手机绑定接口
     *
     * @param wsBond 邮箱绑定
     * @return response
     */
    public Boolean bondCreate(WSBond wsBond) {
        CreateBondRequest request = new CreateBondRequest();
        request.setInfProductId(wsBond.getProductId());
        request.setInfPwd(infPwd);
        String requestUUID = CommonUtil.genRequestUUID();
        request.setRequestUUID(requestUUID);
        request.setWSBond(wsBond);
        String url = getUrl() + "/rest/request/bond/create";
        String resp="";
        log.info("WS接口调用绑定邮箱/手机名bondCreate: request={}",JSONObject.toJSONString(request));
        try {
            resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            log.info("WS接口调用绑定邮箱/手机名bondCreate: resp= {}",resp);
            CreateBondResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "WS", CreateBondResponse.class);
            return Optional.ofNullable(response).map(r -> parseWSResponse(r.getResult())).orElse(false);
        } catch (Exception ex) {
            log.error("WS接口调用异常bondCreate：绑定邮箱/手机名：{},uuid:{}", wsBond.getBondContext(), requestUUID, ex);
            throw ThirdResponseHelper.businessException(ex,"WS接口调用异常：",ResultEnum.WS_EXCEPTION);
        }
    }

    /**
     * 添加银行卡
     *
     * @param bankInfo 银行卡信息
     * @return 添加结果
     */
    public WSResultObj updateCustomerBank(BankCardInfo bankInfo) {
        String resp="";
        try {
            UpdateCustomerBankCardRequest request = new UpdateCustomerBankCardRequest();
            request.setInfProductId(bankInfo.getProductId());
            request.setInfPwd(infPwd);
            request.setBankCardInfo(bankInfo);
            String url = getUrl() + "/rest/request/bank_request/modify";
            resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            log.info("/rest/request/bank_request/modify 调用WS绑定银行卡信息返回结果：{}", JSONObject.toJSONString(resp));
            UpdateCustomerBankCardResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "WS", UpdateCustomerBankCardResponse.class);
            return response.getWSResultObj();
        } catch (Exception ex) {
            log.error("调用WS接口异常，UpdateCustomerBankCardResponse错误：" + ex.getMessage(), ex);
            throw ThirdResponseHelper.businessException(ex,"调用WS接口异常，UpdateCustomerBankCardResponse错误：",ResultEnum.WS_EXCEPTION);
        }
    }

    /**
     * ws查询资金账户详情
     *
     * @param customersBank 邮箱绑定
     * @return response
     */
    public List<WSCustomersBank> getFoundDetail(WSQueryCustomersBank customersBank) {
        QueryCustomersBankRequest request = new QueryCustomersBankRequest();
        request.setInfProductId(customersBank.getProductId());
        request.setInfPwd(infPwd);
        String requestUUID = CommonUtil.genRequestUUID();
        request.setRequestUUID(requestUUID);
        request.setWSQueryCustomersBank(customersBank);
        String url = getUrl() + "/rest/customers/customer_bank/query";
        String resp="";
        try {
            resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            QueryCustomersBankResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp,"WS",  QueryCustomersBankResponse.class);
            if (response == null || response.getWSCustomersBank() == null) {
                throw new MKTIntegrationException(ResultEnum.GET_FOUND_DETAIL_FAIL);
            }
            return ThirdResponseHelper.pullDataIfExistsDefaultError(resp,"WS",  QueryCustomersBankResponse.class).getWSCustomersBank();
        } catch (Exception ex) {
            log.error("WS接口调用异常：查询资金账户用户名：{},uuid:{}", customersBank.getLoginName(), requestUUID, ex);
            throw ThirdResponseHelper.businessException(ex,"WS接口调用异常：",ResultEnum.WS_EXCEPTION);
        }
    }

    /**
     * 解析ws接口response
     *
     * @param response ws返回的response
     * @return true:成功
     */
    private boolean parseWSResponse(String response) {
        if (StringUtils.isBlank(response)) {
            return false;
        }
        return response.startsWith(WS_RESPONSE_SUCCESS);
    }

    /**
     * 解析ws接口response
     *
     * @param response ws返回的response
     * @return true:成功
     */
    private String parseWSError(String response) {
        /*if (StringUtils.isBlank(response)) {
            return ResultEnum.OUT_SYSTEM_ERROR.getMessage();
        }
        String errMsg="";
        try {
            JSONObject object = JSONObject.parseObject(response);
            errMsg = (String)object.get("errMsg");
        } catch (Exception e){
            return ResultEnum.OUT_SYSTEM_ERROR.getMessage();
        }
        return errMsg;*/
        return ResultEnum.WS_EXCEPTION.getMessage();
    }

    public List<WSCustomersBank> queryCustomerBanks(WSQueryCustomersBank bank,String wsDefaultUri) {

        try {
            QueryCustomersBankRequest request = new QueryCustomersBankRequest();
            request.setInfProductId(bank.getProductId());
            request.setInfPwd(infPwd);
            request.setWSQueryCustomersBank(bank);
            String url =  wsDefaultUri + "/rest/customers/customer_bank/query";
            String resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            QueryCustomersBankResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp,"WS",  QueryCustomersBankResponse.class);
            return response.getWSCustomersBank();

        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryCustomersBankResponse错误", ex);
            throw ThirdResponseHelper.businessException(ex,"调用WS接口异常:",ResultEnum.WS_EXCEPTION);
        }

    }
    public List<WSWithdrawalRequests> queryWithdrawRequest(WSQueryWithdrawalRequests wsQueryWithdrawalRequest, String wsDefaultUri) {
        try {
            QueryWithdrawalRequestsRequest request = new QueryWithdrawalRequestsRequest();
            request.setInfProductId(wsQueryWithdrawalRequest.getProductId());
            request.setInfPwd(infPwd);
            request.setWSQueryWithdrawalRequests(wsQueryWithdrawalRequest);
            String url = wsDefaultUri + "/rest/request/query_withdrawal_requests";
            String resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            QueryWithdrawalRequestsResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp,"WS",  QueryWithdrawalRequestsResponse.class);
            return response.getWSWithdrawalRequests();
        } catch (Exception ex) {
            log.error("调用WS接口异常，queryWithdrawRequest错误", ex);
            throw ThirdResponseHelper.businessException(ex,"调用WS接口异常:",ResultEnum.WS_EXCEPTION);
        }

    }

    public WSQueryCountAmount queryWithdrawalCount(WSQueryWithdrawalRequests wSQueryWithdrawalRequests,WSCustomers customers) {
        try {
            QueryCountWithdrawalRequestsRequest request = new QueryCountWithdrawalRequestsRequest();
            request.setInfProductId(wSQueryWithdrawalRequests.getProductId());
            request.setInfPwd(customers.getPwd());
            request.setWSQueryWithdrawalRequests(wSQueryWithdrawalRequests);
//            String url = wsTemplate.getDefaultUri() + "/rest/request/query_count_withdrawal_requests";
            String resp = HttpClientUtil.postJson(getUrl(), JSONObject.toJSONString(request));
            QueryCountWithdrawalRequestsResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp,"WS",  QueryCountWithdrawalRequestsResponse.class);
            return response.getWSQueryCountAmount();
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryCountWithdrawalRequestsRequest", ex);
            throw ThirdResponseHelper.businessException(ex, "调用WS接口异常:", ResultEnum.WS_EXCEPTION);
        }
    }

    public WSWithdrawalRequests createWithdrawRequest(WSWithdrawalRequests wsWithdrawalRequest,WSCustomers customer) {
        try {
            WithdrawalApplyRequest request = new WithdrawalApplyRequest();
            request.setInfProductId(wsWithdrawalRequest.getProductId());
            request.setInfPwd(customer.getPwd());
            request.setWSWithdrawalRequests(wsWithdrawalRequest);
            request.setRequestUUID(genRequestUUID());
            String resp = HttpClientUtil.postJson(getUrl(), JSONObject.toJSONString(request));
            WithdrawalApplyResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "WS", WithdrawalApplyResponse.class);
            return response.getWSWithdrawalRequests();
        } catch (Exception ex) {
            log.error("调用WS接口异常，WithdrawalApplyResponse错误", ex);
//            BizException bizException = buildBizException(ex);
            //WS报错转义 304847: 无比特币存款; 304848: 比特币取款总额超过比特币存款总额3倍
//            if (Stream.of("304847", "304848").anyMatch(bizException.getErrCode()::contains)) {
//                bizException = new BizException(bizException.getErrCode(), "您暂时不满足比特币取款条件，如有疑问请联系客服", bizException.getCause());
//            }
            throw ThirdResponseHelper.businessException(ex, "调用WS接口异常:", ResultEnum.WS_EXCEPTION);
        }
    }
    private String genRequestUUID() {
        return UUID.randomUUID().toString().replace("-", "").toLowerCase();
    }

    /**
     * C66 修改玩家详细信息（包括修改密码、状态等详细信息）
     *
     * @param wsCustomers <pre>
     */
    public ModifyAccountResponse modifyAccount(WSCustomers wsCustomers, String infFlag,String url) {
        try {
            if(StringUtils.equals(infFlag,"17")) {
                wsCustomers.setLastUpdatedBy(wsCustomers.getLoginName());
            }
            WSCustomers customer = getSimpleCustomer(wsCustomers.getProductId(), wsCustomers.getLoginName());
            ModifyAccountRequest request = new ModifyAccountRequest();
            request.setInfProductId(wsCustomers.getProductId());
            request.setInfPwd(infPwd);
            request.setWSCustomers(wsCustomers);
            request.setInfFlag(infFlag);

            String resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            ModifyAccountResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "WS", ModifyAccountResponse.class);
            return response;
        } catch (Exception ex) {
            log.error("调用WS接口异常，ModifyAccountRequest错误", ex);
            throw ThirdResponseHelper.businessException(ex, "调用WS接口异常:", ResultEnum.WS_EXCEPTION);
        }
    }

    /**
     * 校验类型[
     * 1:检查loginName是否存在;
     * 2:检查电话是否存在;
     * 3:检查真实姓名是否存在;
     * 4:检查德州扑克信息（添加密码状态判断）;
     * 5:检查微信账号是否存在（wechat openId）;
     * 6:检查邮箱是否存在;
     * 7:检查Facebook Id是否存在;
     * 8:检查电话是否绑定;
     * 9:检查银行卡号是否存在;
     * 10:检查邮箱是否绑定]
     * 11:检查证件号是否存在
     *
     * @param productId
     * @param checkType
     * @param checkValue
     * @return
     */
    public boolean checkCustomerInfo(String productId, int checkType, String checkValue,String loginName) {
        try {
//            WsProductTemplate wsTemplate = generateWsTemplate(productId);
            CheckCustomerInfoNewRequest request = new CheckCustomerInfoNewRequest();
            request.setInfProductId(productId);
            WSCustomers customer = getSimpleCustomer(productId, loginName);
//            request.setInfPwd(wsTemplate.getInfPwd());
            request.setInfPwd(customer.getPwd());
            WSCustomerCheck check = new WSCustomerCheck();
            check.setCheckType(checkType);
            check.setCheckValue(checkValue);
            request.setWsCustomerCheck(check);
//            CheckCustomerInfoNewResponse response = (CheckCustomerInfoNewResponse) wsTemplate.marshalSendAndReceive(request);
//            String url = getUrl() + "/rest/customers/check_customer_info_new";
            String resp = HttpClientUtil.postJson(getUrl(), JSONObject.toJSONString(request));
            CheckCustomerInfoNewResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "WS", CheckCustomerInfoNewResponse.class);

            if ("true".equals(response.getWsResultObj().getStatus())) {
                return true;
            } else if ("false".equals(response.getWsResultObj().getStatus())) {
                return false;
            } else {
                throw new Exception("校验type=" + checkType + "返回异常：" + response.getWsResultObj().getMsg() + "-" + response.getWsResultObj().getMsg());
            }
        } catch (Exception ex) {
            log.error("调用WS接口异常，CheckCustomerInfoNewResponse错误", ex);
            throw ThirdResponseHelper.businessException(ex, "调用WS接口异常:", ResultEnum.WS_EXCEPTION);
        }
    }

    /**
     * 校验类型[
     * 1:检查loginName是否存在;
     * 2:检查电话是否存在;
     * 3:检查真实姓名是否存在;
     * 4:检查德州扑克信息（添加密码状态判断）;
     * 5:检查微信账号是否存在（wechat openId）;
     * 6:检查邮箱是否存在;
     * 7:检查Facebook Id是否存在;
     * 8:检查电话是否绑定;
     * 9:检查银行卡号是否存在;
     * 10:检查邮箱是否绑定]
     * 11:检查证件号是否存在
     * @param productId
     * @param checkType
     * @param checkValue
     * @return
     */
    public boolean checkCustomerInfo(String productId, int checkType, String checkValue) {
        try {
            CheckCustomerInfoNewRequest request = new CheckCustomerInfoNewRequest();
            request.setInfProductId(productId);

            request.setInfPwd(infPwd);
            WSCustomerCheck check = new WSCustomerCheck();
            check.setCheckType(checkType);
            check.setCheckValue(checkValue);
            request.setWsCustomerCheck(check);

            log.info("checkCustomerInfo调用WS接口 param={}",JSONObject.toJSONString(request));
            String url = getUrl() + "/rest/customers/check_customer_info_new";
            String resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            CheckCustomerInfoNewResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "WS", CheckCustomerInfoNewResponse.class);
            log.info("checkCustomerInfo调用WS接口 response={}",JSONObject.toJSONString(response));

            if ("true".equals(response.getWsResultObj().getStatus())) {
                return true;
            } else if ("false".equals(response.getWsResultObj().getStatus())) {
                return false;
            } else {
                throw new Exception("校验type=" + checkType + "返回异常：" + response.getWsResultObj().getMsg() + "-" + response.getWsResultObj().getMsg());
            }
        } catch (Exception ex) {
            log.error("调用WS接口异常，CheckCustomerInfoNewResponse错误", ex);
            throw ThirdResponseHelper.businessException(ex, "调用WS接口异常:", ResultEnum.WS_EXCEPTION);
        }
    }


    /**
     * 校验短信或邮件模板编号
     * @return
     */
    public Boolean checkSmsEmailNo(String productId,String sendType,String templateNumber,String loginName) {
        try {
//            WsProductTemplate wsTemplate = generateWsTemplate(productId);
            CheckSmsEmailNoRequest request = new CheckSmsEmailNoRequest();
            WSCustomers customer = getSimpleCustomer(productId, loginName);
            request.setInfProductId(productId);
//            request.setInfPwd(wsTemplate.getInfPwd());
            request.setInfPwd(customer.getPwd());
            request.setSendType(sendType);
            request.setTemplateNumber(templateNumber);
            String url = getUrl() + "/rest/customers/sms_email/checkSmsEmailNo";
            String resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            CheckSmsEmailNoResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "WS", CheckSmsEmailNoResponse.class);
            return response.getSuccess();
        } catch (Exception ex) {
            log.error("调用WS接口异常, checkSmsEmailNo", ex);
            throw ThirdResponseHelper.businessException(ex, "调用WS接口异常:", ResultEnum.WS_EXCEPTION);
        }
    }

    /**
     * 创建短信邮件
     * @param smsEmail
     * @param smsEmailDetails
     * @return
     */
    public Map<String, Integer> createSmsEmail(WSSmsEmail smsEmail, List<WSSmsEmailDetail> smsEmailDetails,String loginName) {
        try {
            String productId = smsEmail.getProductId();
//            WsProductTemplate wsTemplate = generateWsTemplate(productId);
            CreateSmsEmailRequest request = new CreateSmsEmailRequest();
            WSCustomers customer = getSimpleCustomer(productId, loginName);
            request.setInfProductId(productId);
//            request.setInfPwd(wsTemplate.getInfPwd());
            request.setInfPwd(customer.getPwd());
            request.setSmsEmailDetails(smsEmailDetails);
            request.setSmsEmail(smsEmail);
            String url = getUrl() + "/rest/customers/sms_email/create";
            String resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            CreateSmsEmailResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "WS", CreateSmsEmailResponse.class);
            return response.getResult();
        } catch (Exception ex) {
            log.error("调用WS接口异常, createSmsEmail", ex);
            throw ThirdResponseHelper.businessException(ex, "调用WS接口异常:", ResultEnum.WS_EXCEPTION);
        }
    }

    protected List<String> testBranch = Arrays.asList("SLS","SLS1");
    protected List<String> allGames = Arrays.asList("5","21", "27");
    protected List<String> allGames1 = Arrays.asList("5","21");
    protected List<String> allGames2 = Arrays.asList("5","27");
    protected WSBranch branchElectionByDefault(List<WSBranch> branches) {
        log.info("branchElectionByDefault allGames={}", allGames);
        List<WSBranch> allGamesBranchs = new ArrayList<>();
        branches.stream().filter(b -> StringUtils.isNoneBlank(b.getSupportGames()) && b.getSupportGames().split(",").length >= 2 && !testBranch.contains(b.getBranchName().toUpperCase())).forEach(b -> {
            List<String> games = Lists.newArrayList(b.getSupportGames().split(","));
            if(games.containsAll(allGames)) {
                allGamesBranchs.add(b);
            } else if(games.containsAll(allGames1)) {
                allGamesBranchs.add(b);
            } else if(games.containsAll(allGames2)) {
                allGamesBranchs.add(b);
            }
        });
        if(allGamesBranchs.size() > 0) {
            Collections.shuffle(allGamesBranchs);
            return allGamesBranchs.get(0);
        }
        log.info("混合门店列表为空");
        return null;
    }

    public QueryCustomersResponse queryCustomers(QueryCustomersRequest req) {
        String body = JSONObject.toJSONString(req);
        String s = HttpClientUtil.postJson(getUrl(), body);
        return JSONObject.parseObject(s,QueryCustomersResponse.class);
    }

    /**
     *
     * 创建代理下级存取款的提案
     * */
    public SaveAgentTransResponse createCustAgentTransaction(WSAgentTrans custAgentTransaction, String productId) {
        try {
//            WsProductTemplate wsTemplate = generateWsTemplate(productId);
            SaveAgentTransRequest request = new SaveAgentTransRequest();
            WSCustomers customer = getSimpleCustomer(productId, custAgentTransaction.getLoginName());
            request.setInfProductId(productId);
            request.setInfPwd(customer.getPwd());
            request.setRequestUUID(UUID.randomUUID().toString());
            request.setWsAgentTrans(custAgentTransaction);

            String resp = HttpClientUtil.postJson(getUrl(), JSONObject.toJSONString(request));
            return ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "WS", SaveAgentTransResponse.class);
        } catch (Exception ex) {
            log.error("调用WS接口异常, syncDepositWithdraw", ex);
            throw ThirdResponseHelper.businessException(ex, "调用WS接口异常:", ResultEnum.WS_EXCEPTION);
        }
    }

    public boolean exchangeGameToCash(WSTransfer wsTransfer) {
        try {
//            WsProductTemplate wsTemplate = generateWsTemplate(wsTransfer.getProductId());
            ExchangeCreditRequest request = new ExchangeCreditRequest();
            WSCustomers customer = getSimpleCustomer(wsTransfer.getProductId(), wsTransfer.getLoginName());
            request.setInfProductId(wsTransfer.getProductId());
            request.setInfPwd(customer.getPwd());
            request.setWSTransfer(wsTransfer);
            String resp = HttpClientUtil.postJson(getUrl(), JSONObject.toJSONString(request));
            ExchangeCreditResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "WS", ExchangeCreditResponse.class);
            return "".equals(response.getResult());
        } catch (Exception ex) {
            log.error("调用WS接口异常，ExchangeCreditResponse错误", ex);
            throw ThirdResponseHelper.businessException(ex, "调用WS接口异常:", ResultEnum.WS_EXCEPTION);
        }
    }

    /**
     * 查询银行卡修改提案
     *
     * @param wsQueryModifyBankRequest
     * @return
     */
    public List<WSModifyBankRequests> queryModifyBankRequests(WSQueryModifyBankRequests wsQueryModifyBankRequest) {
        try {
            QueryModifyBankRequestsRequest request = new QueryModifyBankRequestsRequest();
            request.setInfProductId(wsQueryModifyBankRequest.getProductId());
            request.setInfPwd(infPwd);
            request.setWSQueryModifyBankRequests(wsQueryModifyBankRequest);
            String url = getUrl() + "/rest/request/bank_request/query_page";
            String resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            QueryModifyBankRequestsResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "WS", QueryModifyBankRequestsResponse.class);
            return response.getWSModifyBankRequests();
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryModifyBankRequestsResponse错误", ex);
            throw ThirdResponseHelper.businessException(ex, "调用WS接口异常:", ResultEnum.WS_EXCEPTION);
        }
    }



    public boolean approveRequest(WSRequestsApprove approve, String productId) {
        try {
            RequestApproveRequest request = new RequestApproveRequest();
            request.setInfProductId(productId);
            request.setInfPwd(infPwd);
            request.setWSRequestsApprove(approve);
            String url = getUrl() + "/rest/request/approve";
            String resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            RequestApproveResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "WS", RequestApproveResponse.class);
            List<WSResponseApprove> wsResponseApproves = response.getWSResponseApprove();
            if (org.apache.commons.collections.CollectionUtils.isEmpty(wsResponseApproves)) {
                return false;
            }
            for (WSResponseApprove wsResponseApprove : wsResponseApproves) {
                if (!wsResponseApprove.isResultStatus()) {
                    throw new MKTIntegrationException(wsResponseApprove.getErrorMsg());
                }
            }
        } catch (Exception ex) {
            log.error("调用WS接口异常，RequestApproveResponse错误", ex);
            throw ThirdResponseHelper.businessException(ex, "调用WS接口异常:", ResultEnum.WS_EXCEPTION);
        }
        return true;
    }

    /**
     * description: 调用ws给玩家加减额度接口
     * @param:  [wsCreditLogs]
     * @return: com.cn.schema.creditlogs.CreateCreditLogsForCommToCreditResponse
     * @Date: 2023/6/22 15:45
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public CreateCreditLogsForCommToCreditResponse commCreditCreate(WSCreditLogs wsCreditLogs) {
        try {
            CreateCreditLogsForCommToCreditRequest request = new CreateCreditLogsForCommToCreditRequest();
            request.setInfProductId(wsCreditLogs.getProductId());
            request.setInfPwd(infPwd);
            request.setWSCreditLogs(wsCreditLogs);
            String url = getUrl() + "/rest/creditlogs/comm_credit/create";
            String resp = HttpClientUtil.postJson(url, JSONObject.toJSONString(request));
            CreateCreditLogsForCommToCreditResponse response = ThirdResponseHelper.pullDataIfExistsDefaultError(resp, "WS", CreateCreditLogsForCommToCreditResponse.class);
            return response;
        } catch (Exception ex) {
            log.error("调用WS接口异常，CreateCreditLogsForCommToCreditResponse错误", ex);
            throw ThirdResponseHelper.businessException(ex, "调用WS接口异常:", ResultEnum.WS_EXCEPTION);
        }
    }

}
