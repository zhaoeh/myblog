package com.mkt.agent.integration.service;

import com.cn.schema.customers.*;
import com.cn.schema.urf.QueryBranchRequest;
import com.cn.schema.urf.QueryBranchResponse;
import com.mkt.agent.integration.entities.ws.InterWSCustomers;

public interface WsRestInter {

    //远程调用ws创建新的客户
    public CreateNewAccountResponse createInterNewAccount(InterWSCustomers wsCustomers,String url,String infFlag);

    public QueryCustomersBasicResponse getCustomer(WSQueryCustomers wsQueryCustomers,String url);

    public QueryCustomerDownlineResponse queryAllPlayerByParentPage(WSQueryCustomerDownline wsQueryCustomerDownline, String url);

    public QueryBranchResponse queryBranches(QueryBranchRequest request, String product);

    public QueryCountCustomersResponse countCustomers(WSQueryCustomers wsQueryCustomers,String url);


    public QueryCustomersResponse queryCustomersSingleTable(WSQueryCustomers wsQueryCustomers,String url);


}
