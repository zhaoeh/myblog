package com.mkt.agent.integration.entities.request;

import com.mkt.agent.common.enums.CustomizedValidationContents;
import com.mkt.agent.common.valid.EnumValid;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;

public class QueryAgentTransReq extends BaseReq {
    @ApiModelProperty("主键")
    private String id;
    @ApiModelProperty("客户ID")
    private String customerId;
    @ApiModelProperty("状态 0--未绑定 1--已绑定 2--解绑 3--删除")
    private String tradeType;
    @ApiModelProperty("创建时间开始")
    private String createdDateBegin;
    @ApiModelProperty("创建时间结束")
    private String createdDateEnd;
    @ApiModelProperty("最后修改人")
    private String requestNo;
    @ApiModelProperty("备注")
    private String remark;
    @ApiModelProperty("审核日期")
    private String verificationDate;
    @ApiModelProperty("提案状态0 待审核、1通过、2 拒绝")
    private Integer status;
    @ApiModelProperty("代理登录名")
    private String parentLoginName;
    @ApiModelProperty("终端类型")
    private String endpointType;
    private String customerName;
    private String isFirst;
    private String amountStart;
    private String amountEnd;


    private int pageNo = 1;
    private int pageSize = 20;

    @ApiModelProperty(value = "siteId 1:Bingoplus  2:Arenaplus  3:Gameplus")
    @EnumValid(contents = CustomizedValidationContents.site_id_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class} )
    private Integer siteId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getTradeType() {
        return tradeType;
    }

    public void setTradeType(String tradeType) {
        this.tradeType = tradeType;
    }

    public String getCreatedDateBegin() {
        return createdDateBegin;
    }

    public void setCreatedDateBegin(String createdDateBegin) {
        this.createdDateBegin = createdDateBegin;
    }

    public String getCreatedDateEnd() {
        return createdDateEnd;
    }

    public void setCreatedDateEnd(String createdDateEnd) {
        this.createdDateEnd = createdDateEnd;
    }

    public String getRequestNo() {
        return requestNo;
    }

    public void setRequestNo(String requestNo) {
        this.requestNo = requestNo;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getVerificationDate() {
        return verificationDate;
    }

    public void setVerificationDate(String verificationDate) {
        this.verificationDate = verificationDate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getParentLoginName() {
        return parentLoginName;
    }

    public void setParentLoginName(String parentLoginName) {
        this.parentLoginName = parentLoginName;
    }

    public String getEndpointType() {
        return endpointType;
    }

    public void setEndpointType(String endpointType) {
        this.endpointType = endpointType;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getIsFirst() {
        return isFirst;
    }

    public String getAmountStart() {
        return amountStart;
    }

    public void setAmountStart(String amountStart) {
        this.amountStart = amountStart;
    }

    public String getAmountEnd() {
        return amountEnd;
    }

    public void setAmountEnd(String amountEnd) {
        this.amountEnd = amountEnd;
    }

    public void setIsFirst(String isFirst) {
        this.isFirst = isFirst;
    }

    public Integer getSiteId() {
        return siteId;
    }

    public void setSiteId(Integer siteId) {
        this.siteId = siteId;
    }
}
