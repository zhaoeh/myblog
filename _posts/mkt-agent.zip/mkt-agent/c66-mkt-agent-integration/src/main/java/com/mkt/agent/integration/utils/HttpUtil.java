package com.mkt.agent.integration.utils;

import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

public class HttpUtil {


    public static ResponseEntity<?> postForEntity(String url, Map paramMap, Class outClass) {

        LinkedMultiValueMap<String, String> headers = new LinkedMultiValueMap<>();

        Map<String, String> map = new HashMap<>();
        map.put("Content-Type", "application/json");
        headers.setAll(map);

        HttpEntity<?> request = new HttpEntity<>(paramMap, headers);

        return new RestTemplate().postForEntity(url, request, outClass);

    }

}
