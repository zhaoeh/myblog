package com.mkt.agent.integration.entities.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel
@Data
public class UpdateCustomerInfoReq extends BaseReq {

    @ApiModelProperty(value = "新密码[公钥加密]")
    private String newPassword;

    @ApiModelProperty(value = "要修改的 phone",example="", position = 3)
    private String newPhone;

    @ApiModelProperty(value = "要修改的 email",example="kgdtajewcm@gmail.com", position = 3)
    private String newEmail;

    @ApiModelProperty(value = "取款密码，RSA加密<br/>Withdrawal Password, RSA encrypt")
    private String newWithdrawalPwd;



}

