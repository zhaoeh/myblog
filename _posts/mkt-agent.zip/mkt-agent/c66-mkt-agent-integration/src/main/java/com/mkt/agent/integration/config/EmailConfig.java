package com.mkt.agent.integration.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @Description: 邮件配置
 * @Author: PTMinnisLi
 * @Date: 2023/6/6
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Component
@RefreshScope
public class EmailConfig {

    @Value("${C66.email.url}")
    private String emailServerApiUrl;

    @Value("${C66.email.product-key}")
    private String productKey;

    /**
     * 邮箱验证码失效时间：默认15分钟（900秒）
     */
    @Value("${C66.email.expire-time:15}")
    private Long emailOtpExpireTime;

//    @Value("${C66.connection.timeout:60000}")
//    private long connTimeout;
//
//    @Value("${C66.receive.timeout:60000}")
//    private long receiveTimeout;

}
