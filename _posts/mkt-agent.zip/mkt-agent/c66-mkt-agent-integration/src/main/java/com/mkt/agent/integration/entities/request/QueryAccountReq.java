package com.mkt.agent.integration.entities.request;

import io.swagger.annotations.ApiModelProperty;

public class QueryAccountReq extends BaseReq {

    @ApiModelProperty(value = "账号类型[0:银行卡,1:比特币，3:USDT,4:MBTC,5:ETH,6:ALIPAY_A,7:ALIPAY_Q,8:BITOLL], 缺省为所有", example = "1")
    private Integer accountType;

    @ApiModelProperty(value = "账号", example = "62260080123455")
    private String accountNo;

    @ApiModelProperty(value = "是否检查BTC汇率[默认检查,传入0则不检查,以WS账户flag为准]", example = "1")
    private Integer checkRate;

    @ApiModelProperty(value = "目标协议列表,不填默认protocols返回所有钱包类型协议", example = "bitoll")
    private String protocolType;

    @ApiModelProperty(value = "是否返回指定信用级屏蔽的取款账号，1是，0否，默认否", example = "1")
    private String depositLevelCheckFlag;

    public Integer getAccountType() {
        return accountType;
    }

    public void setAccountType(Integer accountType) {
        this.accountType = accountType;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public Integer getCheckRate() {
        return checkRate;
    }

    public void setCheckRate(Integer checkRate) {
        this.checkRate = checkRate;
    }

    public String getProtocolType() {
        return protocolType;
    }

    public void setProtocolType(String protocolType) {
        this.protocolType = protocolType;
    }

    public String getDepositLevelCheckFlag() {
        return depositLevelCheckFlag;
    }

    public void setDepositLevelCheckFlag(String depositLevelCheckFlag) {
        this.depositLevelCheckFlag = depositLevelCheckFlag;
    }

    @Override
    public String toString() {
        return "QueryAccountReq{" +
                "accountType=" + accountType +
                ", accountNo='" + accountNo + '\'' +
                ", checkRate=" + checkRate +
                ", depositLevelCheckFlag=" + depositLevelCheckFlag +
                '}';
    }
}
