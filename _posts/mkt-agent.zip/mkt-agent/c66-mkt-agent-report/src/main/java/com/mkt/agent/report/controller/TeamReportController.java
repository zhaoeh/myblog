package com.mkt.agent.report.controller;

import com.google.gson.Gson;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.reportapi.requests.TeamReportByGameRequest;
import com.mkt.agent.common.entity.api.reportapi.requests.TeamReportRequest;
import com.mkt.agent.common.entity.api.reportapi.responses.TeamReportByGameResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.TeamReportResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.TurnoverDistributionResp;
import com.mkt.agent.common.entity.api.reportapi.responses.TurnoverTopResp;
import com.mkt.agent.common.entity.api.reportapi.responses.base.ReportPageResponse;
import com.mkt.agent.common.entity.clickhouse.req.DashBoardUserTreeQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.ClDashBoardDataRes;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.RedisUtil;
import com.mkt.agent.report.clickhouse.mapper.TDailyOrderMapper;
import com.mkt.agent.report.exception.MKTRportException;
import com.mkt.agent.report.fegin.UserFeignService;
import com.mkt.agent.report.mapper.TeamReportHistoryMapper;
import com.mkt.agent.report.mapper.TeamReportHistoryTypeMapper;
import com.mkt.agent.report.mapper.UserMapper;
import com.mkt.agent.report.req.TAgentCustomers;
import com.mkt.agent.report.req.TeamReportHistory;
import com.mkt.agent.report.req.TeamReportHistoryType;
import com.mkt.agent.report.service.ReportService;
import com.mkt.agent.report.utils.AgentLevelUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/team-report")
@Api(tags = "team-report API")
@Slf4j
@RefreshScope
public class TeamReportController {

    @Resource
    private  AgentLevelUtil agentLevelUtil;

    @Resource(name = "teamReportServiceImpl")
    private ReportService reportService;

    @PostMapping("/queryByPageAndCondition")
    @ApiOperation("team report realtime data by page")
    public ReportPageResponse<TeamReportResponse> queryByPageAndCondition(@RequestBody TeamReportRequest req) {
        log.info("team report param :{}", req.toString());
        ReportPageResponse<TeamReportResponse> reportPageResponse = reportService.queryByPageAndCondition(req);
        log.info("team report resp :{}", reportPageResponse);
        log.info("team report total :{}", reportPageResponse.getTotal());
        return reportPageResponse;
    }

    @PostMapping("/history")
    @ApiOperation("team report history by page ")
    public ReportPageResponse<TeamReportResponse> history(@RequestBody TeamReportRequest req) {
        log.info("team report param :{}", req.toString());
        ReportPageResponse<TeamReportResponse> reportPageResponse = reportService.history(req);
        log.info("team report resp :{}", reportPageResponse);
        log.info("team report total :{}", reportPageResponse.getTotal());
        return reportPageResponse;
    }

    @PostMapping("/getGameReport")
    @ApiOperation("getGameReport")
    public TeamReportByGameResponse getGameReport(@RequestBody TeamReportByGameRequest req) {
        if (!agentLevelUtil.agentAccountExist(req.getLoginName(),req.getAgentAccount())){
            log.info("You can only view your own team information");
            throw new MKTRportException("You can only view your own team information");
        }
        log.info("customer game report parm :{}", req.toString());
        TeamReportByGameResponse gameReport = reportService.getGameReport(req);
        log.info("customer game report param :{}", gameReport);
        return gameReport;
    }


    @PostMapping("/export")
    @ApiOperation("export team report")
    public List<TeamReportResponse> export(@RequestBody TeamReportRequest req) {
        log.info("team report export param :{}", req.toString());
        req.setIsPage(false);
        List<TeamReportResponse> result = reportService.export(req);
        log.info("team report export result :{}", result);
        return result;
    }

    @PostMapping("/history/export")
    @ApiOperation("export team report")
    public List<TeamReportResponse> historyExport(@RequestBody TeamReportRequest req) {
        log.info("team report history export param :{}", req.toString());
        req.setIsPage(false);
        List<TeamReportResponse> result = reportService.exportHistory(req);
        log.info("team report history export result :{}", result);
        return result;
    }



    @PostMapping("getDashboardTeamSummary")
    @ApiOperation("getDashboardTeamSummary  team report")
    public CommissionRecordDashBoardResponse getDashboardTeamSummary(@RequestBody TeamReportRequest req) {
//        log.info("team report history export param :{}", req.toString());
//        req.setIsPage(false);
        CommissionRecordDashBoardResponse  result = reportService.getDashboardTeamSummary(req);
//        log.info("team report history export result :{}", result);
        return result;
    }

    @Autowired
    private UserFeignService userFeignService;



    private <T> List<List<T>> splitArrayList(List<T> list, int splitSize) {
        List<List<T>> subLists = new ArrayList<>();
        for (int i = 0; i < list.size(); i += splitSize) {
            int endIndex = Math.min(i + splitSize, list.size());
            subLists.add(list.subList(i, endIndex));
        }
        return subLists;
    }


    @Value("${tempReport.splitRow:6500}") //
    private Integer splitRow;


    @GetMapping("getGameReportTest")
    @ApiOperation("缓存测试")
    public Map<String, Object> queryByPageAndConditionTest(HttpServletRequest request ) {

        Map<String, String> p = new HashMap<>();
        String t =request.getParameter("t")  ;
        String name =request.getParameter("name")  ;
        String flag =request.getParameter("flag")  ;
        String saveFlag =request.getParameter("saveFlag")  ;


        ClDashBoardDataRes today =  reportService.saveLocalData(DateUtils.stringToDate(t) ,Integer.valueOf(flag)   ,Integer.valueOf(saveFlag) ,name ) ;

    log.info("today ={}", new Gson().toJson(today));
        return null;
    }
    @Autowired
        private UserMapper userMapper ;
    @Autowired
    private TeamReportHistoryMapper teamReportHistoryMapper ;

    @Autowired
    private TeamReportHistoryTypeMapper teamReportHistoryTypeMapper ;


    @Resource
    private TDailyOrderMapper tDailyOrderMapper;



    /**
     * 是否缓存*
     * 2缓存  1 不缓存* 默认2
     */
    @Value("${tempReport.isCache:2}")
    private String isCache;

    /**
     * 下级大于100时缓存*
     */
    @Value("${tempReport.subUsers:100}")
    private int subUsers;

    @Resource
    private RedisUtil redisUtil;


}
