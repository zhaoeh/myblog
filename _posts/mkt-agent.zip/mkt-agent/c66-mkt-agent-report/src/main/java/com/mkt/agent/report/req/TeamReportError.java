package com.mkt.agent.report.req;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.util.Date;

@Data
@ApiModel(description = "t_team_report_error")
@TableName("t_team_report_error")
public class TeamReportError {
    private String id;
    private String type;
    private String loginName;
    private String status;
    private Date createtime;


    public String getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public String getLoginName() {
        return loginName;
    }

    public String getStatus() {
        return status;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }
}
