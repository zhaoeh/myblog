package com.mkt.agent.report.mapper;

import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerQueryResponse;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserMapper {


    List<TCustomerLayer> selectUserTreeByParentNTime (
            @Param("parent") String parent, @Param("createTimeStart") String createTimeStart, @Param("createTimeEnd") String createTimeEnd);

}
