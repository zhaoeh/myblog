package com.mkt.agent.report.fegin;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.userapi.requests.AgentListRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

/**
 * @interfaceName: AgentApiClient
 * @Description:
 * @Author: Austin
 * @Date: 2023/5/30
 */
//@FeignClient(name = "${feign.mkt-agent-api}", url = "127.0.0.1:18080")
@FeignClient(name = "${feign.mkt-agent-api}")
public interface AgentApiClient {

    @PostMapping(value = "/agentCustomers/list")
    Result<List<TAgentCustomers>> getAgentList(AgentListRequest request);

}
