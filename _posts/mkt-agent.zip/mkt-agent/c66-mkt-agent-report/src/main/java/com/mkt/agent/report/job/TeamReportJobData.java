package com.mkt.agent.report.job;

import com.google.gson.Gson;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.integration.bi.responses.UserGameSummerResponse;
import com.mkt.agent.common.entity.api.reportapi.requests.TeamReportByGameRequest;
import com.mkt.agent.common.entity.api.reportapi.requests.TeamReportRequest;
import com.mkt.agent.common.entity.api.reportapi.responses.TeamReportByGameResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.TeamReportResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.base.ReportPageResponse;
import com.mkt.agent.common.entity.clickhouse.req.DashBoardUserTreeQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.ClDashBoardDataRes;
import com.mkt.agent.common.enums.GameTypeEnum;
import com.mkt.agent.common.enums.SettlementPeriodEnum;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.RedisUtil;
import com.mkt.agent.report.clickhouse.mapper.TDailyOrderMapper;
import com.mkt.agent.report.fegin.UserFeignService;
import com.mkt.agent.report.mapper.TeamReportErrorMapper;
import com.mkt.agent.report.mapper.TeamReportHistoryMapper;
import com.mkt.agent.report.mapper.TeamReportHistoryTypeMapper;
import com.mkt.agent.report.req.*;
import com.mkt.agent.report.service.ReportService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Author: stanko
 */
@EnableScheduling
@Component
@Slf4j
@RefreshScope
public class TeamReportJobData {

    /**
     * 是否缓存*
     * 2缓存  1 不缓存* 默认2
     */
    @Value("${tempReport.isCache:2}")
    private String isCache;

    /**
     * 下级大于100时缓存*
     */
    @Value("${tempReport.subUsers:100}")
    private int subUsers;

    @Resource
    private RedisUtil redisUtil;


    /**
     *   开始缓存昨天的数据
     */
    @Scheduled(cron = "0 21 01 * * ?")
    public void localCacheData() {

        List<TAgentCustomers> list = reportService.findAllAgent();

        Calendar calendar = Calendar.getInstance();
        Date date = calendar.getTime();

        for(TAgentCustomers agentCustomers : list) {

                calendar = Calendar.getInstance();
                calendar.add(Calendar.DAY_OF_MONTH,    -1 );

                  date = calendar.getTime();

              reportService.saveLocalData(date,1,2, agentCustomers.getLoginName())  ;


        }

    }





    /**
     * 开始缓存 1-到上月  游戏分类
     */
//    @Scheduled(cron = "0 20 18 * * ?")


    @Autowired
    private TeamReportErrorMapper teamReportErrorMapper;

    @Autowired
    private TeamReportHistoryTypeMapper teamReportHistoryTypeMapper;


    @Resource
    private ReportService reportService;

    @Autowired
    private TeamReportHistoryMapper teamReportHistoryMapper;


    @Value("${tempReport.splitRow:4000}") //
    private Integer splitRow;

    public static void main(String[] args) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH,   -1);
        Date date = calendar.getTime();

        Date min =  DateUtils.getFirstDayOfMonth(date) ;

        Date max =  DateUtils.getLastDayOfMonth(date) ;

        System.out.println(DateUtils.dateToString(min) +"," + DateUtils.dateToString(max));

    }

    private <T> List<List<T>> splitArrayList(List<T> list, int splitSize) {
        List<List<T>> subLists = new ArrayList<>();
        for (int i = 0; i < list.size(); i += splitSize) {
            int endIndex = Math.min(i + splitSize, list.size());
            subLists.add(list.subList(i, endIndex));
        }
        return subLists;
    }

    @Autowired
    private UserFeignService userFeignService;

    @Autowired
    private TDailyOrderMapper tDailyOrderMapper;

    @Scheduled(cron = "0 0/3 * * * ?") // 每5执行一次
    public void localCacheData88() {
            List<TeamReportError> reportErrors   =  teamReportErrorMapper.getList() ;

            for (TeamReportError error : reportErrors) {

                Map<String, String> p = new HashMap<>();
                p.put("min",DateUtils.dateToString(error.getCreatetime(),"yyyy-MM-dd")) ;
                p.put("max",DateUtils.dateToString(error.getCreatetime(),"yyyy-MM-dd")) ;
                p.put("loginName" ,error.getLoginName() );



                 reportService.saveLocalData(error.getCreatetime() ,1   ,2 ,error.getLoginName() ) ;



                Map<String,String>  parame2 = new HashMap<>() ;
                parame2.put("rowid"  , error.getId())  ;
                teamReportErrorMapper.deleteByMap2(parame2)  ;
            }


    }


}
