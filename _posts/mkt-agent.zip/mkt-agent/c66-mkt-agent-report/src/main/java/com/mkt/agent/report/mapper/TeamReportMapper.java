package com.mkt.agent.report.mapper;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.common.entity.api.reportapi.requests.TeamReportRequest;
import com.mkt.agent.common.entity.api.reportapi.responses.sum.TeamReportSumResponse;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface TeamReportMapper extends BaseMapper<AgentCommissionRecord> {

    TeamReportSumResponse queryByPageAndConditionSum(@Param("rq")TeamReportRequest rq, @Param("ew") Wrapper<AgentCommissionRecord> queryWrapper);
    List<com.mkt.agent.report.req.TAgentCustomers>  findAllAgent() ;
    default Wrapper<AgentCommissionRecord> getRecordQueryWrapper(TeamReportRequest req, List<String> agentNames, String sortName) {

        String isAsc = req.getIsAsc() ? "asc" : "desc";
        String isSort = "".equals(sortName) ? "settle_date_start desc" : sortName +" "+ isAsc;
        return Wrappers.<AgentCommissionRecord>lambdaQuery()
                // 玩家投注日期 >= 开始时间
                .ge(StringUtils.isNotEmpty(req.getPlayInfoDateStart()), AgentCommissionRecord::getSettleDateStart, req.getPlayInfoDateStart())
                // 玩家投注日期 <= 结束时间
                .le(StringUtils.isNotEmpty(req.getPlayInfoDateEnd()), AgentCommissionRecord::getSettleDateEnd, req.getPlayInfoDateEnd())
                // agentAccount like account
                .like(StringUtils.isNotEmpty(req.getAgentAccount()), AgentCommissionRecord::getAgentAccount, req.getAgentAccount())
                // parent like account
                .like(StringUtils.isNotEmpty(req.getParentAccount()), AgentCommissionRecord::getParentAccount, req.getParentAccount())
                // agentAccount in agentNames
                .in(AgentCommissionRecord::getAgentAccount, agentNames)
                // 登录人排在第一位,之后根据创建时间排序
                .last("order by case when agent_account = '"+ req.getLoginName() +"' then 1 else 2 end, "+ isSort +"");
    }
}
