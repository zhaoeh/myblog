package com.mkt.agent.report.clickhouse.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.clickhouse.DailyOrderAll;
import com.mkt.agent.common.entity.clickhouse.resp.ClDashBoardDataRes;
import com.mkt.agent.report.req.TUserFinanceDwTreed;
import com.mkt.agent.report.req.TUserFinanceOrderTreed;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface TDailyOrderMapper extends BaseMapper<DailyOrderAll> {

    List<TUserFinanceOrderTreed> findList(Map<String, Object> parame);  //  游戏指标查询


    List<TUserFinanceDwTreed> findListByCz(Map<String, Object> parame);  //充值查询


    List<TUserFinanceDwTreed> findListByTx(Map<String, Object> parame);

    List<TUserFinanceOrderTreed> findListByDay(Map<String, Object> parame);

    List<TUserFinanceDwTreed> findListByDayCz(Map<String, Object> parame);

    List<TUserFinanceDwTreed> findListByDayTx(Map<String, Object> parame);

    List<TUserFinanceOrderTreed> findListByGameType(Map<String, Object> parame);

    List<TUserFinanceOrderTreed> findListByPayers(Map<String, Object> parame);  // 月数据

    List<TUserFinanceDwTreed> findListByCzByPayers(Map<String, Object> parame);  //月 充值数据

    List<TUserFinanceDwTreed> findListByTxByPayers(Map<String, Object> parame);

    List<ClDashBoardDataRes>  getNewAllData(Map<String, Object> p);

    List<ClDashBoardDataRes> getNewAllData2(Map<String, Object> p);

    List<ClDashBoardDataRes> getNewAllData3(Map<String, Object> p);

    List<ClDashBoardDataRes> getNewAllDataNew(Map<String, Object> p);

    List<ClDashBoardDataRes> getNewAllDataGameType(Map<String, Object> p);

    Long getBetPlayers(Map<String, Object> p);
}
