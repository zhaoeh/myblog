package com.mkt.agent.report.mapper;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.common.entity.api.reportapi.requests.TeamReportRequest;
import com.mkt.agent.common.entity.api.reportapi.responses.sum.TeamReportSumResponse;
import com.mkt.agent.report.req.TeamReportError;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface TeamReportErrorMapper extends BaseMapper<TeamReportError> {
    List<TeamReportError> getList();

    void deleteByMap2(Map<String, String> parame2);
}
