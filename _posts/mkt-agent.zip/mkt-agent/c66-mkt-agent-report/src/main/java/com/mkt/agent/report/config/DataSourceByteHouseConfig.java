package com.mkt.agent.report.config;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.core.MybatisConfiguration;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import com.baomidou.mybatisplus.extension.spring.MybatisSqlSessionFactoryBean;
import com.mkt.agent.common.config.JdbcParamsConfig;
import com.mkt.agent.ds.core.DataSourceConstants;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.ibatis.logging.stdout.StdOutImpl;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import javax.annotation.Resource;

/**
 * @Description TODO
 * @Classname DataSourceClickhouseConfig
 * @Date 2023/11/22 12:22
 * @Created by TJSLucian
 */
@Configuration
@MapperScan(sqlSessionFactoryRef = "bytehouseSqlSessionFactory", basePackages = {"com.mkt.agent.commission.clickhouse.mapper"})
public class DataSourceByteHouseConfig {

   @Resource
    private JdbcParamsConfig jdbcParamsConfig ;

    @Value("${spring.datasource.third.username}")
    private String userName;
    @Value("${spring.datasource.third.apiKey}")
    private String apiKey;
    @Value("${spring.datasource.third.url}")
    private String url;
    @Value("${spring.datasource.third.poolName}")
    private String poolName;
    @Value("${spring.datasource.third.driver-class-name}")
    private String driverClassName;

    @Bean(DataSourceConstants.BYTE_HOUSE_DATASOURCE)
    public HikariDataSource hikariDataSource(){
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setDriverClassName(driverClassName);
        hikariConfig.setJdbcUrl(url);
        hikariConfig.setUsername(userName);
        hikariConfig.setPassword(apiKey);
        hikariConfig.setConnectionTimeout(jdbcParamsConfig.getConnectionTimeout());
        hikariConfig.setIdleTimeout(jdbcParamsConfig.getIdleTimeout());
        hikariConfig.setMaximumPoolSize(jdbcParamsConfig.getMaxPoolSize());
        hikariConfig.setMinimumIdle(jdbcParamsConfig.getMinIdle());
        hikariConfig.setMaxLifetime(jdbcParamsConfig.getMaxLifetime());
        hikariConfig.setPoolName(poolName);
        return new HikariDataSource(hikariConfig);
    }

}
