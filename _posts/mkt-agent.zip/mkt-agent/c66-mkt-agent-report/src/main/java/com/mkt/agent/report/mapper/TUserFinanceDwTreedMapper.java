package com.mkt.agent.report.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.report.req.TUserFinanceDwTreed;
import com.mkt.agent.report.req.TUserFinanceOrderTreed;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface TUserFinanceDwTreedMapper  extends BaseMapper<TUserFinanceDwTreed> {

    List<TUserFinanceDwTreed> findList(Map<String, Object> parame);

    List<TUserFinanceDwTreed> findListByDay(Map<String, Object> parame);
}
