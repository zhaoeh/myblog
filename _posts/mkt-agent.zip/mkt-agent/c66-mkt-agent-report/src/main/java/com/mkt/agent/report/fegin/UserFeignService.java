package com.mkt.agent.report.fegin;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.clickhouse.req.DashBoardUserTreeQueryReq;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

//@FeignClient(name = "${feign.mkt-user}", url = "127.0.0.1:50098")
@FeignClient(name = "${feign.mkt-user}")
public interface UserFeignService {

    @GetMapping("/user/tree/by-parent")
    Result<List<TCustomerLayer>> selectUserTree (
            @RequestParam("parent") String parent,
            @RequestParam("customerTypeList") List<Integer> customerTypeList
    );

    @PostMapping("/user/tree/byParentNTime")
    Result<List<TCustomerLayer>> selectUserTreeByParentNTime(@RequestBody DashBoardUserTreeQueryReq queryEntity);


    @PostMapping("/user/tree/byParentNTimeCount")
    Result<Long> selectUserTreeByParentNTimeCount(@RequestBody DashBoardUserTreeQueryReq queryEntity);





}
