package com.mkt.agent.report.fegin;

import com.mkt.agent.common.entity.api.reportapi.requests.TeamReportRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

//@FeignClient(name = "${feign.mkt-agent-job}", url = "127.0.0.1:18087")
@FeignClient(name = "${feign.mkt-agent-job}")
public interface JobFeignReportService {

    @PostMapping(value = "/customerPlayInfo_job_trigger/redo")
    void redo(@RequestBody TeamReportRequest req);


}
