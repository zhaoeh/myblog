package com.mkt.agent.commission.board.core;

import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordDashBoardRequest;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.utils.ThreadLocalUtil;
import org.springframework.stereotype.Component;

/**
 * @description: dash board运行周期处理器
 * @author: ErHu.Zhao
 * @create: 2024-01-16
 **/
@Component
public class DashBoardRunsProcessor {

    private final DashBoardUpdateLimiter dashBoardUpdateLimiter;

    public DashBoardRunsProcessor(DashBoardUpdateLimiter dashBoardUpdateLimiter) {
        this.dashBoardUpdateLimiter = dashBoardUpdateLimiter;
    }

    /**
     * 预处理
     *
     * @param oldReq 原始请求
     * @param newReq 新请求
     */
    public void beforeProcessor(CommissionRecordDashBoardRequest oldReq, ClDashBoardCreateQueryReq newReq) {
        cacheLimitParamsToThread(oldReq);
        updateDashBoardWithAdditional(newReq);
    }

    /**
     * 额外更新动作
     *
     * @param newReq 新请求
     */
    private void updateDashBoardWithAdditional(ClDashBoardCreateQueryReq newReq) {
        dashBoardUpdateLimiter.updateAdditionalWithAsyncAndLimiter(newReq);
    }

    /**
     * 缓存限流参数
     *
     * @param req
     */
    private void cacheLimitParamsToThread(CommissionRecordDashBoardRequest req) {
        String chosenType = req.getChosenType();
        String chosenPeriod = req.getChosenPeriod();
        String loginName = req.getLoginName();
        ThreadLocalUtil.set(Constants.CHOSEN_TYPE_KEY, chosenType);
        ThreadLocalUtil.set(Constants.CHOSEN_PERIOD_KEY, chosenPeriod);
        ThreadLocalUtil.set(Constants.LOGIN_NAME_KEY, loginName);
    }
}
