package com.mkt.agent.commission.board.core;

import com.google.gson.Gson;
import com.mkt.agent.commission.fegin.AgentFeignService;
import com.mkt.agent.commission.fegin.UserFeignService;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 * @program: mkt-agent
 * @description: dash board数据重构器
 * @author: Erhu.Zhao
 * @create: 2023-12-07 14:34
 */
@Component
@Slf4j
public class DashBoardHelper {

    private final DashBoardCommonUtil dashBoardCommonUtil;

    private final Gson gson;

    private final RedisUtil redisUtil;

    private final AgentFeignService agentFeignService;

    private final UserFeignService userFeignService;

    public DashBoardHelper(
                           DashBoardCommonUtil dashBoardCommonUtil,
                           Gson gson, RedisUtil redisUtil,
                           AgentFeignService agentFeignService,
                           UserFeignService userFeignService) {
        this.dashBoardCommonUtil = dashBoardCommonUtil;
        this.gson = gson;
        this.redisUtil = redisUtil;
        this.agentFeignService = agentFeignService;
        this.userFeignService = userFeignService;
    }

    public DashBoardCommonUtil getDashBoardCommonUtil() {
        return dashBoardCommonUtil;
    }

    /**
     * 聚合仪表盘数据响应
     *
     * @param left  左侧数据
     * @param right 右侧数据
     * @return 聚合后的数据
     */
    public CommissionRecordDashBoardResponse refactorBoardResponseData(CommissionRecordDashBoardResponse left, CommissionRecordDashBoardResponse right) {
        left.setDeposit(left.getDeposit().add(right.getDeposit()));
        left.setBetPlayers(left.getBetPlayers() + right.getBetPlayers());
        left.setGgr(left.getGgr().add(right.getGgr()));
        left.setRegistrationNumber(left.getRegistrationNumber() + right.getRegistrationNumber());
        left.setTurnover(left.getTurnover().add(right.getTurnover()));
        left.setWithdraw(left.getWithdraw().add(right.getWithdraw()));
        left.setFirstDepositPlayers(left.getFirstDepositPlayers() + right.getFirstDepositPlayers());
        left.setFirstDepositAmount(left.getFirstDepositAmount().add(right.getFirstDepositAmount()));

        return left;
    }

    /**
     * 聚合仪表盘数据响应
     *
     * @param left  左侧数据
     * @param right 右侧数据
     * @return 聚合后的数据
     */
    public DashBoardHistoryEntity refactorBoardEntityData(DashBoardHistoryEntity left, DashBoardHistoryEntity right) {
        left.setDeposit(left.getDeposit().add(right.getDeposit()));
        left.setRegistrationNumber(left.getRegistrationNumber() + right.getRegistrationNumber());
        left.setTurnover(left.getTurnover().add(right.getTurnover()));
        left.setGgr(left.getGgr().add(right.getGgr()));
        left.setWithdraw(left.getWithdraw().add(right.getWithdraw()));
        left.setFirstDepositPlayers(left.getFirstDepositPlayers() + right.getFirstDepositPlayers());
        left.setFirstDepositAmount(left.getFirstDepositAmount().add(right.getFirstDepositAmount()));


        return left;
    }

    /**
     * 根据 dashBoardHistoryEntity 生成一个CommissionRecordDashBoardResponse副本
     *
     * @param dashBoardHistoryEntity dashBoardHistoryEntity实体
     * @return CommissionRecordDashBoardResponse副本
     */
    public CommissionRecordDashBoardResponse generateCopyResponseOfEntity(DashBoardHistoryEntity dashBoardHistoryEntity) {
        CommissionRecordDashBoardResponse response = new CommissionRecordDashBoardResponse();
        Optional.ofNullable(dashBoardHistoryEntity).ifPresent(entity -> BeanCopyUtil.copyProperties(entity, response));
        return response;
    }

    /**
     * 离散数据汇总（1.聚合数据 2.计算佣金）
     *
     * @param sources 离散数据集合
     * @return 汇总后数据
     */
    public CommissionRecordDashBoardResponse summarizeDiscreteData(List<DashBoardHistoryEntity> sources) {
        CommissionRecordDashBoardResponse response = Optional.ofNullable(sources).flatMap(list -> list.stream().filter(e -> StringUtils.isNotBlank(e.getLoginName())).
                reduce(this::refactorBoardEntityData).map(this::generateCopyResponseOfEntity)).orElseGet(CommissionRecordDashBoardResponse::new);
        log.info("[summarizeDiscreteData method] end to summarizeDiscreteData,response is {}", gson.toJson(response));
        return response;
    }

    /**
     * 根据缓存key获取缓存value对象
     *
     * @param cacheKey 缓存Key
     * @return key对应的value data
     */
    public DashBoardHistoryEntity loadDashBoardDataFromCache(String cacheKey) {
        // 优先查询缓存数据，查询后直接返回给客户端
        return Optional.ofNullable(redisUtil.get(cacheKey)).map(value -> {
            DashBoardHistoryEntity cacheValue = gson.fromJson(value.toString(), DashBoardHistoryEntity.class);
            log.info("[loadDashBoardDataFromCache method] load cache value of current user, cacheKey is {}, cacheValue is {}", cacheKey, gson.toJson(cacheValue));
            return cacheValue;
        }).orElseGet(DashBoardHistoryEntity::new);
    }

    /**
     * 判断31天范围内的目标日期属于当前月还是历史月份
     *
     * @param localDate 目标日期
     * @return true：属于当前月  false：属于历史月份
     */
    public boolean belongCurrentMonth(String localDate) {
        // 传入的日期
        int targetDay = CommonUtil.convertToInt(localDate);
        // 获取31天前的日期
        int agoSomeDays = CommonUtil.convertToInt(DateUtils.getNDaysAgo(31).toString());
        // 获取当前日期
        int currentDay = CommonUtil.convertToInt(DateUtils.getNDaysAgo(0).toString());
        log.info("[belongCurrentMonth method] targetDay is {},agoSomeDays is {},currentDay is {}", targetDay, agoSomeDays, currentDay);
        if (targetDay > currentDay) {
            throw new IllegalArgumentException("错误的目标日期");
        }
        // 获取上个月最后一天
        int lastDayOfLastMonth = CommonUtil.convertToInt(DateUtils.getLastMonthLastDayV1().toString());
        // 传入的日期大于上个月最后一天，则表示为当前月
        return targetDay > lastDayOfLastMonth;
    }

    /**
     * 从缓存中查询柱状图，维护到响应中
     *
     * @param queryReq 请求
     * @param response 响应
     */
    public void appendTurnoverTopList(ClDashBoardCreateQueryReq queryReq, CommissionRecordDashBoardResponse response) {
        String cacheKey = Constants.CURRENT_USER_TURNOVER_TOP_CACHE_PREFIX + queryReq.getAgentAccount();
        log.info("[appendTurnoverTopList method] begin to appendTurnoverTopList,cacheKey is {}", cacheKey);
        CommissionRecordDashBoardResponse cacheValue = Optional.ofNullable(redisUtil.get(cacheKey)).map(v -> gson.fromJson(v.toString(), CommissionRecordDashBoardResponse.class)).
                orElseGet(CommissionRecordDashBoardResponse::new);
//        List<ClTurnoverTopResp> turnoverTopList = cacheValue.getTurnoverTopList();
//        response.setTurnoverTopList(turnoverTopList);
//        log.info("[appendTurnoverTopList method] end to appendTurnoverTopList,turnoverTopList is {}", gson.toJson(turnoverTopList));
    }

}