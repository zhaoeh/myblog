package com.mkt.agent.commission.board.core;

import com.google.gson.Gson;
import com.mkt.agent.commission.mapper.CommissionRecordMapper;
import com.mkt.agent.commission.util.DashBoardV1Utils;
import com.mkt.agent.common.config.DashBoardConfig;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.DashBoardCommissionVo;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * @program: mkt-agent
 * @description: 仪表盘附加任务更新器
 * @author: Erhu.Zhao
 * @create: 2023-12-05 20:55
 */
@Component
@Slf4j
public class DashBoardUpdaterAdditional {

    private static ExecutorService executorService;

    private final Gson gson;

    private final RedisUtil redisUtil;

    private final DashBoardUpdater dashBoardUpdater;

    /**
     * 历史数据补救器
     */
    private final DashBoardHelper dashBoardHelper;

    private final DashBoardV1Utils dashBoardV1Utils;

    private final Integer threadPoolSize;

    private final CommissionRecordMapper commissionRecordMapper;

    public DashBoardUpdaterAdditional(Gson gson, RedisUtil redisUtil,
                                      DashBoardHelper dashBoardHelper,
                                      DashBoardUpdater dashBoardUpdater,
                                      DashBoardV1Utils dashBoardV1Utils,
                                      DashBoardConfig dashBoardConfig,
                                      CommissionRecordMapper commissionRecordMapper) {
        this.gson = gson;
        this.redisUtil = redisUtil;
        this.dashBoardHelper = dashBoardHelper;
        this.dashBoardUpdater = dashBoardUpdater;
        this.dashBoardV1Utils = dashBoardV1Utils;
        this.threadPoolSize = dashBoardConfig.getThreadPoolSize();
        this.commissionRecordMapper = commissionRecordMapper;
    }

    @PostConstruct
    public void initTheadPool() {
        log.info("begin to init thread pool of DashBoardUpdaterAdditional");
        executorService = Executors.newFixedThreadPool(this.threadPoolSize);
        log.info("end to init thread pool of DashBoardUpdaterAdditional, threadPoolSize is {}", this.threadPoolSize);
    }

    /**
     * 更新当前用户佣金缓存
     *
     * @param queryReq
     */
    public void updateDashBoardCacheOfAdditional(ClDashBoardCreateQueryReq queryReq) {
        executorService.execute(() -> {
            try {
                log.info("[updateDashBoardCacheOfAdditional method] 开始异步更新附加数据，请求是 {}", gson.toJson(queryReq));

                // 设置userNameList 如果下级代理用户为空的话，则直接更新缓存为一个空对象
                boolean isUpdateForEmpty = !dashBoardUpdater.setUserNameList(queryReq) ? Boolean.TRUE : Boolean.FALSE;
                log.info("[updateDashBoardCacheOfAdditional method] isUpdateForEmpty is {}", isUpdateForEmpty);

                // 更新当前请求佣金数据
                updateCommission(queryReq, isUpdateForEmpty);
            } catch (Exception e) {
                log.error("[updateDashBoardCacheOfAdditional method] updateDashBoardCacheOfAdditional of asyn caught an exception, e is :", e);
            }
        });
    }

    /**
     * 更新佣金
     *
     * @param queryReq
     * @param isUpdateForEmpty
     * @return
     */
    private void updateCommission(ClDashBoardCreateQueryReq queryReq, boolean isUpdateForEmpty) {
        log.info("开始异步更新当前用户的佣金缓存,当前请求是 {}", gson.toJson(queryReq));
        if (isHistoryMonth(queryReq.getRecordDateStart(), queryReq.getRecordDateEnd())) {
            //上个月 或者 上上个月
            updateHistoryCommission(queryReq);
        } else {
            // 更新实时佣金
            updateRuntimeCommission(queryReq, isUpdateForEmpty);
        }
    }

    /**
     * 更新历史佣金
     */
    private void updateHistoryCommission(ClDashBoardCreateQueryReq queryReq) {
        log.info("[updateRuntimeCommission] 开始异步更新历史佣金缓存（上个月/上上个月）...");
        String agentAccount = queryReq.getAgentAccount();
        String recordDateStart = queryReq.getRecordDateStart();
        String recordDateEnd = queryReq.getRecordDateEnd();
        DashBoardCommissionVo historyCommission = commissionRecordMapper.queryCommissionByNameDate(ClDashBoardCreateQueryReq.builder().agentAccount(agentAccount)
                .recordDateStart(recordDateStart).recordDateEnd(recordDateEnd).build());
        if (Objects.isNull(historyCommission)) {
            historyCommission = DashBoardCommissionVo.builder().commission(BigDecimal.ZERO.setScale(2, RoundingMode.DOWN)).agentAccount(agentAccount).build();
        }
        historyCommission.setRecordDateStart(recordDateStart);
        historyCommission.setRecordDateEnd(recordDateEnd);
        log.info("历史原始佣金数据源（上个月/上上个月）:{}", gson.toJson(historyCommission));
        BigDecimal commission = historyCommission.getCommission();
        String commissionKey = Constants.COMMISSION_CACHE_PREFIX + agentAccount + recordDateStart + recordDateEnd;
        log.info("[updateRuntimeCommission] 历史佣金数据更新:{} 开始时间:{} 结束时间:{} 计算后的佣金:{}", agentAccount, recordDateStart, recordDateEnd, commission);
        redisUtil.setByTimeUnit(commissionKey, Objects.isNull(commission) ? BigDecimal.ZERO : commission, 1, TimeUnit.DAYS);
        log.info("[updateRuntimeCommission] 异步更新历史佣金缓存结束（上个月/上上个月）...");
    }

    /**
     * 更新实时佣金
     *
     * @param queryReq
     * @param isUpdateForEmpty
     * @return
     */
    private void updateRuntimeCommission(ClDashBoardCreateQueryReq queryReq, boolean isUpdateForEmpty) {
        log.info("[updateRuntimeCommission] 开始异步更新实时佣金缓存...");
        DashBoardHistoryEntity responseFromClickHouse = dashBoardUpdater.obtainResponseFromClickHouse(queryReq, isUpdateForEmpty);
        CommissionRecordDashBoardResponse comResponse = dashBoardHelper.generateCopyResponseOfEntity(responseFromClickHouse);
        comResponse.setRecordDateStart(queryReq.getRecordDateStart());
        comResponse.setRecordDateEnd(queryReq.getRecordDateEnd());
        log.info("实时佣金数据来源Clickhouse（非上个月+非上上个月）:{}", gson.toJson(comResponse));
        // 更新缓存时,实时计算佣金
        BigDecimal commission = isUpdateForEmpty ? BigDecimal.ZERO : dashBoardV1Utils.updateCommission(comResponse);
        String commissionKey = Constants.COMMISSION_CACHE_PREFIX + comResponse.getLoginName() + comResponse.getRecordDateStart() + comResponse.getRecordDateEnd();
        log.info("[updateRuntimeCommission] 实时佣金数据更新:{} 开始时间:{} 结束时间:{} 计算后的佣金:{}", comResponse.getLoginName(), comResponse.getRecordDateStart(), comResponse.getRecordDateEnd(), commission);
        redisUtil.setByTimeUnit(commissionKey, Objects.isNull(commission) ? BigDecimal.ZERO : commission, 1, TimeUnit.DAYS);
        log.info("[updateRuntimeCommission] 异步更新实时佣金缓存结束...");
    }

    /**
     * 是否是上个月的请求
     *
     * @param recordDateStart
     * @param recordDateEnd
     * @param firstDayOfLastMonth
     * @param lastDayOfLastMonth
     * @return true：是  false：否
     */
    private boolean isLastMonth(String recordDateStart, String recordDateEnd, String firstDayOfLastMonth, String lastDayOfLastMonth) {
        return firstDayOfLastMonth.equals(recordDateStart) && lastDayOfLastMonth.equals(recordDateEnd);
    }

    /**
     * 是否是上上个月的请求
     *
     * @param recordDateStart
     * @param recordDateEnd
     * @param firstDayOfLast2Month
     * @param lastDayOfLast2Month
     * @return true：是 false：否
     */
    private boolean isLast2Month(String recordDateStart, String recordDateEnd, String firstDayOfLast2Month, String lastDayOfLast2Month) {
        return firstDayOfLast2Month.equals(recordDateStart) && lastDayOfLast2Month.equals(recordDateEnd);
    }

    /**
     * 是否是历史月份请求
     *
     * @param recordDateStart
     * @param recordDateEnd
     * @return
     */
    private boolean isHistoryMonth(String recordDateStart, String recordDateEnd) {
        String firstDayOfLastMonth = DateUtils.getLastNMonthFirstDay(1).toString();
        String lastDayOfLastMonth = DateUtils.getLastNMonthLastDay(1).toString();
        String firstDayOfLast2Month = DateUtils.getLastNMonthFirstDay(2).toString();
        String lastDayOfLast2Month = DateUtils.getLastNMonthLastDay(2).toString();
        log.info("recordDateStart is {},recordDateEnd is {},firstDayOfLastMonth is {}," +
                        "lastDayOfLastMonth is {},firstDayOfLast2Month is {},lastDayOfLast2Month is {}",
                recordDateStart, recordDateEnd, firstDayOfLastMonth, lastDayOfLastMonth, firstDayOfLast2Month, lastDayOfLast2Month);
        return isLastMonth(recordDateStart, recordDateEnd, firstDayOfLastMonth, lastDayOfLastMonth) ||
                isLast2Month(recordDateStart, recordDateEnd, firstDayOfLast2Month, lastDayOfLast2Month);
    }

}