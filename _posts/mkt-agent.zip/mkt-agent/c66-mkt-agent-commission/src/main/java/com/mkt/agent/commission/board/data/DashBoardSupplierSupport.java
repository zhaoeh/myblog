package com.mkt.agent.commission.board.data;

import com.google.gson.Gson;
import com.mkt.agent.commission.board.core.DashBoardHelper;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverTopResp;
import com.mkt.agent.common.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Optional;

/**
 * @program: mkt-agent
 * @description: dash board 中间层
 * @author: Erhu.Zhao
 * @create: 2023-12-06 18:47
 */
@Slf4j
public abstract class DashBoardSupplierSupport implements DashBoardSupplier {

    protected final Gson gson;

    protected final DashBoardHelper dashBoardHelper;

    protected final RedisUtil redisUtil;

    protected DashBoardSupplierSupport(Gson gson, DashBoardHelper dashBoardHelper, RedisUtil redisUtil) {
        this.gson = gson;
        this.dashBoardHelper = dashBoardHelper;
        this.redisUtil = redisUtil;
    }

}