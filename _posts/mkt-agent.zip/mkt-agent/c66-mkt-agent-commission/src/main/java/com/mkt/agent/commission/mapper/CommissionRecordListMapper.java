package com.mkt.agent.commission.mapper;

import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordListRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordListResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.sum.CommissionRecordListSumResponse;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CommissionRecordListMapper {


    List<CommissionRecordListResponse> queryByPageAndCondition(CommissionRecordListRequest rq);


    CommissionRecordListSumResponse queryByPageAndConditionSum(CommissionRecordListRequest rq);

    Long countQueryByPageAndCondition(CommissionRecordListRequest rq);

}
