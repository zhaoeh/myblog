package com.mkt.agent.commission.board.data;

import com.google.gson.Gson;
import com.mkt.agent.commission.board.core.DashBoardHelper;
import com.mkt.agent.commission.board.core.DashBoardUpdateLimiter;
import com.mkt.agent.commission.mapper.HistoryAgentDashboardDailyMapper;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * @program: mkt-agent
 * @description: 仪表盘历史数据供应者（根据条件查询两张历史表，优先查询表1：t_agent_dashboard ，如果表1不存在区间内数据，则查询表2：t_agent_dashboard_daily_history，查询完成后重新计算佣金后存入表1）
 * @author: Erhu.Zhao
 * @create: 2023-12-05 13:59
 */
@Slf4j
@Component
public class HistoryDataDashBoardSupplier extends DashBoardSupplierSupport {

    private final HistoryAgentDashboardDailyMapper historyAgentDashboardDailyMapper;

    private final Gson gson;

    protected HistoryDataDashBoardSupplier(HistoryAgentDashboardDailyMapper historyAgentDashboardDailyMapper,
                                           DashBoardHelper dashBoardHelper, Gson gson, RedisUtil redisUtil) {
        super(gson, dashBoardHelper, redisUtil);
        this.historyAgentDashboardDailyMapper = historyAgentDashboardDailyMapper;
        this.gson = gson;
    }

    @Override
    public String strategy() {
        return Constants.HISTORY_DATA;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public CommissionRecordDashBoardResponse loadDashBoardData(ClDashBoardCreateQueryReq queryReq) {
        log.info("[loadDashBoardData method] begin to loadDashBoardData in HistoryDataDashBoardSupplier class,queryReq is {}", gson.toJson(queryReq));
        CommissionRecordDashBoardResponse historyData = doLoadDashBoardData(queryReq, Collections.emptyMap());
        // 拼接柱状图
//        dashBoardHelper.appendTurnoverTopList(queryReq, historyData);

        log.info("[loadDashBoardData method] begin to loadDashBoardData in HistoryDataDashBoardSupplier class,historyData is {}", gson.toJson(historyData));
        return historyData;
    }

    @Override
    public CommissionRecordDashBoardResponse loadTurnoverData(ClDashBoardCreateQueryReq queryReq) {
        log.info("[loadTurnoverData method] begin to loadTurnoverData in HistoryDataDashBoardSupplier class,request is {}", gson.toJson(queryReq));
        CommissionRecordDashBoardResponse historyData = doLoadDashBoardData(queryReq, Map.of("queryTurnover", "true"));
        log.info("[loadTurnoverData method] begin to loadTurnoverData in HistoryDataDashBoardSupplier class,historyData is {}", gson.toJson(historyData));
        return historyData;
    }

    /**
     * 执行加载DashBoard数据
     *
     * @param queryReq 业务请求
     * @return
     */
    private CommissionRecordDashBoardResponse doLoadDashBoardData(ClDashBoardCreateQueryReq queryReq, Map<String, String> append) {
        if (Objects.isNull(queryReq)) {
            return new CommissionRecordDashBoardResponse();
        }
        return doHistoryTwo(queryReq, append);
    }

    /**
     * 查询第二张历史表 t_agent_dashboard_daily_history 后，聚合结果计算佣金后，存入t_agent_dashboard表
     *
     * @param queryReq 查询参数
     * @return 聚合并计算佣金后的返回结果
     */
    private CommissionRecordDashBoardResponse doHistoryTwo(ClDashBoardCreateQueryReq queryReq, Map<String, String> append) {
        return dashBoardHelper.summarizeDiscreteData(secondQuery(queryReq, append));
    }

    /**
     * 查询表2： t_agent_dashboard_daily_history，统计当前用户每天的历史数据（以天为维度，每个用户每天的历史汇总数据），每天的汇总数据，没有计算佣金
     *
     * @param queryReq 请求参数
     */
    public List<DashBoardHistoryEntity> secondQuery(ClDashBoardCreateQueryReq queryReq, Map<String, String> append) {
        log.info("[secondQuery method] begin to secondQuery, queryReq is {}", gson.toJson(queryReq));
        List<DashBoardHistoryEntity> list = historyAgentDashboardDailyMapper.loadHistoryDashBoardDailyData(queryReq, append);
        log.info("[secondQuery method] end to secondQuery, list size is {}", Optional.ofNullable(list).map(List::size).orElse(0));
        return list;
    }

}