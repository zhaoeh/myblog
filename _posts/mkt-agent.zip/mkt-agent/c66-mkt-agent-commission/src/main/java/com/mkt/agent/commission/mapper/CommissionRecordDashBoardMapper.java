package com.mkt.agent.commission.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CommissionRecordDashBoardMapper extends BaseMapper<CommissionRecordDashBoardResponse> {



}
