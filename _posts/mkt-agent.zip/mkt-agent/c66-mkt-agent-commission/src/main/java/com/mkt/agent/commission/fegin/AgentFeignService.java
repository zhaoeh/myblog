package com.mkt.agent.commission.fegin;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TAgentGlobalConfigEntity;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.TAgentUpdateLog;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerContractQueryByPageRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomerQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerContractQueryByPageResponse;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerQueryResponse;
import com.mkt.agent.common.entity.api.fund.req.FundTradeReq;
import com.mkt.agent.common.entity.api.fund.req.FundTransferReq;
import io.swagger.annotations.ApiOperation;
import org.apache.ibatis.annotations.Param;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

//@FeignClient(name = "${feign.mkt-agent-api}", url = "127.0.0.1:8091")
@FeignClient(name = "${feign.mkt-agent-api}")
public interface AgentFeignService {

    @PostMapping("/agent_for_commission/queryAllSameLevelByPage")
    Result<Page<AgentCustomerContractQueryByPageResponse>> queryListByPageAndCondition(@RequestBody AgentCustomerContractQueryByPageRequest req);

    @PostMapping("/fund/deposit")
    Result<Boolean> callback(@RequestBody FundTradeReq req);

    @PostMapping("/fund/transfer")
    Result<Boolean> transfer(@RequestBody FundTransferReq req);

    @PostMapping(value = "/apiAgent/getOne")
    Result<AgentCustomerQueryResponse> getOne(@RequestBody AgentCustomerQueryRequest req);

    @GetMapping(value ="/agentCustomers/one/byName")
    Result<TAgentCustomers> getAgentByLoginName(@RequestParam(value = "loginName")String loginName);

    @GetMapping(value ="/agentCustomers/queryTopAgent")
    Result<TAgentCustomers> queryTopAgent(@RequestParam(value = "customerId")Long customerId);

    @GetMapping(value ="/agentCustomers/queryTopAgentByAccount")
    Result<TAgentCustomers> queryTopAgentByAccount(@RequestParam(value = "account")String account);

    @PostMapping(value ="/global/config/getValuesByName")
    Result<List<TAgentGlobalConfigEntity>> queryGlobalConfig(@RequestBody List<String> names);

    @PostMapping(value ="/agentContract/queryRealContractByLoginName")
    Result<TAgentContract> queryRealContractByLoginName(@RequestParam(value = "loginName")String loginName);

    @PostMapping(value ="/agentContract/queryContractByLoginName")
    Result<TAgentContract> queryContractByLoginName(@RequestParam(value = "loginName")String loginName);

    @PostMapping(value ="/agent_update/getFrashBaName")
    Result<TAgentUpdateLog> getFrashAgentUpdateLogByName(@RequestParam("loginName")String loginName);

    @PostMapping(value ="/agent_update/updateBaName")
    void updateAgentUpdateLogByName(@RequestParam("loginName")String loginName);

    @PostMapping(value = "/agentContractBind/queryContractBindByName")
    Result<TAgentContractBind> queryContractBindByName(@RequestParam("loginName")String loginName);
}
