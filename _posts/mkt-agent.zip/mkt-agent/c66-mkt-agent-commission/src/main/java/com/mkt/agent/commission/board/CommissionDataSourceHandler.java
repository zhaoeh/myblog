package com.mkt.agent.commission.board;

import com.mkt.agent.ds.finder.DataSourceHandler;
import com.mkt.agent.ds.finder.DataSourceRequest;
import com.mkt.agent.ds.finder.DataSourceResponse;
import com.mkt.agent.ds.finder.DataSourceType;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordDashBoardRequest;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-01-19
 **/
@Component
public class CommissionDataSourceHandler implements DataSourceHandler {
    @Override
    public List<DataSourceRequest> handleRequestWithDataSource(Object[] args) {
        List<DataSourceRequest> requests = new ArrayList<>();
        DataSourceRequest request1 = new DataSourceRequest();
        request1.setDataSourceType(DataSourceType.ByteHouse);
        CommissionRecordDashBoardRequest newRequest = new CommissionRecordDashBoardRequest();
        args[0] = newRequest;
        request1.setNewRequest(args);
        requests.add(request1);
        return requests;
    }

    @Override
    public Object handleResponseWithDataSource(List<DataSourceResponse> dataSourceResponses) {
        return null;
    }
}
