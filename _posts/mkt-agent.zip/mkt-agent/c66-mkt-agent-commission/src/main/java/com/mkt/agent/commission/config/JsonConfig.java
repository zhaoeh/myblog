package com.mkt.agent.commission.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @program: mkt-agent
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-12-06 11:47
 */
@Configuration
public class JsonConfig {

    @Bean
    public Gson gson() {
        return new Gson();
    }

    @Bean
    public ObjectMapper objectMapper() {
        return new ObjectMapper();
    }
}