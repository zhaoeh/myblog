package com.mkt.agent.commission.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractList;
import org.apache.ibatis.annotations.Mapper;

import java.util.Map;

@Mapper
public interface TAgentContractListMapper extends BaseMapper<TAgentContractList> {


}
