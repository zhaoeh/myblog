package com.mkt.agent.commission.util;

import com.google.common.collect.Lists;

import com.google.gson.Gson;
import com.mkt.agent.commission.clickhouse.mapper.DashBoardV1Mapper;
import com.mkt.agent.commission.fegin.AgentFeignService;
import com.mkt.agent.commission.fegin.UserFeignService;
import com.mkt.agent.commission.mapper.CommissionRecordMapper;
import com.mkt.agent.common.config.DashBoardConfig;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.TAgentUpdateLog;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.entity.clickhouse.req.DashBoardUserTreeQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverDistriResp;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverTopResp;
import com.mkt.agent.common.entity.clickhouse.resp.DashBoardBetPlayersVo;
import com.mkt.agent.common.enums.AgentUpdateLogEnum;
import com.mkt.agent.common.enums.CommissionPlanTypeEnum;
import com.mkt.agent.common.utils.DashBoardCommonUtil;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.SerializationUti;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @Description 获取dashBoard数据
 * @Classname DashBoardUtils
 * @Date 2023/12/5 13:59
 * @Created by TJSLucian
 */
@Component
@Slf4j
@RefreshScope
public class DashBoardV1Utils {

    @Resource
    private AgentFeignService agentFeignService;

    @Resource
    private UserFeignService userFeignService;

    @Autowired
    private DashBoardConfig dashBoardConfig;

    @Resource
    private DashBoardV1Mapper dashBoardV1Mapper;

    @Resource
    private DashBoardCommonUtil dashBoardCommonUtil;

    @Resource
    private Gson gson;


    @Transactional
    public DashBoardHistoryEntity getDashBoardResFromCl(ClDashBoardCreateQueryReq queryReq){

        DashBoardHistoryEntity response = null;

        if (queryReq.getLoginNameList().size() <= dashBoardConfig.getBatchQuerySize()) {
            response = dashBoardV1Mapper.queryDashBoardDataByPlural(queryReq);
        } else {

            List<List<String>> batches = Lists.partition(queryReq.getLoginNameList(), dashBoardConfig.getBatchQuerySize());

            Set<ClDashBoardCreateQueryReq> batchQuerys = batches.stream().map(b -> ClDashBoardCreateQueryReq.builder()
                    .loginNameList(b).recordDateStart(queryReq.getRecordDateStart()).recordDateEnd(queryReq.getRecordDateEnd())
                    .build()).collect(Collectors.toSet());

            response = batchQuerys.stream().map(q -> dashBoardV1Mapper.queryDashBoardDataByPlural(q))
                    .reduce((source,increment) -> dashBoardCommonUtil.sumDataResultV2(source,increment)).orElseGet(DashBoardHistoryEntity::new);

        }

        Result<Long> registerUserResult = userFeignService.selectUserTreeByParentNTimeCount(new DashBoardUserTreeQueryReq(queryReq.getAgentAccount(),queryReq.getRecordDateTimeStart(),queryReq.getRecordDateTimeEnd()));

        if(Objects.isNull(response)){
            if(!registerUserResult.isSuccess() || Objects.isNull(registerUserResult.getData()) || registerUserResult.getData() == 0){
                return null;
            }
        }

        response.setLoginName(queryReq.getAgentAccount());
        response.setParentLoginName(queryReq.getParentAgentAccount());
        response.setRegistrationNumber(registerUserResult.isSuccess()&&Objects.isNull(registerUserResult.getData())?0L:registerUserResult.getData());

        return response;

    }


    public List<ClTurnoverTopResp> turnoverTop(ClDashBoardCreateQueryReq queryReq) {

        log.info("/DashBoardV1Utils/turnoverTop 入参loginName：{}", queryReq.getAgentAccount());

        try {

            List<String> userNameList = queryReq.getLoginNameList();

            if (userNameList.size() <= dashBoardConfig.getBatchQuerySize()) {
                return dashBoardV1Mapper.topList(queryReq);
            } else{
                List<List<String>> batches = Lists.partition(userNameList, dashBoardConfig.getBatchQuerySize());

                Set<ClDashBoardCreateQueryReq> batchQuerys = batches.stream().map(b -> ClDashBoardCreateQueryReq.builder()
                        .loginNameList(b)
                        .build()).collect(Collectors.toSet());

                List<ClTurnoverTopResp> turnoverTopList = batchQuerys.stream().map(q -> dashBoardV1Mapper.topList(q))
                        .reduce((d1,d2) -> {
                            d1 = Stream.concat(d1.stream(),d2.stream())
                                    .sorted((t1,t2) -> t2.getTurnoverSum().compareTo(t1.getTurnoverSum()))
                                    .limit(10)
                                    .collect(Collectors.toList());
                            return d1;
                        }).orElse(Collections.emptyList());
                return turnoverTopList;
            }

        }catch (Exception e){
            log.error("Failed to handle turnoverTop for agent:{}!",queryReq.getAgentAccount(),e);
        }
        return null;
    }

    public List<ClTurnoverDistriResp> turnoverDistri(ClDashBoardCreateQueryReq queryReq) {

        log.info("/DashBoardV1Utils/turnoverDistri 入参loginName：{}", queryReq.getAgentAccount());

        try {

            List<String> userNameList = queryReq.getLoginNameList();

            if (userNameList.size() <= dashBoardConfig.getBatchQuerySize()) {
                return dashBoardV1Mapper.distriList(queryReq);
            } else{
                List<List<String>> batches = Lists.partition(userNameList, dashBoardConfig.getBatchQuerySize());

                Set<ClDashBoardCreateQueryReq> batchQuerys = batches.stream().map(b -> ClDashBoardCreateQueryReq.builder()
                        .loginNameList(b)
                        .build()).collect(Collectors.toSet());

                List<ClTurnoverDistriResp> turnoverDistriList = batchQuerys.stream().map(q -> dashBoardV1Mapper.distriList(q))
                        .reduce((l1, l2) -> Stream.concat(l1.stream(), l2.stream()).collect(Collectors.toList())).orElse(Collections.emptyList());

                return turnoverDistriList;
            }

        }catch (Exception e){
            log.error("Failed to handle turnoverDistri for agent:{}!",queryReq.getAgentAccount(),e);
        }
        return null;
    }

    public Long updateBetPlayers(ClDashBoardCreateQueryReq queryReq){

        if(Objects.isNull(queryReq) || Objects.isNull(queryReq.getAgentAccount()) || Objects.isNull(queryReq.getRecordDateStart())){
            return null;
        }

        log.info("[DashBoardV1Utils-updateBetPlayers]Begin to update betPlayers for agent:{} from: {} to: {}",queryReq.getLoginNameList(),queryReq.getRecordDateStart(),queryReq.getRecordDateEnd());

        String agentAccount = queryReq.getAgentAccount();

        return doHandleBetPlayers(agentAccount,queryReq.getRecordDateStart(),queryReq.getRecordDateEnd());

    }

    private Long doHandleBetPlayers(String agentAccount, String recordDateStart, String recordDateEnd){

        log.info("doHandleBetPlayers for agent:{}, The params is recordDateStart:{},recordDateEnd:{}",agentAccount,recordDateStart.toString(),recordDateEnd.toString());

        try {
            Result<List<TCustomerLayer>> agentTeamResult = userFeignService.selectUserTreeByParentNTime(DashBoardUserTreeQueryReq.builder().parent(agentAccount).build());


            if(agentTeamResult.isSuccess()&&!Objects.isNull(agentTeamResult.getData())){

                List<TCustomerLayer> agentTeam = agentTeamResult.getData();
                List<String> agentTeamNames = agentTeam.stream().map(a -> a.getLoginName()).collect(Collectors.toList());
                Long betPlayers = 0L;
                if(!CollectionUtils.isEmpty(agentTeam)){
                    betPlayers = this.getBetPlayersFromCl(ClDashBoardCreateQueryReq.builder().agentAccount(agentAccount).loginNameList(agentTeamNames).recordDateStart(recordDateStart)
                            .recordDateEnd(recordDateEnd).build());
                }

                if(null!=betPlayers && betPlayers > 0L){
                    return betPlayers;
                }
                log.info("[doHandleBetPlayers]The betPlayers for agent:{} from {} to {}  is:{} ", agentAccount,recordDateStart,recordDateEnd,betPlayers);
            }
        }catch (Exception e){
            log.error("[doHandleBetPlayers]Failed to update betPlayers for agent:{}",agentAccount,e);
        }

        return null;

    }

    private Long getBetPlayersFromCl(ClDashBoardCreateQueryReq queryReq){
        if(Objects.isNull(queryReq) || CollectionUtils.isEmpty(queryReq.getLoginNameList())){
            return null;
        }

        log.info("Begin to query BetPlayers for agent:{}",queryReq.getAgentAccount());

        List<String> userNames = queryReq.getLoginNameList();

        if (userNames.size() <= dashBoardConfig.getBatchQuerySize()) {
            return dashBoardV1Mapper.getBetPlayersFromCl(queryReq);
        } else {

            List<List<String>> batches = Lists.partition(userNames, dashBoardConfig.getBatchQuerySize());

            Set<ClDashBoardCreateQueryReq> batchQuerys = batches.stream().map(b -> ClDashBoardCreateQueryReq.builder()
                    .loginNameList(b).recordDateStart(queryReq.getRecordDateStart()).recordDateEnd(queryReq.getRecordDateEnd())
                    .build()).collect(Collectors.toSet());

            Long response = batchQuerys.stream().map(q -> dashBoardV1Mapper.getBetPlayersFromCl(q)).filter(a -> !Objects.isNull(a))
                    .reduce((r1, r2) -> r1 + r2).orElse(0L);
            return response;
        }
    }


    public BigDecimal updateCommission(CommissionRecordDashBoardResponse entity) {

        String agentAccount =entity.getLoginName();
        try {

            //第1步： 调用agent-api服务 获取1级代理
            Result<TAgentCustomers> topAgentResult = agentFeignService.queryTopAgentByAccount(agentAccount);

            //1级代理
            TAgentCustomers topAgent = topAgentResult.getData();

            //第二步：获取1级代理的佣金方案
            //查询代理方案
            Result<TAgentContract> agentContractResult = agentFeignService.queryContractByLoginName(agentAccount);

            TAgentContract topContract = agentContractResult.getData();

            //所有团队用户
            List<String> userNameTopList = null;
            //第三步：判断是否设置条件
            if (topContract.getSettlementConditions() == 1) {
                log.info("The agent:{} has condition",agentAccount);
                //如果设置了条件，计算佣金时需要计算是否满足条件 调用user服务 查询1级代理的所有下级用户
                DashBoardUserTreeQueryReq queryTopEntity = new DashBoardUserTreeQueryReq();
                queryTopEntity.setParent(topAgent.getLoginName());
                Result<List<TCustomerLayer>> userListTopResult = userFeignService.selectUserTreeByParentNTime(queryTopEntity);
                if (userListTopResult.isSuccess() && !Objects.isNull(userListTopResult.getData()) && userListTopResult.getData().size() > 0) {
                    userNameTopList = userListTopResult.getData().stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList());

                    ClDashBoardCreateQueryReq queryTopReq = ClDashBoardCreateQueryReq.builder().recordDateStart(entity.getRecordDateStart()).recordDateEnd(entity.getRecordDateEnd()).loginNameList(userNameTopList)
                            .activeAmount(topContract.getActiveUserTurnover()).build();
                    Long count = 0L;
                    count = this.queryTurnoverActivePlayerCount(queryTopReq);
                    log.info("Active count is :{}",count);

                    if(count < topContract.getActiveUserHeadcount()){
                        log.info("The active count is not enough!");
                        return BigDecimal.ZERO.setScale(2,RoundingMode.DOWN);
                    }

                }
            }
            Result<TAgentContractBind> bindResult = agentFeignService.queryContractBindByName(agentAccount);
            //第四步：计算佣金
            BigDecimal commission = calculateCommission(entity, topContract, bindResult.getData());

            log.info("After calculateCommission the response is:{}",commission);
            return commission;
        }catch (Exception e){
            log.info("Failed to calculateCommission for agent:{}",agentAccount,e);
        }
        return null;
    }

    private BigDecimal calculateCommission(CommissionRecordDashBoardResponse dashBoardResponse,TAgentContract tAgentContract,TAgentContractBind bind){

        log.info("Begin to calculateCommission for agent:{} from :{} to :{}",dashBoardResponse.getLoginName(),dashBoardResponse.getRecordDateStart(),dashBoardResponse.getRecordDateEnd());

        List<SettlementPercentageReq> settlementPercentageList = SerializationUti.deserializeFromString(bind.getPercentageDetails(), SettlementPercentageReq.class);

        //佣金比例 暂时选择第一阶段
        SettlementPercentageReq percentageReq = settlementPercentageList.get(0);

        //佣金费率 选择 allGameType
        BigDecimal commissionValue = new BigDecimal(String.valueOf(percentageReq.getAllGamesPercentage())).divide(new BigDecimal(100));

        //根据佣金方案来计算
        String commissionType = tAgentContract.getCommissionPlanType();
        log.info("commission informaiont for agent:{} : the type is :{}, the data is:{}",dashBoardResponse.getLoginName(),commissionType,gson.toJson(dashBoardResponse));

        if(commissionType.equals(CommissionPlanTypeEnum.TURNOVER.getCode())){
            return dashBoardResponse.getTurnover().multiply(commissionValue).setScale(2, RoundingMode.DOWN);

        }else if(commissionType.equals(CommissionPlanTypeEnum.GGR.getCode())){
            if(dashBoardResponse.getGgr().compareTo(BigDecimal.ZERO)>=0){
                return dashBoardResponse.getGgr().multiply(commissionValue).setScale(2, RoundingMode.DOWN);
            }else {
                return BigDecimal.ZERO.setScale(2);
            }

        }else {
            return BigDecimal.ZERO.setScale(2);
        }

    }

    private Long queryTurnoverActivePlayerCount(ClDashBoardCreateQueryReq queryReq) {

        if (queryReq.getLoginNameList().size() <= dashBoardConfig.getBatchQuerySize()) {
            return dashBoardV1Mapper.queryTurnoverActivePlayerCount(queryReq);
        } else {

            List<List<String>> batches = Lists.partition(queryReq.getLoginNameList(), dashBoardConfig.getBatchQuerySize());

            Set<ClDashBoardCreateQueryReq> batchQuerys = batches.stream().map(b -> ClDashBoardCreateQueryReq.builder()
                    .loginNameList(b).recordDateStart(queryReq.getRecordDateStart()).recordDateEnd(queryReq.getRecordDateEnd()).activeAmount(queryReq.getActiveAmount())
                    .build()).collect(Collectors.toSet());

            Long response = batchQuerys.stream().map(q -> dashBoardV1Mapper.queryTurnoverActivePlayerCount(q))
                    .reduce((r1,r2) -> {
                        r1 = r1 + r2;
                        return r1;}).orElse(0L);
            return response;
        }
    }


    public boolean isAgentChanged(String loginName){

        Result<TAgentUpdateLog> logResult = agentFeignService.getFrashAgentUpdateLogByName(loginName);
        if(logResult.isSuccess()&&!Objects.isNull(logResult.getData())){
            log.info("The agent:{} has been changed!",loginName);
            return true;
        }
        return false;
    }

    public void makeAgentChanged(String loginName){

        agentFeignService.updateAgentUpdateLogByName(loginName, AgentUpdateLogEnum.DASHBOARD.getType());
        log.info("The agent:{}'s data has been updated!",loginName);
    }

}
