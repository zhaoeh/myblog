package com.mkt.agent.commission.board.core;

import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.utils.DateUtils;

/**
 * @program: mkt-agent
 * @description: 仪表盘数据缓存key构建器
 * @author: Erhu.Zhao
 * @create: 2023-12-06 10:37
 */
public class DashBoardCacheKeyBuilder {

    public static String key(String userName, String currentDataStr) {
        return Constants.CURRENT_USER_DASH_BOARD_CACHE_PREFIX + userName + currentDataStr;
    }

    public static String key(ClDashBoardCreateQueryReq request, String currentDataStr) {
        return key(request.getAgentAccount(), currentDataStr);
    }

    public static String key(ClDashBoardCreateQueryReq request) {
        return key(request, DateUtils.getNDaysAgo(0).toString());
    }

    public static String repairKey(ClDashBoardCreateQueryReq request) {
        return Constants.CURRENT_USER_DASH_BOARD_REPAIR_CACHE_PREFIX + request.getAgentAccount();
    }
}