package com.mkt.agent.commission.board.core;

import com.google.gson.Gson;
import com.mkt.agent.commission.fegin.UserFeignService;
import com.mkt.agent.commission.util.DashBoardV1Utils;
import com.mkt.agent.common.config.DashBoardConfig;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.entity.clickhouse.req.DashBoardUserTreeQueryReq;
import com.mkt.agent.common.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @program: mkt-agent
 * @description: 仪表盘更新器
 * @author: Erhu.Zhao
 * @create: 2023-12-05 20:55
 */
@Component
@Slf4j
public class DashBoardUpdater {

    public static final String OLD_REQUEST = "old_request";

    private static ExecutorService executorService;

    private final Gson gson;

    private final RedisUtil redisUtil;

    private final DashBoardCommonUtil dashBoardCommonUtil;

    /**
     * 历史数据补救器
     */
    private final HistoryDataRepair historyDataRepair;

    private final DashBoardHelper dashBoardHelper;

    private final UserFeignService userFeignService;

    private final DashBoardV1Utils dashBoardV1Utils;

    private final Integer threadPoolSize;

    public DashBoardUpdater(Gson gson, RedisUtil redisUtil,
                            DashBoardCommonUtil dashBoardCommonUtil,
                            HistoryDataRepair historyDataRepair,
                            DashBoardHelper dashBoardHelper,
                            UserFeignService userFeignService,
                            DashBoardV1Utils dashBoardV1Utils,
                            DashBoardConfig dashBoardConfig) {
        this.gson = gson;
        this.redisUtil = redisUtil;
        this.dashBoardCommonUtil = dashBoardCommonUtil;
        this.historyDataRepair = historyDataRepair;
        this.dashBoardHelper = dashBoardHelper;
        this.userFeignService = userFeignService;
        this.dashBoardV1Utils = dashBoardV1Utils;
        this.threadPoolSize = dashBoardConfig.getThreadPoolSize();
    }

    @PostConstruct
    public void initTheadPool() {
        log.info("begin to init thread pool of DashBoardUpdater");
        // 初始化单例线程池，确保始终只有一个线程连接clickHouse
        // 2024-01-12: 修改为10个线程，因为clickHouse之前通过代理服务器转发，导致连接数释放不及时；现在改为直连clickHouse，因此可以适当增加并发线程数
        executorService = Executors.newFixedThreadPool(this.threadPoolSize);
        log.info("end to init thread pool of DashBoardUpdater, threadPoolSize is {}", this.threadPoolSize);
    }

    public void updateDashBoardCache(ClDashBoardCreateQueryReq queryReq) {

        executorService.execute(() -> {
            try {

                log.info("[updateDashBoardCache method] begin to updateDashBoardCache of asyn");

                // 设置userNameList 如果下级代理用户为空的话，则直接更新缓存为一个空对象
                boolean isUpdateForEmpty = !setUserNameList(queryReq) ? Boolean.TRUE : Boolean.FALSE;
                log.info("[updateDashBoardCache method] isUpdateForEmpty is {}", isUpdateForEmpty);

                // 调用clickHouse缓存柱状图
//                cacheTurnoverTop(queryReq, isUpdateForEmpty);

                // 更新当前用户当天缓存
                updateCurrentDayCache(queryReq, isUpdateForEmpty);

                // 如果代理关系发生变更，更新当前用户当月1号至昨日的缓存
                // toDo:测试完毕需要注释掉
                updateCurrentBeforeCacheOfRelationChange(queryReq, isUpdateForEmpty);

                // 更新当前用户汇总数据的投注人数
                updateBetPlayers(queryReq);

                // 补救
                historyDataRepair.repair(queryReq, isUpdateForEmpty);
                log.info("[updateDashBoardCache method] end to updateDashBoardCache and connect clickHouse of asyn");
            } catch (Exception e) {
                log.error("[updateDashBoardCache method] updateDashBoardCache of asyn caught an exception, e is :", e);
            }
        });
    }

    /**
     * 更新当前用户汇总记录中的投注人数
     *
     * @param queryReq
     */
    private void updateBetPlayers(ClDashBoardCreateQueryReq queryReq) {
        String key = Constants.BETPLAYERS_CACHE_PREFIX + queryReq.getAgentAccount() + queryReq.getRecordDateStart() + queryReq.getRecordDateEnd();
        Long betPlayers = dashBoardV1Utils.updateBetPlayers(queryReq);
        if (Objects.isNull(betPlayers)) {
            log.error("从clickHouse查询的 betPlayers 为 null，跳过缓存更新");
            return;
        }
        redisUtil.setByTimeUnit(key, betPlayers.toString(), 1, TimeUnit.DAYS);
    }


    /**
     * 判断当前用户代理关系是否发生变更
     *
     * @param queryReq 请求
     * @return 结果 true: 当前用户代理关系发生变更 false: 当前用户代理关系未发生变更
     */
    private boolean isAgentRelationChange(ClDashBoardCreateQueryReq queryReq) {
        String loginName = queryReq.getAgentAccount();
        boolean isAgentRelationChange = dashBoardV1Utils.isAgentChanged(loginName);
        dashBoardV1Utils.makeAgentChanged(loginName);
        log.info("[isAgentRelationChange method] begin to run isAgentRelationChange, current user is {}, isAgentRelationChange is {}", loginName, isAgentRelationChange);
        return isAgentRelationChange;
    }

    /**
     * 更新某一天缓存
     */
    public void updateDailyCache(ClDashBoardCreateQueryReq queryReq, boolean isUpdateForEmpty) {
        DashBoardHistoryEntity responseFromClickHouse = obtainResponseFromClickHouse(queryReq, isUpdateForEmpty);
        // 更新缓存
        dashBoardCommonUtil.saveRedisForDashBoard(List.of(responseFromClickHouse));
    }

    /**
     * 连接clickHouse查询当前用户指定时间区间的数据
     *
     * @param queryReq 请求
     * @return 响应
     */
    public DashBoardHistoryEntity obtainResponseFromClickHouse(ClDashBoardCreateQueryReq queryReq, boolean isUpdateForEmpty) {
        DashBoardHistoryEntity responseFromClickHouse = isUpdateForEmpty ? new DashBoardHistoryEntity() : dashBoardV1Utils.getDashBoardResFromCl(queryReq);
        log.info("[updateDailyCache method] responseFromClickHouse is {}", gson.toJson(responseFromClickHouse));
        responseFromClickHouse.setDashDate(queryReq.getRecordDateStart());
        responseFromClickHouse.setLoginName(queryReq.getAgentAccount());
        responseFromClickHouse.setParentLoginName(queryReq.getParentAgentAccount());
        return responseFromClickHouse;
    }

    /**
     * 更新月初至当天之前的缓存
     *
     * @param queryReq 请求
     */
    public void updateCurrentBeforeCacheOfRelationChange(ClDashBoardCreateQueryReq queryReq, boolean isUpdateForEmpty) {
        if (isAgentRelationChange(queryReq)) {
            updateCurrentBeforeCache(queryReq, isUpdateForEmpty);
        }
    }

    /**
     * 更新当天的缓存
     *
     * @param queryReq 请求
     */
    public void updateCurrentDayCache(ClDashBoardCreateQueryReq queryReq, boolean isUpdateForEmpty) {
        log.info("[updateCurrentDayCache method] begin to updateCurrentDayCache.request is {}", queryReq);
        // 当天日期
        List<String> dateRangeAsStr = List.of(DateUtils.getNDaysAgo(0).toString());
        updateCacheOfDays(dateRangeAsStr, queryReq, isUpdateForEmpty);
        log.info("[updateCurrentDayCache method] end to updateCurrentDayCache.");
    }

    /**
     * 更新月初1号至昨日的缓存
     *
     * @param queryReq 请求
     */
    public void updateCurrentBeforeCache(ClDashBoardCreateQueryReq queryReq, boolean isUpdateForEmpty) {
        log.info("[updateCurrentBeforeCache method] begin to updateCurrentBeforeCache.");
        // 当前月份1号到昨日的区间
        List<String> dateRangeAsStr = DateUtils.getDateRangeAsStr(DateUtils.getLastNMonthFirstDay(0), DateUtils.getNDaysAgo(1));
        updateCacheOfDays(dateRangeAsStr, queryReq, isUpdateForEmpty);
        log.info("[updateCurrentBeforeCache method] end to updateCurrentBeforeCache.");
    }

    /**
     * 迭代更新某个时间段内的缓存数据
     *
     * @param days    时间段，以天为单位
     * @param request 请求对象
     */
    public void updateCacheOfDays(List<String> days, ClDashBoardCreateQueryReq request, boolean isUpdateForEmpty) {
        log.info("[updateCacheOfDays method] begin to updateCacheOfDays,days is {}", gson.toJson(days));
        if (CollectionUtils.isEmpty(days)) {
            return;
        }
        days.stream().forEach(date -> {
            ClDashBoardCreateQueryReq thatDay = new ClDashBoardCreateQueryReq();
            BeanCopyUtil.copyProperties(request, thatDay);
            thatDay.setRecordDateStart(date);
            thatDay.setRecordDateEnd(date);
            thatDay.setRecordDateTimeStart(date + Constants.START_TIME);
            thatDay.setRecordDateTimeEnd(date + Constants.END_TIME);
            updateDailyCache(thatDay, isUpdateForEmpty);
        });
        log.info("[updateCacheOfDays method] end to updateCacheOfDays");
    }

    /**
     * 设置下级代理列表
     *
     * @param req 请求
     * @return 是否设置成功 true：设置成功 false：设置失败
     */
    public boolean setUserNameList(ClDashBoardCreateQueryReq req) {
        // 获取下级用户名
        DashBoardUserTreeQueryReq queryEntity = new DashBoardUserTreeQueryReq();
        String currentAgent = req.getAgentAccount();
        queryEntity.setParent(currentAgent);
        Result<List<TCustomerLayer>> userListResult = userFeignService.selectUserTreeByParentNTime(queryEntity);

        if (userListResult.isSuccess() && !Objects.isNull(userListResult.getData()) && userListResult.getData().size() > 0) {
            List<String> userNameList = userListResult.getData().stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList());
            req.setLoginNameList(userNameList);
            log.info("当前用户 {} 获取下级代理列表成功，LoginNameList size 为 {}", currentAgent, userNameList.size());
            return true;
        }
        log.info("当前用户 {} 获取下级代理列表为空，默认设置 LoginNameList 为空集合", currentAgent);
        req.setLoginNameList(Collections.emptyList());
        return false;
    }
}