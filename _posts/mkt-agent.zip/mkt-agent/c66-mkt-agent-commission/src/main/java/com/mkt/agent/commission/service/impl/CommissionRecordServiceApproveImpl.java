package com.mkt.agent.commission.service.impl;

import com.mkt.agent.commission.exception.MKTCommissionException;
import com.mkt.agent.commission.mapper.CommissionRecordApproveMapper;
import com.mkt.agent.commission.service.CommissionRecordQueryService;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordApproveRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordApproveResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordListResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.base.CommissionRecordPageResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.sum.CommissionRecordApproveSumResponse;
import com.mkt.agent.common.enums.CommissionRecordStatusEnum;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.ExcelUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
@Slf4j
public class CommissionRecordServiceApproveImpl implements CommissionRecordQueryService<CommissionRecordApproveRequest, CommissionRecordApproveResponse> {


    @Autowired
    private CommissionRecordApproveMapper commissionRecordApproveMapper;

    @Override
    public CommissionRecordPageResponse<CommissionRecordApproveResponse> queryByPageAndCondition(CommissionRecordApproveRequest req) {

        //分页数据初始化
        req.setPageSize(req.getPageSize());

        if(StringUtils.isNotBlank(req.getCreateTimeStart())){
            req.setCreateTimeStart(req.getCreateTimeStart()+" 00:00:00");
        }

        if(StringUtils.isNotBlank(req.getCreateTimeEnd())){
            req.setCreateTimeEnd(req.getCreateTimeEnd()+" 23:59:59");
        }

        // 查总记录数
        Long total = commissionRecordApproveMapper.countQueryByPageAndCondition(req);

        // 查记录
        List<CommissionRecordApproveResponse> resultList = commissionRecordApproveMapper.queryByPageAndCondition(req);

        CommissionRecordPageResponse<CommissionRecordApproveResponse> commissionRecordOutVOPage = new CommissionRecordPageResponse<>();
        commissionRecordOutVOPage.setRecords(resultList);
        commissionRecordOutVOPage.setTotal(total);
        commissionRecordOutVOPage.setCurrent(req.getPageNum());
        commissionRecordOutVOPage.setSize(req.getPageSize());
        commissionRecordOutVOPage.setPages(total / req.getPageSize());

        Map<String, BigDecimal> pageSumMap = commissionRecordOutVOPage.getPageSumMap();
        // 分页数据聚合
        for (CommissionRecordApproveResponse commissionRecordApproveResponse : resultList) {


            if (Objects.isNull(pageSumMap.get(BaseConstants.CommissionAmount))) {
                pageSumMap.put(BaseConstants.CommissionAmount, new BigDecimal(0));
                pageSumMap.put(BaseConstants.ActualCommissionAmount, new BigDecimal(0));
                pageSumMap.put(BaseConstants.AppendCommissionAmount, new BigDecimal(0));
            }

            // 分页聚合
            pageSumMap.put(BaseConstants.CommissionAmount, pageSumMap.get(BaseConstants.CommissionAmount).add(commissionRecordApproveResponse.getCommissionAmount()));
            pageSumMap.put(BaseConstants.ActualCommissionAmount, pageSumMap.get(BaseConstants.ActualCommissionAmount).add(commissionRecordApproveResponse.getActualCommissionAmount()));
            pageSumMap.put(BaseConstants.AppendCommissionAmount, pageSumMap.get(BaseConstants.AppendCommissionAmount).add(commissionRecordApproveResponse.getAppendCommissionAmount()));

        }

        CommissionRecordApproveSumResponse commissionRecordApproveSumResponse = commissionRecordApproveMapper.queryByPageAndConditionSum(req);
        if (Objects.nonNull(commissionRecordApproveSumResponse)) {
            Map<String, BigDecimal> searchSumMap = commissionRecordOutVOPage.getSearchSumMap();

            if (Objects.isNull(searchSumMap.get(BaseConstants.CommissionAmount))) {
                searchSumMap.put(BaseConstants.CommissionAmount, new BigDecimal(0));
                searchSumMap.put(BaseConstants.ActualCommissionAmount, new BigDecimal(0));
                searchSumMap.put(BaseConstants.AppendCommissionAmount, new BigDecimal(0));
            }

            searchSumMap.put(BaseConstants.CommissionAmount, commissionRecordApproveSumResponse.getSumCommissionAmount());
            searchSumMap.put(BaseConstants.ActualCommissionAmount, commissionRecordApproveSumResponse.getSumActualCommissionAmount());
            searchSumMap.put(BaseConstants.AppendCommissionAmount, commissionRecordApproveSumResponse.getSumAppendCommissionAmount());
        }

        return commissionRecordOutVOPage;
    }


    @Override
    public List<CommissionRecordApproveResponse> export(CommissionRecordApproveRequest req, HttpServletResponse response) {
        // 导出全部数据
        req.setIsPage(false);
        List<CommissionRecordApproveResponse> responses = commissionRecordApproveMapper.queryByPageAndCondition(req);

        for(CommissionRecordApproveResponse approveResponse:responses){
            LocalDate date = DateUtils.stringToLocalDate(approveResponse.getSettleDateStart());
            approveResponse.setCommissionPeriod(date.getYear()+"-"+date.getMonthValue());
            approveResponse.setStatusStr(CommissionRecordStatusEnum.getNameByValue(approveResponse.getStatus()));
            approveResponse.setAgentTypeStr(approveResponse.getAgentType()==0?"General line":"Professional line");
        }
        return responses;

    }


}
