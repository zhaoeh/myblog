package com.mkt.agent.commission.clickhouse.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.DailyOrderAll;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.ClDashBoardDataRes;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverDistriResp;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverTopResp;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description TODO
 * @Classname DashBoardMapper
 * @Date 2023/11/22 14:42
 * @Created by TJSLucian
 */
@Mapper
public interface DashBoardV1Mapper extends BaseMapper<DailyOrderAll> {


    DashBoardHistoryEntity queryDashBoardDataByPlural(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    List<ClTurnoverTopResp> topList(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    List<ClTurnoverDistriResp> distriList(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    Long queryTurnoverActivePlayerCount(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    Long getBetPlayersFromCl(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

}
