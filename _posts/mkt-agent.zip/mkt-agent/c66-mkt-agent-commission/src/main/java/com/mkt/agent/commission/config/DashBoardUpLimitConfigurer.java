package com.mkt.agent.commission.config;

import com.mkt.agent.common.config.DashBoardConfig;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.enums.DashboardChosenTimeEnum;
import com.mkt.agent.common.limit.PriorityLimitConfigurer;
import com.mkt.agent.common.utils.ThreadLocalUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;
import org.springframework.util.ConcurrentReferenceHashMap;

import java.util.Map;
import java.util.Objects;

/**
 * @description: 自定义限流key生成器
 * @author: ErHu.Zhao
 * @create: 2024-01-13
 **/
@Component
@Slf4j
public class DashBoardUpLimitConfigurer implements PriorityLimitConfigurer, InitializingBean {

    private final DashBoardConfig dashBoardConfig;

    /**
     * 自定义的限流拦截key前缀
     */
    private static final String LIMIT_PREFIX = "DASHBOARD_LIMIT_";

    private static Map<String, String> limitKeysMapper = new ConcurrentReferenceHashMap<>();

    public DashBoardUpLimitConfigurer(DashBoardConfig dashBoardConfig) {
        this.dashBoardConfig = dashBoardConfig;
    }

    @Override
    public String limitKeyConfigurer(Object param) {
        String loginName = ThreadLocalUtil.get(Constants.LOGIN_NAME_KEY);
        String limitKey = dashBoardConfig.getLimitKey();
        // 优先使用自定义配置中的limitKey作为缓存key的一部分
        if (StringUtils.isNotBlank(limitKey)) {
            return LIMIT_PREFIX + limitKey + "_" + loginName;
        }
        return buildLimitKey();
    }

    @Override
    public Long limitPeriodConfigurer(Object target) {
        return dashBoardConfig.getLimitPeriod();
    }

    @Override
    public Long limitCountConfigurer(Object target) {
        return dashBoardConfig.getLimitCount();
    }

    /**
     * 构建限流key
     *
     * @return
     */
    private String buildLimitKey() {
        String chosenPeriod = ThreadLocalUtil.get(Constants.CHOSEN_PERIOD_KEY);
        String chosenType = ThreadLocalUtil.get(Constants.CHOSEN_TYPE_KEY);
        String loginName = ThreadLocalUtil.get(Constants.LOGIN_NAME_KEY);
        String prefixKey = limitKeysMapper.get(chosenPeriod + chosenType);
        if (StringUtils.isBlank(prefixKey)) {
            return null;
        }
        return LIMIT_PREFIX + prefixKey + "_" + loginName;
    }


    @Override
    public void afterPropertiesSet() throws Exception {
        if (Objects.isNull(limitKeysMapper)) {
            limitKeysMapper = new ConcurrentReferenceHashMap<>();
        }
        // 当前月
        limitKeysMapper.put(buildCurrentMapperKey(DashboardChosenTimeEnum.ChosenType_Month), Constants.CURRENT_MONTH);
        // 当前周
        limitKeysMapper.put(buildCurrentMapperKey(DashboardChosenTimeEnum.ChosenType_Week), Constants.CURRENT_WEEK);
        // 当前天
        limitKeysMapper.put(buildCurrentMapperKey(DashboardChosenTimeEnum.ChosenType_Day), Constants.CURRENT_DAY);

        // 上个月
        limitKeysMapper.put(buildLastMapperKey(DashboardChosenTimeEnum.ChosenType_Month), Constants.LAST_MONTH);
        // 上周
        limitKeysMapper.put(buildLastMapperKey(DashboardChosenTimeEnum.ChosenType_Week), Constants.LAST_WEEK);
        // 昨天
        limitKeysMapper.put(buildLastMapperKey(DashboardChosenTimeEnum.ChosenType_Day), Constants.LAST_DAY);

        // 上上个月
        limitKeysMapper.put(buildLast2MapperKey(DashboardChosenTimeEnum.ChosenType_Month), Constants.LAST2_MONTH);
        // 上上周
        limitKeysMapper.put(buildLast2MapperKey(DashboardChosenTimeEnum.ChosenType_Week), Constants.LAST2_WEEK);
        // 前天
        limitKeysMapper.put(buildLast2MapperKey(DashboardChosenTimeEnum.ChosenType_Day), Constants.LAST2_DAY);
    }

    /**
     * 构建当前
     *
     * @param chosenType
     * @return
     */
    private String buildCurrentMapperKey(DashboardChosenTimeEnum chosenType) {
        return DashboardChosenTimeEnum.ChosenPeriod_Current.getName() + chosenType.getName();
    }

    /**
     * 构建上
     *
     * @param chosenType
     * @return
     */
    private String buildLastMapperKey(DashboardChosenTimeEnum chosenType) {
        return DashboardChosenTimeEnum.ChosenPeriod_Last.getName() + chosenType.getName();
    }

    /**
     * 构建上上
     *
     * @param chosenType
     * @return
     */
    private String buildLast2MapperKey(DashboardChosenTimeEnum chosenType) {
        return DashboardChosenTimeEnum.ChosenPeriod_Last_Two.getName() + chosenType.getName();
    }
}
