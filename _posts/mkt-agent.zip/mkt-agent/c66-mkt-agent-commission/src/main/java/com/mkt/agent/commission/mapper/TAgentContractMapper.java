package com.mkt.agent.commission.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * @ClassName CommissionPlanMapper
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Mapper
public interface TAgentContractMapper extends BaseMapper<TAgentContract> {

    TAgentContract selectByIdParame(Map<String, Object> parame);
}
