package com.mkt.agent.commission.mapper;

import com.mkt.agent.commission.req.TAgentCustomers;
import com.mkt.agent.common.entity.TCustomerLayer;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;
import java.util.Objects;

@Mapper
public interface UserMapper {


    List<TAgentCustomers>  listTopAgent(Map<String, Object> parame);


    List<TCustomerLayer> selectUserTreeByParentNTime (
            @Param("parent") String parent, @Param("createTimeStart") String createTimeStart, @Param("createTimeEnd") String createTimeEnd);

    void updateUserIsEnable(Map<String, Object> parame);
}
