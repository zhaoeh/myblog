package com.mkt.agent.commission.service;

import com.mkt.agent.common.entity.api.commissionapi.requests.base.CommissionRecordBaseRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.base.CommissionRecordBaseResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.base.CommissionRecordPageResponse;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

public interface CommissionRecordQueryService<Req extends CommissionRecordBaseRequest, Res extends CommissionRecordBaseResponse> {

    CommissionRecordPageResponse<Res> queryByPageAndCondition(Req commissionRecordListRequest);


    List<Res> export(Req req, HttpServletResponse response);


}
