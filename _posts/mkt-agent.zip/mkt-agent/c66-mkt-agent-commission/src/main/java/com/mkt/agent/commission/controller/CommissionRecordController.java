package com.mkt.agent.commission.controller;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.mkt.agent.commission.exception.MKTCommissionException;
import com.mkt.agent.commission.fegin.AgentFeignService;
import com.mkt.agent.commission.mapper.UserMapper;
import com.mkt.agent.commission.service.CommissionRecordService;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.constants.DefaultAgentConstant;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TAgentGlobalConfigEntity;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordResetRequest;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordUpdateRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordPlanResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordSingleResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.common.entity.api.fund.req.FundTransferReq;
import com.mkt.agent.common.entity.api.jobapi.responses.AgentDetails;
import com.mkt.agent.common.entity.system.LoginUserInfo;
import com.mkt.agent.common.enums.*;
import com.mkt.agent.common.utils.BeanCopyUtil;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.UserContext;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.util.*;

/**
 * 佣金记录 api
 */
@RestController
@RequestMapping("/commissionRecord")
@Api(tags = "commission_record API")
@Slf4j
public class CommissionRecordController {

    @Autowired
    private CommissionRecordService commissionRecordService;

    @Autowired
    private AgentFeignService agentFeignService;


    @PostMapping("/queryByCommissionRecordId")
    @ApiOperation("query commission records by commission id")
    public CommissionRecordSingleResponse queryByCommissionRecordId(@RequestParam("id") Long commissionRecordId) {
        log.info("commission_record_detail query param :{}", commissionRecordId);
        // 根据佣金记录id查询佣金记录
        AgentCommissionRecord oneById = commissionRecordService.getById(commissionRecordId);

        if(Objects.isNull(oneById)){
            throw new MKTCommissionException(ResultEnum.RECORD_NOT_EXIST);
        }

        if (oneById.getAgentType() == 3) {
            return null;
        }
        //qindingping 安全bug修复：增加账号校验，只能查看直属下级的记录
        LoginUserInfo userInfo = UserContext.getContext();
        boolean ifCheckParent = null!=userInfo && null!=oneById.getParentId() && Constants.FROM_FRONTEND.equals(userInfo.getFrom());
        if( ifCheckParent && !Objects.equals(userInfo.getUserId(),oneById.getParentId().toString())){
            throw new MKTCommissionException(ResultEnum.FORBIDDEN);
        }

        CommissionRecordSingleResponse result = new CommissionRecordSingleResponse();
        // 佣金期间按年-月份展示（例如2023.07）
        result.setSettleMonth(oneById.getSettleDateStart().getYear() + "." + new DecimalFormat("00").format(oneById.getSettleDateStart().getMonthValue()));

        BeanCopyUtil.copyProperties(oneById, result);

        //获取顶级代理
        result.setLevel1AgentAccount(oneById.getAgentAccount());
        try {
            if (StringUtils.isNoneBlank(oneById.getLevel1AgentAccount())) {
                Result<TAgentCustomers> topAgent = agentFeignService.queryTopAgent(oneById.getCustomerId());
                result.setLevel1AgentAccount(topAgent.isSuccess() ? topAgent.getData().getLoginName() : "");
            }
        } catch (Exception e) {
            e.printStackTrace();
            result.setLevel1AgentAccount(oneById.getAgentAccount());
        }

        log.info("commission_record_detail query result :{}", result);
        return result;
    }

    @PostMapping("/queryCommissionPlanByCommissionRecordId")
    @ApiOperation("query commission plan by commission id")
    public CommissionRecordPlanResponse queryCommissionPlanByCommissionRecordId(@RequestParam("id") Long commissionRecordId) {

        // 根据佣金记录id查询佣金计划
        log.info("commission_record_plan query param :{}", commissionRecordId);
        AgentCommissionRecord oneById = commissionRecordService.getById(commissionRecordId);

        CommissionRecordPlanResponse result = new CommissionRecordPlanResponse();

        if (Objects.nonNull(oneById)) {
            BeanCopyUtil.copyProperties(oneById, result);
        } else {
            throw new MKTCommissionException(ResultEnum.RECORD_NOT_EXIST);
        }
        String percentageDetails = oneById.getPercentageDetails();
        JSONArray jsonArray = JSONArray.parseArray(percentageDetails);
        //一期取第一个
        JSONObject jsonObject = jsonArray.getJSONObject(0);

        if (oneById.getCommissionValues().equals(CommissionValuesEnum.ALL_GAME_TYPES.getCode())) {
            for (GameTypeEnum value : GameTypeEnum.values()) {
                if (!value.getDes().equals(GameTypeEnum.All.getDes())) {
                    jsonObject.remove(value.getDes());
                }
            }
        } else {
            jsonObject.remove(ContractKeysEnum.All.getDes());
        }

        result.setDetailJSONObject(jsonObject);
        result.setActiveUserTurnover1(oneById.getActiveUserTurnover());
        log.info("commission_record_plan query result :{}", result);
        return result;
    }

    @PostMapping("/commissionRecordFirstApproveById")
    @ApiOperation("commissionRecordFirstApproveById")
    public Boolean commissionRecordFirstApproveById(@RequestBody @Valid CommissionRecordUpdateRequest req) {
        // 佣金审批 一审
        log.info("commissionRecordFirstApproveById param :{}", req);

        BigDecimal zero = new BigDecimal(BaseConstants.DEFAULT_AMOUNT);
        BigDecimal actualCommissionAmount = req.getActualCommissionAmount();
        if (actualCommissionAmount.compareTo(zero) < 0) {
            throw new MKTCommissionException(ResultEnum.APPROVE_AMOUNT_ILLEGAL);
        }

        // 查记录是否存在
        AgentCommissionRecord one = commissionRecordService.getById(req.getCommissionRecordId());
        if (Objects.isNull(one)) {
            throw new MKTCommissionException(ResultEnum.RECORD_NOT_EXIST);
        }

        Integer status = one.getStatus();
        if (!Objects.equals(status, CommissionRecordStatusEnum.FIRST_PENDING.getValue())) {
            throw new MKTCommissionException(ResultEnum.RECORD_STATUS_ILLEGAL_FOR_FIRST_APPROVE);
        }

        one.setFirstApproveBy(req.getAgentAccount());
        one.setActualCommissionAmount(req.getActualCommissionAmount());

        // 状态赋值
        Integer reqStatus = req.getStatus();

        if (Objects.equals(reqStatus, CommissionRecordStatusEnum.AGREED.getValue())) {
            log.info("一审审批通过 :{}", reqStatus);

            BigDecimal approvalAmount = getNeedSecApproval();

            log.info("佣金金额：{},实际发放金额：{},限额：{}", one.getCommissionAmount(), actualCommissionAmount, approvalAmount);

            //如果佣金金额和实际发放金额不一致 或者 佣金金额大于等于阈值  需要二审
            if (one.getCommissionAmount().compareTo(actualCommissionAmount) != 0 || (approvalAmount != null && one.getCommissionAmount().compareTo(approvalAmount) >= 0)) {
                log.info("佣金和实发不一致或者佣金大于限额");
                one.setStatus(CommissionRecordStatusEnum.SECOND_PENDING.getValue());
            } else {
                log.info("佣金和实发一致并且佣金小于限额");
                one.setStatus(CommissionRecordStatusEnum.SECOND_AGREED.getValue());
                one.setSecondApproveBy(Constants.CREATED_BY_SYSTEM);
                //发放佣金 失败则返回 成功则更新
                if (!transferCommission(one)) {
                    return false;
                }

            }

        } else if (Objects.equals(reqStatus, CommissionRecordStatusEnum.REJECTED.getValue())) {
            log.info("一审审批拒绝 :{}", reqStatus);
            one.setStatus(CommissionRecordStatusEnum.FIRST_REJECTED.getValue());
        } else {
            throw new MKTCommissionException(ResultEnum.AGREE_OR_REJECT_NO_OTHER_CHOICE);
        }

        boolean result = commissionRecordService.updateById(one);
        log.info("commissionRecordFirstApproveById result :{}", result);
        return result;
    }


    @PostMapping("/commissionRecordSecondApproveById")
    @ApiOperation("commissionRecordSecondApproveById")
    public Boolean commissionRecordSecondApproveById(@RequestBody @Valid CommissionRecordUpdateRequest req) {
        // 佣金审批 二审
        log.info("commissionRecordSecondApproveById param :{}", req);

        // 查记录是否存在
        AgentCommissionRecord one = commissionRecordService.getById(req.getCommissionRecordId());
        if (Objects.isNull(one)) {
            throw new MKTCommissionException(ResultEnum.RECORD_NOT_EXIST);
        }

        Integer status = one.getStatus();
        if (!Objects.equals(status, CommissionRecordStatusEnum.SECOND_PENDING.getValue())) {
            throw new MKTCommissionException(ResultEnum.RECORD_STATUS_ILLEGAL_FOR_SECOND_APPROVE);
        }

        String secondApproveOne = req.getAgentAccount();
        String firstApproveOne = one.getFirstApproveBy();

        if (StringUtils.equals(secondApproveOne, firstApproveOne)) {
            throw new MKTCommissionException(ResultEnum.APPROVED_BY_SAME_MANAGER);
        }

        one.setSecondApproveBy(secondApproveOne);

        // 状态赋值
        Integer reqStatus = req.getStatus();
        if (Objects.equals(reqStatus, CommissionRecordStatusEnum.AGREED.getValue())) {
            one.setStatus(CommissionRecordStatusEnum.SECOND_AGREED.getValue());
            //二审同意，发放佣金
            transferCommission(one);

        } else if (Objects.equals(reqStatus, CommissionRecordStatusEnum.REJECTED.getValue())) {
            one.setStatus(CommissionRecordStatusEnum.SECOND_REJECTED.getValue());
        } else {
            throw new MKTCommissionException(ResultEnum.AGREE_OR_REJECT_NO_OTHER_CHOICE);
        }

        log.info("sucess to pay commission, update the record now:{}", one);
        Boolean result = commissionRecordService.updateById(one);

        log.info("commissionRecordSecondApproveById result :{}", result);
        return result;
    }

    @PostMapping("/commissionRecordSecondResetById")
    @ApiOperation("commissionRecordSecondResetById")
    public Boolean commissionRecordSecondResetById(@RequestBody @Valid CommissionRecordResetRequest req) {
        // 佣金审批 二审 reset
        log.info("commissionRecordSecondResetById param :{}", req);

        // 查记录是否存在
        AgentCommissionRecord one = commissionRecordService.getById(req.getCommissionRecordId());
        if (Objects.isNull(one)) {
            throw new MKTCommissionException(ResultEnum.RECORD_NOT_EXIST);
        }

        Integer status = one.getStatus();
        if (!status.equals(CommissionRecordStatusEnum.SECOND_REJECTED.getValue()) && !status.equals(CommissionRecordStatusEnum.FIRST_REJECTED.getValue())) {
            throw new MKTCommissionException(ResultEnum.RECORD_STATUS_ILLEGAL_FOR_RESET);
        }

        // TIME NOT BEFORE TWO MONTH AGO

        LocalDateTime createTime = DateUtils.stringToLocalDateTime(one.getCreateTime());
        LocalDateTime now = LocalDateTime.now().minusMonths(2);

        if (createTime.isBefore(now)) {
            throw new MKTCommissionException(ResultEnum.RECORD_RESET_TIME_IS_OVERDUE);
        }

        AgentCommissionRecord agentCommissionRecord = new AgentCommissionRecord();
        agentCommissionRecord.setId(req.getCommissionRecordId());
        agentCommissionRecord.setStatus(CommissionRecordStatusEnum.FIRST_PENDING.getValue());
        agentCommissionRecord.setFirstApproveBy("");
        agentCommissionRecord.setSecondApproveBy("");
        agentCommissionRecord.setActualCommissionAmount(new BigDecimal(0));
        boolean result = commissionRecordService.updateById(agentCommissionRecord);
        log.info("commissionRecordSecondResetById result :{}", result);
        return result;

    }

    @PostMapping("/commissionRecordSecondPayById")
    @ApiOperation("commissionRecordSecondPayById")
    public Boolean commissionRecordSecondPayById(@RequestBody @Valid CommissionRecordUpdateRequest req) {
        // 佣金审批 二审 支付
        log.info("commissionRecordSecondPayById param :{}", req);

        // 查记录是否存在
        AgentCommissionRecord one = commissionRecordService.getById(req.getCommissionRecordId());
        if (Objects.isNull(one)) {
            throw new MKTCommissionException(ResultEnum.RECORD_NOT_EXIST);
        }

        String agentAccount = req.getAgentAccount();
        if (!StringUtils.equals(agentAccount, one.getParentAccount())) {
            throw new MKTCommissionException(ResultEnum.NO_AUTH_TO_TRANSFER);
        }

        Integer status = one.getStatus();
        if (Objects.equals(status, CommissionRecordStatusEnum.PAID.getValue())) {
            throw new MKTCommissionException(ResultEnum.RECORD_STATUS_ILLEGAL_FOR_PAY);
        }

        BigDecimal actualCommissionAmount = req.getActualCommissionAmount();
        if (new BigDecimal("0.00").compareTo(actualCommissionAmount) >= 0) {
            throw new MKTCommissionException(ResultEnum.PAY_AMOUNT_ILLEGAL);
        }

        // password valid

        // do transfer
        FundTransferReq request = new FundTransferReq();
        request.setFromId(one.getParentId());
        request.setFromAccount(one.getParentAccount());
        request.setToId(one.getCustomerId());
        request.setToAccount(one.getAgentAccount());
        request.setAmount(actualCommissionAmount);

        log.info("call agentFeign params: {}", request);
        Result<Boolean> data = agentFeignService.transfer(request);

        if (!data.isSuccess()) {
            throw new MKTCommissionException(data.getMessage(), ResultEnum.TRANSFER_FAIL.getCode());
        }
        AgentCommissionRecord agentCommissionRecord = new AgentCommissionRecord();
        agentCommissionRecord.setId(req.getCommissionRecordId());
        agentCommissionRecord.setActualCommissionAmount(req.getActualCommissionAmount());
        // 状态赋值
        agentCommissionRecord.setStatus(CommissionRecordStatusEnum.PAID.getValue());
        agentCommissionRecord.setUpdateTime(DateUtils.getCurrentDateTime());
        boolean result = commissionRecordService.updateById(agentCommissionRecord);
        log.info("commissionRecordSecondPayById result :{}", result);
        return result;
    }


    /**
     * description: 获取是否需要二审审核金额阈值
     *
     * @param: []
     * @return: java.math.BigDecimal
     * @Date: 2023/7/19 14:10
     * @Version: 1.0.0
     * @Author: Lucian
     */
    private BigDecimal getNeedSecApproval() {
        BigDecimal def = new BigDecimal(600);
        //查询需要二审审批金额阈值
        List<String> names = new ArrayList<>();
        names.add(Constants.COMMISSION_NEED_SECOND_APPROVAL_AMOUNT);
        try {
            Result<List<TAgentGlobalConfigEntity>> config = agentFeignService.queryGlobalConfig(names);
            log.info("query globe config result:{}", config);
            if (config.isSuccess()) {
                return new BigDecimal(config.getData().get(0).getParamValue());
            }
        } catch (Exception e) {
            log.info("query commission need second approval amount failed. Param:{},Error message:{}", names, e.getMessage());
        }
        return def;
    }

    /**
     * description: 发放佣金
     *
     * @param: [one]
     * @return: java.lang.Boolean
     * @Date: 2023/7/19 14:23
     * @Version: 1.0.0
     * @Author: Lucian
     */
    private Boolean transferCommission(AgentCommissionRecord one) {
        FundTransferReq fundTransferReq = new FundTransferReq();
        fundTransferReq.setFromId(DefaultAgentConstant.DEFAULT_AGENT_ID);
        fundTransferReq.setFromAccount(DefaultAgentConstant.DEFAULT_LOGIN_NAME);
        fundTransferReq.setToId(one.getCustomerId());
        fundTransferReq.setToAccount(one.getAgentAccount());
        //实际发放的佣金，在一审审核时设置
        fundTransferReq.setAmount(one.getActualCommissionAmount());

        log.info("call transfer system to pay commission for agent:{}", fundTransferReq);

        Boolean tranferResult = false;
        try {
            Result<Boolean> data = agentFeignService.transfer(fundTransferReq);
            log.info("call transfer system to pay commission for agent response:{}", data);
            tranferResult = data != null && data.isSuccess() ? data.getData() : false;
        } catch (Exception e) {
            log.error("Second verify failed recod commission informatin：{} error information：{}", one, e.getMessage());
        }
        return tranferResult;
    }

    //

    @PostMapping("/commissionGen")
    @ApiOperation("commissionGen")
    public Map<String, Object> commissionGen(@RequestBody @Valid Map<String, String> req) {
        Map<String, Object> result = new HashMap<>();

        String loginName = req.get("loginName");
//        String username  =  req .get("username") ;
        String isSave = req.get("isSave");
        String startDate = req.get("startDate");
        String endDate = req.get("endDate");

        Map<String, Object> parame = new HashMap<>();
        parame.put("startDate", startDate);
        parame.put("endDate", endDate);
        parame.put("isSave", isSave);

        log.info("----req={}",new Gson().toJson(req));


        if (!StringUtils.isBlank(loginName)) {
            //显示全部

            String[] names = loginName.split(",");

            for (String name : names) {
                parame.put("name", name);
                parame.put("agent_level", 1);
                List<com.mkt.agent.commission.req.TAgentCustomers> customers = userMapper.listTopAgent(parame);
                log.info("customerscustomerscustomers ={}", new Gson().toJson(customers));


                if (customers != null && customers.size() > 0) {

                    com.mkt.agent.commission.req.TAgentCustomers agentCustomers = customers.get(0);

                    if (agentCustomers.getCommissionContractBindId() != null) {
                        result = commissionRecordService.calcCommissionData(agentCustomers, parame);  //  开始计算佣金
                    }


                } else {
//                    parame.put("agent_level", 1);
                    parame.remove("agent_level") ;
                    customers = userMapper.listTopAgent(parame);
                    log.info("customerscustomerscustomers ={}", new Gson().toJson(customers));
                    if (customers != null && customers.size() > 0) {
                        com.mkt.agent.commission.req.TAgentCustomers agentCustomers = customers.get(0);

                        while ( agentCustomers.getAgentLevel() != 1) {
                            parame.put("name", agentCustomers.getParentName());
                            customers = userMapper.listTopAgent(parame);
                            if (customers != null && customers.size() > 0) {
                                  agentCustomers = customers.get(0);
                            }
                        }
                    log.info("---- 一级账号={}" , new Gson().toJson(agentCustomers));
                        result = commissionRecordService.calcCommissionData(agentCustomers, parame);  //  开始计算佣金

                    }
                }


            }


        } else {
            parame.put("agent_level", 1);
            List<com.mkt.agent.commission.req.TAgentCustomers> customers = userMapper.listTopAgent(parame);

            log.info("customerscustomerscustomers ={}", new Gson().toJson(customers));

            for (com.mkt.agent.commission.req.TAgentCustomers agentCustomers : customers) {
                if (agentCustomers.getCommissionContractBindId() != null) {
                    commissionRecordService.calcCommissionData(agentCustomers, parame);  //  开始计算佣金
                }

            }


        }

        return result;
    }

    @Autowired
    private UserMapper userMapper;

    //更新


    @PostMapping("/updatePlayerStatus")
    @ApiOperation("updatePlayerStatus")
    public Map<String, Object> updatePlayerStatus(@RequestBody @Valid Map<String, String> req) {

        Map<String, Object> result = new HashMap<>();

        commissionRecordService.updatePlayerStatus(req);

          return  result ;
    }

}
