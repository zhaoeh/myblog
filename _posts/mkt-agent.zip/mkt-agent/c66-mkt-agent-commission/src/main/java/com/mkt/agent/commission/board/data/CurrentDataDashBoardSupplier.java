package com.mkt.agent.commission.board.data;

import com.google.gson.Gson;
import com.mkt.agent.commission.board.core.DashBoardCacheKeyBuilder;
import com.mkt.agent.commission.board.core.DashBoardHelper;
import com.mkt.agent.commission.board.core.DashBoardUpdateLimiter;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @program: mkt-agent
 * @description: 仪表盘当天实时数据供应者
 * @author: Erhu.Zhao
 * @create: 2023-12-05 14:00
 */
@Component
@Slf4j
public class CurrentDataDashBoardSupplier extends DashBoardSupplierSupport {

    private final DashBoardUpdateLimiter dashBoardUpdateLimiter;

    public CurrentDataDashBoardSupplier(Gson gson, DashBoardUpdateLimiter dashBoardUpdateLimiter,
                                        RedisUtil redisUtil,
                                        DashBoardHelper dashBoardHelper) {
        super(gson, dashBoardHelper, redisUtil);
        this.dashBoardUpdateLimiter = dashBoardUpdateLimiter;
    }

    @Override
    public String strategy() {
        return Constants.CURRENT_DATA;
    }

    @Override
    public CommissionRecordDashBoardResponse loadDashBoardData(ClDashBoardCreateQueryReq queryReq) {
        log.info("[loadDashBoardData method] begin to loadDashBoardData in CurrentDataDashBoardSupplier class,request is {}", gson.toJson(queryReq));
        // 优先查询缓存数据，查询后直接返回给客户端
        CommissionRecordDashBoardResponse currentData = doLoadDashBoardData(queryReq);

        // 更新缓存数据（限流、异步）
        dashBoardUpdateLimiter.updateDashBoardCacheOfAsyncAndLimiter(queryReq);

        // 获取缓存数据后直接返回
        log.info("[loadDashBoardData method] end to loadDashBoardData in CurrentDataDashBoardSupplier class,currentData is {}", gson.toJson(currentData));
        return currentData;
    }

    @Override
    public CommissionRecordDashBoardResponse loadTurnoverData(ClDashBoardCreateQueryReq queryReq) {
        log.info("[loadTurnoverData method] begin to loadTurnoverData in CurrentDataDashBoardSupplier class,request is {}", gson.toJson(queryReq));
        return doLoadDashBoardData(queryReq);
    }

    /**
     * 查询缓存，获取指定时间段区间的汇总数据(聚合后)
     *
     * @param queryReq
     * @return
     */
    private CommissionRecordDashBoardResponse doLoadDashBoardData(ClDashBoardCreateQueryReq queryReq) {
        if (Objects.isNull(queryReq)) {
            return new CommissionRecordDashBoardResponse();
        }
        // 获取当前请求中的开始日期和结束日期的区间
        List<String> dateRangeAsStr = DateUtils.getDateRangeAsStr(DateUtils.stringToLocalDate(queryReq.getRecordDateStart()), DateUtils.stringToLocalDate(queryReq.getRecordDateEnd()));
        log.info("[doLoadDashBoardData method] begin to doLoadDashBoardData,dateRangeAsStr is {}", gson.toJson(dateRangeAsStr));
        CommissionRecordDashBoardResponse response = dashBoardHelper.summarizeDiscreteData(loadDashBoardDataOfList(dateRangeAsStr, queryReq.getAgentAccount()));
        log.info("[doLoadDashBoardData method] end to doLoadDashBoardData,response is {}", gson.toJson(response));
        return response;
    }

    /**
     * 根据日期范围加载缓存中的汇总数据
     *
     * @param dateRangeAsStr 日期范围
     * @return 缓存汇总数据集合
     */
    private List<DashBoardHistoryEntity> loadDashBoardDataOfList(List<String> dateRangeAsStr, String userName) {
        log.info("[loadDashBoardDataOfList method] begin to loadDashBoardDataOfList, dateRangeAsStr is {},userName is {}", gson.toJson(dateRangeAsStr), userName);
        List<DashBoardHistoryEntity> response = Optional.ofNullable(dateRangeAsStr).map(list -> list.stream().map(dateStr -> dashBoardHelper.loadDashBoardDataFromCache(DashBoardCacheKeyBuilder.key(userName, dateStr))).collect(Collectors.toList())).orElseGet(Collections::emptyList);
        log.info("[loadDashBoardDataOfList method] end to loadDashBoardDataOfList, response is {}", gson.toJson(response));
        return response;
    }

}