package com.mkt.agent.commission.controller;

import com.mkt.agent.commission.clickhouse.service.ClDashBoardV1Service;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordDashBoardRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.dashboard.DashboardTopNDistriVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @Description TODO
 * @Classname DashBoardController
 * @Date 2023/11/28 11:03
 * @Created by TJSLucian
 */
@RestController
@RequestMapping("/dashBoard")
@Api(tags = "dashBoard API")
@Slf4j
public class DashBoardV1Controller {

    @Autowired
    private ClDashBoardV1Service clDashBoardV1Service;

    @PostMapping(value = "/teamSummaryQuery")
    @ApiOperation(value = "获取代理仪表盘Team Summary数据")
    public Result<CommissionRecordDashBoardResponse> dashBoardQueryFromClickHouse(@RequestBody @Valid CommissionRecordDashBoardRequest req){
        log.info("dashBoardQuery params:{}",req.toString());
        return clDashBoardV1Service.getTeamSummaryData(req);

    }


    @PostMapping("/getTurnoverTopNDistriData")
    @ApiOperation("game turnover distribution")
    public DashboardTopNDistriVo getTurnoverTopNDistriData(@RequestParam String loginName) {
        return clDashBoardV1Service.getTurnoverTopNDistriData(loginName);
    }

}
