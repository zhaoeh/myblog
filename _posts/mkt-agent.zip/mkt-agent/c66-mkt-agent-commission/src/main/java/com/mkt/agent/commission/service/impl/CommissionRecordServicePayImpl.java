package com.mkt.agent.commission.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.commission.exception.MKTCommissionException;
import com.mkt.agent.commission.fegin.AgentFeignService;
import com.mkt.agent.commission.mapper.CommissionRecordMapper;
import com.mkt.agent.commission.service.CommissionRecordQueryService;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordPayRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordPayResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.base.CommissionRecordPageResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.common.enums.CommissionRecordStatusEnum;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.BeanCopyUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
@Slf4j
public class CommissionRecordServicePayImpl implements CommissionRecordQueryService<CommissionRecordPayRequest, CommissionRecordPayResponse> {

    @Autowired
    private CommissionRecordMapper commissionRecordMapper;

    @Autowired
    private AgentFeignService agentFeignService;

    public CommissionRecordPageResponse<CommissionRecordPayResponse> queryByPageAndCondition(CommissionRecordPayRequest req) {

        log.info("/commissionRecord-pay/queryByPageAndCondition param:{}",req.toString());

        // 1.根据分页请求查询分页数据
        // 根据loginName查询代理信息
        TAgentCustomers customers = getAgentByLoginName(req.getLoginName());
        // 只筛选出直属下级
        int agentLevelQuery = customers.getAgentLevel() + 1;
        // 构建查询条件
        LambdaQueryWrapper<AgentCommissionRecord> eq = Wrappers.<AgentCommissionRecord>lambdaQuery()
                // Account模糊查询
                .like(StringUtils.isNotEmpty(req.getAgentAccount()), AgentCommissionRecord::getAgentAccount, req.getAgentAccount())
                // Commission Period >= start time && <= end time
                .ge(StringUtils.isNotEmpty(req.getSettleDateStart()), AgentCommissionRecord::getSettleDateStart, req.getSettleDateStart())
                .le(StringUtils.isNotEmpty(req.getSettleDateEnd()), AgentCommissionRecord::getSettleDateEnd, req.getSettleDateEnd())
                // Status
                .eq(!Objects.isNull(req.getStatus())&&req.getStatus().equals(CommissionRecordStatusEnum.PAID.getValue()), AgentCommissionRecord::getStatus, req.getStatus())
                .eq(!Objects.isNull(req.getStatus())&&!req.getStatus().equals(CommissionRecordStatusEnum.PAID.getValue()), AgentCommissionRecord::getStatus, CommissionRecordStatusEnum.FIRST_PENDING.getValue())
                // 直属下级
                .eq(AgentCommissionRecord::getAgentLevel, agentLevelQuery)
                // parentId 为当前人
                .eq(AgentCommissionRecord::getParentId, customers.getCustomersId())
                .orderByAsc(AgentCommissionRecord::getAgentLevel);
        // 查询分页
        Page<AgentCommissionRecord> page = new Page<>(req.getPageNum(), req.getPageSize());
        Page<AgentCommissionRecord> pageResult = commissionRecordMapper.selectPage(page, eq);
        Long countSum = commissionRecordMapper.selectCount(eq);
        log.info("commissionRecord total={}", countSum);
        // VO转换
        CommissionRecordPageResponse<CommissionRecordPayResponse> commissionRecordOutVOPage =
                BeanCopyUtil.copyProperties(pageResult, CommissionRecordPageResponse::new);
        commissionRecordOutVOPage.setRecords(BeanCopyUtil.copyListProperties(pageResult.getRecords(), CommissionRecordPayResponse::new));
        commissionRecordOutVOPage.setTotal(countSum);

        // 2.处理分页聚合数据
        List<CommissionRecordPayResponse> resultList = commissionRecordOutVOPage.getRecords();

        Map<String, BigDecimal> pageSumMap = commissionRecordOutVOPage.getPageSumMap();
        // 分页数据聚合
        for (CommissionRecordPayResponse commissionRecordPayResponse : resultList) {

            if (Objects.isNull(pageSumMap.get(BaseConstants.CommissionAmount))) {
                pageSumMap.put(BaseConstants.CommissionAmount, new BigDecimal(0));
                pageSumMap.put(BaseConstants.ActualCommissionAmount, new BigDecimal(0));
            }

            // 分页聚合
            pageSumMap.put(BaseConstants.CommissionAmount, pageSumMap.get(BaseConstants.CommissionAmount).add(commissionRecordPayResponse.getCommissionAmount()));
            pageSumMap.put(BaseConstants.ActualCommissionAmount, pageSumMap.get(BaseConstants.ActualCommissionAmount).add(commissionRecordPayResponse.getActualCommissionAmount()));

        }

        var commissionRecordPaySumResponse = commissionRecordMapper.queryByPageAndConditionSum(eq);
        if (Objects.nonNull(commissionRecordPaySumResponse)) {
            Map<String, BigDecimal> searchSumMap = commissionRecordOutVOPage.getSearchSumMap();

            if (Objects.isNull(searchSumMap.get(BaseConstants.CommissionAmount))) {
                searchSumMap.put(BaseConstants.CommissionAmount, new BigDecimal(0));
                searchSumMap.put(BaseConstants.ActualCommissionAmount, new BigDecimal(0));
            }

            searchSumMap.put(BaseConstants.CommissionAmount, commissionRecordPaySumResponse.getSumCommissionAmount());
            searchSumMap.put(BaseConstants.ActualCommissionAmount, commissionRecordPaySumResponse.getSumActualCommissionAmount());
        }

        return commissionRecordOutVOPage;
    }

    /**
     * 佣金支付列表导出(仅传回数据)
     *
     * @param req 分页请求
     */
    @Override
    public List<CommissionRecordPayResponse> export(CommissionRecordPayRequest req, HttpServletResponse response) {

        // 根据loginName查询代理信息
        TAgentCustomers customers = getAgentByLoginName(req.getLoginName());
        // 只筛选出直属下级
        int agentLevelQuery = customers.getAgentLevel() + 1;
        // 导出全部数据
        req.setIsPage(false);
        // 查询列表
        List<AgentCommissionRecord> agentCommissionRecords = commissionRecordMapper
                .selectList(Wrappers.<AgentCommissionRecord>lambdaQuery()
                        // Account模糊查询
                        // Account模糊查询
                        .like(StringUtils.isNotEmpty(req.getAgentAccount()), AgentCommissionRecord::getAgentAccount, req.getAgentAccount())
                        // Commission Period >= start time && <= end time
                        .ge(StringUtils.isNotEmpty(req.getSettleDateStart()), AgentCommissionRecord::getSettleDateStart, req.getSettleDateStart())
                        .le(StringUtils.isNotEmpty(req.getSettleDateEnd()), AgentCommissionRecord::getSettleDateEnd, req.getSettleDateEnd())
                        // Status
                        .eq(!Objects.isNull(req.getStatus())&&req.getStatus().equals(CommissionRecordStatusEnum.PAID.getValue()), AgentCommissionRecord::getStatus, req.getStatus())
                        .eq(!Objects.isNull(req.getStatus())&&!req.getStatus().equals(CommissionRecordStatusEnum.PAID.getValue()), AgentCommissionRecord::getStatus, CommissionRecordStatusEnum.FIRST_PENDING.getValue())
                        // 直属下级
                        .eq(AgentCommissionRecord::getAgentLevel, agentLevelQuery)
                        // parentId 为当前人
                        .eq(AgentCommissionRecord::getParentId, customers.getCustomersId())
                        .orderByAsc(AgentCommissionRecord::getAgentLevel));
        // VO转换
        return BeanCopyUtil.copyListProperties(agentCommissionRecords, CommissionRecordPayResponse::new,(agentCommissionRecord,commissionRecordPayResponse) ->{
            Integer statues = agentCommissionRecord.getStatus();
            commissionRecordPayResponse.setStatusValue(statues.equals(5)?"Paid":"Not Paid");
            commissionRecordPayResponse.setCommissionPeriod(agentCommissionRecord.getSettleDateStart().getYear()+"-"+agentCommissionRecord.getSettleDateStart().getMonthValue());
        });
    }

    /**
     * 根据loginName获取代理用户信息
     *
     * @param loginName loginName
     * @return 代理用户信息
     */
    private TAgentCustomers getAgentByLoginName(String loginName) {
        Result<TAgentCustomers> result = agentFeignService.getAgentByLoginName(loginName);
        if (!result.isSuccess() || Objects.isNull(result.getData())) {
            throw new MKTCommissionException(ResultEnum.AGENT_NOT_EXIST);
        }
        return result.getData();
    }
}
