package com.mkt.agent.commission.mapper;

import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordDetailRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDetailResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.sum.CommissionRecordDetailSumResponse;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CommissionRecordDetailMapper {

    int queryCountByPageAndCondition(CommissionRecordDetailRequest rq);

    List<CommissionRecordDetailResponse> queryByPageAndCondition(CommissionRecordDetailRequest rq);

    CommissionRecordDetailSumResponse queryByPageAndConditionSum(CommissionRecordDetailRequest rq);


}
