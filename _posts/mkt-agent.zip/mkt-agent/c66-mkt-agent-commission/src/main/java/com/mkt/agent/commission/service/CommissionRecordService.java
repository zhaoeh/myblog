package com.mkt.agent.commission.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mkt.agent.commission.req.TAgentCustomers;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordDashBoardRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;

import java.util.List;
import java.util.Map;

public interface CommissionRecordService extends IService<AgentCommissionRecord> {

    Result<CommissionRecordDashBoardResponse> getDashBoardCommissionData(CommissionRecordDashBoardRequest req);

    Map<String,Object>  calcCommissionData(TAgentCustomers agentCustomers, Map<String,Object> parame);

    void updatePlayerStatus(Map<String, String> req);
}
