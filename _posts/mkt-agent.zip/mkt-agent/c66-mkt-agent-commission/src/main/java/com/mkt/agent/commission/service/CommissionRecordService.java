package com.mkt.agent.commission.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordDashBoardRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;

import java.util.List;

public interface CommissionRecordService extends IService<AgentCommissionRecord> {

    Result<CommissionRecordDashBoardResponse> getDashBoardCommissionData(CommissionRecordDashBoardRequest req);
}
