package com.mkt.agent.commission.mapper;


import com.mkt.agent.common.entity.api.reportapi.responses.TurnoverDistributionResp;
import com.mkt.agent.common.entity.api.reportapi.responses.TurnoverTopResp;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface TurnoverInfoMapper {

    /**
     * 投注额占比饼状图
     * @return
     *  game_type       游戏类型
     *  turnoverSum     该类型游戏的投注额总计
     *  turnoverDistribution    该类型游戏的投注额占比(该类型游戏的投注额总计/全部投注额总计)
     */
    List<TurnoverDistributionResp> distributionList(@Param(value = "parent") String parent);

    /**
     * 排名前十的玩家账号柱状图
     * @return
     *  login_name      玩家名
     *  turnoverSum     投注额总计
     */
    List<TurnoverTopResp> topList(@Param(value = "parent") String parent);
}
