package com.mkt.agent.commission.mapper;

import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @program: mkt-agent
 * @description: 仪表盘历史数据mapper(历史表2 : t_agent_dashboard_daily_history)
 * @author: Erhu.Zhao
 * @create: 2023-12-05 14:16
 */
@Mapper
public interface HistoryAgentDashboardDailyMapper {
    /**
     * 查询仪表盘历史数据(第2张历史表)
     *
     * @param request 请求
     * @return 响应
     */
    List<DashBoardHistoryEntity> loadHistoryDashBoardDailyData(@Param("re") ClDashBoardCreateQueryReq request, @Param("ap") Map<String, String> appendParam);

    /**
     * 根据id删除数据
     *
     * @param id 主键
     * @return 删除个数
     */
    int deleteById(@Param("id") Long id);

    /**
     * 根据loginName和dashDate删除历史数据
     *
     * @param request 请求
     * @return 删除条数
     */
    int deleteByLoginNameAndDashDate(DashBoardHistoryEntity request);

    /**
     * 根据id更新
     *
     * @param request
     * @return
     */
    int updateById(DashBoardHistoryEntity request);

    /**
     * 插入历史记录
     *
     * @param request 请求
     * @return 插入结果
     */
    int insert(DashBoardHistoryEntity request);
}