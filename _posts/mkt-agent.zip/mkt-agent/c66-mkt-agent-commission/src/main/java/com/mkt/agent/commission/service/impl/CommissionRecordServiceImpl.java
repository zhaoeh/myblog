package com.mkt.agent.commission.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mkt.agent.commission.fegin.AgentFeignService;
import com.mkt.agent.commission.fegin.UserFeignService;
import com.mkt.agent.commission.mapper.CommissionRecordDashBoardMapper;
import com.mkt.agent.commission.mapper.CommissionRecordMapper;
import com.mkt.agent.commission.service.CommissionRecordService;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordDashBoardRequest;
import com.mkt.agent.common.entity.clickhouse.req.DashBoardUserTreeQueryReq;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.common.enums.CommissionPlanTypeEnum;
import com.mkt.agent.common.enums.DashboardChosenTimeEnum;
import com.mkt.agent.common.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;


@Service
@Slf4j
public class CommissionRecordServiceImpl extends ServiceImpl<CommissionRecordMapper, AgentCommissionRecord> implements CommissionRecordService {


    @Resource
    private CommissionRecordMapper commissionRecordMapper;

    @Resource
    private AgentFeignService agentFeignService;

    @Resource
    private UserFeignService userFeignService;

    @Resource
    private CommissionRecordDashBoardMapper commissionRecordDashBoardMapper;


    @Override
    public Result<CommissionRecordDashBoardResponse> getDashBoardCommissionData(CommissionRecordDashBoardRequest req) {

        //1.计算日期
        getNeededRecordDate(req);
        log.info("CommissionRecordServiceImpl getDashBoardCommissionData params:{}",req);

        CommissionRecordDashBoardResponse lastPeriodData = null;
        //查询记录表，查不到再去计算，计算完入库记录表
        if(!StringUtils.isBlank(req.getRecordDateStartLast())){
            //查询上个时间区间数据
            lastPeriodData = commissionRecordDashBoardMapper.selectOne(new LambdaQueryWrapper<CommissionRecordDashBoardResponse>().eq(CommissionRecordDashBoardResponse::getRecordDateStart,req.getRecordDateStartLast())
                    .eq(CommissionRecordDashBoardResponse::getRecordDateEnd,req.getRecordDateEndLast()).eq(CommissionRecordDashBoardResponse::getLoginName,req.getLoginName()));
            if(Objects.isNull(lastPeriodData)){
                //计算
                lastPeriodData = calculateData(req.getLoginName(),req.getRecordDateStartLast(),req.getRecordDateEndLast(),req.getRecordDateTimeStartLast(),req.getRecordDateTimeEndLast());
                lastPeriodData.setLoginName(req.getLoginName());
                lastPeriodData.setRecordDateStart(req.getRecordDateStartLast());
                lastPeriodData.setRecordDateEnd(req.getRecordDateEndLast());

                //判断是否需要入数据库
                if(DateUtils.isBeforeCurrentMonth(lastPeriodData.getRecordDateStart(),lastPeriodData.getRecordDateEnd())){
                    commissionRecordDashBoardMapper.insert(lastPeriodData);
                }
            }
        }

        CommissionRecordDashBoardResponse lastTwoPeriodData = null;

        if(!StringUtils.isBlank(req.getRecordDateStartLastTwo())){

            //查询上上个时间区间数据
            lastTwoPeriodData = commissionRecordDashBoardMapper.selectOne(new LambdaQueryWrapper<CommissionRecordDashBoardResponse>().eq(CommissionRecordDashBoardResponse::getRecordDateStart,req.getRecordDateStartLastTwo())
                    .eq(CommissionRecordDashBoardResponse::getRecordDateEnd,req.getRecordDateEndLastTwo()).eq(CommissionRecordDashBoardResponse::getLoginName,req.getLoginName()));
            if(Objects.isNull(lastTwoPeriodData)){
                //计算
                lastTwoPeriodData = calculateData(req.getLoginName(),req.getRecordDateStartLastTwo(),req.getRecordDateEndLastTwo(),req.getRecordDateTimeStartLastTwo(),req.getRecordDateTimeEndLastTwo());
                lastTwoPeriodData.setLoginName(req.getLoginName());
                lastTwoPeriodData.setRecordDateStart(req.getRecordDateStartLastTwo());
                lastTwoPeriodData.setRecordDateEnd(req.getRecordDateEndLastTwo());
                //判断是否入库
                if(DateUtils.isBeforeCurrentMonth(lastTwoPeriodData.getRecordDateStart(),lastTwoPeriodData.getRecordDateEnd())){
                    commissionRecordDashBoardMapper.insert(lastTwoPeriodData);
                }

            }
        }

        CommissionRecordDashBoardResponse currentPeriodData = null;
        if(!StringUtils.isBlank(req.getRecordDateStart())){
            //查询当下时间区间
            currentPeriodData = calculateData(req.getLoginName(),req.getRecordDateStart(),req.getRecordDateEnd(),req.getRecordDateTimeStart(),req.getRecordDateTimeEnd());
        }

        CommissionRecordDashBoardResponse response = new CommissionRecordDashBoardResponse();

        //7.汇总数据
        //汇总当前区间
        sumDataResult(response,currentPeriodData);
        //汇总上个区间
        sumDataResult(response,lastPeriodData);
        //汇总上上个区间
        sumDataResult(response,lastTwoPeriodData);

        log.info("finished to getDashBoardCommissionData:{}",response);

        return Result.success(response);
    }

    /**
     * description: 计算时间区间的佣金数据
     * @param:  [req]
     * @return: com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse
     * @Date: 2023/10/30 14:27
     * @Version: 1.0.0
     * @Author: Lucian
     */
    private CommissionRecordDashBoardResponse calculateData(String loginName,String recordDateStart,String recordDateEnd,String recordDateTimeStart,String recordDateTimeEnd){

        CommissionRecordDashBoardResponse result = new CommissionRecordDashBoardResponse();
        result.setLoginName(loginName);
        result.setRecordDateStart(recordDateStart);
        result.setRecordDateEnd(recordDateEnd);

        //1.查询当前代理团队的存取款
        CommissionRecordDashBoardResponse depositWData = commissionRecordMapper.querySumAgentDepositWData(loginName,recordDateStart,recordDateEnd);
        log.info("The depositWData from :{} to :{} is:{}",recordDateStart,recordDateEnd,depositWData);

        //2.查询当前代理团队的游戏数据
        CommissionRecordDashBoardResponse gameData = commissionRecordMapper.querySumAgentGameData(loginName,recordDateStart,recordDateEnd);
        log.info("The gameData from :{} to :{} is:{}",recordDateStart,recordDateEnd,gameData);

        //3.查询注册人数
        Result<Long> registerUserResult = userFeignService.selectUserTreeByParentNTimeCount(new DashBoardUserTreeQueryReq(loginName,recordDateTimeStart,recordDateTimeEnd));
        log.info("The registerUserNumber from :{} to :{} is:{}",recordDateStart,recordDateEnd,registerUserResult);

        //4.查询首存人数和首存金额
        CommissionRecordDashBoardResponse firstDepositeData = commissionRecordMapper.querySumAgentfirstDepositeData(loginName,recordDateStart,recordDateEnd);
        log.info("The firstDepositeData from :{} to :{} is:{}",recordDateStart,recordDateEnd,firstDepositeData);

        //5.查询有投注额的人数
        CommissionRecordDashBoardResponse betPlayersData = commissionRecordMapper.querybetPlayersCount(loginName,recordDateStart,recordDateEnd);
        log.info("The betPlayersData from :{} to :{} is:{}",recordDateStart,recordDateEnd,betPlayersData);

        //6.封装数据返回
        result.setDeposit(Objects.isNull(depositWData)? BigDecimal.ZERO:depositWData.getDeposit());
        result.setWithdraw(Objects.isNull(depositWData)?BigDecimal.ZERO:depositWData.getWithdraw());
        result.setTurnover(Objects.isNull(gameData)?BigDecimal.ZERO:gameData.getTurnover());
        result.setGgr(Objects.isNull(gameData)?BigDecimal.ZERO:gameData.getGgr());
        result.setWinorloss(Objects.isNull(gameData)?BigDecimal.ZERO:gameData.getWinorloss());
        result.setRegistrationNumber(registerUserResult.isSuccess()&&Objects.isNull(registerUserResult.getData())?0L:registerUserResult.getData());
        result.setFirstDepositAmount(Objects.isNull(firstDepositeData)?BigDecimal.ZERO:firstDepositeData.getFirstDepositAmount());
        result.setFirstDepositPlayers(Objects.isNull(firstDepositeData)?0L:firstDepositeData.getFirstDepositPlayers());
        result.setBetPlayers(Objects.isNull(betPlayersData)?0L:betPlayersData.getBetPlayers());

        //计算佣金
        calculateCommission(result);

        log.info("finished to calculate commission data from {} to {} for {}, result is:{}",recordDateStart,recordDateEnd,loginName,result);
        return result;

    }

    /**
     * description: 计算日期
     * @param:  [req]
     * @return: void
     * @Date: 2023/10/30 15:59
     * @Version: 1.0.0
     * @Author: Lucian
     */
    private void getNeededRecordDate(CommissionRecordDashBoardRequest req){

        String chosenType = req.getChosenType();
        String chosenPeriod = req.getChosenPeriod();

        //月类型
        if(chosenType.equals(DashboardChosenTimeEnum.ChosenType_Month.getName())){

            if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Current.getName())){
                //当前月
                req.setRecordDateStart(DateUtils.getLastNMonthFirstDay(0).toString());
                req.setRecordDateEnd(DateUtils.getLastNMonthLastDay(0).toString());
                req.setRecordDateTimeStart(DateUtils.getLastNMonthFirstDay(0)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEnd(DateUtils.getLastNMonthLastDay(0)+ BaseConstants.END_TIME);
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last.getName())){
                //上一个月
                req.setRecordDateStartLast(DateUtils.getLastNMonthFirstDay(1).toString());
                req.setRecordDateEndLast(DateUtils.getLastNMonthLastDay(1).toString());
                req.setRecordDateTimeStartLast(DateUtils.getLastNMonthFirstDay(1)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLast(DateUtils.getLastNMonthLastDay(1)+ BaseConstants.END_TIME);
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last_Two.getName())){
                //上两个月
                req.setRecordDateStartLastTwo(DateUtils.getLastNMonthFirstDay(2).toString());
                req.setRecordDateEndLastTwo(DateUtils.getLastNMonthLastDay(2).toString());
                req.setRecordDateTimeStartLastTwo(DateUtils.getLastNMonthFirstDay(2)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLastTwo(DateUtils.getLastNMonthLastDay(2)+ BaseConstants.END_TIME);
            }
        }else if(chosenType.equals(DashboardChosenTimeEnum.ChosenType_Week.getName())){
            if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Current.getName())){
                //当前周
                req.setRecordDateStart(DateUtils.getNWeeksAgoMonday(0).toString());
                req.setRecordDateEnd(DateUtils.getNWeeksAgoSunday(0).toString());
                req.setRecordDateTimeStart(DateUtils.getNWeeksAgoMonday(0)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEnd(DateUtils.getNWeeksAgoSunday(0)+ BaseConstants.END_TIME);
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last.getName())){
                //上一个周
                req.setRecordDateStartLast(DateUtils.getNWeeksAgoMonday(1).toString());
                req.setRecordDateEndLast(DateUtils.getNWeeksAgoSunday(1).toString());
                req.setRecordDateTimeStartLast(DateUtils.getNWeeksAgoMonday(1)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLast(DateUtils.getNWeeksAgoSunday(1)+ BaseConstants.END_TIME);
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last_Two.getName())){
                //上两个周
                req.setRecordDateStartLastTwo(DateUtils.getNWeeksAgoMonday(2).toString());
                req.setRecordDateEndLastTwo(DateUtils.getNWeeksAgoSunday(2).toString());
                req.setRecordDateTimeStartLastTwo(DateUtils.getNWeeksAgoMonday(2)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLastTwo(DateUtils.getNWeeksAgoSunday(2)+ BaseConstants.END_TIME);
            }
        }else if(chosenType.equals(DashboardChosenTimeEnum.ChosenType_Day.getName())){
            if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Current.getName())){
                //当天
                req.setRecordDateStart(DateUtils.getNDaysAgo(0).toString());
                req.setRecordDateEnd(DateUtils.getNDaysAgo(0).toString());
                req.setRecordDateTimeStart(DateUtils.getNDaysAgo(0)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEnd(DateUtils.getNDaysAgo(0)+ BaseConstants.END_TIME);
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last.getName())){
                //昨天
                req.setRecordDateStartLast(DateUtils.getNDaysAgo(1).toString());
                req.setRecordDateEndLast(DateUtils.getNDaysAgo(1).toString());
                req.setRecordDateTimeStartLast(DateUtils.getNDaysAgo(1)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLast(DateUtils.getNDaysAgo(1)+ BaseConstants.END_TIME);
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last_Two.getName())){
                //前天
                req.setRecordDateStartLastTwo(DateUtils.getNDaysAgo(2).toString());
                req.setRecordDateEndLastTwo(DateUtils.getNDaysAgo(2).toString());
                req.setRecordDateTimeStartLastTwo(DateUtils.getNDaysAgo(2)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLastTwo(DateUtils.getNDaysAgo(2)+ BaseConstants.END_TIME);
            }
        }
        log.info("handle date finished. The date is:{}",req);

    }

    private void calculateCommission(CommissionRecordDashBoardResponse dashBoardResponse){

        Result<TAgentCustomers> topAgentResult = agentFeignService.queryTopAgentByAccount(dashBoardResponse.getLoginName());
        if(!topAgentResult.isSuccess()||Objects.isNull(topAgentResult.getData())){
            dashBoardResponse.setCommissionAmount(BigDecimal.ZERO.setScale(2));
            return ;
        }
        TAgentCustomers topAgent = topAgentResult.getData();

        //佣金比例
        Result<TAgentContract> agentContractResult = agentFeignService.queryRealContractByLoginName(dashBoardResponse.getLoginName());

        TAgentContract tAgentContract = agentContractResult.getData();

        if(Objects.isNull(tAgentContract)){
            dashBoardResponse.setCommissionAmount(BigDecimal.ZERO.setScale(2));
            return ;
        }

        //是否设置条件
        if(tAgentContract.getSettlementConditions()==1){
            log.info("set settlement conditions--");
            //查询1级代理的所有下级用户

            DashBoardUserTreeQueryReq queryTopEntity = new DashBoardUserTreeQueryReq();
            queryTopEntity.setParent(topAgent.getLoginName());
            Result<List<TCustomerLayer>> userListTopResult = userFeignService.selectUserTreeByParentNTime(queryTopEntity);

            List<String> userNameTopList = null;
            if(userListTopResult.isSuccess()&&!Objects.isNull(userListTopResult.getData())&&userListTopResult.getData().size()>0){
                userNameTopList = userListTopResult.getData().stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList());
            }else {
                log.info("No user data.");
                dashBoardResponse.setCommissionAmount(BigDecimal.ZERO.setScale(2));
                return ;
            }

            Long count = 0L;
            if(tAgentContract.getCommissionPlanType().equals(CommissionPlanTypeEnum.TURNOVER.getCode())){
                count = commissionRecordMapper.queryTurnoverActivePlayerCount(userNameTopList,dashBoardResponse.getRecordDateStart(),dashBoardResponse.getRecordDateEnd(),tAgentContract.getActiveUserTurnover());
            }else if(tAgentContract.getCommissionPlanType().equals(CommissionPlanTypeEnum.GGR.getCode())){
                count = commissionRecordMapper.queryGgrActivePlayerCount(userNameTopList,dashBoardResponse.getRecordDateStart(),dashBoardResponse.getRecordDateEnd(),tAgentContract.getActiveUserTurnover());
            }
            log.info("Active count is :{}",count);

            if(count < tAgentContract.getActiveUserHeadcount()){
                log.info("The active count is not enough!");
                dashBoardResponse.setCommissionAmount(BigDecimal.ZERO.setScale(2));
                return ;
            }
        }

        //佣金比例 暂时选择第一阶段
        SettlementPercentageReq percentageReq = tAgentContract.getSettlementPercentageList().get(0);

        //佣金费率 选择 allGameType
        BigDecimal commissionValue = new BigDecimal(String.valueOf(percentageReq.getAllGamesPercentage())).divide(new BigDecimal(100));
        log.info("commission rate is:{}", commissionValue);
        //根据佣金方案来计算
        String commissionType = tAgentContract.getCommissionPlanType();
        log.info("commission type is :{}",commissionType);

        if(commissionType.equals(CommissionPlanTypeEnum.TURNOVER.getCode())){
            dashBoardResponse.setCommissionAmount(dashBoardResponse.getTurnover().multiply(commissionValue).setScale(2, RoundingMode.DOWN));
            return ;
        }else if(commissionType.equals(CommissionPlanTypeEnum.GGR.getCode())){
            if(dashBoardResponse.getGgr().compareTo(BigDecimal.ZERO)>=0){
                dashBoardResponse.setCommissionAmount(dashBoardResponse.getGgr().multiply(commissionValue).setScale(2, RoundingMode.DOWN));
            }else {
                dashBoardResponse.setCommissionAmount(BigDecimal.ZERO.setScale(2));
            }

        }else {
            dashBoardResponse.setCommissionAmount(BigDecimal.ZERO.setScale(2));
        }


    }

    /**
     * description: 累加计算结果
     * @param:  [source, increment]
     * @return: com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse
     * @Date: 2023/10/30 16:12
     * @Version: 1.0.0
     * @Author: Lucian
     */
    private CommissionRecordDashBoardResponse sumDataResult(CommissionRecordDashBoardResponse source,CommissionRecordDashBoardResponse increment){
        if(!Objects.isNull(increment)){
            log.info("begin to sub data from increment:{} to source:{} ",increment,source);
            source.setCommissionAmount(source.getCommissionAmount().add(increment.getCommissionAmount()));
            source.setRegistrationNumber(source.getRegistrationNumber()+increment.getRegistrationNumber());
            source.setFirstDepositPlayers(source.getFirstDepositPlayers()+increment.getFirstDepositPlayers());
            source.setBetPlayers(source.getBetPlayers()+increment.getBetPlayers());
            source.setTurnover(source.getTurnover().add(increment.getTurnover()));
            source.setGgr(source.getGgr().add(increment.getGgr()));
            source.setWinorloss(source.getWinorloss().add(increment.getWinorloss()));
            source.setFirstDepositAmount(source.getFirstDepositAmount().add(increment.getFirstDepositAmount()));
            source.setDeposit(source.getDeposit().add(increment.getDeposit()));
            source.setWithdraw(source.getWithdraw().add(increment.getWithdraw()));
        }
        log.info("finished sub data, result is:{}",source);
        return source;
    }

}
