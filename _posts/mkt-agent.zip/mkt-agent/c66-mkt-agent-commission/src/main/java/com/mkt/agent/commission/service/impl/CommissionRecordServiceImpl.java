package com.mkt.agent.commission.service.impl;

import com.alibaba.nacos.common.utils.MD5Utils;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.gson.Gson;
import com.mkt.agent.commission.clickhouse.mapper.TDailyOrderMapper;
import com.mkt.agent.commission.fegin.AgentFeignService;
import com.mkt.agent.commission.fegin.UserFeignService;
import com.mkt.agent.commission.mapper.*;
import com.mkt.agent.commission.req.CommissionValues;
import com.mkt.agent.commission.service.CommissionRecordService;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractList;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordDashBoardRequest;
import com.mkt.agent.common.entity.api.userapi.requests.AgentListRequest;
import com.mkt.agent.common.entity.clickhouse.req.DashBoardUserTreeQueryReq;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.common.entity.clickhouse.resp.ClDashBoardDataRes;
import com.mkt.agent.common.enums.CommissionPlanTypeEnum;
import com.mkt.agent.common.enums.CommissionRecordStatusEnum;
import com.mkt.agent.common.enums.DashboardChosenTimeEnum;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.NumberUtils;
import com.mkt.agent.common.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;


@Service
@Slf4j
public class CommissionRecordServiceImpl extends ServiceImpl<CommissionRecordMapper, AgentCommissionRecord> implements CommissionRecordService {

    @Autowired
   private TAgentContractBindMapper tAgentContractBindMapper  ;

    @Resource
    private CommissionRecordMapper commissionRecordMapper;

    @Resource
    private AgentFeignService agentFeignService;

    @Resource
    private UserFeignService userFeignService;

    @Resource
    private CommissionRecordDashBoardMapper commissionRecordDashBoardMapper;

    @Autowired
    private RedisUtil redisUtil ;


    @Value("${tempReport.expireLongTime:900}") //半小时
    private Long expireLongTime;


    @Override
    public Result<CommissionRecordDashBoardResponse> getDashBoardCommissionData(CommissionRecordDashBoardRequest req) {

        //1.计算日期
        getNeededRecordDate(req);
        log.info("CommissionRecordServiceImpl getDashBoardCommissionData params:{}",req);

        CommissionRecordDashBoardResponse lastPeriodData = null;
        //查询记录表，查不到再去计算，计算完入库记录表
        if(!StringUtils.isBlank(req.getRecordDateStartLast())){
            //查询上个时间区间数据
            lastPeriodData = commissionRecordDashBoardMapper.selectOne(new LambdaQueryWrapper<CommissionRecordDashBoardResponse>().eq(CommissionRecordDashBoardResponse::getRecordDateStart,req.getRecordDateStartLast())
                    .eq(CommissionRecordDashBoardResponse::getRecordDateEnd,req.getRecordDateEndLast()).eq(CommissionRecordDashBoardResponse::getLoginName,req.getLoginName()));
            if(Objects.isNull(lastPeriodData)){
                //计算
                lastPeriodData = calculateData(req.getLoginName(),req.getRecordDateStartLast(),req.getRecordDateEndLast(),req.getRecordDateTimeStartLast(),req.getRecordDateTimeEndLast());
                lastPeriodData.setLoginName(req.getLoginName());
                lastPeriodData.setRecordDateStart(req.getRecordDateStartLast());
                lastPeriodData.setRecordDateEnd(req.getRecordDateEndLast());

                //判断是否需要入数据库
                if(DateUtils.isBeforeCurrentMonth(lastPeriodData.getRecordDateStart(),lastPeriodData.getRecordDateEnd())){
                    commissionRecordDashBoardMapper.insert(lastPeriodData);
                }
            }
        }

        CommissionRecordDashBoardResponse lastTwoPeriodData = null;

        if(!StringUtils.isBlank(req.getRecordDateStartLastTwo())){

            //查询上上个时间区间数据
            lastTwoPeriodData = commissionRecordDashBoardMapper.selectOne(new LambdaQueryWrapper<CommissionRecordDashBoardResponse>().eq(CommissionRecordDashBoardResponse::getRecordDateStart,req.getRecordDateStartLastTwo())
                    .eq(CommissionRecordDashBoardResponse::getRecordDateEnd,req.getRecordDateEndLastTwo()).eq(CommissionRecordDashBoardResponse::getLoginName,req.getLoginName()));
            if(Objects.isNull(lastTwoPeriodData)){
                //计算
                lastTwoPeriodData = calculateData(req.getLoginName(),req.getRecordDateStartLastTwo(),req.getRecordDateEndLastTwo(),req.getRecordDateTimeStartLastTwo(),req.getRecordDateTimeEndLastTwo());
                lastTwoPeriodData.setLoginName(req.getLoginName());
                lastTwoPeriodData.setRecordDateStart(req.getRecordDateStartLastTwo());
                lastTwoPeriodData.setRecordDateEnd(req.getRecordDateEndLastTwo());
                //判断是否入库
                if(DateUtils.isBeforeCurrentMonth(lastTwoPeriodData.getRecordDateStart(),lastTwoPeriodData.getRecordDateEnd())){
                    commissionRecordDashBoardMapper.insert(lastTwoPeriodData);
                }

            }
        }

        CommissionRecordDashBoardResponse currentPeriodData = null;
        if(!StringUtils.isBlank(req.getRecordDateStart())){
            //查询当下时间区间
            currentPeriodData = calculateData(req.getLoginName(),req.getRecordDateStart(),req.getRecordDateEnd(),req.getRecordDateTimeStart(),req.getRecordDateTimeEnd());
        }

        CommissionRecordDashBoardResponse response = new CommissionRecordDashBoardResponse();

        //7.汇总数据
        //汇总当前区间
        sumDataResult(response,currentPeriodData);
        //汇总上个区间
        sumDataResult(response,lastPeriodData);
        //汇总上上个区间
        sumDataResult(response,lastTwoPeriodData);

        log.info("finished to getDashBoardCommissionData:{}",response);

        return Result.success(response);
    }
    @Autowired
private TAgentContractListMapper tAgentContractListMapper;


    public Map<String,Object>  calcCommissionData(com.mkt.agent.commission.req.TAgentCustomers agentCustomers , Map<String,Object> parame) {
        //开始计算佣金

        // 获取佣金需求
        Map<String,Object> result =  new HashMap<>() ;

//        Map<String,String> parame = new HashMap<>();
        parame.put("id",agentCustomers.getCommissionContractBindId() + "") ;

        String  startDate =   parame.get("startDate").toString() ;
        String  endDate =   parame.get("endDate").toString() ;
        String sutff  = startDate + endDate;
        String  sutffLost =  startDate + endDate + "_lost";

        String topKey =    agentCustomers.getLoginName() +  sutff;
        String topKeyLost =    agentCustomers.getLoginName() +  sutffLost;

        if (redisUtil.get(topKeyLost) != null  &&  parame.get("isSave").equals("-1") ){
            log.info("有 佣金数据为 yj={}",redisUtil.get(topKey) );
            return   result  ;
        }



        TAgentContract  agentContract   =  agentContractMapper.selectByIdParame(parame) ;

        log.info("agentContract-agentContract------={}",new Gson().toJson(agentContract));

        //获取佣金明细
        Map<String, Object> parame2 =new HashMap<>();
        parame2.put("contract_id",agentContract.getId() +"" );
        List<TAgentContractList>  lists   =  tAgentContractListMapper.selectByMap(parame2) ;


        log.info("TAgentContractList-lists------={}",new Gson().toJson(lists));

        CommissionValues  commissionValues  = new CommissionValues() ;
        if(agentContract.getCommissionPlanType().equals("TURNOVER")){
            log.info(" 开始计算 TURNOVER  模式");
              commissionValues = calcCommissionDataByTurnover(agentCustomers,agentContract,lists,parame);
        }else {
            log.info(" 开始计算 GGR  模式");

              commissionValues =   calcCommissionDataByGgr(agentCustomers,agentContract,lists,parame);

        }

         // 开始 一级保存佣金

//        commissionRecordMapper.insert(obj);

        log.info("打印 一级佣金 记录    ,  commissionValues={},agentCustomers={}" ,commissionValues.getYj(),new Gson().toJson(agentCustomers));
        if(commissionValues.getYj().doubleValue() >  0) {
            AgentCommissionRecord tops = new AgentCommissionRecord();
            tops.setCustomerId(agentCustomers.getCustomersId());
            tops.setParentId(agentCustomers.getParentId());
            tops.setAgentAccount(agentCustomers.getLoginName());
            tops.setLevel1AgentAccount(agentCustomers.getLoginName());
            tops.setAgentType(agentCustomers.getAgentType());
            tops.setParentAccount(agentCustomers.getParentName());
            tops.setSiteId(agentCustomers.getSiteId());
            tops.setHashCode(getHashCode(agentCustomers.getLoginName(),parame.get("startDate").toString().substring(0,7)));
            tops.setAgentLevel(agentCustomers.getAgentLevel());
            tops.setSettlementConditions(agentContract.getSettlementConditions());
            tops.setActiveUserTurnover(agentContract.getActiveUserTurnover1());
            tops.setActiveUserHeadcount(agentContract.getActiveUserHeadcount());
//        tops.seto
            tops.setActualUserCount(commissionValues.getSumactiveUser());
            tops.setCommissionValues("ALL_GAME_TYPES");
            tops.setPercentageDetails(agentContract.getPercentageDetails());
//        commission_plan_name
            tops.setCommissionPlanName(agentContract.getCommissionPlanName());
            tops.setCommissionPlanId(agentContract.getId());
            tops.setCommissionType(agentContract.getCommissionPlanType());
            tops.setCommissionValue(NumberUtils.twoScaleFormat(commissionValues.getBl().divide(new BigDecimal(100))));
            //settlement_period
            tops.setSettlementPeriod(agentContract.getSettlementPeriod());
            tops.setStatus(agentCustomers.getAgentLevel() == 1 ? CommissionRecordStatusEnum.FIRST_PENDING.getValue() : CommissionRecordStatusEnum.UNPAID.getValue());
            tops.setCommissionAmount(commissionValues.getYj());
            tops.setActualCommissionAmount(BigDecimal.ZERO);
            tops.setAppendCommissionAmount(BigDecimal.ZERO);
            tops.setCurrency(BaseConstants.PHP);
            tops.setGGR(commissionValues.getGgr());
            tops.setTurnover(commissionValues.getTurnover());
            tops.setWinOrLoss(commissionValues.getWinOrLoss());
            tops.setDeposit(commissionValues.getDeposit());
            tops.setWithdrawal(commissionValues.getWithdrawal());
            tops.setSettleDateStart(DateUtils.getLastMonthFirstDay());
            tops.setSettleDateEnd(DateUtils.getLastMonthLastDayV1());

            redisUtil.set(topKey,tops.getCommissionAmount()) ;
            redisUtil.set(topKeyLost,tops.getCommissionAmount()) ;
            redisUtil.setExpire(topKeyLost,expireLongTime);



            tops.setCreatedBy(BaseConstants.SYSTEM);
            if (!parame.get("isSave").equals("-1")) {
                commissionRecordMapper.insert(tops);

            }

            saveDailiData(agentContract,parame,agentCustomers);

            if (!parame.get("isSave").equals("-1")) {

                //查找 符合条件玩家记录
                savePalyerUser(commissionValues.getList(), agentContract, parame, agentCustomers);
            }
            // 开始保存代理数据

            //查询 我的代理数据




        }else {
            redisUtil.set(topKey,0) ;
            redisUtil.set(topKeyLost,0) ;
            redisUtil.setExpire(topKeyLost,expireLongTime);

            //查询所有代理
            AgentListRequest agentListRequest = new AgentListRequest();
            agentListRequest.setRootParentName(agentCustomers.getLoginName());
            agentListRequest.setIsQueryTree(true);
            Result<List<TAgentCustomers>> agentList = agentFeignService.getAgentList(agentListRequest);

            log.info("代理账号:={},下级代理数据为={}", agentCustomers.getLoginName(),agentList.getData());
            if (agentList!= null &&  agentList.getData()  != null ) {

                List<TAgentCustomers> tempList = agentList.getData();

                for (TAgentCustomers object : tempList) {
                    topKey = agentCustomers.getLoginName() + sutff;
                    topKeyLost = object.getLoginName() + sutffLost;
                    redisUtil.set(topKey, 0);
                    redisUtil.set(topKeyLost, 0);
                }
            }
        }


return  result ;



    }

    @Override
    public void updatePlayerStatus(Map<String, String> req) {

        String loginName = req.get("loginName");

        String status = req.get("status");


        List<TCustomerLayer>  list = userMapper.selectUserTreeByParentNTime(loginName,null,null) ;
        List<String> payers   = new ArrayList<>();
        if(list.size() >0) {
              payers = list.stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList());

            log.info("用户数据------ = {}", new Gson().toJson(payers));


        }

        payers.add(loginName);

        Map<String, Object> parame = new HashMap<>();

        parame.put("loginName", payers);
        parame.put("status", status);

        userMapper.updateUserIsEnable(parame);



    }

    private void saveDailiData(TAgentContract agentContract, Map<String, Object> parame, com.mkt.agent.commission.req.TAgentCustomers agentCustomers) {

            // 先找2级



        Map<String, Object> maps   = new HashMap<>();
        maps.put("parent_id",  agentCustomers.getCustomersId()) ;
        List<com.mkt.agent.commission.req.TAgentCustomers> list=    userMapper.listTopAgent(maps) ;
        log.info("下级代理 ---list={}",list);

        //  开始计算下级数据
        for(com.mkt.agent.commission.req.TAgentCustomers customers :  list) {
            //查看佣金比例
            Map<String, Object> parame2  =   new HashMap<>();

            String  startDate =   parame.get("startDate").toString() ;
            String  endDate =   parame.get("endDate").toString() ;
            String sutff  = startDate + endDate;
            String  sutffLost =  startDate + endDate + "_lost";

            String topKey =    customers.getLoginName() +  sutff;
            String topKeyLost =    customers.getLoginName() +  sutffLost;

            parame2.put("login_name",customers.getLoginName());
           List<TAgentContractBind> contractBindList =    tAgentContractBindMapper.selectByMap(parame2) ;

            if(contractBindList.size() >   0 ) {
                TAgentContractBind tAgentContractBind   =  contractBindList.get(0) ;
                log.info("佣金比例  percentageDetails={}",tAgentContractBind.getPercentageDetails() );

                JSONArray jsonArray =    new JSONArray(tAgentContractBind.getPercentageDetails()) ;

                if(jsonArray.length() >  0 ) {
                    JSONObject object =  jsonArray.getJSONObject(0) ;
                    BigDecimal  allGamesPercentage  =  object.getBigDecimal("allGamesPercentage") ;
                    // 开始计算

                    Map<String, Object> byteHouseData = getByteHouseData1(customers.getLoginName(), null, parame);

                    log.info("-----byteHouseData ={}" , new Gson().toJson(byteHouseData));

                    AgentCommissionRecord tops = new AgentCommissionRecord();
                    tops.setCustomerId(customers.getCustomersId());
                    tops.setParentId(customers.getParentId());
                    tops.setAgentAccount(customers.getLoginName());
                    tops.setLevel1AgentAccount(agentCustomers.getLoginName());
                    tops.setAgentType(1);
                    tops.setParentAccount(customers.getParentName());
                    tops.setSiteId(customers.getSiteId());
                    tops.setHashCode(getHashCode(customers.getLoginName(),parame.get("startDate").toString().substring(0,7)));
                    tops.setAgentLevel(customers.getAgentLevel());
                    tops.setSettlementConditions(agentContract.getSettlementConditions());
                    tops.setActiveUserTurnover(agentContract.getActiveUserTurnover1());
                    tops.setActiveUserHeadcount(agentContract.getActiveUserHeadcount());
//        tops.seto
                    tops.setCommissionValues("ALL_GAME_TYPES");
                    tops.setPercentageDetails(agentContract.getPercentageDetails());
//        commission_plan_name
                    tops.setCommissionPlanName(agentContract.getCommissionPlanName());
                    tops.setCommissionPlanId(agentContract.getId());
                    tops.setCommissionType(agentContract.getCommissionPlanType());
                    tops.setCommissionValue(NumberUtils.twoScaleFormat(allGamesPercentage.divide(new BigDecimal(100))));
                    //settlement_period
                    tops.setSettlementPeriod(agentContract.getSettlementPeriod());
                    tops.setStatus(customers.getAgentLevel() == 1 ? CommissionRecordStatusEnum.FIRST_PENDING.getValue() : CommissionRecordStatusEnum.UNPAID.getValue());
                    tops.setGGR(new BigDecimal(byteHouseData.get("ggr").toString()));
                    tops.setTurnover(new BigDecimal(byteHouseData.get("turnover").toString()));
                    tops.setWinOrLoss(new BigDecimal(byteHouseData.get("winOrLoss").toString()));
                    tops.setDeposit(new BigDecimal(byteHouseData.get("depositAmount").toString()));
                    tops.setWithdrawal(new BigDecimal(byteHouseData.get("withdrawalAmount").toString()));
                    tops.setSettleDateStart(DateUtils.getLastMonthFirstDay());
                    tops.setSettleDateEnd(DateUtils.getLastMonthLastDayV1());
                    if(agentContract.getCommissionPlanType().equals("TURNOVER")){
                        tops.setCommissionAmount(NumberUtils.twoScaleFormat(tops.getTurnover().multiply(allGamesPercentage).divide(new BigDecimal(100))));
                    }else {
                        //查看上级佣金
                        String parentKey =  customers.getParentName() +  sutff ;
                        Object money = redisUtil.get(parentKey);//上级佣金
                        Double m = 0D;
                        if(money != null   &&  !StringUtils.isBlank(money.toString())){
                            m  = Double.valueOf(money.toString()) ;
                        }


                        if(tops.getGGR().doubleValue() > 0  &&  m >  0  ) {


                            tops.setCommissionAmount(NumberUtils.twoScaleFormat(tops.getGGR().multiply(allGamesPercentage).divide(new BigDecimal(100))));
                        }else {
                            tops.setCommissionAmount((BigDecimal.ZERO));
                        }
                    }
                    redisUtil.set(topKey,tops.getCommissionAmount()) ;
                    redisUtil.set(topKeyLost,tops.getCommissionAmount()) ;
                    redisUtil.setExpire(topKeyLost,expireLongTime);
                    tops.setActualCommissionAmount(BigDecimal.ZERO);
                    tops.setAppendCommissionAmount(BigDecimal.ZERO);
                    tops.setCurrency(BaseConstants.PHP);

                    tops.setCreatedBy(BaseConstants.SYSTEM);


                    if (!parame.get("isSave").equals("-1")) {

                        commissionRecordMapper.insert(tops);
                    }
                    if(customers.getAgentLevel() != 5   ){
                        maps   = new HashMap<>();
                        maps.put("parent_id",  customers.getCustomersId()) ;

                            saveDailiData(agentContract,parame,customers);

                    }

                }

            }


        }




    }


    private String getHashCode(String loginName, String startDate) {
        String res = loginName + startDate;
       try {
           return MD5Utils.md5Hex(res.getBytes()) ;
       }catch (Exception e) {
           return   res  ;
       }
    }

    private void savePalyerUser(List<TCustomerLayer> list, TAgentContract agentContract, Map<String, Object> parame, com.mkt.agent.commission.req.TAgentCustomers tAgentCustomers) {
        String startDate  = parame.get("startDate").toString() ;
        String endDate  = parame.get("endDate").toString() ;

        Map<String,TCustomerLayer> tempData = new HashMap<>() ;
        for(TCustomerLayer customerLayer : list){

            tempData.put(customerLayer.getLoginName(),customerLayer) ;
        }

        Map<String,Object> map = new HashMap<>() ;
        map.put("min", startDate);
        map.put("max", endDate);
        if (agentContract.getSettlementConditions() ==1 ){
            //显示活跃数据 按要求显示数据
            map.put("activeUserTurnover", agentContract.getActiveUserTurnover());
        }


        List<String> payers = list.stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList());

        log.info("用户数据------ = {}",new Gson().toJson(payers));

        List<List<String>> splitLists = splitArrayList(payers, splitRow);



        for (List<String> sublist : splitLists) {
            map.put("loginName", sublist);

            List<ClDashBoardDataRes> listData = tDailyOrderMapper.getNewAllDataNew2(map);   //  查询 bytehouse 数据

            if(listData.size() >  0 ) {
                log.info("-----有效用户为={},用户数为:={}" , new Gson().toJson(listData),listData.size());

                for(ClDashBoardDataRes dashBoardDataRes : listData){

                    TCustomerLayer  tCustomerLayer  =  tempData.get(dashBoardDataRes.getLoginName());

                    AgentCommissionRecord tops = new AgentCommissionRecord();
                    tops.setCustomerId(tCustomerLayer.getCustomerId());
                    tops.setParentId(tCustomerLayer.getParentId());
                    tops.setAgentAccount(tCustomerLayer.getLoginName());
                    tops.setLevel1AgentAccount(tAgentCustomers.getLoginName());
                    tops.setAgentType(3);
                    tops.setParentAccount(tCustomerLayer.getParentLoginName());
                    tops.setSiteId(tCustomerLayer.getSiteId());
                    tops.setHashCode(getHashCode(tCustomerLayer.getLoginName(),parame.get("startDate").toString().substring(0,7)));
                    tops.setCommissionValues("ALL_GAME_TYPES");
//        commission_plan_name
                    tops.setCurrency(BaseConstants.PHP);
                    tops.setGGR(dashBoardDataRes.getGgr());
                    tops.setTurnover(dashBoardDataRes.getTurnover1());
                    tops.setWinOrLoss(dashBoardDataRes.getWinOrLoss());
                    tops.setDeposit(dashBoardDataRes.getDepositAmount());
                    tops.setWithdrawal(dashBoardDataRes.getWithdrawalAmount());
                    tops.setSettleDateStart(DateUtils.getLastMonthFirstDay());
                    tops.setSettleDateEnd(DateUtils.getLastMonthLastDayV1());
                    tops.setCreatedBy(BaseConstants.SYSTEM);
                    try {
                        commissionRecordMapper.insert(tops);
                    }catch (Exception e) {

                    }

                }




            }




        }



    }

    private CommissionValues calcCommissionDataByGgr(com.mkt.agent.commission.req.TAgentCustomers agentCustomers, TAgentContract agentContract, List<TAgentContractList> lists,Map<String,Object> parame) {

        log.info(" 开始计算   模式");
        log.info(" 计算 GGR 参数 agentCustomers ={}  ,agentContract ={}  , lists ={} ,parame={} ",new Gson().toJson(agentCustomers),new Gson().toJson(agentContract),new Gson().toJson(lists),new Gson().toJson(parame));

        CommissionValues commissionValues = new CommissionValues()  ;
        commissionValues.setYj(BigDecimal.ZERO);

        String  isFd =   agentContract.getIsFd();
        int settlementConditions =   agentContract.getSettlementConditions();


        Map<String,Object>  byteHouseData  =   new HashMap<>();

        log.info("fd={},,,,settlementConditions={}",isFd    , settlementConditions);
        byteHouseData  =    getByteHouseData1(agentCustomers.getLoginName(),agentContract, parame );

        commissionValues.setTurnover(new BigDecimal(byteHouseData.get("turnover").toString()));
        commissionValues.setDeposit(new BigDecimal(byteHouseData.get("depositAmount").toString()));
        commissionValues.setGgr(new BigDecimal(byteHouseData.get("ggr").toString()));
        commissionValues.setWinOrLoss(new BigDecimal(byteHouseData.get("winOrLoss").toString()));
        commissionValues.setWithdrawal(new BigDecimal(byteHouseData.get("withdrawalAmount").toString()));
        commissionValues.setSumactiveUser(Integer.valueOf(byteHouseData.get("sumactiveUser").toString()));
        commissionValues.setList((List<TCustomerLayer>) byteHouseData.get("customerLayers"));

    log.info("-----commissionValues={}",new Gson().toJson(commissionValues));
        BigDecimal ggr  =    new BigDecimal(byteHouseData.get("ggr").toString());

        BigDecimal  yj  =  BigDecimal.ZERO ;
        if(ggr.doubleValue() <=0) {
            return  commissionValues  ;
        }
        if(!StringUtils.isBlank(isFd) && isFd.equals("1")  ){

            //勾选 FD 和活跃用户指标  需要获取 Turnover  ,active User 满足情况
            int fdCount  =agentContract.getFdCount();
            int  sc =    Integer.valueOf(byteHouseData.get("sc").toString());

            log.info("lists.size() >  0   &&   lists.get(0).getIsChecked()={},turnoverlist" , lists.size() >  0   &&   lists.get(0).getIsChecked().equals("1") ,new Gson().toJson(lists));
            if(sc <= fdCount) {
                //
                commissionValues.setBl(agentContract.getFdCommission());
                yj  =  ggr.multiply(agentContract.getFdCommission()).divide(new BigDecimal(100));
                log.info("读取的佣金为 FD 不满足条件 ");
            }else if(      settlementConditions  ==  1){
                log.info("首存人数满足 ----     选中活跃数据  ");

                int activeUser =    agentContract.getActiveUserHeadcount() ;
                int sumactiveUser  = Integer.valueOf(byteHouseData.get("sumactiveUser").toString()) ;

                if(sumactiveUser >=   activeUser  ){
                    //开始 计算佣金
                    log.info("首存人数满足 ----     满足选中活跃数据  ");
                    commissionValues.setBl(agentContract.getActiveUserCommission());

                    yj  =  ggr.multiply(agentContract.getActiveUserCommission()).divide(new BigDecimal(100));

                }else {
                    log.info("首存人数满足 ----     不满足选中活跃数据  ");

                }
            }else if(lists.size() >  0   &&   lists.get(0).getIsChecked().equals("1")){
                log.info("首存人数满足 ----  满足  阶梯佣金数据   ");

                TAgentContractList getIndex =   getIndexData(lists,ggr);

                if (getIndex != null ) {
                    commissionValues.setBl(getIndex.getCommission());

                    yj  =  ggr.multiply(getIndex.getCommission()).divide(new BigDecimal(100));

                }
            }


        } else  if(settlementConditions  ==  1) {
            //  仅勾选active user
            log.info("只勾选了  仅勾选active user  ");

            int activeUser =    agentContract.getActiveUserHeadcount() ;
            int sumactiveUser  = Integer.valueOf(byteHouseData.get("sumactiveUser").toString()) ;

            if(sumactiveUser >=   activeUser  ){
                //开始 计算佣金
                commissionValues.setBl(agentContract.getActiveUserCommission());

                yj  =  ggr.multiply(agentContract.getActiveUserCommission()).divide(new BigDecimal(100));

            }

        }else if(lists.size() >  0   &&   lists.get(0).getIsChecked().equals("1")){
            log.info(" 只勾选了 阶梯佣金数据  ");
            TAgentContractList getIndex =   getIndexData(lists,ggr);

            if (getIndex != null ) {

                commissionValues.setBl(getIndex.getCommission());

                yj  =  ggr.multiply(getIndex.getCommission()).divide(new BigDecimal(100));

            }
        }

        yj  = NumberUtils.twoScaleFormat(yj);

        log.info("----- 代理账号 ={}, 一级佣金为={}", agentCustomers.getLoginName()  ,  yj  );
        commissionValues.setYj(yj);


        return  commissionValues ;

    }
    @Autowired
private UserMapper userMapper ;

    private Map<String, Object> getByteHouseData1(String loginName, TAgentContract agentContract, Map<String, Object> parame) {
        Map<String, Object> data  =  new HashMap<>() ;
        List<ClDashBoardDataRes> subData = new ArrayList<>();


        String startDate  = parame.get("startDate").toString() ;
        String endDate  = parame.get("endDate").toString() ;
        int  sumactiveUser = 0  ;

        try{
            List<TCustomerLayer>  list = userMapper.selectUserTreeByParentNTime(loginName,null,null) ;

            data.put("customerLayers",list);

            List<String> payers = list.stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList());

            log.info("用户数据------ = {}",new Gson().toJson(payers));

            List<List<String>> splitLists = splitArrayList(payers, splitRow);
            


            for (List<String> sublist : splitLists) {

                Map<String,Object>  p = new HashMap<>() ;

                p.put("loginName", sublist);
                p.put("min", startDate);
                p.put("max", endDate);


                List<ClDashBoardDataRes> listData = tDailyOrderMapper.getNewAllDataNew(p);   //  查询 bytehouse 数据

                log.info("listData-------={}", new Gson().toJson(listData));
                subData.addAll(listData);

                if(agentContract != null     &&  agentContract.getSettlementConditions() ==1){
                    p.put("activeUserTurnover", agentContract.getActiveUserTurnover1());
                    sumactiveUser   =  sumactiveUser +      tDailyOrderMapper.getActiveUserTurnoverCount(p);
                }

            }





        }catch (Exception e) {
            e.printStackTrace();
        }

        log.info("subData={},sumactiveUsersumactiveUser={}",new Gson().toJson(subData),sumactiveUser);

        BigDecimal turnover   =   (BigDecimal.ZERO) ;
        BigDecimal ggr   =   (BigDecimal.ZERO) ;
        int  sc =   0;
        BigDecimal  winOrLoss  = BigDecimal.ZERO ;
        BigDecimal depositAmount   =   BigDecimal.ZERO ;
        BigDecimal withdrawalAmount  =  BigDecimal.ZERO ;

        for(ClDashBoardDataRes res :  subData){
            turnover  =  turnover.add(res.getTurnover1());
            ggr   =  ggr.add(res.getGgr()) ;
            winOrLoss   =  winOrLoss.add(res.getWinOrLoss()) ;
            depositAmount   =  depositAmount.add(res.getDepositAmount()) ;
            withdrawalAmount   =  withdrawalAmount.add(res.getWithdrawalAmount()) ;
            sc = sc +  res.getFirstDeposit().intValue();
        }


        data.put("turnover",turnover) ;
        data.put("ggr",ggr) ;
        data.put("sc",sc) ;
        data.put("winOrLoss",winOrLoss) ;
        data.put("depositAmount",depositAmount) ;
        data.put("withdrawalAmount",withdrawalAmount) ;
        data.put("sumactiveUser",sumactiveUser) ;


        return  data;
    }

    @Autowired
private TDailyOrderMapper tDailyOrderMapper;

    private <T> List<List<T>> splitArrayList(List<T> list, int splitSize) {
        List<List<T>> subLists = new ArrayList<>();
        for (int i = 0; i < list.size(); i += splitSize) {
            int endIndex = Math.min(i + splitSize, list.size());
            subLists.add(list.subList(i, endIndex));
        }
        return subLists;
    }


    @Value("${tempReport.splitRow:6500}") //
    private Integer splitRow;


    private CommissionValues calcCommissionDataByTurnover(com.mkt.agent.commission.req.TAgentCustomers agentCustomers, TAgentContract agentContract, List<TAgentContractList> lists,Map<String,Object> parame) {

        log.info(" 计算 Turnover 参数 agentCustomers ={}  ,agentContract ={}  , lists ={} ,parame={} ",new Gson().toJson(agentCustomers),new Gson().toJson(agentContract),new Gson().toJson(lists),new Gson().toJson(parame));

        CommissionValues commissionValues =new CommissionValues();

        commissionValues.setYj(BigDecimal.ZERO);

         String  isFd =   agentContract.getIsFd();
        int settlementConditions =   agentContract.getSettlementConditions();

//        commissionValues

        Map<String,Object>  byteHouseData;

        log.info("fd={},,,,settlementConditions={}",isFd    , settlementConditions);
        byteHouseData  =    getByteHouseData1(agentCustomers.getLoginName(),agentContract, parame );

        /**
         * data.put("turnover",turnover) ;
         *         data.put("ggr",ggr) ;
         *         data.put("sc",sc) ;
         *         data.put("winOrLoss",winOrLoss) ;
         *         data.put("depositAmount",depositAmount) ;
         *         data.put("withdrawalAmount",withdrawalAmount) ;
         */
        commissionValues.setTurnover(new BigDecimal(byteHouseData.get("turnover").toString()));
        commissionValues.setDeposit(new BigDecimal(byteHouseData.get("depositAmount").toString()));
        commissionValues.setGgr(new BigDecimal(byteHouseData.get("ggr").toString()));
        commissionValues.setWinOrLoss(new BigDecimal(byteHouseData.get("winOrLoss").toString()));
        commissionValues.setWithdrawal(new BigDecimal(byteHouseData.get("withdrawalAmount").toString()));
        commissionValues.setSumactiveUser(Integer.valueOf(byteHouseData.get("sumactiveUser").toString()));
        BigDecimal turnover  =    new BigDecimal(byteHouseData.get("turnover").toString());
        commissionValues.setList((List<TCustomerLayer>) byteHouseData.get("customerLayers"));

        BigDecimal  yj  =  BigDecimal.ZERO ;
        if(!StringUtils.isBlank(isFd) && isFd.equals("1")  ){
            int fdCount  =agentContract.getFdCount();
            int  sc =    Integer.valueOf(byteHouseData.get("sc").toString());



            log.info("lists.size() >  0   &&   lists.get(0).getIsChecked()={},turnoverlist" , lists.size() >  0   &&   lists.get(0).getIsChecked().equals("1") ,new Gson().toJson(lists));
            if(sc <= fdCount) {
                //
                commissionValues.setBl(agentContract.getFdCommission());

                yj  =  turnover.multiply(agentContract.getFdCommission()).divide(new BigDecimal(100));
                log.info("读取的佣金为 FD 不满足条件 ");

            }else if(   settlementConditions  ==  1){
                log.info("首存人数满足 ----  满足  选中活跃数据  ");

                int activeUser =    agentContract.getActiveUserHeadcount() ;
                int sumactiveUser  = Integer.valueOf(byteHouseData.get("sumactiveUser").toString()) ;

                if(sumactiveUser >=   activeUser  ){
                    //开始 计算佣金
                    commissionValues.setBl(agentContract.getActiveUserCommission());

                    yj  =  turnover.multiply(agentContract.getActiveUserCommission()).divide(new BigDecimal(100));

                }
            }else if(lists.size() >  0   &&   lists.get(0).getIsChecked().equals("1")){
                log.info("首存人数满足 ----  满足  阶梯佣金数据   ");

                TAgentContractList getIndex =   getIndexData(lists,turnover);

                if (getIndex != null ) {
                    commissionValues.setBl(getIndex.getCommission());

                    yj  =  turnover.multiply(getIndex.getCommission()).divide(new BigDecimal(100));

                }
            }


        } else  if(settlementConditions  ==  1) {
            //  仅勾选active user
            log.info("只勾选了  仅勾选active user  ");

            int activeUser =    agentContract.getActiveUserHeadcount() ;
            int sumactiveUser  = Integer.valueOf(byteHouseData.get("sumactiveUser").toString()) ;

            if(sumactiveUser >=   activeUser  ){
                //开始 计算佣金
                commissionValues.setBl(agentContract.getActiveUserCommission());

                yj  =  turnover.multiply(agentContract.getActiveUserCommission()).divide(new BigDecimal(100));

            }

        }else if(lists.size() >  0   &&   lists.get(0).getIsChecked().equals("1")){
            log.info(" 只勾选了 阶梯佣金数据  ");
            TAgentContractList getIndex =   getIndexData(lists,turnover);

            if (getIndex != null ) {
                commissionValues.setBl(getIndex.getCommission());

                yj  =  turnover.multiply(getIndex.getCommission()).divide(new BigDecimal(100));

            }
        }
        yj  = NumberUtils.twoScaleFormat(yj);

        log.info("----- 代理账号 ={}, 一级佣金为={}", agentCustomers.getLoginName()  ,  yj  );
        commissionValues.setYj(yj);
        return   commissionValues  ;
        
    }

    private TAgentContractList getIndexData(List<TAgentContractList> lists, BigDecimal turnover) {

        TAgentContractList result = null ;

        Collections.sort(lists, new Comparator<TAgentContractList>() {
            @Override
            public int compare(TAgentContractList o1, TAgentContractList o2) {
                return o1.getTurnoverGgr().intValue() -  o2.getTurnoverGgr().intValue();
            }
        });

        log.info("----- 排序后的数据,,,={}",new Gson().toJson(lists));

        for(TAgentContractList tAgentContractList : lists){

            if(turnover.doubleValue() <=  tAgentContractList.getTurnoverGgr().doubleValue()) {
                result     =    tAgentContractList ;
                log.info("----- 对比到结果为,,,={}",new Gson().toJson(result));

                break;
            }
        }


        return   result ;
    }

    @Autowired
    private TAgentContractMapper agentContractMapper ;

    /**
     * description: 计算时间区间的佣金数据
     * @param:  [req]
     * @return: com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse
     * @Date: 2023/10/30 14:27
     * @Version: 1.0.0
     * @Author: Lucian
     */
    private CommissionRecordDashBoardResponse calculateData(String loginName,String recordDateStart,String recordDateEnd,String recordDateTimeStart,String recordDateTimeEnd){

        CommissionRecordDashBoardResponse result = new CommissionRecordDashBoardResponse();
        result.setLoginName(loginName);
        result.setRecordDateStart(recordDateStart);
        result.setRecordDateEnd(recordDateEnd);

        //1.查询当前代理团队的存取款
        CommissionRecordDashBoardResponse depositWData = commissionRecordMapper.querySumAgentDepositWData(loginName,recordDateStart,recordDateEnd);
        log.info("The depositWData from :{} to :{} is:{}",recordDateStart,recordDateEnd,depositWData);

        //2.查询当前代理团队的游戏数据
        CommissionRecordDashBoardResponse gameData = commissionRecordMapper.querySumAgentGameData(loginName,recordDateStart,recordDateEnd);
        log.info("The gameData from :{} to :{} is:{}",recordDateStart,recordDateEnd,gameData);

        //3.查询注册人数
        Result<Long> registerUserResult = userFeignService.selectUserTreeByParentNTimeCount(new DashBoardUserTreeQueryReq(loginName,recordDateTimeStart,recordDateTimeEnd));
        log.info("The registerUserNumber from :{} to :{} is:{}",recordDateStart,recordDateEnd,registerUserResult);

        //4.查询首存人数和首存金额
        CommissionRecordDashBoardResponse firstDepositeData = commissionRecordMapper.querySumAgentfirstDepositeData(loginName,recordDateStart,recordDateEnd);
        log.info("The firstDepositeData from :{} to :{} is:{}",recordDateStart,recordDateEnd,firstDepositeData);

        //5.查询有投注额的人数
        CommissionRecordDashBoardResponse betPlayersData = commissionRecordMapper.querybetPlayersCount(loginName,recordDateStart,recordDateEnd);
        log.info("The betPlayersData from :{} to :{} is:{}",recordDateStart,recordDateEnd,betPlayersData);

        //6.封装数据返回
        result.setDeposit(Objects.isNull(depositWData)? BigDecimal.ZERO:depositWData.getDeposit());
        result.setWithdraw(Objects.isNull(depositWData)?BigDecimal.ZERO:depositWData.getWithdraw());
        result.setTurnover(Objects.isNull(gameData)?BigDecimal.ZERO:gameData.getTurnover());
        result.setGgr(Objects.isNull(gameData)?BigDecimal.ZERO:gameData.getGgr());
        result.setWinorloss(Objects.isNull(gameData)?BigDecimal.ZERO:gameData.getWinorloss());
        result.setRegistrationNumber(registerUserResult.isSuccess()&&Objects.isNull(registerUserResult.getData())?0L:registerUserResult.getData());
        result.setFirstDepositAmount(Objects.isNull(firstDepositeData)?BigDecimal.ZERO:firstDepositeData.getFirstDepositAmount());
        result.setFirstDepositPlayers(Objects.isNull(firstDepositeData)?0L:firstDepositeData.getFirstDepositPlayers());
        result.setBetPlayers(Objects.isNull(betPlayersData)?0L:betPlayersData.getBetPlayers());

        //计算佣金
        calculateCommission(result);

        log.info("finished to calculate commission data from {} to {} for {}, result is:{}",recordDateStart,recordDateEnd,loginName,result);
        return result;

    }

    /**
     * description: 计算日期
     * @param:  [req]
     * @return: void
     * @Date: 2023/10/30 15:59
     * @Version: 1.0.0
     * @Author: Lucian
     */
    private void getNeededRecordDate(CommissionRecordDashBoardRequest req){

        String chosenType = req.getChosenType();
        String chosenPeriod = req.getChosenPeriod();

        //月类型
        if(chosenType.equals(DashboardChosenTimeEnum.ChosenType_Month.getName())){

            if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Current.getName())){
                //当前月
                req.setRecordDateStart(DateUtils.getLastNMonthFirstDay(0).toString());
                req.setRecordDateEnd(DateUtils.getLastNMonthLastDay(0).toString());
                req.setRecordDateTimeStart(DateUtils.getLastNMonthFirstDay(0)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEnd(DateUtils.getLastNMonthLastDay(0)+ BaseConstants.END_TIME);
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last.getName())){
                //上一个月
                req.setRecordDateStartLast(DateUtils.getLastNMonthFirstDay(1).toString());
                req.setRecordDateEndLast(DateUtils.getLastNMonthLastDay(1).toString());
                req.setRecordDateTimeStartLast(DateUtils.getLastNMonthFirstDay(1)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLast(DateUtils.getLastNMonthLastDay(1)+ BaseConstants.END_TIME);
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last_Two.getName())){
                //上两个月
                req.setRecordDateStartLastTwo(DateUtils.getLastNMonthFirstDay(2).toString());
                req.setRecordDateEndLastTwo(DateUtils.getLastNMonthLastDay(2).toString());
                req.setRecordDateTimeStartLastTwo(DateUtils.getLastNMonthFirstDay(2)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLastTwo(DateUtils.getLastNMonthLastDay(2)+ BaseConstants.END_TIME);
            }
        }else if(chosenType.equals(DashboardChosenTimeEnum.ChosenType_Week.getName())){
            if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Current.getName())){
                //当前周
                req.setRecordDateStart(DateUtils.getNWeeksAgoMonday(0).toString());
                req.setRecordDateEnd(DateUtils.getNWeeksAgoSunday(0).toString());
                req.setRecordDateTimeStart(DateUtils.getNWeeksAgoMonday(0)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEnd(DateUtils.getNWeeksAgoSunday(0)+ BaseConstants.END_TIME);
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last.getName())){
                //上一个周
                req.setRecordDateStartLast(DateUtils.getNWeeksAgoMonday(1).toString());
                req.setRecordDateEndLast(DateUtils.getNWeeksAgoSunday(1).toString());
                req.setRecordDateTimeStartLast(DateUtils.getNWeeksAgoMonday(1)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLast(DateUtils.getNWeeksAgoSunday(1)+ BaseConstants.END_TIME);
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last_Two.getName())){
                //上两个周
                req.setRecordDateStartLastTwo(DateUtils.getNWeeksAgoMonday(2).toString());
                req.setRecordDateEndLastTwo(DateUtils.getNWeeksAgoSunday(2).toString());
                req.setRecordDateTimeStartLastTwo(DateUtils.getNWeeksAgoMonday(2)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLastTwo(DateUtils.getNWeeksAgoSunday(2)+ BaseConstants.END_TIME);
            }
        }else if(chosenType.equals(DashboardChosenTimeEnum.ChosenType_Day.getName())){
            if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Current.getName())){
                //当天
                req.setRecordDateStart(DateUtils.getNDaysAgo(0).toString());
                req.setRecordDateEnd(DateUtils.getNDaysAgo(0).toString());
                req.setRecordDateTimeStart(DateUtils.getNDaysAgo(0)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEnd(DateUtils.getNDaysAgo(0)+ BaseConstants.END_TIME);
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last.getName())){
                //昨天
                req.setRecordDateStartLast(DateUtils.getNDaysAgo(1).toString());
                req.setRecordDateEndLast(DateUtils.getNDaysAgo(1).toString());
                req.setRecordDateTimeStartLast(DateUtils.getNDaysAgo(1)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLast(DateUtils.getNDaysAgo(1)+ BaseConstants.END_TIME);
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last_Two.getName())){
                //前天
                req.setRecordDateStartLastTwo(DateUtils.getNDaysAgo(2).toString());
                req.setRecordDateEndLastTwo(DateUtils.getNDaysAgo(2).toString());
                req.setRecordDateTimeStartLastTwo(DateUtils.getNDaysAgo(2)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLastTwo(DateUtils.getNDaysAgo(2)+ BaseConstants.END_TIME);
            }
        }
        log.info("handle date finished. The date is:{}",req);

    }

    private void calculateCommission(CommissionRecordDashBoardResponse dashBoardResponse){

        Result<TAgentCustomers> topAgentResult = agentFeignService.queryTopAgentByAccount(dashBoardResponse.getLoginName());
        if(!topAgentResult.isSuccess()||Objects.isNull(topAgentResult.getData())){
            dashBoardResponse.setCommissionAmount(BigDecimal.ZERO.setScale(2));
            return ;
        }
        TAgentCustomers topAgent = topAgentResult.getData();

        //佣金比例
        Result<TAgentContract> agentContractResult = agentFeignService.queryRealContractByLoginName(dashBoardResponse.getLoginName());

        TAgentContract tAgentContract = agentContractResult.getData();

        if(Objects.isNull(tAgentContract)){
            dashBoardResponse.setCommissionAmount(BigDecimal.ZERO.setScale(2));
            return ;
        }

        //是否设置条件
        if(tAgentContract.getSettlementConditions()==1){
            log.info("set settlement conditions--");
            //查询1级代理的所有下级用户

            DashBoardUserTreeQueryReq queryTopEntity = new DashBoardUserTreeQueryReq();
            queryTopEntity.setParent(topAgent.getLoginName());
            Result<List<TCustomerLayer>> userListTopResult = userFeignService.selectUserTreeByParentNTime(queryTopEntity);

            List<String> userNameTopList = null;
            if(userListTopResult.isSuccess()&&!Objects.isNull(userListTopResult.getData())&&userListTopResult.getData().size()>0){
                userNameTopList = userListTopResult.getData().stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList());
            }else {
                log.info("No user data.");
                dashBoardResponse.setCommissionAmount(BigDecimal.ZERO.setScale(2));
                return ;
            }

            Long count = 0L;
            if(tAgentContract.getCommissionPlanType().equals(CommissionPlanTypeEnum.TURNOVER.getCode())){
                count = commissionRecordMapper.queryTurnoverActivePlayerCount(userNameTopList,dashBoardResponse.getRecordDateStart(),dashBoardResponse.getRecordDateEnd(),tAgentContract.getActiveUserTurnover());
            }else if(tAgentContract.getCommissionPlanType().equals(CommissionPlanTypeEnum.GGR.getCode())){
                count = commissionRecordMapper.queryGgrActivePlayerCount(userNameTopList,dashBoardResponse.getRecordDateStart(),dashBoardResponse.getRecordDateEnd(),tAgentContract.getActiveUserTurnover());
            }
            log.info("Active count is :{}",count);

            if(count < tAgentContract.getActiveUserHeadcount()){
                log.info("The active count is not enough!");
                dashBoardResponse.setCommissionAmount(BigDecimal.ZERO.setScale(2));
                return ;
            }
        }

        //佣金比例 暂时选择第一阶段
        SettlementPercentageReq percentageReq = tAgentContract.getSettlementPercentageList().get(0);

        //佣金费率 选择 allGameType
        BigDecimal commissionValue = new BigDecimal(String.valueOf(percentageReq.getAllGamesPercentage())).divide(new BigDecimal(100));
        log.info("commission rate is:{}", commissionValue);
        //根据佣金方案来计算
        String commissionType = tAgentContract.getCommissionPlanType();
        log.info("commission type is :{}",commissionType);

        if(commissionType.equals(CommissionPlanTypeEnum.TURNOVER.getCode())){
            dashBoardResponse.setCommissionAmount(dashBoardResponse.getTurnover().multiply(commissionValue).setScale(2, RoundingMode.DOWN));
            return ;
        }else if(commissionType.equals(CommissionPlanTypeEnum.GGR.getCode())){
            if(dashBoardResponse.getGgr().compareTo(BigDecimal.ZERO)>=0){
                dashBoardResponse.setCommissionAmount(dashBoardResponse.getGgr().multiply(commissionValue).setScale(2, RoundingMode.DOWN));
            }else {
                dashBoardResponse.setCommissionAmount(BigDecimal.ZERO.setScale(2));
            }

        }else {
            dashBoardResponse.setCommissionAmount(BigDecimal.ZERO.setScale(2));
        }


    }

    /**
     * description: 累加计算结果
     * @param:  [source, increment]
     * @return: com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse
     * @Date: 2023/10/30 16:12
     * @Version: 1.0.0
     * @Author: Lucian
     */
    private CommissionRecordDashBoardResponse sumDataResult(CommissionRecordDashBoardResponse source,CommissionRecordDashBoardResponse increment){
        if(!Objects.isNull(increment)){
            log.info("begin to sub data from increment:{} to source:{} ",increment,source);
            source.setCommissionAmount(source.getCommissionAmount().add(increment.getCommissionAmount()));
            source.setRegistrationNumber(source.getRegistrationNumber()+increment.getRegistrationNumber());
            source.setFirstDepositPlayers(source.getFirstDepositPlayers()+increment.getFirstDepositPlayers());
            source.setBetPlayers(source.getBetPlayers()+increment.getBetPlayers());
            source.setTurnover(source.getTurnover().add(increment.getTurnover()));
            source.setGgr(source.getGgr().add(increment.getGgr()));
            source.setWinorloss(source.getWinorloss().add(increment.getWinorloss()));
            source.setFirstDepositAmount(source.getFirstDepositAmount().add(increment.getFirstDepositAmount()));
            source.setDeposit(source.getDeposit().add(increment.getDeposit()));
            source.setWithdraw(source.getWithdraw().add(increment.getWithdraw()));
        }
        log.info("finished sub data, result is:{}",source);
        return source;
    }

}
