package com.mkt.agent.commission.controller;

import com.mkt.agent.commission.service.CommissionRecordQueryService;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordPayRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordPayResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.base.CommissionRecordPageResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 佣金支付记录(代理前台) api
 */
@RestController
@RequestMapping("/commissionRecord-pay")
@Api(tags = "commission_record_pay API")
@Slf4j
public class CommissionRecordPayController {

    @Resource(name = "commissionRecordServicePayImpl")
    private CommissionRecordQueryService commissionRecordQueryService;


    @PostMapping("/queryByPageAndCondition")
    @ApiOperation("query commission records pay by page and conditions")
    public CommissionRecordPageResponse<CommissionRecordPayResponse> queryByPageAndCondition(@RequestBody CommissionRecordPayRequest req) {
        // 佣金支付记录(分页)
        log.info("commission_record_pay query parm :{}", req.toString());
        CommissionRecordPageResponse result = commissionRecordQueryService.queryByPageAndCondition(req);
        log.info("commission_record_pay query result :{}", result);
        return result;
    }

    @PostMapping("/exportCommissionRecord")
    @ApiOperation("export Commission Record")
    public List<CommissionRecordPayResponse> exportCommissionRecord(@RequestBody CommissionRecordPayRequest req, HttpServletResponse response) {
        // 佣金支付记录(导出)
        List<CommissionRecordPayResponse> export = commissionRecordQueryService.export(req, response);
        return export;
    }

}
