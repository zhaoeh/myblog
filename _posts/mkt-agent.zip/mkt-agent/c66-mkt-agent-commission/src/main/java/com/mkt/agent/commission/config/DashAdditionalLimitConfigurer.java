package com.mkt.agent.commission.config;

import com.mkt.agent.common.limit.PriorityLimitConfigurer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @description: 额外的限流配置器
 * @author: ErHu.Zhao
 * @create: 2024-01-15
 **/
@Component
@Slf4j
public class DashAdditionalLimitConfigurer implements PriorityLimitConfigurer {

    private final DashBoardUpLimitConfigurer dashBoardUpLimitConfigurer;

    public DashAdditionalLimitConfigurer(DashBoardUpLimitConfigurer dashBoardUpLimitConfigurer) {
        this.dashBoardUpLimitConfigurer = dashBoardUpLimitConfigurer;
    }

    @Override
    public String limitKeyConfigurer(Object target) {
        return dashBoardUpLimitConfigurer.limitKeyConfigurer(target) + "_ADDITIONAL";
    }

    @Override
    public Long limitPeriodConfigurer(Object target) {
        return dashBoardUpLimitConfigurer.limitPeriodConfigurer(target);
    }

    @Override
    public Long limitCountConfigurer(Object target) {
        return dashBoardUpLimitConfigurer.limitCountConfigurer(target);
    }
}
