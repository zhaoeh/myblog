package com.mkt.agent.commission.fegin;


import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.clickhouse.req.DashBoardUserTreeQueryReq;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

//@FeignClient(name = "${feign.mkt-agent-api}", url = "127.0.0.1:8091")
@FeignClient(name = "${feign.mkt-user}")
public interface UserFeignService {

    @PostMapping("/user/tree/byParentNTimeCount")
    Result<Long> selectUserTreeByParentNTimeCount(@RequestBody DashBoardUserTreeQueryReq queryEntity);

    @PostMapping("/user/tree/byParentNTime")
    Result<List<TCustomerLayer>> selectUserTreeByParentNTime(@RequestBody DashBoardUserTreeQueryReq queryEntity);

}
