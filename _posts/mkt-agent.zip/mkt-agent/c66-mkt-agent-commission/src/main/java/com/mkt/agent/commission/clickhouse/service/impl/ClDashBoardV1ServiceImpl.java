package com.mkt.agent.commission.clickhouse.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mkt.agent.commission.board.DashBoardQueerer;
import com.mkt.agent.commission.board.core.DashBoardRunsProcessor;
import com.mkt.agent.commission.clickhouse.service.ClDashBoardV1Service;
import com.mkt.agent.commission.exception.MKTCommissionException;
import com.mkt.agent.commission.fegin.AgentFeignService;
import com.mkt.agent.commission.fegin.UserFeignService;
import com.mkt.agent.commission.mapper.CommissionRecordDashBoardMapper;
import com.mkt.agent.commission.mapper.CommissionRecordMapper;
import com.mkt.agent.commission.util.DashBoardV1Utils;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordDashBoardRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.dashboard.DashboardTopNDistriVo;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.entity.clickhouse.req.DashBoardUserTreeQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverDistriResp;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverTopResp;
import com.mkt.agent.common.utils.DashBoardCommonUtil;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.RedisUtil;
import com.mkt.agent.common.utils.ThreadLocalUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @Description 计算仪表盘service--
 * @Classname ClDashBoardServiceImpl
 * @Date 2023/11/22 14:01
 * @Created by TJSLucian
 */
@Service
@Slf4j
public class ClDashBoardV1ServiceImpl extends ServiceImpl<CommissionRecordMapper, AgentCommissionRecord> implements ClDashBoardV1Service {

    @Resource
    private CommissionRecordDashBoardMapper commissionRecordDashBoardMapper;

    @Autowired
    private DashBoardQueerer dashBoardQueerer;

    @Resource
    private DashBoardCommonUtil dashBoardCommonUtil;

    @Resource
    private DashBoardV1Utils dashBoardV1Utils;

    @Autowired
    private RedisUtil redisUtil;

    @Resource
    private UserFeignService userFeignService;

    @Resource
    private Gson gson;

    @Resource
    private AgentFeignService agentFeignService;

    private ExecutorService executorService;

    @Resource
    private DashBoardRunsProcessor dashBoardRunsProcessor;

    @PostConstruct
    public void init() {
        executorService = Executors.newFixedThreadPool(10);
    }


    @Override
    public Result<CommissionRecordDashBoardResponse> getTeamSummaryData(CommissionRecordDashBoardRequest req){

        log.info("CommissionRecordServiceImpl getDashBoardCommissionData params:{}",req);

        try {

            //1.计算日期
            ClDashBoardCreateQueryReq newReq = dashBoardCommonUtil.getNeededRecordDate(req);

            // 计算完日期后进行预处理
            dashBoardRunsProcessor.beforeProcessor(req, newReq);

            CommissionRecordDashBoardResponse lastPeriodData = null;

            String recordDateStart = "";
            String recordDateEnd = "";

            //查询记录表，查不到再去计算，计算完入库记录表
            if(!StringUtils.isBlank(req.getRecordDateStartLast())){
                //查询上个时间区间数据
                lastPeriodData = commissionRecordDashBoardMapper.selectOne(new LambdaQueryWrapper<CommissionRecordDashBoardResponse>().eq(CommissionRecordDashBoardResponse::getRecordDateStart,req.getRecordDateStartLast())
                        .eq(CommissionRecordDashBoardResponse::getRecordDateEnd,req.getRecordDateEndLast()).eq(CommissionRecordDashBoardResponse::getLoginName,req.getLoginName()));
                if(Objects.isNull(lastPeriodData)){

                    //计算
                    lastPeriodData = calculateDataV1(req.getLoginName(),req.getRecordDateStartLast(),req.getRecordDateEndLast(),req.getRecordDateTimeStartLast(),req.getRecordDateTimeEndLast());

                    //判断是否需要入数据库
                    if(DateUtils.isBeforeCurrentMonth(lastPeriodData.getRecordDateStart(),lastPeriodData.getRecordDateEnd()) && dashBoardCommonUtil.isNeededSave(lastPeriodData)){
                        commissionRecordDashBoardMapper.insert(lastPeriodData);
                    }
                }
                //方便后续计算
                recordDateStart = req.getRecordDateStartLast();
                recordDateEnd = req.getRecordDateEndLast();
            }

            CommissionRecordDashBoardResponse lastTwoPeriodData = null;

            if(!StringUtils.isBlank(req.getRecordDateStartLastTwo())){

                //查询上上个时间区间数据
                lastTwoPeriodData = commissionRecordDashBoardMapper.selectOne(new LambdaQueryWrapper<CommissionRecordDashBoardResponse>().eq(CommissionRecordDashBoardResponse::getRecordDateStart,req.getRecordDateStartLastTwo())
                        .eq(CommissionRecordDashBoardResponse::getRecordDateEnd,req.getRecordDateEndLastTwo()).eq(CommissionRecordDashBoardResponse::getLoginName,req.getLoginName()));
                if(Objects.isNull(lastTwoPeriodData)){

                    //计算
                    lastTwoPeriodData = calculateDataV1(req.getLoginName(),req.getRecordDateStartLastTwo(),req.getRecordDateEndLastTwo(),req.getRecordDateTimeStartLastTwo(),req.getRecordDateTimeEndLastTwo());

                    //判断是否入库
                    if(DateUtils.isBeforeCurrentMonth(lastTwoPeriodData.getRecordDateStart(),lastTwoPeriodData.getRecordDateEnd()) && dashBoardCommonUtil.isNeededSave(lastTwoPeriodData)){
                        commissionRecordDashBoardMapper.insert(lastTwoPeriodData);
                    }

                }
                //方便后续计算
                recordDateStart = req.getRecordDateStartLastTwo();
                recordDateEnd = req.getRecordDateEndLastTwo();
            }

            CommissionRecordDashBoardResponse currentPeriodData = null;
            if(!StringUtils.isBlank(req.getRecordDateStart())){
                //方便后续计算
                recordDateStart = req.getRecordDateStart();
                recordDateEnd = req.getRecordDateEnd();
                //查询当下时间区间
                currentPeriodData = calculateDataV1(req.getLoginName(),req.getRecordDateStart(),req.getRecordDateEnd(),req.getRecordDateTimeStart(),req.getRecordDateTimeEnd());
            }

            CommissionRecordDashBoardResponse response = new CommissionRecordDashBoardResponse();

            response.setLoginName(req.getLoginName());
            response.setRecordDateStart(recordDateStart);
            response.setRecordDateEnd(recordDateEnd);

            //7.汇总数据
            //汇总当前区间
            sumDataResultV1(response,currentPeriodData);
            //汇总上个区间
            sumDataResultV1(response,lastPeriodData);
            //汇总上上个区间
            sumDataResultV1(response,lastTwoPeriodData);

            //设置佣金
            String cacheKey = Constants.COMMISSION_CACHE_PREFIX + response.getLoginName()+response.getRecordDateStart()+response.getRecordDateEnd();
            log.info("[asyncQuery method] begin to append commission,cacheKey is {}", cacheKey);

            Object cacheCommissionValue = redisUtil.get(cacheKey);
            if(!Objects.isNull(cacheCommissionValue)){
                log.info("The commission for agent:{} from cache is:{}",response.getLoginName(),cacheCommissionValue.toString());
                BigDecimal cacheCommission = Optional.ofNullable(cacheCommissionValue).map(v -> gson.fromJson(v.toString(), BigDecimal.class)).
                        orElse(BigDecimal.ZERO);
                response.setCommissionAmount(cacheCommission.setScale(2,RoundingMode.DOWN));
            }

            log.info("finished to getDashBoardCommissionData:{}",response);

            //设置投注人数
            String betPlayersCacheKey = Constants.BETPLAYERS_CACHE_PREFIX + response.getLoginName()+response.getRecordDateStart()+response.getRecordDateEnd();
            Object cacheBetPlayersValue = redisUtil.get(betPlayersCacheKey);
            if(!Objects.isNull(cacheBetPlayersValue)){
                log.info("The commission for agent:{} from cache is:{}",response.getLoginName(),cacheBetPlayersValue);
                Long betPlayers = Optional.ofNullable(cacheBetPlayersValue).map(v -> gson.fromJson(v.toString(), Long.class)).
                        orElse(0L);
                response.setBetPlayers(betPlayers);
            }

            return Result.success(response);
        }catch (MKTCommissionException e){
            throw e;
        }catch (Exception exception){
            log.info("Failed to query dashboard data.", exception);
            throw new MKTCommissionException("The system is busy now. Please try again!");
        } finally {
            ThreadLocalUtil.clear();
        }

    }


    private CommissionRecordDashBoardResponse calculateDataV1(String agentAccount, String recordDateStart,String recordDateEnd,String recordDateTimeStart,String recordDateTimeEnd){

        ClDashBoardCreateQueryReq queryReq = ClDashBoardCreateQueryReq.builder().agentAccount(agentAccount).recordDateStart(recordDateStart).recordDateEnd(recordDateEnd)
                .recordDateTimeStart(recordDateTimeStart).recordDateTimeEnd(recordDateTimeEnd).build();

        Result<TAgentCustomers> agentResult = agentFeignService.getAgentByLoginName(agentAccount);
        if(!agentResult.isSuccess() || Objects.isNull(agentResult.getData())){
            throw new MKTCommissionException("The agent is not exist!");
        }

        queryReq.setParentAgentAccount(agentResult.getData().getParentName());

        CommissionRecordDashBoardResponse sumData = dashBoardQueerer.queryDashBoardData(queryReq);

        log.info("After querying data from clickhouse:{}",sumData.toString());
        sumData.setLoginName(agentAccount);
        sumData.setRecordDateStart(recordDateStart);
        sumData.setRecordDateEnd(recordDateEnd);

        log.info("finished to calculate commission data from {} to {} for {}, result is:{}",recordDateStart,recordDateEnd,agentAccount,sumData);
        return sumData;

    }

    private CommissionRecordDashBoardResponse sumDataResultV1(CommissionRecordDashBoardResponse source,CommissionRecordDashBoardResponse increment){
        if(!Objects.isNull(increment)){
            log.info("begin to sub data from increment:{} to source:{} ",increment,source);
            source.setCommissionAmount(source.getCommissionAmount().add(increment.getCommissionAmount()));
            source.setRegistrationNumber(source.getRegistrationNumber()+increment.getRegistrationNumber());
            source.setFirstDepositPlayers(source.getFirstDepositPlayers()+increment.getFirstDepositPlayers());
            source.setBetPlayers(source.getBetPlayers()+increment.getBetPlayers());
            source.setTurnover(source.getTurnover().add(increment.getTurnover()));
            source.setGgr(source.getGgr().add(increment.getGgr()));
            source.setWinorloss(source.getWinorloss().add(increment.getWinorloss()));
            source.setFirstDepositAmount(source.getFirstDepositAmount().add(increment.getFirstDepositAmount()));
            source.setDeposit(source.getDeposit().add(increment.getDeposit()));
            source.setWithdraw(source.getWithdraw().add(increment.getWithdraw()));
        }
        log.info("finished sub data, result is:{}",source);
        return source;
    }


    @Override
    public DashboardTopNDistriVo getTurnoverTopNDistriData(String loginName) {

        String cacheDistriKey = Constants.CURRENT_USER_TURNOVER_DSITRI_CACHE_PREFIX + loginName;

        List<ClTurnoverDistriResp> distriRespList = Optional.ofNullable(redisUtil.get(cacheDistriKey)).map(value -> {
            List<ClTurnoverDistriResp> cacheDistriList = gson.fromJson(value.toString(), new TypeToken<List<ClTurnoverDistriResp>>(){}.getType());
            log.info("[turnoverDistribution method] load cache turnoverDistribution of current user, cacheKey is {}, cacheValue is {}", cacheDistriKey, gson.toJson(cacheDistriList));
            return cacheDistriList;
        }).orElse(Collections.emptyList());

        String cacheTopKey = Constants.CURRENT_USER_TURNOVER_TOP_CACHE_PREFIX + loginName;

        List<ClTurnoverTopResp> topRespList = Optional.ofNullable(redisUtil.get(cacheTopKey)).map(value -> {
            List<ClTurnoverTopResp> cacheTopList = gson.fromJson(value.toString(), new TypeToken<List<ClTurnoverTopResp>>(){}.getType());
            log.info("[turnoverTop method] load cache turnoverTop of current user, cacheKey is {}, cacheValue is {}", cacheTopKey, gson.toJson(cacheTopList));
            return cacheTopList;
        }).orElse(Collections.emptyList());


        this.executorService.submit(() -> {

            try {
                DashBoardUserTreeQueryReq queryEntity = new DashBoardUserTreeQueryReq();
                queryEntity.setParent(loginName);
                Result<List<TCustomerLayer>> userListResult = userFeignService.selectUserTreeByParentNTime(queryEntity);

                List<String> userNameList = null;
                if(userListResult.isSuccess()&&!CollectionUtils.isEmpty(userListResult.getData())){
                    userNameList = userListResult.getData().stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList());
                    ClDashBoardCreateQueryReq updateReq = ClDashBoardCreateQueryReq.builder().loginNameList(userNameList).agentAccount(loginName).build();
                    List<ClTurnoverTopResp> topList = dashBoardV1Utils.turnoverTop(updateReq);
                    redisUtil.setByTimeUnit(Constants.CURRENT_USER_TURNOVER_TOP_CACHE_PREFIX + loginName, gson.toJson(topList), 1, TimeUnit.DAYS);

                    List<ClTurnoverDistriResp> distriList = dashBoardV1Utils.turnoverDistri(updateReq);

                    List<ClTurnoverDistriResp> distriListResp = Optional.ofNullable(distriList)
                            .map(list -> list.stream().collect(Collectors.groupingBy(ClTurnoverDistriResp::getGameType)).values().stream().
                                    map(listItem -> listItem.stream().reduce((d1,d2) -> {
                                        d1.setTurnoverSum(d1.getTurnoverSum().add(d2.getTurnoverSum()));
                                        return d1;
                                    }).orElseGet(ClTurnoverDistriResp::new)).collect(Collectors.toList())).orElseGet(ArrayList::new);
                    if(!CollectionUtils.isEmpty(distriListResp)){
                        log.info("The distriList for agent:{} is:{}",loginName,gson.toJson(distriListResp));

                        redisUtil.setByTimeUnit(Constants.CURRENT_USER_TURNOVER_DSITRI_CACHE_PREFIX + loginName, gson.toJson(distriListResp), 1, TimeUnit.DAYS);
                    }

                }else {
                    log.info("No user data.");
                }
            }catch (Exception e){
                log.error("Failed to update turnoverTop for agent:{}",loginName,e);
            }

        });

        DashboardTopNDistriVo dashboardTopNDistriVo = new DashboardTopNDistriVo();
        dashboardTopNDistriVo.setDistriRespList(distriRespList);
        dashboardTopNDistriVo.setTopRespList(topRespList);

        return dashboardTopNDistriVo;
    }

}
