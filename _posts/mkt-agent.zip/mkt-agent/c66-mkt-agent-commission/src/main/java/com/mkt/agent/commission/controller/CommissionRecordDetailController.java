package com.mkt.agent.commission.controller;

import com.mkt.agent.commission.service.CommissionRecordQueryService;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordDetailRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDetailResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.base.CommissionRecordPageResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@RestController
@RequestMapping("/commissionRecord-detail")
@Api(tags = "commission_record_detail API")
@Slf4j
public class CommissionRecordDetailController {

    @Resource(name = "commissionRecordServiceDetailImpl")
    private CommissionRecordQueryService commissionRecordQueryService;


    @PostMapping("/queryByPageAndCondition")
    @ApiOperation("query commission records detail by page and conditions")
    public CommissionRecordPageResponse<CommissionRecordDetailResponse> queryByPageAndCondition(@RequestBody CommissionRecordDetailRequest req) {
        log.info("commission_record_detail query parm :{}", req.toString());
        CommissionRecordPageResponse result = commissionRecordQueryService.queryByPageAndCondition(req);
        log.info("commission_record_detail query result :{}", result);
        return result;
    }


    @PostMapping("/exportCommissionRecord")
    @ApiOperation("export Commission Record")
    public List<CommissionRecordDetailResponse> exportCommissionRecord(@RequestBody CommissionRecordDetailRequest req, HttpServletResponse response) {
        return commissionRecordQueryService.export(req, response);
    }



}
