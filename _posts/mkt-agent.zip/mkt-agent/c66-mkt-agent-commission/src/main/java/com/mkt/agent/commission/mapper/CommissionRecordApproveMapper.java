package com.mkt.agent.commission.mapper;

import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordApproveRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordApproveResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.sum.CommissionRecordApproveSumResponse;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CommissionRecordApproveMapper {


    List<CommissionRecordApproveResponse> queryByPageAndCondition(CommissionRecordApproveRequest rq);


    CommissionRecordApproveSumResponse queryByPageAndConditionSum(CommissionRecordApproveRequest rq);

    Long countQueryByPageAndCondition(CommissionRecordApproveRequest rq);

}
