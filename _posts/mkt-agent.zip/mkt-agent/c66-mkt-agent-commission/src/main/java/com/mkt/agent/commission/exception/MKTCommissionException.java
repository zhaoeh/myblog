package com.mkt.agent.commission.exception;

import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;
import lombok.Getter;

/**
 * @ClassName BusinessException
 * @Description 自定义业务异常
 * @Author TJSAlex
 * @Date 2023/5/19 12:11
 * @Version 1.0
 **/
@Getter
public class MKTCommissionException extends BusinessException {

    public MKTCommissionException() {
        super();
    }

    public MKTCommissionException(String message) {
        super(message);
    }

    public MKTCommissionException(ResultEnum resultEnum) {
        super(resultEnum);
    }

    public MKTCommissionException(String message, Integer code) {
        super(message);
        this.code = code;
    }

    public MKTCommissionException(String message, Throwable cause) {
        super(message, cause);
    }
}
