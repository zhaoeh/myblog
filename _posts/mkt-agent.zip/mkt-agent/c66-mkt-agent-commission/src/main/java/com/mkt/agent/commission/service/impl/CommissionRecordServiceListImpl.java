package com.mkt.agent.commission.service.impl;

import com.mkt.agent.commission.exception.MKTCommissionException;
import com.mkt.agent.commission.mapper.CommissionRecordListMapper;
import com.mkt.agent.commission.service.CommissionRecordQueryService;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordListRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordListResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.base.CommissionRecordPageResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.sum.CommissionRecordListSumResponse;
import com.mkt.agent.common.enums.CommissionRecordStatusEnum;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.ExcelUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
@Slf4j
public class CommissionRecordServiceListImpl implements CommissionRecordQueryService<CommissionRecordListRequest, CommissionRecordListResponse> {


    @Autowired
    private CommissionRecordListMapper commissionRecordListMapper;

    @Override
    public CommissionRecordPageResponse<CommissionRecordListResponse> queryByPageAndCondition(CommissionRecordListRequest req) {

        //分页数据初始化
        req.setPageSize(req.getPageSize());

        if(StringUtils.isNotBlank(req.getCreateTimeStart())){
            req.setCreateTimeStart(req.getCreateTimeStart()+" 00:00:00");
        }

        if(StringUtils.isNotBlank(req.getCreateTimeEnd())){
            req.setCreateTimeEnd(req.getCreateTimeEnd()+" 23:59:59");
        }

        // 查总记录数
        Long total = commissionRecordListMapper.countQueryByPageAndCondition(req);

        // 查记录
        List<CommissionRecordListResponse> resultList = commissionRecordListMapper.queryByPageAndCondition(req);

        CommissionRecordPageResponse<CommissionRecordListResponse> commissionRecordOutVOPage = new CommissionRecordPageResponse<>();
        commissionRecordOutVOPage.setRecords(resultList);
        commissionRecordOutVOPage.setTotal(total);
        commissionRecordOutVOPage.setCurrent(req.getPageNum());
        commissionRecordOutVOPage.setSize(req.getPageSize());
        commissionRecordOutVOPage.setPages(total / req.getPageSize());

        Map<String, BigDecimal> pageSumMap = commissionRecordOutVOPage.getPageSumMap();
        // 分页数据聚合
        for (CommissionRecordListResponse commissionRecordListResponse : resultList) {


            if (Objects.isNull(pageSumMap.get(BaseConstants.CommissionAmount))) {
                pageSumMap.put(BaseConstants.CommissionAmount, new BigDecimal(0));
                pageSumMap.put(BaseConstants.ActualCommissionAmount, new BigDecimal(0));
                pageSumMap.put(BaseConstants.AppendCommissionAmount, new BigDecimal(0));
            }

            // 分页聚合
            pageSumMap.put(BaseConstants.CommissionAmount, pageSumMap.get(BaseConstants.CommissionAmount).add(commissionRecordListResponse.getCommissionAmount()));
            pageSumMap.put(BaseConstants.ActualCommissionAmount, pageSumMap.get(BaseConstants.ActualCommissionAmount).add(commissionRecordListResponse.getActualCommissionAmount()));
            pageSumMap.put(BaseConstants.AppendCommissionAmount, pageSumMap.get(BaseConstants.AppendCommissionAmount).add(commissionRecordListResponse.getAppendCommissionAmount()));

        }

        CommissionRecordListSumResponse commissionRecordListSumResponse = commissionRecordListMapper.queryByPageAndConditionSum(req);
        if (Objects.nonNull(commissionRecordListSumResponse)) {
            Map<String, BigDecimal> searchSumMap = commissionRecordOutVOPage.getSearchSumMap();

            if (Objects.isNull(searchSumMap.get(BaseConstants.CommissionAmount))) {
                searchSumMap.put(BaseConstants.CommissionAmount, new BigDecimal(0));
                searchSumMap.put(BaseConstants.ActualCommissionAmount, new BigDecimal(0));
                searchSumMap.put(BaseConstants.AppendCommissionAmount, new BigDecimal(0));
            }

            searchSumMap.put(BaseConstants.CommissionAmount, commissionRecordListSumResponse.getSumCommissionAmount());
            searchSumMap.put(BaseConstants.ActualCommissionAmount, commissionRecordListSumResponse.getSumActualCommissionAmount());
            searchSumMap.put(BaseConstants.AppendCommissionAmount, commissionRecordListSumResponse.getSumAppendCommissionAmount());
        }

        return commissionRecordOutVOPage;
    }


    @Override
    public List<CommissionRecordListResponse> export(CommissionRecordListRequest req, HttpServletResponse response) {
        if(StringUtils.isNotBlank(req.getCreateTimeStart())){
            req.setCreateTimeStart(req.getCreateTimeStart()+" 00:00:00");
        }

        if(StringUtils.isNotBlank(req.getCreateTimeEnd())){
            req.setCreateTimeEnd(req.getCreateTimeEnd()+" 23:59:59");
        }
        // 导出全部数据
        req.setIsPage(false);
        List<CommissionRecordListResponse> responses = commissionRecordListMapper.queryByPageAndCondition(req);

        for(CommissionRecordListResponse recordListResponse:responses){
            LocalDate date = DateUtils.stringToLocalDate(recordListResponse.getSettleDateStart());
            recordListResponse.setCommissionPeriod(date.getYear()+"-"+date.getMonthValue());
            recordListResponse.setStatusStr(CommissionRecordStatusEnum.getNameByValue(recordListResponse.getStatus()));
            recordListResponse.setAgentTypeStr(recordListResponse.getAgentType()==0?"General line":"Professional line");
        }
        return responses;
    }


}
