package com.mkt.agent.commission.config;

import com.mkt.agent.common.config.JdbcParamsConfig;
import com.mkt.agent.ds.core.DataSourceConstants;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.Resource;

/**
 * @Description TODO
 * @Classname DataSourceClickhouseConfig
 * @Date 2023/11/22 12:22
 * @Created by TJSLucian
 */
@Configuration
public class DataSourceByteHouseConfig {

    @Resource
    private JdbcParamsConfig jdbcParamsConfig ;

    @Value("${spring.datasource.third.username}")
    private String userName;
    @Value("${spring.datasource.third.apiKey}")
    private String apiKey;
    @Value("${spring.datasource.third.url}")
    private String url;
    @Value("${spring.datasource.third.poolName}")
    private String poolName;
    @Value("${spring.datasource.third.driver-class-name}")
    private String driverClassName;

    @Bean(DataSourceConstants.MASTER_BYTE_HOUSE_DATASOURCE)
    public HikariDataSource hikariDataSource(){
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setDriverClassName(driverClassName);
        hikariConfig.setJdbcUrl(url);
        hikariConfig.setUsername(userName);
        hikariConfig.setPassword(apiKey);
        hikariConfig.setConnectionTimeout(jdbcParamsConfig.getConnectionTimeout());
        hikariConfig.setIdleTimeout(jdbcParamsConfig.getIdleTimeout());
        hikariConfig.setMaximumPoolSize(jdbcParamsConfig.getMaxPoolSize());
        hikariConfig.setMinimumIdle(jdbcParamsConfig.getMinIdle());
        hikariConfig.setMaxLifetime(jdbcParamsConfig.getMaxLifetime());
        hikariConfig.setPoolName(poolName);
        return new HikariDataSource(hikariConfig);
    }

}
