package com.mkt.agent.commission.board.core;

import com.google.gson.Gson;
import com.mkt.agent.commission.fegin.AgentFeignService;
import com.mkt.agent.commission.mapper.HistoryAgentDashboardDailyMapper;
import com.mkt.agent.commission.mapper.HistoryAgentDashboardMapper;
import com.mkt.agent.commission.util.DashBoardV1Utils;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.utils.BeanCopyUtil;
import com.mkt.agent.common.utils.DashBoardCommonUtil;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.*;

/**
 * @program: mkt-agent
 * @description: 历史数据维修器
 * @author: Erhu.Zhao
 * @create: 2023-12-08 19:51
 */
@Component
@Slf4j
@RefreshScope
public class HistoryDataRepair {

    private final DashBoardV1Utils dashBoardV1Utils;

    private final DashBoardCommonUtil dashBoardCommonUtil;

    private final HistoryAgentDashboardDailyMapper historyAgentDashboardDailyMapper;

    private final HistoryAgentDashboardMapper historyAgentDashboardMapper;

    private final AgentFeignService agentFeignService;

    private final RedisUtil redisUtil;

    private final Gson gson;

    private final DashBoardHelper dashBoardHelper;

    private static final List<Integer> repairTimes = new ArrayList<>();

    private final Integer repairBeforeDays;

    private final Integer interval;

    // 维修器开关
    private final boolean isOpenRepair;

    /**
     * 默认向前维修天数
     */
    private static final int DEFAULT_BEFORE_DAYS = 7;

    /**
     * 最大向前维修天数
     */
    private static final int MAX_BEFORE_DAYS = 10;

    public HistoryDataRepair(DashBoardV1Utils dashBoardV1Utils, DashBoardCommonUtil dashBoardCommonUtil,
                             HistoryAgentDashboardDailyMapper historyAgentDashboardDailyMapper,
                             HistoryAgentDashboardMapper historyAgentDashboardMapper,
                             AgentFeignService agentFeignService,
                             RedisUtil redisUtil, Gson gson,
                             DashBoardHelper dashBoardHelper,
                             @Value("${repair.before.days:7}") Integer repairBeforeDays,
                             @Value("${repair.interval.hours:3}") Integer interval,
                             @Value("${repair.switch:false}") Boolean isOpenRepair) {
        this.dashBoardV1Utils = dashBoardV1Utils;
        this.dashBoardCommonUtil = dashBoardCommonUtil;
        this.historyAgentDashboardDailyMapper = historyAgentDashboardDailyMapper;
        this.historyAgentDashboardMapper = historyAgentDashboardMapper;
        this.agentFeignService = agentFeignService;
        this.redisUtil = redisUtil;
        this.gson = gson;
        this.dashBoardHelper = dashBoardHelper;
        this.repairBeforeDays = repairBeforeDays;
        this.interval = interval;
        this.isOpenRepair = isOpenRepair;
    }

    @PostConstruct
    public void init() {
        try {
            collectBeforeDays(sureDays());
        } catch (Exception e) {
            collectBeforeDays(DEFAULT_BEFORE_DAYS);
        }
    }

    public void repair(ClDashBoardCreateQueryReq queryReq, boolean isUpdateForEmpty) {
        if (!isOpenRepair) {
            log.info("[repair method] property of [repair.switch] is closed, repair not allowed");
        }
        log.info("[repair method] begin to repair history table");
        String key = DashBoardCacheKeyBuilder.repairKey(queryReq);
        if (redisUtil.exists(key)) {
            log.error("[repair method] the current user has triggered repair,frequent repair not allowed");
            return;
        }
        // 设置3小时过期时间
        redisUtil.set(key, 1, interval * 60 * 60);
        doRepair(queryReq, isUpdateForEmpty);
    }

    /**
     * 执行修复
     *
     * @param queryReq 入参
     */
    private void doRepair(ClDashBoardCreateQueryReq queryReq, boolean isUpdateForEmpty) {
        log.info("[doRepair method] begin to doRepair");

        // 连接clickHouse查询当前用户指定时间区间的数据
        repairTimes.stream().forEach(time -> {
            log.info("[doRepair method] begin to doRepair before {} days", time);
            String repairDate = DateUtils.getNDaysAgo(time).toString();
            ClDashBoardCreateQueryReq newQuery = repackageQueryParam(queryReq, repairDate);

            // 判断 repairDate 属于上个月还是当前月
            boolean belongCurrentMonth = dashBoardHelper.belongCurrentMonth(repairDate);

            // 从clickHouse获取指定日期的数据
            DashBoardHistoryEntity clickHouseData = isUpdateForEmpty ? new DashBoardHistoryEntity() : obtainDataFromClickHouse(newQuery);
            DashBoardHistoryEntity localData = obtainLocalData(newQuery, belongCurrentMonth);
            // 如果前置日期的clickHouse的汇总数据和本地前置日期的汇总数据完全一致，则直接跳过维修工作
            if (compareDashBoardData(clickHouseData, localData)) {
                return;
            }

            Result<TAgentContract> contractResult = agentFeignService.queryContractByLoginName(queryReq.getAgentAccount());

            if(!contractResult.isSuccess() || Objects.isNull(contractResult.getData())){
                return;
            }
            TAgentContract contract = contractResult.getData();

            if (belongCurrentMonth) {
                // 属于当月数据变更，维修当前用户的缓存
                repairCurrentData(clickHouseData);
            } else {
                // 属于上个月数据变更，维修上个月当前用户的历史数据
                repairHistoryData(clickHouseData, queryReq);
            }

            log.info("[doRepair method] end to doRepair before {} days", time);
        });
        log.info("[doRepair method] end to doRepair");
    }

    /**
     * 维修当前用户在当前月的汇总数据
     *
     * @param clickHouseData 实时数据
     */
    private void repairCurrentData(DashBoardHistoryEntity clickHouseData) {
        dashBoardCommonUtil.saveRedisForDashBoard(List.of(clickHouseData));
    }

    private void repairHistoryData(DashBoardHistoryEntity clickHouseData, ClDashBoardCreateQueryReq queryReq) {
        // 更新历史数据
        repairHistoryDataOfTable2(clickHouseData);
        // 删除表1历史数据
        repairHistoryDataOfTable1(queryReq);
    }

    /**
     * 从clickHouse获取当前用户指定日期的汇总数据
     *
     * @param newQuery 入参
     * @return 响应
     */
    private DashBoardHistoryEntity obtainDataFromClickHouse(ClDashBoardCreateQueryReq newQuery) {
        return Optional.ofNullable(dashBoardV1Utils.getDashBoardResFromCl(newQuery)).orElseGet(DashBoardHistoryEntity::new);
    }

    /**
     * 获取本地数据（由于和clickHouse的数据进行比对）
     *
     * @param newQuery           入参
     * @param belongCurrentMonth 是否属于当前月还是上个月
     * @return 本地数据
     */
    private DashBoardHistoryEntity obtainLocalData(ClDashBoardCreateQueryReq newQuery, boolean belongCurrentMonth) {
        return belongCurrentMonth ? obtainDataFromCache(newQuery) : obtainDataFromHistoryTable(newQuery);
    }

    /**
     * 从历史表2获取当前用户指定日期的汇总数据（历史表2指挥持久化上个月数据）
     *
     * @param newQuery 入参
     * @return 响应
     */
    private DashBoardHistoryEntity obtainDataFromHistoryTable(ClDashBoardCreateQueryReq newQuery) {
        return Optional.ofNullable(queryHistoryTable(newQuery)).flatMap(list -> list.stream().findFirst()).orElseGet(DashBoardHistoryEntity::new);
    }

    /**
     * 从历史缓存中获取当前用户指定日期的汇总数据（缓存只会缓存当月数据）
     *
     * @param newQuery
     * @return
     */
    private DashBoardHistoryEntity obtainDataFromCache(ClDashBoardCreateQueryReq newQuery) {
        log.info("[obtainDataFromCache method] Get cached user information start");
        DashBoardHistoryEntity currentDataOfUser = dashBoardHelper.loadDashBoardDataFromCache(DashBoardCacheKeyBuilder.key(newQuery));
        log.info("[obtainDataFromCache method] Get cached user information end");
        return currentDataOfUser;
    }

    /**
     * 比较两个 DashBoardHistoryEntity 对象的内容是否完全相等
     *
     * @param left  左侧对象
     * @param right 右侧对象
     * @return 两个对象是否相等 true：相等 false：不相等
     */
    private boolean compareDashBoardData(DashBoardHistoryEntity left, DashBoardHistoryEntity right) {
        EqualsBuilder equalsBuilder = new EqualsBuilder();
        return equalsBuilder.append(left.getDashDate(), right.getDashDate()).
                append(left.getBetPlayers(), right.getBetPlayers()).
                append(left.getDeposit(), right.getDeposit()).
                append(left.getGgr(), right.getGgr()).
                append(left.getTurnover(), right.getTurnover()).
                append(left.getWinorloss(), right.getWinorloss()).
                append(left.getWithdraw(), right.getWithdraw()).
                append(left.getFirstDepositAmount(), right.getFirstDepositAmount()).
                append(left.getFirstDepositPlayers(), right.getFirstDepositPlayers()).
                append(left.getLoginName(), right.getLoginName()).
                append(left.getParentLoginName(), right.getParentLoginName()).
                append(left.getRegistrationNumber(), right.getRegistrationNumber()).isEquals();
    }


    /**
     * 根据条件重新组装请求对象
     *
     * @param source     原始请求对象
     * @param repairDate 维修日期
     * @return 重新组装后的请求对象
     */
    private ClDashBoardCreateQueryReq repackageQueryParam(ClDashBoardCreateQueryReq source, String repairDate) {
        ClDashBoardCreateQueryReq target = new ClDashBoardCreateQueryReq();
        BeanCopyUtil.copyProperties(source, target);
        target.setRecordDateStart(repairDate);
        target.setRecordDateEnd(repairDate);
        target.setRecordDateTimeStart(repairDate + Constants.START_TIME);
        target.setRecordDateTimeEnd(repairDate + Constants.END_TIME);
        return target;
    }

    /**
     * 查询表2： t_agent_dashboard_daily_history，统计当前用户每天的历史数据（以天为维度，每个用户每天的历史汇总数据），每天的汇总数据，没有计算佣金
     *
     * @param queryReq 请求参数
     */
    private List<DashBoardHistoryEntity> queryHistoryTable(ClDashBoardCreateQueryReq queryReq) {
        log.info("[queryHistoryTable method] begin to query history table2");
        List<DashBoardHistoryEntity> dataList = historyAgentDashboardDailyMapper.loadHistoryDashBoardDailyData(queryReq, Collections.emptyMap());
        log.info("[queryHistoryTable method] end to query history table2");
        return dataList;
    }

    /**
     * 更新历史数据
     *
     * @param responseFromClickHouse
     */
    private void repairHistoryDataOfTable2(DashBoardHistoryEntity responseFromClickHouse) {
        log.info("[repairHistoryDataOfTable2 method] begin to updateHistoryData");
        historyAgentDashboardDailyMapper.deleteByLoginNameAndDashDate(responseFromClickHouse);
        historyAgentDashboardDailyMapper.insert(responseFromClickHouse);
        log.info("[repairHistoryDataOfTable2 method] end to updateHistoryData");
    }

    /**
     * 删除指定区间的历史数据
     *
     * @param request 请求
     */
    private void repairHistoryDataOfTable1(ClDashBoardCreateQueryReq request) {
        log.info("[repairHistoryDataOfTable1 method] begin to removeHistoryDataOfTable1");
        // 删除表1上个月第一天到上个月最后一天的数据
        request.setRecordDateStart(DateUtils.getLastNMonthFirstDay(1).toString());
        request.setRecordDateEnd(DateUtils.getLastMonthLastDayV1().toString());
        Integer removeCount = historyAgentDashboardMapper.deleteByCondition(request);
        log.info("[repairHistoryDataOfTable1 method] end to removeHistoryDataOfTable1");
    }

    private int sureDays() {
        if (Objects.nonNull(repairBeforeDays)) {
            int days = Integer.valueOf(repairBeforeDays);
            if (days > MAX_BEFORE_DAYS) {
                days = MAX_BEFORE_DAYS;
            }
            return days;
        }
        return DEFAULT_BEFORE_DAYS;
    }

    private void collectBeforeDays(int up) {
        for (int day = 1; day <= up; day++) {
            repairTimes.add(day);
        }
    }

}