package com.mkt.agent.commission.mapper;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.sum.CommissionRecordPaySumResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.DashBoardCommissionVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface CommissionRecordMapper extends BaseMapper<AgentCommissionRecord> {

    CommissionRecordPaySumResponse queryByPageAndConditionSum( @Param("ew") Wrapper<AgentCommissionRecord> queryWrapper);

    CommissionRecordDashBoardResponse querySumAgentDepositWData(@Param("loginName") String loginName, @Param("recordDateStart") String recordDateStart, @Param("recordDateEnd") String recordDateEnd);

    CommissionRecordDashBoardResponse querySumAgentGameData(@Param("loginName") String loginName, @Param("recordDateStart") String recordDateStart, @Param("recordDateEnd") String recordDateEnd);

    CommissionRecordDashBoardResponse querySumAgentfirstDepositeData(@Param("parent") String loginName, @Param("recordDateStart") String recordDateStart, @Param("recordDateEnd") String recordDateEnd);

    CommissionRecordDashBoardResponse querybetPlayersCount(@Param("parent") String loginName, @Param("recordDateStart") String recordDateStart, @Param("recordDateEnd") String recordDateEnd);

    Long queryTurnoverActivePlayerCount(@Param("loginNameList") List<String> loginNameList, @Param("recordDateStart") String recordDateStart, @Param("recordDateEnd") String recordDateEnd,@Param("activeAmount") int activeAmount);

    Long queryGgrActivePlayerCount(@Param("loginNameList") List<String> loginNameList, @Param("recordDateStart") String recordDateStart, @Param("recordDateEnd") String recordDateEnd,@Param("activeAmount") int activeAmount);

    DashBoardCommissionVo queryCommissionByNameDate(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

}
