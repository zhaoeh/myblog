package com.mkt.agent.commission.mapper;

import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @program: mkt-agent
 * @description: 仪表盘历史数据mapper(历史表1 : t_agent_dashboard)
 * @author: Erhu.Zhao
 * @create: 2023-12-05 14:16
 */
@Mapper
public interface HistoryAgentDashboardMapper {
    /**
     * 查询仪表盘历史数据(第1张历史表)
     *
     * @param request 请求
     * @return 响应
     */
    List<CommissionRecordDashBoardResponse> loadHistoryDashBoardSummaryData(ClDashBoardCreateQueryReq request);

    Integer addHistoryDashBoardData(CommissionRecordDashBoardResponse data);

    Integer deleteByCondition(ClDashBoardCreateQueryReq request);

}