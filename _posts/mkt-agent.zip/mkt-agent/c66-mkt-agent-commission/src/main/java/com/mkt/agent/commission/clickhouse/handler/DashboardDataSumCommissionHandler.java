package com.mkt.agent.commission.clickhouse.handler;

import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.utils.DashBoardCommonUtil;
import com.mkt.agent.ds.finder.DataSourceHandler;
import com.mkt.agent.ds.finder.DataSourceRequest;
import com.mkt.agent.ds.finder.DataSourceResponse;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * @Description 聚合来自clickhouse和bytehouse的数据
 * @Classname dashboardDataSumHandler
 * @Date 2024/1/22 12:23
 * @Created by TJSLucian
 */
public class DashboardDataSumCommissionHandler implements DataSourceHandler {

    @Resource
    private DashBoardCommonUtil commonUtil;

    @Override
    public List<DataSourceRequest> handleRequestWithDataSource(Object[] args) {

        if(Objects.nonNull(args)&&Objects.nonNull(args[0])){
            ClDashBoardCreateQueryReq originalQueryReq = (ClDashBoardCreateQueryReq)args[0];

            List<DataSourceRequest> list = commonUtil.splitQueryReq(originalQueryReq);
            return list;
        }

        return null;
    }

    @Override
    public Object handleResponseWithDataSource(List<DataSourceResponse> dataSourceResponses) {
        return null;
    }




}
