package com.mkt.agent.commission.config.mybatisplusConfig.handler;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import com.mkt.agent.common.entity.system.LoginUserInfo;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.UserContext;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * 更新自动填充
 */
@Component
public class CommisssionMetaObjectHandler implements MetaObjectHandler {

    @Override
    public void insertFill(MetaObject metaObject) {
        LoginUserInfo userInfo = UserContext.getContext();
        String username = ObjectUtils.isNotEmpty(userInfo)
                && StringUtils.isNotEmpty(userInfo.getUsername()) ? userInfo.getUsername() : "not_login_user";
        // 插入操作时，自动填充字段的值
        this.setFieldValByName("createBy", username, metaObject);
        this.setFieldValByName("createTime", DateUtils.getCurrentDateTime(), metaObject);
        this.setFieldValByName("updateBy", username, metaObject);
        this.setFieldValByName("updateTime", DateUtils.getCurrentDateTime(), metaObject);
    }

    @Override
    public void updateFill(MetaObject metaObject) {
        LoginUserInfo userInfo = UserContext.getContext();
        String username = ObjectUtils.isNotEmpty(userInfo)
                && StringUtils.isNotEmpty(userInfo.getUsername()) ? userInfo.getUsername() : "not_login_user";
        // 更新操作时，自动填充字段的值
        this.setFieldValByName("updateBy", username, metaObject);
        this.setFieldValByName("updateTime", DateUtils.getCurrentDateTime(), metaObject);
    }
}
