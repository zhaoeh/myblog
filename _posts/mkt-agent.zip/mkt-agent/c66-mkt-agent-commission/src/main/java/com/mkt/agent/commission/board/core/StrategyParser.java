package com.mkt.agent.commission.board.core;

import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.utils.BeanCopyUtil;
import com.mkt.agent.common.utils.CommonUtil;
import com.mkt.agent.common.utils.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * @program: mkt-agent
 * @description: 解析请求以组装策略容器
 * @author: Erhu.Zhao
 * @create: 2023-12-05 14:46
 */
@Component
public class StrategyParser {

    private final DashBoardHelper dashBoardHelper;

    public StrategyParser(DashBoardHelper dashBoardHelper) {
        this.dashBoardHelper = dashBoardHelper;
    }

    /**
     * 解析请求以组装策略容器
     *
     * @param request 请求
     * @return 策略容器
     */
    public Map<String, ClDashBoardCreateQueryReq> parserStrategy(ClDashBoardCreateQueryReq request) {
        // toDo: 更新request对象中的loginNameList
        return cutClDashBoardCreateQueryReq(request);
    }

    /**
     * 解析请求已组装策略容器(适配饼状图)
     *
     * @param request 请求
     * @return 响应
     */
    public Map<String, ClDashBoardCreateQueryReq> parserStrategyOfTurnoverData(ClDashBoardCreateQueryReq request) {
        return cutOfTurnoverData(request);
    }

    /**
     * 根据结束日期切割请求对象
     *
     * @param request 请求对象
     * @return
     */
    public Map<String, ClDashBoardCreateQueryReq> cutClDashBoardCreateQueryReq(ClDashBoardCreateQueryReq request) {
        Map<String, ClDashBoardCreateQueryReq> requestCollector = new HashMap<>(8);
        // 请求中的开始日期
        int beginFromRequest = Optional.ofNullable(request.getRecordDateStart()).filter(StringUtils::isNotBlank).map(CommonUtil::convertToInt).orElse(Integer.MIN_VALUE);
        // 请求中的结束日期
        int endFromRequest = Optional.ofNullable(request.getRecordDateEnd()).filter(StringUtils::isNotBlank).map(CommonUtil::convertToInt).orElse(Integer.MAX_VALUE);
        if (beginFromRequest > endFromRequest) {
            return requestCollector;
        }

        // 上个月最后一天
        String lastDayOfLastMonth = DateUtils.getLastMonthLastDayV1().toString();
        int endFromLastDayOfLastMonth = CommonUtil.convertToInt(lastDayOfLastMonth);
        if (endFromRequest <= endFromLastDayOfLastMonth) {
            // 纯粹历史数据
            requestCollector.put(Constants.HISTORY_DATA, request);
        } else {
            // 当前月第一天
            String firstDayOfCurrentMonth = DateUtils.getLastNMonthFirstDay(0).toString();
            int beginFirstDayOfCurrentMonth = CommonUtil.convertToInt(firstDayOfCurrentMonth);
            if (beginFromRequest >= beginFirstDayOfCurrentMonth) {
                // 纯粹当月数据
                requestCollector.put(Constants.CURRENT_DATA, request);
            } else {
                // 跨月数据
                acrossTheMonth(requestCollector, request, firstDayOfCurrentMonth, lastDayOfLastMonth);
            }
        }
        return requestCollector;
    }

    /**
     * 聚合跨月数据的请求
     *
     * @param requestCollector       请求容器
     * @param request                请求
     * @param firstDayOfCurrentMonth 当前月第一天
     * @param lastDayOfLastMonth     上个月最后一天
     */
    private void acrossTheMonth(Map<String, ClDashBoardCreateQueryReq> requestCollector, ClDashBoardCreateQueryReq request,
                                String firstDayOfCurrentMonth, String lastDayOfLastMonth) {
        assembleRequestOfCurrentMonthData(requestCollector, request, firstDayOfCurrentMonth);
        assembleRequestOfPastMonthsData(requestCollector, request, lastDayOfLastMonth);
    }

    /**
     * 聚合纯粹当月实时数据的请求
     *
     * @param requestCollector 请求容器
     * @param request          请求
     */
    private void assembleRequestOfCurrentMonthData(Map<String, ClDashBoardCreateQueryReq> requestCollector, ClDashBoardCreateQueryReq request, String firstDayOfCurrentMonth) {
        ClDashBoardCreateQueryReq current = new ClDashBoardCreateQueryReq();
        BeanCopyUtil.copyProperties(request, current);
        current.setRecordDateStart(firstDayOfCurrentMonth);
        requestCollector.put(Constants.CURRENT_DATA, current);
    }

    /**
     * 聚合纯粹历史月份的请求
     *
     * @param requestCollector   请求容器
     * @param request            请求
     * @param lastDayOfLastMonth 上个月最后一天
     */
    private void assembleRequestOfPastMonthsData(Map<String, ClDashBoardCreateQueryReq> requestCollector, ClDashBoardCreateQueryReq request, String lastDayOfLastMonth) {
        // 历史月份的数据（上个月，上上月，以此类推）
        ClDashBoardCreateQueryReq last = new ClDashBoardCreateQueryReq();
        BeanCopyUtil.copyProperties(request, last);
        last.setRecordDateEnd(lastDayOfLastMonth);
        requestCollector.put(Constants.HISTORY_DATA, last);
    }

    /**
     * 适配饼状图需求,分割日期
     *
     * @param req 当前请求
     * @return 分割后的请求容器
     */
    private Map<String, ClDashBoardCreateQueryReq> cutOfTurnoverData(ClDashBoardCreateQueryReq req) {
        Map<String, ClDashBoardCreateQueryReq> requestCollector = new HashMap<>(8);
        // 29天之前的日期
        String dayOfBefore = DateUtils.getNDaysAgo(29).toString();
        boolean isBelongCurrent = dashBoardHelper.belongCurrentMonth(dayOfBefore);
        ClDashBoardCreateQueryReq currentMonthReq = new ClDashBoardCreateQueryReq();
        BeanCopyUtil.copyProperties(req, currentMonthReq);

        // 当前日期
        String currentDay = DateUtils.getNDaysAgo(0).toString();
        // 当前月第一天
        String firstDayOfCurrentMonth = DateUtils.getLastNMonthFirstDay(0).toString();
        currentMonthReq.setRecordDateStart(firstDayOfCurrentMonth);
        currentMonthReq.setRecordDateEnd(currentDay);
        requestCollector.put(Constants.CURRENT_DATA, currentMonthReq);
        // 历史月份策略
        if (!isBelongCurrent) {
            ClDashBoardCreateQueryReq historyMonthReq = new ClDashBoardCreateQueryReq();
            BeanCopyUtil.copyProperties(req, historyMonthReq);
            // 上个月最后一天
            String lastDayOfLastMonth = DateUtils.getLastMonthLastDayV1().toString();
            // 历史月份
            historyMonthReq.setRecordDateStart(dayOfBefore);
            historyMonthReq.setRecordDateEnd(lastDayOfLastMonth);
            requestCollector.put(Constants.HISTORY_DATA, historyMonthReq);
        }
        return requestCollector;
    }

}