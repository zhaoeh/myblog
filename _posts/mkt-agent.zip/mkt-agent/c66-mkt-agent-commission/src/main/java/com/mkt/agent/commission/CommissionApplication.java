package com.mkt.agent.commission;

import com.mkt.agent.ds.annotation.EnableDS;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableAsync;

@EnableDiscoveryClient
@EnableFeignClients
@EnableAsync
@RefreshScope
@SpringBootApplication(scanBasePackages = {"com.mkt.agent.commission", "com.mkt.agent.common", "com.mkt.agent.integration"})
@EnableDS
public class CommissionApplication {
    public static void main(String[] args) {
        SpringApplication.run(CommissionApplication.class);
    }
}
