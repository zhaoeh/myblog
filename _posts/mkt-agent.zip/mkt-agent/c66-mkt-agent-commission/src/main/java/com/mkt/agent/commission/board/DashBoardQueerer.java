package com.mkt.agent.commission.board;

import com.google.gson.Gson;
import com.mkt.agent.commission.board.core.DashBoardHelper;
import com.mkt.agent.commission.board.core.DashBoardUpdater;
import com.mkt.agent.commission.board.core.StrategyParser;
import com.mkt.agent.commission.board.data.DashBoardSupplier;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverDistriResp;
import com.mkt.agent.common.utils.ThreadLocalUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * @program: mkt-agent
 * @description: 仪表盘处理器
 * @author: Erhu.Zhao
 * @create: 2023-12-05 14:02
 */
@Component
@Slf4j
public class DashBoardQueerer {

    private final Map<String, DashBoardSupplier> dashBoardServiceMap = new HashMap<>();

    private final StrategyParser parser;

    private final DashBoardHelper dashBoardHelper;

    private final Gson gson;

    public DashBoardQueerer(ObjectProvider<Map<String, DashBoardSupplier>> objectProvider, StrategyParser parser, DashBoardHelper dashBoardHelper, Gson gson) {
        this.dashBoardHelper = dashBoardHelper;
        Map<String, DashBoardSupplier> opsMap = objectProvider.getIfAvailable();
        if (!CollectionUtils.isEmpty(opsMap)) {
            opsMap.forEach((k, v) -> this.dashBoardServiceMap.put(v.strategy(), v));
        }
        this.gson = gson;
        this.parser = parser;
    }

    public CommissionRecordDashBoardResponse queryDashBoardData(ClDashBoardCreateQueryReq request) {
        CommissionRecordDashBoardResponse data;
        try {
            log.info("[queryDashBoardData method] begin to query current user data,request is {}", gson.toJson(request));
            data = afterProcessData(request, loadData(request));
            wrapResponse(data, request);
            log.info("[queryDashBoardData method] end to query current user data,the data summary is : {}", gson.toJson(data));
        } catch (Exception e) {
            log.error("[queryDashBoardData method] error", e);
            throw e;
        }
        return data;
    }

    /**
     * 加载汇总数据
     *
     * @param request 请求
     * @return 当前用户指定时间段内的汇总数据
     */
    private List<CommissionRecordDashBoardResponse> loadData(ClDashBoardCreateQueryReq request) {
        Map<String, ClDashBoardCreateQueryReq> strategyContainer = parser.parserStrategy(request);
        List<CommissionRecordDashBoardResponse> result = new ArrayList<>();
        strategyContainer.forEach((k, v) -> result.add(this.dashBoardServiceMap.get(k).loadDashBoardData(v)));
        return result;
    }

    /**
     * 加载饼状图数据
     *
     * @param request 请求
     * @return 当前用户指定时间段内的饼状图数据
     */
    private List<CommissionRecordDashBoardResponse> loadTurnoverData(ClDashBoardCreateQueryReq request) {
        Map<String, ClDashBoardCreateQueryReq> strategyContainer = parser.parserStrategyOfTurnoverData(request);
        List<CommissionRecordDashBoardResponse> result = new ArrayList<>();
        strategyContainer.forEach((k, v) -> result.add(this.dashBoardServiceMap.get(k).loadTurnoverData(v)));
        return result;
    }

    /**
     * 数据后置处理
     *
     * @param dataList 参数
     * @return 组合后的对象
     */
    private CommissionRecordDashBoardResponse afterProcessData(ClDashBoardCreateQueryReq request, List<CommissionRecordDashBoardResponse> dataList) {
        log.info("[afterProcessData method] dataList is {},userName is {}", gson.toJson(dataList), request.getAgentAccount());
        // 最终返回结果： （1）重新聚合
        return Optional.ofNullable(dataList).flatMap(list -> list.stream().reduce(dashBoardHelper::refactorBoardResponseData)).
                orElseGet(CommissionRecordDashBoardResponse::new);

    }

    /**
     * 获取饼图数据
     *
     * @param request 请求
     * @return 响应(实时饼图数据)
     */
    public List<ClTurnoverDistriResp> obtainTurnoverDistriList(ClDashBoardCreateQueryReq request) {
        // 饼图数据
        /*return Optional.ofNullable(loadTurnoverData(request)).flatMap(list -> list.stream().
                        reduce(dashBoardHelper::refactorBoardResponseData).map(dashBoardHelper::calculateTurnoverDistriList)).
                orElseGet(ArrayList::new);*/
        return null;
    }

    /**
     * 包装响应
     *
     * @param data    响应
     * @param request 原始请求
     */
    private void wrapResponse(CommissionRecordDashBoardResponse data, ClDashBoardCreateQueryReq request) {
        // 设置id为null,后续需要使用该对象插入到历史表1
        data.setId(null);
        // 下述字段需要返回
        data.setRecordDateStart(request.getRecordDateStart());
        data.setRecordDateEnd(request.getRecordDateEnd());
        data.setLoginName(request.getAgentAccount());
    }

}