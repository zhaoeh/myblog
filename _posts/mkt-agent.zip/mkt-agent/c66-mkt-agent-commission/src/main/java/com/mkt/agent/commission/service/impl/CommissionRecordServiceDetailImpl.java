package com.mkt.agent.commission.service.impl;

import com.mkt.agent.commission.exception.MKTCommissionException;
import com.mkt.agent.commission.mapper.CommissionRecordDetailMapper;
import com.mkt.agent.commission.service.CommissionRecordQueryService;
import com.mkt.agent.commission.service.CommissionRecordService;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordDetailRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDetailResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.base.CommissionRecordPageResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.sum.CommissionRecordDetailSumResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.ExcelUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
public class CommissionRecordServiceDetailImpl implements CommissionRecordQueryService<CommissionRecordDetailRequest, CommissionRecordDetailResponse> {


    @Autowired
    private CommissionRecordDetailMapper commissionRecordDetailMapper;

    @Autowired
    private CommissionRecordService commissionRecordService;

    public CommissionRecordPageResponse<CommissionRecordDetailResponse> queryByPageAndCondition(CommissionRecordDetailRequest req) {

        // 根据commissionRecordId查记录
        Long commissionRecordId = req.getCommissionRecordId();
        AgentCommissionRecord one = commissionRecordService.getById(commissionRecordId);

        if (Objects.isNull(one)) {
            throw new MKTCommissionException(ResultEnum.COMMISSION_RECORD_NOT_EXIST);
        }

        //需要修改
        req.setSettleDateStart(one.getSettleDateStart().toString());
        req.setSettleDateEnd(one.getSettleDateEnd().toString());

        //设置父类账号
        req.setParentAccount(one.getAgentAccount());

        //分页数据初始化
        req.setPageSize(req.getPageSize());

        CommissionRecordPageResponse<CommissionRecordDetailResponse> commissionRecordOutVOPage = new CommissionRecordPageResponse<>();

        int count = commissionRecordDetailMapper.queryCountByPageAndCondition(req);

        if(count<=0){
            return commissionRecordOutVOPage;
        }
        // 查记录
        List<CommissionRecordDetailResponse> resultList = commissionRecordDetailMapper.queryByPageAndCondition(req);

        commissionRecordOutVOPage.setRecords(resultList);
        commissionRecordOutVOPage.setTotal(count);
        commissionRecordOutVOPage.setCurrent(req.getPageNum());
        commissionRecordOutVOPage.setSize(req.getPageSize());

        Map<String, BigDecimal> pageSumMap = commissionRecordOutVOPage.getPageSumMap();
        // 分页数据聚合
        for (CommissionRecordDetailResponse commissionRecordDetailResponse : resultList) {

            if (Objects.isNull(pageSumMap.get(BaseConstants.Turnover))) {
                pageSumMap.put(BaseConstants.GenerateCommission, new BigDecimal(0));
                pageSumMap.put(BaseConstants.Turnover, new BigDecimal(0));
                pageSumMap.put(BaseConstants.GGR, new BigDecimal(0));
                pageSumMap.put(BaseConstants.WinAndLoss, new BigDecimal(0));
                pageSumMap.put(BaseConstants.Deposit, new BigDecimal(0));
                pageSumMap.put(BaseConstants.Withdrawal, new BigDecimal(0));
            }

            // 分页聚合
            pageSumMap.put(BaseConstants.GenerateCommission, pageSumMap.get(BaseConstants.GenerateCommission).add(commissionRecordDetailResponse.getCommissionAmount()));
            pageSumMap.put(BaseConstants.Turnover, pageSumMap.get(BaseConstants.Turnover).add(commissionRecordDetailResponse.getTurnover()));
            pageSumMap.put(BaseConstants.GGR, pageSumMap.get(BaseConstants.GGR).add(commissionRecordDetailResponse.getGGR()));
            pageSumMap.put(BaseConstants.WinAndLoss, pageSumMap.get(BaseConstants.WinAndLoss).add(commissionRecordDetailResponse.getWinOrLoss()));
            pageSumMap.put(BaseConstants.Deposit, pageSumMap.get(BaseConstants.Deposit).add(commissionRecordDetailResponse.getDeposit()));
            pageSumMap.put(BaseConstants.Withdrawal, pageSumMap.get(BaseConstants.Withdrawal).add(commissionRecordDetailResponse.getWithdrawal()));

        }

        CommissionRecordDetailSumResponse commissionRecordDetailSumResponse = commissionRecordDetailMapper.queryByPageAndConditionSum(req);
        if (Objects.nonNull(commissionRecordDetailSumResponse)) {
            Map<String, BigDecimal> searchSumMap = commissionRecordOutVOPage.getSearchSumMap();

            if (Objects.isNull(searchSumMap.get(BaseConstants.Turnover))) {
                searchSumMap.put(BaseConstants.GenerateCommission, new BigDecimal(0));
                searchSumMap.put(BaseConstants.Turnover, new BigDecimal(0));
                searchSumMap.put(BaseConstants.GGR, new BigDecimal(0));
                searchSumMap.put(BaseConstants.WinAndLoss, new BigDecimal(0));
                searchSumMap.put(BaseConstants.Deposit, new BigDecimal(0));
                searchSumMap.put(BaseConstants.Withdrawal, new BigDecimal(0));
            }
            searchSumMap.put(BaseConstants.GenerateCommission, commissionRecordDetailSumResponse.getSumGenerateCommission());
            searchSumMap.put(BaseConstants.Turnover, commissionRecordDetailSumResponse.getSumTurnover());
            searchSumMap.put(BaseConstants.GGR, commissionRecordDetailSumResponse.getSumGGR());
            searchSumMap.put(BaseConstants.WinAndLoss, commissionRecordDetailSumResponse.getSumWinAndLoss());
            searchSumMap.put(BaseConstants.Deposit, commissionRecordDetailSumResponse.getSumDeposit());
            searchSumMap.put(BaseConstants.Withdrawal, commissionRecordDetailSumResponse.getSumWithdrawal());
        }

        return commissionRecordOutVOPage;
    }

    @Override
    public List<CommissionRecordDetailResponse> export(CommissionRecordDetailRequest req,HttpServletResponse response) {
        Long commissionRecordId = req.getCommissionRecordId();
        AgentCommissionRecord one = commissionRecordService.getById(commissionRecordId);

        if (Objects.isNull(one)) {
            throw new MKTCommissionException(ResultEnum.COMMISSION_RECORD_NOT_EXIST);
        }

        //设置父类账号
        req.setParentAccount(one.getAgentAccount());

        //分页数据初始化
        req.setPageSize(req.getPageSize());

        List<CommissionRecordDetailResponse> responses = commissionRecordDetailMapper.queryByPageAndCondition(req);

        responses.stream().forEach(r->{
            r.setAgentTypeStr(r.getAgentType()==0||r.getAgentType()==1?"Direct Agent":"Direct Player");

            /*switch (r.getAgentType()){
                case 0:
                    r.setAgentTypeStr("General Line");
                    break;
                case 1:
                    r.setAgentTypeStr("Professional Line");
                    break;
                default:
                    r.setAgentTypeStr("Direct Player");
                    break;
            }*/
        });
        return responses;

    }


}
