package com.mkt.agent.commission.board.core;

import com.mkt.agent.commission.config.DashBoardUpLimitConfigurer;
import com.mkt.agent.commission.config.DashAdditionalLimitConfigurer;
import com.mkt.agent.common.annotation.RequestLimit;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @program: mkt-agent
 * @description: 限流式更新缓存
 * @author: Erhu.Zhao
 * @create: 2023-12-06 17:32
 */
@Component
@Slf4j
public class DashBoardUpdateLimiter {

    private final DashBoardUpdater dashBoardUpdater;

    private final DashBoardUpdaterAdditional dashBoardUpdaterAdditional;

    public DashBoardUpdateLimiter(DashBoardUpdater dashBoardUpdater, DashBoardUpdaterAdditional dashBoardUpdaterAdditional) {
        this.dashBoardUpdater = dashBoardUpdater;
        this.dashBoardUpdaterAdditional = dashBoardUpdaterAdditional;
    }

    @RequestLimit(keyField = "agentAccount", period = 60, count = 1, limitConfigurer = DashBoardUpLimitConfigurer.class, handlerPolicy = RequestLimit.HandlerPolicy.REFUSE_RUN)
    public void updateDashBoardCacheOfAsyncAndLimiter(ClDashBoardCreateQueryReq info) {
        // 异步更新缓存数据
        dashBoardUpdater.updateDashBoardCache(info);
    }

    @RequestLimit(keyField = "agentAccount", period = 60, count = 1, limitConfigurer = DashAdditionalLimitConfigurer.class, handlerPolicy = RequestLimit.HandlerPolicy.REFUSE_RUN)
    public void updateAdditionalWithAsyncAndLimiter(ClDashBoardCreateQueryReq info) {
        // 异步更新缓存数据
        dashBoardUpdaterAdditional.updateDashBoardCacheOfAdditional(info);
    }

}