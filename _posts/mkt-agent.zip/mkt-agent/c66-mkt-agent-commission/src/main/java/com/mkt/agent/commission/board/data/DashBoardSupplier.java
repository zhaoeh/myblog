package com.mkt.agent.commission.board.data;

import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;

/**
 * @program: mkt-agent
 * @description: 仪表盘数据供应者
 * @author: Erhu.Zhao
 * @create: 2023-12-05 13:57
 */
public interface DashBoardSupplier {

    /**
     * 策略
     *
     * @return 策略名称
     */
    String strategy();

    /**
     * 查询仪表盘数据
     *
     * @param queryReq 请求
     * @return 响应
     */
    CommissionRecordDashBoardResponse loadDashBoardData(ClDashBoardCreateQueryReq queryReq);

    /**
     * 查询饼图数据
     *
     * @param queryReq 请求
     * @return 响应
     */
    CommissionRecordDashBoardResponse loadTurnoverData(ClDashBoardCreateQueryReq queryReq);

}