package com.mkt.agent.commission.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CommonMapper<T> extends BaseMapper<T> {

    int insertBatchSomeColumn(List<T> entityList);

}
