package com.mkt.agent.commission.clickhouse.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordDashBoardRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.dashboard.DashboardTopNDistriVo;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.common.entity.api.reportapi.responses.TurnoverDistributionResp;
import com.mkt.agent.common.entity.api.reportapi.responses.TurnoverTopResp;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverDistriResp;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverTopResp;

import java.util.List;

/**
 * @Description TODO
 * @Classname ClCommissionRecordService
 * @Date 2023/11/22 14:00
 * @Created by TJSLucian
 */
public interface ClDashBoardV1Service extends IService<AgentCommissionRecord> {

    Result<CommissionRecordDashBoardResponse> getTeamSummaryData(CommissionRecordDashBoardRequest req);

    DashboardTopNDistriVo getTurnoverTopNDistriData(String loginName);

}
