package com.mkt.agent.api.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mkt.agent.common.entity.api.agentapi.TAgentReferralCode;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentReferralCodeRequest;
import com.mkt.agent.common.entity.api.referral.ReferralCodeResp;
import com.mkt.agent.common.entity.api.referral.ReferralReq;

import java.util.List;

/**
 * @ClassName TAgentReferralCodeService
 * @Author TJSAustin
 * @Date 2023/5/23 10:00
 * @Version 1.0
 **/
public interface TAgentReferralCodeService extends IService<TAgentReferralCode> {

    Boolean referralCodeAllow(String referralCode);

    List<ReferralCodeResp> listReferral(String loginName);

    ReferralCodeResp edit(ReferralReq req);

    String generateId();

    List<String> getLoginNames(AgentReferralCodeRequest request);

    String getLoginName(AgentReferralCodeRequest request);

    String getReferralLink();
}
