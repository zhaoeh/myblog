package com.mkt.agent.api.service.impl;

import com.mkt.agent.api.mapper.TAgentUpdateLogMapper;
import com.mkt.agent.api.service.TAgentUpdateLogService;
import com.mkt.agent.api.utils.AgentApiUtils;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.api.agentapi.TAgentUpdateLog;
import com.mkt.agent.common.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;


/**
 * @Description TODO
 * @Classname TAgentUpdateLogServiceImpl
 * @Date 2023/12/8 18:24
 * @Created by TJSLucian
 */
@Service
@Slf4j
public class TAgentUpdateLogServiceImpl implements TAgentUpdateLogService {

    @Autowired
    private TAgentUpdateLogMapper agentUpdateLogMapper;

    @Autowired
    private AgentApiUtils agentApiUtils;

    @Override
    public TAgentUpdateLog getFrashBaName(String loginName) {
        return agentUpdateLogMapper.getFrashBaName(loginName);
    }

    @Override
    public void updateByName(String loginName){
        log.info("Update the agent update log for :{}",loginName);
        agentUpdateLogMapper.updateByName(loginName);
    }

    @Override
    public void saveList(List<String> names){

        if(CollectionUtils.isEmpty(names)){
            return;
        }

        List<String> parentAgentNameList = agentApiUtils.getParentNamesList(names);

        LocalDate currentDate = LocalDate.now();

        String currentDateTime = DateUtils.getCurrentDateTime();

        List<TAgentUpdateLog> list = parentAgentNameList.stream().map(agentAccount -> TAgentUpdateLog.builder().loginName(agentAccount)
                .updateDate(currentDate.toString()).updateDateTime(currentDateTime).status(BaseConstants.AGENT_UPDATE_LOG_STATUS_VILID).build()).collect(Collectors.toList());

        agentUpdateLogMapper.insertBatchSomeColumn(list);
    }




}
