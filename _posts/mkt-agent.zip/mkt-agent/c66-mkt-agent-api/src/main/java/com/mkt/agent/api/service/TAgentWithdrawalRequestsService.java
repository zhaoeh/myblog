package com.mkt.agent.api.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.api.entity.TAgentWithdrawalRequests;
import com.mkt.agent.common.entity.api.fund.req.QueryAgentWithdrawalRequestsReq;

public interface TAgentWithdrawalRequestsService {
    /**
     * 创建提案
     * @param requests
     * @return
     */
    TAgentWithdrawalRequests create(TAgentWithdrawalRequests requests);

    /**
     * 审核操作
     * @param requests
     * @return
     */
    boolean approval(TAgentWithdrawalRequests requests);


    Page<TAgentWithdrawalRequests> queryByCondition(QueryAgentWithdrawalRequestsReq requestsReq);

    /**
     * 查询是否有pending状态的提案
     * @param loginName
     * @param productId
     * @return
     */
    boolean hasPendingRequests(String loginName, String productId);
}
