package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.api.entity.TAgentFundRecord;
import com.mkt.agent.api.entity.req.FundRecordReq;
import com.mkt.agent.common.entity.api.fund.resp.FundRecordResp;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @ClassName FundMapper
 * @Author TJSAlex
 * @Date 2023/5/18 16:50
 * @Version 1.0
 **/
public interface FundRecordMapper extends BaseMapper<TAgentFundRecord> {
    Integer count(@Param("fundRecordReq") FundRecordReq fundRecordReq,
                  @Param("fundType") Integer fundType,
                  @Param("fundStatus") Integer fundStatus, @Param("customerType") Integer customerType);

    List<FundRecordResp> list(@Param("fundRecordReq") FundRecordReq fundRecordReq,
                              @Param("fundType") Integer fundType,
                              @Param("fundStatus") Integer fundStatus,
                              @Param("customerType") Integer customerType,
                              @Param("hasPage") boolean hasPage);

    Integer updateStatus(@Param("fundRecord") TAgentFundRecord fundRecord);

    BigDecimal countAmountByType(@Param("account") String account,
                                 @Param("fundType") Integer fundType,
                                 @Param("beginDate") Date begin);

    TAgentFundRecord selectLastOneByType(@Param("account") String account,@Param("fundType") Integer fundType);
}
