package com.mkt.agent.api.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mkt.agent.api.exception.MKTAgentException;
import com.mkt.agent.api.mapper.TAgentReferralCodeMapper;
import com.mkt.agent.api.service.TAgentReferralCodeService;
import com.mkt.agent.common.entity.api.agentapi.TAgentReferralCode;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentReferralCodeRequest;
import com.mkt.agent.common.entity.api.referral.ReferralCodeResp;
import com.mkt.agent.common.entity.api.referral.ReferralReq;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.utils.BeanCopyUtil;
import com.mkt.agent.common.utils.ReferralIdGenerator;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@RefreshScope
public class TAgentReferralCodeServiceImpl extends ServiceImpl<TAgentReferralCodeMapper, TAgentReferralCode> implements TAgentReferralCodeService {

    @Value("${mkt.referralLink}")
    private String referralLink;

    //判断当前代理是否允许创建下级代理
    @Override
    public Boolean referralCodeAllow(String referralCode) {
        QueryWrapper<TAgentReferralCode> wrapper = new QueryWrapper();
        if (StringUtils.isNotBlank(referralCode)) {
            wrapper.eq("referral_id", referralCode);
        } else {
            return false;
        }
        long count = super.count(wrapper);
        return count <= 0;
    }

    @Override
    public List<ReferralCodeResp> listReferral(String loginName) {
        List<TAgentReferralCode> referralCodes = this.getBaseMapper().selectList(new LambdaQueryWrapper<TAgentReferralCode>()
                .eq(TAgentReferralCode::getLoginName, loginName));
        List<ReferralCodeResp> list = BeanCopyUtil.copyListProperties(referralCodes, ReferralCodeResp::new);
        for (ReferralCodeResp rsp : list) {
            rsp.setReferralLink(referralLink);
        }
        return list;
    }

    @Override
    public ReferralCodeResp edit(ReferralReq req) {
        String loginName = req.getLoginName();
        String referralId = req.getReferralId();
        TAgentReferralCode tAgentReferralCode = checkReferralId(loginName,referralId);
        try {
            tAgentReferralCode.setReferralId(referralId);
            this.getBaseMapper().updateById(tAgentReferralCode);
        } catch (DuplicateKeyException e) {
            throw new BusinessException("ReferralId Duplicate");
        } catch (RuntimeException e) {
            throw new BusinessException(e.getMessage());
        }
        ReferralCodeResp resp = BeanCopyUtil.copyProperties(tAgentReferralCode, ReferralCodeResp::new);
        return resp;
    }

    @Override
    public String generateId() {
        return ReferralIdGenerator.generateReferralId();
    }

    @Override
    public List<String> getLoginNames(AgentReferralCodeRequest request) {
        List<TAgentReferralCode> tAgentReferralCodes = this.getBaseMapper()
                .selectList(new LambdaQueryWrapper<TAgentReferralCode>()
                        .like(TAgentReferralCode::getReferralId, request.getReferralId()));
        if (CollectionUtils.isEmpty(tAgentReferralCodes) ) {
            throw new MKTAgentException(ResultEnum.REGISTER_ID_NOT_EXIST);
        }
        return tAgentReferralCodes.stream().map(TAgentReferralCode :: getLoginName).collect(Collectors.toList());
    }

    @Override
    public String getLoginName(AgentReferralCodeRequest request) {
        List<TAgentReferralCode> tAgentReferralCodes = this.getBaseMapper()
                .selectList(new LambdaQueryWrapper<TAgentReferralCode>()
                        .eq(TAgentReferralCode::getReferralId, request.getReferralId()));
        if (CollectionUtils.isEmpty(tAgentReferralCodes) ) {
            throw new MKTAgentException(ResultEnum.REGISTER_ID_NOT_EXIST);
        }
        if (tAgentReferralCodes.size() > 1) {
            throw new MKTAgentException(ResultEnum.REGISTER_ID_NOT_ONE);
        }
        return tAgentReferralCodes.get(0).getLoginName();
    }

    @Override
    public String getReferralLink() {
        return referralLink;
    }

    private TAgentReferralCode checkReferralId(String loginName,String referralId) {
        TAgentReferralCode referralCode = this.getBaseMapper().selectOne(new LambdaQueryWrapper<TAgentReferralCode>().eq(TAgentReferralCode::getLoginName, loginName));
        if (Objects.isNull(referralCode)) {
            throw new BusinessException("loginName不存在");
        }
        int length = referralId.length();
        if (length < 4 || length > 8) {
            throw new BusinessException("minimum 4 characters, maximum 8 characters.");
        }
        if(referralId.equals(referralCode.getReferralId())) {
            throw new BusinessException("new referralId is same to the old one");
        }
        char[] chars = referralId.toCharArray();
        for (char c : chars) {
            if (c == 'i' || c == 'l' || c == 'o' || c == '0' || c == '1') {
                throw new BusinessException("i,l,o,0,1, not case sensitive");
            }
        }
        return referralCode;
    }

}
