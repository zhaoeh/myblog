package com.mkt.agent.api.service.impl;

import com.alibaba.excel.util.StringUtils;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cn.schema.creditlogs.WSDepositTrans;
import com.cn.schema.customers.WSCustomers;
import com.mkt.agent.api.entity.TAgentDepositTrans;
import com.mkt.agent.api.entity.req.FundTradeReq;
import com.mkt.agent.api.enums.DepositTransEnum;
import com.mkt.agent.api.mapper.DepositTransMapper;
import com.mkt.agent.api.service.DepositTransService;
import com.mkt.agent.api.service.FundService;
import com.mkt.agent.api.service.TAgentCustomersService;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.constants.LockKeyConst;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.fund.req.DepositTransReq;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.utils.NumberUtils;
import com.mkt.agent.common.utils.RedisUtil;
import com.mkt.agent.common.utils.TransIdGenerator;
import com.mkt.agent.integration.config.UserCenterConfig;
import com.mkt.agent.integration.config.WSConfig;
import com.mkt.agent.integration.entities.request.CreateOnlineOrderReq;
import com.mkt.agent.integration.template.UserCenterTemplate;
import com.mkt.agent.integration.template.WsTemplate;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.Duration;
import java.util.Date;
import java.util.Objects;

/**
 * @ClassName TDepositTransServiceImpl
 * @Author TJSAlex
 * @Date 2023/6/28 14:58
 * @Version 1.0
 **/
@Service
@Slf4j
public class DepositTransServiceImpl extends BaseFundServiceImpl implements DepositTransService {

    @Resource
    private DepositTransMapper depositTransMapper;
    @Resource
    private FundService fundService;
    @Resource
    private TAgentCustomersService tAgentCustomersService;
    @Resource
    private WSConfig wsConfig;
    @Resource
    private UserCenterConfig userCenterConfig;

    @Resource
    private RedisUtil redisUtil;

    @Override
    public boolean apply(CreateOnlineOrderReq req) {
        boolean firstDeposit = false;
        Long count = depositTransMapper.selectCount(new LambdaQueryWrapper<TAgentDepositTrans>()
                .eq(TAgentDepositTrans::getCustomerId, req.getCustomerId())
                .eq(TAgentDepositTrans::getLoginName, req.getLoginName())
                .eq(TAgentDepositTrans::getDeleteFlag, 0));
        if(count > 0) {
            firstDeposit = true;
        }

        req.setAmount(NumberUtils.twoScaleFormat(req.getAmount()));
//        TAgentCustomers customer = getParentByLoginName(req.getLoginName());
        String username = req.getLoginName();
//        String referenceId = TransIdGenerator.singleGenRequestId(req.getProductId(), Constants.REQUEST_TYPE_DEPOSIT);
        String referenceId = TransIdGenerator.getSingleId(Constants.C66);
        Date now = new Date();
        TAgentDepositTrans depositTrans = TAgentDepositTrans.builder()
                .customerId(Long.parseLong(req.getCustomerId())).loginName(req.getLoginName())
                .productId(req.getProductId()).amount(req.getAmount()).referenceId(referenceId)
                .parent(req.getLoginName()).catalog(0).depositType(0).firstDeposit(firstDeposit)
                .createdBy(username).depositBy(username).product(1).createdDate(now).lastUpdateDate(now)
                .status(DepositTransEnum.Pending.getCode()).build();
        int insert = depositTransMapper.insert(depositTrans);
        return insert > 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean approve(WSDepositTrans req) {
        boolean r;

        boolean lock = false;
        String lockKey = LockKeyConst.DEPOSIT_SUCCESS+req.getReferenceId();

        try {
            lock = redisUtil.setIfAbsent(lockKey,"1", Duration.ofMinutes(2));
            if (lock) {
                TAgentDepositTrans depositTrans = depositTransMapper.selectOne(new LambdaQueryWrapper<TAgentDepositTrans>()
                        .eq(StringUtils.isNotBlank(req.getCustomerId()), TAgentDepositTrans::getCustomerId, req.getCustomerId())
                        .eq(TAgentDepositTrans::getReferenceId, req.getReferenceId())
                        .eq(TAgentDepositTrans::getLoginName, req.getLoginName())
                        .eq(TAgentDepositTrans::getStatus,DepositTransEnum.Pending.getCode())
                        .eq(TAgentDepositTrans::getDeleteFlag, 0));
                if (Objects.isNull(depositTrans)) {
                    throw new BusinessException("该提案订单不存在");
                }

                FundTradeReq tradeReq = FundTradeReq.builder().agentId(depositTrans.getCustomerId())
                        .loginName(depositTrans.getLoginName())
                        .amount(depositTrans.getAmount()).isApprove(true)
                        .orderId(depositTrans.getReferenceId()).build();
                r = fundService.deposit(tradeReq);
                if (r) {
                    depositTrans.setStatus(DepositTransEnum.Approved.getCode());
                    r = depositTransMapper.updateById(depositTrans) > 0;
                }
            }else{
                throw new BusinessException("Locking Please Try Again Later");
            }
        }catch (Exception e){
            log.error("",e);
            throw new BusinessException(e.getMessage());
        }finally {
            if (lock) {redisUtil.remove(lockKey);}
        }

        return r;
    }

    @Override
    public Page<TAgentDepositTrans> query(DepositTransReq req) {
        LambdaQueryWrapper<TAgentDepositTrans> queryWrapper = new LambdaQueryWrapper<TAgentDepositTrans>()
                .eq((Objects.nonNull(req.getStatus())), TAgentDepositTrans::getStatus, req.getStatus())
                .eq(Objects.nonNull(req.getCustomerId()), TAgentDepositTrans::getCustomerId, req.getCustomerId())
                .eq(StringUtils.isNotBlank(req.getLoginName()), TAgentDepositTrans::getLoginName, req.getLoginName())
                .eq(StringUtils.isNotBlank(req.getOrderId()), TAgentDepositTrans::getReferenceId, req.getOrderId())
                .eq(Objects.nonNull(req.getStatus()),TAgentDepositTrans::getStatus,req.getStatus())
                .eq(TAgentDepositTrans::getDeleteFlag, 0);
        Long total = depositTransMapper.selectCount(queryWrapper);
        Page<TAgentDepositTrans> pageResult = Page.of(req.getPageNum(), req.getPageSize(),total);
        if(Objects.isNull(total) || total == 0){
            return pageResult;
        }
        pageResult = depositTransMapper.selectPage(pageResult, queryWrapper);
        return pageResult;
    }

    @Override
    public boolean apply(WSDepositTrans req) {
        boolean firstDeposit = false;
        Long count = depositTransMapper.selectCount(new LambdaQueryWrapper<TAgentDepositTrans>()
                .eq(TAgentDepositTrans::getCustomerId, req.getCustomerId())
                .eq(TAgentDepositTrans::getLoginName, req.getLoginName())
                .eq(TAgentDepositTrans::getDeleteFlag, 0));
        if(count > 0) {
            firstDeposit = true;
        }
        String username = req.getLoginName();
        TAgentCustomers customer = tAgentCustomersService.getAgentByLoginName(username);
//        WsTemplate wsTemplate = new WsTemplate(wsConfig.getWsDefaultUrl(),wsConfig.getPwd());
        UserCenterTemplate userCenterTemplate = new UserCenterTemplate(userCenterConfig.getUserCenterDefaultUrl(),userCenterConfig.getPwd());
        WSCustomers c = userCenterTemplate.queryCustomerByLoginName(req.getProductId(), username);
        if(ObjectUtils.isEmpty(c)) {
            return false;
        }
        Date now = new Date();
        TAgentDepositTrans depositTrans = TAgentDepositTrans.builder()
                .customerId(Long.parseLong(req.getCustomerId())).loginName(req.getLoginName())
                .productId(req.getProductId()).amount(new BigDecimal(req.getAmount())).referenceId(req.getReferenceId())
                .parent(req.getParent()).catalog(0).depositType(0).firstDeposit(firstDeposit)
                .endPoint(req.getEndPoint()).endPointUrl(req.getEndPointUrl()).transCode(req.getTransCode())
                .lastUpdatedBy(req.getLastUpdate()).registerBranchCode(c.getBranchCode())
                .registerBranchName(c.getBranchName())
                .createdBy(req.getLoginName()).depositBy(req.getLoginName()).product(customer.getSiteId())
                .createdDate(now).lastUpdateDate(now)
                .status(DepositTransEnum.Pending.getCode()).build();
        int insert = depositTransMapper.insert(depositTrans);
        return insert > 0;
    }
}
