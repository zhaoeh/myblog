package com.mkt.agent.api.entity.req;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @ClassName FundModifyReq
 * @Author TJSAlex
 * @Date 2023/6/19 18:57
 * @Version 1.0
 **/
@Data
public class FundModifyReq implements Serializable {
    @ApiModelProperty(value = "agentId")
    @NotNull(message = "agentId is required!")
    private Long agentId;

    @ApiModelProperty(value = "loginName")
    @NotNull(message = "loginName is required!")
    private String loginName;

    @ApiModelProperty(value = "amount")
    @NotNull(message = "amount is required!")
    private BigDecimal amount;

    @ApiModelProperty(value = "type",notes = "true:减额度 false:加额度")
    @NotNull(message = "type is required!")
    private Boolean type;
}
