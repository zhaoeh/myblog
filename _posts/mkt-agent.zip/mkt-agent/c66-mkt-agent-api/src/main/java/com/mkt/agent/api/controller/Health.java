package com.mkt.agent.api.controller;


import com.mkt.agent.common.entity.Result;

import com.mkt.agent.common.utils.StreamUtils;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.InputStream;


/**
 * @ClassName HealthController
 * @Description 应用程序健康检查
 * @Author Tim
 * @Date 2023/6/23 14:18
 * @Version 1.0
 **/
@RestController
@Slf4j
public class Health {

    @ApiOperation(value = "检查服务是否健康运行", notes = "检查服务是否健康运行")
    @RequestMapping(value = "/health")
    public Result<String> health() {
        return readGitProperties();
    }

    private Result<String> readGitProperties() {
        InputStream inputStream = null;
        try {
            ClassLoader classLoader = getClass().getClassLoader();
            inputStream = classLoader.getResourceAsStream("git.properties");
            String versionJson = StreamUtils.readStream(inputStream);
            String[] gits = versionJson.split("=");
            String version = "version:"+gits[gits.length-1];
            return Result.success(version.substring(0,version.length()-2));
        } catch (Exception e) {
            log.error("get git version info fail", e);
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (Exception e) {
                log.error("close inputstream fail", e);
            }
        }
        return Result.success();
    }

}
