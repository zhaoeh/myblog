package com.mkt.agent.api.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cn.schema.creditlogs.WSDepositTrans;
import com.mkt.agent.api.entity.TAgentDepositTrans;
import com.mkt.agent.api.service.DepositTransService;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.fund.req.DepositTransReq;
import com.mkt.agent.common.entity.api.fund.req.FundApproveReq;
import com.mkt.agent.integration.entities.request.CreateOnlineOrderReq;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @ClassName DepositTransController
 * @Description 存款提案
 * @Author TJSAlex
 * @Date 2023/6/28 14:27
 * @Version 1.0
 **/
@RestController
@RequestMapping("/depositRequests")
public class DepositTransController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private DepositTransService depositTransService;

    @ApiOperation(
            value = "生成存款提案接口",
            notes = "生成存款提案接口,",
            httpMethod = "POST"
    )
    @PostMapping("/apply")
    public Result<Boolean> apply(@RequestBody CreateOnlineOrderReq req) {
        try {
            boolean resp = depositTransService.apply(req);
            logger.info("/depositRequests/apply 入参CreateOnlineOrderReq：{} 返回值：{}", req.toString(), resp);
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/depositRequests/apply 出异常了，入参CreateOnlineOrderReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @ApiOperation(
            value = "存款提案修改",
            notes = "存款提案修改",
            httpMethod = "POST"
    )
    @PostMapping("/approve")
    public Result<Boolean> approve(@RequestBody WSDepositTrans requests) {
        try {
            boolean resp = depositTransService.approve(requests);
            logger.info("/depositRequests/approve 入参WSDepositTrans：{} 返回值：{}", requests.toString(), resp);
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/depositRequests/approve 出异常了，入参WSDepositTrans：{} 异常信息：{}", requests.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @ApiOperation(
            value = "查询取款提案",
            notes = "查询取款提案",
            httpMethod = "POST"
    )
    @PostMapping("/query")
    public Result<Page<TAgentDepositTrans>> query(@RequestBody DepositTransReq requestsReq) {
        try {
            Page<TAgentDepositTrans> resp = depositTransService.query(requestsReq);
            logger.info("/depositRequests/query 入参DepositTransReq：{} 返回值：{}", requestsReq.toString(), resp.getRecords().toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/depositRequests/query 出异常了，入参DepositTransReq：{} 异常信息：{}", requestsReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }
}
