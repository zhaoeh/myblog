package com.mkt.agent.api.feign;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.commissionapi.requests.*;
import com.mkt.agent.common.entity.api.commissionapi.responses.*;
import com.mkt.agent.common.entity.api.commissionapi.responses.base.CommissionRecordPageResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.dashboard.DashboardTopNDistriVo;
import io.swagger.annotations.ApiOperation;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

/**
 * @interfaceName: 佣金模块api
 * @Description:
 * @Author: Amida
 * @Date: 2023/5/30
 */
//@FeignClient(name = "${feign.mkt-agent-commission}", url = "127.0.0.1:18081")
@FeignClient(name = "${feign.mkt-agent-commission}")
public interface CommissionApiGateClient {
    @PostMapping("/commissionRecord/updatePlayerStatus")
    Result<Map<String, Object>> updatePlayerStatus(@RequestBody Map<String, String> req);

}
