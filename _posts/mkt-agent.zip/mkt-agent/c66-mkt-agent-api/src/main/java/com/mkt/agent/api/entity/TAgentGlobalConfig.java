package com.mkt.agent.api.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.mkt.agent.common.entity.BaseEntity;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @ClassName TAgentGlobalConfig
 * @Description 全局配置表
 * @Author TJSAlex
 * @Date 2023/5/22 16:18
 * @Version 1.0
 **/
@TableName
@Data
@SuperBuilder
@NoArgsConstructor
public class TAgentGlobalConfig extends BaseEntity {
    private String paramName;
    private String paramValue;
    private Integer isEnable;
    private String createBy;
    private String updateBy;
}
