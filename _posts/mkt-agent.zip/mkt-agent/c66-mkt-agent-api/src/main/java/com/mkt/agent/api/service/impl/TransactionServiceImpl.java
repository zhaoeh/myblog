package com.mkt.agent.api.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.mkt.agent.api.entity.TAgentDepositTrans;
import com.mkt.agent.api.entity.TAgentFundRecord;
import com.mkt.agent.api.entity.TAgentWallet;
import com.mkt.agent.api.entity.req.FundApproveReq;
import com.mkt.agent.api.entity.req.FundTradeReq;
import com.mkt.agent.api.mapper.DepositTransMapper;
import com.mkt.agent.api.mapper.FundRecordMapper;
import com.mkt.agent.api.mapper.FundWalletMapper;
import com.mkt.agent.api.service.FundService;
import com.mkt.agent.api.service.TransactionService;
import com.mkt.agent.common.enums.FundStatusEnum;
import com.mkt.agent.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * @ClassName TransactionServiceImpl
 * @Author TJSAlex
 * @Date 2023/5/25 14:43
 * @Version 1.0
 **/
@Service
@Slf4j
public class TransactionServiceImpl implements TransactionService {
    @Resource
    private FundWalletMapper fundWalletMapper;
    @Resource
    private FundRecordMapper fundRecordMapper;

    @Transactional(rollbackFor = Throwable.class)
    @Override
    public boolean transfer(Long fromId, Long toId, BigDecimal amount) {

        if(fromId!=-1l){
            TAgentWallet fromWallet = fundWalletMapper.selectOne(new LambdaQueryWrapper<TAgentWallet>().eq(TAgentWallet::getAgentId, fromId).eq(TAgentWallet::getIsEnable, 1));
            BigDecimal subtract = fromWallet.getBalance().subtract(amount);
            fromWallet.setBalance(subtract);
            fundWalletMapper.updateById(fromWallet);
        }
        TAgentWallet toWallet = fundWalletMapper.selectOne(new LambdaQueryWrapper<TAgentWallet>().eq(TAgentWallet::getAgentId, toId).eq(TAgentWallet::getIsEnable, 1));
        if (Objects.nonNull(toWallet)) {
            BigDecimal add = toWallet.getBalance().add(amount);
            toWallet.setBalance(add);
            fundWalletMapper.updateById(toWallet);
            return true;
        }
        return false;
    }

    @Override
    public boolean updateWithdrawalStatus(TAgentFundRecord record, com.mkt.agent.api.entity.req.FundApproveReq req) {
        record.setStatus(req.getIsApprove() ? FundStatusEnum.Success.getCode() : FundStatusEnum.Failure.getCode());
        record.setId(null);
        int insert = fundRecordMapper.insert(record);
        //风控审批不通过退还余额
        if (insert == 1 && !req.getIsApprove()) {
            BigDecimal amount = record.getAmount();
            TAgentWallet wallet = fundWalletMapper.selectOne(new LambdaQueryWrapper<TAgentWallet>().eq(TAgentWallet::getAgentId, req.getAgentId())
                    .eq(TAgentWallet::getLoginName, req.getLoginName()).eq(TAgentWallet::getIsEnable, 1));
            if (Objects.isNull(wallet)) {
                throw new BusinessException("该代理钱包不存在");
            }
            BigDecimal originalAmount = wallet.getBalance().add(amount);
            wallet.setBalance(originalAmount);
            fundWalletMapper.updateById(wallet);
        }
        return insert != 0;
    }


    @Override
    public BigDecimal getAmount(String loginName){
        // todo
        LambdaQueryWrapper<TAgentWallet> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(TAgentWallet::getLoginName,loginName);

        TAgentWallet tAgentWallet = fundWalletMapper.selectOne(wrapper);
        if(tAgentWallet != null){
            return tAgentWallet.getBalance();
        }
        return BigDecimal.ZERO;
    }
}
