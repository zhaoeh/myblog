package com.mkt.agent.api.mq.listener;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mkt.agent.api.exception.MKTAgentException;
import com.mkt.agent.api.mq.handler.TransferHandler;
import com.mkt.agent.api.mq.msg.TransferMessage;
import com.mkt.agent.api.service.*;
import com.mkt.agent.common.constants.ATransferConstants;
import com.mkt.agent.common.entity.api.atransferapi.request.A2ATransferReq;
import com.mkt.agent.common.entity.api.atransferapi.request.A2PTransferReq;
import com.mkt.agent.common.entity.api.atransferapi.request.AgentAllTransferReq;
import com.mkt.agent.common.entity.api.atransferapi.request.P2ATransferReq;
import com.mkt.agent.common.utils.BeanCopyUtil;
import com.mkt.agent.common.utils.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Objects;

@Slf4j
@Component
public class TransferListener {

    private static final String TRANSFER_APPROVE_QUEUE = "C66.officeapp.online.agent.transfer";

    private static final String TRANSFER_APPROVE_EXCHANGE = "exchange_online_agent_transfer";

    private static final String TRANSFER_APPROVE_ROUTING_KEY = "C66.online.agent.transfer";

    @Autowired
    private A2ATransferService a2ATransferService;

    @Autowired
    private A2PTransferService a2PTransferService;

    @Autowired
    private P2ATransferService p2ATransferService;

    @Resource
    private TransferHandler transferHandler;


    @RabbitListener(bindings = @QueueBinding(
                    value = @Queue(value = TRANSFER_APPROVE_QUEUE, durable = "true", autoDelete = "false"),
                    exchange = @Exchange(value = TRANSFER_APPROVE_EXCHANGE, durable = "true", type = "direct"),
                    key = TRANSFER_APPROVE_ROUTING_KEY))
    public void A2ATransferListener(Message msg) throws Exception {

        if (msg == null) {
            log.info("创建A2A转账交易记录message消息为空");
            return;
        }
        log.info("transfer mq service is ready!----msg is:{}",msg.toString());
        String data = new String(msg.getBody());
        if (StringUtils.isNotBlank(data)) {
            JSONObject messageJson = JSON.parseObject(data);

            if(Objects.isNull(messageJson)){
                log.info("创建A2A转账交易记录message消息为空----");
                return;
            }

            log.info("messageJson is:{}",messageJson.toJSONString());

            AgentAllTransferReq req = JsonUtil.toObject(messageJson.getString("content"), AgentAllTransferReq.class);
            TransferMessage transferMessage = BeanCopyUtil.copyProperties(req,TransferMessage::new);
            try {
                //插入消息
                log.info("Insert mq message:{}",transferMessage.toString());
                TransferMessage oldMsg = transferHandler.select(transferMessage.getMessageId());
                if(Objects.isNull(oldMsg)){
                    transferMessage.setContent(JSONObject.toJSONString(req));
                    transferHandler.insert(transferMessage);
                }else if(oldMsg.getStatus()==1){
                    return;
                }

            }catch (Exception e){
                log.info("Message already exists!", e);
                return;
            }

            try {

                log.info("Begin to handle transfer service by mq. The param is :{}",req.toString());

                if(req.getFromToType().equals(ATransferConstants.A2A)){
                    //代理转代理
                    A2ATransferReq a2ATransferReq = new A2ATransferReq();
                    BeanUtils.copyProperties(req, a2ATransferReq);
                    a2ATransferService.createA2ATrans(a2ATransferReq);
                }else if(req.getFromToType().equals(ATransferConstants.A2P)){
                    //代理转玩家
                    A2PTransferReq a2PTransferReq = new A2PTransferReq();
                    BeanUtils.copyProperties(req, a2PTransferReq);
                    a2PTransferService.createA2PTrans(a2PTransferReq);
                }else if(req.getFromToType().equals(ATransferConstants.P2A)){
                    //玩家转代理
                    P2ATransferReq p2ATransferReq = new P2ATransferReq();
                    BeanUtils.copyProperties(req, p2ATransferReq);
                    p2ATransferService.createP2ATrans(p2ATransferReq);
                }

                transferMessage.setStatus(1);
                transferHandler.updateByMsgId(transferMessage);

                log.info("Transfer successfully!");

            } catch (Exception e) {
                log.info("Handle transfer service error", e);
                e.printStackTrace();
                transferMessage.setStatus(2);
                transferHandler.updateByMsgId(transferMessage);
                log.error(e.getLocalizedMessage(), e);
            }
        } else {
            log.error("Rabbit消息, 接收创建存款交易记录失败！");
        }
    }
}