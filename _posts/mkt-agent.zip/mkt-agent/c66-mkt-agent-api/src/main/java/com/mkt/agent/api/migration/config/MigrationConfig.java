package com.mkt.agent.api.migration.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @Description: 数据
 * @Author: PTMinnisLi
 * @Date: 2023/6/30
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Component
@RefreshScope
public class MigrationConfig {

    /**
     * 是否开启migration功能
     */
    @Value("${mkt.agent.migration.isOpen:0}")
    private Boolean isOpen;

    /**
     * 获取数据的分页配置
     */
    @Value("${mkt.agent.migration.access.pageIndex:500}")
    private Integer pageIndex;

    /**
     * 获取数据的数据源配置
     */
    @Value("${mkt.agent.migration.access.baseUrl:127.0.0.1}")
    private String baseUrl;


    @Value("${mkt.agent.migration.access.insertPageIndex:1000}")
    private Integer insertPageIndex;


    @Value("${mkt.agent.migration.generalContract}")
    private String generalContract;


    @Value("${mkt.agent.migration.professionalContract}")
    private String professionalContract;


}
