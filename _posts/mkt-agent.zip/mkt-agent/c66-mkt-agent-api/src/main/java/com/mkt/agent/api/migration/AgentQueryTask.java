package com.mkt.agent.api.migration;

import com.alibaba.fastjson.JSONObject;
import com.mkt.agent.api.exception.MKTAgentException;
import com.mkt.agent.api.migration.entity.AgentCustomers;
import com.mkt.agent.common.entity.PageReq;
import com.mkt.agent.integration.utils.HttpClientUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Callable;

@Slf4j
public class AgentQueryTask implements Callable<List<AgentCustomers>> {

    private final PageReq pageReq;

    private final String baseUrl;

    public AgentQueryTask(PageReq pageReq, String baseUrl) {
        this.pageReq = pageReq;
        this.baseUrl = baseUrl;
    }

    public List<AgentCustomers> call() {

        log.info("代理系统分页查询接口子任务[{}]开始", pageReq.getPageNum());

        // 创建分页请求
        HashMap<String, String> pageRequest = new HashMap<>();
        pageRequest.put("productId", "C66");
        pageRequest.put("loginFlag", "1");
        pageRequest.put("pageNum", pageReq.getPageNum().toString());
        pageRequest.put("pageSize", pageReq.getPageSize().toString());

        // 请求老代理系统接口
        String response = null;
        try {
            response = HttpClientUtil.postJson(baseUrl + "/webApi/queryAgentCustomersV2.do", JSONObject.toJSONString(pageRequest), 15 * 60 * 1000, 15 * 60 * 1000, 15 * 60 * 1000);
        } catch (Exception e) {
            log.error("访问 agent老代理系统分页查询接口[/webApi/queryAgentCustomersV2.do] 失败");
            throw new MKTAgentException("访问 agent老代理系统查询数量接口[/webApi/queryAgentCustomersV2.do] 失败，具体信息为: " + e.getMessage());
        }
        if (StringUtils.isEmpty(response)) {
            log.error("访问 agent老代理系统分页查询接口[/webApi/queryAgentCustomersV2.do] 响应为空");
            throw new MKTAgentException("访问 agent老代理系统查询数量接口[/webApi/queryAgentCustomersV2.do] 响应为空");
        }

        // 解析响应数据
        JSONObject jsonResponse = null;
        try {
            jsonResponse = JSONObject.parseObject(response);
        } catch (Exception e) {
            log.error("访问 agent老代理系统查询数量接口[/webApi/queryAgentCustomersV2.do] response解析失败，源数据为{}", response);
            throw new MKTAgentException("访问 agent老代理系统查询数量接口[/webApi/queryAgentCustomersV2.do] 失败，源数据为: " + response);
        }

        if (!Objects.isNull(jsonResponse.get("error"))) {
            log.error("访问 agent老代理系统查询数量接口[/webApi/queryAgentCustomersV2.do] 失败，具体信息为: {}", jsonResponse);
            throw new MKTAgentException("访问 agent老代理系统查询数量接口[/webApi/queryAgentCustomersV2.do] 失败，具体信息为: " + jsonResponse);
        }
        Object data = jsonResponse.get("data");
        if (Objects.isNull(data) || Objects.isNull(JSONObject.parseObject(data.toString()).get("content"))) {
            log.error("访问 agent老代理系统分页查询接口[/webApi/queryAgentCustomersV2.do] 分页数据为空, 具体信息为: {}", jsonResponse);
            throw new MKTAgentException("访问 agent老代理系统查询数量接口[/webApi/queryAgentCustomersV2.do] 分页数据为空，具体信息为: " + jsonResponse);
        }
        String pageContent = JSONObject.parseObject(data.toString()).get("content").toString();
        List<AgentCustomers> agentCustomers = JSONObject.parseArray(pageContent, AgentCustomers.class);
        log.info("代理系统分页查询接口子任务[{}]结束, 查询到的数量为 [{}] 条", pageReq.getPageNum(), CollectionUtils.isEmpty(agentCustomers) ? 0 : agentCustomers.size());
        return agentCustomers;
    }
}
