package com.mkt.agent.api.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.Version;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.entity.BaseEntity;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

/**
 * @ClassName TAgentWallet
 * @Description 佣金钱包
 * @Author TJSAlex
 * @Date 2023/5/23 15:35
 * @Version 1.0
 **/
@Data
@SuperBuilder
@NoArgsConstructor
@TableName
public class TAgentWallet extends BaseEntity {

    private String productId;
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long agentId;
    private String loginName;
    private BigDecimal balance;
    private String currency;
    private Integer isEnable;
    @Version
    private Integer version;
}
