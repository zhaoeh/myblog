package com.mkt.agent.api.mapper;


import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.TAgentMessageRecord;
import org.apache.ibatis.annotations.Mapper;

@Mapper
@TableName("message_record")
public interface MessageRecordMapper extends BaseMapper<TAgentMessageRecord> {
}

