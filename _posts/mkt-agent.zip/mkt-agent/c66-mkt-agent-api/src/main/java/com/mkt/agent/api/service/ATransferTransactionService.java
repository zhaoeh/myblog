package com.mkt.agent.api.service;

import com.mkt.agent.api.entity.TAgentFundRecord;
import com.mkt.agent.common.entity.api.atransferapi.P2ATransferEntity;
import com.mkt.agent.common.entity.api.atransferapi.request.A2ATransferReq;
import com.mkt.agent.common.entity.api.atransferapi.request.A2PTransferReq;
import com.mkt.agent.common.entity.api.atransferapi.request.P2ATransferReq;

/**
 * @Description 代理转账
 * @Classname ATransferTransactionService
 * @Date 2023/6/22 11:37
 * @Created by TJSLucian
 */
public interface ATransferTransactionService {

    void a2aTransferV1(A2ATransferReq req) throws Exception;

    void a2pTransfer(A2PTransferReq req) throws Exception;

    void createFundRecord(TAgentFundRecord record);

    boolean p2aTransferFirst(P2ATransferReq req) throws Exception;

    boolean p2aTransferSecondSucess(P2ATransferEntity entity,TAgentFundRecord fundRecord) throws Exception;

    boolean p2aTransferSecondFailure(P2ATransferEntity record,TAgentFundRecord fundRecord) throws Exception;

}
