package com.mkt.agent.api.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mkt.agent.common.entity.TAgentGlobalConfigEntity;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentGlobalConfigSaveRequest;

import java.util.List;

/**
 * @Description TODO
 * @Classname GlobalConfigService
 * @Date 2023/6/28 13:57
 * @Created by TJSLucian
 */
public interface GlobalConfigService  extends IService<TAgentGlobalConfigEntity> {

    List<TAgentGlobalConfigEntity> getValuesByName(List<String> names);

    boolean saveGlobalConfig(AgentGlobalConfigSaveRequest names);
}
