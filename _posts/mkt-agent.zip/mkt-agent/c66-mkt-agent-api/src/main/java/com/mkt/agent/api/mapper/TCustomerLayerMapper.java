package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.TCustomerLayer;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface TCustomerLayerMapper extends BaseMapper<TCustomerLayer> {
    public void updateBatch(@Param("list") List<TCustomerLayer> list);

    public String isAgent(@Param("loginName") String loginName);

    public List<String> uniqueNameList();
}
