package com.mkt.agent.api.service;

import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;

/**
 * @ClassName TDepositTransService
 * @Author TJSAlex
 * @Date 2023/6/28 14:58
 * @Version 1.0
 **/
public interface BaseFundService {
    void checkAgentRelationship(Long parentId, Long childId);

    TAgentCustomers getParentByLoginName(String loginName);
}