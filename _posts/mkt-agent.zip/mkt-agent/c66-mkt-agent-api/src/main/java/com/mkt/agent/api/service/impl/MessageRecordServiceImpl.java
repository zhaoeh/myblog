package com.mkt.agent.api.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mkt.agent.api.mapper.MessageRecordMapper;
import com.mkt.agent.api.service.MessageRecordService;
import com.mkt.agent.common.entity.TAgentMessageRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MessageRecordServiceImpl extends ServiceImpl<MessageRecordMapper,TAgentMessageRecord> implements MessageRecordService {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private MessageRecordMapper messageRecordMapper;



}
