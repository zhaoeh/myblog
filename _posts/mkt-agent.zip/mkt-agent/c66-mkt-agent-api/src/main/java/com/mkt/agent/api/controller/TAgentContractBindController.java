package com.mkt.agent.api.controller;

import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.entity.api.agentapi.requests.SubAgentContractBindReq;
import com.mkt.agent.api.service.TAgentContractBindService;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @ClassName TAgentContractBindController
 * @Description 代理佣金方案绑定
 * @Author TJSAustin
 * @Date 2023/5/23 10:00
 * @Version 1.0
 **/
@RestController
@RequestMapping("/agentContractBind")
@Validated
public class TAgentContractBindController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    TAgentContractBindService tAgentContractBindService;

    /**
     * @Description: 代理前端,我的代理模块,编辑下级代理佣金比例时,先查询出父代理的佣金比例
     * @Author: Austin
     * @Date: 2023/5/25
     */
    @GetMapping(value ="/queryPercentageDetails")
    @ApiOperation(value = "查询父代理佣金方案", notes = "查询父代理佣金方案")
    public Result<List<SettlementPercentageReq>> queryPercentageDetails(@NotNull(message = "currentCustomersId is not null") Long currentCustomersId) {
        try {
            List<SettlementPercentageReq> resp = tAgentContractBindService.queryPercentageDetails(currentCustomersId);
            logger.info("/agentContractBind/queryPercentageDetails 入参currentCustomersId：{} 返回值：{}", currentCustomersId, resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentContractBind/queryPercentageDetails 出异常了，入参currentCustomersId：{} 异常信息：{}", currentCustomersId, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    /**
     * @Description: 编辑下级代理佣金比例
     * @Author: Austin
     * @Date: 2023/5/25
     */
    @PostMapping(value ="/updateSubAgentContractBind")
    @ApiOperation(value = "编辑下级代理佣金比例", notes = "编辑下级代理佣金比例")
    public Result updateSubAgentContractBind(@RequestBody  @Validated(value = InputValidationGroup.Update.class) SubAgentContractBindReq subAgentContractBindReq) {
        try {
            logger.info("/agentContractBind/updateSubAgentContractBind 入参subAgentContractBindReq：{} 返回值：void", subAgentContractBindReq.toString());
            tAgentContractBindService.updateSubAgentContractBind(subAgentContractBindReq);
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/agentContractBind/updateSubAgentContractBind 出异常了，入参subAgentContractBindReq：{} 异常信息：{}",
                    subAgentContractBindReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping(value ="/queryContractBindByName")
    @ApiOperation(value = "查询佣金比例", notes = "查询佣金比例")
    public TAgentContractBind queryContractBindByName(@RequestParam("loginName") String loginName){
        return tAgentContractBindService.queryTAgentContractBindByLoginName(loginName);
    }

}
