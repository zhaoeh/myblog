package com.mkt.agent.api.service;

import com.mkt.agent.common.entity.api.atransferapi.A2ATransferEntity;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.atransferapi.request.A2ATransferListReq;
import com.mkt.agent.common.entity.api.atransferapi.request.A2ATransferReq;
import com.mkt.agent.integration.entities.PageModelExt;
import com.mkt.agent.integration.entities.Response;

/**
 * @Description TODO
 * @Classname A2ATransferService
 * @Date 2023/6/21 13:57
 * @Created by TJSLucian
 */
public interface A2ATransferService {

    Result<PageModelExt<A2ATransferEntity>> queryA2ATransList(A2ATransferListReq req);

    Result<Boolean> createA2ATrans(A2ATransferReq req) throws Exception;

}
