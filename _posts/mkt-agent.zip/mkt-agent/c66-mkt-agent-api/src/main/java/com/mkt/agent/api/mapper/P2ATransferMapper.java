package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.atransferapi.P2ATransferEntity;
import com.mkt.agent.common.entity.api.atransferapi.request.P2ATransferListReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @Description TODO
 * @Classname A2PTransferMapper
 * @Date 2023/6/22 13:38
 * @Created by TJSLucian
 */
@Mapper
public interface P2ATransferMapper extends BaseMapper<P2ATransferEntity> {


    Integer queryListCount(@Param("p2ATransferListReq") P2ATransferListReq p2ATransferListReq);

    List<P2ATransferEntity> queryList(@Param("p2ATransferListReq") P2ATransferListReq p2ATransferListReq);

    Map sumByCondition(@Param("p2ATransferListReq") P2ATransferListReq p2ATransferListReq);

    Integer updateVerifyItemByTId(@Param("entity") P2ATransferEntity entity);

}
