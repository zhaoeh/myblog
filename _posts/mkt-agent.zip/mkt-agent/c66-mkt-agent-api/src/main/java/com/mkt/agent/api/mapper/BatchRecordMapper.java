package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.dto.BatchAccountInfoDTO;
import com.mkt.agent.common.entity.BatchRecord;
import com.mkt.agent.common.entity.BatchRecordExample;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface BatchRecordMapper extends BaseMapper<BatchRecord> {
    long countByExample(BatchRecordExample example);

    int deleteByExample(BatchRecordExample example);

    int deleteByPrimaryKey(Long id);

    int insert(BatchRecord row);

    int insertSelective(BatchRecord row);

    List<BatchAccountInfoDTO> queryBatchAccountsByBatchId(Long id);

    List<BatchRecord> selectByExample(BatchRecordExample example);

    BatchRecord selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("row") BatchRecord row, @Param("example") BatchRecordExample example);

    int updateByExample(@Param("row") BatchRecord row, @Param("example") BatchRecordExample example);

    int updateByPrimaryKeySelective(BatchRecord row);

    int updateByPrimaryKey(BatchRecord row);

    String findLastAccount(String prefix);
}