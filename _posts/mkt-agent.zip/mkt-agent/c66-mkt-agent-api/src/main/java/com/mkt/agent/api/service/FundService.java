package com.mkt.agent.api.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.api.entity.TAgentFundRecord;
import com.mkt.agent.api.entity.req.*;
import com.mkt.agent.api.entity.resp.FundBalanceResp;
import com.mkt.agent.common.entity.SumPageResponse;
import com.mkt.agent.common.entity.api.fund.resp.FundRecordResp;
import com.mkt.agent.common.enums.FundStatusEnum;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @ClassName FundService
 * @Author TJSAlex
 * @Date 2023/5/18 16:47
 * @Version 1.0
 **/
public interface FundService {
    SumPageResponse<FundRecordResp> list(FundRecordReq req);

    void export(FundRecordReq req, HttpServletResponse response) throws IOException;

    FundBalanceResp getBalance(FundAgentReq req);

    boolean transfer(FundTransferReq req);

    boolean deposit(FundTradeReq req);

    /**
     * 接收转账总额
     * @param loginName
     * @param beginTime
     * @return
     */
    BigDecimal receiveAmount(String loginName, Date beginTime);

    TAgentFundRecord withdrawal(FundTradeReq req, String reqId);

    Boolean updateWithdrawState(FundTradeReq req);

    Boolean addAgentWallet(FundAgentReq req);

    Boolean modifyAmount(FundModifyReq req);

    void saveFundRecord(FundTransferReq req, Integer status, Integer interactionPerson, Integer isCommission);

    /**
     * 保存 存款账变数据
     * @param entity entity
     * @param statusEnum 账变状态枚举
     */
    void saveDepositLog(FundTradeReq entity, FundStatusEnum statusEnum);
}
