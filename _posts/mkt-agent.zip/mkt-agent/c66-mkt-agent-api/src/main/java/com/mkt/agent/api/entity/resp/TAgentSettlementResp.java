package com.mkt.agent.api.entity.resp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @ClassName CommissionPlanResp
 * @Description 佣金方案
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Data
public class TAgentSettlementResp implements Serializable {

    /*
        AGENT_ID
    */
    @ApiModelProperty(value = "AGENT_ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long agentId;

    /*
        佣金方案类型
    */
    @ApiModelProperty(value = "LOGIN_NAME")
    private String loginName;


    /*
        创建人(父代理)
    */
    @ApiModelProperty(value = "CREATED_BY")
    private String createdBy;

    /*
        佣金方案id
    */
    @ApiModelProperty(value = "CREATED_BY")
    private String contractId;

    /*
        佣金方案名称
    */
    @ApiModelProperty(value = "COMMISSION_PLAN_NAME")
    private String commissionPlanName;

    /*
        佣金方案类型
        0:turnover, 1:GGR
   */
    @ApiModelProperty(value = "COMMISSION_PLAN_TYPE")
    private String commissionPlanType;

    /*
        结算周期
    */
    @ApiModelProperty(value = "settlement_period")
    private String settlementPeriod;

    /*
        代理类型
    */
    @ApiModelProperty(value = "AGENT_TYPE")
    private String agentType;

    /*
       代理层级
    */
    @ApiModelProperty(value = "AGENT_LEVEL")
    private Integer agentLevel;

    /*
       结算条件
    */
    @ApiModelProperty(value = "SETTLEMENT_CONDITIONS")
    private String settlementConditions;


    /*
       活跃投注
    */
    @ApiModelProperty(value = "ACTIVE_USER_TURNOVER")
    private String activeUserTurnover;


    /*
       结算条件
    */
    @ApiModelProperty(value = "ACTIVE_USER_HEADCOUNT")
    private String activeUserHeadcount;

    /*
        结算类型
    */
    @ApiModelProperty(value = "commission_values")
    private String commissionValues;

    /*
        代理佣金绑定id
    */
    @ApiModelProperty(value = "contractBindId")
    private String contractBindId;


    /*
         佣金比例文本
     */
    @ApiModelProperty(value = "percentage_details")
    private String percentageDetails;


    /*
         佣金比例集合
     */
    @ApiModelProperty(value = "佣金比例集合")
    private List<SettlementPercentageReq> settlementPercentageReq;




}
