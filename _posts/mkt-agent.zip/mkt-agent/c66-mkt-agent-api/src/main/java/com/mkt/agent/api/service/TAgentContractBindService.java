package com.mkt.agent.api.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mkt.agent.api.entity.req.TAgentCustomersBuildReq;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.entity.api.agentapi.requests.SubAgentContractBindReq;

import java.util.List;

public interface TAgentContractBindService extends IService<TAgentContractBind> {

    public TAgentContract queryTAgentContractByBindId(Long bindId);

    public Integer updateBatchPercentageByBindId(TAgentContractBind initBind);

    public List<TAgentContractBind>  queryAllTopAgentContractBindByContractId(Long contractId);

    public List<SettlementPercentageReq> queryPercentageDetails(Long currentAgentId);

    TAgentContractBind queryTAgentContractBindByLoginName(String loginName);

    public void updateSubAgentContractBind(SubAgentContractBindReq subAgentContractBindReq);

    public void percentageDetailsAllow(List<SettlementPercentageReq> settlementPercentageReqList, List<SettlementPercentageReq> currentPercentageReqList);

    public void updateBatchPercentageByBindIds(TAgentCustomersBuildReq tAgentCustomersBuildReq);

    public void checkPercentage(List<SettlementPercentageReq> currentPercentageReqList);
}
