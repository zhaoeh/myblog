package com.mkt.agent.api.service;

import com.mkt.agent.common.entity.api.atransferapi.A2PTransferEntity;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.atransferapi.request.A2PTransferListReq;
import com.mkt.agent.common.entity.api.atransferapi.request.A2PTransferReq;
import com.mkt.agent.integration.entities.PageModelExt;

/**
 * @Description TODO
 * @Classname A2ATransferService
 * @Date 2023/6/21 13:57
 * @Created by TJSLucian
 */
public interface A2PTransferService {

    Result<PageModelExt<A2PTransferEntity>> queryA2PTransList(A2PTransferListReq req);

    Result<Boolean> createA2PTrans(A2PTransferReq req) throws Exception;
}
