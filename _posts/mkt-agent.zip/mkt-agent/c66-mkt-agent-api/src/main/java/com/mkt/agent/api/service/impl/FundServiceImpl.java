package com.mkt.agent.api.service.impl;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mkt.agent.api.entity.TAgentDepositTrans;
import com.mkt.agent.api.entity.TAgentFundRecord;
import com.mkt.agent.api.entity.TAgentWallet;
import com.mkt.agent.api.entity.req.*;
import com.mkt.agent.api.entity.resp.FundBalanceResp;
import com.mkt.agent.api.enums.DepositTransEnum;
import com.mkt.agent.api.mapper.DepositTransMapper;
import com.mkt.agent.api.mapper.FundRecordMapper;
import com.mkt.agent.api.mapper.FundWalletMapper;
import com.mkt.agent.api.service.FundService;
import com.mkt.agent.api.service.TransactionService;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.constants.DefaultAgentConstant;
import com.mkt.agent.common.entity.SumPageResponse;
import com.mkt.agent.common.entity.TByteHouseData;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordApproveResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.sum.CommissionRecordApproveSumResponse;
import com.mkt.agent.common.entity.api.fund.resp.FundRecordResp;
import com.mkt.agent.common.enums.*;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.ExcelUtil;
import com.mkt.agent.common.utils.RedisUtil;
import com.mkt.agent.common.utils.TransIdGenerator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;

/**
 * @ClassName FundServiceImpl
 * @Author TJSAlex
 * @Date 2023/5/18 16:47
 * @Version 1.0
 **/
@Service
@Slf4j
public class FundServiceImpl extends BaseFundServiceImpl implements FundService {

    @Resource
    private FundRecordMapper fundRecordMapper;
    @Resource
    private FundWalletMapper fundWalletMapper;
    @Autowired
    private TransactionService transactionService;
    @Resource
    private DepositTransMapper depositTransMapper;


    @Override
    public SumPageResponse<FundRecordResp> list(FundRecordReq req) {
        SumPageResponse<FundRecordResp> sumPageResponse = new SumPageResponse<>();
        Integer fundType = FundTypeEnum.getCodeByName(req.getFundType());
        Integer fundStatus = FundStatusEnum.getCodeByName(req.getStatus());
        Integer customerType = CustomerTypeEnum.getValueByDesc(req.getInteractionPerson());
        Map<String, BigDecimal> amountReq = buildAmountReq(req);
        Integer total;
        if(Objects.isNull(amountReq)){
            total = 0;
        }else{
            total = fundRecordMapper.count(req, fundType, fundStatus, customerType, amountReq);
        }

        if (Objects.isNull(total) || total == 0) {
            sumPageResponse.setTotal(total);
            sumPageResponse.setCurrent(req.getPageNum());
            sumPageResponse.setSize(req.getPageSize());
            return sumPageResponse;
        }
        List<FundRecordResp> list = fundRecordMapper.list(req, fundType, fundStatus, customerType, true, amountReq);
        transferProperties(list);
        sumPageResponse.setRecords(list);
        sumPageResponse.setTotal(total);
        sumPageResponse.setCurrent(req.getPageNum());
        sumPageResponse.setSize(req.getPageSize());
        sumPageResponse.setPages(total / req.getPageSize());

        Map<String, BigDecimal> pageSumMap = sumPageResponse.getPageSumMap();
        // 当前页汇总数据
        for (FundRecordResp fundRecordResp : list) {
            if (Objects.isNull(pageSumMap.get(BaseConstants.FundRecordAmount))) {
                pageSumMap.put(BaseConstants.FundRecordAmount, new BigDecimal(0));
            }
            pageSumMap.put(BaseConstants.FundRecordAmount, pageSumMap.get(BaseConstants.FundRecordAmount).add(new BigDecimal(fundRecordResp.getAmount())));
        }
        log.info("Fund Record当前页汇总数据：FundRecordAmount：{}", pageSumMap.get(BaseConstants.FundRecordAmount));
        // 所有汇总数据
        Map<String, BigDecimal> searchSumMap = sumPageResponse.getSearchSumMap();
        List<FundRecordResp> listSum = fundRecordMapper.list(req, fundType, fundStatus, customerType, false, amountReq);
        for (FundRecordResp fundRecordResp : listSum) {
            if (Objects.isNull(searchSumMap.get(BaseConstants.FundRecordAmountSum))) {
                searchSumMap.put(BaseConstants.FundRecordAmountSum, new BigDecimal(0));
            }
            searchSumMap.put(BaseConstants.FundRecordAmountSum, searchSumMap.get(BaseConstants.FundRecordAmountSum).add(new BigDecimal(fundRecordResp.getAmount())));
        }
        log.info("Fund Record所有汇总数据：FundRecordAmountSum：{}", searchSumMap.get(BaseConstants.FundRecordAmountSum));

        log.info("开始缓存----");
        new Thread(()->{

            //
            FundRecordReq  temp   =  req;
            temp.setPageNum(-1);
            temp.setPageSize(-1);
            temp.setIsPage(false);
            String  key   =    getKey(temp);

            log.info("key数据={}",key);



            String totalCache =  (String)redisUtil.get(key+"_total1");

            int  total2   =   total;

            if (StringUtils.isBlank(totalCache) ||  (!StringUtils.isBlank(totalCache)     &&  Integer.valueOf(totalCache) !=  total2 )){
                //设置
                Integer fundType2 = FundTypeEnum.getCodeByName(temp.getFundType());
                Integer fundStatus2 = FundStatusEnum.getCodeByName(temp.getStatus());
                Integer customerType2 = CustomerTypeEnum.getValueByDesc(temp.getInteractionPerson());


                List<FundRecordResp> list2 = fundRecordMapper.list(temp, fundType2, fundStatus2, customerType2, false, amountReq);
                transferProperties(list2);

                redisUtil.set(key+"_total1",list2.size());

                 redisUtil.set(key,new Gson().toJson(list2));

            }


        }).start();
        return sumPageResponse;
    }

    private Map<String, BigDecimal> buildAmountReq(FundRecordReq req) {
        Map<String, BigDecimal> amountReq = new HashMap<>();
        BigDecimal min = req.getMinAmount();
        BigDecimal max = req.getMaxAmount();

        if (Objects.isNull(min)) {
            if (Objects.isNull(max)) {
                return amountReq;
            } else if (max.compareTo(BigDecimal.ZERO) > 0) {
                amountReq.put("incomeMax", max);
                return amountReq;
            } else if (max.compareTo(BigDecimal.ZERO) < 0) {
                amountReq.put("outcomeMin", BigDecimal.valueOf(Math.abs(max.doubleValue())));
                amountReq.put("comeType", BigDecimal.ZERO);
                return amountReq;
            } else {
                amountReq.put("incomeMax", max);
                amountReq.put("comeType", BigDecimal.ONE);
                return amountReq;
            }
        } else if (min.compareTo(BigDecimal.ZERO) > 0) {
            if (Objects.isNull(max)) {
                amountReq.put("incomeMin", min);
                amountReq.put("comeType", BigDecimal.ONE);
                return amountReq;
            } else if (max.compareTo(BigDecimal.ZERO) > 0) {
                amountReq.put("incomeMin", min);
                amountReq.put("incomeMax", max);
                amountReq.put("comeType", BigDecimal.ONE);
                return amountReq;
            } else if (max.compareTo(BigDecimal.ZERO) < 0) {
                return null;
            } else {
                return null;
            }
        } else if (min.compareTo(BigDecimal.ZERO) < 0) {
            if (Objects.isNull(max)) {
                amountReq.put("outcomeMax", BigDecimal.valueOf(Math.abs(min.doubleValue())));
                return amountReq;
            } else if (max.compareTo(BigDecimal.ZERO) > 0) {
                amountReq.put("incomeMax", max);
                amountReq.put("outcomeMax", BigDecimal.valueOf(Math.abs(min.doubleValue())));
                return amountReq;
            } else if (max.compareTo(BigDecimal.ZERO) < 0) {
                if (min.compareTo(max) > 0) {
                    return null;
                }
                amountReq.put("outcomeMin", BigDecimal.valueOf(Math.abs(max.doubleValue())));
                amountReq.put("outcomeMax", BigDecimal.valueOf(Math.abs(min.doubleValue())));
                amountReq.put("comeType", BigDecimal.ZERO);
                return amountReq;
            } else {
                amountReq.put("incomeMax", max);
                amountReq.put("outcomeMax", BigDecimal.valueOf(Math.abs(min.doubleValue())));
                amountReq.put("comeType", BigDecimal.ZERO);
                return amountReq;
            }
        } else {
            if (Objects.isNull(max)) {
                amountReq.put("incomeMin", min);
                amountReq.put("comeType", BigDecimal.ONE);
                return amountReq;
            } else if (max.compareTo(BigDecimal.ZERO) > 0) {
                amountReq.put("incomeMin", min);
                amountReq.put("incomeMax", max);
                amountReq.put("comeType", BigDecimal.ONE);
                return amountReq;
            } else if (max.compareTo(BigDecimal.ZERO) < 0) {
                return null;
            } else {
                amountReq.put("incomeMin", min);
                amountReq.put("incomeMax", max);
                amountReq.put("comeType", BigDecimal.ONE);
                return amountReq;
            }
        }
    }

    private String getKey(FundRecordReq temp) {
        StringBuffer key =   new StringBuffer();

        if (!StringUtils.isBlank(temp.getAccount())){
            key.append(temp.getAccount());
        }
        if (!StringUtils.isBlank(temp.getFundType())){
            key.append(temp.getFundType());
        }
        if (!StringUtils.isBlank(temp.getInteractionPerson())){
            key.append(temp.getInteractionPerson());
        }
        if (!StringUtils.isBlank(temp.getToAccount())){
            key.append(temp.getToAccount());
        }
        if (!StringUtils.isBlank(temp.getFromAccount())){
            key.append(temp.getFromAccount());
        }
        if (!StringUtils.isBlank(temp.getStatus())){
            key.append(temp.getStatus());
        }
        if (temp.getMinAmount()!=null  ){
            key.append(temp.getMinAmount());
        }
        if (temp.getMaxAmount()!=null  ){
            key.append(temp.getMaxAmount());
        }
        if (!StringUtils.isBlank(temp.getStartTime())){
            key.append(temp.getStartTime());
        }
        if (!StringUtils.isBlank(temp.getEndTime())){
            key.append(temp.getEndTime());
        }
        if (!StringUtils.isBlank(temp.getTransactionId())){
            key.append(temp.getTransactionId());
        }

        if(StringUtils.isBlank(key.toString())) {
            key.append("report"  +  DateUtils.dateToString(new Date()));
        }
        return  key.toString();
    }

    @Override
    public void export(FundRecordReq req, HttpServletResponse response) throws IOException {




        // 导出全部数据
        req.setIsPage(false);
        req.setPageNum(-1);
        req.setPageSize(-1);
        String  key   =   getKey(req);

        log.info("key数据={}",key);

        String json   = (String) redisUtil.get(key);
        List<FundRecordResp> list=new ArrayList<>() ;

        if(StringUtils.isBlank(json)) {

            Integer fundType = FundTypeEnum.getCodeByName(req.getFundType());
            Integer fundStatus = FundStatusEnum.getCodeByName(req.getStatus());
            Integer customerType = CustomerTypeEnum.getValueByDesc(req.getInteractionPerson());

            Map<String, BigDecimal> amountReq = buildAmountReq(req);
            if(Objects.nonNull(amountReq)){
                list = fundRecordMapper.list(req, fundType, fundStatus, customerType, false, amountReq);
            }
        }else {
            list  =  new Gson().fromJson(json, new TypeToken<List<FundRecordResp>>() {}.getType());


            log.info("走缓存去");
        }
       // ExcelUtil.export(list, FundRecordResp.class, "fundList", response);
//        EasyExcel.write("test.xlsx", FundRecordResp.class).sheet("模板").doWrite(list);

        String fileName = "filename"  + ".xlsx";
        response.setHeader("Content-Disposition", "attachment; filename=" + new String(fileName.getBytes("gb2312"), "ISO8859-1"));

        ExcelWriter excelWriter = EasyExcel.write(response.getOutputStream(), FundRecordResp.class).build();
        // 调用上一步构建数据的方法
        excelWriter.write(list, EasyExcel.writerSheet("sheet1").build());
        excelWriter.finish();

        log.info("---导出完成");


    }

    @Autowired
    private RedisUtil redisUtil;

    @Override
    public FundBalanceResp getBalance(FundAgentReq req) {
        TAgentWallet wallet = fundWalletMapper.selectOne(new LambdaQueryWrapper<TAgentWallet>()
                .eq(TAgentWallet::getAgentId, req.getAgentId())
                .eq(TAgentWallet::getLoginName, req.getLoginName())
                .eq(TAgentWallet::getIsEnable, 1));
        if (Objects.isNull(wallet)) {
            throw new BusinessException("该agentId不存在");
        }
        return FundBalanceResp.builder().agentId(wallet.getAgentId())
                .loginName(wallet.getLoginName())
                .balance(wallet.getBalance()).build();
    }

    @Override
    public boolean transfer(FundTransferReq req) {
        log.info("transfer param:{}",req);
        boolean success = transactionService.transfer(req.getFromId(), req.getToId(), req.getAmount());
        Integer status = success ? FundStatusEnum.Success.getCode() : FundStatusEnum.Failure.getCode();
        saveFundRecord(req, status,CustomerTypeEnum.AGENT.getValue(),Constants.ISCOMMISSION);
        return success;
    }

    @Override
    @org.springframework.transaction.annotation.Transactional(rollbackFor = Exception.class)
    public boolean deposit(FundTradeReq req) {
        // checkAgentRelationship(DefaultAgentConstant.DEFAULT_AGENT_ID, req.getAgentId());
        TAgentDepositTrans depositTrans = checkRefId(req);
        TAgentWallet wallet = checkWallet(req);
        BigDecimal amount = wallet.getBalance().add(depositTrans.getAmount());
        wallet.setBalance(amount);
        int i = fundWalletMapper.updateById(wallet);
        boolean success = i > 0;

        // String transId = TransIdGenerator.singleGenRequestId(Constants.C66, Constants.REQUEST_TYPE_DEPOSIT);
        // TAgentFundRecord record = TAgentFundRecord.builder().agentId(req.getAgentId()).account(req.getLoginName())
        //         .isIncome(FundTypeEnum.Deposit.getIsIncome()).fundType(FundTypeEnum.Deposit.getCode())
        //         .fromId(DefaultAgentConstant.DEFAULT_AGENT_ID).fromAccount(DefaultAgentConstant.DEFAULT_LOGIN_NAME)
        //         .toId(req.getAgentId()).toAccount(req.getLoginName())
        //         .amount(req.getAmount()).status(success ? FundStatusEnum.Success.getCode() : FundStatusEnum.Failure.getCode())
        //         .transactionId(transId).orderId(req.getOrderId()).interactionPerson(CustomerTypeEnum.SYSTEM.getValue()).build();
        // fundRecordMapper.insert(record);
        if(success){
            LambdaUpdateWrapper<TAgentFundRecord> upWrapper = new LambdaUpdateWrapper<>();
            upWrapper.eq(TAgentFundRecord::getOrderId,req.getOrderId());
            upWrapper.set(TAgentFundRecord::getUpdateTime,new Date());
            upWrapper.set(TAgentFundRecord::getStatus,FundStatusEnum.Success.getCode());
            int update = fundRecordMapper.update(null, upWrapper);
            if(1 != update){
                log.error("存款更新账变记录失败 ~ 单号 {} ",req.getOrderId());
            }
        }
        return success;
    }

    private TAgentDepositTrans checkRefId(FundTradeReq req) {
        TAgentDepositTrans depositTrans = depositTransMapper.selectOne(new LambdaQueryWrapper<TAgentDepositTrans>()
                .eq(TAgentDepositTrans::getCustomerId, req.getAgentId()).eq(TAgentDepositTrans::getLoginName, req.getLoginName())
                .eq(TAgentDepositTrans::getReferenceId, req.getOrderId()).eq(TAgentDepositTrans::getStatus, DepositTransEnum.Pending.getCode())
                .eq(TAgentDepositTrans::getDeleteFlag, 0));
        if(Objects.isNull(depositTrans)) {
            throw new BusinessException("该订单号不存在");
        }
        return depositTrans;
    }

    private TAgentWallet checkWallet(FundTradeReq req) {
        TAgentWallet wallet = fundWalletMapper.selectOne(new LambdaQueryWrapper<TAgentWallet>().eq(TAgentWallet::getAgentId, req.getAgentId())
                .eq(TAgentWallet::getLoginName, req.getLoginName())
                .eq(TAgentWallet::getIsEnable, 1));
        if (Objects.isNull(wallet)) {
            throw new BusinessException("deposit account does not exist!");
        }
        return wallet;
    }

    @Override
    @Transactional(rollbackOn = Throwable.class)
    public TAgentFundRecord withdrawal(FundTradeReq req,String reqId) {
        TAgentWallet wallet = checkWallet(req);
        checkWalletBalance(wallet.getBalance(),req.getAmount());
        BigDecimal amount = wallet.getBalance().subtract(req.getAmount());
        wallet.setBalance(amount);
        boolean success = fundWalletMapper.updateById(wallet) > 0;
        if(!success){
            throw new BusinessException(ResultEnum.ERROR_WITHDRAW_FAILED);
        }

//         String transId = TransIdGenerator.singleGenRequestId(Constants.C66, Constants.REQUEST_TYPE_WITHDRAWAL);
//        String orderId = TransIdGenerator.singleGenRequestId(Constants.C66, Constants.REQUEST_TYPE_WITHDRAWAL);
        String orderId = TransIdGenerator.getSingleId(Constants.C66);
        TAgentFundRecord record = TAgentFundRecord
                .builder()
                .agentId(req.getAgentId())
                .account(req.getLoginName())
                .isIncome(FundTypeEnum.Withdrawal.getIsIncome()).fundType(FundTypeEnum.Withdrawal.getCode())
                .fromId(DefaultAgentConstant.DEFAULT_AGENT_ID).fromAccount(DefaultAgentConstant.DEFAULT_LOGIN_NAME)
                .toId(req.getAgentId()).toAccount(req.getLoginName())
                .amount(req.getAmount()).status( FundStatusEnum.Pending.getCode())
                .transactionId(reqId)
                .orderId(orderId)
                .interactionPerson(CustomerTypeEnum.SYSTEM.getValue()).build();
        fundRecordMapper.insert(record);
        return record;
    }


    @Override
    public BigDecimal receiveAmount(String loginName, Date beginTime){
        BigDecimal bigDecimal = fundRecordMapper.countAmountByType(loginName, FundTypeEnum.Received.getCode(), beginTime);
        if(bigDecimal == null){
            return BigDecimal.ZERO;
        }
        return bigDecimal;
    }

    @Override
    public Boolean updateWithdrawState(FundTradeReq req) {
        TAgentFundRecord record = fundRecordMapper.selectLastOneByType(req.getLoginName(), FundTypeEnum.Withdrawal.getCode());

        if (record == null) {
            throw new BusinessException(ResultEnum.ERROR_WITHDRAW_NOT_EXISTS);
        }
        if (!FundStatusEnum.Pending.getCode().equals(record.getStatus())) {
            log.warn("fundRecord id:{} status:{} just ignore ", record.getId(), record.getStatus());
            return false;
        }
        req.setAgentId(record.getAgentId());
        Integer status=null;
        // 所有对用户操作操作应该加锁
        if (!req.getIsApprove() && Objects.equals(record.getStatus(), FundStatusEnum.Pending.getCode())) {
            TAgentWallet wallet = checkWallet(req);
            wallet.setBalance(wallet.getBalance().add(record.getAmount()));
            fundWalletMapper.updateById(wallet);
            status=FundStatusEnum.Failure.getCode();
        }else{
            status = FundStatusEnum.Success.getCode();
        }

        TAgentFundRecord updateRecord = TAgentFundRecord.builder()
                .id(record.getId())
                .status(status)
                .updateTime(DateUtils.getCurrentDateTime()).build();

        return  fundRecordMapper.updateById(updateRecord) > 0;

    }

    @Override
    @org.springframework.transaction.annotation.Transactional(rollbackFor = Exception.class)
    public Boolean addAgentWallet(FundAgentReq req) {
        TAgentWallet wallet = TAgentWallet.builder().agentId(req.getAgentId())
                .loginName(req.getLoginName()).productId(StringUtils.isNotBlank(req.getProductId()) ? req.getProductId() : Constants.C66)
                .build();
        int insert = fundWalletMapper.insert(wallet);
        return insert > 0;
    }

    @Override
    public Boolean modifyAmount(FundModifyReq req) {
        FundTradeReq tradeReq = new FundTradeReq();
        tradeReq.setAgentId(req.getAgentId());
        tradeReq.setLoginName(req.getLoginName());
        tradeReq.setAmount(req.getAmount());
        TAgentWallet wallet = checkWallet(tradeReq);
        BigDecimal res;
        if (req.getType()) {
            res= wallet.getBalance().subtract(req.getAmount());
        }else {
            res = wallet.getBalance().add(req.getAmount());
        }
        wallet.setBalance(res);
        int success = fundWalletMapper.updateById(wallet);
        return success>0;
    }

    private TAgentFundRecord checkFundRecord(FundApproveReq req) {
        TAgentFundRecord record = fundRecordMapper.selectOne(new LambdaQueryWrapper<TAgentFundRecord>().eq(TAgentFundRecord::getAgentId, req.getAgentId())
                .eq(TAgentFundRecord::getAccount, req.getLoginName()).eq(TAgentFundRecord::getTransactionId, req.getTransactionId())
                .eq(TAgentFundRecord::getStatus, FundStatusEnum.Pending.getCode())
                .eq(TAgentFundRecord::getIsIncome, IncomeEnum.OUT.code).eq(TAgentFundRecord::getIsDeleted, 0));
        if (Objects.isNull(record)) {
            throw new BusinessException("审批订单信息不正确");
        }
        return record;
    }

    @Override
    public void saveFundRecord(FundTransferReq req, Integer status,Integer interactionPerson,Integer isCommission) {

        TAgentFundRecord record;
        if (req.getFromId() == DefaultAgentConstant.DEFAULT_AGENT_ID) {
            int isIncome = FundTypeEnum.ReceivedCommission.getIsIncome();
            int fundType = FundTypeEnum.ReceivedCommission.getCode();
//            String transId = TransIdGenerator.singleGenRequestId(Constants.C66, Constants.REQUEST_TYPE_DEPOSIT);
//            String orderId = TransIdGenerator.singleGenRequestId(Constants.C66, Constants.REQUEST_TYPE_TRANSFER);
            String transId = TransIdGenerator.getSingleId(Constants.C66);
            String orderId = TransIdGenerator.getSingleId(Constants.C66);
            record = TAgentFundRecord.builder().agentId(req.getToId()).account(req.getToAccount())
                    .toId(req.getToId()).toAccount(req.getToAccount()).fromId(req.getFromId())
                    .fromAccount(req.getFromAccount()).transactionId(transId).fundType(fundType).isIncome(isIncome).status(status)
                    .status(status).amount(req.getAmount()).orderId(orderId).interactionPerson(CustomerTypeEnum.SYSTEM.getValue()).build();
            fundRecordMapper.insert(record);
            return;
        }

        //默认设置为转账
        int isIncomeFrom = FundTypeEnum.Transfer.getIsIncome();
        int fundTypeFrom = FundTypeEnum.Transfer.getCode();
        int isIncomeTo = FundTypeEnum.Received.getIsIncome();
        int fundTypeTo = FundTypeEnum.Received.getCode();

        //如果是发放佣金
        if(isCommission.equals(Constants.ISCOMMISSION)){
            isIncomeFrom = FundTypeEnum.PaidCommission.getIsIncome();
            fundTypeFrom = FundTypeEnum.PaidCommission.getCode();

            isIncomeTo = FundTypeEnum.ReceivedCommission.getIsIncome();
            fundTypeTo = FundTypeEnum.ReceivedCommission.getCode();
        }

//        String transId = TransIdGenerator.singleGenRequestId(Constants.C66, Constants.REQUEST_TYPE_WITHDRAWAL);
//        String orderId = TransIdGenerator.singleGenRequestId(Constants.C66, Constants.REQUEST_TYPE_TRANSFER);

        String transId = TransIdGenerator.getSingleId(Constants.C66);
        String orderId = TransIdGenerator.getSingleId(Constants.C66);

        record = TAgentFundRecord.builder().agentId(req.getFromId()).account(req.getFromAccount())
                .toId(req.getToId()).toAccount(req.getToAccount()).fromId(req.getFromId())
                .fromAccount(req.getFromAccount()).transactionId(transId).fundType(fundTypeFrom).isIncome(isIncomeFrom).status(status)
                .status(status).amount(req.getAmount()).orderId(orderId).interactionPerson(interactionPerson).build();
        fundRecordMapper.insert(record);

//        transId = TransIdGenerator.singleGenRequestId(Constants.C66, Constants.REQUEST_TYPE_DEPOSIT);
        transId = TransIdGenerator.getSingleId(Constants.C66);

        record = TAgentFundRecord.builder().agentId(req.getToId()).account(req.getToAccount())
                .toId(req.getToId()).toAccount(req.getToAccount()).fromId(req.getFromId())
                .fromAccount(req.getFromAccount()).transactionId(transId).fundType(fundTypeTo).isIncome(isIncomeTo).status(status)
                .status(status).amount(req.getAmount()).orderId(orderId).interactionPerson(interactionPerson).build();
        fundRecordMapper.insert(record);
    }

    private void checkWalletBalance(BigDecimal balance,BigDecimal amount) {
        if (balance.compareTo(amount) < 0) {
            throw new BusinessException("balance is not enough");
        }
    }
    private void transferProperties(List<FundRecordResp> list){
        list.stream().forEach(r->{
            Integer fundType = r.getType();
            r.setStatus(FundStatusEnum.getNameByCode(r.getFundStatus()));
            r.setAmount(FundTypeEnum.setAmount(r.getAmount(),fundType));
            r.setFundType(FundTypeEnum.getNameByCode(fundType));

        });
    }

    @Override
    @org.springframework.transaction.annotation.Transactional(rollbackFor = Exception.class)
    public void saveDepositLog(FundTradeReq entity,FundStatusEnum statusEnum) {

//        String transId = TransIdGenerator.singleGenRequestId(Constants.C66, Constants.REQUEST_TYPE_DEPOSIT);
        String transId = TransIdGenerator.getSingleId(Constants.C66);
        TAgentFundRecord record = TAgentFundRecord.builder()
                .agentId(entity.getAgentId())
                .toId(entity.getAgentId())
                .toAccount(entity.getLoginName())
                .account(entity.getLoginName())
                .amount(entity.getAmount())
                .orderId(entity.getOrderId())

                .status(statusEnum.getCode())
                // other
                .transactionId(transId)
                .isIncome(FundTypeEnum.Deposit.getIsIncome())
                .fundType(FundTypeEnum.Deposit.getCode())
                .fromId(DefaultAgentConstant.DEFAULT_AGENT_ID)
                .fromAccount(DefaultAgentConstant.DEFAULT_LOGIN_NAME)
                .interactionPerson(CustomerTypeEnum.SYSTEM.getValue())
                .build();
        int insert = fundRecordMapper.insert(record);
        if (1 != insert){
            log.error("存款写入 账变记录失败 ~ 单号 {} ",entity.getOrderId());
        }
    }

    public static void main(String[] args) {



    }
}
