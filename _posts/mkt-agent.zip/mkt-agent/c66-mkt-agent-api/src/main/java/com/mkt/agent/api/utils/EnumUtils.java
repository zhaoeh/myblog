package com.mkt.agent.api.utils;

import java.util.ArrayList;
import java.util.List;

public class EnumUtils {

    /**
     * 根据枚举class类,枚举值获取枚举
     *
     * @author Austin
     * @data 2023-05-15
     **/
    public static <T extends Enum<T>> T fromString(Class<T> enumClass, String value) {
        if (enumClass == null || value == null) {
            throw new IllegalArgumentException("Enum class and value must not be null");
        }
        for (T enumConstant : enumClass.getEnumConstants()) {
            if (enumConstant.toString().equalsIgnoreCase(value)) {
                return enumConstant;
            }
        }
        throw new IllegalArgumentException("Invalid value for enum " + enumClass.getSimpleName() + ": " + value);
    }

    public static <T extends Enum<T>> List<String> toStringList(Class<T> enumClass) {
        if (enumClass == null) {
            throw new IllegalArgumentException("Enum class must not be null");
        }
        List<String> values = new ArrayList<>();
        for (T enumConstant : enumClass.getEnumConstants()) {
            values.add(enumConstant.toString());
        }
        return values;
    }
}

