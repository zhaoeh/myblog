package com.mkt.agent.api.mq.msg;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Transient;

/**
 * @Description TODO
 * @Classname TransferMessage
 * @Date 2023/9/25 12:23
 * @Created by TJSLucian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("t_agent_transfer_mq")
public class TransferMessage {
    private String messageId; // 消息唯一标识符
    private Long timestamp; // 消息时间戳
    private String dateTime;
    private int status; //0: 未处理 1:已处理 2:处理失败
    private String content;
}
