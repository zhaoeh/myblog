package com.mkt.agent.api.mq.handler;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.mkt.agent.api.mapper.TransferMQMapper;
import com.mkt.agent.api.mq.msg.TransferMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @Description TODO
 * @Classname TransferHandler
 * @Date 2023/9/25 12:04
 * @Created by TJSLucian
 */
@Component
public class TransferHandler {

    @Autowired
    private TransferMQMapper mapper;

    public TransferMessage select(String messageId){
        return mapper.selectOne(new LambdaQueryWrapper<TransferMessage>().eq(TransferMessage::getMessageId,messageId));
    }

    public void insert(TransferMessage message){
        mapper.insert(message);
    }

    public void updateByMsgId(TransferMessage message){
        mapper.update(message,new LambdaQueryWrapper<TransferMessage>().eq(TransferMessage::getMessageId,message.getMessageId()));
    }


}
