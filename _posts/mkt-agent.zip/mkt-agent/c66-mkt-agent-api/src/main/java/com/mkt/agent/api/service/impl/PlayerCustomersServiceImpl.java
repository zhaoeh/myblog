package com.mkt.agent.api.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cn.schema.customers.CreateNewAccountResponse;
import com.cn.schema.customers.QueryCustomerDownlineResponse;
import com.cn.schema.customers.WSCustomers;
import com.cn.schema.customers.WSQueryCustomerDownline;
import com.mkt.agent.api.entity.req.PlayerCustomersReq;
import com.mkt.agent.api.exception.MKTAgentException;
import com.mkt.agent.api.service.PlayerCustomersService;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.agentapi.requests.PlayerCustomersQueryReq;
import com.mkt.agent.common.enums.CustomerTypeEnum;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.helper.FunctionHelper;
import com.mkt.agent.common.helper.Conditions;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.RedisUtil;
import com.mkt.agent.common.utils.WSUtils;
import com.mkt.agent.integration.config.UserCenterConfig;
import com.mkt.agent.integration.entities.ws.InterWSCustomers;
import com.mkt.agent.integration.exception.MKTIntegrationException;
import com.mkt.agent.integration.service.UserCenterRestInter;
import com.mkt.agent.integration.service.WsRestInter;
import com.mkt.agent.integration.template.UserCenterTemplate;
import com.mkt.agent.integration.template.WsTemplate;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.StopWatch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Locale;
import java.util.Objects;

/**
 * @ClassName PlayerCustomersServiceImpl
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Service
@Slf4j
public class PlayerCustomersServiceImpl implements PlayerCustomersService {

    @Autowired
    private UserCenterConfig userCenterConfig;

    @Autowired
    private WsRestInter wsRestInter;

    @Autowired
    private UserCenterRestInter userCenterRestInter;

    private static final String CREATE_NEW_ACCOUNT_URL = "/rest/customers/create_new_account";

    private static final String USER_CENTER_CREATE_NEW_ACCOUNT_URL = "/customer/account/create_new_account";


    private static final String QUERY_CUSTOMER_DOWNLINE = "/rest/customers/query_customer_downline";

    @Resource
    private RedisUtil redisUtil;

    /**
     * 创建我的直属玩家
     *
     * @param playerCustomersReq 创建玩家request
     */
    @Override
    public void create(PlayerCustomersReq playerCustomersReq) {
        // 1.调用ws创建我的直属玩家
        try {
            InterWSCustomers interWSCustomers = new InterWSCustomers();
            interWSCustomers.setCreatedBy(playerCustomersReq.getCreatedBy());
            interWSCustomers.setCreatedDate(DateUtils.getCurrentDateTime());
            interWSCustomers.setPwd(WSUtils.encryptedPasswordOf(playerCustomersReq.getPassword(), playerCustomersReq.getAccount()));
            interWSCustomers.setProductId(playerCustomersReq.getProductId());
            interWSCustomers.setLoginName(playerCustomersReq.getAccount());
            interWSCustomers.setParentId(String.valueOf(playerCustomersReq.getParentId()));
            //ws字典值,3为代理,1为玩家
            interWSCustomers.setCustomerType("1");
            interWSCustomers.setIpAddress(playerCustomersReq.getIp());
            interWSCustomers.setMarginSwitch("0");
            String userCenterIsOpen = userCenterConfig.getUserCenterIsOpen();
            log.info("userCenterIsOpen( 1-UserCenter分支; 0-WS分支 ): {}", userCenterIsOpen);
            log.info("开始创建直属玩家===");
            Result<CreateNewAccountResponse> response = FunctionHelper.doIt(Conditions.userCenterIsOpen(userCenterIsOpen),
                    new UserCenterTemplate(USER_CENTER_CREATE_NEW_ACCOUNT_URL, userCenterRestInter, wsRestInter)::createNewAccount,
                    new WsTemplate(CREATE_NEW_ACCOUNT_URL, wsRestInter)::createNewAccount, interWSCustomers, "7;office");
            if (Objects.isNull(response) || !response.isSuccess()) {
                log.error("ws addInterWSCustomer is null");
                throw new MKTIntegrationException(ResultEnum.MY_PLAYER_CREATE_FAIL);
            }
            String typeKey = Constants.REGISTER_CUSTOMER_TYPE+interWSCustomers.getLoginName().toLowerCase(Locale.ROOT);
            log.info("The typeKey for is:{}",typeKey);
            redisUtil.set(typeKey, BaseConstants.WS_PLAYER.toString());
        } catch (Exception e) {
            e.printStackTrace();
            log.error("ws addInterWSCustomer is exception:{}", e.getMessage());
            throw new MKTIntegrationException(e.getMessage(), ResultEnum.MY_PLAYER_CREATE_FAIL.getCode());
        }
    }


    /**
     * 调用ws分页查询我的直属玩家
     *
     * @param playerCustomersQueryReq 查询玩家request
     */
    @Override
    public Page<WSCustomers> queryAllPlayerByParent(PlayerCustomersQueryReq playerCustomersQueryReq) {
        Page<WSCustomers> page = new Page<>();
        try {
            WSQueryCustomerDownline wsQueryCustomerDownline = new WSQueryCustomerDownline();
            wsQueryCustomerDownline.setLoginName(playerCustomersQueryReq.getAccount());
            // Player Type
            wsQueryCustomerDownline.setDomainName(playerCustomersQueryReq.getRegisterDomain());
            wsQueryCustomerDownline.setRegDateStart(playerCustomersQueryReq.getCreateTimeStart());
            wsQueryCustomerDownline.setRegDateEnd(playerCustomersQueryReq.getCreateTimeEnd());
            // 分页及系统字段
            wsQueryCustomerDownline.setPageNum(playerCustomersQueryReq.getPageNum());
            wsQueryCustomerDownline.setPageSize(playerCustomersQueryReq.getPageSize());
            wsQueryCustomerDownline.setOrderBy("treeLevel desc");
            wsQueryCustomerDownline.setProductId(playerCustomersQueryReq.getProductId());
            wsQueryCustomerDownline.setCustomerType(CustomerTypeEnum.PLAYER.getValue().toString());
            wsQueryCustomerDownline.setWithFields3(true);
            wsQueryCustomerDownline.setDontTree(true);
            wsQueryCustomerDownline.setCount(true);

            // 先获取count
            QueryCustomerDownlineResponse response = getWSPlayerInfo(wsQueryCustomerDownline);
            log.info("response.getCount：{}", response.getCount());
            log.info("---请求ws1结束");
            page.setTotal(response.getCount());
            // 数量为0时直接返回结果集
            if (response.getCount() == 0) {
                log.info("The data size from ws is 0");
                page.setSize(playerCustomersQueryReq.getPageSize());
                return page;
            }

            // 获取查询结果
            wsQueryCustomerDownline.setCount(false);
            response = getWSPlayerInfo(wsQueryCustomerDownline);
            log.info("call ws service to get data.size:{},", response.getWsCustomers().size());
            page.setRecords(response.getWsCustomers());
            page.setCurrent(playerCustomersQueryReq.getPageNum());
            page.setSize(playerCustomersQueryReq.getPageSize());
            return page;
        } catch (Exception e) {
            log.error("ws addInterWSCustomer is exception:{}", e.getMessage());
            throw new MKTAgentException(ResultEnum.MY_PLAYER_SEARCH_FAIL);
        }
    }

    private QueryCustomerDownlineResponse getWSPlayerInfo(WSQueryCustomerDownline wsQueryCustomerDownline) {
        WsTemplate queryPlayerWsTemplate = new WsTemplate(QUERY_CUSTOMER_DOWNLINE, wsRestInter);
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        log.info("begin to call ws for queryAllPlayerByParentPage---");
        Result<QueryCustomerDownlineResponse> response = queryPlayerWsTemplate.queryAllPlayerByParentPage(wsQueryCustomerDownline);
        stopWatch.stop();
        log.info("finished calling ws for queryAllPlayerByParentPage---接口耗时：{}", stopWatch.getTime());
        if (Objects.isNull(response) || !response.isSuccess() || response.getData() == null) {
            log.error("ws queryAllPlayerByParentPage is null");
            throw new MKTAgentException(ResultEnum.MY_PLAYER_SEARCH_FAIL);
        }
        return response.getData();
    }
}
