package com.mkt.agent.api.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mkt.agent.common.entity.TAgentMessageRecord;

public interface MessageRecordService extends IService<TAgentMessageRecord> {



}