package com.mkt.agent.api.controller;

import com.mkt.agent.api.service.GlobalConfigService;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TAgentGlobalConfigEntity;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentGlobalConfigSaveRequest;
import com.mkt.agent.common.enums.ResultEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Description 代理系统常量操作类
 * @Classname GlobalConfigController
 * @Date 2023/6/28 15:48
 * @Created by TJSLucian
 */
@RestController
@RequestMapping("/global/config")
public class GlobalConfigController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private GlobalConfigService globalConfigService;

    @PostMapping("/getValuesByName")
    public Result<List<TAgentGlobalConfigEntity>> getValuesByName(@RequestBody List<String> names) {
        try {
            List<TAgentGlobalConfigEntity> resp = globalConfigService.getValuesByName(names);
            logger.info("/global/config/getValuesByName 入参names：{} 返回值：{}", names, resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/global/config/getValuesByName 出异常了，入参names：{} 异常信息：{}", names, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping("/save")
    public Result saveGlobalConfig(@RequestBody @Validated AgentGlobalConfigSaveRequest request) {
        try {
            boolean success = globalConfigService.saveGlobalConfig(request);
            if (!success) {
                return Result.fail(ResultEnum.CONFIG_UPDATE_OR_INSERT_FAIL);
            }
            logger.info("/global/config/save 入参AgentGlobalConfigSaveRequest：{} 返回值：void", request.toString());
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/global/config/save 出异常了，入参AgentGlobalConfigSaveRequest：{} 异常信息：{}", request.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


}
