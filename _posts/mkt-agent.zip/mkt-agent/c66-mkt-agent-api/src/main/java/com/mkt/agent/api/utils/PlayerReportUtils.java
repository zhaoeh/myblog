package com.mkt.agent.api.utils;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.mkt.agent.api.mapper.TAgentCountGroupMonthMapper;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonth;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @Description TODO
 * @Classname playerReportUtils
 * @Date 2024/3/5 10:03
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class PlayerReportUtils {

    @Resource
    private AgentApiUtils agentApiUtils;

    @Resource
    private TAgentCountGroupMonthMapper groupMonthMapper;

    @Transactional(rollbackFor = Exception.class)
    public void handleIsEnableForPlayer(String loginName,Integer isEnable){

        try {
            log.info("[handleIsEnableForPlayer]Begin to handleIsEnableForPlayer for agent:{} isEnable is:{}",loginName,isEnable);

            List<TAgentCountGroupMonth> currentAgentDataList = groupMonthMapper.selectList(new LambdaQueryWrapper<TAgentCountGroupMonth>().eq(TAgentCountGroupMonth::getAgentName,loginName));

            if(!CollectionUtils.isEmpty(currentAgentDataList)){

                log.info("[handleIsEnableForPlayer]The currentAgentDataList for agent:{} is:{}",loginName,Arrays.toString(currentAgentDataList.toArray()));

                groupMonthMapper.makeAgentAbleOrNot(loginName,isEnable);

                List<String> parentNames = new ArrayList<>();

                agentApiUtils.getParentAgentList(parentNames,loginName,loginName);

                if(!CollectionUtils.isEmpty(parentNames)){

                    log.info("[handleIsEnableForPlayer]Needed to be handled parentNames are:{}", Arrays.toString(parentNames.toArray()));

                    currentAgentDataList.forEach(countGroup -> {

                        if(isEnable.equals(BaseConstants.AGENTS_IS_ABLE)){
                            groupMonthMapper.addParentAgentData(parentNames,countGroup.getTotalCount()+countGroup.getSelfCount(),countGroup.getAgentMonth());
                        }else {
                            groupMonthMapper.subParentAgentData(parentNames,countGroup.getTotalCount()+countGroup.getSelfCount(),countGroup.getAgentMonth());
                        }

                    });

                    log.info("[handleIsEnableForPlayer]Success to handleCountGroupForPlayer for agent:{}",loginName);

                }

            }
        }catch (Exception e){
            log.error("[handleIsEnableForPlayer]Failed!!",e);
        }

    }

    @Transactional(rollbackFor = Exception.class)
    public void handleIsDeletedForPlayer(String loginName,Integer isDeleted){

        try {
            log.info("[handleIsDeletedForPlayer]Begin to handleIsDeletedForPlayer for agent:{} isDeleted is:{}",loginName,isDeleted);

            List<TAgentCountGroupMonth> currentAgentDataList = groupMonthMapper.selectList(new LambdaQueryWrapper<TAgentCountGroupMonth>().eq(TAgentCountGroupMonth::getAgentName,loginName));

            if(!CollectionUtils.isEmpty(currentAgentDataList)){

                log.info("[handleIsDeletedForPlayer]The currentAgentDataList for agent:{} is:{}",loginName,Arrays.toString(currentAgentDataList.toArray()));

                groupMonthMapper.makeAgentDeletedOrNot(loginName,isDeleted);

                List<String> parentNames = new ArrayList<>();

                agentApiUtils.getParentAgentList(parentNames,loginName,loginName);

                if(!CollectionUtils.isEmpty(parentNames)){

                    log.info("[handleIsDeletedForPlayer]Needed to be handled parentNames are:{}", Arrays.toString(parentNames.toArray()));

                    currentAgentDataList.forEach(countGroup -> {

                        if(isDeleted.equals(BaseConstants.AGENTS_NO_DELETED)){
                            groupMonthMapper.addParentAgentData(parentNames,countGroup.getTotalCount()+countGroup.getSelfCount(),countGroup.getAgentMonth());
                        }else {
                            groupMonthMapper.subParentAgentData(parentNames,countGroup.getTotalCount()+countGroup.getSelfCount(),countGroup.getAgentMonth());
                        }

                    });

                    log.info("[handleIsDeletedForPlayer]Success to handleCountGroupForPlayer for agent:{}",loginName);

                }

            }
        }catch (Exception e){
            log.error("[handleIsDeletedForPlayer]Failed!!",e);
        }


    }

}
