package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.api.entity.req.TAgentContractQueryReq;
import com.mkt.agent.api.entity.resp.TAgentSettlementResp;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @ClassName CommissionPlanMapper
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Mapper
public interface TAgentContractMapper extends BaseMapper<TAgentContract> {


    public List<TAgentSettlementResp> queryListByPeriod(String settlementPeriod);

    public List<TAgentContract> queryList(@Param("req") TAgentContractQueryReq tAgentContractQueryReq);

    public Integer count(@Param("req") TAgentContractQueryReq tAgentContractQueryReq);

}
