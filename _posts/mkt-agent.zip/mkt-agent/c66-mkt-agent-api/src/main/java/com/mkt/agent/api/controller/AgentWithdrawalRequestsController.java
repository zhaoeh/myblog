package com.mkt.agent.api.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cn.schema.request.WithdrawalApplyResponse;
import com.mkt.agent.api.entity.TAgentWithdrawalRequests;
import com.mkt.agent.common.entity.api.fund.req.QueryAgentWithdrawalRequestsReq;
import com.mkt.agent.api.service.TAgentWithdrawalRequestsService;
import com.mkt.agent.common.entity.Result;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/withdrawalRequests")
public class AgentWithdrawalRequestsController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private TAgentWithdrawalRequestsService withdrawalRequestsService;

    @ApiOperation(
            value = "生成取款提案接口",
            notes = "生成取款提案接口,",
            response = WithdrawalApplyResponse.class,
            httpMethod = "POST"
    )
    @PostMapping("/apply")
    public Result<TAgentWithdrawalRequests> createWithdrawalRequests(@RequestBody TAgentWithdrawalRequests requests) {
        try {
            TAgentWithdrawalRequests resp = withdrawalRequestsService.create(requests);
            logger.info("/withdrawalRequests/apply 入参TAgentWithdrawalRequests：{} 返回值：{}", requests.toString(), resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/withdrawalRequests/apply 出异常了，入参TAgentWithdrawalRequests：{} 异常信息：{}", requests.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @ApiOperation(
            value = "取款提案修改",
            notes = "取款提案修改",
            httpMethod = "POST"
    )
    @PostMapping("/approval")
    public Result<Boolean> approval(@RequestBody TAgentWithdrawalRequests requests) {
        try {
            boolean approval = withdrawalRequestsService.approval(requests);
            logger.info("/withdrawalRequests/approval 入参TAgentWithdrawalRequests：{} 返回值：{}", requests.toString(), approval);
            return Result.success(approval);
        } catch (Exception e) {
            logger.error("/withdrawalRequests/approval 出异常了，入参TAgentWithdrawalRequests：{} 异常信息：{}", requests.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @ApiOperation(value = "查询是否有待审核的提款")
    @GetMapping("/hasPendingRequests")
    public Result<Boolean> hasPendingRequests(@RequestParam("loginName") String loginName, @RequestParam("productId") String productId) {
        try {
            boolean result = withdrawalRequestsService.hasPendingRequests(loginName, productId);
            logger.info("/withdrawalRequests/hasPendingRequests 入参(loginName：{}, productId：{}) 返回值：{}", loginName, productId, result);
            return Result.success(result);
        } catch (Exception e) {
            logger.error("/withdrawalRequests/hasPendingRequests 出异常了，入参(loginName：{}, productId：{}) 异常信息：{}", loginName, productId, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @ApiOperation(
            value = "查询取款提案",
            notes = "查询取款提案",
            httpMethod = "POST"
    )
    @PostMapping("/query")
    public Result<Page<TAgentWithdrawalRequests>> queryWithdrawRequestByCondition(@RequestBody QueryAgentWithdrawalRequestsReq requestsReq) {
        try {
            Page<TAgentWithdrawalRequests> resp = withdrawalRequestsService.queryByCondition(requestsReq);
            logger.info("/withdrawalRequests/query 入参QueryAgentWithdrawalRequestsReq：{} 返回值：{}", requestsReq.toString(), resp.getRecords().toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/withdrawalRequests/query 出异常了，入参QueryAgentWithdrawalRequestsReq：{} 异常信息：{}", requestsReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }
}
