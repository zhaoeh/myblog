package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.api.entity.TAgentWithdrawalRequests;
import com.mkt.agent.common.entity.api.fund.req.QueryAgentWithdrawalRequestsReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface TAgentWithdrawalRequestsMapper extends BaseMapper<TAgentWithdrawalRequests> {

    /**
     * 分页查询取款提案信息接口
     *
     * @param query 查询条件
     * @return  List<WSWithdrawalRequests> 查询出来返回的结果集合
     */
    List<TAgentWithdrawalRequests> queryWithdrawRequestByCondition(@Param("query") QueryAgentWithdrawalRequestsReq query);

    long  selectFoundRows();

    /**
     * 获取最后一次取款
     * @param loginName
     * @return
     */
    TAgentWithdrawalRequests selectLast(@Param("loginName") String loginName);

}
