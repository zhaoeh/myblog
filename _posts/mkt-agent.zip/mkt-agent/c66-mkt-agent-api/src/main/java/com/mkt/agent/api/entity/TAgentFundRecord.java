package com.mkt.agent.api.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.entity.BaseOperationEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

/**
 * @ClassName TFundRecord
 * @Description 账变记录
 * @Author TJSAlex
 * @Date 2023/5/18 14:00
 * @Version 1.0
 **/
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_agent_fund_record")
public class TAgentFundRecord extends BaseOperationEntity {
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long agentId;
    private String account;
    private Integer fundType;
    private BigDecimal amount;
    private Integer status;
    private Long fromId;
    private String fromAccount;
    private Long toId;
    private String toAccount;
    private Integer interactionPerson;
    private String transactionId;
    private Integer isIncome;
    private String orderId;
}
