package com.mkt.agent.api.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.cn.schema.creditlogs.CreateCreditLogsForCommToCreditResponse;
import com.cn.schema.creditlogs.WSCreditLogs;
import com.mkt.agent.api.entity.TAgentFundRecord;
import com.mkt.agent.api.entity.TAgentWallet;
import com.mkt.agent.api.enums.ATransferApproveStatusEnum;
import com.mkt.agent.api.enums.ATransferCreditModeEnum;
import com.mkt.agent.api.enums.ATransferStatusEnum;
import com.mkt.agent.api.mapper.*;
import com.mkt.agent.api.service.ATransferTransactionService;
import com.mkt.agent.common.config.ProductKeyConfig;
import com.mkt.agent.common.constants.ATransferConstants;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.atransferapi.A2ATransferEntity;
import com.mkt.agent.common.entity.api.atransferapi.A2PTransferEntity;
import com.mkt.agent.common.entity.api.atransferapi.P2ATransferEntity;
import com.mkt.agent.common.entity.api.atransferapi.request.A2ATransferReq;
import com.mkt.agent.common.entity.api.atransferapi.request.A2PTransferReq;
import com.mkt.agent.common.entity.api.atransferapi.request.P2ATransferReq;
import com.mkt.agent.common.enums.CustomerTypeEnum;
import com.mkt.agent.common.enums.FundStatusEnum;
import com.mkt.agent.common.enums.FundTypeEnum;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.utils.PHPDESEncrypt;
import com.mkt.agent.common.utils.TransIdGenerator;
import com.mkt.agent.integration.config.WSConfig;
import com.mkt.agent.integration.exception.ATransferException;
import com.mkt.agent.integration.template.WsTemplate;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;


@Service
@Slf4j
public class ATransferTransactionServiceImpl implements ATransferTransactionService {

    @Resource
    private FundWalletMapper fundWalletMapper;

    @Resource
    private FundRecordMapper fundRecordMapper;

    @Resource
    private A2ATransferMapper a2ATransferMapper;

    @Resource
    private P2ATransferMapper p2ATransferMapper;

    @Resource
    private A2PTransferMapper a2PTransferMapper;

    @Resource
    private WSConfig wsConfig;

    @Resource
    private ProductKeyConfig productKeyConfig;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void a2aTransferV1(A2ATransferReq req) throws Exception {

        // check
        a2aTransferV1Check(req);

        // 封装提案
        A2ATransferEntity entity = buildTransferEntity(req);

        log.info("创建提案");
        a2ATransferMapper.insert(entity);

        log.info("为出账和入账代理创建账变记录");
        TAgentFundRecord record1 = buildOutgoingFundRecord(entity);
        TAgentFundRecord record2 = buildIncomingFundRecord(entity);
        this.createFundRecord(record1);
        this.createFundRecord(record2);

        log.info("执行资金转移");
        // 考虑到 OptimisticLockingFailureException 问题进行重试
        final long startTime = System.currentTimeMillis();
        // 10 seconds in milliseconds
        final long retryDuration = 10000;
        // Start with a sleep of 100 milliseconds between retries
        long sleepTime = 100;
        final int maxRetries = 5;
        int currentRetry = 0;

        while (true) {
            try {
                log.info("begin to transfer to :{} from :{},this is the :{} times to try",req.getToAccount(),req.getFromAccount(),currentRetry);
                executeA2ATransfer(entity, record1, record2,req);
                log.info("Success to add :{} to :{} and cut it from :{},this is the :{} times to try",entity.getAmount(),req.getToAccount(),req.getFromAccount(),currentRetry);
                break;
            } catch (OptimisticLockingFailureException e) {
                if (++currentRetry > maxRetries || System.currentTimeMillis() - startTime > retryDuration) {
                    throw new RuntimeException("Failed to perform transfer after multiple attempts", e);
                }

                try {
                    Thread.sleep(sleepTime);
                    // Double the sleep time for the next retry
                    sleepTime *= 2;
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new RuntimeException("Transfer operation was interrupted", ie);
                }
            }
        }

    }

    private Map<Long, TAgentWallet> a2aTransferV1Check(A2ATransferReq req){

        Map<Long, TAgentWallet> wallets = fundWalletMapper
                .selectByAgentIds(Arrays.asList(req.getFromId(), req.getToId()))
                .stream().collect(Collectors.toMap(TAgentWallet::getAgentId, Function.identity()));

        TAgentWallet fromWallet = wallets.get(req.getFromId());

        // 校验余额是否充足
        if (!(fromWallet.getBalance().compareTo(req.getAmount()) >= 0)) {
            throw new RuntimeException("Insufficient balance for agent " + req.getFromId());
        }
        return wallets;
    }

    private A2ATransferEntity buildTransferEntity(A2ATransferReq req) {
        return A2ATransferEntity.builder()
                .productId(req.getProductId())
                .siteId(req.getSiteId())
                .status(ATransferStatusEnum.Failure.getCode())
                .transactionId(TransIdGenerator.getSingleId(Constants.C66))
                .transferType(req.getTransferType())
                .fromId(req.getFromId())
                .fromAccount(req.getFromAccount())
                .toId(req.getToId())
                .toAccount(req.getToAccount())
                .amount(req.getAmount())
                .remarks(req.getRemarks())
                .currency(StringUtils.isNotBlank(req.getCurrency()) ? req.getCurrency() : BaseConstants.PHP)
                .updateBy(req.getCreateBy()).createBy(req.getCreateBy()).build();
    }

    private TAgentFundRecord buildOutgoingFundRecord(A2ATransferEntity entity) {
        String transId1 = TransIdGenerator.getSingleId(Constants.C66);
        return TAgentFundRecord.builder()
                .agentId(entity.getFromId())
                .account(entity.getFromAccount())
                .fundType(FundTypeEnum.Transfer.getCode())
                .amount(entity.getAmount())
                .status(FundStatusEnum.Failure.getCode())
                .fromId(entity.getFromId())
                .fromAccount(entity.getFromAccount())
                .toId(entity.getToId())
                .toAccount(entity.getToAccount())
                .orderId(entity.getTransactionId()).transactionId(transId1)
                .interactionPerson(CustomerTypeEnum.AGENT.getValue())
                .isIncome(FundTypeEnum.Transfer.getIsIncome()).build();
    }

    private void executeA2ATransfer(A2ATransferEntity entity, TAgentFundRecord record1, TAgentFundRecord record2,A2ATransferReq req) throws Exception {
        log.info("excuteTransfer----");
        Map<Long, TAgentWallet> wallets = a2aTransferV1Check(req);
        TAgentWallet fromWallet = wallets.get(entity.getFromId());
        TAgentWallet toWallet = wallets.get(entity.getToId());

        fromWallet.setBalance(fromWallet.getBalance().subtract(entity.getAmount()));
        toWallet.setBalance(toWallet.getBalance().add(entity.getAmount()));

        log.info("使用乐观锁更新from钱包余额-- the from wallet account is:{}, new balance is:{},amount is {}",fromWallet.getLoginName(),fromWallet.getBalance(),entity.getAmount());
        boolean updatedFromWallet = updateWalletWithOptimisticLocking(fromWallet);
        log.info("使用乐观锁更新to钱包余额-- the to wallet account is:{}, new balance is:{},amount is {}",toWallet.getLoginName(),toWallet.getBalance(),entity.getAmount());
        boolean updatedToWallet = updateWalletWithOptimisticLocking(toWallet);

        if (updatedFromWallet && updatedToWallet) {
            log.info("更新提案和账变状态为成功");
            updateSuccess(entity, record1, record2);
        } else {
            throw new Exception("Failed to update wallet due to concurrent modification.");
        }
    }

    private void updateSuccess(A2ATransferEntity entity, TAgentFundRecord record1, TAgentFundRecord record2) {
        entity.setStatus(ATransferStatusEnum.Success.getCode());
        a2ATransferMapper.updateStatus(entity);
        record1.setStatus(FundStatusEnum.Success.getCode());
        record2.setStatus(FundStatusEnum.Success.getCode());
        fundRecordMapper.updateStatus(record1);
        fundRecordMapper.updateStatus(record2);
    }

    private boolean updateWalletWithOptimisticLocking(TAgentWallet wallet) {

        TAgentWallet n = new TAgentWallet();
        n.setId(wallet.getId());
        n.setBalance(wallet.getBalance());
        n.setVersion(wallet.getVersion());
        int result = fundWalletMapper.updateById(n);
        return result > 0;
    }

    private TAgentFundRecord buildIncomingFundRecord(A2ATransferEntity entity) {
//        String transId2 = TransIdGenerator.singleGenRequestId(Constants.C66, Constants.REQUEST_TYPE_TRANSFER);
        String transId2 = TransIdGenerator.getSingleId(Constants.C66);
        return TAgentFundRecord.builder()
                .agentId(entity.getToId())
                .account(entity.getToAccount())
                .fundType(FundTypeEnum.Received.getCode())
                .amount(entity.getAmount())
                .status(FundStatusEnum.Failure.getCode())
                .fromId(entity.getFromId())
                .fromAccount(entity.getFromAccount())
                .toId(entity.getToId())
                .toAccount(entity.getToAccount())
                .orderId(entity.getTransactionId()).transactionId(transId2)
                .interactionPerson(CustomerTypeEnum.AGENT.getValue())
                .isIncome(FundTypeEnum.Received.getIsIncome()).build();
    }

    @Transactional(rollbackFor = Throwable.class)
    @Override
    public void a2pTransfer(A2PTransferReq req) throws Exception{

        // 1. 创建提案
        A2PTransferEntity entity = A2PTransferEntity.builder().amount(req.getAmount()).currency(StringUtils.isNotBlank(req.getCurrency())? req.getCurrency(): BaseConstants.PHP).fromId(req.getFromId())
                .fromAccount(req.getFromAccount()).toId(req.getToId()).toAccount(req.getToAccount()).status(ATransferStatusEnum.Failure.getCode())
                .productId(StringUtils.isNotBlank(req.getProductId())?req.getProductId():Constants.C66).transactionId(TransIdGenerator.getSingleId(Constants.C66))
                .siteId(req.getSiteId()).ipAddress(req.getIpAddress()).updateBy(req.getCreateBy()).createBy(Constants.CREATED_BY_SYSTEM).remarks(req.getRemarks())
                .isFirst(checkIsFirst(req.getToId())).build();

        a2PTransferMapper.insert(entity);

        //创建账变记录
//        String transId = TransIdGenerator.singleGenRequestId(Constants.C66, Constants.REQUEST_TYPE_TRANSFER);
        String transId = TransIdGenerator.getSingleId(Constants.C66);
        TAgentFundRecord record = TAgentFundRecord.builder().agentId(entity.getFromId()).account(entity.getFromAccount()).fundType(FundTypeEnum.Transfer.getCode())
                .amount(entity.getAmount()).status(FundStatusEnum.Failure.getCode()).fromId(entity.getFromId()).fromAccount(entity.getFromAccount())
                .toId(entity.getToId()).toAccount(entity.getToAccount()).orderId(entity.getTransactionId()).transactionId(transId).interactionPerson(CustomerTypeEnum.PLAYER.getValue())
                .isIncome(FundTypeEnum.Transfer.getIsIncome()).build();
        this.createFundRecord(record);


        //给代理钱包减额度
        operateAWallet(entity.getFromId(),entity.getFromAccount(),entity.getAmount(),ATransferConstants.SUBTRACT);

        //给玩家加额度
        WsTemplate wsTemplate = new WsTemplate(wsConfig.getWsDefaultUrl(),wsConfig.getPwd());
        //封装请求实体类
        WSCreditLogs wsCreditLogs = getA2PWSCreditLogs(entity);
        log.info("call ws service to add money from user param:{}",wsCreditLogs);
        CreateCreditLogsForCommToCreditResponse resp = wsTemplate.commCreditCreate(wsCreditLogs);
        log.info("call ws service to add money from user response:{}",resp.toString());
        if(null==resp || !resp.isResult()){
            throw new ATransferException("failed to operated the user wallet!");
        }

        //修改订单状态为成功
        entity.setStatus(ATransferStatusEnum.Success.getCode());
        a2PTransferMapper.updateStatus(entity);
        //修改账变记录状态为成功
        record.setStatus(FundStatusEnum.Success.getCode());
        fundRecordMapper.updateStatus(record);

    }

    /**
     * description: 玩家转代理第一步 创建提案，给玩家减额度
     * @param:  [entity]
     * @return: boolean
     * @Date: 2023/6/23 11:50
     * @Version: 1.0.0
     * @Author: Lucian
     */
    @Override
    @Transactional(rollbackFor = Throwable.class)
    public boolean p2aTransferFirst(P2ATransferReq req) throws Exception{

        // 1. 创建提案 状态为等待审核
        P2ATransferEntity entity = P2ATransferEntity.builder().amount(req.getAmount()).currency(StringUtils.isNotBlank(req.getCurrency())? req.getCurrency(): BaseConstants.PHP).fromId(req.getFromId())
                .fromAccount(req.getFromAccount()).toId(req.getToId()).toAccount(req.getToAccount()).status(ATransferApproveStatusEnum.Pending.getCode())
                .productId(StringUtils.isNotBlank(req.getProductId())?req.getProductId(): Constants.C66).transactionId(TransIdGenerator.getSingleId(Constants.C66))
                .siteId(req.getSiteId()).ipAddress(req.getIpAddress()).updateBy(req.getCreateBy()).createBy(Constants.CREATED_BY_SYSTEM).remarks(req.getRemarks())
                .isFirst(checkIsFirst(req.getFromId())).build();

        p2ATransferMapper.insert(entity);

        // 2. 创建账变记录
//        String transId = TransIdGenerator.singleGenRequestId(Constants.C66, Constants.REQUEST_TYPE_TRANSFER);
        String transId = TransIdGenerator.getSingleId(Constants.C66);
        TAgentFundRecord record = TAgentFundRecord.builder().agentId(entity.getToId()).account(entity.getToAccount()).fundType(FundTypeEnum.Received.getCode())
                .amount(entity.getAmount()).status(FundStatusEnum.Pending.getCode()).fromId(entity.getFromId()).fromAccount(entity.getFromAccount())
                .toId(entity.getToId()).toAccount(entity.getToAccount()).orderId(entity.getTransactionId()).transactionId(transId).interactionPerson(CustomerTypeEnum.PLAYER.getValue())
                .isIncome(FundTypeEnum.Received.getIsIncome()).build();
        this.createFundRecord(record);

        //给玩家减额度
        WsTemplate wsTemplate = new WsTemplate(wsConfig.getWsDefaultUrl(),wsConfig.getPwd());
        //封装请求实体类
        WSCreditLogs wsCreditLogs = getP2AWSCreditLogs(entity, ATransferCreditModeEnum.SUBTRACT.getStr());
        log.info("call ws service to sub money from user param:{}",wsCreditLogs.toString());
        CreateCreditLogsForCommToCreditResponse resp = wsTemplate.commCreditCreate(wsCreditLogs);
        log.info("call ws service to sub money from user response:{}",resp);
        if(null==resp || !resp.isResult()){
            throw new ATransferException("failed to operated the user wallet!");
        }

        return true;
    }

    /**
     * description: 玩家转代理第二步：审核成功，给代理加钱，修改提案状态
     * @param:  [entity]
     * @return: boolean
     * @Date: 2023/6/23 13:27
     * @Version: 1.0.0
     * @Author: Lucian
     */
    @Transactional(rollbackFor = Throwable.class)
    @Override
    public boolean p2aTransferSecondSucess(P2ATransferEntity entity,TAgentFundRecord fundRecord) throws Exception {

        log.info("Add money to agent's wallet: {}",entity.toString());

        //修改提案状态为Process 二审通过 未加钱
        entity.setStatus(ATransferApproveStatusEnum.Process.getCode());
        p2ATransferMapper.updateVerifyItemByTId(entity);

        //给代理钱包加额度
        TAgentWallet wallet = checkWallet(entity.getToId(),entity.getToAccount());
        BigDecimal amount = wallet.getBalance().add(entity.getAmount());
        wallet.setBalance(amount);
        int i = fundWalletMapper.updateById(wallet);
        if(i != 1){
            throw new ATransferException("给代理钱包加额度失败");
        }

        //修改提案状态
        entity.setStatus(ATransferApproveStatusEnum.Approved.getCode());
        p2ATransferMapper.updateVerifyItemByTId(entity);
        //修改账变状态
        fundRecord.setStatus(FundStatusEnum.Success.getCode());
        fundRecordMapper.updateStatus(fundRecord);
        return true;
    }

    /**
     * description: 玩家转代理第二步：审核失败，给玩家恢复额度，修改提案状态
     * @param:  [record,entity]
     * @return: boolean
     * @Date: 2023/6/23 13:28
     * @Version: 1.0.0
     * @Author: Lucian
     */
    @Transactional
    @Override
    public boolean p2aTransferSecondFailure(P2ATransferEntity record,TAgentFundRecord fundRecord) throws Exception {

        log.info("p2aTransferSecondFailure() param:{}",record.toString());

        //更新提案状态为失败
        record.setStatus(ATransferApproveStatusEnum.Rejected.getCode());
        p2ATransferMapper.updateVerifyItemByTId(record);

        //更新账变记录为失败
        fundRecord.setStatus(FundStatusEnum.Failure.getCode());
        fundRecordMapper.updateStatus(fundRecord);

        //给玩家加额度
        WsTemplate wsTemplate = new WsTemplate(wsConfig.getWsDefaultUrl(),wsConfig.getPwd());
        //封装请求实体类
        WSCreditLogs wsCreditLogs = getP2AWSCreditLogs(record,ATransferCreditModeEnum.ADD.getStr());

        log.info("call ws service to add money from user param:{}",wsCreditLogs.toString());
        CreateCreditLogsForCommToCreditResponse resp = wsTemplate.commCreditCreate(wsCreditLogs);
        log.info("call ws service to add money from user response:{}",resp.toString());
        if(null==resp ||!resp.isResult()){
            throw new ATransferException("给玩家加额度失败");
        }
        return true;
    }


    /**
     * description: 给代理加减额度
     * @param:  [agentId, loginName, amount, type]
     * @return: void
     * @Date: 2023/6/27 18:35
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public void operateAWallet(Long agentId,String loginName,BigDecimal amount,String type){
        TAgentWallet wallet = checkWallet(agentId,loginName);
        BigDecimal result;
        if(type.equals(ATransferConstants.SUBTRACT)){
            result = wallet.getBalance().subtract(amount);
        }else {
            result = wallet.getBalance().add(amount);
        }
        wallet.setBalance(result);
        fundWalletMapper.updateById(wallet);
    }

    /**
     * description: 创建账变记录
     * @param:  [record]
     * @return: void
     * @Date: 2023/6/27 18:49
     * @Version: 1.0.0
     * @Author: Lucian
     */
    @Override
    public void createFundRecord(TAgentFundRecord record){
        fundRecordMapper.insert(record);
    }


    private TAgentWallet checkWallet(Long agentId,String agentLoginName) {
        TAgentWallet wallet = fundWalletMapper.selectOne(new LambdaQueryWrapper<TAgentWallet>().eq(TAgentWallet::getAgentId, agentId)
                .eq(TAgentWallet::getLoginName, agentLoginName).eq(TAgentWallet::getIsEnable, 1));
        if (Objects.isNull(wallet)) {
            throw new BusinessException("deposit account does not exist!");
        }
        return wallet;
    }

    /**
     * description: 封装A2P请求ws实体类 给玩家加额度
     * @param:  []
     * @return: com.cn.schema.creditlogs.WSCreditLogs
     * @Date: 2023/6/22 15:56
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public WSCreditLogs getA2PWSCreditLogs(A2PTransferEntity entity) throws Exception{
        WSCreditLogs wsCreditLogs = new WSCreditLogs();
        wsCreditLogs.setProductId(entity.getProductId());
        wsCreditLogs.setCreatedBy(entity.getCreateBy());
        wsCreditLogs.setAmount(entity.getAmount().toString());//额度
        wsCreditLogs.setReferenceId(entity.getTransactionId()); // 新代理系统的单号
        wsCreditLogs.setLastUpdatedBy(entity.getUpdateBy());
        wsCreditLogs.setSiteId(entity.getSiteId()); //1 BP,  2 AP

        //给玩家加钱
        wsCreditLogs.setTransCode(ATransferCreditModeEnum.ADD.getCode());
        wsCreditLogs.setCreditMode(ATransferCreditModeEnum.ADD.getStr());

        wsCreditLogs.setRemarks(entity.getRemarks());
        wsCreditLogs.setLoginName(entity.getToAccount());
        wsCreditLogs.setCustomerId(entity.getToId().toString());

        String key = "{"+wsCreditLogs.getLoginName()+wsCreditLogs.getProductId()+wsCreditLogs.getAmount()+"}";
        PHPDESEncrypt phpdesEncrypt = new PHPDESEncrypt(wsCreditLogs.getProductId(),  ATransferConstants.ENCRYPT_TYPE,productKeyConfig.getKey08());
        wsCreditLogs.setMd5Code(phpdesEncrypt.encrypt(key));

        return wsCreditLogs;
    }


    /**
     * description: 封装P2A请求ws实体类 给玩家加减额度
     * @param:  entity 实体类
     * @param:  type IN:加额度  OUT:减额度
     * @return: com.cn.schema.creditlogs.WSCreditLogs
     * @Date: 2023/6/22 16:53
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public WSCreditLogs getP2AWSCreditLogs(P2ATransferEntity entity,String type) throws Exception{
        WSCreditLogs wsCreditLogs = new WSCreditLogs();
        wsCreditLogs.setProductId(entity.getProductId());
        wsCreditLogs.setCreatedBy(entity.getCreateBy());
        wsCreditLogs.setAmount(entity.getAmount().toString());//额度
        wsCreditLogs.setReferenceId(entity.getTransactionId()); // 新代理系统的单号
        wsCreditLogs.setLastUpdatedBy(entity.getUpdateBy());
        wsCreditLogs.setSiteId(entity.getSiteId()); //1 BP,  2 AP

        if(type.equals(ATransferCreditModeEnum.SUBTRACT.getStr())){
            //给玩家减钱
            wsCreditLogs.setTransCode(ATransferCreditModeEnum.SUBTRACT.getCode());
            wsCreditLogs.setCreditMode(ATransferCreditModeEnum.SUBTRACT.getStr());
        }else {
            //给玩家加钱
            wsCreditLogs.setTransCode(ATransferCreditModeEnum.ADD.getCode());
            wsCreditLogs.setCreditMode(ATransferCreditModeEnum.ADD.getStr());
        }

        wsCreditLogs.setRemarks(entity.getRemarks());
        wsCreditLogs.setLoginName(entity.getFromAccount());
        wsCreditLogs.setCustomerId(entity.getFromId().toString());

        String key = "{"+wsCreditLogs.getLoginName()+wsCreditLogs.getProductId()+wsCreditLogs.getAmount()+"}";
        PHPDESEncrypt phpdesEncrypt = new PHPDESEncrypt(wsCreditLogs.getProductId(), ATransferConstants.ENCRYPT_TYPE,productKeyConfig.getKey08());
        wsCreditLogs.setMd5Code(phpdesEncrypt.encrypt(key));

        return wsCreditLogs;
    }

    /**
     * description: 校验是否是第一次转账，0: 否 1：是
     * @param:  [playerId]
     * @return: java.lang.Integer
     * @Date: 2023/6/26 14:44
     * @Version: 1.0.0
     * @Author: Lucian
     */
    private Integer checkIsFirst(Long playerId){

        List<P2ATransferEntity> entity = p2ATransferMapper.selectList(new LambdaQueryWrapper<P2ATransferEntity>().eq(P2ATransferEntity::getFromId,playerId));

        return null == entity||entity.size()==0 ? 1 : 0;

    }

}
