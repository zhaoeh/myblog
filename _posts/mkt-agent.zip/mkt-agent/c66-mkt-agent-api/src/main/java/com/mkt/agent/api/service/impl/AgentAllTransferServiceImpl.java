package com.mkt.agent.api.service.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.mkt.agent.api.mapper.TCustomerLayerMapper;
import com.mkt.agent.api.service.AgentAllTransferService;
import com.mkt.agent.api.utils.MessageUtils;
import com.mkt.agent.common.constants.ATransferConstants;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.atransferapi.request.AgentAllTransferReq;
import com.mkt.agent.common.entity.mq.Message;
import com.mkt.agent.common.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Description TODO
 * @Classname AgentAllTransferServiceImpl
 * @Date 2023/7/11 18:26
 * @Created by TJSLucian
 */
@Service
@Slf4j
public class AgentAllTransferServiceImpl implements AgentAllTransferService {

    @Autowired
    private TCustomerLayerMapper tCustomerLayerMapper;

    @Override
    public Result<Message> createAllTrans(AgentAllTransferReq req) throws Exception {

        log.info("进入代理转账createAllTrans 参数：{}",req.toString());

        TCustomerLayer fromer = tCustomerLayerMapper.selectOne(new LambdaQueryWrapper<TCustomerLayer>()
                .eq(TCustomerLayer::getCustomerId,req.getFromId()).eq(TCustomerLayer::getLoginName,req.getFromAccount()));

        TCustomerLayer toer = tCustomerLayerMapper.selectOne(new LambdaQueryWrapper<TCustomerLayer>()
                .eq(TCustomerLayer::getCustomerId,req.getToId()).eq(TCustomerLayer::getLoginName,req.getToAccount()));

        if(fromer==null || toer == null){
            return Result.fail("Agent or player does not exist!");
        }

        Integer fromType = fromer.getCustomerType();
        Integer toType = toer.getCustomerType();

        log.info("Agent Transfer FromType:{}, ToType:{}",fromType,toType);

        if(fromType==3 && toType==3){
            //代理转代理
            req.setFromToType(ATransferConstants.A2A);
        }else if(fromType == 3 && toType==1){
            //代理转玩家
            req.setFromToType(ATransferConstants.A2P);
        }else if(fromType==1 && toType==3){
            //玩家转代理
            req.setFromToType(ATransferConstants.P2A);
        }

        req.setTimestamp(System.currentTimeMillis());
        req.setDateTime(DateUtils.getCurrentDateTime());
        req.setMessageId(MessageUtils.msgIdGeneratorForTransfer(req.getFromToType(),req.getProductId(),req.getTimestamp()));
        Message message = new Message();
        message.setContent(JSON.toJSONString(req));

        return Result.success(message);
    }

}
