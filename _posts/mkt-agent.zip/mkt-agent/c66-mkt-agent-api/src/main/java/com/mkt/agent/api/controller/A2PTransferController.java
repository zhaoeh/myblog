package com.mkt.agent.api.controller;

import com.mkt.agent.api.service.A2PTransferService;
import com.mkt.agent.common.entity.api.atransferapi.A2PTransferEntity;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.atransferapi.request.A2PTransferListReq;
import com.mkt.agent.common.entity.api.atransferapi.request.A2PTransferReq;
import com.mkt.agent.integration.entities.PageModelExt;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Description 代理给玩家转账
 * @Classname A2PTransferController
 * @Date 2023/6/21 13:52
 * @Created by TJSLucian
 */
@RestController
@RequestMapping("/A2P")
public class A2PTransferController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private A2PTransferService a2PTransferService;

    @PostMapping(value = "/create")
    public Result<Boolean> createA2PTrans(@RequestBody A2PTransferReq req) {
        try {
            Result<Boolean> resp = a2PTransferService.createA2PTrans(req);
            if(resp.isSuccess()) {
                logger.info("/A2P/create 入参A2PTransferReq：{} 返回值：{}", req.toString(), resp.getData());
                return resp;
            } else {
                logger.error("/A2P/create 出异常了，入参A2PTransferReq：{} 异常信息：{}", req.toString(), resp.getMessage());
                return Result.fail(resp.getMessage());
            }
        } catch (Exception e) {
            logger.error("/A2P/create 出异常了，入参A2PTransferReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @ApiOperation(value = "查询代理给玩家转账提案列表")
    @PostMapping(value = "/queryList")
    public Result<PageModelExt<A2PTransferEntity>> queryA2PTransList(@RequestBody A2PTransferListReq req) {
        try {
            Result<PageModelExt<A2PTransferEntity>> resp = a2PTransferService.queryA2PTransList(req);
            if(resp.isSuccess()) {
                logger.info("/A2P/queryList 入参A2PTransferListReq：{} 返回值：{}", req.toString(), resp.getData().getData().toString());
                return resp;
            } else {
                logger.error("/A2P/queryList 出异常了，入参A2PTransferListReq：{} 异常信息：{}", req.toString(), resp.getMessage());
                return Result.fail(resp.getMessage());
            }
        } catch (Exception e) {
            logger.error("/A2P/queryList 出异常了，入参A2PTransferListReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


}
