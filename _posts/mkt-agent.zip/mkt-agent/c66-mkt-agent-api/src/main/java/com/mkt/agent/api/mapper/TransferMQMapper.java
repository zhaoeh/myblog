package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.api.mq.msg.TransferMessage;
import com.mkt.agent.common.entity.mq.Message;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Description TODO
 * @Classname TransferMQMessage
 * @Date 2023/9/25 12:05
 * @Created by TJSLucian
 */
@Mapper
public interface TransferMQMapper extends BaseMapper<TransferMessage> {

}
