package com.mkt.agent.api.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.cn.schema.customers.WSCustomers;
import com.mkt.agent.api.entity.TAgentFundRecord;
import com.mkt.agent.api.enums.ATransferApproveStatusEnum;
import com.mkt.agent.api.mapper.*;
import com.mkt.agent.api.service.ATransferTransactionService;
import com.mkt.agent.api.service.P2ATransferService;
import com.mkt.agent.common.constants.ATransferConstants;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.atransferapi.P2ATransferEntity;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.atransferapi.request.P2ATransferListReq;
import com.mkt.agent.common.entity.api.atransferapi.request.P2ATransferReq;
import com.mkt.agent.common.entity.api.atransferapi.request.P2ATransferVerifyReq;
import com.mkt.agent.common.enums.CustomerTypeEnum;
import com.mkt.agent.common.enums.FundStatusEnum;
import com.mkt.agent.common.enums.FundTypeEnum;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.utils.TransIdGenerator;
import com.mkt.agent.integration.config.UserCenterConfig;
import com.mkt.agent.integration.config.WSConfig;
import com.mkt.agent.integration.entities.PageModelExt;
import com.mkt.agent.integration.template.UserCenterTemplate;
import com.mkt.agent.integration.template.WsTemplate;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;

/**
 * @Description TODO
 * @Classname A2PTransferServiceImpl
 * @Date 2023/6/21 19:27
 * @Created by TJSLucian
 */
@Service
@Slf4j
public class P2ATransferServiceImpl implements P2ATransferService {

    @Resource
    private TAgentCustomersMapper tAgentCustomersMapper;

    @Resource
    private ATransferTransactionService aTransferTransactionService;

    @Resource
    private P2ATransferMapper p2ATransferMapper;

    @Resource
    private FundRecordMapper fundRecordMapper;

    @Resource
    private GlobalConfigMapper globalConfigMapper;

    @Resource
    private WSConfig wsConfig;

    @Resource
    private UserCenterConfig userCenterConfig;

    @Override
    public synchronized Result<Boolean> createP2ATrans(P2ATransferReq req) throws Exception{

        log.info("进入玩家转代理模块 参数：{}",req.toString());

        //判断代理和玩家是否存在
        checkAPExist(req.getToId(),req.getFromAccount());

        // 2. 给玩家减额度
        Boolean result = aTransferTransactionService.p2aTransferFirst(req);
        if(!result){
            return Result.fail("Failed to transfer!");
        }
        return Result.success(result);

    }

    @Override
    public Result<Boolean> verifyP2ATrans(P2ATransferVerifyReq req) throws Exception {

        log.info("verifyP2ATrans param:{}",req.toString());

        // 1. 查询P2A转账提案
        P2ATransferEntity record = p2ATransferMapper.selectOne(new LambdaQueryWrapper<P2ATransferEntity>().eq(P2ATransferEntity::getTransactionId,req.getTransactionId()));

        if(null == record){
            log.error("审核玩家转代理提案失败 {}",req);
            return Result.fail("invalid transactionId");
        }

        // 2. 查询账变记录
        TAgentFundRecord fundRecord = fundRecordMapper.selectOne(new LambdaQueryWrapper<TAgentFundRecord>()
                .eq(TAgentFundRecord::getOrderId, record.getTransactionId()));

        //审核类型 一审 二审
        String type = req.getType();

        Result<Boolean> result = Result.success(true);

        switch (type){

            //门店一审
            case ATransferConstants.VERIFY_TYPE_FIRST:

                // 更新一审审核时间和审核人
                record.setFirstReviewer(req.getVerifyBy());
                record.setFirstReviewTime(new Date());

                //一审通过
                if(req.getFlag().equals(ATransferConstants.VERIFY_SUCESS)){
                    log.info("verifyP2ATrans passed the first verify");
                    //判断是否需要二审
                    //金额大于阈值需要二审
                    List<String> approvedAmount = globalConfigMapper.getValuesByName(Arrays.asList(ATransferConstants.APPROVE_AMOUNT));
                    if(null==approvedAmount||approvedAmount.size()==0){
                        result.setData(false);
                        result.setMessage("illegal limit amount!");
                        return Result.fail(result);
                    }
                    boolean NeedSecond = record.getAmount().compareTo(new BigDecimal(approvedAmount.get(0))) > 0;
                    if(NeedSecond){
                        //需要二审
                        //更新提案状态 等待二审
                        record.setStatus(ATransferApproveStatusEnum.Pending2.getCode());
                        p2ATransferMapper.updateVerifyItemByTId(record);
                    }else {
                        //不需要二审
                        //给代理加钱，加钱成功后修改提案状态为Approved，账变状态
                        aTransferTransactionService.p2aTransferSecondSucess(record,fundRecord);
                    }
                //一审拒绝 更新提案状态 给玩家退回额度
                }else {
                    log.info("The first verify failed");
                    aTransferTransactionService.p2aTransferSecondFailure(record,fundRecord);
                }

                break;

            //门店二审
            case ATransferConstants.VERIFY_TYPE_SECOND:
                log.info("verifyP2ATrans passed the second verify");
                // 更新二审审核时间和审核人
                record.setSecondReviewer(req.getVerifyBy());
                record.setSecondReviewTime(new Date());

                //二审审核通过
                if(req.getFlag().equals(ATransferConstants.VERIFY_SUCESS)){
                    //修改提案状态为Process
                    record.setStatus(ATransferApproveStatusEnum.Process.getCode());
                    p2ATransferMapper.updateVerifyItemByTId(record);

                    //给代理加钱，加钱成功后修改提案状态为Approved，账变状态
                    aTransferTransactionService.p2aTransferSecondSucess(record,fundRecord);

                //二审审核拒绝
                }else {
                    log.info("verifyP2ATrans failed the second verify");
                    //给玩家恢复额度 更新提案状态
                    aTransferTransactionService.p2aTransferSecondFailure(record,fundRecord);
                }
                break;
        }

        return result;
    }


    @Override
    public Result<PageModelExt<P2ATransferEntity>> queryP2ATransList(P2ATransferListReq req) {

        Result<PageModelExt<P2ATransferEntity>> response = new Result<>();

        PageModelExt<P2ATransferEntity> pageModel = new PageModelExt<>();

        req.setOrder(StringUtils.defaultIfBlank(req.getOrder(), "t.create_time desc"));

        //mybatis版本问题 不能在xml文件中判空
        req.setStartCreateTime(StringUtils.isNotBlank(req.getStartCreateTime()+"")?req.getStartCreateTime():null);
        req.setEndCreateTime(StringUtils.isNotBlank(req.getEndCreateTime()+"")?req.getEndCreateTime():null);

        Integer count = p2ATransferMapper.queryListCount(req);

        if(count > 0){
            List<P2ATransferEntity> list = p2ATransferMapper.queryList(req);

            double subAmount = list.stream().mapToDouble(tran -> Double.valueOf(tran.getAmount().toString())).sum();
            Map sumResult = p2ATransferMapper.sumByCondition(req);

            Map statistics = new HashMap();
            statistics.put("subAmount", subAmount);
            statistics.put("totalAmount", sumResult.get("AMOUNT").toString());
            statistics.put("totalAccount", sumResult.get("ACCOUNT").toString());

            pageModel.setStatistics(statistics);
            pageModel.setData(list);
        }

        pageModel.setPageNo(req.getPageNum());
        pageModel.setPageSize(req.getPageSize());
        pageModel.setTotalRow(count);

        response.setData(pageModel);

        return response;
    }

    private void checkAPExist(Long agentId, String playerName){
        TAgentCustomers agent = tAgentCustomersMapper.selectOne(new LambdaQueryWrapper<TAgentCustomers>()
                .eq(TAgentCustomers::getCustomersId, agentId).eq(TAgentCustomers::getIsDeleted, 0));

        if(Objects.isNull(agent)){
            throw new BusinessException("agent does not exist!");
        }

        WSCustomers wsCustomers = null;
        try {
//            WsTemplate wsTemplate = new WsTemplate(wsConfig.getWsDefaultUrl(),wsConfig.getPwd());
            UserCenterTemplate userCenterTemplate = new UserCenterTemplate(userCenterConfig.getUserCenterDefaultUrl(),userCenterConfig.getPwd());
            wsCustomers = userCenterTemplate.queryCustomerByLoginName("C66",playerName);
        }catch (Exception e){
            log.info("call ws to get custmoer failed, loginName:{},error message:{}",playerName,e.getMessage());
        }
        if (Objects.isNull(wsCustomers)) {
            throw new BusinessException(" player does not exist!");
        }

    }





}
