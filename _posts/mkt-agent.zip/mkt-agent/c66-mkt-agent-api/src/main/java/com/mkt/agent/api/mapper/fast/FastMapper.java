package com.mkt.agent.api.mapper.fast;

import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.fast.pojo.AgentCustomersMapping;
import com.mkt.agent.common.fast.pojo.FastQueryModel;
import com.mkt.agent.common.fast.pojo.IncrementCheckPoint;
import com.mkt.agent.common.fast.pojo.SimpleCustomers;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface FastMapper {


    /**
     * 根据条件查询代理信息
     *
     * @return
     */
    List<SimpleCustomers> selectSimpleCustomers(@Param("params") List<String> params, @Param("isMappingDone") Integer isMappingDone);


    /**
     * 查询目标代理集的上级代理链
     *
     * @param agentNames
     * @return
     */
    List<SimpleCustomers> selectSuperAgentsByNames(@Param("params") List<String> agentNames);

    /**
     * 查询目标代理集的上级代理链(针对大量入参)
     *
     * @param agentNames
     * @return
     */
    List<SimpleCustomers> selectSuperAgentsByNamesOfLarge(@Param("params") List<String> agentNames);

    /**
     * 更新代理脱敏状态
     *
     * @param agentNames
     * @return
     */
    int updateAgentsStatus(@Param("params") List<String> agentNames, @Param("isMappingDone") Integer isMappingDone);

    /**
     * 查询checkpoint表中需要补救的代理
     *
     * @param param
     * @return
     */
    List<SimpleCustomers> selectAgentWithCheckPoint(@Param("param") IncrementCheckPoint param);

    /**
     * 批量插入代理脱敏映射
     *
     * @param params
     * @return
     */
    int batchInsertAgentMapping(@Param("agentMapping") List<AgentCustomersMapping> params);

    /**
     * 根据条件查询代理映射
     *
     * @param params
     * @return
     */
    List<AgentCustomersMapping> queryAgentsMapping(@Param("params") List<String> params);

    /**
     * 根据条件查询代理映射(针对in条件大量情况，创建临时表关联查询)
     *
     * @param params
     * @return
     */
    List<AgentCustomersMapping> queryAgentsMappingOfLarge(@Param("params") List<String> params);

    /**
     * 全量清空代理脱敏映射表
     */
    void clearAgentsMapping();

    /**
     * 批量插入checkpoint
     *
     * @param params
     * @return
     */
    int batchInsertCheckPoint(@Param("checkPoints") List<IncrementCheckPoint> params);

    /**
     * 根据条件删除check point表
     *
     * @param params
     * @param eventType
     * @param checkPointStep
     * @return
     */
    int deleteIncrementCheckPoint(@Param("params") List<String> params, @Param("eventType") Integer eventType, @Param("checkPointStep") Integer checkPointStep);

    /**
     * 查询checkpoint表中需要补救的资源
     *
     * @param param
     * @return
     */
    List<IncrementCheckPoint> selectTargetCheckPoints(@Param("param") IncrementCheckPoint param);

    /**
     * 查询checkpoint表中需要补救的资源数
     *
     * @param param
     * @return
     */
    int selectTargetCheckPointsOfCount(@Param("param") IncrementCheckPoint param);

    /**
     * 根据条件查询未转移的有效玩家集合总数
     *
     * @param agentNames
     * @return
     */
    int queryNotTransferPlayersCountByCondition(@Param("params") List<String> agentNames);

    /**
     * 关联脱敏映射表查询所有未转移的有效玩家集合总数
     *
     * @return
     */
    int queryNotTransferPlayersCountWithJoin();

    /**
     * 根据条件查询未转移的有效玩家集合
     *
     * @return
     */
    List<TCustomerLayer> queryNotTransferPlayersWithJoin(@Param("params") List<String> agentNames);

    /**
     * 关联脱敏表查询某个范围内未同步的玩家集合
     *
     * @param start
     * @param end
     * @return
     */
    List<TCustomerLayer> queryNotTransferPlayersWithLimit(@Param("start") Integer start, @Param("end") Integer end);


    /**
     * 更新玩家映射状态
     *
     * @param userNames
     * @return
     */
    int updateUsersStatus(@Param("params") List<String> userNames, @Param("isTransferDone") Integer isTransferDone);

    /**
     * 查询代理和对应的玩家数量并按照数量降序
     *
     * @return
     */
    List<Map<String, String>> queryUsersCountForAgent(@Param("bigSize") Integer bigSize);

    /**
     * 查询目标玩家集的信息
     *
     * @param userNames
     * @return
     */
    List<TCustomerLayer> queryPlayersByNames(@Param("params") List<String> userNames);

    /**
     * 查询指定脱敏状态的代理总数
     *
     * @param queryModel
     * @return
     */
    int queryAgentsCount(@Param("model") FastQueryModel queryModel);

    /**
     * 查询指定转移状态的玩家总数
     *
     * @param queryModel
     * @return
     */
    int queryPlayersCount(@Param("model") FastQueryModel queryModel);

    /**
     * 查询已经成功脱敏的代理总数
     *
     * @param queryModel
     * @return
     */
    int queryAgentsCountDone(@Param("model") FastQueryModel queryModel);

}
