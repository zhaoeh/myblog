package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.api.entity.req.TAgentCustomersBuildReq;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface TAgentContractBindMapper extends BaseMapper<TAgentContractBind> {

    public TAgentContract queryTAgentContractByBindId(Long bindId);

    public Integer updateBatchPercentageByBindId(@Param("initBind") TAgentContractBind initBind);

    public List<TAgentContractBind> queryAllTopAgentContractBindByContractId(Long commissionContractId);

    public String queryPercentageDetails(Long currentCustomersId);

    public void updateBatchPercentageByBindIds(@Param("tAgentCustomersBuildReq") TAgentCustomersBuildReq tAgentCustomersBuildReq);


}
