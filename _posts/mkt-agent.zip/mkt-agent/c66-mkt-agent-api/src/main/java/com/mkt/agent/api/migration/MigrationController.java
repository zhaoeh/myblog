package com.mkt.agent.api.migration;

import com.mkt.agent.api.migration.config.MigrationConfig;
import com.mkt.agent.api.migration.entity.AgentCustomers;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * @Description: 数据迁移controller
 * @Author: PTMinnisLi
 * @Date: 2023/6/30
 */
@Slf4j
@RestController
@RequestMapping("/agent")
public class MigrationController {

    @Autowired
    private AgentMigrationAccessProcess accessProcess;

    @Resource
    private MigrationConfig config;


    @GetMapping("/migration")
    public Result migration() {

        // 1.迁移开关判断
        if (!config.getIsOpen()) {
            return Result.fail("数据迁移开关未开启，迁移停止; migration switch is off now ,migration stopped");
        }
        log.info("start time : " + DateUtils.dateToDateTime(new Date()));
        // 2.获取数据
        List<AgentCustomers> agentCustomers = accessProcess.oldDataMigrationGetData(config.getPageIndex(), config.getBaseUrl());
        // 3.导入/更新数据
        String  str = accessProcess.oldAgentToNewAgent(agentCustomers);
        log.info("end time : " + DateUtils.dateToDateTime(new Date()));
        return Result.success(str);
    }
}
