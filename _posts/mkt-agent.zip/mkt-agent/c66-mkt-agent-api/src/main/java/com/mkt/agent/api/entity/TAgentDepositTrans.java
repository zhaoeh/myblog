package com.mkt.agent.api.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @ClassName TAgentDepositTrans
 * @Description 存款提案
 * @Author TJSAlex
 * @Date 2023/6/28 14:03
 * @Version 1.0
 **/
@TableName
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TAgentDepositTrans implements Serializable {
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;
    private BigDecimal amount;
    private String loginName;
    private String transCode;
    private Integer status;
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long customerId;
    private Date createdDate;
    private Date lastUpdateDate;
    private String createdBy;
    private String lastUpdatedBy;
    private Date depositDate;
    private String depositBy;
    private Integer depositType;
    private String referenceId;
    private String currency;
    private String sourceCurrency;
    private Boolean firstDeposit;
    private BigDecimal fee;
    private BigDecimal feeRate;
    private String parent;
    private String ipAddress;
    private String registerBranchName;
    private String registerBranchCode;
    private String productId;
    private Integer product;
    private String processingBy;
    private Date processingTime;
    private Integer catalog;
    private String endPoint;
    private String endPointUrl;
    private String remark;
    private Integer deleteFlag;
}

