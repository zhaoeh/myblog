package com.mkt.agent.api.entity.req;

import lombok.*;

import java.util.List;

/**
 * @ClassName TAgentCustomersReq
 * @Author TJSAustin
 * @Date 2023/5/25 10:00
 * @Version 1.0
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public class TAgentCustomersBuildReq {

    private Long  CommissionContractCode;

    private List<Long>  customersIdList;

    private String updateBy;

    private String initPercentageDetails;
}
