package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.api.entity.TAgentGlobalConfig;

/**
 * @ClassName ConfigMapper
 * @Author TJSAlex
 * @Date 2023/5/22 16:40
 * @Version 1.0
 **/
public interface ConfigMapper extends BaseMapper<TAgentGlobalConfig> {
}
