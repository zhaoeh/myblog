package com.mkt.agent.api.entity.req;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @ClassName FundApproveReq
 * @Description 风控订单审批入参
 * @Author TJSAlex
 * @Date 2023/6/10 16:06
 * @Version 1.0
 **/
@Data
public class FundApproveReq implements Serializable {

    @ApiModelProperty(value = "agentId")
    @NotNull(message = "agentId is required!")
    private Long agentId;
    @ApiModelProperty(value = "loginName")
    @NotBlank(message = "loginName is required!")
    private String loginName;
    @ApiModelProperty(value = "transId")
    @NotBlank(message = "trans ID is required!")
    private String transactionId;
    @ApiModelProperty(value = "isApprove")
    @NotNull(message = "isApprove is required!")
    private Boolean isApprove;

}
