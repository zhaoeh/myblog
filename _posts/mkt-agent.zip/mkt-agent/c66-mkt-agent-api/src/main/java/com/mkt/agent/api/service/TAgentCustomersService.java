package com.mkt.agent.api.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.mkt.agent.api.entity.req.TAgentCustomersQueryReq;
import com.mkt.agent.api.entity.req.TAgentCustomersReq;
import com.mkt.agent.api.entity.resp.TAgentCustomersResp;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomersReq;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentCustomersRemarkReq;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerGateResp;
import com.mkt.agent.common.entity.api.agentapi.responses.TAgentCustomersFrontResp;
import com.mkt.agent.common.entity.api.agentapi.responses.UserResp;
import com.mkt.agent.common.entity.api.userapi.requests.AgentListRequest;
import com.mkt.agent.common.enums.ResultEnum;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName AgentService
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
public interface TAgentCustomersService extends IService<TAgentCustomers> {

    public void create(TAgentCustomersReq tAgentCustomersReq, String ip);

    public Page<TAgentCustomersResp> queryList(TAgentCustomersQueryReq tAgentContractQueryReq);

    public Page<TAgentCustomersResp> queryListBP(TAgentCustomersQueryReq tAgentContractQueryReq);

    public void update(TAgentCustomersReq tAgentCustomersReq);

    public List<TAgentCustomersResp>  getAgentTree(String parent);

    public List<TAgentCustomersResp> export(TAgentCustomersQueryReq tAgentCustomersQueryReq, HttpServletResponse response);

    public Boolean checkAgentPower(Long customersId);

    public List<TAgentCustomers> getAgentByCustomerIds(List<Long> list);

    public void updateByMQMessage(TCustomerLayer tCustomerLayer);

    public TAgentCustomers getByCustomerId(Long customerId);

    public void cancelAgent(Long customerId);

    public void updateAgentRemark(TAgentCustomersRemarkReq tAgentCustomersRemarkReq);

    public AgentCustomerGateResp getAgentAndContractByCustomerId(Long customerId);

    TAgentCustomers getAgentByLoginName(String loginName);

    public List<TAgentCustomersFrontResp> subAgentExport(TAgentCustomersQueryReq tAgentCustomersQueryReq, HttpServletResponse response);

    //selectByLoginName
    TAgentCustomers selectOne(String loginName);

    public void userToAgent(TAgentCustomersReq tAgentCustomersReq);

    public void subUserToAgent(TAgentCustomersReq tAgentCustomersReq);

    List<TAgentCustomers> getAgentListByLoginName(AgentListRequest request);

    public TAgentCustomers queryTopAgent(Long customersId);

    public TAgentCustomers queryTopAgentByAccount(String account);

    UserResp queryCustomers(String loginName);

    public ResultEnum checkAgentIsTop(TAgentCustomersQueryReq tAgentCustomersQueryReq);

    boolean isAgent(String loginName);

    public Page<String> queryAgentCustomers(AgentCustomersReq agentCustomersReq);

    public Integer selectTotalAgents(String loginName);

    public Integer selectDirectAgents(String loginName);

}
