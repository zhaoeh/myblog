package com.mkt.agent.api.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cn.schema.customers.WSCustomers;
import com.mkt.agent.api.entity.req.PlayerCustomersReq;
import com.mkt.agent.api.service.BatchService;
import com.mkt.agent.api.service.PlayerCustomersService;
import com.mkt.agent.common.entity.BatchRecord;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.agentapi.requests.BatchQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.PlayerCustomersQueryReq;
import com.mkt.agent.common.entity.api.agentapi.responses.BatchQueryResp;
import com.mkt.agent.common.entity.api.userapi.requests.PlayerCustomersBatchReq;
import com.mkt.agent.common.entity.api.userapi.responses.PlayerCustomersBatchResp;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.UserContext;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;


/**
 * @ClassName PlayerController
 * @Description 代理
 * @Author TJSAustin
 * @Date 2023/6/6 10:00
 * @Version 1.0
 **/
@RestController
@RequestMapping("/player")
@Validated
public class PlayerCustomersController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private PlayerCustomersService playerCustomersService;

    @Resource
    private BatchService batchService;

    @PostMapping(value = "/create")
    @ApiOperation(value = "创建我的直属玩家", notes = "创建我的直属玩家")
    public Result create(@RequestBody @Validated PlayerCustomersReq playerCustomersReq) {
        try {
            logger.info("/player/create 入参playerCustomersReq：{} 返回值：void", playerCustomersReq.toString());
            playerCustomersReq.setLoginName(UserContext.getUsername());
            playerCustomersService.create(playerCustomersReq, null);
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/player/create 出异常了，入参playerCustomersReq：{} 异常信息：{}", playerCustomersReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping(value = "/batch-create")
    @ApiOperation(value = "创建我的直属玩家-批量接口", notes = "创建我的直属玩家-批量接口")
    public Result batchCreate(@RequestBody @Validated PlayerCustomersBatchReq playerCustomersBatchReq) {
        try {
            logger.info("/player/batch-create 入参playerCustomersReq：{} 返回值：void", playerCustomersBatchReq.toString());
            Result<Boolean> result = batchService.batchCreate(playerCustomersBatchReq);
            return result;
        } catch (Exception e) {
            logger.error("/player/batch-create 出异常了，入参playerCustomersReq：{} 异常信息：{}", playerCustomersBatchReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping(value = "/batch-list")
    @ApiOperation(value = "查询批量创建玩家的历史记录", notes = "创建我的直属玩家-批量接口")
    public Result<Page<BatchQueryResp>> batchList(@RequestBody @Validated BatchQueryRequest request) {
        // 查询的玩家&&记录是固定的
        request.setQueryType(BatchService.BATCH_TYPE_PLAYER);
        request.setCreator(UserContext.getUsername());
        try {
            logger.info("/player/batch-list BatchQueryRequest：{} 返回值：void", request);
            Page<BatchQueryResp> page = batchService.queryBatchInfo(request);
            return Result.success(200, "success", page);
        } catch (Exception e) {
            logger.error("/player/batch-list 出异常了，BatchQueryRequest：{} 异常信息：{}", request, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @GetMapping(value = "/batch-records")
    @ApiOperation(value = "查询批量创建玩家的历史记录", notes = "创建我的直属玩家-批量接口")
    public Result<List<BatchRecord>> batchRecordList(@RequestParam(name = "batchId") String batchId) {
        if (!StringUtils.isNumeric(batchId)) {
            return Result.fail(ResultEnum.RECORD_NOT_EXIST);
        }
        try {
            logger.info("/player/batch-records batchId：{} ", batchId);
            List<BatchRecord> page = batchService.getBatchRecords(Long.parseLong(batchId));
            return Result.success(200, "success", page);
        } catch (Exception e) {
            logger.error("/player/batch-records batchId：{}", batchId, e);
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @PostMapping(value = "/list")
    @ApiOperation(value = "我的直属玩家列表(分页)", notes = "我的直属玩家列表(分页)")
    public Result<Page<WSCustomers>> queryAllPlayerByParent(@RequestBody @Validated PlayerCustomersQueryReq playerCustomersQueryReq) {
        try {
            Page<WSCustomers> resp = playerCustomersService.queryAllPlayerByParent(playerCustomersQueryReq);
            if (null == resp) {
                return Result.fail(ResultEnum.RECORD_NOT_EXIST);
            }
            logger.info("/player/list 入参playerCustomersQueryReq：{} 返回值：{}", playerCustomersQueryReq.toString(), resp.getRecords().toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/player/list 出异常了，入参playerCustomersQueryReq：{} 异常信息：{}", playerCustomersQueryReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


}
