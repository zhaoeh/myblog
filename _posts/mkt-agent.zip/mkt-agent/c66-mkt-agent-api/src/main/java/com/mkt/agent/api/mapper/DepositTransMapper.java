package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.api.entity.TAgentDepositTrans;

/**
 * @ClassName DepositTransMapper
 * @Author TJSAlex
 * @Date 2023/6/28 16:07
 * @Version 1.0
 **/
public interface DepositTransMapper extends BaseMapper<TAgentDepositTrans> {
}
