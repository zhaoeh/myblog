package com.mkt.agent.api.service;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.atransferapi.request.AgentAllTransferReq;
import com.mkt.agent.common.entity.mq.Message;

/**
 * @Description TODO
 * @Classname AgentAllTransferService
 * @Date 2023/7/11 18:26
 * @Created by TJSLucian
 */
public interface AgentAllTransferService {

    Result<Message> createAllTrans(AgentAllTransferReq req) throws Exception;

}
