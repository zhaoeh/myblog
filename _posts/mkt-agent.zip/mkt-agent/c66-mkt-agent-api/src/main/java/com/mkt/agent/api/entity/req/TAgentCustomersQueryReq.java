package com.mkt.agent.api.entity.req;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.entity.PageReq;
import com.mkt.agent.common.enums.CustomizedValidationContents;
import com.mkt.agent.common.valid.EnumValid;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @ClassName AgentReq
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Data
public class TAgentCustomersQueryReq extends PageReq {

    /*
        登录名
    */
    @ApiModelProperty(value = "登录名")
    private String loginName;

    /*
        父级代理
   */
    @ApiModelProperty(value = "父级代理")
    private String parent;

    /*
        产品
   */
    @ApiModelProperty(value = "所属产品 ALL,1,2,3(1:Bingoplus 2:Arenaplus 3:Gameplus)")
    @EnumValid(contents = CustomizedValidationContents.product_site_id_values,groups = InputValidationGroup.Query.class)
    private String productSiteId;

    /*
        代理类型 0:普通 1:专业代理
    */
    @ApiModelProperty(value = "代理类型 ALL,0:普通,1:专业代理")
    @NotBlank(message = "agent type is not blank",groups = InputValidationGroup.Query.class)
    @EnumValid(contents = CustomizedValidationContents.agent_type_values,groups = InputValidationGroup.Query.class)
    private String agentType;

    /*
        代理可以发展最大下级代理层数
    */
    @ApiModelProperty(value = "代理层级 1,2,3,4,5")
    @NotNull(message = "agent level is not blank",groups = InputValidationGroup.Query.class)
    private List<Integer> agentLevelList;

    /*
       0:turnover, 1:GGR
   */
    @ApiModelProperty(value = "佣金计划类型 ALL,TURNOVER,GGR")
    @NotBlank(message = "commission plan type is not blank",groups = InputValidationGroup.Query.class)
    @EnumValid(contents = CustomizedValidationContents.commission_plan_type_values,groups = InputValidationGroup.Query.class)
    private String commissionPlanType;

    /*
        佣金方案code
    */
    @ApiModelProperty(value = "佣金方案名称")
    private String agentContractName;

    /*
        佣金方案code
    */
    @ApiModelProperty(value = "Referral ID")
    private String referralId;

    /*
        启用标识 0:启用 1:禁用
    */
    @ApiModelProperty(value = "启用标识  0禁用，1启用")
    @NotBlank(message = "is enable is not blank",groups = InputValidationGroup.Query.class)
    @EnumValid(contents = CustomizedValidationContents.is_enable_values,groups = InputValidationGroup.Query.class)
    private String isEnable;


    /*
        启用标识 0:启用 1:禁用
    */
    @ApiModelProperty(value = "备注")
    private String remarks;

    /*
        开始时间
    */
    @ApiModelProperty(value = "开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private String startTime;

    /*
        结束时间
    */
    @ApiModelProperty(value = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private String endTime;

    @ApiModelProperty(value = "顶级代理")
    private String levelOneAgent;

    @Override
    public Integer getPageNum() {
        return pageNum;
    }

    @Override
    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    @Override
    public Integer getPageSize() {
        return pageSize;
    }

    @Override
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    @ApiModelProperty(value = "字段排序。asc:true/desc:false")
    private Boolean isPage = true;


    public TAgentCustomersQueryReq() {
        pageNum = null;
        pageSize =null;
    }


    public String getLevelOneAgent() {
        if("".equals(levelOneAgent)||levelOneAgent==null){
            return "acc66";//去除该属性的前后空格并进行非空非null判断
        }
        return levelOneAgent;
    }

}
