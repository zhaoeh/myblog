package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonth;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description for player report
 * @Classname TAgentCountGroupMonthMapper
 * @Date 2024/3/5 10:24
 * @Created by TJSLucian
 */
@Mapper
public interface TAgentCountGroupMonthMapper extends BaseMapper<TAgentCountGroupMonth> {

    void makeAgentAbleOrNot(@Param("loginName") String loginName, @Param("isEnable")Integer isEnable);

    void addParentAgentData(@Param("parentNames")List<String> parentNames,@Param("aimCount")Integer aimCount,@Param("aimMonth")String aimMonth);

    void subParentAgentData(@Param("parentNames")List<String> parentNames,@Param("aimCount")Integer aimCount,@Param("aimMonth")String aimMonth);

    void makeAgentDeletedOrNot(@Param("loginName") String loginName, @Param("isDeleted")Integer isDeleted);


}
