package com.mkt.agent.api.controller;

import com.mkt.agent.api.service.ATransferTransactionService;
import com.mkt.agent.api.service.P2ATransferService;
import com.mkt.agent.common.constants.ATransferConstants;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.Response;
import com.mkt.agent.common.entity.api.atransferapi.P2ATransferEntity;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.atransferapi.request.P2ATransferListReq;
import com.mkt.agent.common.entity.api.atransferapi.request.P2ATransferReq;
import com.mkt.agent.common.entity.api.atransferapi.request.P2ATransferVerifyReq;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.TransIdGenerator;
import com.mkt.agent.integration.entities.PageModelExt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @Description 玩家给代理转账
 * @Classname P2ATransferController
 * @Date 2023/6/21 13:52
 * @Created by TJSLucian
 */
@RestController
@RequestMapping("/P2A")
public class P2ATransferController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private P2ATransferService p2ATransferService;
    @Autowired
    private ATransferTransactionService aTransferTransactionService;

    @PostMapping(value = "/create")
    public Result<Boolean> createP2ATrans(@RequestBody P2ATransferReq req) {
        try {
            Result<Boolean> resp = p2ATransferService.createP2ATrans(req);
            if (resp.isSuccess()) {
                logger.info("/P2A/create 入参P2ATransferReq：{} 返回值：{}", req.toString(), resp.getData());
                return resp;
            } else {
                logger.error("/P2A/create 出异常了，入参P2ATransferReq：{} 异常信息：{}", req.toString(), resp.getMessage());
                return Result.fail(resp.getMessage());
            }
        } catch (Exception e) {
            logger.error("/P2A/create 出异常了，入参P2ATransferReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping(value = "/queryList")
    public Result<PageModelExt<P2ATransferEntity>> queryP2ATransList(@RequestBody P2ATransferListReq req) {
        try {
            Result<PageModelExt<P2ATransferEntity>> resp = p2ATransferService.queryP2ATransList(req);
            if(resp.isSuccess()) {
                logger.info("/P2A/queryList 入参P2ATransferListReq：{}", req.toString());
                return resp;
            } else {
                logger.error("/P2A/queryList 出异常了，入参P2ATransferListReq：{} 异常信息：{}", req.toString(), resp.getMessage());
                return Result.fail(resp.getMessage());
            }
        } catch (Exception e) {
            logger.error("/P2A/queryList 出异常了，入参P2ATransferListReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @PostMapping(value = "/verify")
    public Result<Boolean> verifyP2ATrans(@RequestBody P2ATransferVerifyReq req) {
        try {
            Result<Boolean> resp = p2ATransferService.verifyP2ATrans(req);
            if(resp.isSuccess()) {
                logger.info("/P2A/verify 入参P2ATransferVerifyReq：{} 返回值：{}", req.toString(), resp.getData());
                return resp;
            } else {
                logger.error("/P2A/verify 出异常了，入参P2ATransferVerifyReq：{} 异常信息：{}", req.toString(), resp.getMessage());
                return Result.fail(resp.getMessage());
            }
        } catch (Exception e) {
            logger.error("/P2A/verify 出异常了，入参P2ATransferVerifyReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

}
