package com.mkt.agent.api.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mkt.agent.api.entity.req.TAgentCustomersBuildReq;
import com.mkt.agent.api.exception.MKTAgentException;
import com.mkt.agent.api.mapper.TAgentContractBindMapper;
import com.mkt.agent.api.mapper.TAgentCustomersMapper;
import com.mkt.agent.api.service.TAgentContractBindService;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.entity.api.agentapi.requests.SubAgentContractBindReq;
import com.mkt.agent.common.utils.SerializationUti;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TAgentContractBindServiceImpl extends ServiceImpl<TAgentContractBindMapper, TAgentContractBind> implements TAgentContractBindService {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private TAgentContractBindMapper tAgentContractBindMapper;

    @Autowired
    private TAgentCustomersMapper tAgentCustomersMapper;

    @Override
    public TAgentContract queryTAgentContractByBindId(Long bindId) {
        return tAgentContractBindMapper.queryTAgentContractByBindId(bindId);
    }

    @Override
    public Integer updateBatchPercentageByBindId(TAgentContractBind initBind) {
        return tAgentContractBindMapper.updateBatchPercentageByBindId(initBind);
    }

    @Override
    public List<TAgentContractBind> queryAllTopAgentContractBindByContractId(Long contractId) {
        return tAgentContractBindMapper.queryAllTopAgentContractBindByContractId(contractId);
    }

    @Override
    public List<SettlementPercentageReq> queryPercentageDetails(Long currentCustomersId) {
        String parentPercentage = tAgentContractBindMapper.queryPercentageDetails(currentCustomersId);
        List<SettlementPercentageReq> settlementPercentageReqList = SerializationUti.deserializeFromString(parentPercentage, SettlementPercentageReq.class);
        return settlementPercentageReqList;
    }

    @Override
    public TAgentContractBind queryTAgentContractBindByLoginName(String loginName) {
        TAgentContractBind contractBind = tAgentContractBindMapper.selectOne(new LambdaQueryWrapper<TAgentContractBind>().eq(TAgentContractBind::getLoginName, loginName).eq(TAgentContractBind::getIsDeleted, 0));
        return contractBind;
    }

    @Override
    public void updateSubAgentContractBind(SubAgentContractBindReq subAgentContractBindReq) {
        //登录用户与修改代理是否直属关系
        LambdaQueryWrapper<TAgentCustomers> layerLambdaQueryWrapper = new LambdaQueryWrapper<>();
        layerLambdaQueryWrapper.eq(TAgentCustomers::getParentId, subAgentContractBindReq.getParentCustomersId())
                .eq(TAgentCustomers::getParentName, subAgentContractBindReq.getParentLoginName())
                .eq(TAgentCustomers::getCustomersId, subAgentContractBindReq.getSubCustomersId())
                .eq(TAgentCustomers::getLoginName, subAgentContractBindReq.getSubLoginName())
                .eq(TAgentCustomers::getIsEnable, 1)
                .eq(TAgentCustomers::getIsDeleted, 0);
        if (!tAgentCustomersMapper.exists(layerLambdaQueryWrapper)) {
            logger.info("Only the commission ratio of directly subordinate agents can be modified.");
            throw new MKTAgentException("Only the commission ratio of directly subordinate agents can be modified.");
        }
        //查询父代理佣金比例
        List<SettlementPercentageReq> settlementPercentageReqList = queryPercentageDetails(subAgentContractBindReq.getParentCustomersId());
        List<SettlementPercentageReq> currentPercentageReqList = subAgentContractBindReq.getSettlementPercentageReq();
        percentageDetailsAllow(settlementPercentageReqList, currentPercentageReqList);
        //获取子代理佣金绑定数据
        TAgentContractBind tAgentContractBind = tAgentContractBindMapper.selectOne(
                new LambdaQueryWrapper<TAgentContractBind>().eq(TAgentContractBind::getLoginName, subAgentContractBindReq.getSubLoginName()));
        //1.集合 to String  2.子代理佣金绑定数据赋值
        tAgentContractBind.setPercentageDetails(SerializationUti.serializeToString(currentPercentageReqList));
        tAgentContractBind.setCreateBy(subAgentContractBindReq.getParentLoginName());
        //持久化操作
        super.saveOrUpdate(tAgentContractBind);
    }


    public void percentageDetailsAllow(List<SettlementPercentageReq> settlementPercentageReqList, List<SettlementPercentageReq> currentPercentageReqList) {
        if (settlementPercentageReqList == null) {
            logger.info("parent agent percentage array size is null");
            throw new MKTAgentException("parent agent percentage array size is null");
        }
        //对比父代理佣金比例与当前拿佣金比例,遵循: 1.长度必须一致 2.各阶梯父>=子
        if (settlementPercentageReqList.size() != currentPercentageReqList.size()) {
            logger.info("parent agent percentage array size is :{} , sub agent percentage array size is :{} , both must same ", settlementPercentageReqList.size(), currentPercentageReqList.size());
            throw new MKTAgentException("parent agent percentage array size is :" + settlementPercentageReqList.size() + " , sub agent percentage array size is : " + currentPercentageReqList.size() + ", both must same ");
        }
        //集合根据order排序
        settlementPercentageReqList = settlementPercentageReqList.stream().sorted(Comparator.comparing(SettlementPercentageReq::getOrder)).collect(Collectors.toList());
        currentPercentageReqList = currentPercentageReqList.stream().sorted(Comparator.comparing(SettlementPercentageReq::getOrder)).collect(Collectors.toList());
        //集合 to Iterator
        Iterator<SettlementPercentageReq> settlementPercentageReqIterator = settlementPercentageReqList.iterator();
        Iterator<SettlementPercentageReq> currentPercentageReqIterator = currentPercentageReqList.iterator();
        //遍历Iterator,比较佣金比例
        while (settlementPercentageReqIterator.hasNext()) {
            SettlementPercentageReq settlementPercentageReq = settlementPercentageReqIterator.next();
            SettlementPercentageReq currentPercentageReq = currentPercentageReqIterator.next();
            if (!settlementPercentageReq.comparePercentage(currentPercentageReq)) {
                logger.info("parent agent percentage must more than the sub agent percentage");
                throw new MKTAgentException("parent agent percentage must more than the sub agent percentage");
            }
        }

    }

    @Override
    public void updateBatchPercentageByBindIds(TAgentCustomersBuildReq tAgentCustomersBuildReq) {
        tAgentContractBindMapper.updateBatchPercentageByBindIds(tAgentCustomersBuildReq);
    }

}
