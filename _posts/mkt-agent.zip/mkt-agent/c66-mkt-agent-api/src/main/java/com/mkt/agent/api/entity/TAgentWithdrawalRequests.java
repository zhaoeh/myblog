package com.mkt.agent.api.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.enums.CustomizedValidationContents;
import com.mkt.agent.common.valid.EnumValid;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;


@Data
@TableName("t_agent_withdrawal_requests")
public class TAgentWithdrawalRequests {
    protected BigDecimal amount;

    protected String bankAccountName;

    protected String bankAccountNo;

    protected String bankAccountType;

    protected String bankProvince;

    protected String bankCity;

    protected String bankName;

    protected String branchName;

    protected String createdBy;

    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss",
            timezone = "GMT+8"
    )
    protected Date createdDate;

    protected String currency;

    protected String customerId;

    protected String customerType;

    protected String loginName;

    protected String productId;

    protected String flag;

    protected String ipAddress;

    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss",
            timezone = "GMT+8"
    )
    protected Date lastUpdate;

    protected String lastUpdatedBy;

    protected String processedBy;

    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss",
            timezone = "GMT+8"
    )
    protected Date processedDate;

    protected String remarks;

    @TableId
    protected String requestId;

    protected String auditBy;

    protected String auditDate;

    protected String endPointUrl;

    protected String endPointType;

    protected String deleteFlag;

    /**
     * 0-取款到银行卡或信用卡帐户，1-取款到比特币帐户 2-取款到虚拟币账号
     */
    private String catalog = "0";


    @ApiModelProperty(value = "取款目标币种")
    private String targetCurrency;

    @ApiModelProperty(value = "存款门店编码")
    private String branchCode;

    @ApiModelProperty(value = "注册门店名称")
    private String registerBranchName;

    private String registerBranchCode;

    @ApiModelProperty(value = "开户域名", example = "www.aaa.com")
    protected String domainName;


    @ApiModelProperty(value = "风控类型")
    protected Integer exceptionPromptType;

    @ApiModelProperty(value = "风控原因")
    protected String exceptionPrompt;

    @ApiModelProperty(value = "风控时间")
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss",
            timezone = "GMT+8"
    )
    protected Date riskCompletionTime;

    @ApiModelProperty(value = "第一次取款")
    private String firstWithdrawal;

    @TableField(exist = false)
    private String approveBy;

    @ApiModelProperty(value = "siteId 1:Bingoplus  2:Arenaplus  3:Gameplus")
    @EnumValid(contents = CustomizedValidationContents.site_id_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class} )
    private Integer siteId;

}
