package com.mkt.agent.api.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cn.schema.creditlogs.WSDepositTrans;
import com.mkt.agent.api.entity.TAgentDepositTrans;
import com.mkt.agent.common.entity.api.fund.req.DepositTransReq;
import com.mkt.agent.integration.entities.request.CreateOnlineOrderReq;

/**
 * @ClassName DepositTransService
 * @Author TJSAlex
 * @Date 2023/6/28 16:34
 * @Version 1.0
 **/
public interface DepositTransService {
    boolean apply(CreateOnlineOrderReq req);

    boolean approve(WSDepositTrans requests);

    Page<TAgentDepositTrans> query(DepositTransReq requestsReq);

    boolean apply(WSDepositTrans vo);
}
