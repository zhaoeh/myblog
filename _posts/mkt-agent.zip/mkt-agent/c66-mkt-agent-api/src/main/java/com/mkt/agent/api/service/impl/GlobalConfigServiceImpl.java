package com.mkt.agent.api.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mkt.agent.api.exception.MKTAgentException;
import com.mkt.agent.api.mapper.GlobalConfigMapper;
import com.mkt.agent.api.service.GlobalConfigService;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.TAgentGlobalConfigEntity;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentGlobalConfigSaveRequest;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.BeanCopyUtil;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

/**
 * @Description TODO
 * @Classname GlobalConfigServiceImpl
 * @Date 2023/6/28 16:00
 * @Created by TJSLucian
 */
@Service
public class GlobalConfigServiceImpl extends ServiceImpl<GlobalConfigMapper, TAgentGlobalConfigEntity> implements GlobalConfigService {


    @Resource
    private GlobalConfigMapper globalConfigMapper;


    /**
     * description: 根据参数名称查询参数常量值
     *
     * @param: [names]
     * @return: com.mkt.agent.common.entity.Result
     * @Date: 2023/6/28 16:06
     * @Version: 1.0.0
     * @Author: Lucian
     */
    @Override
    public List<TAgentGlobalConfigEntity> getValuesByName(List<String> names) {

        if (CollectionUtils.isEmpty(names)) {
            return Collections.EMPTY_LIST;
        }
        List<TAgentGlobalConfigEntity> result = globalConfigMapper.selectList(Wrappers.<TAgentGlobalConfigEntity>lambdaQuery()
                .in(TAgentGlobalConfigEntity::getParamName, names));
        if (CollectionUtils.isEmpty(result)) {
            return Collections.EMPTY_LIST;
        }
        return result;
    }

    /**
     * 新增或者修改config
     *
     * @param request 全局配置更新/新增请求类
     * @return 成功/失败
     */
    @Override
    public boolean saveGlobalConfig(AgentGlobalConfigSaveRequest request) {

        TAgentGlobalConfigEntity config = BeanCopyUtil.copyProperties(request, TAgentGlobalConfigEntity::new);

        // 下面两个key对应的值只能是数字类型
        if ((request.getParamName().equals(Constants.BranchConstants.CONFIG_KEY_WITHDRAWAL_RISK_RECEIVE)
                || request.getParamName().equals(Constants.BranchConstants.CONFIG_KEY_WITHDRAWAL_RISK_AMOUNT))
                && !NumberUtils.isDigits(request.getParamValue())) {
            throw new MKTAgentException(ResultEnum.CAN_ONLY_SET_NUMBER);
        }
        // 根据param_name 确认唯一一个配置
        Long count = globalConfigMapper.selectCount(Wrappers.<TAgentGlobalConfigEntity>lambdaQuery()
                .eq(TAgentGlobalConfigEntity::getParamName, request.getParamName()));
        if (count > 0) {
            // param_name为空时进行更新
            return globalConfigMapper.update(config, Wrappers.<TAgentGlobalConfigEntity>lambdaQuery()
                    .eq(TAgentGlobalConfigEntity::getParamName, request.getParamName())) == 1;
        }
        // param_name不为空时进行新增
        return globalConfigMapper.insert(config) == 1;
    }

}
