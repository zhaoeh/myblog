package com.mkt.agent.api.service;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.api.entity.req.TAgentContractQueryReq;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentContractReq;
import com.mkt.agent.api.entity.resp.TAgentContractResp;
import com.mkt.agent.api.entity.resp.TAgentSettlementResp;
import com.mkt.agent.common.entity.api.agentapi.responses.TAgentContractDictionaryResp;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @ClassName TAgentContractService
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
public interface TAgentContractService extends IService<TAgentContract> {

    public void create(TAgentContractReq TAgentContractReq);

    public Page<TAgentContractResp> queryList(TAgentContractQueryReq tAgentContractQueryReq);

    public void update(TAgentContractReq tAgentContractReq);

    @Deprecated
    public void updateAgentCountById(Long id);

    public void updateAgentCountByIdV1(Long id);

    public TAgentContract selectOne(Long id);

    public List<TAgentSettlementResp> queryListByPeriod(String settlementPeriod);

    public void export(TAgentContractQueryReq tAgentContractQueryReq, HttpServletResponse response);

    public void delete(Long id);

    public List<TAgentContractDictionaryResp> queryNameList(String  contractName);


}
