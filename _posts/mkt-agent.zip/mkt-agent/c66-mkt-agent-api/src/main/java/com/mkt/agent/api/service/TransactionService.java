package com.mkt.agent.api.service;

import com.mkt.agent.api.entity.TAgentDepositTrans;
import com.mkt.agent.api.entity.TAgentFundRecord;
import com.mkt.agent.common.entity.api.fund.req.FundApproveReq;

import java.math.BigDecimal;

/**
 * @ClassName TransactionService
 * @Description 账变交易
 * @Author TJSAlex
 * @Date 2023/5/25 14:42
 * @Version 1.0
 **/
public interface TransactionService {

    boolean transfer(Long fromId, Long toId, BigDecimal amount);

    boolean updateWithdrawalStatus(TAgentFundRecord record ,  com.mkt.agent.api.entity.req.FundApproveReq req);

    /**
     * 获取余额
     * @param loginName
     * @return
     */
    BigDecimal getAmount(String loginName);
}
