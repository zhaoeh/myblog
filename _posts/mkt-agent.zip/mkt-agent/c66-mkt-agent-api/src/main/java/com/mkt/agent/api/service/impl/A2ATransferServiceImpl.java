package com.mkt.agent.api.service.impl;

import com.mkt.agent.api.mapper.A2ATransferMapper;
import com.mkt.agent.api.mapper.TAgentCustomersMapper;
import com.mkt.agent.api.service.A2ATransferService;
import com.mkt.agent.api.service.ATransferTransactionService;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.atransferapi.A2ATransferEntity;
import com.mkt.agent.common.entity.api.atransferapi.request.A2ATransferListReq;
import com.mkt.agent.common.entity.api.atransferapi.request.A2ATransferReq;
import com.mkt.agent.common.entity.api.atransferapi.request.AgentAllTransferReq;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.integration.entities.PageModelExt;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;

/**
 * @Description TODO
 * @Classname A2ATransferServiceImpl
 * @Date 2023/6/21 13:57
 * @Created by TJSLucian
 */
@Service
@Slf4j
public class A2ATransferServiceImpl implements A2ATransferService {

    @Resource
    private TAgentCustomersMapper tAgentCustomersMapper;

    @Resource
    private ATransferTransactionService aTransferTransactionService;

    @Resource
    private A2ATransferMapper a2ATransferMapper;

    @Override
    public synchronized Result<Boolean> createA2ATrans(A2ATransferReq req) throws Exception {

        log.info("进入代理转代理模块 参数：{}",req.toString());

        //判断代理是否存在
        checkAgentExist(req.getFromId(),req.getToId());

        //给出账代理扣钱，给入账代理加钱 修改提案状态为成功 修改账变记录状态为成功
        aTransferTransactionService.a2aTransferV1(req);

        return Result.success(true);
    }

    @Override
    public Result<PageModelExt<A2ATransferEntity>> queryA2ATransList(A2ATransferListReq req) {
        Result<PageModelExt<A2ATransferEntity>> response = new Result<>();

        PageModelExt<A2ATransferEntity> pageModel = new PageModelExt<>();

        //mybatis版本问题 不能在xml文件中判空
        req.setStartCreateTime(StringUtils.isNotBlank(req.getStartCreateTime()+"")?req.getStartCreateTime():null);
        req.setEndCreateTime(StringUtils.isNotBlank(req.getEndCreateTime()+"")?req.getEndCreateTime():null);

        req.setOrder(StringUtils.defaultIfBlank(req.getOrder(), "t.create_time desc"));

        Integer count = a2ATransferMapper.queryListCount(req);

        if(count > 0){
            List<A2ATransferEntity> list = a2ATransferMapper.queryList(req);

            double subAmount = list.stream().mapToDouble(tran -> Double.valueOf(tran.getAmount().toString())).sum();
            BigDecimal totalAmount = a2ATransferMapper.sumByCondition(req);

            Map statistics = new HashMap();
            statistics.put("subAmount", subAmount);
            statistics.put("totalAmount", totalAmount);

            pageModel.setStatistics(statistics);
            pageModel.setData(list);
        }

        pageModel.setPageNo(req.getPageNum());
        pageModel.setPageSize(req.getPageSize());
        pageModel.setTotalRow(count);

        response.setData(pageModel);

        return response;
    }

    private void checkAgentExist(Long fromId, Long toId){

        List<Long> list = new ArrayList<>();
        list.add(fromId);
        list.add(toId);

        List<TAgentCustomers> agetList = tAgentCustomersMapper.getAgentByCustomerIds(list);

        if (Objects.isNull(agetList)||agetList.size()!=2) {
            throw new BusinessException("agent does not exist!");
        }
    }

}
