package com.mkt.agent.api.controller;

import com.mkt.agent.api.entity.dto.ConfigDto;
import com.mkt.agent.api.service.ConfigService;
import com.mkt.agent.api.service.TAgentReferralCodeService;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentReferralCodeRequest;
import com.mkt.agent.common.entity.api.referral.ReferralCodeResp;
import com.mkt.agent.common.entity.api.referral.ReferralReq;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


/**
 * @ClassName ReferralController
 * @Description 推荐ID，链接视图层
 * @Author TJSAlex
 * @Date 2023/5/24 15:11
 * @Version 1.0
 **/
@RestController
@RequestMapping("/referral")
public class ReferralController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private TAgentReferralCodeService referralCodeService;

    @Autowired
    private ConfigService configService;

    @GetMapping("/list")
    public Result<List<ReferralCodeResp>> list(@RequestParam("loginName") String loginName) {
        try {
            List<ReferralCodeResp> resp = referralCodeService.listReferral(loginName);
            logger.info("/referral/list 入参loginName：{} 返回值：{}", loginName, resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/referral/list 出异常了，入参loginName：{} 异常信息：{}", loginName, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping("/edit")
    public Result<ReferralCodeResp> edit(@RequestBody @Validated ReferralReq referralReq) {
        try {
            ReferralCodeResp resp = referralCodeService.edit(referralReq);
            logger.info("/referral/edit 入参referralReq：{} 返回值：{}", referralReq.toString(), resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/referral/edit 出异常了，入参referralReq：{} 异常信息：{}", referralReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping("/generateId")
    public Result<String> generateId() {
        try {
            String resp = referralCodeService.generateId();
            logger.info("/referral/generateId 入参：void 返回值：{}", resp);
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/referral/generateId 出异常了，入参：void 异常信息：{}", e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping("/get")
    public Result<String> getLoginName(@RequestBody AgentReferralCodeRequest request) {
        try {
            String resp = referralCodeService.getLoginName(request);
            logger.info("/referral/get 入参request：{} 返回值：{}", request.toString(), resp);
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/referral/get 出异常了，入参request：{} 异常信息：{}", request.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping("/get/list")
    public Result<List<String>> getLoginNames(@RequestBody AgentReferralCodeRequest request) {
        try {
            List<String> resp = referralCodeService.getLoginNames(request);
            logger.info("/referral/get/list 入参request：{} 返回值：{}", request.toString(), resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/referral/get/list 出异常了，入参request：{} 异常信息：{}", request.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @GetMapping("/getReferralLink")
    public Result<List<ConfigDto>> getReferralLink() {
        try {
            //String refs = referralCodeService.getReferralLink();
            List<ConfigDto> list = configService.list();
            List<ConfigDto> resp = list.stream().filter(v -> v.getParamName().startsWith("site")).collect(Collectors.toList());
            logger.info("/referral/getReferralLink 入参：void 返回值：{}", resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/referral/getReferralLink 出异常了，入参：void 异常信息：{}", e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

}
