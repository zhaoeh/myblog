//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.mkt.agent.api.migration.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AgentCustomers implements Serializable {
    @ApiModelProperty("主账号ID")
    protected String mainAccountId;
    @ApiModelProperty(
            value = "会员ID",
            notes = "和WS一致，联合 productId 作为唯一主键"
    )
    private Long customerId;
    @ApiModelProperty("产品ID")
    private String productId = "C66";
    @ApiModelProperty("会员登录名")
    private String loginName;
    @ApiModelProperty(
            value = "是否需要渠道打包，0-不需要；1-需要",
            notes = "是否需要渠道打包，0-不需要；1-需要层"
    )
    private int isNeedPackage = 0;
    @ApiModelProperty(
            value = "渠道打包备注信息",
            notes = "渠道打包备注信息"
    )
    private String packageRemark = "";
    @ApiModelProperty("佣金额度（佣金钱包）")
    private BigDecimal commissionCredit;
    @ApiModelProperty("佣金开关（佣金状态）")
    private Integer commissionStatus;
    @ApiModelProperty("是否内部代理")
    private Integer isInnerAgent;
    @ApiModelProperty("三级分销开始时间")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date agentStartDate;
    @ApiModelProperty("开户域名（注册源）")
    private String domainName;
    @ApiModelProperty("下线用户注册时信用等级")
    private Integer childInitialLevel;
    @ApiModelProperty("下线用户是否为白名单")
    private Integer isNeedCheckWithdrawal;
    @ApiModelProperty("是否有资格-强制更新ws上级,上级绑定时 专用")
    private boolean toForceUpdateWSParentIsLegal = false;
    @ApiModelProperty("唯一识别码")
    private String palcode;
    @ApiModelProperty("注册ip")
    private String registerIp = "";
    @ApiModelProperty("注册来源类型")
    private String registerFromType;
    @ApiModelProperty("会员创建时间")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date createdDate;
    @ApiModelProperty("会员信息创建人")
    private String createdBy;
    @ApiModelProperty("会员信息最后修改时间")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date lastUpdate;
    @ApiModelProperty("会员信息最后修改人")
    private String lastUpdatedBy;
    @ApiModelProperty("上级ID")
    private Long parentId;
    @ApiModelProperty("上级登录名")
    private String parentName;
    @ApiModelProperty(
            value = "直线会员数",
            notes = "agent office 会员信息页面"
    )
    private Integer firstDownCount;
    @ApiModelProperty(
            value = "二级会员数",
            notes = "agent office 会员信息页面"
    )
    private Integer secDownCount;
    @ApiModelProperty(
            value = "三级会员数",
            notes = "agent office 会员信息页面"
    )
    private Integer thrDownCount;
    @ApiModelProperty("下线层级")
    private String agentLevel;
    @ApiModelProperty("是否禁止修改代理类型(is_inner_agent)  0-允许修改；  1-禁止修改")
    private int isForbiddenUpdateAgentType;
    @ApiModelProperty("客户星级")
    private String customerLevel;
    @ApiModelProperty("信用等级")
    private String depositLevel;
    @ApiModelProperty("会员状态")
    private String flag;
    @ApiModelProperty("发展下线开关（发展下线状态）")
    private String isMarket;
    @ApiModelProperty("下线是否疑似套利")
    private Integer downlineArbit;
    @ApiModelProperty("下线是否关闭洗码")
    private Integer downlineDisXm;
    @ApiModelProperty("下线是否关闭优惠")
    private Integer downlinePromotionDis;
    @ApiModelProperty("会员注册时间")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private String regDate;
    @ApiModelProperty("备注")
    private String remarks;
    @ApiModelProperty("优先等级。-5，套利客，-4，测试，-3，下线，-2，关注，-1，黑名单，0，普通，1，VIP，2，白名单，3，俱乐部")
    private String priorityLevel;
    @ApiModelProperty("用户类型，0，试玩账号，1，真实用户，2，合作伙伴，3，其它，4，游客")
    private String customerType;
    @ApiModelProperty("币种")
    private String currency;
    @ApiModelProperty(" 配合产品常量commission_auto_convert_from_main_to_sub_currency 一起实现，佣金提案审核的时候 是否转到 对应币种的子账号下")
    private String commAutoConvertToSubCurrency = "";
    @ApiModelProperty("代理类型，0普通代理，1总代，2专业代理")
    private Integer lineType;
    @ApiModelProperty(
            value = "佣金子线。0，第一套方案，1，第二套方案",
            notes = "用于佣金结算"
    )
    private Integer subline;
    @ApiModelProperty("普通三级分销佣金方案编号")
    private String contractCode;
    @ApiModelProperty("专业代理方案编号")
    private String lineContractCode;
    @ApiModelProperty("普通三级分销第二套佣金方案编号")
    private String sublineContractCode;
    @ApiModelProperty("当前佣金方案名")
    private String contractName;
    @ApiModelProperty("佣金方案ID")
    private Long contractId;
    @ApiModelProperty("当前普通代理方案生效时间")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date effectiveDate;
    @ApiModelProperty("新佣金方案")
    private String wellContractCode;
    @ApiModelProperty("新佣金方案名")
    private String wellContractName;
    @ApiModelProperty(
            value = "新佣金方案生效时间",
            notes = "也用于结算佣金时"
    )
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date wellEffectiveDate;
    @ApiModelProperty("当前佣金方案名")
    private String sublineContractName;
    @ApiModelProperty("佣金方案ID")
    private Long sublineContractId;
    @ApiModelProperty("当前普通三级分销第二套方案生效时间")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date sublineEffectiveDate;
    @ApiModelProperty("新佣金方案")
    private String sublineWellContractCode;
    @ApiModelProperty("新佣金方案名")
    private String sublineWellContractName;
    @ApiModelProperty(
            value = "新佣金方案生效时间",
            notes = "也用于结算佣金时"
    )
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date sublineWellEffectiveDate;
    @ApiModelProperty
    private String lineContractName;
    @ApiModelProperty
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date lineWellEffectiveDate;
    @ApiModelProperty
    private String lineWellContractCode;
    @ApiModelProperty
    private String lineWellContractName;
    @ApiModelProperty("当前专业代理方案生效时间")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date lineEffectiveDate;
    @ApiModelProperty("修改后的代理方案code")
    private String newContractCode;
    @ApiModelProperty("修改后的代理方案名称")
    private String newContractName;
    @ApiModelProperty("修改前的代理方案code")
    private String oldContractCode;
    @ApiModelProperty("修改前的代理方案名称")
    private String oldContractName;
    @ApiModelProperty("是否立即生效 0立即生效 1下期生效")
    private Integer effectiveFlag;
    @ApiModelProperty("生效日期")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date realEffectiveDate;
    @ApiModelProperty("下沉类型")
    private int sinkType;
    @ApiModelProperty("匹配时间")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date matchDate;
    @ApiModelProperty("代理层数")
    private int agentLevelCount;
    @ApiModelProperty("注册IP")
    private String ipAddress;
    @ApiModelProperty("最后登录Ip")
    private String lastLoginIp;
    @ApiModelProperty("创建时间（字符串）")
    private String createdDateStr;
    @ApiModelProperty("匹配时间（字符串）")
    private String matchDateStr;
    @ApiModelProperty("佣金方案绑定类型，0，普通方案，1，专代方案")
    private int contractBindType;
    @ApiModelProperty(
            value = "佣金状态首次开启时间",
            notes = "默认为2000-01-01 00:00:00"
    )
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date commissionEnabledTime;
    @ApiModelProperty(
            value = "是否显示下线登录名",
            notes = "0是1否"
    )
    private Integer showDownlineName;
    @ApiModelProperty("开启发展线下状态时间")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private String isMarketEnabledTime;
    @ApiModelProperty(
            value = "币商",
            notes = "0否1是"
    )
    private Integer isBiMerchant;
    @ApiModelProperty("开启发展线下状态时间")
    private String creditSign;
    @ApiModelProperty(
            value = "佣金额度账户状态",
            notes = "0-正常 1-异常"
    )
    private Integer creditFlag;
    @ApiModelProperty(
            value = "是否显示转下线按钮",
            notes = "0-不显示 1-显示"
    )
    private Integer showToDownline;
    @ApiModelProperty("首次存款时间")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date firstDepositDate;
    @ApiModelProperty("最后登录时间")
    @DateTimeFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private Date lastLoginDate;
    @ApiModelProperty("web访问权限")
    private String webResource;
    @ApiModelProperty("分成比例")
    private List<Objects> custProportions;
    @ApiModelProperty("当前用户关联的域名信息")
    private List<Objects> relationRecords = new ArrayList();
    @ApiModelProperty("注册终端")
    private String registerType;
    @ApiModelProperty("注册终端（office显示）")
    private String registerTypeForShow;
    @ApiModelProperty("交易密码")
    private String transactionPwd;
    @ApiModelProperty("登录启用标示：0禁用，1启用, AgentOffice独有")
    private Integer loginFlag;
    @ApiModelProperty("数据标识（代理前端能不能显示设置好的菜单）1-禁用(不显示菜单) 0-启用(显示菜单)")
    private Integer dataFlag;
    @ApiModelProperty("显示数据的时间段:默认为0;0,限制;1,一个月以内;3三个月以内;6,六个月以内")
    private Integer dataRange;
    @ApiModelProperty("用户保证金，仅在已关联保证金的代理方案生效")
    private BigDecimal guaranteeAmount;
    @ApiModelProperty("是否属于专代线路下的节点 0不属于专代线路 1属于专代线路")
    private Integer isNodeOfProfessionalAgents;

}
