package com.mkt.agent.api.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cn.schema.customers.WSCustomers;
import com.mkt.agent.api.entity.req.PlayerCustomersReq;
import com.mkt.agent.common.entity.api.agentapi.requests.PlayerCustomersQueryReq;

/**
 * @ClassName PlayerCustomersService
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
public interface PlayerCustomersService {

    void create(PlayerCustomersReq playerCustomersReq);

    Page<WSCustomers> queryAllPlayerByParent(PlayerCustomersQueryReq playerCustomersQueryReq);

}
