package com.mkt.agent.api.entity.req;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @ClassName FundTradeReq
 * @Description 收取佣金
 * @Author TJSAlex
 * @Date 2023/5/23 16:16
 * @Version 1.0
 **/
@Data
public class FundTransferReq implements Serializable {

    @ApiModelProperty(value = "fromId")
    @NotNull(message = "fromId is required!")
    private Long fromId;
    @ApiModelProperty(value = "fromAccount")
    @NotBlank(message = "fromAccount is required!")
    private String fromAccount;
    @ApiModelProperty(value = "toId")
    @NotNull(message = "toId is required!")
    private Long toId;
    @ApiModelProperty(value = "fromAccount")
    @NotBlank(message = "toAccount is required!")
    private String toAccount;
    @ApiModelProperty(value = "amount")
    @NotNull(message = "amount is required!")
    @DecimalMin(value = "0.000000",message = "amount format is incorrect!")
    private BigDecimal amount;
}
