package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.agentapi.TAgentReferralCode;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TAgentReferralCodeMapper extends BaseMapper<TAgentReferralCode> {





}
