package com.mkt.agent.api.mq.sender;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @Description TODO
 * @Classname TransferMQSender
 * @Date 2023/9/9 15:45
 * @Created by TJSLucian
 */
@Slf4j
@Component
public class TransferMQSender {

    private final RabbitTemplate rabbitTemplate;

    private final String exchange = "exchange_online_agent_transfer";

    private final String routingKey = "C66.online.agent.transfer";

    @Autowired
    public TransferMQSender(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void sendMessage(String message) {
        log.info("[RabbitMQ-agent-api][Sender]  exchange:{} routingKey:{} message:{}", exchange, routingKey, message);
        rabbitTemplate.convertAndSend(exchange,routingKey,message);

    }

}
