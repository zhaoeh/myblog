package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.TAgentGlobalConfigEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;


/**
 * @Description TODO
 * @Classname GlobalConfigMapper
 * @Date 2023/6/22 13:38
 * @Created by TJSLucian
 */
@Mapper
public interface GlobalConfigMapper extends BaseMapper<TAgentGlobalConfigEntity> {

    List<String> getValuesByName(@Param("names") List<String> names);

}
