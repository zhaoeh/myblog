package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.atransferapi.A2PTransferEntity;
import com.mkt.agent.common.entity.api.atransferapi.P2ATransferEntity;
import com.mkt.agent.common.entity.api.atransferapi.request.A2PTransferListReq;
import com.mkt.agent.common.entity.api.atransferapi.request.P2ATransferListReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @Description TODO
 * @Classname A2PTransferMapper
 * @Date 2023/6/22 13:38
 * @Created by TJSLucian
 */
@Mapper
public interface A2PTransferMapper extends BaseMapper<A2PTransferEntity> {

    Integer queryListCount(@Param("a2PTransferListReq") A2PTransferListReq a2PTransferListReq);

    List<A2PTransferEntity> queryList(@Param("a2PTransferListReq") A2PTransferListReq a2PTransferListReq);

    Map sumByCondition(@Param("a2PTransferListReq") A2PTransferListReq a2PTransferListReq);

    Integer updateStatus(@Param("entity") A2PTransferEntity entity);

}
