package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.agentapi.TAgentUpdateLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @Description TODO
 * @Classname TAgentUpdateLogMapper
 * @Date 2023/12/8 18:15
 * @Created by TJSLucian
 */
@Mapper
public interface TAgentUpdateLogMapper extends BatchInsertCommonMapper<TAgentUpdateLog> {

    TAgentUpdateLog getFrashBaName(@Param("loginName") String loginName);

    void updateByName(@Param("loginName") String loginName);
}
