package com.mkt.agent.api.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cn.schema.customers.WSQueryCustomers;
import com.mkt.agent.api.entity.TAgentWithdrawalRequests;
import com.mkt.agent.api.entity.req.FundTradeReq;
import com.mkt.agent.api.service.*;
import com.mkt.agent.common.entity.TAgentGlobalConfigEntity;
import com.mkt.agent.common.entity.api.fund.req.QueryAgentWithdrawalRequestsReq;
import com.mkt.agent.api.mapper.TAgentWithdrawalRequestsMapper;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.enums.WithdrawalRequestFlagEnum;
import com.mkt.agent.common.enums.WithdrawalRiskPromptEnum;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.utils.NumberUtils;
import com.mkt.agent.integration.template.WsTemplate;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import static com.mkt.agent.common.enums.ResultEnum.ERROR_WITHDRAW_LIMIT;
import static com.mkt.agent.common.enums.ResultEnum.ERROR_WITHDRAW_NOT_EXISTS;

@Slf4j
@Service
public class TAgentWithdrawalRequestsServiceImpl implements TAgentWithdrawalRequestsService {
    @Autowired
    private WsTemplate wsTemplate;
    @Autowired
    private TransactionService transactionService;
    @Autowired
    private FundService fundService;
    @Autowired
    private TAgentWithdrawalRequestsMapper withdrawalRequestsMapper;
    @Autowired
    private TAgentCustomersService customersService;
    @Autowired
    private GlobalConfigService globalConfigService;


    @Override
    @Transactional(rollbackOn = Throwable.class)
    public TAgentWithdrawalRequests create(TAgentWithdrawalRequests requests) {
        final String loginName = requests.getLoginName();
        WSQueryCustomers wsQueryCustomers = new WSQueryCustomers();
        wsQueryCustomers.setLoginName(loginName);
        wsQueryCustomers.setProductId(requests.getProductId());

        // 取款金额不能大于钱包余额
        BigDecimal amount = transactionService.getAmount(loginName);
        if (amount.compareTo(requests.getAmount()) < 0) {
            throw new BusinessException(ERROR_WITHDRAW_LIMIT);
        }
        // 查询上次取款
        TAgentWithdrawalRequests lastWithdrawal = withdrawalRequestsMapper.selectLast(loginName);
        BigDecimal receiveAmount = lastWithdrawal == null ? BigDecimal.ZERO
                : fundService.receiveAmount(loginName, lastWithdrawal.getCreatedDate());

        BigDecimal x = getReceiveTooLarge();
        BigDecimal y = getWithdrawalTooLarge();
        WithdrawalRiskPromptEnum riskPrompt= WithdrawalRiskPromptEnum.PASS;
        if(NumberUtils.isGreaterOrEqual(receiveAmount,x)){
            log.info("receive too large ===> requestId {} receiveAmount {} x {}",requests.getRequestId(),receiveAmount,x);
            riskPrompt = WithdrawalRiskPromptEnum.RECEIVE_TOO_LARGE;
        }else if(NumberUtils.isGreaterOrEqual(requests.getAmount(),y)){
            riskPrompt = WithdrawalRiskPromptEnum.WITHDRAWAL_TOO_LARGE;
        }

        requests.setRiskCompletionTime(new Date());
        requests.setExceptionPromptType(riskPrompt.getType());
        requests.setExceptionPrompt(riskPrompt.getPrompt());
        requests.setFlag("0");
        requests.setFirstWithdrawal(lastWithdrawal == null ? "1" : "0");
        requests.setCreatedDate(new Date());
        // 自动审核通过
        if(riskPrompt == WithdrawalRiskPromptEnum.PASS){
            requests.setFlag(Constants.REQUEST_FlAG_PROCESSING);
            requests.setProcessedBy("System");
            requests.setProcessedDate(new Date());
        }
        withdrawalRequestsMapper.insert(requests);

        TAgentCustomers tAgentCustomers = customersService.selectOne(loginName);
        FundTradeReq tradeReq = new FundTradeReq();
        tradeReq.setLoginName(loginName);
        tradeReq.setAmount(requests.getAmount());
        tradeReq.setAgentId(tAgentCustomers.getCustomersId());
        fundService.withdrawal(tradeReq,requests.getRequestId());

        return requests;
    }

    @Override
    public boolean approval(TAgentWithdrawalRequests requests) {
        // 查询
        LambdaQueryWrapper<TAgentWithdrawalRequests> Querywrapper = Wrappers
                .lambdaQuery(TAgentWithdrawalRequests.class)
                .eq(TAgentWithdrawalRequests::getRequestId, requests.getRequestId());

        TAgentWithdrawalRequests exists = withdrawalRequestsMapper.selectOne(Querywrapper);
        if (exists == null) {
            throw new BusinessException(ERROR_WITHDRAW_NOT_EXISTS);
        }
        // 更新提案
        TAgentWithdrawalRequests updateRequest = new TAgentWithdrawalRequests();
        updateRequest.setRequestId(exists.getRequestId());
        updateRequest.setFlag(requests.getFlag());
        updateRequest.setRemarks(requests.getRemarks());
        updateRequest.setLastUpdatedBy(requests.getLastUpdatedBy());
        updateRequest.setLastUpdate(new Date());
        updateRequest.setProcessedBy(requests.getProcessedBy());
        updateRequest.setProcessedDate(requests.getProcessedDate());
        updateRequest.setEndPointType(requests.getEndPointType());
        updateRequest.setEndPointUrl(requests.getEndPointUrl());
        withdrawalRequestsMapper.updateById(updateRequest);
        // 更新账变记录
        int flag = Integer.parseInt(requests.getFlag());
        if(WithdrawalRequestFlagEnum.PROCESSING.getVal() != flag){
            FundTradeReq fundTradeReq = new FundTradeReq();
            fundTradeReq.setLoginName(exists.getLoginName());
            fundTradeReq.setIsApprove(WithdrawalRequestFlagEnum.SUCCESS.is(flag));
            fundService.updateWithdrawState(fundTradeReq);
        }
        return true;
    }

    @Override
    public Page<TAgentWithdrawalRequests> queryByCondition(QueryAgentWithdrawalRequestsReq req) {
        Page<TAgentWithdrawalRequests> page = new Page<>();
        //默认包含ALL
        req.setBranchCode(StringUtils.isBlank(req.getBranchCode()) || "ALL".equals(req.getBranchCode()) ? "" : req.getBranchCode());

        List<TAgentWithdrawalRequests> tAgentWithdrawalRequests = withdrawalRequestsMapper.queryWithdrawRequestByCondition(req);
        if (tAgentWithdrawalRequests.isEmpty()) {
            return page;
        }
        long foundRows = withdrawalRequestsMapper.selectFoundRows();
        page.setTotal(foundRows);
        page.setRecords(tAgentWithdrawalRequests);
        page.setCurrent(req.getPageNum());
        return page;
    }

    public BigDecimal getReceiveTooLarge() {
        List<TAgentGlobalConfigEntity> values = globalConfigService.getValuesByName(List.of(Constants.BranchConstants.CONFIG_KEY_WITHDRAWAL_RISK_RECEIVE));
        if(values.isEmpty()){
            log.warn("miss config WITHDRAWAL_RISK_RECEIVE ");
            throw new BusinessException();
        }
        return new BigDecimal(values.get(0).getParamValue());
    }

    public BigDecimal getWithdrawalTooLarge() {
        List<TAgentGlobalConfigEntity> values = globalConfigService.getValuesByName(List.of(Constants.BranchConstants.CONFIG_KEY_WITHDRAWAL_RISK_AMOUNT));
        if(values.isEmpty()){
            log.warn("miss config WITHDRAWAL_RISK_AMOUNT ");
            throw new BusinessException();
        }
        return new BigDecimal(values.get(0).getParamValue());

    }

    @Override
    public boolean hasPendingRequests(String loginName, String productId) {
        LambdaQueryWrapper<TAgentWithdrawalRequests> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(TAgentWithdrawalRequests::getLoginName, loginName)
                .eq(TAgentWithdrawalRequests::getProductId, productId)
                .in(TAgentWithdrawalRequests::getFlag, WithdrawalRequestFlagEnum.PENDING.getVal(), WithdrawalRequestFlagEnum.PROCESSING.getVal()
                );
        Long count = withdrawalRequestsMapper.selectCount(wrapper);

        return count != null && count > 0;
    }
}
