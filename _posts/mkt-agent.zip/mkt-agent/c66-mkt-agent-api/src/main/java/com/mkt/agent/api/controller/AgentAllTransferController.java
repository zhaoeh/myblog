package com.mkt.agent.api.controller;

import com.mkt.agent.api.service.AgentAllTransferService;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.atransferapi.request.AgentAllTransferReq;
import com.mkt.agent.common.entity.mq.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @Description TODO
 * @Classname AgentAllTransferController
 * @Date 2023/7/11 18:37
 * @Created by TJSLucian
 */
@RestController
@RequestMapping("/Agent/transfer")
public class AgentAllTransferController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private AgentAllTransferService agentAllTransferService;

    @PostMapping(value = "/create")
    public Result<Message> createAllTrans(@RequestBody AgentAllTransferReq req) {
        try {
            Result<Message> resp = agentAllTransferService.createAllTrans(req);
            if(resp.isSuccess()) {
                logger.info("/Agent/transfer/create 入参AgentAllTransferReq：{} 返回值：{}", req.toString(), resp.getData());
                return resp;
            } else {
                logger.error("/Agent/transfer/create 出异常了，入参AgentAllTransferReq：{} 异常信息：{}", req.toString(), resp.getMessage());
                return Result.fail(resp.getMessage());
            }
        } catch (Exception e) {
            logger.error("/Agent/transfer/create 出异常了，入参AgentAllTransferReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }
}
