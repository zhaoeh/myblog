package com.mkt.agent.api.helper;

import com.mkt.agent.api.exception.MKTAgentException;
import com.mkt.agent.api.mapper.BatchRecordMapper;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;

/**
 * @program: BatchUserHelper
 * @description: 批量创建用户/代理生成用户名
 * @author: Jojo
 * @create: 2024/04/04-17:50
 **/
@Component
@Slf4j
public class BatchUserHelper {
    @Resource
    private RedisUtil redisUtil;
    @Resource
    private BatchRecordMapper batchRecordMapper;

    // 获取最后一位后缀
    public AtomicLong getSuffix(String prefix, boolean prefixAble) {
        if (prefixAble && (prefix.length() > 10 || prefix.length() < 2 || !prefix.matches("[a-z]+"))) {
            throw new MKTAgentException(ResultEnum.PREFIX_IS_INCORRECT);
        }
        // 初始化后缀数字
        AtomicLong maxCount = new AtomicLong(0);
        if (prefix.length() > 0) {
            String lastName = Optional.ofNullable(batchRecordMapper.findLastAccount(prefix)).orElse("");
            String suffix = lastName.replaceFirst("^" + prefix, "");
            // 后缀不是纯数字的话, 从"00"开始创建
            if (suffix.matches("\\d+")) {
                maxCount.addAndGet(Long.parseLong(suffix));
            }
        }
        return generateAccount(prefix, maxCount);
    }

    // 生成不重复的后缀数字
    private AtomicLong generateAccount(String prefix, AtomicLong maxCount) {
        String account = prefix + String.format("%02d", maxCount.get());
        if (redisUtil.exists(Constants.UNIQUE_NAME_PREFIX + account)) {
            maxCount.getAndIncrement(); // 获取并递增
            generateAccount(prefix, maxCount);
        }
        Integer total = prefix.length() + Long.toString(maxCount.get()).length();
        if (total > Constants.MAX_ACCOUNT_LENGTH) {
            throw new MKTAgentException(ResultEnum.PREFIX_IS_INCORRECT);
        }
        log.info("Begin to create new account ----- prefix={}, start suffix is {}", prefix, maxCount);
        return maxCount;
    }

    // 自定义生成账户
    public String getAccountByPrefix(String prefix, AtomicLong suffix) {
        // 赋值并且后缀递增
        String account = prefix + String.format("%02d", suffix.getAndIncrement());
        if (account.length() > Constants.MAX_ACCOUNT_LENGTH) {
            throw new MKTAgentException(ResultEnum.ACCOUNT_IS_INCORRECT);
        }
        while (redisUtil.exists(Constants.UNIQUE_NAME_PREFIX + account)) {
            log.info("The account '{}' is exist, generating the next one", account);
            account = prefix + String.format("%02d", suffix.getAndIncrement());
        }
        log.info("The current new account ----- is {}", account);
        return account;
    }

}
