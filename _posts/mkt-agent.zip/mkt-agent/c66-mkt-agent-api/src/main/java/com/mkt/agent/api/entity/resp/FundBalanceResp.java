package com.mkt.agent.api.entity.resp;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @ClassName FundBalanceResp
 * @Description 代理余额
 * @Author TJSAlex
 * @Date 2023/5/24 14:35
 * @Version 1.0
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FundBalanceResp implements Serializable {
    @ApiModelProperty(value = "agentId")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long agentId;
    @ApiModelProperty(value = "loginName")
    private String loginName;
    @ApiModelProperty(value = "balance")
    private BigDecimal balance;
}
