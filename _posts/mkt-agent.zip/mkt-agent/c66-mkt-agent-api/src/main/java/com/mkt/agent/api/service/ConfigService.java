package com.mkt.agent.api.service;


import com.mkt.agent.api.entity.dto.ConfigDto;

import java.util.List;

/**
 * @ClassName ConfigService
 * @Author TJSAlex
 * @Date 2023/5/22 16:35
 * @Version 1.0
 **/
public interface ConfigService {
    boolean save(ConfigDto req);

    boolean del(ConfigDto req);

    List<ConfigDto> list();
}
