package com.mkt.agent.api.mq;

import com.mkt.agent.api.entity.TAgentWithdrawalRequests;
import com.mkt.agent.api.mq.msg.WithdrawApproveMessage;
import com.mkt.agent.api.service.MessageRecordService;
import com.mkt.agent.api.service.TAgentWithdrawalRequestsService;
import com.mkt.agent.common.entity.TAgentMessageRecord;
import com.mkt.agent.common.utils.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;

@Component
@Slf4j
public class WithdrawApproveListener {
    private final String WITHDRAW_APPROVE_QUEUE = "c66.agent.gateway.withdrawl.approve";

    private final String WITHDRAW_APPROVE_EXCHANGE = "exchange_withdraw_approve";

    private final String WITHDRAW_APPROVE_ROUTING_KEY = "*.routingkey.merchant.online.order";

    @Autowired
    private TAgentWithdrawalRequestsService withdrawalRequestsService;

    @Autowired
    private MessageRecordService messageRecordService;


    @RabbitListener(bindings = {@QueueBinding(
            value = @Queue(value = WITHDRAW_APPROVE_QUEUE, durable = "true", autoDelete = "false"),
            exchange = @Exchange(value = WITHDRAW_APPROVE_EXCHANGE, type = "topic", durable = "true"),
            key = WITHDRAW_APPROVE_ROUTING_KEY)})
    public void listenRegister(Message message) {
        try {
            byte[] body = message.getBody();
            String json = new String(body, StandardCharsets.UTF_8);
            log.info("[Withdraw-approve]receive withdraw approve message:{}", json);
            WithdrawApproveMessage withdrawalMessage = JsonUtil.toObject(json, WithdrawApproveMessage.class);
            log.info("[Withdraw-approve]withdraw approve message:{}", withdrawalMessage);

            TAgentWithdrawalRequests requests = new TAgentWithdrawalRequests();
            requests.setRequestId(withdrawalMessage.getRequestId());
            requests.setFlag(withdrawalMessage.getFlag());
            requests.setEndPointType(withdrawalMessage.getEndpoint());
            requests.setEndPointUrl(withdrawalMessage.getEndpointUrl());
            if(withdrawalRequestsService.approval(requests)){
                messageRecordService.saveOrUpdate(new TAgentMessageRecord().builder()
                        .messageId(message.getMessageProperties().getMessageId())
                        .customerId(withdrawalMessage.getCustomerId())
                        .exchange(WITHDRAW_APPROVE_EXCHANGE)
                        .queue(WITHDRAW_APPROVE_QUEUE)
                        .message(json).flag(0).build());
            };
            log.info("[Withdraw-approve]Withdraw finished!");
        } catch (Exception e) {
            log.error("[Withdraw-approve]withdraw approve message", e);
            messageRecordService.save(new TAgentMessageRecord().builder()
                    .messageId(message.getMessageProperties().getMessageId())
                    .exchange(WITHDRAW_APPROVE_EXCHANGE)
                    .queue(WITHDRAW_APPROVE_QUEUE)
                    .message(message.toString()).flag(1).build());
        }
    }
}
