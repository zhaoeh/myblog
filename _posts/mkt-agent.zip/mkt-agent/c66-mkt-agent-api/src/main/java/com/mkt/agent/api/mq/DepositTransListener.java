package com.mkt.agent.api.mq;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cn.schema.creditlogs.WSDepositTrans;
import com.google.gson.Gson;
import com.mkt.agent.api.entity.req.FundTradeReq;
import com.mkt.agent.api.exception.MKTAgentException;
import com.mkt.agent.api.service.DepositTransService;
import com.mkt.agent.api.service.FundService;
import com.mkt.agent.api.service.TAgentCustomersService;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.enums.FundStatusEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import javax.annotation.Resource;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Optional;

@Slf4j
@Component
public class DepositTransListener {

    private static final String DEPOSIT_APPROVE_QUEUE = "C66.officeapp.online.agent.order";

    private static final String DEPOSIT_APPROVE_EXCHANGE = "exchange_online_agent_order";

    private static final String DEPOSIT_APPROVE_ROUTING_KEY = "C66.online.agent.order";

    @Autowired
    private DepositTransService depositTransService;
    @Autowired
    private TAgentCustomersService tAgentCustomersService;
    @Autowired
    private FundService fundService;
    @Resource
    private Gson gson;

    @RabbitListener(bindings = @QueueBinding(
                    value = @Queue(value = DEPOSIT_APPROVE_QUEUE, durable = "true", autoDelete = "false"),
                    exchange = @Exchange(value = DEPOSIT_APPROVE_EXCHANGE, durable = "true", type = "topic"),
                    key = DEPOSIT_APPROVE_ROUTING_KEY))
    public void depositTrans(Message msg) throws IOException {
        if (msg == null) {
            log.info("创建存款交易记录message消息为空");
            return;
        }
        log.info("[Deposit]Receive deposit message:{}", gson.toJson(msg));
        String data = new String(msg.getBody());
        //LOG.info("处理创建存款交易记录Rabbit:{}", data);
        if (StringUtils.isNotBlank(data)) {
            try {
                JSONObject messageJson = JSON.parseObject(data);
                String msgContent = messageJson.getString("msgContent");
                if (StringUtils.isBlank(msgContent)) {
                    log.error("[Deposit]处理创建存款交易记录Rabbit,消息对象为空, 消息内容:{}.", messageJson);
                    return;
                }
                JSONObject messageData = JSON.parseObject(msgContent);
                log.info("[Deposit]处理创建存款交易记录Rabbit:{}", messageData);
                String transCode = Optional.ofNullable(messageData.getString("transCode")).orElse("");
                String endPoint = Optional.ofNullable(messageData.getString("endPoint")).orElse("");
                String requestdomain = Optional.ofNullable(messageData.getString("requestdomain")).orElse("");
                String referenceId = Optional.ofNullable(messageData.getString("referenceId")).orElse("");
                String productId = Optional.ofNullable(messageData.getString("productId")).orElse("");

                String loginName = Optional.ofNullable(messageData.getString("loginName")).orElse("");
                String amount = Optional.ofNullable(messageData.getString("amount")).orElse("0");
                String createdBy = Optional.ofNullable(messageData.getString("createdBy")).orElse("");
                String remarks = Optional.ofNullable(messageData.getString("remarks")).orElse("");
                String supOrderProcess = Optional.ofNullable(messageData.getString("supOrderProcess")).orElse("");
                String depositBy = Optional.ofNullable(messageData.getString("depositor")).orElse("");
                String isChatHelp = Optional.ofNullable(messageData.getString("paySource")).orElse("");
                String handAmount = Optional.ofNullable(messageData.getString("handAmount")).orElse("");
                String btcAmount = Optional.ofNullable(messageData.getString("btcAmount")).orElse("");
                String rate = Optional.ofNullable(messageData.getString("rate")).orElse("");
                String sourceCurrency = Optional.ofNullable(messageData.getString("sourceCurrency")).orElse("");
                String transferPlatform = Optional.ofNullable(messageData.getString("transferPlatform")).orElse("");
                String protocol = Optional.ofNullable(messageData.getString("usdtProtocol")).orElse("");
                Integer orderSource = Optional.ofNullable(messageData.getInteger("orderSource")).orElse(0);
                String channelCode = Optional.ofNullable(messageData.getString("channelCode")).orElse("");
                String ipAddress = Optional.ofNullable(messageData.getString("createdIp")).orElse("");

                WSDepositTrans vo = new WSDepositTrans();
                vo.setTransCode(transCode.replace("\"", ""));
                vo.setEndPoint(endPoint.replace("\"", ""));
                vo.setEndPointUrl(requestdomain.replace("\"", ""));
                vo.setReferenceId(referenceId.replace("\"", ""));
                vo.setProductId(productId.replace("\"", ""));
                vo.setLoginName(loginName.replace("\"", ""));
                vo.setAmount(amount.replace("\"", ""));
                vo.setCreatedBy(createdBy.replace("\"", ""));
                vo.setRemarks(remarks.replace("\"", ""));
                vo.setSupOrderProcess(supOrderProcess.replace("\"", ""));
                vo.setDepositBy(depositBy.replace("\"", ""));
                vo.setIsChatHelp(isChatHelp.replace("\"", ""));
                vo.setSourceCurrency(sourceCurrency.replace("\"", ""));
                vo.setBtcRate(rate.replace("\"", ""));
                vo.setBtcAmount(btcAmount.replace("\"", ""));
                vo.setProtocol(protocol.replace("\"", ""));
                vo.setOrderSource(orderSource);
                vo.setChannelCode(channelCode.replace("\"", ""));
                vo.setIpAddress(ipAddress);
                if (StringUtils.isNotBlank(transferPlatform)) {
                    vo.setTargetPlatform(transferPlatform);
                }
                /*if(StringUtils.isBlank(vo.getSourceCurrency())){
                    WSCustomers customerByLoginName = customerService.getCustomerByLoginname(vo.getLoginName());
                    if(customerByLoginName!=null ){
                        vo.setSourceCurrency(customerByLoginName.getCurrency());
                    }
                }*/
                vo.setSourceCurrency(Constants.DEFAULT_CURRENCY);

                if (StringUtils.isNotBlank(handAmount)) {
                    vo.setAmount(handAmount);
                    vo.setFee(BigDecimal.ZERO.toPlainString());
                }
                log.info("[Deposit] transCode:{},endPoint:{},referenceId:{},loginName:{},amount:{},createBy:{},reamarks:{},supOrderProcess:{},depositBy:{} isChatHelp:{}",
                        transCode, endPoint, referenceId, loginName, amount, createdBy, remarks, supOrderProcess, "*", isChatHelp);

                StopWatch stopWatch = new StopWatch();
                stopWatch.start("hellocreateDepositTrans-start");

                TAgentCustomers customer = tAgentCustomersService.getAgentByLoginName(loginName);
                vo.setCustomerId(customer.getCustomersId().toString());
                depositTransService.apply(vo);

                log.info("[Deposit]insert deposit fund log");
                FundTradeReq fundTradeReqEntity = FundTradeReq.builder()
                        .agentId(customer.getCustomersId())
                        .loginName(loginName)
                        .amount(new BigDecimal(amount))
                        .orderId(referenceId)
                        .build();
                fundService.saveDepositLog(fundTradeReqEntity, FundStatusEnum.Pending);

                stopWatch.stop();
                log.info("[Deposit]Deposit finished! HellocreateDepositTrans-cost:{}", stopWatch.prettyPrint());
            } catch (MKTAgentException e) {
                log.error(e.getLocalizedMessage(), e);
            }
        } else {
            log.error("[Deposit]Rabbit消息, 接收创建存款交易记录失败！");
        }
    }
}