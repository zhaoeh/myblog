package com.mkt.agent.api.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.api.entity.req.TAgentContractQueryReq;
import com.mkt.agent.api.service.TAgentContractBindService;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentContractReq;
import com.mkt.agent.api.entity.resp.TAgentContractResp;
import com.mkt.agent.api.entity.resp.TAgentSettlementResp;
import com.mkt.agent.api.service.TAgentContractService;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.agentapi.responses.TAgentContractDictionaryResp;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.BeanCopyUtil;
import com.mkt.agent.common.utils.SerializationUti;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;


/**
 * @ClassName TAgentContractController
 * @Description 佣金方案
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@RestController
@RequestMapping("/agentContract")
@Validated
public class TAgentContractController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private TAgentContractService tAgentContractService;

    @Resource
    private TAgentContractBindService tAgentContractBindService;

    @PostMapping(value = "/create")
    @ApiOperation(value = "创建佣金方案", notes = "创建佣金方案")
    public Result create(@Validated(value = InputValidationGroup.Insert.class) @RequestBody TAgentContractReq tAgentContractReq) {
        try {
            logger.info("/agentContract/create 入参tAgentContractReq：{} 返回值：void", tAgentContractReq.toString());
            tAgentContractService.create(tAgentContractReq);
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/agentContract/create 出异常了，入参tAgentContractReq：{} 异常信息：{}", tAgentContractReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @PostMapping(value = "/queryList")
    @ApiOperation(value = "查询佣金方案", notes = "查询佣金方案")
    public Result<Page<TAgentContractResp>> queryList(@RequestBody @Validated TAgentContractQueryReq tAgentContractQueryReq) {
        try {
            Page<TAgentContractResp> resp = tAgentContractService.queryList(tAgentContractQueryReq);
            logger.info("/agentContract/queryList 入参tAgentContractQueryReq：{} 返回值：{}", tAgentContractQueryReq.toString(), resp.getRecords().toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentContract/queryList 出异常了，入参tAgentContractQueryReq：{} 异常信息：{}", tAgentContractQueryReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @PostMapping(value ="/queryRealContractByLoginName")
    @ApiOperation(value = "查询代理佣金方案", notes = "查询代理佣金方案")
    public Result<TAgentContract> queryRealContractByLoginName(@NotNull(message = "loginName is not null") String loginName) {
        try {
            //通过loginName查询绑定信息
            TAgentContractBind contractBind = tAgentContractBindService.queryTAgentContractBindByLoginName(loginName);

            //查询佣金方案
            TAgentContract agentContract = tAgentContractService.selectOne(contractBind.getCommissionContractId());
            //设置实际佣金比例
            agentContract.setPercentageDetails(contractBind.getPercentageDetails());
            agentContract.setSettlementPercentageList(SerializationUti.deserializeFromString(contractBind.getPercentageDetails(),SettlementPercentageReq.class));

            return Result.success(agentContract);
        } catch (Exception e) {
            logger.error("/agentContractBind/queryPercentageDetails 出异常了，入参currentCustomersId：{} 异常信息：{}", loginName, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping(value ="/queryContractByLoginName")
    @ApiOperation(value = "查询代理佣金方案", notes = "查询代理佣金方案")
    public Result<TAgentContract> queryContractByLoginName(@NotNull(message = "loginName is not null") String loginName) {
        try {
            //通过loginName查询绑定信息
            TAgentContractBind contractBind = tAgentContractBindService.queryTAgentContractBindByLoginName(loginName);

            //查询佣金方案
            TAgentContract agentContract = tAgentContractService.selectOne(contractBind.getCommissionContractId());

            return Result.success(agentContract);
        } catch (Exception e) {
            logger.error("/agentContractBind/queryPercentageDetails 出异常了，入参currentCustomersId：{} 异常信息：{}", loginName, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @PostMapping(value = "/update")
    @ApiOperation(value = "编辑佣金方案", notes = "编辑佣金方案")
    public Result update(@RequestBody @Validated(value = InputValidationGroup.Update.class) TAgentContractReq tAgentContractReq) {
        try {
            logger.info("/agentContract/update 入参tAgentContractReq：{} 返回值：void", tAgentContractReq.toString());
            tAgentContractService.update(tAgentContractReq);
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/agentContract/update 出异常了，入参tAgentContractReq：{} 异常信息：{}", tAgentContractReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @GetMapping(value = "/updateAgentCountById")
    @ApiOperation(value = "编辑佣金方案代理总数", notes = "编辑佣金方案代理总数")
    public Result updateAgentCountById(Long id) {
        try {
            logger.info("/agentContract/updateAgentCountById 入参id：{} 返回值：void", id);
            // tAgentContractService.updateAgentCountById(id);
            tAgentContractService.updateAgentCountByIdV1(id);
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/agentContract/updateAgentCountById 出异常了，入参id：{} 异常信息：{}", id, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @GetMapping(value = "/queryListByPeriod")
    @ApiOperation(value = "通过周期查询佣金方案", notes = "通过周期查询佣金方案")
    public Result<List<TAgentSettlementResp>> queryListByPeriod(@NotBlank(message = "settlementPeriod is not null") String settlementPeriod) {
        try {
            List<TAgentSettlementResp> resp = tAgentContractService.queryListByPeriod(settlementPeriod);
            logger.info("/agentContract/queryListByPeriod 入参settlementPeriod：{} 返回值：{}", settlementPeriod, resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentContract/queryListByPeriod 出异常了，入参settlementPeriod：{} 异常信息：{}", settlementPeriod, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @PostMapping(value = "/export")
    @ApiOperation(value = "佣金方案导出", notes = "佣金方案导出")
    public Result export(@RequestBody @Validated TAgentContractQueryReq tAgentContractQueryReq, HttpServletResponse response) {
        try {
            logger.info("/agentContract/export 入参tAgentContractQueryReq：{} 返回值：void", tAgentContractQueryReq.toString());
            tAgentContractService.export(tAgentContractQueryReq, response);
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/agentContract/export 出异常了，入参tAgentContractQueryReq：{} 异常信息：{}", tAgentContractQueryReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @GetMapping(value = "/delete")
    @ApiOperation(value = "逻辑删除佣金方案", notes = "逻辑删除佣金方案")
    public Result delete(@NotNull(message = "id is not null") Long id) {
        try {
            logger.info("/agentContract/delete 入参id：{} 返回值：void", id);
            tAgentContractService.delete(id);
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/agentContract/delete 出异常了，入参id：{} 异常信息：{}", id, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @GetMapping(value = "/queryNameList")
    @ApiOperation(value = "查询佣金方案", notes = "查询佣金方案")
    public Result<List<TAgentContractDictionaryResp>> queryNameList(@NotBlank(message = "contract name is not null") String contractName) {
        try {
            List<TAgentContractDictionaryResp> resp = tAgentContractService.queryNameList(contractName);
            logger.info("/agentContract/queryNameList 入参contractName：{} 返回值：{}", contractName, resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentContract/queryNameList 出异常了，入参contractName：{} 异常信息：{}", contractName, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

}



