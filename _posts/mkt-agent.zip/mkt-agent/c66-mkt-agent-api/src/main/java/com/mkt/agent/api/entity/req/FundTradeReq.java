package com.mkt.agent.api.entity.req;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @ClassName FundTradeReq
 * @Description 充值，提款
 * @Author TJSAlex
 * @Date 2023/5/26 11:24
 * @Version 1.0
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FundTradeReq implements Serializable {
    @ApiModelProperty(value = "agentId")
    @NotNull(message = "agentId is required!")
    private Long agentId;
    @ApiModelProperty(value = "loginName")
    @NotNull(message = "loginName is required!")
    private String loginName;
    @ApiModelProperty(value = "amount")
    @NotNull(message = "amount is required!")
    @DecimalMin(value = "0.000000",message = "amount format is incorrect!")
    private BigDecimal amount;
    @ApiModelProperty(value = "orderId",hidden = true)
    @NotNull(message = "orderId is required!")
    private String orderId;
    @ApiModelProperty(value = "isApprove",hidden = true)
    private Boolean isApprove;
}
