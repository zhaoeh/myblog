package com.mkt.agent.api.entity.req;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @ClassName FundTradeReq
 * @Description 充值，提款
 * @Author TJSAlex
 * @Date 2023/5/26 11:24
 * @Version 1.0
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FundTradeReq implements Serializable {
    @ApiModelProperty(value = "agentId")
    @NotNull(message = "agentId不能为空")
    private Long agentId;
    @ApiModelProperty(value = "loginName")
    @NotNull(message = "loginName不能为空")
    private String loginName;
    @ApiModelProperty(value = "amount")
    @NotNull(message = "amount不能为空")
    @DecimalMin(value = "0.000000",message = "amount格式不正确")
    private BigDecimal amount;
    @ApiModelProperty(value = "orderId",hidden = true)
    @NotNull(message = "orderId不能为空")
    private String orderId;
    @ApiModelProperty(value = "isApprove",hidden = true)
    private Boolean isApprove;
}
