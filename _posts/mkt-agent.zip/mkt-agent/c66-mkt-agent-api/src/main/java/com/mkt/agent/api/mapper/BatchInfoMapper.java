package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.BatchInfo;
import com.mkt.agent.common.entity.BatchInfoExample;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface BatchInfoMapper extends BaseMapper<BatchInfo> {
    long countByExample(BatchInfoExample example);

    int deleteByExample(BatchInfoExample example);

    int deleteByPrimaryKey(Long id);

    int insert(BatchInfo row);

    Long insertSelective(BatchInfo row);

    List<BatchInfo> selectByExample(BatchInfoExample example);

    BatchInfo selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("row") BatchInfo row, @Param("example") BatchInfoExample example);

    int updateByExample(@Param("row") BatchInfo row, @Param("example") BatchInfoExample example);

    int updateByPrimaryKeySelective(BatchInfo row);

    int updateByPrimaryKey(BatchInfo row);

    int updateAsyncDataById(@Param("batchInfo") BatchInfo batchInfo);
}