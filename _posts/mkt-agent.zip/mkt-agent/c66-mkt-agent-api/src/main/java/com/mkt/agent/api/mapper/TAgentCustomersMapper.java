package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomersReq;
import com.mkt.agent.api.entity.req.TAgentCustomersQueryReq;
import com.mkt.agent.api.entity.resp.TAgentCustomersResp;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerGateResp;
import com.mkt.agent.common.entity.api.userapi.requests.AgentListCopyRequest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @ClassName AgentMapper
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Mapper
public interface TAgentCustomersMapper extends BaseMapper<TAgentCustomers> {

    public List<TAgentCustomersResp> queryList(@Param("req") TAgentCustomersQueryReq tAgentCustomersQueryReq);

    public List<TAgentCustomersResp> queryListBp(@Param("req") TAgentCustomersQueryReq tAgentCustomersQueryReq);

    public Integer countBp(@Param("req") TAgentCustomersQueryReq tAgentCustomersQueryReq);

    public List<TAgentCustomersResp> getAgentTree(@Param("req") TAgentCustomersQueryReq tAgentCustomersQueryReq);

    public Integer count(@Param("req") TAgentCustomersQueryReq tAgentCustomersQueryReq);

    public List<TAgentCustomers> getAgentByCustomerIds(@Param("list") List<Long> list);

    public void cancelAgentBatchById(@Param("list") List<TAgentCustomers> list);

    public AgentCustomerGateResp getAgentAndContractByCustomerId(Long customerId);

    public TAgentCustomers getCancelAgentByCustomerId(Long customerId);

    public void updateCancelAgentToAgent(@Param("req") TAgentCustomers TAgentCustomers);

    public List<TAgentCustomers> getAgentList(@Param("req") AgentListCopyRequest agentListRequest);

    public List<String> queryAgentCustomers(@Param("req") AgentCustomersReq agentCustomersReq);

    public Integer queryAgentCustomersCount(@Param("req") AgentCustomersReq agentCustomersReq);

    public Integer selectTotalAgents( @Param(value = "parent") String parent);

    public Integer selectDirectAgents( @Param(value = "parent") String parent);


}
