package com.mkt.agent.api.mq.msg;

import lombok.Data;

import java.math.BigDecimal;

/*{
     "agentId": 1,
     "loginName": "jason",
     "amount": 1,
     "isApprove": false,
 }*/


@Data
public class WithdrawApproveMessage {
    private String loginName;
    private String flag;
    private String requestId;
    private Long customerId;
    private String endpoint;
    private String endpointUrl;
}
