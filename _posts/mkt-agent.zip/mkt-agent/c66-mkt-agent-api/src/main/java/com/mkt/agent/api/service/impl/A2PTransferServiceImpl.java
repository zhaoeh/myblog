package com.mkt.agent.api.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.mkt.agent.api.mapper.A2PTransferMapper;
import com.mkt.agent.api.mapper.TAgentCustomersMapper;
import com.mkt.agent.api.mapper.TCustomerLayerMapper;
import com.mkt.agent.api.service.A2PTransferService;
import com.mkt.agent.api.service.ATransferTransactionService;
import com.mkt.agent.common.entity.api.atransferapi.A2PTransferEntity;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.atransferapi.request.A2PTransferListReq;
import com.mkt.agent.common.entity.api.atransferapi.request.A2PTransferReq;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.integration.entities.PageModelExt;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @Description TODO
 * @Classname A2PTransferServiceImpl
 * @Date 2023/6/21 19:27
 * @Created by TJSLucian
 */
@Service
@Slf4j
public class A2PTransferServiceImpl implements A2PTransferService {

    @Resource
    private TAgentCustomersMapper tAgentCustomersMapper;

    @Autowired
    private TCustomerLayerMapper tCustomerLayerMapper;

    @Resource
    private ATransferTransactionService aTransferTransactionService;

    @Resource
    private A2PTransferMapper a2PTransferMapper;

    @Override
    public synchronized Result<Boolean> createA2PTrans(A2PTransferReq req) throws Exception{

        log.info("进入代理转玩家模块 参数：{}",req.toString());

        //判断代理和玩家是否存在
        checkAPExist(req.getFromId(),req.getToId());

        // 2. 给代理扣钱 给玩家加钱 修改订单状态,账变记录状态
        aTransferTransactionService.a2pTransfer(req);

        return Result.success(true);
    }

    @Override
    public Result<PageModelExt<A2PTransferEntity>> queryA2PTransList(A2PTransferListReq req) {
        Result<PageModelExt<A2PTransferEntity>> response = new Result<>();

        PageModelExt<A2PTransferEntity> pageModel = new PageModelExt<>();

        //mybatis版本问题 不能在xml文件中判空
        req.setStartCreateTime(StringUtils.isNotBlank(req.getStartCreateTime()+"")?req.getStartCreateTime():null);
        req.setEndCreateTime(StringUtils.isNotBlank(req.getEndCreateTime()+"")?req.getEndCreateTime():null);

        req.setOrder(StringUtils.defaultIfBlank(req.getOrder(), "t.create_time desc"));

        Integer count = a2PTransferMapper.queryListCount(req);

        if(count > 0){
            List<A2PTransferEntity> list = a2PTransferMapper.queryList(req);

            double subAmount = list.stream().mapToDouble(tran -> Double.valueOf(Double.valueOf(tran.getAmount().toString()))).sum();
            Map sumResult = a2PTransferMapper.sumByCondition(req);

            Map statistics = new HashMap();
            statistics.put("subAmount", subAmount);
            statistics.put("totalAmount", sumResult.get("AMOUNT").toString());
            statistics.put("totalAccount", sumResult.get("ACCOUNT").toString());

            pageModel.setStatistics(statistics);
            pageModel.setData(list);
        }

        pageModel.setPageNo(req.getPageNum());
        pageModel.setPageSize(req.getPageSize());
        pageModel.setTotalRow(count);

        response.setData(pageModel);

        return response;
    }

    private void checkAPExist(Long agentId, Long playerId){
        TAgentCustomers agent = tAgentCustomersMapper.selectOne(new LambdaQueryWrapper<TAgentCustomers>()
                .eq(TAgentCustomers::getCustomersId, agentId).eq(TAgentCustomers::getIsDeleted, 0));

        if(Objects.isNull(agent)){
            throw new BusinessException("agent or player does not exist!");
        }

        TCustomerLayer customer = tCustomerLayerMapper.selectOne(new LambdaQueryWrapper<TCustomerLayer>().eq(TCustomerLayer::getCustomerId,playerId));

        if (Objects.isNull(customer)) {
            throw new BusinessException("agent or player does not exist!");
        }
    }

    /**
     * description: 校验是否是第一次转账，0: 否 1：是
     * @param:  [playerId]
     * @return: java.lang.Boolean
     * @Date: 2023/6/26 14:39
     * @Version: 1.0.0
     * @Author: Lucian
     */
    private Integer checkIsFirst(Long playerId){

        List<A2PTransferEntity> entity = a2PTransferMapper.selectList(new LambdaQueryWrapper<A2PTransferEntity>().eq(A2PTransferEntity::getToId,playerId));

        return null == entity || entity.size()==0 ? 1 : 0;

    }



}
