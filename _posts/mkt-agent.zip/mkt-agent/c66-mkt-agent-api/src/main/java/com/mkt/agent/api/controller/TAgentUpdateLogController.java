package com.mkt.agent.api.controller;

import com.mkt.agent.api.service.TAgentUpdateLogService;
import com.mkt.agent.common.entity.api.agentapi.TAgentUpdateLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Description TODO
 * @Classname TAgentUpdateLogController
 * @Date 2023/12/8 18:17
 * @Created by TJSLucian
 */
@RestController
@RequestMapping("/agent_update")
public class TAgentUpdateLogController {

    @Autowired
    private TAgentUpdateLogService agentUpdateLogService;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @PostMapping(value = "/getFrashBaName")
    public TAgentUpdateLog getFrashBaName(@RequestParam("loginName")String loginName){
        return agentUpdateLogService.getFrashBaName(loginName);
    }

    @PostMapping(value = "/updateBaName")
    public void updateByName(@RequestParam("loginName")String loginName){
        agentUpdateLogService.updateByName(loginName);
    }

    @PostMapping(value = "/saveList")
    public void saveList(@RequestBody List<String> names){
        agentUpdateLogService.saveList(names);
    }


}
