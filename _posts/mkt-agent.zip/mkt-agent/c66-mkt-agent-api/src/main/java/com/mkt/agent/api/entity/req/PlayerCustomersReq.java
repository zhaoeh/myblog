package com.mkt.agent.api.entity.req;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @ClassName TAgentCustomersReq
 * @Author TJSAustin
 * @Date 2023/6/6 10:00
 * @Version 1.0
 **/
@Data
@NoArgsConstructor
@ToString(exclude = {"password"})
public class PlayerCustomersReq {

    /**
     * 登录名
     */
    @ApiModelProperty(value = "登录名")
    @NotBlank(message = "account can not be empty")
    private String account;

    /**
     * 产品
     */
    @ApiModelProperty(value = "所属产品")
    @NotBlank(message = "productId id can not be empty")
    private String productId;

    /**
     * 父级代理
     */
    @ApiModelProperty(value = "父级代理")
    @NotNull(message = "parent Id can not be empty")
    private Long parentId;

    /**
     * 密码
     */
    @ApiModelProperty(value = "密码")
    @NotNull(message = "password can not be empty")
    private String password;

    /**
     * 创建人
     */
    @ApiModelProperty(value = "创建人")
    @NotNull(message = "createdBy can not be empty")
    private String createdBy;

    /**
     * ip
     */
    @ApiModelProperty(value = "创建人")
    @NotNull(message = "ip can not be empty")
    private String ip;

    @ApiModelProperty(value = "当前登录者")
    private String loginName;

}
