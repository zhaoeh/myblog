package com.mkt.agent.api.entity.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.Map;

/**
 * @ClassName GlobalConfigReq
 * @Description 全局配置入参
 * @Author TJSAlex
 * @Date 2023/5/22 16:28
 * @Version 1.0
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ConfigDto implements Serializable {
    @ApiModelProperty(value = "paramName")
    @NotBlank(message = "paramName不能为空")
    private String paramName;
    @ApiModelProperty(value = "paramValue")
    @NotBlank(message = "paramValue不能为空")
    private String paramValue;

    private Map<String,String> siteMap;
}
