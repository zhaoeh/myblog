package com.mkt.agent.api.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.mkt.agent.api.mapper.TAgentCustomersMapper;
import com.mkt.agent.api.service.BaseFundService;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.exception.BusinessException;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Objects;

/**
 * @ClassName BaseFundServiceImpl
 * @Author TJSAlex
 * @Date 2023/6/28 16:31
 * @Version 1.0
 **/
@Service
public class BaseFundServiceImpl implements BaseFundService {
    @Resource
    private TAgentCustomersMapper tAgentCustomersMapper;

    @Override
    public void checkAgentRelationship(Long parentId, Long childId) {
        TAgentCustomers customer = tAgentCustomersMapper.selectOne(new LambdaQueryWrapper<TAgentCustomers>()
                .eq(TAgentCustomers::getCustomersId, childId).eq(TAgentCustomers::getParentId, parentId).eq(TAgentCustomers::getIsDeleted, 0));
        TAgentCustomers customer2 = tAgentCustomersMapper.selectOne(new LambdaQueryWrapper<TAgentCustomers>()
                .eq(TAgentCustomers::getCustomersId, parentId).eq(TAgentCustomers::getParentId, childId).eq(TAgentCustomers::getIsDeleted, 0));
        if (Objects.isNull(customer) && Objects.isNull(customer2)) {
            throw new BusinessException("代理层级关系错误");
        }
    }

    @Override
    public TAgentCustomers getParentByLoginName(String loginName) {
        TAgentCustomers customer = tAgentCustomersMapper.selectOne(new LambdaQueryWrapper<TAgentCustomers>().eq(TAgentCustomers::getLoginName, loginName)
                .eq(TAgentCustomers::getIsDeleted, 0));
        if (Objects.isNull(customer)) {
            throw new BusinessException("代理用户不存在");
        }
        return customer;
    }
}
