package com.mkt.agent.api.entity.req;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.enums.CustomizedValidationContents;
import com.mkt.agent.common.valid.EnumValid;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @ClassName TAgentCustomersReq
 * @Author TJSAustin
 * @Date 2023/5/25 10:00
 * @Version 1.0
 **/
@Data
@NoArgsConstructor
public class TAgentCustomersReq {

    /*
        主键
    */
    @ApiModelProperty(value = "id")
    private Long id;

    /*
        登录名
    */
    @ApiModelProperty(value = "登录名")
    @Size(max = 16, min = 4, message = "玩家账号长度必须大于等于4或小于等于16")
    private String loginName;

    /*
        产品
   */
    @ApiModelProperty(value = "所属产品C66")
    private String productId;


    /*
        佣金方案code
    */
    @ApiModelProperty(value = "佣金方案code")
    private Long commissionContractCode;

    /*
        父级代理
   */
    @ApiModelProperty(value = "父级代理")
    private String parentId;

    /*
        密码
   */
    @ApiModelProperty(value = "密码")
    @Size(max = 16, min = 8, message = "玩家密码长度必须大于等于8或小于等于16")
    private String pwd;


    /*
        代理类型 0:普通,1:专业代理
    */
    @ApiModelProperty(value = "代理类型 0:普通,1:专业代理")
    private Integer agentType;


    /*
        代理可以发展最大下级代理层数
    */
    @ApiModelProperty(value = "可发展最大下级代理层数 0,1,2,3,4")
    private Integer developableLevel;

    /*
        启用标识 0:启用 1:禁用
    */
    @ApiModelProperty(value = "启用标识 0禁用，1启用")
    private Integer isEnable;

    /*
        Referral ID
    */
    @ApiModelProperty(value = "Referral ID")
    private String referralId;

    /*
         创建人
    */
    @ApiModelProperty(value = "创建人")
    private String createBy;


    /*
        创建时间
    */
    @Column(name = "CREATE_TIME", nullable = false)
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private LocalDateTime createTime;

    /*
        修改人
    */
    @ApiModelProperty(value = "编辑者")
    private String updateBy;

    /*
        修改时间
    */
    @Column(name="UPDATE_TIME")
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private LocalDateTime updateTime;


    /*
        customersId
    */
    @ApiModelProperty(name="CUSTOMERS_ID")
    private Long customersId;



    /*
        备注
    */
    @Column(name="remark")
    private String remark;

    @ApiModelProperty(value = "siteId 1:Bingoplus  2:Arenaplus  3:Gameplus")
    @EnumValid(contents = CustomizedValidationContents.site_id_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class} )
    private Integer siteId;


    @ApiModelProperty(value = "佣金比例集合")
    private List<SettlementPercentageReq> settlementPercentageList;

    @Override
    public String toString() {
        return "AgentReq{" +
                "id=" + id +
                ", loginName='" + loginName + '\'' +
                ", productId='" + productId + '\'' +
                ", commissionContractCode='" + commissionContractCode + '\'' +
                ", parentId=" + parentId +
                ", agentType=" + agentType +
                ", developableLevel=" + developableLevel +
                ", isEnable=" + isEnable +
                ", createBy='" + createBy + '\'' +
                ", createTime=" + createTime +
                ", updateBy='" + updateBy + '\'' +
                ", updateTime=" + updateTime +
                ", remark='" + remark + '\'' +
                ", siteId='" + siteId + '\'' +
                '}';
    }
}
