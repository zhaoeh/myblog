package com.mkt.agent.api.mapper;

import com.mkt.agent.common.entity.api.agentapi.TAgentCustomersBranch;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Description TODO
 * @Classname TAgentUpdateLogMapper
 * @Date 2023/12/8 18:15
 * @Created by TJSLucian
 */
@Mapper
public interface TAgentCustomersBranchMapper extends BatchInsertCommonMapper<TAgentCustomersBranch> {

}
