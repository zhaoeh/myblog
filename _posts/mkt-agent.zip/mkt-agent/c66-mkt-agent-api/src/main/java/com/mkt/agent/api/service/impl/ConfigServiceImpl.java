package com.mkt.agent.api.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.mkt.agent.api.entity.TAgentGlobalConfig;
import com.mkt.agent.api.entity.dto.ConfigDto;
import com.mkt.agent.api.mapper.ConfigMapper;
import com.mkt.agent.api.service.ConfigService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @ClassName ConfigServiceImpl
 * @Author TJSAlex
 * @Date 2023/5/22 16:36
 * @Version 1.0
 **/
@Service
public class ConfigServiceImpl implements ConfigService {

    @Resource
    private ConfigMapper configMapper;

    @Override
    public boolean save(ConfigDto req) {
        String paramName = req.getParamName();
        String paramValue = req.getParamValue();
        LambdaQueryWrapper<TAgentGlobalConfig> wrapper = new LambdaQueryWrapper<TAgentGlobalConfig>()
                .eq(TAgentGlobalConfig::getParamName, paramName).eq(TAgentGlobalConfig::getIsEnable,1);
        TAgentGlobalConfig tAgentGlobalConfig = configMapper.selectOne(wrapper);
        if (Objects.isNull(tAgentGlobalConfig)) {
            tAgentGlobalConfig = TAgentGlobalConfig.builder().paramName(paramName).paramValue(paramValue).build();
            int insert = configMapper.insert(tAgentGlobalConfig);
            return insert != 0;
        }
        if (tAgentGlobalConfig.getIsEnable() == 1 && !StringUtils.equals(tAgentGlobalConfig.getParamValue(),req.getParamValue())) {
            tAgentGlobalConfig.setParamValue(paramValue);
            int insert = configMapper.updateById(tAgentGlobalConfig);
            return insert != 0;
        }
        return false;
    }

    @Override
    public boolean del(ConfigDto req) {
        String paramName = req.getParamName();
        LambdaQueryWrapper<TAgentGlobalConfig> wrapper = new LambdaQueryWrapper<TAgentGlobalConfig>()
                .eq(TAgentGlobalConfig::getParamName, paramName).eq(TAgentGlobalConfig::getIsEnable, 1);
        TAgentGlobalConfig config = configMapper.selectOne(wrapper);
        if (Objects.nonNull(config)) {
            config.setIsEnable(0);
            int update = configMapper.updateById(config);
            return update != 0;
        }
        return false;
    }

    @Override
    public List<ConfigDto> list() {
        List<TAgentGlobalConfig> list = configMapper.selectList(new LambdaQueryWrapper<TAgentGlobalConfig>()
                .eq(TAgentGlobalConfig::getIsEnable, 1));
        return convert(list);
    }

    private List<ConfigDto> convert(List<TAgentGlobalConfig> list) {
        return list.stream().map(c -> {
            ConfigDto dto = new ConfigDto(c.getParamName(), c.getParamValue(),null);
            return dto;
        }).collect(Collectors.toList());
    }
}
