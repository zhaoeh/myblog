package com.mkt.agent.api;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.retry.annotation.Retryable;
import org.springframework.transaction.annotation.Transactional;

@SpringBootApplication(scanBasePackages = {"com.mkt.agent.api","com.mkt.agent.common","com.mkt.agent.integration"})
@EnableDiscoveryClient
@EnableFeignClients
@Retryable
@Transactional
public class AgentApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(AgentApiApplication.class);
    }
}
