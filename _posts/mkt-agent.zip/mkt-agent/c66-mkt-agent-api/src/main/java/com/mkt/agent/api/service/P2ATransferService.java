package com.mkt.agent.api.service;

import com.mkt.agent.common.entity.api.atransferapi.P2ATransferEntity;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.atransferapi.request.P2ATransferListReq;
import com.mkt.agent.common.entity.api.atransferapi.request.P2ATransferReq;
import com.mkt.agent.common.entity.api.atransferapi.request.P2ATransferVerifyReq;
import com.mkt.agent.integration.entities.PageModelExt;

/**
 * @Description TODO
 * @Classname A2ATransferService
 * @Date 2023/6/21 13:57
 * @Created by TJSLucian
 */
public interface P2ATransferService {

    Result<PageModelExt<P2ATransferEntity>> queryP2ATransList(P2ATransferListReq req);

    Result<Boolean> createP2ATrans(P2ATransferReq req) throws Exception;

    Result<Boolean> verifyP2ATrans(P2ATransferVerifyReq req) throws Exception;

}
