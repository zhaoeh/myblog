package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.atransferapi.A2ATransferEntity;
import com.mkt.agent.common.entity.api.atransferapi.request.A2ATransferListReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.List;

/**
 * @Description TODO
 * @Classname A2ATransferMapper
 * @Date 2023/6/22 13:38
 * @Created by TJSLucian
 */
@Mapper
public interface A2ATransferMapper extends BaseMapper<A2ATransferEntity> {

    Integer queryListCount(@Param("req") A2ATransferListReq req);

    List<A2ATransferEntity> queryList(@Param("req") A2ATransferListReq req);

    BigDecimal sumByCondition(@Param("req") A2ATransferListReq req);

    Integer updateStatus(@Param("entity")A2ATransferEntity entity);

}
