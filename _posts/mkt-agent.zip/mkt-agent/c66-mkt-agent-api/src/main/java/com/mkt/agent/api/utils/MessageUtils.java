package com.mkt.agent.api.utils;

import com.mkt.agent.common.utils.NumberUtils;

/**
 * @Description TODO
 * @Classname MessageUtils
 * @Date 2023/9/9 17:42
 * @Created by TJSLucian
 */
public class MessageUtils {


    public static String msgIdGeneratorForTransfer(String fromToType,String productId,Long timeStamp){
        StringBuilder sb = new StringBuilder();
        sb.append(fromToType).append("|").append(productId).append("|").append(timeStamp).append("|").append(NumberUtils.getRNum(10));
        return sb.toString();
    }

}
