package com.mkt.agent.api.controller;

import com.mkt.agent.api.entity.dto.ConfigDto;
import com.mkt.agent.api.service.ConfigService;
import com.mkt.agent.common.entity.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @ClassName GlobalConfigController
 * @Description 全局配置设置
 * @Author TJSAlex
 * @Date 2023/5/22 15:55
 * @Version 1.0
 **/
@RestController
@RequestMapping("/config")
public class ConfigController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ConfigService configService;

    @PostMapping("/save")
    public Result<Boolean> save(@RequestBody @Validated ConfigDto req) {
        try {
            boolean success = configService.save(req);
            logger.info("/config/save 入参ConfigDto：{} 返回值：{}", req.toString(), success);
            return Result.success(success);
        } catch (Exception e) {
            logger.error("/config/save 出异常了，入参ConfigDto：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping("/del")
    public Result<Boolean> del(@RequestBody @Validated ConfigDto req) {
        try {
            boolean success = configService.del(req);
            logger.info("/config/del 入参ConfigDto：{} 返回值：{}", req.toString(), success);
            return Result.success(success);
        } catch (Exception e) {
            logger.error("/config/del 出异常了，入参ConfigDto：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @GetMapping("/list")
    public Result<List<ConfigDto>> list() {
        try {
            List<ConfigDto> list = configService.list();
            list.stream().map(c -> {
                Map<String, String> hashMap = new HashMap<>();
                hashMap.put(c.getParamName(), c.getParamValue());
                c.setSiteMap(hashMap);
                return c;
            }).collect(Collectors.toList());
            logger.info("/config/list 入参：void 返回值：{}", list.toString());
            return Result.success(list);
        } catch (Exception e) {
            logger.error("/config/list 出异常了，入参：void 异常信息：{}", e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }
}
