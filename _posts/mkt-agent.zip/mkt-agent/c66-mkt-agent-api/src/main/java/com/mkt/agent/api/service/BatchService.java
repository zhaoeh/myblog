package com.mkt.agent.api.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.dto.BatchAccountInfoDTO;
import com.mkt.agent.common.entity.BatchRecord;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.agentapi.requests.BatchQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentCustomersBatchReq;
import com.mkt.agent.common.entity.api.agentapi.responses.BatchQueryResp;
import com.mkt.agent.common.entity.api.userapi.requests.PlayerCustomersBatchReq;
import com.mkt.agent.common.entity.api.userapi.responses.PlayerCustomersBatchResp;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 批量创建用户、代理 逻辑
 * 最终会调用
 * com.mkt.agent.api.service.TAgentCustomersService#create(com.mkt.agent.api.entity.req.TAgentCustomersReq, javax.servlet.http.HttpServletRequest)
 * com.mkt.agent.api.service.PlayerCustomersService#create(com.mkt.agent.api.entity.req.PlayerCustomersReq)
 * 进行单独远程创建
 * 此service用于管理创建结果以及落库
 */
public interface BatchService {
    byte BATCH_TYPE_AGENT = 1;
    byte BATCH_TYPE_PLAYER = 2;

    Page<BatchQueryResp> queryBatchInfo(BatchQueryRequest request);

    List<BatchRecord> getBatchRecords(long batchId);

    List<BatchAccountInfoDTO> queryBatchAccountsByBatchId(long batchId);

    Result<Boolean> createTopAgentByBatch(TAgentCustomersBatchReq tAgentCustomersBatchReq, HttpServletRequest request) throws InterruptedException;

    Result<Boolean> batchCreate(PlayerCustomersBatchReq playerCustomersBatchReq) throws InterruptedException;


}
