package com.mkt.agent.api.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.api.entity.req.TAgentCustomersQueryReq;
import com.mkt.agent.api.entity.req.TAgentCustomersReq;
import com.mkt.agent.api.entity.resp.TAgentCustomersResp;
import com.mkt.agent.api.service.BatchService;
import com.mkt.agent.api.service.TAgentCustomersService;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.dto.BatchAccountInfoDTO;
import com.mkt.agent.common.entity.BatchRecord;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomersReq;
import com.mkt.agent.common.entity.api.agentapi.requests.BatchQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentCustomersBatchReq;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentCustomersRemarkReq;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerGateResp;
import com.mkt.agent.common.entity.api.agentapi.responses.BatchQueryResp;
import com.mkt.agent.common.entity.api.agentapi.responses.TAgentCustomersFrontResp;
import com.mkt.agent.common.entity.api.agentapi.responses.UserResp;
import com.mkt.agent.common.entity.api.userapi.requests.AgentListRequest;
import com.mkt.agent.common.entity.api.userapi.responses.PlayerCustomersBatchResp;
import com.mkt.agent.common.entity.clickhouse.req.DashBoardUserTreeQueryReq;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.IPUtils;
import com.mkt.agent.common.utils.UserContext;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.*;


/**
 * @ClassName AgentController
 * @Description 代理
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@RestController
@RequestMapping("/agentCustomers")
@Validated
public class TAgentCustomersController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private TAgentCustomersService tAgentCustomersService;
    @Resource
    private BatchService batchService;

    @PostMapping(value = "/create")
    @ApiOperation(value = "创建代理", notes = "创建代理")
    public Result create(@RequestBody TAgentCustomersReq tAgentCustomersReq, HttpServletRequest request) {
        logger.info("/agentCustomers/create 入参tAgentCustomersReq：{} 返回值：void", tAgentCustomersReq.toString());
        tAgentCustomersService.create(tAgentCustomersReq, IPUtils.getRequestIP(request),null);
        return Result.success(ResultEnum.SUCCESS);
    }

    @PostMapping(value = "/queryAllAgent")
    @ApiOperation(value = "代理查询", notes = "代理查询")
    public Result<Page<TAgentCustomersResp>> queryAllAgent(@RequestBody @Validated(value = InputValidationGroup.Query.class) TAgentCustomersQueryReq tAgentCustomersQueryReq) {
        try {
            Page<TAgentCustomersResp> resp = tAgentCustomersService.queryList(tAgentCustomersQueryReq);
            logger.info("/agentCustomers/queryAllAgent 入参tAgentCustomersQueryReq：{} 返回值：{}", tAgentCustomersQueryReq.toString(), resp.getRecords().toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentCustomers/queryAllAgent 出异常了，入参tAgentCustomersQueryReq：{} 异常信息：{}", tAgentCustomersQueryReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping(value = "/queryAllAgentBP")
    @ApiOperation(value = "代理前台查询", notes = "代理前台查询")
    public Result<Page<TAgentCustomersResp>> queryAllAgentBP(@RequestBody @Validated(value = InputValidationGroup.Query.class) TAgentCustomersQueryReq tAgentCustomersQueryReq) {
        try {
            Page<TAgentCustomersResp> resp = tAgentCustomersService.queryListBP(tAgentCustomersQueryReq);
            logger.info("/agentCustomers/queryAllAgent 入参tAgentCustomersQueryReq：{} 返回值：{}", tAgentCustomersQueryReq.toString(), resp.getRecords().toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentCustomers/queryAllAgent 出异常了，入参tAgentCustomersQueryReq：{} 异常信息：{}", tAgentCustomersQueryReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }
    @PostMapping(value = "/update")
    @ApiOperation(value = "代理编辑", notes = "代理编辑")
    public Result update(@RequestBody @Validated(value = InputValidationGroup.Update.class) TAgentCustomersReq tAgentCustomersReq) {
        try {
            logger.info("/agentCustomers/update 入参tAgentCustomersReq：{} 返回值：void", tAgentCustomersReq.toString());
            tAgentCustomersService.update(tAgentCustomersReq);
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/agentCustomers/update 出异常了，入参tAgentCustomersReq：{} 异常信息：{}", tAgentCustomersReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @PostMapping(value = "/updateAgentRemark")
    @ApiOperation(value = "代理编辑备注", notes = "代理编辑备注")
    public Result updateAgentRemark(@RequestBody @Validated(value = InputValidationGroup.Update.class) TAgentCustomersRemarkReq tAgentCustomersRemarkReq) {
        try {
            logger.info("/agentCustomers/updateAgentRemark 入参tAgentCustomersRemarkReq：{} 返回值：void", tAgentCustomersRemarkReq.toString());
            tAgentCustomersService.updateAgentRemark(tAgentCustomersRemarkReq);
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/agentCustomers/updateAgentRemark 出异常了，入参tAgentCustomersRemarkReq：{} 异常信息：{}", tAgentCustomersRemarkReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @GetMapping(value = "/getAgentTree")
    public Result<Void> getAgentTree(@NotBlank(message = "parent is not blank") String parent) {
        try {
            List<TAgentCustomersResp> resp = tAgentCustomersService.getAgentTree(parent);
            logger.info("/agentCustomers/getAgentTree 入参parent：{} 返回值：{}", parent, resp.toString());
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/agentCustomers/getAgentTree 出异常了，入参parent：{} 异常信息：{}", parent, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping("/export")
    @ApiOperation(value = "代理导出", notes = "代理导出")
    public Result<List<TAgentCustomersResp>> export(@RequestBody @Validated(value = InputValidationGroup.Query.class) TAgentCustomersQueryReq tAgentCustomersQueryReq, HttpServletResponse response) {
        try {
            List<TAgentCustomersResp> resp = tAgentCustomersService.export(tAgentCustomersQueryReq, response);
            logger.info("/agentCustomers/export 入参tAgentCustomersQueryReq：{} 返回值 size：{}", tAgentCustomersQueryReq.toString(), resp.size());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentCustomers/export 出异常了，入参tAgentCustomersQueryReq：{} 异常信息：{}", tAgentCustomersQueryReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @GetMapping(value = "/checkAgentPower")
    @ApiOperation(value = "通过CustomersId判断代理是否为一般代理或者最下级代理", notes = "通过CustomersId判断代理是否为一般代理或者最下级代理")
    public Result checkAgentPower(@Validated @NotNull(message = "customers id is not blank") Long customersId) {
        try {
            logger.info("/agentCustomers/checkAgentPower 入参customersId：{} 返回值：void", customersId);
            Boolean success = tAgentCustomersService.checkAgentPower(customersId);
            if (success) {
                return Result.success(ResultEnum.AGENT_HAVE_POWER);
            } else {
                return Result.fail(ResultEnum.AGENT_HAVE_NOT_POWER);
            }
        } catch (Exception e) {
            logger.error("/agentCustomers/checkAgentPower 出异常了，入参customersId：{} 异常信息：{}", customersId, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @PostMapping(value = "/getAgentByCustomerIds")
    @ApiOperation(value = "通过CustomersIds获取代理", notes = "通过CustomersIds获取代理")
    Result<List<TAgentCustomers>> getAgentByCustomerIds(@RequestBody List<Long> list) {
        try {
            List<TAgentCustomers> resp = tAgentCustomersService.getAgentByCustomerIds(list);
            logger.info("/agentCustomers/getAgentByCustomerIds 入参list：{} 返回值：{}", list, resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentCustomers/getAgentByCustomerIds 出异常了，入参list：{} 异常信息：{}", list, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @PostMapping(value = "/updateByMQMessage")
    public Result updateByMQMessage(@RequestBody TCustomerLayer tCustomerLayer) {
        try {
            logger.info("/agentCustomers/updateByMQMessage 入参tCustomerLayer：{} 返回值：void", tCustomerLayer.toString());
            tAgentCustomersService.updateByMQMessage(tCustomerLayer);
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/agentCustomers/updateByMQMessage 出异常了，入参tCustomerLayer：{} 异常信息：{}", tCustomerLayer.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @PostMapping(value = "/userToAgent")
    public Result userToAgent(@RequestBody TAgentCustomersReq tAgentCustomersReq) {
        try {
            logger.info("/agentCustomers/userToAgent 入参tAgentCustomersReq：{} 返回值：void", tAgentCustomersReq.toString());
            tAgentCustomersService.userToAgent(tAgentCustomersReq);
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/agentCustomers/userToAgent 出异常了，入参tAgentCustomersReq：{} 异常信息：{}", tAgentCustomersReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @PostMapping(value = "/subUserToAgent")
    public Result subUserToAgent(@RequestBody TAgentCustomersReq tAgentCustomersReq) {
        try {
            logger.info("/agentCustomers/subUserToAgent 入参tAgentCustomersReq：{} 返回值：void", tAgentCustomersReq.toString());
            tAgentCustomersService.subUserToAgent(tAgentCustomersReq);
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/agentCustomers/subUserToAgent 出异常了，入参tAgentCustomersReq：{} 异常信息：{}", tAgentCustomersReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @GetMapping(value = "/cancelAgent")
    @ApiOperation(value = "取消代理资格", notes = "取消代理资格")
    public Result cancelAgent(@Validated @NotNull(message = "customers id is not blank") Long customersId) {
        try {
            logger.info("/agentCustomers/cancelAgent 入参customersId：{} 返回值：void", customersId);
            tAgentCustomersService.cancelAgent(customersId);
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/agentCustomers/cancelAgent 出异常了，入参customersId：{} 异常信息：{}", customersId, e);
            return Result.fail(e.getMessage());
        }
    }


    @GetMapping(value = "/one")
    @ApiOperation(value = "通过CustomersId获取代理信息", notes = "通过CustomersId获取代理信息", hidden = true)
    public Result<TAgentCustomers> getAgentByCustomerId(@RequestParam Long customerId) {
        try {
            TAgentCustomers resp = tAgentCustomersService.getByCustomerId(customerId);
            logger.info("/agentCustomers/one 入参customerId：{} 返回值：{}", customerId, resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentCustomers/one 出异常了，入参customerId：{} 异常信息：{}", customerId, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @GetMapping(value = "/getAgentAndContractByCustomerId")
    @ApiOperation(value = "通过CustomersId获取代理信息", notes = "通过CustomersId获取代理信息", hidden = true)
    public Result<AgentCustomerGateResp> getAgentAndContractByCustomerId(@Validated @NotNull(message = "customers id is not blank") Long customerId) {
        try {
            AgentCustomerGateResp resp = tAgentCustomersService.getAgentAndContractByCustomerId(customerId);
            logger.info("/agentCustomers/getAgentAndContractByCustomerId 入参customerId：{} 返回值：{}", customerId, resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentCustomers/getAgentAndContractByCustomerId 出异常了，入参customerId：{} 异常信息：{}", customerId, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping("/subAgentExport")
    @ApiOperation(value = "代理导出", notes = "代理导出")
    public Result<List<TAgentCustomersFrontResp>> subAgentExport(@RequestBody @Validated(value = InputValidationGroup.Query.class) TAgentCustomersQueryReq tAgentCustomersQueryReq, HttpServletResponse response) {
        try {
            List<TAgentCustomersFrontResp> resp = tAgentCustomersService.subAgentExport(tAgentCustomersQueryReq, response);
            logger.info("/agentCustomers/subAgentExport 入参tAgentCustomersQueryReq：{} 返回值：{}", tAgentCustomersQueryReq.toString(), resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentCustomers/subAgentExport 出异常了，入参tAgentCustomersQueryReq：{} 异常信息：{}", tAgentCustomersQueryReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @GetMapping(value = "/one/byName")
    @ApiOperation(value = "通过loginName获取代理信息", notes = "通过loginName获取代理信息", hidden = true)
    public Result<TAgentCustomers> getAgentByLoginName(@RequestParam String loginName) {
        TAgentCustomers resp = tAgentCustomersService.getAgentByLoginName(loginName);
        logger.info("/agentCustomers/one/byName 入参loginName：{} 返回值：{}", loginName, resp.toString());
        return Result.success(resp);
    }

    @GetMapping(value = "/list/byNameNLevel")
    @ApiOperation(value = "获取某代理的团队中指定level或指定代理名称的代理名称列表", notes = "获取某代理的团队中指定level的代理列表")
    public List<String> getAgentListByNameNLevel(@RequestParam("parent") String parent,@RequestParam("parentAccount") String parentAccount, @RequestParam("agentAccount") String agentAccount, @RequestParam("level") Integer level){
        logger.info("/agentCustomers/list/byNameNLevel 入参loginName：{} ,parentAccount:{}, agentAccount:{}, level:{}", parent,parentAccount,agentAccount,level);
        return tAgentCustomersService.getAgentListByNameNLevel(parent,parentAccount,agentAccount,level);
    }

    @GetMapping(value = "/team/byNameNLevel")
    @ApiOperation(value = "获取某代理的团队中指定level或指定代理名称的代理列表-对象", notes = "获取某代理的团队中指定level的代理列表")
    public List<TAgentCustomers> getTeamAgentListByNameNLevel(@RequestParam("parent") String parent,@RequestParam("parentAccount") String parentAccount, @RequestParam("agentAccount") String agentAccount, @RequestParam("level") Integer level){
        logger.info("/agentCustomers/team/byNameNLevel 入参parent：{} ,agentAccount:{}, level:{}", parent,agentAccount,level);
        return tAgentCustomersService.getTeamAgentListByNameNLevel(parent,parentAccount,agentAccount,level);
    }



    @PostMapping(value = "/list")
    @ApiOperation(value = "通过条件获取代理信息", notes = "通过条件获取代理信息", hidden = true)
    public Result<List<TAgentCustomers>> getAgentList(@RequestBody AgentListRequest request) {
        try {
            List<TAgentCustomers> resp = tAgentCustomersService.getAgentListByLoginName(request);
            logger.info("/agentCustomers/list 入参request：{} 返回值：{}", request.toString(), resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentCustomers/list 出异常了，入参request：{} 异常信息：{}", request.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @GetMapping(value = "/queryTopAgent")
    @ApiOperation(value = "获取顶级代理", notes = "获取顶级代理", hidden = true)
    public Result<TAgentCustomers> queryTopAgent(@Validated @NotNull(message = "customers id is not blank") Long customerId) {
        try {
            TAgentCustomers resp = tAgentCustomersService.queryTopAgent(customerId);
            if (Objects.isNull(resp)) {
                return Result.fail(ResultEnum.AGENT_NOT_EXIST.getMessage());
            }
            logger.info("/agentCustomers/queryTopAgent 入参customerId：{} 返回值：{}", customerId, resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentCustomers/queryTopAgent 出异常了，入参customerId：{} 异常信息：{}", customerId, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @GetMapping(value = "/queryTopAgentByAccount")
    @ApiOperation(value = "获取顶级代理", notes = "获取顶级代理", hidden = true)
    public Result<TAgentCustomers> queryTopAgentByAccount(@Validated @NotNull(message = "account id is not blank") String account) {
        try {
            TAgentCustomers resp = tAgentCustomersService.queryTopAgentByAccount(account);
            if (Objects.isNull(resp)) {
                return Result.fail(ResultEnum.AGENT_NOT_EXIST.getMessage());
            }
            logger.info("/agentCustomers/queryTopAgentByAccount 入参account：{} 返回值：{}", account, resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentCustomers/queryTopAgentByAccount 出异常了，入参account：{} 异常信息：{}", account, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @GetMapping(value = "/queryCustomers")
    @ApiOperation(value = "通过loginName获取用户信息", notes = "通过loginName获取用户信息", hidden = true)
    public Result<UserResp> queryCustomers(@RequestParam("loginName") String loginName) {
        try {
            UserResp resp = tAgentCustomersService.queryCustomers(loginName);
            logger.info("/agentCustomers/queryCustomers 入参loginName：{} 返回值：{}", loginName, resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentCustomers/queryCustomers 出异常了，入参loginName：{} 异常信息：{}", loginName, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping(value = "/checkAgentIsTop")
    @ApiOperation(value = "判断当前代理是否为顶级代理", notes = "判断当前代理是否为顶级代理", hidden = true)
    public Result checkAgentIsTop(@RequestBody TAgentCustomersQueryReq tAgentCustomersQueryReq) {
        try {
            ResultEnum resp = tAgentCustomersService.checkAgentIsTop(tAgentCustomersQueryReq);
            logger.info("/agentCustomers/checkAgentIsTop 入参tAgentCustomersQueryReq：{} 返回值：{}", tAgentCustomersQueryReq.toString(), resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentCustomers/checkAgentIsTop 出异常了，入参tAgentCustomersQueryReq：{} 异常信息：{}", tAgentCustomersQueryReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @GetMapping(value = "/isAgent")
    @ApiOperation(value = "判断该用户是否为代理", notes = "判断该用户是否为代理", hidden = true)
    public Result<Boolean> isAgent(@RequestParam String loginName) {
        try {
            Boolean resp = tAgentCustomersService.isAgent(loginName);
            logger.info("/agentCustomers/isAgent 入参loginName：{} 返回值：{}", loginName, resp);
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentCustomers/isAgent 出异常了，入参loginName：{} 异常信息：{}", loginName, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping(value = "/createTopAgentByBatch")
    @ApiOperation(value = "批量创建代理", notes = "；批量创建代理")
    public Result createTopAgentByBatch(@RequestBody TAgentCustomersBatchReq tAgentCustomersBatchReq, HttpServletRequest request) {
        try {
            logger.info("/agentCustomers/createTopAgentByBatch tAgentCustomersBatchReq：{} 返回值：Result", tAgentCustomersBatchReq.toString());
            Result<Boolean> result = batchService.createTopAgentByBatch(tAgentCustomersBatchReq, request);
            return result;
        } catch (Exception e) {
            logger.error("/agentCustomers/createTopAgentByBatch 出异常了，入参tAgentCustomersReq：{} 异常信息：{}", tAgentCustomersBatchReq.toString(), e.toString());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping(value = "/getTopAgentBatch")
    @ApiOperation(value = "查询批量创建的代理", notes = "；查询批量创建的代理")
    public Result<Page<BatchQueryResp>> getTopAgentBatch(@RequestBody BatchQueryRequest batchQueryRequest, HttpServletRequest request) {
        // 查询的记录
        batchQueryRequest.setQueryType(BatchService.BATCH_TYPE_AGENT);
        try {
            logger.info("/agentCustomers/getTopAgentBatch BatchQueryRequest：{} 返回值：void", batchQueryRequest);
            Page<BatchQueryResp> page = batchService.queryBatchInfo(batchQueryRequest);
            return Result.success(200, "success", page);
        } catch (Exception e) {
            logger.error("/agentCustomers/getTopAgentBatch 出异常了，入参tAgentCustomersReq：{} 异常信息：{}", batchQueryRequest, e.toString());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping(value = "/selectAgentsCount")
    @ApiOperation(value = "查询代理的账号数量", notes = "查询代理的账号数量")
    public Result<Map<String, Integer>> selectAgentsCount(@RequestParam String loginName) {
        // 查询代理数量 <key：筛选条件, value：数量>
        Map<String, Integer> resp = new HashMap<>();
        // 团队代理数量
        Integer totalAgents = tAgentCustomersService.selectTotalAgents(loginName);
        logger.info("此代理所有团队代理数量的数量--totalAgents：{}", totalAgents);
        resp.put("totalAgents", totalAgents);
        // 直属代理数量
        Integer directAgents = tAgentCustomersService.selectDirectAgents(loginName);
        logger.info("此代理的直属代理的数量--directAgents：{}", directAgents);
        resp.put("directAgents", directAgents);
        // 下线代理数量
        Integer downlineAgents = totalAgents - directAgents;
        logger.info("此代理的所有下线代理的数量--downlineAgents：{}", downlineAgents);
        resp.put("downlineAgents", downlineAgents);
        return Result.success(resp);
    }

    @GetMapping(value = "/selectParentAgentByNameAndLevel")
    @ApiOperation(value = "根据 parentLoginName 及 parentLevel 查询 agent")
    public Result<TAgentCustomers> selectParentAgentByNameAndLevel(@RequestParam("parentLoginName") String parentLoginName, @RequestParam("parentLevel") String parentLevel) {
        return Result.success(tAgentCustomersService.selectParentAgentByNameAndLevel(parentLoginName, parentLevel));
    }

    @GetMapping(value = "/selectParentAgentByNameAndLevelEnable")
    @ApiOperation(value = "根据 parentLoginName 及 parentLevel 查询 agent")
    public Result<TAgentCustomers> selectParentAgentByNameAndLevelEnable(@RequestParam("parentLoginName") String parentLoginName, @RequestParam("parentLevel") String parentLevel) {
        return Result.success(tAgentCustomersService.selectParentAgentByNameAndLevelEnable(parentLoginName, parentLevel));
    }

    /**
     * 获取某批代理的下级代理
     *
     * @param queryEntity
     * @return
     */
    @PostMapping("/selectDirectAgentNamesByParentList")
    public Result<List<String>> selectDirectAgentNamesByParentListNTime(
            @RequestBody DashBoardUserTreeQueryReq queryEntity) {
        List<String> parentList = queryEntity.getParentList();
        if (CollectionUtils.isEmpty(parentList)) {
            return Result.success(Collections.emptyList());
        }
        return Result.success(tAgentCustomersService.selectDirectAgentNamesByParentListNTime(parentList));
    }

    @GetMapping(value = "/queryBatchAccountsByBatchId")
    @ApiOperation(value = "根据批量创建记录id查询对应账户信息", notes = "根据批量创建记录id查询对应账户信息")
    public Result<List<BatchAccountInfoDTO>> batchAccountList(@RequestParam(name = "batchId") String batchId) {
        if (!StringUtils.isNumeric(batchId)) {
            return Result.fail(ResultEnum.RECORD_NOT_EXIST);
        }
        try {
            logger.info("/agentCustomers/queryBatchAccountsByBatchId batchId：{} ", batchId);
            List<BatchAccountInfoDTO> page = batchService.queryBatchAccountsByBatchId(Long.parseLong(batchId));
            return Result.success(200, "success", page);
        } catch (Exception e) {
            logger.error("/agentCustomers/queryBatchAccountsByBatchId batchId：{}", batchId, e);
            return Result.fail(e.getMessage());
        }
    }


    //===================对外接口================================================
    @PostMapping(value = "/queryAgentCustomers")
    @ApiOperation(value = "获取代理用户id", notes = "获取代理用户id", hidden = true)
    public Result<Page<String>> queryAgentCustomers(@RequestBody AgentCustomersReq agentCustomersReq) {
        try {
            Page<String> resp = tAgentCustomersService.queryAgentCustomers(agentCustomersReq);
            logger.info("/agentCustomers/queryAgentCustomers 入参agentCustomersReq：{} 返回值：{}", agentCustomersReq.toString(), resp.getRecords().toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/agentCustomers/queryAgentCustomers 出异常了，入参agentCustomersReq：{} 异常信息：{}", agentCustomersReq.toString(), e);
            return Result.fail(e.getMessage());
        }
    }

}
