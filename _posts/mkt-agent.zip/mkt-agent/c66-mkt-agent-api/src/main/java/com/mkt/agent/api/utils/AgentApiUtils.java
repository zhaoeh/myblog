package com.mkt.agent.api.utils;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.mkt.agent.api.mapper.TAgentCustomersMapper;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @Description TODO
 * @Classname AgentApiUtils
 * @Date 2023/12/9 13:55
 * @Created by TJSLucian
 */
@Component
public class AgentApiUtils {

    @Autowired
    private TAgentCustomersMapper agentCustomersMapper;

    /**
     * description: 接收代理用户名入参，返回代理的上级代理链路
     * @param:  [names]
     * @return: java.util.List<java.lang.String>
     * @Date: 2023/12/9 16:11
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public List<String> getParentNamesList(List<String> names){

        List<String> parentAgentNames = new ArrayList<>();

        names.forEach(name ->{
            getParentAgentList(parentAgentNames,name);
        });
        return parentAgentNames;
    }


    private void getParentAgentList(List<String> names,String loginName) {
        TAgentCustomers tAgentCustomers = agentCustomersMapper.selectOne(new LambdaQueryWrapper<TAgentCustomers>().eq(TAgentCustomers::getLoginName,loginName).eq(TAgentCustomers::getIsDeleted, BaseConstants.AGENTS_NO_DELETED)
                .eq(TAgentCustomers::getIsEnable,BaseConstants.AGENTS_IS_ABLE));


        if(!Objects.isNull(tAgentCustomers)){
            names.add(tAgentCustomers.getLoginName());
        }else {
            return;
        }
        if (tAgentCustomers.getAgentLevel().equals(1)) {
            return;
        }
        getParentAgentList(names,tAgentCustomers.getParentName());
    }


}
