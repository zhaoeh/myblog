package com.mkt.agent.api.utils;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.mkt.agent.api.mapper.TAgentCustomersMapper;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @Description TODO
 * @Classname AgentApiUtils
 * @Date 2023/12/9 13:55
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class AgentApiUtils {

    @Autowired
    private TAgentCustomersMapper agentCustomersMapper;


    /**
     * description: 接收代理用户名入参，返回代理的上级代理链路
     * @param:  [names]
     * @return: java.util.List<java.lang.String>
     * @Date: 2023/12/9 16:11
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public void getParentAgentList(List<String> names,String loginName,String oldName) {
        TAgentCustomers tAgentCustomers = agentCustomersMapper.selectOne(new LambdaQueryWrapper<TAgentCustomers>().eq(TAgentCustomers::getLoginName,loginName));

        if(Objects.isNull(tAgentCustomers)){
            return;
        }

        if(!tAgentCustomers.getLoginName().equals(oldName) && (tAgentCustomers.getIsEnable() == BaseConstants.AGENTS_IS_ENABLE || tAgentCustomers.getIsDeleted() != BaseConstants.AGENTS_NO_DELETED)){
            names.add(tAgentCustomers.getLoginName());
            return;
        }

        if(!tAgentCustomers.getLoginName().equals(oldName)){
            log.info("[getParentAgentList]Add agent:{} to parentList for agent:{}",tAgentCustomers.getLoginName(),oldName);
            names.add(tAgentCustomers.getLoginName());
        }

        if (tAgentCustomers.getAgentLevel().equals(1)) {
            return;
        }
        getParentAgentList(names,tAgentCustomers.getParentName(),oldName);
    }


}
