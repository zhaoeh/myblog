package com.mkt.agent.api.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.api.entity.req.*;
import com.mkt.agent.api.entity.resp.FundBalanceResp;
import com.mkt.agent.api.service.FundService;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.SumPageResponse;
import com.mkt.agent.common.entity.api.fund.resp.FundRecordResp;
import com.mkt.agent.common.enums.CustomerTypeEnum;
import com.mkt.agent.common.enums.FundStatusEnum;
import com.mkt.agent.common.enums.ResultEnum;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @ClassName FundController
 * @Description 账变
 * @Author TJSAlex
 * @Date 2023/5/18 14:52
 * @Version 1.0
 **/
@RestController
@RequestMapping("/fund")
public class FundController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private FundService fundService;

    @PostMapping("/list")
    public Result<SumPageResponse<FundRecordResp>> list(@RequestBody FundRecordReq req) {
        try {
            SumPageResponse<FundRecordResp> resp = fundService.list(req);
            logger.info("/fund/list 入参FundRecordReq：{} 返回值：{}", req.toString(), resp.getRecords().toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/fund/list 出异常了，入参FundRecordReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping("/export")
    public Result export(@RequestBody FundRecordReq req, HttpServletResponse response) {
        try {
            logger.info("/fund/export 入参FundRecordReq：{} 返回值：void", req.toString());
            fundService.export(req, response);
            return Result.success(ResultEnum.SUCCESS);
        } catch (IOException e) {
            logger.error("/fund/export 出异常了，入参FundRecordReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping("/transfer")
    public Result<Boolean> transfer(@RequestBody @Validated FundTransferReq req) {
        try {
            boolean success = fundService.transfer(req);
            logger.info("/fund/transfer 入参FundTransferReq：{} 返回值：{}", req.toString(), success);
            return Result.success(success);
        } catch (Exception e) {
            logger.error("/fund/transfer 出异常了，入参FundTransferReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    /**
     * @return
     * @Description 根据agentId获取余额
     * @Date 14:32 2023/5/24
     * @Param
     */
    @ApiOperation(value = "获取代理钱包余额", notes = "获取代理钱包余额 ")
    @PostMapping("/getBalance")
    public Result<FundBalanceResp> getBalance(@RequestBody @Validated FundAgentReq req) {
        try {
            FundBalanceResp resp = fundService.getBalance(req);
            logger.info("/fund/getBalance 入参FundAgentReq：{} 返回值：{}", req.toString(), resp.toString());
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/fund/getBalance 出异常了，入参FundAgentReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @ApiOperation(value = "代理存款", notes = "代理存款 ")
    @PostMapping("/deposit")
    public Result<Boolean> deposit(@RequestBody @Validated FundTradeReq req) {
        try {
            boolean success = fundService.deposit(req);
            logger.info("/fund/deposit 入参FundTradeReq：{} 返回值：{}", req.toString(), success);
            return Result.success(success);
        } catch (Exception e) {
            logger.error("/fund/deposit 出异常了，入参FundTradeReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @ApiOperation(value = "新增代理钱包", notes = "新增代理钱包 ")
    @PostMapping("/addAgentWallet")
    public Result<Boolean> addAgentWallet(@RequestBody @Validated FundAgentReq req) {
        try {
            Boolean success = fundService.addAgentWallet(req);
            logger.info("/fund/addAgentWallet 入参FundAgentReq：{} 返回值：{}", req.toString(), success);
            return Result.success(success);
        } catch (Exception e) {
            logger.error("/fund/addAgentWallet 出异常了，入参FundAgentReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @ApiOperation(value = "代理钱包增减金额", notes = "代理钱包增减金额 ")
    @PostMapping("/modifyAmount")
    public Result<Boolean> modifyAmount(@RequestBody @Validated FundModifyReq req) {
        try {
            Boolean success = fundService.modifyAmount(req);
            logger.info("/fund/modifyAmount 入参FundModifyReq：{} 返回值：{}", req.toString(), success);
            return Result.success(success);
        } catch (Exception e) {
            logger.error("/fund/modifyAmount 出异常了，入参FundModifyReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping("/saveRecord")
    public Result<Void> saveRecord(@RequestBody @Validated FundTransferReq req) {
        try {
            logger.info("/fund/saveRecord 入参FundTransferReq：{} 返回值：void", req.toString());
            fundService.saveFundRecord(req, FundStatusEnum.Pending.getCode(), CustomerTypeEnum.PLAYER.getValue(), Constants.ISNCOMMISSION);
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/fund/saveRecord 出异常了，入参FundTransferReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }
}
