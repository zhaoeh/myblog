package com.mkt.agent.api.feign;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * @interfaceName: AgentApiClient
 * @Description:
 * @Author: Austin
 * @Date: 2023/5/30
 */
//@FeignClient(name = "${feign.mkt-user}", url = "127.0.0.1:18086")
@FeignClient(name = "${feign.mkt-user}")
public interface UserClient {

    @PostMapping(value = "/v1/customer/layer/selectBatchIds")
    Result<List<TCustomerLayer>> selectBatchIds(@RequestBody List<Long> list);

    @PostMapping(value = "/v1/customer/layer/updateBatch")
    Result updateBatch(@RequestBody List<TCustomerLayer> list);

    @GetMapping(value ="/v1/customer/layer/getOneByLoginName")
    Result<TCustomerLayer> getOneByLoginName(@RequestParam("loginName")String loginName);

}
