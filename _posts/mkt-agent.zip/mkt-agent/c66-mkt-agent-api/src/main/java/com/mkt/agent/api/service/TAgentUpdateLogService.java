package com.mkt.agent.api.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mkt.agent.common.entity.api.agentapi.TAgentUpdateLog;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Description TODO
 * @Classname TAgentUpdateLogService
 * @Date 2023/12/8 18:22
 * @Created by TJSLucian
 */
public interface TAgentUpdateLogService {

    TAgentUpdateLog getFrashBaName(String loginName);

    void updateByName(String loginName);

    void saveList(List<String> names);

}
