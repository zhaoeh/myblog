package com.mkt.agent.api.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cn.schema.customers.CreateNewAccountResponse;
import com.cn.schema.customers.WSCustomers;
import com.cn.schema.customers.WSQueryCustomers;
import com.mkt.agent.api.entity.TAgentWallet;
import com.mkt.agent.api.entity.req.FundAgentReq;
import com.mkt.agent.api.entity.req.TAgentCustomersBuildReq;
import com.mkt.agent.api.entity.req.TAgentCustomersQueryReq;
import com.mkt.agent.api.entity.req.TAgentCustomersReq;
import com.mkt.agent.api.entity.resp.TAgentCustomersResp;
import com.mkt.agent.api.exception.MKTAgentException;
import com.mkt.agent.api.feign.UserClient;
import com.mkt.agent.api.mapper.FundWalletMapper;
import com.mkt.agent.api.mapper.TAgentCustomersMapper;
import com.mkt.agent.api.mapper.TCustomerLayerMapper;
import com.mkt.agent.api.service.FundService;
import com.mkt.agent.api.service.TAgentContractBindService;
import com.mkt.agent.api.service.TAgentContractService;
import com.mkt.agent.api.service.TAgentCustomersService;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentCustomersReq;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentCustomersRemarkReq;
import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerGateResp;
import com.mkt.agent.common.entity.api.agentapi.responses.TAgentCustomersFrontResp;
import com.mkt.agent.common.entity.api.agentapi.responses.UserResp;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.userapi.requests.AgentListCopyRequest;
import com.mkt.agent.common.entity.api.userapi.requests.AgentListRequest;
import com.mkt.agent.common.enums.AgentLevelEnum;
import com.mkt.agent.common.enums.AgentTypeEnum;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.enums.SubAgentTypeEnum;
import com.mkt.agent.common.helper.FunctionHelper;
import com.mkt.agent.common.helper.Conditions;
import com.mkt.agent.common.utils.*;
import com.mkt.agent.integration.config.UserCenterConfig;
import com.mkt.agent.integration.entities.ws.InterWSCustomers;
import com.mkt.agent.integration.service.UserCenterRestInter;
import com.mkt.agent.integration.service.WsRestInter;
import com.mkt.agent.integration.template.UserCenterTemplate;
import com.mkt.agent.integration.template.WsTemplate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @ClassName AgentCustomersServiceImpl
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Service
public class TAgentCustomersServiceImpl extends ServiceImpl<TAgentCustomersMapper, TAgentCustomers> implements TAgentCustomersService {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private UserCenterConfig userCenterConfig;

    @Autowired
    private TAgentCustomersMapper tAgentCustomersMapper;

    @Autowired
    private TAgentContractBindService tAgentContractBindService;

    @Autowired
    private TAgentContractService tAgentContractService;

    @Autowired
    private WsRestInter wsRestInter;

    @Autowired
    private UserCenterRestInter userCenterRestInter;

    @Autowired
    private FundService fundService;

    @Resource
    private FundWalletMapper fundWalletMapper;

    private static final String CREATE_NEW_ACCOUNT_URL = "/rest/customers/create_new_account";

    private static final String USER_CENTER_CREATE_NEW_ACCOUNT_URL = "/customer/account/create_new_account";

    private static final String QUERY_CUSTOMER_BASIC_URL = "/rest/customers/query_customers_basic";

    @Autowired
    private UserClient userClient;
    @Autowired
    private TCustomerLayerMapper tCustomerLayerMapper;
    @Resource
    private RedisUtil redisUtil;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void create(TAgentCustomersReq tAgentCustomersReq, String ip) {
        logger.info("agentCustomersReq : {}", tAgentCustomersReq.toString());

        Result<TCustomerLayer> tCustomerLayerResult = userClient.getOneByLoginName(tAgentCustomersReq.getLoginName());

        if(!Objects.isNull(tCustomerLayerResult.getData())){
            throw new MKTAgentException(ResultEnum.AGENT_ALREADY_EXIST.getMessage());
        }

        try {
            redisUtil.set(Constants.REGISTER_CUSTOMER_TYPE+tAgentCustomersReq.getLoginName().toLowerCase(Locale.ROOT), BaseConstants.WS_AGENT, 24 * 60 * 60);
            TAgentCustomers tAgentCustomers = new TAgentCustomers();
            TAgentContractBind tAgentContractBind = null;
            TAgentContract tAgentContract = null;
            tAgentCustomersReq.setLoginName(tAgentCustomersReq.getLoginName().toLowerCase());
            logger.info("begin to call ws--- to create customer");
            //1.远程调用ws系统接口,创建用户
            CreateNewAccountResponse response = addInterWSCustomer(tAgentCustomersReq, ip);
            if (!CreateNewAccountResponse.class.isInstance(response)) {
                logger.info("ws create customer fail:" + response.toString());
                throw new MKTAgentException(ResultEnum.WS_CREATE_CUSTOMER_FAIL);
            }
            if (StringUtils.isNoneBlank(response.getWsErrorMsg())) {
                throw new MKTAgentException(response.getWsErrorMsg().split("\\^")[1]);
            } else {
                CreateNewAccountResponse createNewAccountResponse = response;
                WSCustomers wsCustomers = createNewAccountResponse.getWSCustomers();
                logger.info("The wsCustomer is:{}", wsCustomers);
                //2.判断是否为1级代理
                if (BaseConstants.C66_ADMIN.equals(tAgentCustomersReq.getCreateBy())) {// 2.1管理员
                    logger.info("the agent is created by C66_ADMIN---");
                    BeanUtils.copyProperties(tAgentCustomersReq, tAgentCustomers);
                    tAgentCustomers.setCustomersId(Long.valueOf(wsCustomers.getCustomerId()));
                    tAgentCustomers.setAgentLevel(AgentLevelEnum.AGENT_TOP.getCode());
                    tAgentCustomers.setParentId(Long.valueOf(wsCustomers.getParentId()));
                    tAgentCustomers.setParentName(wsCustomers.getParentLoginName());
                    logger.info("create agent contract--");
                    tAgentContract = tAgentContractService.selectOne(tAgentCustomersReq.getCommissionContractCode());
                    tAgentContractBind = tAgentContractBind.builder().loginName(wsCustomers.getLoginName()).commissionContractId(tAgentCustomersReq.getCommissionContractCode()).
                            percentageDetails(tAgentContract.getPercentageDetails()).createBy(tAgentCustomers.getCreateBy()).build();
                } else {
                    logger.info("get parent agent----");
                    //2.2 使用当前登陆人Account,查询代理表获取父代理
                    TAgentCustomers parentTAgentCustomers = selectOne(Long.valueOf(wsCustomers.getParentId()), wsCustomers.getCreatedBy());
                    //2.3 判断父代理是否允许创建下级代理
                    if (!ObjectUtils.isEmpty(parentTAgentCustomers)) {//2.3.1有数据,创建下一级代理
                        logger.info("tAgentCustomers :{}", tAgentCustomers.toString());
                        tAgentCustomers = tAgentCustomers.builder().loginName(wsCustomers.getLoginName()).productId(wsCustomers.getProductId()).parentId(Long.valueOf(wsCustomers.getParentId()))
                                .customersId(Long.valueOf(wsCustomers.getCustomerId())).createBy(wsCustomers.getCreatedBy()).agentLevel(parentTAgentCustomers.getAgentLevel() + 1).agentType(parentTAgentCustomers.getAgentType())
                                .parentName(parentTAgentCustomers.getLoginName()).siteId(parentTAgentCustomers.getSiteId()).isEnable(parentTAgentCustomers.getIsEnable()).build();
                        //2.3.2查询父代理佣金方案 by 父代理commissionContractBindId
                        tAgentContract = tAgentContractBindService.queryTAgentContractByBindId(parentTAgentCustomers.getCommissionContractBindId());
                        //查询父代理佣金比例
                        List<SettlementPercentageReq> currentPercentageReqList = tAgentCustomersReq.getSettlementPercentageList();
                        tAgentContractBind = tAgentContractBind.builder().loginName(tAgentCustomers.getLoginName()).commissionContractId(tAgentContract.getId()).percentageDetails(SerializationUti.serializeToString(currentPercentageReqList))
                                .createBy(parentTAgentCustomers.getLoginName()).build();
                    } else {//2.3.2无数据,创建失败
                        logger.info(ResultEnum.WS_CREATE_CUSTOMER_FAIL.getMessage() + wsCustomers.getParentId());
                        throw new MKTAgentException(ResultEnum.WS_CREATE_CUSTOMER_FAIL);
                    }
                }
                logger.info("create agent conract bind---");
                //3.创建代理绑定佣金
                tAgentContractBindService.save(tAgentContractBind);
                //4.代理入库&绑定代理绑定佣金
                tAgentCustomers.setCommissionContractBindId(tAgentContractBind.getId());
                tAgentCustomersMapper.insert(tAgentCustomers);
                //5.ferralCode入库&与代理绑定
                /*tAgentReferralCodeService.save(TAgentReferralCode.builder().loginName(tAgentCustomers.getLoginName()).referralId(tAgentCustomersReq.getReferralId()).createBy(tAgentCustomersReq.getCreateBy())
                        .build());*/
                //6.佣金方案agent count +1
                tAgentContractService.updateAgentCountByIdV1(tAgentContract.getId());
                //7.创建代理钱包
                FundAgentReq fundAgentReq = new FundAgentReq();
                fundAgentReq.setAgentId(tAgentCustomers.getCustomersId());
                fundAgentReq.setLoginName(tAgentCustomers.getLoginName());
                fundAgentReq.setProductId(tAgentCustomers.getProductId());
                fundService.addAgentWallet(fundAgentReq);
            }
        } catch (DuplicateKeyException e) {
            logger.error(ResultEnum.REFERRALID_LOGINNAME_DUPLICATE.getMessage() + e);
            throw new MKTAgentException(ResultEnum.REFERRALID_LOGINNAME_DUPLICATE);
        } catch (MKTAgentException e) {
            logger.info("add agent failed--" + e.getMessage());
            throw e;
        } catch (Exception e) {
            logger.error(ResultEnum.UNEXPECTED_FAIL.getMessage() + e);
            throw new MKTAgentException(e.getMessage(), ResultEnum.UNEXPECTED_FAIL.getCode());
        }
    }



    @Override
    public Page<TAgentCustomersResp> queryList(TAgentCustomersQueryReq tAgentCustomersQueryReq) {
        Page<TAgentCustomersResp> pageResult = new Page<>();
        Integer total = tAgentCustomersMapper.count(tAgentCustomersQueryReq);
        logger.info("入参 tAgentCustomersQueryReq:{}  queryList total:{}", tAgentCustomersQueryReq.toString(), total);
        if (null != total && total != 0) {
            List<TAgentCustomersResp> tAgentCustomersRespList = tAgentCustomersMapper.queryList(tAgentCustomersQueryReq);
            logger.info("queryList  入参 tAgentCustomersQueryReq:{}  tAgentCustomersRespList:{}", tAgentCustomersQueryReq, tAgentCustomersRespList.toString());
            tAgentCustomersRespList.stream().map(tAgentCustomersResp -> {
                if (StringUtils.isNotBlank(tAgentCustomersResp.getPercentageDetails())) {
                    tAgentCustomersResp.setSettlementPercentageReq(SerializationUti.deserializeFromString(tAgentCustomersResp.getPercentageDetails(), SettlementPercentageReq.class));
                }
                TAgentCustomers topTAgentCustomers = queryTopAgent(tAgentCustomersResp.getCustomersId());
                tAgentCustomersResp.setLevelOneAgent(topTAgentCustomers.getLoginName());
                tAgentCustomersResp.setLevelOneCustomersId(topTAgentCustomers.getCustomersId());
                return tAgentCustomersResp;
            }).collect(Collectors.toList());
            if (null != tAgentCustomersQueryReq.getPageNum() && null != tAgentCustomersQueryReq.getPageSize()) {
                pageResult.setSize(tAgentCustomersQueryReq.getPageSize()).setCurrent(tAgentCustomersQueryReq.getPageNum())
                        .setPages(total / tAgentCustomersQueryReq.getPageSize());
            } else {
                pageResult.setSize(-1).setCurrent(-1).setPages(-1);
            }
            pageResult.setRecords(tAgentCustomersRespList).setTotal(total);
        }

        return pageResult;
    }

    @Override
    public Page<TAgentCustomersResp> queryListBP(TAgentCustomersQueryReq tAgentCustomersQueryReq) {
        Page<TAgentCustomersResp> pageResult = new Page<>();
        Integer total = tAgentCustomersMapper.countBp(tAgentCustomersQueryReq);
        logger.info("入参 tAgentCustomersQueryReq:{}  queryList total:{}", tAgentCustomersQueryReq.toString(), total);
        if (null != total && total != 0) {
            List<TAgentCustomersResp> tAgentCustomersRespList = tAgentCustomersMapper.queryListBp(tAgentCustomersQueryReq);
            logger.info("queryList  入参 tAgentCustomersQueryReq:{}  tAgentCustomersRespList:{}", tAgentCustomersQueryReq, tAgentCustomersRespList.toString());
            tAgentCustomersRespList.stream().map(tAgentCustomersResp -> {
                if (StringUtils.isNotBlank(tAgentCustomersResp.getPercentageDetails())) {
                    tAgentCustomersResp.setSettlementPercentageReq(SerializationUti.deserializeFromString(tAgentCustomersResp.getPercentageDetails(), SettlementPercentageReq.class));
                }
                TAgentCustomers topTAgentCustomers = queryTopAgent(tAgentCustomersResp.getCustomersId());
                tAgentCustomersResp.setLevelOneAgent(topTAgentCustomers.getLoginName());
                tAgentCustomersResp.setLevelOneCustomersId(topTAgentCustomers.getCustomersId());
                return tAgentCustomersResp;
            }).collect(Collectors.toList());
            if (null != tAgentCustomersQueryReq.getPageNum() && null != tAgentCustomersQueryReq.getPageSize()) {
                pageResult.setSize(tAgentCustomersQueryReq.getPageSize()).setCurrent(tAgentCustomersQueryReq.getPageNum())
                        .setPages(total / tAgentCustomersQueryReq.getPageSize());
            } else {
                pageResult.setSize(-1).setCurrent(-1).setPages(-1);
            }
            pageResult.setRecords(tAgentCustomersRespList).setTotal(total);
        }

        return pageResult;
    }
    @Override
    @Transactional
    public void update(TAgentCustomersReq tAgentCustomersReq) {
        TAgentCustomers currentTAgentCustomers = selectOne(tAgentCustomersReq.getCustomersId(), tAgentCustomersReq.getLoginName());
        //判断当前代理是否存在
        if (ObjectUtils.isEmpty(currentTAgentCustomers)) {
            logger.info(ResultEnum.AGENT_NOT_EXIST.getMessage() + "CustomersId:{},LoginName:{}", tAgentCustomersReq.getCustomersId(), tAgentCustomersReq.getLoginName());
            throw new MKTAgentException(ResultEnum.AGENT_NOT_EXIST);
        }

        if (currentTAgentCustomers.getAgentLevel() == 1) {
            //代理类型判断 遵循由General Line-->Professional Line
            if (currentTAgentCustomers.getAgentType().equals(AgentTypeEnum.PROFESSIONAL_LINE.getIndex()) && tAgentCustomersReq.getAgentType()
                    .equals(AgentTypeEnum.GENERAL_LINE.getIndex())) {
                logger.info("update tAgentCustomers must follow from small to big, " +
                                "tAgentCustomers : {} current agentType is {}, not allow update to :{}  ",
                        currentTAgentCustomers.getLoginName(), currentTAgentCustomers.getAgentType().
                                equals(AgentTypeEnum.GENERAL_LINE.getIndex()) ? "General Line" : "Professional Line",
                        tAgentCustomersReq.getAgentType().equals(AgentTypeEnum.GENERAL_LINE.getIndex()) ? "General Line" : "Professional Line");
                throw new MKTAgentException(ResultEnum.AGENT_TYPE_UPDATE);
            }
            //代理最大发展下线判断 遵循由small-->big
            if (currentTAgentCustomers.getDevelopableLevel() > tAgentCustomersReq.getDevelopableLevel()) {
                logger.info("update tAgentCustomers must follow from small to big, " +
                                "tAgentCustomers : {} current developable Level is {}, not allow update to :{}  ",
                        currentTAgentCustomers.getLoginName(), currentTAgentCustomers.getDevelopableLevel(),
                        tAgentCustomersReq.getDevelopableLevel());
                throw new MKTAgentException(ResultEnum.AGENT_DEVELOPABLE_LEVEL_UPDATE);
            }
        }


        TAgentContract tAgentContractBefore = tAgentContractBindService.queryTAgentContractByBindId(currentTAgentCustomers.getCommissionContractBindId());
        TAgentContract currentTAgentContract = tAgentContractService.selectOne(tAgentCustomersReq.getCommissionContractCode());
        if (!tAgentContractBefore.getId().equals(tAgentCustomersReq.getCommissionContractCode())) {

            //更新绑定信息
            TAgentCustomersQueryReq tAgentCustomersQueryReq = new TAgentCustomersQueryReq();
            tAgentCustomersQueryReq.setLevelOneAgent(currentTAgentCustomers.getLoginName());
            List<TAgentCustomersResp> list = tAgentCustomersMapper.queryList(tAgentCustomersQueryReq);
            List<Long> customersIdList = Arrays.asList();

            List<SettlementPercentageReq> initList = new ArrayList<>();
            initList.add(new SettlementPercentageReq());

            if (!CollectionUtils.isEmpty(list)) {
                customersIdList = list.stream().map(TAgentCustomersResp::getCommissionContractBindId).collect(Collectors.toList());
                tAgentContractBindService.updateBatchPercentageByBindIds(TAgentCustomersBuildReq.builder().customersIdList(customersIdList)
                        .CommissionContractCode(currentTAgentContract.getId()).initPercentageDetails(SerializationUti.serializeToString(initList)).build());
            }

            //修补一级代理绑定表的真实佣金方案
            TAgentContractBind tAgentContractBindBefore = tAgentContractBindService.getOne(new LambdaQueryWrapper<TAgentContractBind>().eq(TAgentContractBind::getCommissionContractId, currentTAgentContract.getId())
                    .eq(TAgentContractBind::getLoginName, currentTAgentCustomers.getLoginName()));

            tAgentContractBindBefore.setCommissionContractId(tAgentCustomersReq.getCommissionContractCode());
            tAgentContractBindBefore.setPercentageDetails(currentTAgentContract.getPercentageDetails());
            tAgentContractBindService.saveOrUpdate(tAgentContractBindBefore);

            //更新佣金方案表信息
            currentTAgentContract.setAgentCount(currentTAgentContract.getAgentCount() + customersIdList.size());
            tAgentContractService.saveOrUpdate(currentTAgentContract);
            tAgentContractBefore.setAgentCount(tAgentContractBefore.getAgentCount() - customersIdList.size());
            tAgentContractService.saveOrUpdate(tAgentContractBefore);
        }
        currentTAgentCustomers.setAgentType(tAgentCustomersReq.getAgentType());
        currentTAgentCustomers.setDevelopableLevel(tAgentCustomersReq.getDevelopableLevel());
        currentTAgentCustomers.setIsEnable(tAgentCustomersReq.getIsEnable());
        BeanUtils.copyProperties(tAgentCustomersReq, currentTAgentCustomers);
        super.saveOrUpdate(currentTAgentCustomers);
    }

    @Override
    public List<TAgentCustomersResp> getAgentTree(String parent) {
        TAgentCustomersQueryReq tAgentCustomersQueryReq = new TAgentCustomersQueryReq();
        return tAgentCustomersMapper.getAgentTree(tAgentCustomersQueryReq);
    }

    @Override
    public List<TAgentCustomersResp> export(TAgentCustomersQueryReq tAgentCustomersQueryReq, HttpServletResponse response) {
        Integer total = tAgentCustomersMapper.count(tAgentCustomersQueryReq);
        if (Objects.isNull(total) || total == 0) {
            return new ArrayList<>();
        }
        // 导出全部数据
        tAgentCustomersQueryReq.setIsPage(false);
        List<TAgentCustomersResp> tAgentCustomersRespList = tAgentCustomersMapper.queryList(tAgentCustomersQueryReq);
        tAgentCustomersRespList.stream().map(tAgentCustomersResp -> {
            TAgentCustomers topTAgentCustomers = queryTopAgent(tAgentCustomersResp.getCustomersId());
            tAgentCustomersResp.setLevelOneAgent(topTAgentCustomers.getLoginName());
            tAgentCustomersResp.setLevelOneCustomersId(topTAgentCustomers.getCustomersId());
            tAgentCustomersResp.setAgentTypeValue(tAgentCustomersResp.getAgentType().equals(0) ? "General Line" : "Professional Line");
            tAgentCustomersResp.setIsEnableValue(tAgentCustomersResp.getIsEnable().equals(0) ? "No" : "Yes");
            switch (tAgentCustomersResp.getProductSiteId()) {
                case 1:
                    tAgentCustomersResp.setProductSiteIdValue("Bingoplus");
                    break;
                case 2:
                    tAgentCustomersResp.setProductSiteIdValue("Arenaplus");
                    break;
                case 3:
                    tAgentCustomersResp.setProductSiteIdValue("Gameplus");
                    break;
                default:
                    throw new MKTAgentException(ResultEnum.SITE_ID_IS_ERROR);
            }
            return tAgentCustomersResp;
        }).collect(Collectors.toList());
        logger.info("tAgentCustomersRespList: {}", Arrays.toString(tAgentCustomersRespList.toArray()));
        return tAgentCustomersRespList;
    }

    @Override
    public Boolean checkAgentPower(Long customersId) {
        QueryWrapper<TAgentCustomers> wrapper = new QueryWrapper();
        wrapper.eq("customers_id", customersId);
        TAgentCustomers tAgentCustomers = super.getOne(wrapper);
        if (ObjectUtils.isEmpty(tAgentCustomers)) {
            logger.info(ResultEnum.AGENT_NOT_EXIST.getMessage() + "customersId:{}", customersId);
            throw new MKTAgentException(ResultEnum.AGENT_NOT_EXIST);
        }
        if (tAgentCustomers.getAgentType().equals(AgentTypeEnum.PROFESSIONAL_LINE.getIndex()) && agentAllow(tAgentCustomers.getCustomersId(), tAgentCustomers.getAgentLevel())) {
            logger.info("this agent has the power");
            return true;
        } else {
            logger.info("this agent has not the power");
            return false;
        }
    }

    @Override
    public List<TAgentCustomers> getAgentByCustomerIds(List<Long> list) {
        if (CollectionUtils.isEmpty(list)) {
            return Arrays.asList();
        }
        return tAgentCustomersMapper.getAgentByCustomerIds(list);
    }

    @Override
    @Transactional
    public void updateByMQMessage(TCustomerLayer tCustomerLayer) {
        TAgentCustomers currentTAgentCustomers = selectOne(tCustomerLayer.getCustomerId(), tCustomerLayer.getLoginName());
        TAgentCustomers parentTAgentCustomers = selectOne(tCustomerLayer.getParentId(), tCustomerLayer.getParentLoginName());
        TAgentContract currentTAgentContract = tAgentContractBindService.queryTAgentContractByBindId(parentTAgentCustomers.getCommissionContractBindId());
        TAgentContract tAgentContractBefore = tAgentContractBindService.queryTAgentContractByBindId(currentTAgentCustomers.getCommissionContractBindId());
        List<TAgentCustomers> list = new ArrayList<>(Arrays.asList(currentTAgentCustomers));
        parentTAgentCustomers.getCommissionContractBindId();
        Integer currentLevel = parentTAgentCustomers.getAgentLevel() + 1;
        currentTAgentCustomers.setParentId(tCustomerLayer.getParentId());
        currentTAgentCustomers.setParentName(tCustomerLayer.getParentLoginName());
        currentTAgentCustomers.setUpdateBy(tCustomerLayer.getUpdateBy());
        currentTAgentCustomers.setAgentLevel(currentLevel);
        updateAgentListLevel(currentTAgentCustomers.getCustomersId(), currentLevel, list);
        if (!CollectionUtils.isEmpty(list)) {
            List<Long> contractBindIdList = list.stream().map(TAgentCustomers::getCommissionContractBindId).collect(Collectors.toList());
            tAgentContractBindService.updateBatchPercentageByBindIds(TAgentCustomersBuildReq.builder().customersIdList(contractBindIdList).CommissionContractCode(currentTAgentContract.getId()).updateBy(parentTAgentCustomers.getLoginName()).build());
            currentTAgentContract.setAgentCount(currentTAgentContract.getAgentCount() + contractBindIdList.size() + 1);
            tAgentContractService.saveOrUpdate(currentTAgentContract);
            tAgentContractBefore.setAgentCount(tAgentContractBefore.getAgentCount() - contractBindIdList.size() - 1);
            tAgentContractService.saveOrUpdate(tAgentContractBefore);
        }
        super.saveOrUpdate(currentTAgentCustomers);
    }

    /**
     * 根据CustomerId获取代理
     *
     * @param customerId customerId
     * @return 代理
     */
    @Override
    public TAgentCustomers getByCustomerId(Long customerId) {
        TAgentCustomers tAgentCustomers = this.getBaseMapper().selectOne(new LambdaQueryWrapper<TAgentCustomers>()
                .eq(TAgentCustomers::getCustomersId, customerId));
        if (tAgentCustomers == null) {
            throw new MKTAgentException(ResultEnum.AGENT_NOT_EXIST);
        }
        return tAgentCustomers;
    }

    @Override
    @Transactional
    public void cancelAgent(Long customerId) {
        TAgentCustomers tAgentCustomers = getByCustomerId(customerId);
        if (!tAgentCustomers.getAgentLevel().equals(1)) {
            logger.error("this agent is not top one");
            throw new MKTAgentException(ResultEnum.AGENT_NOT_TOP_ONE);
        }
        TAgentCustomersQueryReq tAgentCustomersQueryReq = new TAgentCustomersQueryReq();
        tAgentCustomersQueryReq.setLevelOneAgent(tAgentCustomers.getLoginName());
        List<TAgentCustomersResp> list = tAgentCustomersMapper.queryList(tAgentCustomersQueryReq);
        List<TAgentCustomers> tAgentCustomersList = BeanCopyUtil.copyListProperties(list, TAgentCustomers::new, (tAgentCustomersSources, tAgentCustomersTarget) -> {
            tAgentCustomersTarget.setIsDeleted(-2);
        });
        tAgentCustomers.setIsDeleted(-2);

        //查出的list里已经包含了本代理
//        tAgentCustomersList.add(tAgentCustomers);


        List<Long> customersIdList = tAgentCustomersList.stream().map(TAgentCustomers::getCustomersId).collect(Collectors.toList());
        Result<List<TCustomerLayer>> response = userClient.selectBatchIds(customersIdList);
        logger.info("/v1/customer/layer/selectBatchIds 入参customersIdList：{} 返回值：{}", customersIdList, response);
        if (!Objects.isNull(response)) {
            if (response.isSuccess()) {
                tAgentCustomersMapper.cancelAgentBatchById(tAgentCustomersList);
                List<Long> contractBindIdList = tAgentCustomersList.stream().map(TAgentCustomers::getCommissionContractBindId).collect(Collectors.toList());
                TAgentContract tAgentContractBefore = tAgentContractBindService.queryTAgentContractByBindId(tAgentCustomers.getCommissionContractBindId());
                if(Objects.isNull(tAgentContractBefore)){
                    throw new MKTAgentException(ResultEnum.AGENT_CONTRACT_NOT_EXIST);
                }
                tAgentContractBefore.setAgentCount(tAgentContractBefore.getAgentCount() - tAgentCustomersList.size());
                tAgentContractService.saveOrUpdate(tAgentContractBefore);
                tAgentContractBindService.getBaseMapper().deleteBatchIds(contractBindIdList);
                List<TCustomerLayer> tCustomerLayerList = response.getData();
                tCustomerLayerList.stream().map(tCustomerLayer -> {
                    tCustomerLayer.setCustomerType(BaseConstants.WS_PLAYER);
                    return tCustomerLayer;
                }).collect(Collectors.toList());
                userClient.updateBatch(tCustomerLayerList);
                logger.info("/v1/customer/layer/updateBatch 入参tCustomerLayerList：{} 返回值：void", tCustomerLayerList);
            }
        }
    }

    @Override
    public void updateAgentRemark(TAgentCustomersRemarkReq tAgentCustomersRemarkReq) {
        TAgentCustomers agentCustomers = selectOne(tAgentCustomersRemarkReq.getCustomersId(), tAgentCustomersRemarkReq.getLoginName());
        if (!Objects.isNull(agentCustomers)) {
            agentCustomers.setRemarks(tAgentCustomersRemarkReq.getRemarks());
            saveOrUpdate(agentCustomers);
        } else {
            throw new MKTAgentException(ResultEnum.AGENT_NOT_EXIST);
        }
    }

    @Override
    public AgentCustomerGateResp getAgentAndContractByCustomerId(Long customerId) {
        return tAgentCustomersMapper.getAgentAndContractByCustomerId(customerId);
    }

    @Override
    public List<TAgentCustomersFrontResp> subAgentExport(TAgentCustomersQueryReq tAgentCustomersQueryReq, HttpServletResponse response) {
        TAgentCustomers tAgentCustomers = null;
        if (StringUtils.isNotBlank(tAgentCustomersQueryReq.getLevelOneAgent())) {
            tAgentCustomers = selectOne(tAgentCustomersQueryReq.getLevelOneAgent());
        }
        Integer parentAgentLevel = tAgentCustomers.getAgentLevel();
        Integer total = tAgentCustomersMapper.count(tAgentCustomersQueryReq);
        if (Objects.isNull(total) || total == 0) {
            return null;
        }
        // 导出全部数据
        tAgentCustomersQueryReq.setIsPage(false);
        List<TAgentCustomersResp> tAgentCustomersRespList = tAgentCustomersMapper.queryList(tAgentCustomersQueryReq);
        List<TAgentCustomersFrontResp> TAgentCustomersFrontRespList = BeanCopyUtil.copyListProperties(tAgentCustomersRespList, TAgentCustomersFrontResp::new, (tAgentCustomersResp, tAgentCustomersFrontResp) -> {
            tAgentCustomersFrontResp.setAgentType(tAgentCustomersResp.getAgentLevel().equals(parentAgentLevel + 1) ? SubAgentTypeEnum.DIRECT_AGENTS.getValue()
                    : SubAgentTypeEnum.DOWNLINE_AGENTS.getValue());
        });
        return TAgentCustomersFrontRespList;

        /*try {
            ExcelUtil.export(TAgentCustomersFrontRespList,TAgentCustomersFrontResp.class,"tAgentCustomersRespList",response);
        }catch (IOException e){
            logger.error(ResultEnum.AGENT_EXPORT_FAIL.getMessage() + e);
            throw new MKTAgentException(ResultEnum.AGENT_EXPORT_FAIL);
        }*/
    }

    @Override
    public TAgentCustomers getAgentByLoginName(String loginName) {
        TAgentCustomers tAgentCustomers = this.getBaseMapper().selectOne(new LambdaQueryWrapper<TAgentCustomers>()
                .eq(TAgentCustomers::getLoginName, loginName));
        if (tAgentCustomers == null) {
            throw new MKTAgentException(ResultEnum.AGENT_NOT_EXIST);
        }
        return tAgentCustomers;
    }

    @Override
    public List<TAgentCustomers> getAgentListByLoginName(AgentListRequest request) {
        // pattern 1.查询目标代理的代理树(下级所有代理)
        if (request.getIsQueryTree()) {
            AgentListCopyRequest agentListCopyRequest = new AgentListCopyRequest();
            BeanUtils.copyProperties(request, agentListCopyRequest);
            return getAgentList(agentListCopyRequest);
        }

        // pattern 2.条件查询代理(不查询下级)
        List<TAgentCustomers> tAgentCustomers = this.getBaseMapper().selectList(new LambdaQueryWrapper<TAgentCustomers>()
                .like(TAgentCustomers::getLoginName, request.getRootParentName()) // 登录名模糊查询
                .ge(TAgentCustomers::getAgentLevel, request.getLevelStart()) // 代理查询起始等级
                .le(TAgentCustomers::getAgentLevel, request.getLevelEnd())); // 代理查询终了等级
        if (CollectionUtils.isEmpty(tAgentCustomers)) {
            //throw new MKTAgentException(ResultEnum.AGENT_NOT_EXIST);
            return new ArrayList<>();
        }
        return tAgentCustomers;
    }

    @Override
    public UserResp queryCustomers(String loginName) {
        /*TCustomerLayer tCustomerLayer = tCustomerLayerMapper.selectOne(new LambdaQueryWrapper<TCustomerLayer>()
                .eq(TCustomerLayer::getLoginName, loginName)
                .eq(TCustomerLayer::getIsDeleted, 0));*/

        TCustomerLayer tCustomerLayer = tCustomerLayerMapper.selectOne(new LambdaQueryWrapper<TCustomerLayer>()
                .eq(TCustomerLayer::getLoginName, loginName));
        if (Objects.isNull(tCustomerLayer)) {
            throw new MKTAgentException(ResultEnum.AGENT_NOT_EXIST);
        }
        UserResp userResp = new UserResp();
        userResp.setLoginName(tCustomerLayer.getLoginName());
        userResp.setCustomerId(tCustomerLayer.getCustomerId());
        return userResp;
    }

    /**
     * 查询代理树
     *
     * @param request AgentListRequest
     * @return 代理列表
     */
    private List<TAgentCustomers> getAgentList(AgentListCopyRequest request) {
        List<TAgentCustomers> list = new ArrayList<>();
        // 当前登录代理
        TAgentCustomers tAgentCustomers = tAgentCustomersMapper.selectOne(Wrappers.<TAgentCustomers>lambdaQuery()
                .eq(StringUtils.isNotEmpty(request.getRootParentName()), TAgentCustomers::getLoginName, request.getRootParentName()));
        if (tAgentCustomers.getAgentLevel() >= request.getLevelStart() && tAgentCustomers.getAgentLevel() <= request.getLevelEnd()) {
            list.add(tAgentCustomers);
        }
        // 添加下级代理
        list.addAll(tAgentCustomersMapper.getAgentList(request));
        if (CollectionUtils.isEmpty(list)) {
            //throw new MKTAgentException(ResultEnum.AGENT_NOT_EXIST);
            return new ArrayList<>();
        }
        return list;
    }

    //selectById
    public TAgentCustomers selectOne(Long customersId, String loginName) {
        //select by id
        QueryWrapper<TAgentCustomers> wrapper = new QueryWrapper();
        if (customersId != null && StringUtils.isNotBlank(loginName)) {
            wrapper.eq("customers_id", customersId);
            wrapper.eq("login_Name", loginName);
        } else {
            return null;
        }
        TAgentCustomers tAgentCustomers = tAgentCustomersMapper.selectOne(wrapper);
        return tAgentCustomers;
    }

    public TAgentCustomers selectOne(Long customersId) {
        //select by id
        QueryWrapper<TAgentCustomers> wrapper = new QueryWrapper();
        if (customersId != null) {
            wrapper.eq("customers_id", customersId);
        } else {
            return null;
        }
        TAgentCustomers tAgentCustomers = tAgentCustomersMapper.selectOne(wrapper);
        return tAgentCustomers;
    }

    //selectByLoginName
    @Override
    public TAgentCustomers selectOne(String loginName) {
        if (StringUtils.isBlank(loginName)) {
            logger.info("loginName :{} is null", loginName);
            return null;
        }
        //select by id
        QueryWrapper<TAgentCustomers> wrapper = new QueryWrapper();
        wrapper.eq("login_name", loginName);
        return tAgentCustomersMapper.selectOne(wrapper);
    }

    @Override
    @Transactional
    public void userToAgent(TAgentCustomersReq tAgentCustomersReq) {
        TAgentCustomers tAgentCustomers = tAgentCustomersMapper.getCancelAgentByCustomerId(tAgentCustomersReq.getCustomersId());
        if (!Objects.isNull(tAgentCustomers)) {
            BeanUtils.copyProperties(tAgentCustomersReq, tAgentCustomers, "loginName", "customersId", "id");
            tAgentCustomers.setIsDeleted(0);
        } else {
            tAgentCustomers = new TAgentCustomers();
            BeanUtils.copyProperties(tAgentCustomersReq, tAgentCustomers, "id");
        }
        TAgentContract tAgentContract = tAgentContractService.selectOne(tAgentCustomersReq.getCommissionContractCode());
        TAgentContractBind tAgentContractBind = TAgentContractBind.builder().loginName(tAgentCustomers.getLoginName()).commissionContractId(tAgentContract.getId()).
                createBy(tAgentCustomers.getCreateBy()).percentageDetails(tAgentContract.getPercentageDetails()).build();
        tAgentContractBindService.save(tAgentContractBind);
        tAgentCustomers.setCommissionContractBindId(tAgentContractBind.getId());
        tAgentCustomers.setParentName(tAgentCustomersReq.getCreateBy());
        tAgentContract.setAgentCount(tAgentContract.getAgentCount() + 1);
        tAgentContractService.saveOrUpdate(tAgentContract);
        if (null != tAgentCustomers.getId()) {
            //重置创建时间
            tAgentCustomers.setCreateTime(LocalDateTime.now().toString());
            tAgentCustomersMapper.updateCancelAgentToAgent(tAgentCustomers);
        } else {
            this.save(tAgentCustomers);
        }
        //referralId 1期隐藏
        /*TAgentReferralCode tAgentReferralCode = tAgentReferralCodeService.getOne(new LambdaQueryWrapper<TAgentReferralCode>().eq(TAgentReferralCode::getReferralId, tAgentCustomersReq.getReferralId()));
        if(Objects.isNull(tAgentReferralCode)){
            tAgentReferralCodeService.save(TAgentReferralCode.builder().loginName(tAgentCustomers.getLoginName()).referralId(tAgentCustomersReq.getReferralId()).createBy(tAgentCustomersReq.getCreateBy())
                    .build());
        }*/

        TAgentWallet wallet = fundWalletMapper.selectOne(new LambdaQueryWrapper<TAgentWallet>()
                .eq(TAgentWallet::getAgentId, tAgentCustomers.getCustomersId())
                .eq(TAgentWallet::getLoginName, tAgentCustomers.getLoginName())
                .eq(TAgentWallet::getIsEnable, 1));
        if (Objects.isNull(wallet)) {
            FundAgentReq fundAgentReq = new FundAgentReq();
            fundAgentReq.setAgentId(tAgentCustomers.getCustomersId());
            fundAgentReq.setLoginName(tAgentCustomers.getLoginName());
            fundAgentReq.setProductId(tAgentCustomers.getProductId());
            fundService.addAgentWallet(fundAgentReq);
        }
    }

    @Override
    public void subUserToAgent(TAgentCustomersReq tAgentCustomersReq) {
        TAgentCustomers tAgentCustomers = tAgentCustomersMapper.getCancelAgentByCustomerId(tAgentCustomersReq.getCustomersId());
        if (!Objects.isNull(tAgentCustomers)) {
            BeanUtils.copyProperties(tAgentCustomersReq, tAgentCustomers, "loginName", "customersId", "id");
            tAgentCustomers.setIsDeleted(0);
        } else {
            tAgentCustomers = new TAgentCustomers();
            BeanUtils.copyProperties(tAgentCustomersReq, tAgentCustomers);
        }
        TAgentCustomers parentTAgentCustomers = selectOne(Long.valueOf(tAgentCustomersReq.getParentId()));
        if (Objects.isNull(parentTAgentCustomers)) {
            logger.info(ResultEnum.PARENT_AGENT_NULL.getMessage() + tAgentCustomersReq.getParentId());
            throw new MKTAgentException(ResultEnum.PARENT_AGENT_NULL);
        } else {
            TAgentContract tAgentContract = tAgentContractBindService.queryTAgentContractByBindId(parentTAgentCustomers.getCommissionContractBindId());
            TAgentContractBind tAgentContractBind = TAgentContractBind.builder().loginName(tAgentCustomers.getLoginName()).commissionContractId(tAgentContract.getId()).
                    createBy(tAgentCustomers.getCreateBy()).percentageDetails(SerializationUti.serializeToString(tAgentCustomersReq.getSettlementPercentageList())).build();
            tAgentContractBindService.save(tAgentContractBind);
            tAgentCustomers.setCommissionContractBindId(tAgentContractBind.getId());
            tAgentCustomers.setParentName(parentTAgentCustomers.getLoginName());
            tAgentCustomers.setIsEnable(parentTAgentCustomers.getIsEnable());
            tAgentCustomers.setCreateBy(parentTAgentCustomers.getCreateBy());
            tAgentCustomers.setAgentType(parentTAgentCustomers.getAgentType());
            tAgentCustomers.setAgentLevel(parentTAgentCustomers.getAgentLevel() + 1);
            tAgentCustomers.setProductId(parentTAgentCustomers.getProductId());
            tAgentCustomers.setSiteId(parentTAgentCustomers.getSiteId());
            tAgentCustomers.setParentId(parentTAgentCustomers.getCustomersId());
            tAgentContract.setAgentCount(tAgentContract.getAgentCount() + 1);
            tAgentContractService.saveOrUpdate(tAgentContract);
            if (null != tAgentCustomers.getId()) {
                tAgentCustomersMapper.updateCancelAgentToAgent(tAgentCustomers);
            } else {
                this.save(tAgentCustomers);
            }
            //referralId 1期隐藏 ,2期放开
            /*TAgentReferralCode tAgentReferralCode = tAgentReferralCodeService.getOne(new LambdaQueryWrapper<TAgentReferralCode>().eq(TAgentReferralCode::getReferralId, tAgentCustomersReq.getReferralId()));
            if(Objects.isNull(tAgentReferralCode)){
                tAgentReferralCodeService.save(TAgentReferralCode.builder().loginName(tAgentCustomers.getLoginName()).referralId(tAgentCustomersReq.getReferralId()).createBy(tAgentCustomersReq.getCreateBy())
                        .build());
            }*/
        }

        TAgentWallet wallet = fundWalletMapper.selectOne(new LambdaQueryWrapper<TAgentWallet>()
                .eq(TAgentWallet::getAgentId, tAgentCustomers.getCustomersId())
                .eq(TAgentWallet::getLoginName, tAgentCustomers.getLoginName())
                .eq(TAgentWallet::getIsEnable, 1));
        if (Objects.isNull(wallet)) {
            FundAgentReq fundAgentReq = new FundAgentReq();
            fundAgentReq.setAgentId(tAgentCustomers.getCustomersId());
            fundAgentReq.setLoginName(tAgentCustomers.getLoginName());
            fundAgentReq.setProductId(tAgentCustomers.getProductId());
            fundService.addAgentWallet(fundAgentReq);
        }
    }

    //递归获取1级代理
    @Override
    public TAgentCustomers queryTopAgent(Long customersId) {
        //select by id
        QueryWrapper<TAgentCustomers> wrapper = new QueryWrapper();
        if (customersId != null) {
            wrapper.eq("customers_id", customersId);
        } else {
            return null;
        }
        TAgentCustomers tAgentCustomers = tAgentCustomersMapper.selectOne(wrapper);
        if (tAgentCustomers.getAgentLevel().equals(1)) {
            return tAgentCustomers;
        }
        return queryTopAgent(tAgentCustomers.getParentId());
    }

    //递归获取1级代理
    @Override
    public TAgentCustomers queryTopAgentByAccount(String account) {
        TAgentCustomers tAgentCustomers = tAgentCustomersMapper.selectOne(new LambdaQueryWrapper<TAgentCustomers>().eq(TAgentCustomers::getLoginName,account).eq(TAgentCustomers::getIsEnable,1)
                .eq(TAgentCustomers::getIsDeleted,0));
        if (tAgentCustomers.getAgentLevel().equals(1)) {
            return tAgentCustomers;
        }
        return queryTopAgentByAccount(tAgentCustomers.getParentName());

    }

    //判断当前代理是否允许创建下级代理
    public Boolean agentAllow(Long customersId, Integer agentLevel) {
        TAgentCustomers topTAgentCustomers = queryTopAgent(customersId);
        if (ObjectUtils.isEmpty(topTAgentCustomers)) {
            return false;
        }
        return !topTAgentCustomers.getDevelopableLevel().equals(agentLevel - 1);
    }

    public Boolean checkLoginNameAndReferralId(String loginName, String referralId) {
        TAgentCustomers tAgentCustomer = selectOne(loginName);
        //referralId 1期隐藏 ,2期放开
        //TAgentReferralCode tAgentReferralCode=tAgentReferralCodeService.getOne(new LambdaQueryWrapper<TAgentReferralCode>().eq(TAgentReferralCode::getReferralId,referralId));
        if (Objects.isNull(tAgentCustomer)) {//&&Objects.isNull(tAgentReferralCode) referralId 1期隐藏 ,2期放开
            return true;
        }
        return false;
    }


    public CreateNewAccountResponse addInterWSCustomer(TAgentCustomersReq tAgentCustomersReq, String ip) {

        try {
            InterWSCustomers interWSCustomers = new InterWSCustomers();
            WSQueryCustomers queryCustomer = new WSQueryCustomers();
            queryCustomer.setProductId(tAgentCustomersReq.getProductId());
            queryCustomer.setLoginName(tAgentCustomersReq.getCreateBy());
            queryCustomer.setCustomerId(tAgentCustomersReq.getParentId());
            //referralId 1期隐藏 ,2期放开
            if (checkLoginNameAndReferralId(tAgentCustomersReq.getLoginName(), tAgentCustomersReq.getReferralId())) {
                logger.info("checkLoginNameAndReferralId successful");
                if (!BaseConstants.C66_ADMIN.equals(tAgentCustomersReq.getCreateBy())) {
                    WsTemplate wsTemplate = new WsTemplate(QUERY_CUSTOMER_BASIC_URL, wsRestInter);
                    Result<WSCustomers> parentWsCustomersResponse = wsTemplate.getCustomer(queryCustomer);
                    if (!parentWsCustomersResponse.isSuccess()) {
                        logger.error(ResultEnum.WS_QUERY_CUSTOMER_FAIL.getMessage() + "customersId:{}, loginName:{} ", tAgentCustomersReq.getParentId(), tAgentCustomersReq.getCreateBy());
                        throw new MKTAgentException(ResultEnum.WS_QUERY_CUSTOMER_FAIL);
                    }

                    WSCustomers parentWsCustomers = parentWsCustomersResponse.getData();
                    TAgentCustomers parentTAgentCustomers = selectOne(Long.valueOf(parentWsCustomers.getCustomerId()), parentWsCustomers.getLoginName());
                    //校验父级权限
                    if (agentAllow(parentTAgentCustomers.getCustomersId(), parentTAgentCustomers.getAgentLevel())) {
                        //校验佣金比例start
                        List<SettlementPercentageReq> settlementPercentageReqList = tAgentContractBindService.queryPercentageDetails(parentTAgentCustomers.getCustomersId());
                        List<SettlementPercentageReq> currentPercentageReqList = tAgentCustomersReq.getSettlementPercentageList();
                        tAgentContractBindService.percentageDetailsAllow(settlementPercentageReqList, currentPercentageReqList);
                        //校验佣金比例end
                        interWSCustomers.setCreatedBy(parentWsCustomers.getLoginName());
                        interWSCustomers.setPwd(WSUtils.encryptedPasswordOf(tAgentCustomersReq.getPwd(), tAgentCustomersReq.getLoginName()));
                        interWSCustomers.setProductId(parentWsCustomers.getProductId());
                        interWSCustomers.setLoginName(tAgentCustomersReq.getLoginName());
                        interWSCustomers.setLocale(parentWsCustomers.getLocale());
                        interWSCustomers.setCustomerType(parentWsCustomers.getCustomerType());
                        interWSCustomers.setParentId(parentWsCustomers.getCustomerId());
                        interWSCustomers.setIpAddress(ip);
                        interWSCustomers.setSiteId(parentWsCustomers.getSiteId());
                    } else {
                        logger.info(ResultEnum.AGENT_HAVE_NOT_POWER.getMessage() + "customersId:{} ", parentTAgentCustomers.getCustomersId());
                        throw new MKTAgentException(ResultEnum.AGENT_HAVE_NOT_POWER);
                    }
                } else {
                    interWSCustomers.setCreatedBy(BaseConstants.C66_ADMIN);
                    interWSCustomers.setPwd(WSUtils.encryptedPasswordOf(tAgentCustomersReq.getPwd(), tAgentCustomersReq.getLoginName()));
                    interWSCustomers.setProductId(tAgentCustomersReq.getProductId());
                    interWSCustomers.setLoginName(tAgentCustomersReq.getLoginName());
                    interWSCustomers.setSiteId(tAgentCustomersReq.getSiteId());
                    //ws字典值,3为代理
                    interWSCustomers.setCustomerType(String.valueOf(BaseConstants.WS_AGENT));
                    interWSCustomers.setIpAddress(ip);
                }
                interWSCustomers.setMarginSwitch("0");
            } else {//referralId 1期隐藏 ,2期放开
                logger.info(ResultEnum.REFERRALID_LOGINNAME_DUPLICATE.getMessage());
                throw new MKTAgentException(ResultEnum.REFERRALID_LOGINNAME_DUPLICATE);
            }
            String userCenterIsOpen = userCenterConfig.getUserCenterIsOpen();
            logger.info("userCenterIsOpen( 1-UserCenter分支; 0-WS分支 ): {}", userCenterIsOpen);
            Result<CreateNewAccountResponse> response = FunctionHelper.doIt(Conditions.userCenterIsOpen(userCenterIsOpen),
                    new UserCenterTemplate(USER_CENTER_CREATE_NEW_ACCOUNT_URL, userCenterRestInter, wsRestInter)::createNewAccount,
                    new WsTemplate(CREATE_NEW_ACCOUNT_URL, wsRestInter)::createNewAccount, interWSCustomers, "7;office");
            if (Objects.isNull(response) || null == response.getData()) {
                logger.error(ResultEnum.WS_CREATE_CUSTOMER_RESPONSE_NULL.getMessage());
                throw new MKTAgentException(ResultEnum.WS_CREATE_CUSTOMER_RESPONSE_NULL);
            } else {
                if (!response.isSuccess()) {
                    logger.error(ResultEnum.WS_CREATE_CUSTOMER_FAIL.getMessage() + "---:{}", response.getMessage());
                    throw new MKTAgentException(response.getMessage());
                }
                logger.info("call ws response is :{}", response.getData().toString());
                return response.getData();
            }
        } catch (MKTAgentException e) {
            logger.error("MKTAgentException---ws addInterWSCustomer is exception:" + e);
            throw e;
        } catch (Exception e) {
            logger.error("Exception----ws addInterWSCustomer is exception:" + e);
            throw new MKTAgentException(e.getMessage(), ResultEnum.UNEXPECTED_FAIL.getCode());
        }
    }


    public List<TAgentCustomers> updateAgentListLevel(Long customersId, Integer currentLevel, List<TAgentCustomers> list) {
        //select by id
        QueryWrapper<TAgentCustomers> wrapper = new QueryWrapper();
        if (customersId != null) {
            wrapper.eq("parent_id", customersId);
        } else {
            return Arrays.asList();
        }
        List<TAgentCustomers> tAgentCustomersList = tAgentCustomersMapper.selectList(wrapper);
        if (!CollectionUtils.isEmpty(tAgentCustomersList)) {
            tAgentCustomersList.stream().map(tAgentCustomers -> {
                tAgentCustomers.setAgentLevel(currentLevel);
                tAgentCustomersMapper.updateById(tAgentCustomers);
                return tAgentCustomers;
            }).collect(Collectors.toList());
            list.addAll(tAgentCustomersList);
            for (int i = 0; i < tAgentCustomersList.size(); i++) {
                return updateAgentListLevel(tAgentCustomersList.get(i).getCustomersId(), tAgentCustomersList.get(i).getAgentLevel() + 1, list);
            }
        }
        return Arrays.asList();
    }

    @Override
    public ResultEnum checkAgentIsTop(TAgentCustomersQueryReq tAgentCustomersQueryReq) {
        if (!tAgentCustomersQueryReq.getLevelOneAgent().equals(BaseConstants.C66_ADMIN)) {
            TAgentCustomers customer = tAgentCustomersMapper.selectOne(new LambdaQueryWrapper<TAgentCustomers>()
                    .eq(TAgentCustomers::getLoginName, tAgentCustomersQueryReq.getLevelOneAgent())
                    .eq(TAgentCustomers::getAgentLevel, 1));
            if (Objects.isNull(customer)) {
                logger.error("this agent is not top one");
                return ResultEnum.AGENT_NOT_TOP_ONE;
            }
        }
        return ResultEnum.SUCCESS;
    }

    @Override
    public boolean isAgent(String loginName) {
        String result = tCustomerLayerMapper.isAgent(loginName);
        // 判断该用户是否为代理，为代理时返回true
        if ("3".equals(result)) {
            return true;
        }
        return false;
    }

    @Override
    public Page<String> queryAgentCustomers(AgentCustomersReq req) {
        Page<String> page = new Page<>();
        // 查总记录数
        Integer total = tAgentCustomersMapper.queryAgentCustomersCount(req);
        // 查记录
        List<String> response = tAgentCustomersMapper.queryAgentCustomers(req);
        page.setCurrent(req.getPageNum());
        page.setSize(req.getPageSize());
        page.setPages(total / req.getPageSize());
        page.setRecords(response).setTotal(total);
        return page;
    }

    @Override
    public Integer selectTotalAgents(String loginName) {
        return tAgentCustomersMapper.selectTotalAgents(loginName);
    }

    @Override
    public Integer selectDirectAgents(String loginName) {
        return tAgentCustomersMapper.selectDirectAgents(loginName);
    }

}
