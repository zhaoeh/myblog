package com.mkt.agent.api.migration;

import com.alibaba.fastjson.JSONObject;
import com.mkt.agent.api.exception.MKTAgentException;
import com.mkt.agent.api.mapper.TCustomerLayerMapper;
import com.mkt.agent.api.migration.config.MigrationConfig;
import com.mkt.agent.api.migration.entity.AgentCustomers;
import com.mkt.agent.api.service.TAgentContractBindService;
import com.mkt.agent.api.service.TAgentContractService;
import com.mkt.agent.api.service.TAgentCustomersService;
import com.mkt.agent.api.service.TAgentReferralCodeService;
import com.mkt.agent.common.entity.PageReq;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.integration.utils.HttpClientUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * @Description: 分页获取数据模块
 * @Author: PTMinnisLi
 * @Date: 2023/6/29
 */
@Slf4j
@Component
public class AgentMigrationAccessProcess {

    @Autowired
    private TAgentContractBindService tAgentContractBindService;

    @Autowired
    private TAgentReferralCodeService tAgentReferralCodeService;

    @Autowired
    private TAgentCustomersService tAgentCustomersService;

    @Autowired
    private TAgentContractService tAgentContractService;

    @Autowired
    private TCustomerLayerMapper tCustomerLayerMapper;

    @Resource
    private MigrationConfig config;

    private Map<Long,String> agentMap = new  HashMap<>();

    private Map<String,Long> agentMap2 = new  HashMap<>();

    Map<String,Boolean> referralIdMap = new HashMap<>();

    TAgentContract generalContract = null;

    TAgentContract professionalContract = null;



    public List<AgentCustomers> oldDataMigrationGetData(Integer pageIndex, String baseUrl) {

        generalContract =  null;

        professionalContract = null;

        agentMap = new  HashMap<>();

        agentMap2 = new  HashMap<>();

        referralIdMap = new HashMap<>();

        List<Future<List<AgentCustomers>>> futureList = new ArrayList<>();
        List<AgentCustomers> pageResult = new ArrayList<>();

        // 获取代理数据总量
        Integer agentCount;
        Map<String, String> countRequest = new HashMap<>();
        countRequest.put("productId", "C66");
        countRequest.put("loginFlag", "1");
        String response = null;
        try {
            response = HttpClientUtil.postJson(baseUrl + "/webApi/countAgentCustomers.do", JSONObject.toJSONString(countRequest));
        } catch (Exception e) {
            log.error("访问 agent老代理系统查询数量接口[/webApi/countAgentCustomers.do] 失败");
            throw new MKTAgentException("访问 agent老代理系统查询数量接口[/webApi/countAgentCustomers.do] 失败");
        }
        if (StringUtils.isEmpty(response)) {
            log.error("访问 agent老代理系统查询数量接口[/webApi/countAgentCustomers.do] 响应为空");
            throw new MKTAgentException("访问 agent老代理系统查询数量接口[/webApi/countAgentCustomers.do] 响应为空");
        }

        // 解析响应数据
        JSONObject jsonResponse = null;
        try {
            jsonResponse = JSONObject.parseObject(response);
        } catch (Exception e) {
            log.error("访问 agent老代理系统查询数量接口[/webApi/countAgentCustomers.do] response解析失败，源数据为{}", response);
            throw new MKTAgentException("访问 agent老代理系统查询数量接口[/webApi/countAgentCustomers.do] 失败，源数据为: " + response);
        }

        if (!Objects.isNull(jsonResponse.get("error"))
                || !(Boolean) jsonResponse.get("success")
                || ObjectUtils.isEmpty(jsonResponse.get("data"))) {
            log.error("访问 agent老代理系统查询数量接口[/webApi/countAgentCustomers.do] 失败，具体信息为: {}", jsonResponse);
            throw new MKTAgentException("访问 agent老代理系统查询数量接口[/webApi/countAgentCustomers.do] 失败，具体信息为: " + jsonResponse);
        }
        agentCount = (Integer) jsonResponse.get("data");
        if (agentCount == 0) {
            log.error("访问 agent老代理系统查询数量接口[/webApi/countAgentCustomers.do]  查询数量为0，异常结束");
            throw new MKTAgentException("访问 agent老代理系统查询数量接口[/webApi/countAgentCustomers.do]  查询数量为0，异常结束");
        }
        log.info("访问 agent老代理系统查询数量接口[/webApi/countAgentCustomers.do]  查询结束, 数据总量为: [{}] 条", agentCount);

        // 根据数据总量进行分页查询，汇总数据返回
        // 计算页数(线程池数量)，相除有余数进1
        int totalPages = agentCount % pageIndex == 0 ? agentCount / pageIndex : (agentCount / pageIndex + 1);
        ExecutorService agentExecutor = Executors.newFixedThreadPool(20);

        for (int i = 1; i <= totalPages; i++) {
            PageReq pageReq = new PageReq(i, pageIndex);
            AgentQueryTask agentQueryTask = new AgentQueryTask(pageReq, baseUrl);
            Future<List<AgentCustomers>> future = agentExecutor.submit(agentQueryTask);
            futureList.add(future);
        }

        // 线程池关闭
        agentExecutor.shutdown();

        // 处理各线程分页查询结果
        for (Future<List<AgentCustomers>> future : futureList) {
            try {
                pageResult.addAll(future.get(10, TimeUnit.MINUTES));
                // 处理每一页的查询结果
            } catch (Exception e) {
                throw new MKTAgentException("访问 agent老代理系统分页查询接口[/webApi/queryAgentCustomers.do]  分页查询子任务异常结束，具体错误信息为:" + e.getMessage());
            }
        }

        if (CollectionUtils.isEmpty(pageResult)) {
            log.error("访问 agent老代理系统分页查询接口[/webApi/queryAgentCustomers.do]  查询数量为0，异常结束");
            throw new MKTAgentException("访问 agent老代理系统分页查询接口[/webApi/queryAgentCustomers.do]  查询数量为0，异常结束");
        }
        if (pageResult.size() != agentCount) {
            log.error("访问 agent老代理系统分页查询接口[/webApi/queryAgentCustomers.do]  分页数据与总数不一致，异常结束");
            throw new MKTAgentException("访问 agent老代理系统分页查询接口[/webApi/queryAgentCustomers.do]  分页数据与总数不一致，异常结束");
        }
        log.info("访问 agent老代理系统分页查询接口[/webApi/queryAgentCustomers.do]  查询结束, 数据总量为: [{}] 条", pageResult.size());

        agentMap =  pageResult.stream().collect(Collectors.toMap(AgentCustomers::getCustomerId,AgentCustomers::getLoginName));

        agentMap2 =  pageResult.stream().collect(Collectors.toMap(AgentCustomers::getLoginName,AgentCustomers::getCustomerId));

        return pageResult;
    }


    public String oldAgentToNewAgent(List<AgentCustomers> agentCustomersList){
        StringBuffer str = new StringBuffer();
        int count = agentCustomersList.size();
        Integer insertPageIndex = config.getInsertPageIndex();
        List<List<Integer>> list = new ArrayList<>();
        AtomicInteger num = new AtomicInteger();
        ExecutorService agentExecutor = Executors.newFixedThreadPool(20);
        List<Future<Integer>> futureList = new ArrayList<>();
        for (int i = 0; i < count; i += insertPageIndex) {
            List<AgentCustomers> chunk = agentCustomersList.subList(i, Math.min(i + insertPageIndex, agentCustomersList.size()));
            AgentBatchesInsertTask agentBatchesInsertTask = new AgentBatchesInsertTask(tAgentContractBindService,tAgentReferralCodeService,tAgentCustomersService,tAgentContractService,tCustomerLayerMapper,
                    config,agentMap,agentMap2,referralIdMap,generalContract,professionalContract,chunk);
            Future<Integer> future = agentExecutor.submit(agentBatchesInsertTask);
            futureList.add(future);
        }
        // 线程池关闭
        agentExecutor.shutdown();
        for (Future<Integer> future : futureList) {
            try {
                num.addAndGet(future.get());
                // 处理每一页的查询结果
            } catch (Exception e) {
                e.printStackTrace();
                // 恢复中断状态
                Thread.currentThread().interrupt();
            }
        }
        return str.append("数据迁移完毕,已迁移"+num.get()+"条数据").toString();
    }






}
