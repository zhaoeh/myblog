package com.mkt.agent.api.migration;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.mkt.agent.api.mapper.TCustomerLayerMapper;
import com.mkt.agent.api.migration.config.MigrationConfig;
import com.mkt.agent.api.migration.entity.AgentCustomers;
import com.mkt.agent.api.service.TAgentContractBindService;
import com.mkt.agent.api.service.TAgentContractService;
import com.mkt.agent.api.service.TAgentCustomersService;
import com.mkt.agent.api.service.TAgentReferralCodeService;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.TAgentReferralCode;
import com.mkt.agent.common.enums.CustomerTypeEnum;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.ReferralIdGenerator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.stream.Collectors;

@Slf4j
public class AgentBatchesInsertTask implements Callable<Integer> {


    private TAgentContractBindService tAgentContractBindService;

    private TAgentReferralCodeService tAgentReferralCodeService;

    private TAgentCustomersService tAgentCustomersService;

    private TAgentContractService tAgentContractService;

    private TCustomerLayerMapper tCustomerLayerMapper;

    private MigrationConfig config;

    private Map<Long,String> agentMap;

    private Map<String,Long> agentMap2;

    private Map<String,Boolean> referralIdMap;

    private TAgentContract generalContract;

    private TAgentContract professionalContract;

    private List<AgentCustomers> listPage;




    public AgentBatchesInsertTask(TAgentContractBindService tAgentContractBindService, TAgentReferralCodeService tAgentReferralCodeService, TAgentCustomersService tAgentCustomersService,
                                  TAgentContractService tAgentContractService, TCustomerLayerMapper tCustomerLayerMapper, MigrationConfig config, Map<Long, String> agentMap, Map<String, Long> agentMap2, Map<String, Boolean> referralIdMap, TAgentContract generalContract, TAgentContract professionalContract, List<AgentCustomers> listPage) {
        this.tAgentContractBindService = tAgentContractBindService;
        this.tAgentReferralCodeService = tAgentReferralCodeService;
        this.tAgentCustomersService = tAgentCustomersService;
        this.tAgentContractService = tAgentContractService;
        this.tCustomerLayerMapper = tCustomerLayerMapper;
        this.config = config;
        this.agentMap = agentMap;
        this.agentMap2 = agentMap2;
        this.referralIdMap = referralIdMap;
        this.generalContract = generalContract;
        this.professionalContract = professionalContract;
        this.listPage = listPage;
    }

    public Integer call() {
        List<TAgentContractBind> tAgentContractBindList=tAgentContractBindBatchesInsert(listPage);
        List<TAgentCustomers> tAgentCustomersList = tAgentBatchesInsert(listPage,tAgentContractBindList);
        //referralId 1期隐藏 ,2期放开
        //referralCodeBatchesInsert(tAgentCustomersList);
        batchesUpdateCustomerLayerType(tAgentCustomersList);
        return tAgentCustomersList.size();
    }


    @Transactional
    public List<TAgentContractBind> tAgentContractBindBatchesInsert(List<AgentCustomers> agentCustomersList){
        List<TAgentContractBind> tAgentContractBindList = new ArrayList<>();
        TAgentContract tAgentContract = new TAgentContract();
        for (AgentCustomers agentCustomers : agentCustomersList) {
            String planName = agentCustomers.getLineType() == 0 ? config.getGeneralContract() : config.getProfessionalContract();
            if (agentCustomers.getLineType() == 0) {
                if (Objects.isNull(generalContract)) {
                    generalContract = tAgentContractService.getOne(new LambdaQueryWrapper<TAgentContract>().eq(TAgentContract::getCommissionPlanName, planName));
                }
                tAgentContract = generalContract;
            } else {
                if (Objects.isNull(professionalContract)) {
                    professionalContract = tAgentContractService.getOne(new LambdaQueryWrapper<TAgentContract>().eq(TAgentContract::getCommissionPlanName, planName));
                }
                tAgentContract = professionalContract;
            }
            TAgentContractBind tAgentContractBind;
            if (agentCustomers.getLineType() == 0 || agentCustomers.getLineType() == 1) {
                tAgentContractBind = TAgentContractBind.builder().loginName(agentCustomers.getLoginName()).commissionContractId(tAgentContract.getId()).percentageDetails(tAgentContract.getPercentageDetails())
                        .createBy(agentCustomers.getCreatedBy()).build();
            } else {
                tAgentContractBind = TAgentContractBind.builder().loginName(agentCustomers.getLoginName()).commissionContractId(tAgentContract.getId()).createBy(agentCustomers.getCreatedBy()).build();
            }
            tAgentContractBindList.add(tAgentContractBind);
        }
        tAgentContractBindService.saveBatch(tAgentContractBindList);
        return tAgentContractBindList;
    }

    @Transactional
    public List<TAgentCustomers> tAgentBatchesInsert(List<AgentCustomers> agentCustomersList, List<TAgentContractBind> tAgentContractBindList){
        List<TAgentCustomers> tAgentCustomersList = new ArrayList<>();
        Map<String,Long> map =  tAgentContractBindList.stream().collect(Collectors.toMap(TAgentContractBind::getLoginName,TAgentContractBind::getId));
        agentCustomersList.forEach(agentCustomers->{
            tAgentCustomersList.add(TAgentCustomers.builder().customersId(agentCustomers.getCustomerId()).loginName(agentCustomers.getLoginName()).productId(agentCustomers.getProductId())
                    .parentId(agentCustomers.getParentId()!=null?agentCustomers.getParentId(): agentMap2.get(BaseConstants.C66_ADMIN)).isEnable(agentCustomers.getLoginFlag())
                    .createBy(agentCustomers.getParentId()!=null?agentMap.get(agentCustomers.getParentId()): BaseConstants.C66_ADMIN)
                    .parentName(agentCustomers.getParentId()!=null?agentMap.get(agentCustomers.getParentId()): BaseConstants.C66_ADMIN)
                    .agentLevel(agentCustomers.getLineType()==0 || agentCustomers.getLineType()==1 ? 1 :agentCustomers.getLineType()).agentType(agentCustomers.getLineType()==0? 0 : 1)
                    .developableLevel(agentCustomers.getLineType()==0 || agentCustomers.getLineType()==1 ? 3 : null).createTime(DateUtils.dateToDateTime(agentCustomers.getCreatedDate()))
                    .commissionContractBindId(map.get(agentCustomers.getLoginName())).build());
        });
        tAgentCustomersService.saveBatch(tAgentCustomersList);
        return tAgentCustomersList;
    }
    @Transactional
    public void batchesUpdateCustomerLayerType(List<TAgentCustomers> tAgentCustomersList){
        List<Long> customerIdList = tAgentCustomersList.stream().map(TAgentCustomers::getCustomersId).collect(Collectors.toList());
        List<TCustomerLayer> tCustomerLayerList = tCustomerLayerMapper.selectList(new LambdaQueryWrapper<TCustomerLayer>().in(TCustomerLayer::getCustomerId,customerIdList));
        tCustomerLayerList.forEach(tCustomerLayer->{
            tCustomerLayer.setCustomerType(CustomerTypeEnum.AGENT.getValue());
        });
        if(!CollectionUtils.isEmpty(tCustomerLayerList)){
            tCustomerLayerMapper.updateBatch(tCustomerLayerList);
            Map<Long,Integer> map =  tCustomerLayerList.stream().collect(Collectors.toMap(TCustomerLayer::getCustomerId,TCustomerLayer::getSiteId));
            tAgentCustomersList.forEach(tAgentCustomers->{
                tAgentCustomers.setSiteId(map.get(tAgentCustomers.getCustomersId()));
            });
            tAgentCustomersService.updateBatchById(tAgentCustomersList);
        }else {
            return;
        }
    }

    @Transactional
    public void referralCodeBatchesInsert(List<TAgentCustomers> tAgentCustomersList){
        List<TAgentReferralCode> tAgentReferralCodeList = new ArrayList<>();
        tAgentCustomersList.forEach(agentCustomers->{
            String referralId = checkReferralId();
            tAgentReferralCodeList.add(TAgentReferralCode.builder().loginName(agentCustomers.getLoginName()).referralId(referralId).createBy(agentCustomers.getParentName()).build());
        });
        tAgentReferralCodeService.saveBatch(tAgentReferralCodeList);
    }


    public String checkReferralId(){
        String referralId = ReferralIdGenerator.generateReferralId();
        if(referralIdMap.get(referralId)!=null && referralIdMap.get(referralId)){
            return checkReferralId();
        }else {
            referralIdMap.put(referralId,true);
        }
        return referralId;
    }
}
