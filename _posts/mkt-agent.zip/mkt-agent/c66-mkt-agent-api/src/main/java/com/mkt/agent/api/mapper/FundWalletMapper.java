package com.mkt.agent.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.api.entity.TAgentWallet;

import java.util.List;

/**
 * @ClassName WalletMapper
 * @Description 佣金钱包
 * @Author TJSAlex
 * @Date 2023/5/23 16:37
 * @Version 1.0
 **/
public interface FundWalletMapper extends BaseMapper<TAgentWallet> {

    List<TAgentWallet> selectByAgentIds(List<Long> agentIds);
}
