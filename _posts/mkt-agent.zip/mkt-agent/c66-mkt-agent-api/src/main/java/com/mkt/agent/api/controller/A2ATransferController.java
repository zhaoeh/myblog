package com.mkt.agent.api.controller;

import com.mkt.agent.api.service.A2ATransferService;
import com.mkt.agent.common.entity.api.atransferapi.A2ATransferEntity;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.atransferapi.request.A2ATransferListReq;
import com.mkt.agent.common.entity.api.atransferapi.request.A2ATransferReq;
import com.mkt.agent.integration.entities.PageModelExt;
import com.mkt.agent.integration.entities.Response;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Description 代理给代理转账
 * @Classname A2ATransferController
 * @Date 2023/6/21 13:52
 * @Created by TJSLucian
 */
@RestController
@RequestMapping("/A2A")
public class A2ATransferController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private A2ATransferService a2ATransferService;

    @PostMapping(value = "/create")
    public Result<Boolean> createA2ATrans(@RequestBody A2ATransferReq req) {
        try {
            Result<Boolean> resp = a2ATransferService.createA2ATrans(req);
            if (resp.isSuccess()) {
                logger.info("/A2A/create 入参A2ATransferReq：{} 返回值：{}", req.toString(), resp.getData());
                return resp;
            } else {
                logger.error("/A2A/create 出异常了，入参A2ATransferReq：{} 异常信息：{}", req.toString(), resp.getMessage());
                return Result.fail(resp.getMessage());
            }
        } catch (Exception e) {
            logger.error("/A2A/create 出异常了，入参A2ATransferReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping(value = "/queryList")
    public Result<PageModelExt<A2ATransferEntity>> queryA2ATransList(@RequestBody A2ATransferListReq req) {
        try {
            Result<PageModelExt<A2ATransferEntity>> resp = a2ATransferService.queryA2ATransList(req);
            if (resp.isSuccess()) {
                logger.info("/A2A/queryList 入参A2ATransferListReq：{} 返回值：{}", req.toString(), resp.getData().getData().toString());
                return resp;
            } else {
                logger.error("/A2A/queryList 出异常了，入参A2ATransferListReq：{} 异常信息：{}", req.toString(), resp.getMessage());
                return Result.fail(resp.getMessage());
            }
        } catch (Exception e) {
            logger.error("/A2A/queryList 出异常了，入参A2ATransferListReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


}
