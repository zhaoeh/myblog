package com.mkt.agent.api.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cn.schema.customers.WSCustomers;
import com.mkt.agent.api.entity.req.PlayerCustomersReq;
import com.mkt.agent.api.entity.req.TAgentCustomersReq;
import com.mkt.agent.api.exception.MKTAgentException;
import com.mkt.agent.api.fast.FastContextBuilder;
import com.mkt.agent.api.helper.BatchUserHelper;
import com.mkt.agent.api.mapper.*;
import com.mkt.agent.api.service.BatchService;
import com.mkt.agent.api.service.PlayerCustomersService;
import com.mkt.agent.api.service.TAgentCustomersService;
import com.mkt.agent.common.config.SystemConfig;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.dto.BatchAccountInfoDTO;
import com.mkt.agent.common.entity.*;
import com.mkt.agent.common.entity.api.agentapi.BatchContainer;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomersBranch;
import com.mkt.agent.common.entity.api.agentapi.requests.BatchQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentCustomersBatchReq;
import com.mkt.agent.common.entity.api.agentapi.responses.BatchQueryResp;
import com.mkt.agent.common.entity.api.userapi.requests.PlayerCustomersBatchReq;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.fast.event.CreateAgentEvent;
import com.mkt.agent.common.helper.FunctionHelper;
import com.mkt.agent.common.helper.Conditions;
import com.mkt.agent.common.utils.*;
import com.mkt.agent.integration.config.UserCenterConfig;
import com.mkt.agent.integration.config.WSConfig;
import com.mkt.agent.integration.template.UserCenterTemplate;
import com.mkt.agent.integration.template.WsTemplate;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Supplier;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
//--
@Service
@Slf4j
public class BatchServiceImpl implements BatchService, ApplicationEventPublisherAware {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private ApplicationEventPublisher publisher;
    @Autowired
    private FastContextBuilder fastContextBuilder;

    @Resource
    BatchInfoMapper batchInfoMapper;
    @Resource
    BatchRecordMapper batchRecordMapper;
    @Resource
    TAgentCustomersService tAgentCustomersService;
    @Resource
    PlayerCustomersService playerCustomersService;
    @Resource
    WSConfig wsConfig;
    @Resource
    private SystemConfig systemConfig;

    @Autowired
    private UserCenterConfig userCenterConfig;

//    private ExecutorService executorService;

    private BatchServiceImpl thiz;

    private static final String dateFormatCheckPattern = "^\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\d{2}";

    @Autowired
    private TCustomerLayerMapper tCustomerLayerMapper;
    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private BatchUserNameGenerator batchUserNameGenerator;
    @Autowired
    private BatchUserHelper batchUserHelper;
    @Autowired
    private TAgentContractBindMapper contractBindMapper;
    @Autowired
    private TAgentCustomersBranchMapper branchMapper;

    @PostConstruct
    public void init() {
//        executorService = Executors.newFixedThreadPool(10);
        thiz = this;

        ExecutorService initNamesExecutor = Executors.newSingleThreadExecutor();
        try {
            initNamesExecutor.submit(() -> {
                log.info("CustomerLayerServiceImpl loginName init and timer start...");
                long startTime = System.currentTimeMillis();
                List<String> uniqueNameList = tCustomerLayerMapper.uniqueNameList();

                uniqueNameList.forEach(name -> {
                    redisUtil.set(Constants.UNIQUE_NAME_PREFIX + name.toLowerCase(Locale.ROOT), name.toLowerCase(Locale.ROOT));
                });

                //启动时从4位账号开始生成
                redisUtil.set(Constants.CURRENT_LENGTH, Constants.FOUR + "");

                redisUtil.set(Constants.MAX_TRY_TIMES, 500000 + "");

                long endTime = System.currentTimeMillis();
                log.info("CustomerLayerServiceImpl loginName init end 总耗时：{}/ms ", endTime - startTime);
            });
        }catch (Exception e){
            System.out.println("Task failed");
        }finally {
            initNamesExecutor.shutdown();
            logger.info("initNamesExecutor shutdown");
        }


    }

    @Override
    public Page<BatchQueryResp> queryBatchInfo(BatchQueryRequest request) {
        BatchInfoExample example = new BatchInfoExample();
        BatchInfoExample.Criteria criteria = example.createCriteria();
        String creator = request.getCreator();
        criteria.andBatchTypeEqualTo(request.getQueryType());
        if (StringUtils.isNotBlank(creator)) {
            criteria.andLoginNameEqualTo(creator);
        }
        if (dateMatched(request.getStartTime(), request.getEndTime())) {
            try {
                criteria.andCreateTimeBetween(getDate(request.getStartTime()), getDate(request.getEndTime()));
            } catch (Exception ignored) {
            }
        }
        long total = this.batchInfoMapper.countByExample(example);
        Page<BatchQueryResp> re = new Page<>();
        re.setTotal(total);
        re.setSize(request.getPageSize());
        if (total <= 0) {
            return re;
        }
        long current = request.getPageNum();
        re.setCurrent(current);
        re.setPages(total / request.getPageSize());

        example.setOrderByClause("create_time " + (request.getIsAsc() ? " asc " : " desc "));
        example.setLimitStr("limit " + request.getPageSize() * (current - 1) + "," + request.getPageSize());
        re.setRecords(this.batchInfoMapper.selectByExample(example).stream().map(BatchQueryResp::fromBatchInfo).collect(Collectors.toList()));
        return re;
    }

    private boolean dateMatched(String... dateParams) {
        return Stream.of(dateParams).allMatch(s -> Objects.nonNull(s) && Pattern.matches(dateFormatCheckPattern, s));
    }

    private Date getDate(String dateParam) throws ParseException {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dateParam);
    }

    @Override
    public List<BatchRecord> getBatchRecords(long batchId) {
        BatchRecordExample example = new BatchRecordExample();
        example.createCriteria().andBatchIdEqualTo(batchId);
        return this.batchRecordMapper.selectByExample(example);
    }

    @Override
    public List<BatchAccountInfoDTO> queryBatchAccountsByBatchId(long batchId) {
        return this.batchRecordMapper.queryBatchAccountsByBatchId(batchId);
    }

    @Override
    public Result<Boolean> createTopAgentByBatch(TAgentCustomersBatchReq tAgentCustomersBatchReq, HttpServletRequest request) throws InterruptedException {

        logger.info("BatchServiceImpl-createTopAgentByBatch- agentCustomersReq : {}", tAgentCustomersBatchReq.toString());

        String userName = tAgentCustomersBatchReq.getCreateBy();

        WSCustomers wsCustomer = FunctionHelper.doIt(Conditions.userCenterIsOpen(userCenterConfig.getUserCenterIsOpen()),
                new UserCenterTemplate(userCenterConfig.getUserCenterDefaultUrl(), userCenterConfig.getPwd())::queryCustomerByLoginName,
                new WsTemplate(wsConfig.getWsDefaultUrl(), wsConfig.getPwd())::getSimpleCustomer, systemConfig.getProductId(), userName);

        if (null == wsCustomer) {
            // 没有用户信息
            throw new BusinessException(ResultEnum.USER_CENTER_EXCEPTION);
        }

        boolean prefixAble = StringUtils.isNotBlank(tAgentCustomersBatchReq.getPrefix());
        String prefix = Optional.ofNullable(tAgentCustomersBatchReq.getPrefix()).orElse("");
        AtomicLong suffix = batchUserHelper.getSuffix(prefix, prefixAble);

        //site_id = 1 BP, 2 AP, 3 GP  前台创建前端不传site_id，后台创建传site_id
        int siteId = Objects.isNull(tAgentCustomersBatchReq.getSiteId()) ? wsCustomer.getSiteId() : tAgentCustomersBatchReq.getSiteId();
        Integer count = tAgentCustomersBatchReq.getAgentNumber();
        AtomicInteger successCount = new AtomicInteger(0),
                failedCount = new AtomicInteger(0);
        String percentage = "";
        if (Objects.isNull(tAgentCustomersBatchReq.getSiteId())) {
            //查询佣金比例
            TAgentContractBind bind = contractBindMapper.selectOne(new LambdaQueryWrapper<TAgentContractBind>().eq(TAgentContractBind::getLoginName, userName));
            List<SettlementPercentageReq> settlementPercentageList = SerializationUti.deserializeFromString(bind.getPercentageDetails(), SettlementPercentageReq.class);
            SettlementPercentageReq percentageReq = settlementPercentageList.get(0);
            BigDecimal maxPercentage = BigDecimal.valueOf(percentageReq.getAllGamesPercentage()).setScale(2, RoundingMode.DOWN);
            //佣金比例转换
            percentage = CollectionUtils.isEmpty(tAgentCustomersBatchReq.getSettlementPercentageList()) ? "" :
                    Optional.ofNullable(tAgentCustomersBatchReq.getSettlementPercentageList().get(0).getAllGamesPercentage())
                            .map(String::valueOf)
                            .orElse("0.00");
            BigDecimal currentPercentage = new BigDecimal(percentage);
            if(currentPercentage.compareTo(maxPercentage) > 0 || currentPercentage.compareTo(BigDecimal.ZERO) < 0) {
                throw new MKTAgentException(ResultEnum.PERCENTAGE_INCORRECT);
            }
            percentage = String.valueOf(currentPercentage.setScale(2, RoundingMode.DOWN));
        }

        BatchInfo info = BatchInfo.builder()
                .percentage(percentage)
                .siteId(siteId)
                .prefix(prefix).build();
        buildBatchInfo(tAgentCustomersBatchReq, wsCustomer, info);

        this.batchInfoMapper.insertSelective(info);
        logger.info("Begin to create asyncTask-----infoId:{}", info.getId());

        String ip = IPUtils.getRequestIP(request);
        new Thread(new Runnable() {
            @Override
            public void run() {
                List<BatchContainer> batchContains = new CopyOnWriteArrayList<>();
                ExecutorService executorService = Executors.newFixedThreadPool(10);

                try {

                    logger.info("Begin to run asyncTask:{}", Thread.currentThread().getName());

                    Supplier<String> accountSupplier = () -> prefixAble ? batchUserHelper.getAccountByPrefix(prefix, suffix) : batchUserNameGenerator.getAccount(siteId);
                    Supplier<String> pwdSupplier = () -> batchUserNameGenerator.getPwd();

                    logger.info("finished to make new account");

                    CountDownLatch latch = new CountDownLatch(count);

                    List<Future<BatchRecord>> futureRecords = IntStream.range(0, count)
                            .mapToObj(i -> executorService.submit(() -> {
                                TAgentCustomersReq mockReq = new TAgentCustomersReq();
                                String loginName = accountSupplier.get(), pwd = pwdSupplier.get();
                                BeanUtils.copyProperties(tAgentCustomersBatchReq, mockReq);
                                mockReq.setLoginName(loginName);
                                mockReq.setPwd(pwd);
                                mockReq.setIsEnable(1);
                                try {
                                    tAgentCustomersService.create(mockReq, ip, batchContains);
                                } catch (Exception ignored) {
                                    latch.countDown();
                                    return null;
                                }
                                BatchRecord batchRecord = new BatchRecord();
                                batchRecord.setPwd(pwd);
                                batchRecord.setLoginName(loginName);
                                batchRecord.setPrefix(prefix);
                                latch.countDown();
                                return batchRecord;
                            })).collect(Collectors.toList());
                    latch.await();
                    List<BatchRecord> records = futureRecords.stream().map(f -> {
                        try {
                            BatchRecord record = f.get();
                            if (Objects.nonNull(record)) {
                                successCount.incrementAndGet();
                                logger.info("successCount increment:" + successCount.get());
                            } else {
                                failedCount.incrementAndGet();
                                logger.info("failedCount increment:" + failedCount.get());
                            }
                            return record;
                        } catch (InterruptedException | ExecutionException ignored) {
                            failedCount.incrementAndGet();
                            logger.info("failedCount increment:" + failedCount.get());
                            return null;
                        }
                    }).filter(Objects::nonNull).collect(Collectors.toList());

                    List<TAgentCustomers> tAgentCustomers = batchContains.stream().map(BatchContainer::getTAgentCustomers).filter(Objects::nonNull).collect(Collectors.toList());
                    publisher.publishEvent(new CreateAgentEvent(this, tAgentCustomers, fastContextBuilder.getFastContext()));

                    info.setSuccessCount(successCount.get());
                    info.setFailedCount(failedCount.get());
                    info.setStatus(1);
                    thiz.insert(info, records);
                    executorService.shutdown();
                } catch (Exception interruptedException) {
                    //线程中断
                    logger.info("Update batchInfo data:{}", info);
                    info.setStatus(1);
                    batchInfoMapper.updateByPrimaryKey(info);
                }finally {
                    if(!executorService.isShutdown()){
                        executorService.shutdown();
                    }
                    // 插入门店记录
                    List<TAgentCustomersBranch> branches = batchContains.stream().map(BatchContainer::getTAgentCustomersBranch).filter(Objects::nonNull).collect(Collectors.toList());
                    log.info("批量创建代理-branches size is {}", branches.size());
                    if(!CollectionUtils.isEmpty(branches)){
                        branchMapper.insertBatchSomeColumn(branches);
                    }
                    logger.info("The executorService shutdown:{}",executorService.toString());
                }

            }
        }).start();

        logger.info("The main Thread begin to return data!");
        return Result.success(true);
    }

    @Override
    public Result<Boolean> batchCreate(PlayerCustomersBatchReq playerCustomersBatchReq) throws InterruptedException {
        String userName = playerCustomersBatchReq.getCreatedBy();
        WSCustomers wsCustomer = FunctionHelper.doIt(Conditions.userCenterIsOpen(userCenterConfig.getUserCenterIsOpen()),
                new UserCenterTemplate(userCenterConfig.getUserCenterDefaultUrl(), userCenterConfig.getPwd())::queryCustomerByLoginName,
                new WsTemplate(wsConfig.getWsDefaultUrl(), wsConfig.getPwd())::getSimpleCustomer, systemConfig.getProductId(), userName);
        if (null == wsCustomer) {
            // 没有用户信息
            throw new BusinessException(ResultEnum.USER_CENTER_EXCEPTION);
        }
        int siteId = wsCustomer.getSiteId();//1 BP,  2 AP , 3 GP
        Integer count = playerCustomersBatchReq.getAccountNumber();
        AtomicInteger successCount = new AtomicInteger(0),
                failedCount = new AtomicInteger(0);

        boolean prefixAble = StringUtils.isNotBlank(playerCustomersBatchReq.getPrefix());
        String prefix = Optional.ofNullable(playerCustomersBatchReq.getPrefix()).orElse("");
        AtomicLong suffix = batchUserHelper.getSuffix(prefix, prefixAble);

        BatchInfo info = BatchInfo.builder()
                .siteId(siteId).prefix(prefix).build();
        buildBatchInfo(playerCustomersBatchReq, wsCustomer, info);
        this.batchInfoMapper.insertSelective(info);
        logger.info("Begin to create asyncTask-----infoId:{}", info.getId());
        String currentUser = UserContext.getUsername();

        new Thread(new Runnable() {
            @Override
            public void run() {
                List<BatchContainer> batchContains = new CopyOnWriteArrayList<>();
                ExecutorService executorService = Executors.newFixedThreadPool(10);

                try {
                    Supplier<String> accountSupplier = () -> prefixAble ? batchUserHelper.getAccountByPrefix(prefix, suffix) : batchUserNameGenerator.getAccount(siteId);
                    Supplier<String> pwdSupplier = () -> batchUserNameGenerator.getPwd();

                    CountDownLatch latch = new CountDownLatch(count);

                    List<Future<BatchRecord>> futureRecords = IntStream.range(0, count)
                            .mapToObj(i -> executorService.submit(() -> {
                                PlayerCustomersReq req = new PlayerCustomersReq();
                                String loginName = accountSupplier.get(), pwd = pwdSupplier.get();
                                req.setCreatedBy(playerCustomersBatchReq.getCreatedBy());
                                req.setIp(playerCustomersBatchReq.getIp());
                                req.setAccount(loginName);
                                req.setPassword(pwd);
                                req.setParentId(playerCustomersBatchReq.getParentId());
                                req.setProductId(playerCustomersBatchReq.getProductId());
                                req.setLoginName(currentUser);
                                try {
                                    playerCustomersService.create(req, batchContains);
                                } catch (Exception ignored) {
                                    latch.countDown();
                                    return null;
                                }
                                BatchRecord record = new BatchRecord();
                                record.setLoginName(loginName);
                                record.setPwd(pwd);
                                record.setPrefix(prefix);
                                latch.countDown();
                                return record;
                            })).collect(Collectors.toList());

                    latch.await();
                    List<BatchRecord> records = futureRecords.stream().map(f -> {
                        try {
                            BatchRecord record = f.get();
                            if (Objects.nonNull(record)) {
                                successCount.incrementAndGet();
                            } else {
                                failedCount.incrementAndGet();
                            }
                            return record;
                        } catch (InterruptedException | ExecutionException ignored) {
                            failedCount.incrementAndGet();
                            return null;
                        }
                    }).filter(Objects::nonNull).collect(Collectors.toList());
                    info.setSuccessCount(successCount.get());
                    info.setFailedCount(failedCount.get());
                    info.setStatus(1);
                    thiz.insert(info, records);
                    executorService.shutdown();
                } catch (Exception e) {
                    logger.info("Update batchInfo data:{}, Exception is: ", info, e);
                    info.setStatus(1);
                    batchInfoMapper.updateByPrimaryKey(info);
                    Thread.currentThread().interrupt();
                }finally {
                    if(!executorService.isShutdown()){
                        executorService.shutdown();
                    }
                    logger.info("The executorService shutdown:{}",executorService.toString());
                    List<TAgentCustomersBranch> branches = batchContains.stream().map(BatchContainer::getTAgentCustomersBranch).filter(Objects::nonNull).collect(Collectors.toList());
                    log.info("批量创建玩家-branches size is {}", branches.size());
                    if(!CollectionUtils.isEmpty(branches)){
                        branchMapper.insertBatchSomeColumn(branches);
                    }
                }
            }
        }).start();

        return Result.success(true);
    }

    private void buildBatchInfo(TAgentCustomersBatchReq req, WSCustomers wsCustomer, BatchInfo batchInfo) {
        batchInfo.setBatchType(BATCH_TYPE_AGENT);
        batchInfo.setAgentType(req.getAgentType());
        batchInfo.setAccountCount(req.getAgentNumber().longValue());
        batchInfo.setUserId(Long.parseLong(wsCustomer.getCustomerId()));
        batchInfo.setLoginName(wsCustomer.getLoginName());
        batchInfo.setCommission(req.getCommissionPlanName());
        if (Objects.nonNull(req.getDevelopableLevel())) {
            batchInfo.setAgentLevel(req.getDevelopableLevel().byteValue());
        }
        batchInfo.setProductId(req.getProductId());
        //创建中
        batchInfo.setStatus(0);
        batchInfo.setCreateTime(DateUtils.getCurrentDateTime());
        batchInfo.setUpdateTime(DateUtils.getCurrentDateTime());
        logger.info("Build agent batchInfo success:{}", batchInfo.toString());
    }

    private void buildBatchInfo(PlayerCustomersBatchReq req, WSCustomers wsCustomer, BatchInfo batchInfo) {
        batchInfo.setBatchType(BATCH_TYPE_PLAYER);
        batchInfo.setAccountCount(req.getAccountNumber().longValue());
        batchInfo.setUserId(Long.parseLong(wsCustomer.getCustomerId()));
        batchInfo.setLoginName(wsCustomer.getLoginName());
        batchInfo.setProductId(req.getProductId());
        batchInfo.setAgentLevel((byte) 1);
        batchInfo.setCommission("");
        batchInfo.setStatus(0);
        batchInfo.setCreateTime(DateUtils.getCurrentDateTime());
        batchInfo.setUpdateTime(DateUtils.getCurrentDateTime());
        logger.info("Build player batchInfo success:{}", batchInfo.toString());
    }

    @Transactional
    public Long insert(BatchInfo batchInfo, List<BatchRecord> records) {

        batchInfoMapper.updateAsyncDataById(batchInfo);
        logger.info("Updated batchInfo :{}", batchInfo.getId());

        records.forEach(r -> {
            if (Objects.isNull(r)) {//null when create failed
                return;
            }
            r.setBatchId(batchInfo.getId());
            logger.info("insert Batch Records  batchId:{}", batchInfo.getId());
            this.batchRecordMapper.insertSelective(r);

        });
        return batchInfo.getId();
    }

    @Override
    public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
        this.publisher = applicationEventPublisher;
    }
}
