package com.mkt.agent.api.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cn.schema.customers.WSCustomers;
import com.mkt.agent.api.entity.req.PlayerCustomersReq;
import com.mkt.agent.api.entity.req.TAgentCustomersReq;
import com.mkt.agent.api.mapper.BatchInfoMapper;
import com.mkt.agent.api.mapper.BatchRecordMapper;
import com.mkt.agent.api.mapper.TCustomerLayerMapper;
import com.mkt.agent.api.service.BatchService;
import com.mkt.agent.api.service.PlayerCustomersService;
import com.mkt.agent.api.service.TAgentCustomersService;
import com.mkt.agent.common.config.SystemConfig;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.*;
import com.mkt.agent.common.entity.api.agentapi.requests.BatchQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentCustomersBatchReq;
import com.mkt.agent.common.entity.api.agentapi.responses.BatchQueryResp;
import com.mkt.agent.common.entity.api.userapi.requests.PlayerCustomersBatchReq;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.helper.FunctionHelper;
import com.mkt.agent.common.helper.Conditions;
import com.mkt.agent.common.utils.*;
import com.mkt.agent.integration.config.UserCenterConfig;
import com.mkt.agent.integration.config.WSConfig;
import com.mkt.agent.integration.template.UserCenterTemplate;
import com.mkt.agent.integration.template.WsTemplate;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@Service
@Slf4j
public class BatchServiceImpl implements BatchService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    BatchInfoMapper batchInfoMapper;
    @Resource
    BatchRecordMapper batchRecordMapper;
    @Resource
    TAgentCustomersService tAgentCustomersService;
    @Resource
    PlayerCustomersService playerCustomersService;
    @Resource
    WSConfig wsConfig;
    @Resource
    private SystemConfig systemConfig;

    @Autowired
    private UserCenterConfig userCenterConfig;

//    private ExecutorService executorService;

    private BatchServiceImpl thiz;

    private static final String dateFormatCheckPattern = "^\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\d{2}";

    @Autowired
    private TCustomerLayerMapper tCustomerLayerMapper;
    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private BatchUserNameGenerator batchUserNameGenerator;

    @PostConstruct
    public void init() {
//        executorService = Executors.newFixedThreadPool(10);
        thiz = this;

        ExecutorService initNamesExecutor = Executors.newSingleThreadExecutor();
        try {
            initNamesExecutor.submit(() -> {
                log.info("CustomerLayerServiceImpl loginName init and timer start...");
                long startTime = System.currentTimeMillis();
                List<String> uniqueNameList = tCustomerLayerMapper.uniqueNameList();

                uniqueNameList.forEach(name -> {
                    redisUtil.set(Constants.UNIQUE_NAME_PREFIX + name.toLowerCase(Locale.ROOT), name.toLowerCase(Locale.ROOT));
                });

                //启动时从4位账号开始生成
                redisUtil.set(Constants.CURRENT_LENGTH, Constants.FOUR + "");

                redisUtil.set(Constants.MAX_TRY_TIMES, 500000 + "");

                long endTime = System.currentTimeMillis();
                log.info("CustomerLayerServiceImpl loginName init end 总耗时：{}/ms ", endTime - startTime);
            });
        }catch (Exception e){
            System.out.println("Task failed");
        }finally {
            initNamesExecutor.shutdown();
            logger.info("initNamesExecutor shutdown");
        }


    }

    @Override
    public Page<BatchQueryResp> queryBatchInfo(BatchQueryRequest request) {
        BatchInfoExample example = new BatchInfoExample();
        BatchInfoExample.Criteria criteria = example.createCriteria();
        String creator = request.getCreator();
        criteria.andBatchTypeEqualTo(request.getQueryType());
        if (StringUtils.isNotBlank(creator)) {
            criteria.andLoginNameEqualTo(creator);
        }
        if (dateMatched(request.getStartTime(), request.getEndTime())) {
            try {
                criteria.andCreateTimeBetween(getDate(request.getStartTime()), getDate(request.getEndTime()));
            } catch (Exception ignored) {
            }
        }
        long total = this.batchInfoMapper.countByExample(example);
        Page<BatchQueryResp> re = new Page<>();
        re.setTotal(total);
        re.setSize(request.getPageSize());
        if (total <= 0) {
            return re;
        }
        long current = request.getPageNum();
        re.setCurrent(current);
        re.setPages(total / request.getPageSize());

        example.setOrderByClause("create_time " + (request.getIsAsc() ? " asc " : " desc "));
        example.setLimitStr("limit " + request.getPageSize() * (current - 1) + "," + request.getPageSize());
        re.setRecords(this.batchInfoMapper.selectByExample(example).stream().map(BatchQueryResp::fromBatchInfo).collect(Collectors.toList()));
        return re;
    }

    private boolean dateMatched(String... dateParams) {
        return Stream.of(dateParams).allMatch(s -> Objects.nonNull(s) && Pattern.matches(dateFormatCheckPattern, s));
    }

    private Date getDate(String dateParam) throws ParseException {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(dateParam);
    }

    @Override
    public List<BatchRecord> getBatchRecords(long batchId) {
        BatchRecordExample example = new BatchRecordExample();
        example.createCriteria().andBatchIdEqualTo(batchId);
        return this.batchRecordMapper.selectByExample(example);
    }

    @Override
    public Result<Boolean> createTopAgentByBatch(TAgentCustomersBatchReq tAgentCustomersBatchReq, HttpServletRequest request) throws InterruptedException {

        logger.info("BatchServiceImpl-createTopAgentByBatch- agentCustomersReq : {}", tAgentCustomersBatchReq.toString());

        String userName = tAgentCustomersBatchReq.getCreateBy();

        WSCustomers wsCustomer = FunctionHelper.doIt(Conditions.userCenterIsOpen(userCenterConfig.getUserCenterIsOpen()),
                new UserCenterTemplate(userCenterConfig.getUserCenterDefaultUrl(), userCenterConfig.getPwd())::queryCustomerByLoginName,
                new WsTemplate(wsConfig.getWsDefaultUrl(), wsConfig.getPwd())::getSimpleCustomer, systemConfig.getProductId(), userName);

        if (null == wsCustomer) {
            // 没有用户信息
            throw new BusinessException(ResultEnum.USER_CENTER_EXCEPTION);
        }
        //1 BP,  2 AP,  3 GP  前台创建前端不传site_id，后台创建传site_id
        int siteId = Objects.isNull(tAgentCustomersBatchReq.getSiteId())? wsCustomer.getSiteId():tAgentCustomersBatchReq.getSiteId();

        Integer count = tAgentCustomersBatchReq.getAgentNumber();
        AtomicInteger successCount = new AtomicInteger(0),
                failedCount = new AtomicInteger(0);

        BatchInfo info = buildBatchInfo(tAgentCustomersBatchReq, wsCustomer, siteId);

        this.batchInfoMapper.insertSelective(info);
        logger.info("Begin to create asyncTask-----infoId:{}", info.getId());

        String ip = IPUtils.getRequestIP(request);

        new Thread(new Runnable() {
            @Override
            public void run() {

                ExecutorService executorService = Executors.newFixedThreadPool(10);

                try {

                    logger.info("Begin to run asyncTask:{}", Thread.currentThread().getName());

                    Supplier<String> accountSupplier = () -> batchUserNameGenerator.getAccount(siteId), pwdSupplier = () -> batchUserNameGenerator.getPwd();

                    logger.info("finished to make new account");

                    CountDownLatch latch = new CountDownLatch(count);

                    List<Future<BatchRecord>> futureRecords = IntStream.range(0, count)
                            .mapToObj(i -> executorService.submit(() -> {
                                TAgentCustomersReq mockReq = new TAgentCustomersReq();
                                String loginName = accountSupplier.get(), pwd = pwdSupplier.get();
                                BeanUtils.copyProperties(tAgentCustomersBatchReq, mockReq);
                                mockReq.setLoginName(loginName);
                                mockReq.setPwd(pwd);
                                mockReq.setIsEnable(1);
                                try {
                                    tAgentCustomersService.create(mockReq, ip);
                                } catch (Exception ignored) {
                                    latch.countDown();
                                    return null;
                                }
                                BatchRecord batchRecord = new BatchRecord();
                                batchRecord.setPwd(pwd);
                                batchRecord.setLoginName(loginName);
                                latch.countDown();
                                return batchRecord;
                            })).collect(Collectors.toList());
                    latch.await();
                    List<BatchRecord> records = futureRecords.stream().map(f -> {
                        try {
                            BatchRecord record = f.get();
                            if (Objects.nonNull(record)) {
                                successCount.incrementAndGet();
                            } else {
                                failedCount.incrementAndGet();
                            }
                            logger.info("successCount increment:" + successCount.get());
                            return record;
                        } catch (InterruptedException | ExecutionException ignored) {
                            failedCount.incrementAndGet();
                            logger.info("failedCount increment:" + failedCount.get());
                            return null;
                        }
                    }).filter(Objects::nonNull).collect(Collectors.toList());

                    info.setSuccessCount(successCount.get());
                    info.setFailedCount(failedCount.get());
                    info.setStatus(1);
                    thiz.insert(info, records);
                    executorService.shutdown();
                } catch (Exception interruptedException) {
                    //线程中断
                    logger.info("Update batchInfo data:{}", info);
                    info.setStatus(1);
                    batchInfoMapper.updateByPrimaryKey(info);
                }finally {
                    if(!executorService.isShutdown()){
                        executorService.shutdown();
                    }
                    logger.info("The executorService shutdown:{}",executorService.toString());
                }

            }
        }).start();

        logger.info("The main Thread begin to return data!");
        return Result.success(true);
    }

    @Override
    public Result<Boolean> batchCreate(PlayerCustomersBatchReq playerCustomersBatchReq) throws InterruptedException {
        String userName = playerCustomersBatchReq.getCreatedBy();
        WSCustomers wsCustomer = FunctionHelper.doIt(Conditions.userCenterIsOpen(userCenterConfig.getUserCenterIsOpen()),
                new UserCenterTemplate(userCenterConfig.getUserCenterDefaultUrl(), userCenterConfig.getPwd())::queryCustomerByLoginName,
                new WsTemplate(wsConfig.getWsDefaultUrl(), wsConfig.getPwd())::getSimpleCustomer, systemConfig.getProductId(), userName);
        if (null == wsCustomer) {
            // 没有用户信息
            throw new BusinessException(ResultEnum.USER_CENTER_EXCEPTION);
        }
        int siteId = wsCustomer.getSiteId();//1 BP,  2 AP , 3 GP
        Integer count = playerCustomersBatchReq.getAccountNumber();
        AtomicInteger successCount = new AtomicInteger(0),
                failedCount = new AtomicInteger(0);

        BatchInfo info = buildBatchInfo(playerCustomersBatchReq, wsCustomer, siteId);
        this.batchInfoMapper.insertSelective(info);
        logger.info("Begin to create asyncTask-----infoId:{}", info.getId());

        new Thread(new Runnable() {
            @Override
            public void run() {
                ExecutorService executorService = Executors.newFixedThreadPool(10);

                try {
                    Supplier<String> accountSupplier = () -> batchUserNameGenerator.getAccount(siteId), pwdSupplier = () -> batchUserNameGenerator.getPwd();

                    CountDownLatch latch = new CountDownLatch(count);

                    List<Future<BatchRecord>> futureRecords = IntStream.range(0, count)
                            .mapToObj(i -> executorService.submit(() -> {
                                PlayerCustomersReq req = new PlayerCustomersReq();
                                String loginName = accountSupplier.get(), pwd = pwdSupplier.get();
                                req.setCreatedBy(playerCustomersBatchReq.getCreatedBy());
                                req.setIp(playerCustomersBatchReq.getIp());
                                req.setAccount(loginName);
                                req.setPassword(pwd);
                                req.setParentId(playerCustomersBatchReq.getParentId());
                                req.setProductId(playerCustomersBatchReq.getProductId());
                                try {
                                    playerCustomersService.create(req);
                                } catch (Exception ignored) {
                                    latch.countDown();
                                    return null;
                                }
                                BatchRecord record = new BatchRecord();
                                record.setLoginName(loginName);
                                record.setPwd(pwd);
                                latch.countDown();
                                return record;
                            })).collect(Collectors.toList());

                    latch.await();
                    List<BatchRecord> records = futureRecords.stream().map(f -> {
                        try {
                            BatchRecord record = f.get();
                            if (Objects.nonNull(record)) {
                                successCount.incrementAndGet();
                            } else {
                                failedCount.incrementAndGet();
                            }
                            return record;
                        } catch (InterruptedException | ExecutionException ignored) {
                            failedCount.incrementAndGet();
                            return null;
                        }
                    }).filter(Objects::nonNull).collect(Collectors.toList());

                    info.setSuccessCount(successCount.get());
                    info.setFailedCount(failedCount.get());
                    info.setStatus(1);
                    thiz.insert(info, records);
                    executorService.shutdown();
                } catch (Exception e) {
                    logger.info("Update batchInfo data:{}", info);
                    info.setStatus(1);
                    batchInfoMapper.updateByPrimaryKey(info);
                }finally {
                    if(!executorService.isShutdown()){
                        executorService.shutdown();
                    }
                    logger.info("The executorService shutdown:{}",executorService.toString());
                }
            }
        }).start();

        return Result.success(true);
    }

    private BatchInfo buildBatchInfo(TAgentCustomersBatchReq req, WSCustomers wsCustomer, int siteId) {
        BatchInfo batchInfo = new BatchInfo();
        batchInfo.setBatchType(BATCH_TYPE_AGENT);
        batchInfo.setAgentType(req.getAgentType());
        batchInfo.setAccountCount(req.getAgentNumber().longValue());
        batchInfo.setUserId(Long.parseLong(wsCustomer.getCustomerId()));
        batchInfo.setLoginName(wsCustomer.getLoginName());
        batchInfo.setCommission(req.getCommissionPlanName());
        if (Objects.nonNull(req.getDevelopableLevel())) {
            batchInfo.setAgentLevel(req.getDevelopableLevel().byteValue());
        }
        batchInfo.setSiteId(siteId);
        batchInfo.setProductId(req.getProductId());
        //创建中
        batchInfo.setStatus(0);
        batchInfo.setCreateTime(DateUtils.getCurrentDateTime());
        batchInfo.setUpdateTime(DateUtils.getCurrentDateTime());
        logger.info("Build agent batchInfo success:{}", batchInfo.toString());
        return batchInfo;
    }

    private BatchInfo buildBatchInfo(PlayerCustomersBatchReq req, WSCustomers wsCustomer, int siteId) {
        BatchInfo batchInfo = new BatchInfo();
        batchInfo.setBatchType(BATCH_TYPE_PLAYER);
        batchInfo.setAccountCount(req.getAccountNumber().longValue());
        batchInfo.setUserId(Long.parseLong(wsCustomer.getCustomerId()));
        batchInfo.setLoginName(wsCustomer.getLoginName());
        batchInfo.setSiteId(siteId);
        batchInfo.setProductId(req.getProductId());
        batchInfo.setAgentLevel((byte) 1);
        batchInfo.setCommission("");
        batchInfo.setStatus(0);
        batchInfo.setCreateTime(DateUtils.getCurrentDateTime());
        batchInfo.setUpdateTime(DateUtils.getCurrentDateTime());
        logger.info("Build player batchInfo success:{}", batchInfo.toString());
        return batchInfo;
    }

    @Transactional
    public Long insert(BatchInfo batchInfo, List<BatchRecord> records) {

        batchInfoMapper.updateAsyncDataById(batchInfo);
        logger.info("Updated batchInfo :{}", batchInfo.getId());

        records.forEach(r -> {
            if (Objects.isNull(r)) {//null when create failed
                return;
            }
            r.setBatchId(batchInfo.getId());
            logger.info("insert Batch Records  batchId:{}", batchInfo.getId());
            this.batchRecordMapper.insertSelective(r);

        });
        return batchInfo.getId();
    }

}
