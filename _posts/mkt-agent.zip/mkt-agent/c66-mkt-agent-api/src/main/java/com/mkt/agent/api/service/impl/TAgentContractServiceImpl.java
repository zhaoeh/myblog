package com.mkt.agent.api.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mkt.agent.api.entity.req.TAgentContractQueryReq;
import com.mkt.agent.api.entity.resp.TAgentContractResp;
import com.mkt.agent.api.entity.resp.TAgentSettlementResp;
import com.mkt.agent.api.exception.MKTAgentException;
import com.mkt.agent.api.mapper.TAgentContractMapper;
import com.mkt.agent.api.service.TAgentContractBindService;
import com.mkt.agent.api.service.TAgentContractService;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentContractReq;
import com.mkt.agent.common.entity.api.agentapi.responses.TAgentContractDictionaryResp;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.BeanCopyUtil;
import com.mkt.agent.common.utils.ExcelUtil;
import com.mkt.agent.common.utils.SerializationUti;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @ClassName CommissionPlanServiceImpl
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Service
public class TAgentContractServiceImpl extends ServiceImpl<TAgentContractMapper,TAgentContract> implements TAgentContractService {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private TAgentContractMapper tAgentContractMapper;

    @Autowired
    TAgentContractBindService tAgentContractBindService;

    @Override
    public void create(TAgentContractReq tAgentContractReq) {
        try {
            logger.info("tAgentContractReq : {}", tAgentContractReq.toString());
            tAgentContractReq.refresh();
            TAgentContract tAgentContract = new TAgentContract();
            BeanUtils.copyProperties(tAgentContractReq, tAgentContract, "id");
            logger.info("commissionPlanPO : {}", tAgentContract.toString());
            super.save(tAgentContract);
        } catch (DuplicateKeyException e) {
            logger.error(ResultEnum.CONTRACT_NAME_DUPLICATE.getMessage() + e);
            throw new MKTAgentException(ResultEnum.CONTRACT_NAME_DUPLICATE);
        }
    }

    @Override
    public Page<TAgentContractResp> queryList(TAgentContractQueryReq tAgentContractQueryReq) {
        Page<TAgentContractResp> pageResult=new Page<>();
        //设置分页
        tAgentContractQueryReq.setPageNum(tAgentContractQueryReq.getPageNum());

        Integer total=tAgentContractMapper.count(tAgentContractQueryReq);
        if(null!=total&&total!=0){
            List<TAgentContract> tAgentContractList = tAgentContractMapper.queryList(tAgentContractQueryReq);
            List<TAgentContractResp> commissionPlanRespList=BeanCopyUtil.copyListProperties(tAgentContractList,TAgentContractResp::new,(tAgentContract,tAgentContractResp) ->{
                tAgentContractResp.setId(String.valueOf(tAgentContract.getId()));
                tAgentContractResp.setSettlementPercentageList(tAgentContract.getPercentageDetails());
                tAgentContractResp.setCreateTime(tAgentContract.getCreateTime());
            });
            if(null!=tAgentContractQueryReq.getPageNum() && null!=tAgentContractQueryReq.getPageSize()){
                pageResult.setSize(tAgentContractQueryReq.getPageSize()).setCurrent(tAgentContractQueryReq.getPageNum())
                        .setPages(total / tAgentContractQueryReq.getPageSize());
            }else{
                pageResult.setSize(-1).setCurrent(-1).setPages(-1);
            }
            pageResult.setRecords(commissionPlanRespList).setTotal(total);
        }
        return pageResult;
    }

    @Override
    @Transactional
    public void update(TAgentContractReq tAgentContractReq) {
        logger.info("tAgentContractReq : {}", tAgentContractReq.toString());
        TAgentContract tAgentContract=selectOne(tAgentContractReq.getId());
        if(ObjectUtils.isEmpty(tAgentContract)){
            throw new MKTAgentException(ResultEnum.AGENT_CONTRACT_NOT_EXIST);
        }
        tAgentContractReq.refresh();
        TAgentContract agentContract=new TAgentContract();
        BeanUtils.copyProperties(tAgentContractReq,agentContract,"agentCount");
        agentContract.setAgentCount(tAgentContract.getAgentCount());
        logger.info("agentContract : {}", agentContract.toString());
        //First: update tAgentContractByBind of all agent with this agentContract , tAgentContractByBind of Level 1 Agent
        //are consistent with this agentContract , tAgentContractByBind with all sub agents of all Level 1 Agent with this
        //tAgentContractByBind reset to o;

        List<SettlementPercentageReq> initList = new ArrayList<>();
        initList.add(new SettlementPercentageReq());
        TAgentContractBind initBind = new TAgentContractBind();
        initBind.setCommissionContractId(agentContract.getId());
        initBind.setPercentageDetails(SerializationUti.serializeToString(initList));

        if(!tAgentContractReq.getCommissionValues().equals(tAgentContract.getCommissionValues())){

            //将该佣金方案下的所有的代理的佣金方案初始化
            tAgentContractBindService.updateBatchPercentageByBindId(initBind);

            List<TAgentContractBind> tAgentContractBindList = tAgentContractBindService.queryAllTopAgentContractBindByContractId(agentContract.getId());
            tAgentContractBindList.forEach(tAgentContractBind->{
                tAgentContractBind.setPercentageDetails(SerializationUti.serializeToString(tAgentContractReq.getSettlementPercentageList()));
            });
            tAgentContractBindService.saveOrUpdateBatch(tAgentContractBindList);
        }
        if(!SerializationUti.serializeToString(tAgentContractReq.getSettlementPercentageList()).equals(tAgentContract.getPercentageDetails())){
            tAgentContractBindService.updateBatchPercentageByBindId(initBind);
            List<TAgentContractBind> tAgentContractBindList = tAgentContractBindService.queryAllTopAgentContractBindByContractId(agentContract.getId());
            tAgentContractBindList.forEach(tAgentContractBind->{
                tAgentContractBind.setPercentageDetails(SerializationUti.serializeToString(tAgentContractReq.getSettlementPercentageList()));
            });
            tAgentContractBindService.saveOrUpdateBatch(tAgentContractBindList);
        }
        //Second: update agentContract;
        tAgentContractMapper.updateById(agentContract);
    }

    @Override
    public void updateAgentCountById(Long id) {
        TAgentContract tAgentContract=selectOne(id);
        //update agentCount +1
        tAgentContract.setAgentCount(tAgentContract.getAgentCount()+1);
        tAgentContractMapper.updateById(tAgentContract);
    }
    @Override
    @org.springframework.transaction.annotation.Transactional(rollbackFor = Exception.class)
    public void updateAgentCountByIdV1(Long id) {
        UpdateWrapper<TAgentContract> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", id).setSql("agent_count = agent_count + 1");
        int rowsUpdated = tAgentContractMapper.update(null, updateWrapper);
        if (rowsUpdated <= 0) {
            throw new IllegalStateException("No records were updated, operation failed.");
        }
    }

    @Override
    public TAgentContract selectOne(Long id){
        //select by id
        QueryWrapper<TAgentContract> wrapper = new QueryWrapper();
        if(id!=null){
            wrapper.eq("id",id);
        }else{
            return null;
        }
        TAgentContract tCommissionContract=tAgentContractMapper.selectOne(wrapper);
        logger.info("tCommissionContract :{}",tCommissionContract.toString());
        return tCommissionContract;
    }

    @Override
    public List<TAgentSettlementResp> queryListByPeriod(String settlementPeriod) {
        List<TAgentSettlementResp> tAgentSettlementRespList=tAgentContractMapper.queryListByPeriod(settlementPeriod);
        tAgentSettlementRespList.forEach(tAgentSettlementResp -> {
            String percentage=tAgentSettlementResp.getPercentageDetails();
            if(StringUtils.isNotBlank(percentage)){
                tAgentSettlementResp.setSettlementPercentageReq(SerializationUti.deserializeFromString(percentage, SettlementPercentageReq.class));
            }
        });
        return tAgentSettlementRespList;
    }

    @Override
    public void export(TAgentContractQueryReq tAgentContractQueryReq, HttpServletResponse response) {
        logger.info("tAgentContractQueryReq : {}", tAgentContractQueryReq.toString());
        TAgentContract tAgentContract=new TAgentContract();
        BeanUtils.copyProperties(tAgentContractQueryReq,tAgentContract);
        logger.info("tAgentContract : {}", tAgentContract.toString());
        QueryWrapper wrapper=queryWrapper(tAgentContractQueryReq,tAgentContract);
        long total = super.count(wrapper);
        if(Objects.isNull(total) || total == 0) {
            return;
        }
        List<TAgentContract> tCommissionContractList = super.list(wrapper);
        List<TAgentContractResp> commissionPlanRespList=BeanCopyUtil.copyListProperties(tCommissionContractList,TAgentContractResp::new);
        try {
            ExcelUtil.export(commissionPlanRespList,TAgentContractResp.class,"commissionPlanRespList",response);
        }catch (IOException e){
            logger.error(ResultEnum.CONTRACT_EXPORT_FAIL.getMessage() + e);
            throw new MKTAgentException(ResultEnum.CONTRACT_EXPORT_FAIL);
        }
    }

    @Override
    public void delete(Long id) {
        TAgentContract tAgentContract=selectOne(id);
        if(tAgentContract.getAgentCount()!=0){
            logger.info(ResultEnum.CONTRACT_DELETE_USING.getMessage() +" id:{}",id);
            throw new MKTAgentException(ResultEnum.CONTRACT_DELETE_USING);
        }
        this.getBaseMapper().deleteById(id);
    }

    @Override
    public List<TAgentContractDictionaryResp> queryNameList(String  contractName) {
        TAgentContract tAgentContract = new TAgentContract ();
        List<TAgentContract> list=super.list(new LambdaQueryWrapper<TAgentContract>().like(TAgentContract::getCommissionPlanName,contractName).orderByDesc(TAgentContract::getCreateTime));
        List<TAgentContractDictionaryResp> TAgentContractDictionaryList = list.stream().map(agentContract->{
                TAgentContractDictionaryResp tAgentContractDictionaryResp = new TAgentContractDictionaryResp();
                tAgentContractDictionaryResp.setId(String.valueOf(agentContract.getId()));
                tAgentContractDictionaryResp.setCommissionPlanName(agentContract.getCommissionPlanName());
            return tAgentContractDictionaryResp;
        }).collect(Collectors.toList());
        return TAgentContractDictionaryList;
    }


    public QueryWrapper queryWrapper(TAgentContractQueryReq tAgentContractQueryReq,TAgentContract tAgentContract){
        QueryWrapper<TAgentContract> wrapper = new QueryWrapper();
        if(StringUtils.isNotBlank(tAgentContract.getCommissionPlanName())){
            wrapper.like("COMMISSION_PLAN_NAME",tAgentContract.getCommissionPlanName());
        }
        if(null != tAgentContract.getId() && tAgentContract.getId()!=0){
            wrapper.like("ID",tAgentContract.getId());
        }
        if(StringUtils.isNotBlank(tAgentContract.getCommissionPlanType()) && !tAgentContract.getCommissionPlanType().equals("ALL")){
            wrapper.eq("COMMISSION_PLAN_TYPE",tAgentContract.getCommissionPlanType());
        }
        if(StringUtils.isNotBlank(tAgentContract.getSettlementPeriod()) && !tAgentContract.getSettlementPeriod().equals("ALL")){
            wrapper.eq("SETTLEMENT_PERIOD",tAgentContract.getSettlementPeriod());
        }
        if(StringUtils.isNotBlank(tAgentContract.getCreateBy())){
            wrapper.like("CREATED_BY",tAgentContract.getCreateBy());
        }
        if(tAgentContract.getCreateTime()!=null){
            wrapper.between("CREATE_TIME",tAgentContractQueryReq.getStartTime(),tAgentContractQueryReq.getEndTime());
        }
        wrapper.eq("is_deleted",0).orderByDesc("CREATE_TIME");

        return wrapper;
    }
}





