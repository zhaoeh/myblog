package com.mkt.agent.api.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.gson.Gson;
import com.mkt.agent.api.entity.req.TAgentContractQueryReq;
import com.mkt.agent.api.entity.resp.TAgentSettlementResp;
import com.mkt.agent.api.exception.MKTAgentException;
import com.mkt.agent.api.mapper.TAgentContractListMapper;
import com.mkt.agent.api.mapper.TAgentContractMapper;
import com.mkt.agent.api.service.TAgentContractBindService;
import com.mkt.agent.api.service.TAgentContractService;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractBind;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractList;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentContractListReq;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentContractReq;
import com.mkt.agent.common.entity.api.agentapi.responses.TAgentContractDictionaryResp;
import com.mkt.agent.common.entity.clickhouse.resp.ClDashBoardDataRes;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.BeanCopyUtil;
import com.mkt.agent.common.utils.ExcelUtil;
import com.mkt.agent.common.utils.SerializationUti;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import com.mkt.agent.common.entity.api.agentapi.responses.TAgentContractResp;
import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @ClassName CommissionPlanServiceImpl
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Service
public class TAgentContractServiceImpl extends ServiceImpl<TAgentContractMapper,TAgentContract> implements TAgentContractService {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private TAgentContractMapper tAgentContractMapper;

    @Autowired
    TAgentContractBindService tAgentContractBindService;

    @Autowired
    private TAgentContractListMapper tAgentContractListMapper ;

    @Value("${isLevelUpdate:2}") //
    private  Integer isLevelUpdate  ;



    @Override
    public Map<String,Object> create(TAgentContractReq tAgentContractReq) {
        Map<String,Object> resultData =  new HashMap<>() ;

        //校验请求参数
        ResultEnum resultEnum = checkData(tAgentContractReq);
        if(resultEnum != null)  {
            resultData.put("flag","false") ;
            resultData.put("msg",resultEnum.getMessage()) ;
            return  resultData ;
        }

        try {
            logger.info("tAgentContractReq : {}", tAgentContractReq.toString());

            //设置全量游戏百分比
            specifyAllGamePercent(tAgentContractReq);

            tAgentContractReq.refresh();
            TAgentContract tAgentContract = new TAgentContract();
            BeanUtils.copyProperties(tAgentContractReq, tAgentContract, "id");
            logger.info("commissionPlanPO : {}", tAgentContract.toString());

            if(StringUtils.isBlank(tAgentContract.getIsFd())        ){
                resultData.put("flag","false") ;
                resultData.put("msg","isFd is not blank") ;
                return  resultData ;
            }

            if(tAgentContract.getIsFd().equals("0")  &&  tAgentContract.getSettlementConditions() == 0    &&  (tAgentContractReq.getAgentContractListReqList() ==null  ||   tAgentContractReq.getAgentContractListReqList().size() ==0  ||   tAgentContractReq.getAgentContractListReqList().get(0).getIsChecked().equals("0"))){
                resultData.put("flag","false") ;
                resultData.put("msg"," paramters is error ") ;
                return  resultData ;
            }

            if(tAgentContract.getSettlementConditions() == 1   &&  (tAgentContractReq.getAgentContractListReqList() != null   &&  tAgentContractReq.getAgentContractListReqList().size() >  0   &&   tAgentContractReq.getAgentContractListReqList().get(0).getIsChecked().equals("1")))
            {
                resultData.put("flag","false") ;
                resultData.put("msg"," paramters is error ") ;
                return  resultData ;
            }

            resultData.put("flag","true") ;


//
            super.save(tAgentContract);

            List<TAgentContractListReq>  list =   tAgentContractReq.getAgentContractListReqList();

            if(list!= null ) {
                Long id = tAgentContract.getId();

//            logger.info("---id = {}",  id);
                int l = 0;
                for (TAgentContractListReq tAgentContractListReq : list) {
                    tAgentContractListReq.setContractId(id + "");

                    TAgentContractList obj = new TAgentContractList();
                    BeanUtils.copyProperties(tAgentContractListReq, obj);

                    obj.setContractListId((id + "_" + (++l)));
                    tAgentContractListMapper.insert(obj);

                }


            }



        } catch (DuplicateKeyException e) {
            logger.error(ResultEnum.CONTRACT_NAME_DUPLICATE.getMessage() + e);
            throw new MKTAgentException(ResultEnum.CONTRACT_NAME_DUPLICATE);
        }catch (Exception e) {
           e.printStackTrace();

        }
        return  resultData ;
    }

    private void specifyAllGamePercent(TAgentContractReq tAgentContractReq){
        if(null==tAgentContractReq){
            return;
        }
        List<SettlementPercentageReq> ll = tAgentContractReq.getSettlementPercentageList();
        SettlementPercentageReq o1 = ll.get(0);
        if(tAgentContractReq.getSettlementConditions() == 1){
            o1.setAllGamesPercentage(tAgentContractReq.getActiveUserCommission().floatValue());
        }else{
            //获取梯度佣金配置中佣金值最大的那个
            List<TAgentContractListReq> gradientList = tAgentContractReq.getAgentContractListReqList();
            TAgentContractListReq max = gradientList.stream()
                    .max(Comparator.comparing(TAgentContractListReq::getCommission))
                    .orElse(gradientList.get(0));
            o1.setAllGamesPercentage(max.getCommission().floatValue());
        }
    }

    private ResultEnum checkSettlementConditions(TAgentContractReq req){
        if(req==null){
            return ResultEnum.BAD_REQUEST;
        }
        List<TAgentContractListReq> agentContractListReqList = req.getAgentContractListReqList();
        //勾选了FD限制
        boolean isFd = Constants.ONE.equals(req.getIsFd());
        //勾选了Active Users结算
        boolean isActiveUser = Constants.INT_ONE.equals(req.getSettlementConditions());
        //勾选了Turnover或GGR结算
        boolean isTurnoverOrGgr = !CollectionUtils.isEmpty(agentContractListReqList)
                && Constants.ONE.equals(Optional.ofNullable(agentContractListReqList.get(0)).orElse(new TAgentContractListReq()).getIsChecked());
        //三个都没勾选，不可以
        if(!isFd && !isActiveUser && !isTurnoverOrGgr){
            return ResultEnum.CONTRACT_CONDITION_NOT_CONFIGURED;
        }
        //Active Users和Turnover或GGR不能同时勾选
        if(isActiveUser && isTurnoverOrGgr){
            return ResultEnum.CONTRACT_CONDITION_CANT_ALL_CONFIGURED;
        }
        //不能只勾选了FD限制
        if(isFd && !isActiveUser && !isTurnoverOrGgr){
            return ResultEnum.CONTRACT_CONDITION_CANT_ONLY_FD;
        }
        return null;
    }

    private ResultEnum checkData(TAgentContractReq tAgentContractReq) {
        //校验核算条件配置
        ResultEnum resultEnum = checkSettlementConditions(tAgentContractReq);
        if(null!=resultEnum){
            return resultEnum;
        }

        //校验佣金比例是否超过最大值
        BigDecimal max;
        if(tAgentContractReq.getCommissionPlanType().equals("GGR")){
            max = new BigDecimal(50);
        }else {
            max = new BigDecimal(3);

        }

        if (tAgentContractReq.getSettlementConditions() == 1) {
            if(tAgentContractReq.getActiveUserCommission()==null){
                return ResultEnum.CONTRACT_CONDITION_PERCENTAGE_INVALID;
            }
            if (tAgentContractReq.getActiveUserCommission().doubleValue() >max.doubleValue()  ){
                return ResultEnum.CONTRACT_CONDITION_PERCENTAGE_EXCEED;
            }
        }else  {
            List<TAgentContractListReq> reqList  =    tAgentContractReq.getAgentContractListReqList();
            if(reqList.stream().anyMatch(req -> Objects.isNull(req.getCommission()))){
                return ResultEnum.CONTRACT_CONDITION_PERCENTAGE_INVALID;
            }
            if(reqList.stream().anyMatch(req -> req.getCommission().doubleValue() > max.doubleValue())){
                return ResultEnum.CONTRACT_CONDITION_PERCENTAGE_EXCEED;
            }

            /*for(TAgentContractListReq contractListReq :  reqList){
                if(contractListReq.getCommission().doubleValue() > max.doubleValue()  ) {
                    return ResultEnum.CONTRACT_CONDITION_PERCENTAGE_EXCEED;
                }
            }*/
            //校验配置的梯度佣金是否是逐级增大
            ResultEnum checkResult;
            for (int i = 0; i < reqList.size()-1; i++) {
                checkResult = checkTurnoverGgr(reqList.get(i),reqList.get(i+1));
                if(null!=checkResult){
                    return checkResult;
                }
            }
        }

        return null;
    }


    private ResultEnum checkTurnoverGgr(TAgentContractListReq reqFirst, TAgentContractListReq reqSecond){
        if(null==reqFirst || null==reqSecond || null==reqFirst.getTurnoverGgr() || null==reqSecond.getTurnoverGgr()){
            return ResultEnum.CONTRACT_CONDITION_ERROR;
        }
        if(reqFirst.getTurnoverGgr().compareTo(reqSecond.getTurnoverGgr())>=0){
            return ResultEnum.CONTRACT_CONDITION_ERROR;
        }
        return null;
    }

    @Override
    public Page<TAgentContractResp> queryList(TAgentContractQueryReq tAgentContractQueryReq) {
        Page<TAgentContractResp> pageResult=new Page<>();
        //设置分页
        tAgentContractQueryReq.setPageNum(tAgentContractQueryReq.getPageNum());

        Integer total=tAgentContractMapper.count(tAgentContractQueryReq);
        if(null!=total&&total!=0){
            List<TAgentContract> tAgentContractList = tAgentContractMapper.queryList(tAgentContractQueryReq);
            List<TAgentContractResp> commissionPlanRespList=BeanCopyUtil.copyListProperties(tAgentContractList,TAgentContractResp::new,(tAgentContract,tAgentContractResp) ->{
                tAgentContractResp.setId(String.valueOf(tAgentContract.getId()));
                tAgentContractResp.handleSettlementPercentageList(tAgentContract.getPercentageDetails());
                tAgentContractResp.setCreateTime(tAgentContract.getCreateTime());

                Map<String,Object> parames =   new HashMap<>() ;
                parames.put("contract_id",tAgentContract.getId());

                List<TAgentContractList>  agentContractListReqList  =  tAgentContractListMapper.selectByMap(parames) ;

                tAgentContractResp.setAgentContractListReqList(agentContractListReqList);


            });
            if(null!=tAgentContractQueryReq.getPageNum() && null!=tAgentContractQueryReq.getPageSize()){
                pageResult.setSize(tAgentContractQueryReq.getPageSize()).setCurrent(tAgentContractQueryReq.getPageNum())
                        .setPages(total / tAgentContractQueryReq.getPageSize());
            }else{
                pageResult.setSize(-1).setCurrent(-1).setPages(-1);
            }
            pageResult.setRecords(commissionPlanRespList).setTotal(total);
        }
        return pageResult;
    }

    @Override
    @Transactional
    public void update(TAgentContractReq tAgentContractReq) {
          logger.info("tAgentContractReq : gson = {}",   new Gson().toJson(tAgentContractReq));
//        logger.info("tAgentContractReq : {}", tAgentContractReq.toString());

        //校验请求参数
        ResultEnum resultEnum = checkData(tAgentContractReq);
        if(null!=resultEnum)  {
            throw new MKTAgentException(resultEnum);
        }

        TAgentContract tAgentContract=selectOne(tAgentContractReq.getId());
        if(ObjectUtils.isEmpty(tAgentContract)){
            throw new MKTAgentException(ResultEnum.AGENT_CONTRACT_NOT_EXIST);
        }
        //设置全量游戏百分比
        specifyAllGamePercent(tAgentContractReq);
        tAgentContractReq.refresh();
        TAgentContract agentContract=new TAgentContract();
        BeanUtils.copyProperties(tAgentContractReq,agentContract,"agentCount");
        agentContract.setAgentCount(tAgentContract.getAgentCount());
        logger.info("agentContract : {}", agentContract);
        //First: update tAgentContractByBind of all agent with this agentContract , tAgentContractByBind of Level 1 Agent
        //are consistent with this agentContract , tAgentContractByBind with all sub agents of all Level 1 Agent with this
        //tAgentContractByBind reset to o;

        List<SettlementPercentageReq> initList = new ArrayList<>();
        initList.add(new SettlementPercentageReq());
        TAgentContractBind initBind = new TAgentContractBind();
        initBind.setCommissionContractId(agentContract.getId());
        initBind.setPercentageDetails(SerializationUti.serializeToString(initList));

//        if(!tAgentContractReq.getCommissionValues().equals(tAgentContract.getCommissionValues())){
            if(isLevelUpdate  ==2) {

                new Thread(() -> {
                    //将该佣金方案下的所有的代理的佣金方案初始化
                    tAgentContractBindService.updateBatchPercentageByBindId(initBind);

                    List<TAgentContractBind> tAgentContractBindList = tAgentContractBindService.queryAllTopAgentContractBindByContractId(agentContract.getId());
                    tAgentContractBindList.forEach(tAgentContractBind -> {
                        tAgentContractBind.setPercentageDetails(SerializationUti.serializeToString(tAgentContractReq.getSettlementPercentageList()));
                    });
                    tAgentContractBindService.saveOrUpdateBatch(tAgentContractBindList);

                }).start();  //去更新
            }
//        }
        //Second: update agentContract;
        tAgentContractMapper.updateById(agentContract);


        Long    id =   tAgentContractReq.getId() ;

        Map<String,Object>  parame = new HashMap<>() ;
        parame.put("id",id+"") ;


        tAgentContractListMapper.deleteByContactId(parame) ;

        List<TAgentContractListReq>  list =   tAgentContractReq.getAgentContractListReqList();

        if(list!= null ) {

//            logger.info("---id = {}",  id);
            int l = 0;
            for (TAgentContractListReq tAgentContractListReq : list) {
                tAgentContractListReq.setContractId(id + "");

                TAgentContractList obj = new TAgentContractList();
                BeanUtils.copyProperties(tAgentContractListReq, obj);

                obj.setContractListId((id + "_" + (++l)));
                tAgentContractListMapper.insert(obj);

            }


        }


    }

    @Override
    public void updateAgentCountById(Long id) {
        TAgentContract tAgentContract=selectOne(id);
        //update agentCount +1
        tAgentContract.setAgentCount(tAgentContract.getAgentCount()+1);
        tAgentContractMapper.updateById(tAgentContract);
    }
    @Override
    @org.springframework.transaction.annotation.Transactional(rollbackFor = Exception.class)
    public void updateAgentCountByIdV1(Long id) {
        UpdateWrapper<TAgentContract> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", id).setSql("agent_count = agent_count + 1");
        int rowsUpdated = tAgentContractMapper.update(null, updateWrapper);
        if (rowsUpdated <= 0) {
            throw new IllegalStateException("No records were updated, operation failed.");
        }
    }

    @Override
    public TAgentContract selectOne(Long id){
        //select by id
        QueryWrapper<TAgentContract> wrapper = new QueryWrapper();
        if(id!=null){
            wrapper.eq("id",id);
        }else{
            return null;
        }
        TAgentContract tCommissionContract=tAgentContractMapper.selectOne(wrapper);
        logger.info("tCommissionContract :{}",tCommissionContract);
        return tCommissionContract;
    }

    @Override
    public List<TAgentSettlementResp> queryListByPeriod(String settlementPeriod) {
        List<TAgentSettlementResp> tAgentSettlementRespList=tAgentContractMapper.queryListByPeriod(settlementPeriod);
        tAgentSettlementRespList.forEach(tAgentSettlementResp -> {
            String percentage=tAgentSettlementResp.getPercentageDetails();
            if(StringUtils.isNotBlank(percentage)){
                tAgentSettlementResp.setSettlementPercentageReq(SerializationUti.deserializeFromString(percentage, SettlementPercentageReq.class));
            }
        });
        return tAgentSettlementRespList;
    }

    @Override
    public void export(TAgentContractQueryReq tAgentContractQueryReq, HttpServletResponse response) {
        logger.info("tAgentContractQueryReq : {}", tAgentContractQueryReq.toString());
        TAgentContract tAgentContract=new TAgentContract();
        BeanUtils.copyProperties(tAgentContractQueryReq,tAgentContract);
        logger.info("tAgentContract : {}", tAgentContract.toString());
        QueryWrapper wrapper=queryWrapper(tAgentContractQueryReq,tAgentContract);
        long total = super.count(wrapper);
        if(Objects.isNull(total) || total == 0) {
            return;
        }
        List<TAgentContract> tCommissionContractList = super.list(wrapper);
        List<TAgentContractResp> commissionPlanRespList=BeanCopyUtil.copyListProperties(tCommissionContractList,TAgentContractResp::new);
        try {
            ExcelUtil.export(commissionPlanRespList,TAgentContractResp.class,"commissionPlanRespList",response);
        }catch (IOException e){
            logger.error(ResultEnum.CONTRACT_EXPORT_FAIL.getMessage() + e);
            throw new MKTAgentException(ResultEnum.CONTRACT_EXPORT_FAIL);
        }
    }

    @Override
    public void delete(Long id) {
        TAgentContract tAgentContract=selectOne(id);
        if(tAgentContract.getAgentCount()!=0){
            logger.info(ResultEnum.CONTRACT_DELETE_USING.getMessage() +" id:{}",id);
            throw new MKTAgentException(ResultEnum.CONTRACT_DELETE_USING);
        }
        this.getBaseMapper().deleteById(id);
    }

    @Override
    public List<TAgentContractDictionaryResp> queryNameList(String  contractName) {
        TAgentContract tAgentContract = new TAgentContract ();
        List<TAgentContract> list=super.list(new LambdaQueryWrapper<TAgentContract>().like(TAgentContract::getCommissionPlanName,contractName).orderByDesc(TAgentContract::getCreateTime));
        List<TAgentContractDictionaryResp> TAgentContractDictionaryList = list.stream().map(agentContract->{
                TAgentContractDictionaryResp tAgentContractDictionaryResp = new TAgentContractDictionaryResp();
                tAgentContractDictionaryResp.setId(String.valueOf(agentContract.getId()));
                tAgentContractDictionaryResp.setCommissionPlanName(agentContract.getCommissionPlanName());
            return tAgentContractDictionaryResp;
        }).collect(Collectors.toList());
        return TAgentContractDictionaryList;
    }


    public QueryWrapper queryWrapper(TAgentContractQueryReq tAgentContractQueryReq,TAgentContract tAgentContract){
        QueryWrapper<TAgentContract> wrapper = new QueryWrapper();
        if(StringUtils.isNotBlank(tAgentContract.getCommissionPlanName())){
            wrapper.like("COMMISSION_PLAN_NAME",tAgentContract.getCommissionPlanName());
        }
        if(null != tAgentContract.getId() && tAgentContract.getId()!=0){
            wrapper.like("ID",tAgentContract.getId());
        }
        if(StringUtils.isNotBlank(tAgentContract.getCommissionPlanType()) && !tAgentContract.getCommissionPlanType().equals("ALL")){
            wrapper.eq("COMMISSION_PLAN_TYPE",tAgentContract.getCommissionPlanType());
        }
        if(StringUtils.isNotBlank(tAgentContract.getSettlementPeriod()) && !tAgentContract.getSettlementPeriod().equals("ALL")){
            wrapper.eq("SETTLEMENT_PERIOD",tAgentContract.getSettlementPeriod());
        }
        if(StringUtils.isNotBlank(tAgentContract.getCreateBy())){
            wrapper.like("CREATED_BY",tAgentContract.getCreateBy());
        }
        if(tAgentContract.getCreateTime()!=null){
            wrapper.between("CREATE_TIME",tAgentContractQueryReq.getStartTime(),tAgentContractQueryReq.getEndTime());
        }
        wrapper.eq("is_deleted",0).orderByDesc("CREATE_TIME");

        return wrapper;
    }
}





