package com.mkt.agent.api.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @Description 实现转账功能
 * @Classname RabbitMQConfig
 * @Date 2023/9/9 15:06
 * @Created by TJSLucian
 */
@Configuration
@Slf4j
public class RabbitMQConfig {

    @Value("${spring.rabbitmq.host}")
    private String host;
    @Value("${spring.rabbitmq.port}")
    private String port;
    @Value("${spring.rabbitmq.username}")
    private String username;
    @Value("${spring.rabbitmq.password}")
    private String password;
    @Value("${spring.rabbitmq.transfer.exchange}")
    private String exchange;
    @Value("${spring.rabbitmq.transfer.queue}")
    private String queue;
    @Value("${spring.rabbitmq.transfer.routingKey}")
    private String routingKey;

    // RabbitMQ服务器连接配置
    @Bean
    public ConnectionFactory connectionFactory() {
        log.info("port is:{}",port);
        CachingConnectionFactory connectionFactory = new CachingConnectionFactory();
        connectionFactory.setHost(host); // RabbitMQ服务器地址
        connectionFactory.setPort(Integer.parseInt(port)); // RabbitMQ服务器端口
        connectionFactory.setUsername(username); // RabbitMQ用户名
        connectionFactory.setPassword(password); // RabbitMQ密码
        return connectionFactory;
    }

    // 配置交换机
    @Bean
    public DirectExchange directExchange() {
        return new DirectExchange(exchange);
    }

    // 声明一个队列
    @Bean
    public Queue myQueue() {
        return new Queue(queue);
    }

    // 绑定队列到交换机
    @Bean
    public Binding binding() {
        return BindingBuilder.bind(myQueue()).to(directExchange()).with(routingKey);
    }

    // 声明一个RabbitTemplate，用于发送和接收消息
    @Bean
    public RabbitTemplate rabbitTemplate() {
        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory());
        rabbitTemplate.setExchange(exchange);
        rabbitTemplate.setRoutingKey(routingKey);
        return rabbitTemplate;
    }

}
