package com.mkt.agent.manager.mapper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.manager.entities.SystemUser;
import com.mkt.agent.manager.entities.request.LoginUserRequest;
import com.mkt.agent.manager.entities.response.SystemUserResponse;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Objects;

@Mapper
public interface SystemUserMapper extends BaseMapper<SystemUser> {

    default SystemUser getSystemUserByUsername(LoginUserRequest loginUser) {
        return this.selectOne(Wrappers.<SystemUser>lambdaQuery()
                // 查询条件
                .eq(Objects.nonNull(loginUser.getLoginName()), SystemUser::getLoginName, loginUser.getLoginName()));
    }

    SystemUserResponse selectDetailByUserId(@Param("userId") Long userId);

    default Page<SystemUser> selectUserPage(Page<SystemUser> page, SystemUser systemUser) {
        // 构建条件查询
        LambdaQueryWrapper<SystemUser> queryWrapper = Wrappers.<SystemUser>lambdaQuery()
                // 用户角色
                .eq(Objects.nonNull(systemUser.getUserGroupId()), SystemUser::getUserGroupId, systemUser.getUserGroupId())
                // 创建人
                .eq(StringUtils.isNotEmpty(systemUser.getCreateBy()), SystemUser::getCreateBy, systemUser.getCreateBy())
                // 更新人
                .eq(StringUtils.isNotEmpty(systemUser.getUpdateBy()), SystemUser::getUpdateBy, systemUser.getUpdateBy())
                // 状态
                .eq(Objects.nonNull(systemUser.getIsEnable()), SystemUser::getIsEnable, systemUser.getIsEnable())
                // 账号
                .like(StringUtils.isNotEmpty(systemUser.getLoginName()), SystemUser::getLoginName, systemUser.getLoginName())
                // 过滤掉admin
                .ne(SystemUser::getId, 1);

        return this.selectPage(page, queryWrapper);

    }

    default Long countByGroupId(Long id) {
        return this.selectCount(Wrappers.<SystemUser>lambdaQuery()
                .eq(Objects.nonNull(id), SystemUser::getUserGroupId, id));
    }

}
