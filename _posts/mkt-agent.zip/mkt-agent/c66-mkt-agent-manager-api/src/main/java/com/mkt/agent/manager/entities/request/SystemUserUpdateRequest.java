package com.mkt.agent.manager.entities.request;

import com.mkt.agent.common.annotation.DecryptField;
import com.mkt.agent.common.annotation.Query;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "用户更新请求实体类")
public class SystemUserUpdateRequest {

    @ApiModelProperty(value = "id", required = true)
    @NotNull(message = "用户ID不允许为空!")
    private Long id;

    @ApiModelProperty(value = "启用标识：是否启用，0禁用/1启用(Activition)", required = true)
    @Max(value = 1, message = "状态不允许为空!")
    @Min(value = 0, message = "状态不允许为空!")
    @NotNull(message = "状态不允许为空!")
    private Integer isEnable;

    @ApiModelProperty(value = "用户名(System Account)")
    @Query
    private String loginName;

    @ApiModelProperty(value = "用户角色ID(Role Id)", required = true)
    @NotNull(message = "用户角色不允许为空!")
    private Long userGroupId;

    @ApiModelProperty(value = "密码")
    private String password;

    @ApiModelProperty(value = "备注", hidden = true)
    private String remarks;

}
