package com.mkt.agent.manager.entities.request;

import com.mkt.agent.common.annotation.Query;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "角色创建请求类")
public class UserGroupCreateRequest {

    @ApiModelProperty(value = "启用标识：是否启用，0禁用/1启用(Activition)", required = true)
    @Max(value = 1, message = "isEnable is required!")
    @Min(value = 0, message = "isEnable is required!")
    @NotNull(message = "isEnable is required!")
    private Integer isEnable;

    @ApiModelProperty(value = "角色名称(Role Name)", required = true)
    @NotBlank(message = "groupName is required!")
    @Query
    private String groupName;

    @ApiModelProperty(value = "角色描述(Description)")
    private String groupDescription;

    @ApiModelProperty(value = "菜单id列表(Permission)")
    private List<Long> resourceIds;

}
