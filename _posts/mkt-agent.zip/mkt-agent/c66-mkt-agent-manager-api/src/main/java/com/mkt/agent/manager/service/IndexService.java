package com.mkt.agent.manager.service;

public interface IndexService {
}
