package com.mkt.agent.manager.entities.response;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.annotation.ExcelColumn;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.enums.CustomizedValidationContents;
import com.mkt.agent.common.valid.EnumValid;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @ClassName CommissionPlanResp
 * @Description 佣金方案
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Data
public class TAgentCustomersResp implements Serializable {

    @ApiModelProperty(value = "AGENT_ID")
    private String agentId;

    /*
        佣金方案类型
    */
    @ApiModelProperty(value = "LOGIN_NAME")
    @ExcelColumn(value ="Account",order = 1)
    private String loginName;

    /*
        佣金方案名称
    */
    @ApiModelProperty(value = "COMMISSION_PLAN_CODE")
    private String commissionPlanCode;

    /*
        佣金方案名称
    */
    @ApiModelProperty(value = "COMMISSION_PLAN_NAME")
    @ExcelColumn(value ="Commission Plan",order = 2)
    private String commissionPlanName;

    /*
        佣金方案类型
        0:turnover, 1:GGR
   */
    @ApiModelProperty(value = "COMMISSION_PLAN_TYPE")
    @ExcelColumn(value ="Commission Type",order = 3)
    private String commissionPlanType;

    /*
        Referral Id
    */
    @ApiModelProperty(value = "Referral Id")
    // @ExcelColumn(value ="Referral Id",order = 5)
    private String referralId;

    /*
        isEnable: 0: No, 1: Yes
    */
    @ApiModelProperty(value = "isEnable")
    private Integer isEnable;

    @ExcelColumn(value ="Activition",order = 6)
    private String isEnableValue;

    /*
        flag
    */
    @ApiModelProperty(value = "parent")
    @ExcelColumn(value ="Parent",order = 7)
    private String parent;

    /*
        Level_One_Agent
    */
    @ApiModelProperty(value = "Level_One_Agent")
    @ExcelColumn(value ="LevelOneAgent",order = 8)
    private String levelOneAgent;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long levelOneCustomersId;

    /*
        代理类型：0：General Line (普通代理)，1：Professional Line(专业代理可发展下级)
    */
    @ApiModelProperty(value = "代理类型", example = "0:General line 1:Professional line")
    @ExcelIgnore
    private Integer agentType;


    /*
        agentType
    */
    @ApiModelProperty(value = "代理类型")
    @ExcelColumn(value ="Agent Type",order = 9)
    private String agentTypeValue;

    /*
       agentLevel
    */
    @ApiModelProperty(value = "AGENT_LEVEL")
    @ExcelColumn(value ="Agent Level",order = 10)
    private Integer agentLevel;

    @ApiModelProperty(value = "siteId 1:Bingoplus  2:Arenaplus  3:Gameplus")
    @EnumValid(contents = CustomizedValidationContents.site_id_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class} )
    private Integer productSiteId;

    @ApiModelProperty(value = "Product")
    @ExcelColumn(value ="product",order = 11)
    private String productSiteIdValue;

    /*
        创建时间
    */
    @ApiModelProperty(value = "CREATE_TIME")
    @ExcelColumn(value ="Create Time",order = 12)
    private String createTime;


    /*
        创建时间
    */
    @ApiModelProperty(value = "CUSTOMERS_ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long customersId;

    /*
        备注
    */
    @ApiModelProperty(value = "Remark")
    @ExcelColumn(value ="Remark",order = 13)
    private String remarks;

    /*
        结算条件
        0,1
   */
    @ApiModelProperty(value = "SETTLEMENT_CONDITIONS [0,1]")
    private int settlementConditions;

    /*
        活跃用户投注额
        SETTLEMENT_PERIOD 为1时必填,支持小数
    */
    @ApiModelProperty(value = "ACTIVE_USER_TURNOVER [SETTLEMENT_PERIOD 为1时必填]")
    private int activeUserTurnover;

    /*
        活跃用户数量
        SETTLEMENT_PERIOD 为1时必填,整数
    */
    @ApiModelProperty(value = "ACTIVE_USER_HEADCOUNT [SETTLEMENT_PERIOD 为1时必填]")
    private int activeUserHeadcount;

    /*
        结算类型
        ALL_GAME_TYPES,BY_GAME_TYPE
    */
    @ApiModelProperty(value = "COMMISSION_VALUES")
    private String commissionValues;


    /*
        1:Bingoplus  2:Arenaplus  3:Gameplus
    */
    @ApiModelProperty(value = "siteId 1:Bingoplus  2:Arenaplus  3:Gameplus")
    private Integer siteId;


    /*
         佣金比例文本
     */
    @ApiModelProperty(value = "PERCENTAGE_DETAILS")
    private String percentageDetails;


    /*
         佣金比例集合
     */
    @ApiModelProperty(value = "佣金比例集合")
    private List<SettlementPercentageReq> settlementPercentageReq;

    /*
        可发展层级
    */
    @ApiModelProperty(value = "可发展层级")
    private Integer developableLevel;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long commissionContractBindId;

}
