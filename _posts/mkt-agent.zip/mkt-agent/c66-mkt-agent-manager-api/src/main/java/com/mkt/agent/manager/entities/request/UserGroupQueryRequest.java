package com.mkt.agent.manager.entities.request;

import com.mkt.agent.common.annotation.Query;
import com.mkt.agent.common.constants.SQLConstants;
import com.mkt.agent.common.entity.BasePageRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "角色查询实体类")
public class UserGroupQueryRequest extends BasePageRequest {

    @ApiModelProperty(value = "角色名称(Role Name)")
    @Query(mt = SQLConstants.Query.LIKE)
    private String groupName;

    @ApiModelProperty(value = "状态：是否启用，0禁用/1启用(Activition)")
    @Query
    private Integer isEnable;

    @ApiModelProperty(value = "创建人(Creator)")
    @Query
    private String createBy;

    @ApiModelProperty(value = "更新人(Modifier)")
    @Query
    private String updateBy;

    @ApiModelProperty(hidden = true)
    @Query(mt = SQLConstants.Query.NE)
    private Long id;
}
