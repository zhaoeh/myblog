package com.mkt.agent.manager.handler;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import com.mkt.agent.common.entity.system.LoginUserInfo;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.UserContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

/**
 * 更新自动填充
 */
@Component
@Slf4j
public class ManagerMetaObjectHandler implements MetaObjectHandler {

    @Override
    public void insertFill(MetaObject metaObject) {
        log.info("metaObject is :{}",metaObject.toString());
        LoginUserInfo context = UserContext.getContext();
        String username = ObjectUtils.isNotEmpty(context) ? UserContext.getUsername() : "not_login_user";
        String userType = ObjectUtils.isNotEmpty(context) ? UserContext.getUserType() : "not_login_user";
        log.info("userType is:{]",userType);
        // 插入操作时，自动填充字段的值
        this.setFieldValByName("createBy", username, metaObject);
        this.setFieldValByName("createTime", DateUtils.getCurrentDateTime(), metaObject);
        this.setFieldValByName("createUserType", userType, metaObject);
        this.setFieldValByName("updateBy", username, metaObject);
        this.setFieldValByName("updateTime", DateUtils.getCurrentDateTime(), metaObject);
        this.setFieldValByName("updateUserType", userType, metaObject);
    }

    @Override
    public void updateFill(MetaObject metaObject) {
        LoginUserInfo context = UserContext.getContext();
        String username = ObjectUtils.isNotEmpty(context) ? UserContext.getUsername() : "not_login_user";
        String userType = ObjectUtils.isNotEmpty(context) ? UserContext.getUserType() : "not_login_user";
        // 更新操作时，自动填充字段的值
        this.setFieldValByName("updateBy", username, metaObject);
        this.setFieldValByName("updateTime", DateUtils.getCurrentDateTime(), metaObject);
        this.setFieldValByName("updateUserType", userType, metaObject);
    }
}
