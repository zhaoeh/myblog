package com.mkt.agent.manager.controller;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.utils.UserContext;
import com.mkt.agent.manager.entities.request.ResourceComponentCreateRequest;
import com.mkt.agent.manager.entities.request.ResourceComponentEnableRequest;
import com.mkt.agent.manager.entities.request.ResourceComponentUpdateRequest;
import com.mkt.agent.manager.entities.response.ResourceComponentTreeResponse;
import com.mkt.agent.manager.service.ResourceComponentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/manager/resource")
@Api(tags = {"菜单管理Api"})
public class ResourceComponentController {

    @Autowired
    private ResourceComponentService resourceComponentService;

    @GetMapping("/all")
    @ApiOperation(value = "获取所有菜单")
    public Result<List<ResourceComponentTreeResponse>> getAllResourceComponent() {
        Long userId = Long.valueOf(UserContext.getUserId());
        return Result.success(resourceComponentService.getResourcesTreeByUserId(userId));
    }

    @PostMapping("/create")
    @ApiOperation(value = "添加子菜单")
    public Result createUserGroup(@RequestBody @Validated ResourceComponentCreateRequest request) {
        resourceComponentService.createUserGroup(request);
        return Result.success();
    }

    @PostMapping("/enable")
    @ApiOperation(value = "启用/禁用菜单")
    public Result enableUserGroup(@RequestBody @Validated ResourceComponentEnableRequest request) {
        resourceComponentService.enableResourceComponent(request);
        return Result.success();
    }

    @PostMapping("/update")
    @ApiOperation(value = "修改名称")
    public Result editUserGroup(@RequestBody @Validated ResourceComponentUpdateRequest request) {
        resourceComponentService.modifyName(request);
        return Result.success();
    }

    @GetMapping("/up")
    @ApiOperation(value = "上移", hidden = true)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "菜单id", required = true,dataTypeClass = Long.class)
    })
    public Result moveUp(@RequestParam Long id) {
        resourceComponentService.moveUpOrDown(id, true);
        return Result.success();
    }

    @GetMapping("/down")
    @ApiOperation(value = "下移", hidden = true)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "菜单id", required = true,dataTypeClass = Long.class)
    })
    public Result moveDown(@RequestParam Long id) {
        resourceComponentService.moveUpOrDown(id, false);
        return Result.success();
    }
}
