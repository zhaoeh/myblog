package com.mkt.agent.manager.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.annotation.EncryptMethod;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.manager.entities.SystemUser;
import com.mkt.agent.manager.entities.request.*;
import com.mkt.agent.manager.entities.response.SystemUserResponse;
import com.mkt.agent.manager.service.SystemUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/manager/user")
@Api(tags = {"用户Api"})
@Slf4j
public class SystemUserController {

    @Autowired
    private SystemUserService systemUserService;

    @GetMapping("/one")
    @ApiOperation(value = "获取一个用户")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "查询id", required = true,dataTypeClass = Long.class)
    })
    public Result<SystemUserResponse> getOneSystemUserInfo(@RequestParam Long id) {
        return Result.success(systemUserService.getUserDetailByUserId(id));
    }

    @PostMapping("/list")
    @ApiOperation(value = "获取用户列表(分页)")
    public Result<Page<SystemUser>> getSystemUserList(@RequestBody SystemUserQueryRequest systemUserReq) {
        return Result.success(systemUserService.getSystemUserList(systemUserReq));
    }

    @PostMapping("/create")
    @ApiOperation(value = "添加用户")
    @EncryptMethod
    public Result<SystemUser> createUser(@RequestBody @Validated SystemUserCreateRequest request) {
        log.info("/manager/user/create 接口");
        return Result.success(systemUserService.createUser(request));
    }

    @PostMapping("/enable")
    @ApiOperation(value = "启用/禁用用户")
    public Result enableUser(@RequestBody @Validated SystemUserEnableRequest request) {
        systemUserService.enableUser(request);
        return Result.success();
    }

    @PostMapping("/update")
    @ApiOperation(value = "修改用户")
    public Result editUser(@RequestBody @Validated SystemUserUpdateRequest request) {
        systemUserService.editUser(request);
        return Result.success();
    }

    @GetMapping("/delete")
    @ApiOperation(value = "删除用户")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "用户id", required = true,dataTypeClass = Long.class)
    })
    public Result deleteUser(@RequestParam Long id) {
        systemUserService.deleteUser(id);
        return Result.success();
    }

    @PostMapping("/password/set")
    @ApiOperation(value = "修改密码(修改其他用户)")
    public Result setPassword(@RequestBody @Validated SystemUserPwdUpdateRequest request) {
        systemUserService.setPassword(request);
        return Result.success();
    }

}
