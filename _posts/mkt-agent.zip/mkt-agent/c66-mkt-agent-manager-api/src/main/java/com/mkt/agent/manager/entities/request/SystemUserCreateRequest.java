package com.mkt.agent.manager.entities.request;

import com.mkt.agent.common.annotation.DecryptField;
import com.mkt.agent.common.annotation.Query;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "用户创建请求类")
@ToString(exclude = {"password"})
public class SystemUserCreateRequest {

    @ApiModelProperty(value = "启用标识：是否启用，0禁用/1启用(Activition)", required = true)
    @Max(value = 1, message = "isEnable is required!")
    @Min(value = 0, message = "isEnable is required!")
    @NotNull(message = "isEnable is required!")
    private Integer isEnable;

    @ApiModelProperty(value = "用户名(System Account)", required = true)
    @NotBlank(message = "loginName is required!")
    @Query
    private String loginName;

    @ApiModelProperty(value = "用户角色ID", required = true)
    @NotNull(message = "userGroupId is required!")
    private Long userGroupId;

    @ApiModelProperty(value = "密码", required = true)
    @NotNull(message = "password is required!")
    @DecryptField
    private String password;

    @ApiModelProperty(value = "备注", hidden = true)
    private String remarks;

}
