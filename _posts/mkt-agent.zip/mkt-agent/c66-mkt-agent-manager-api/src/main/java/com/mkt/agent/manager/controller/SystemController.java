package com.mkt.agent.manager.controller;


import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.utils.UserContext;
import com.mkt.agent.manager.entities.request.LoginUserRequest;
import com.mkt.agent.manager.entities.request.SystemPwdUpdateRequest;
import com.mkt.agent.manager.entities.request.SystemUserPwdUpdateRequest;
import com.mkt.agent.manager.entities.response.LoginUserResponse;
import com.mkt.agent.manager.service.SystemService;
import com.mkt.agent.manager.service.SystemUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/manager/sys")
@Api(tags = {"代理后台系统(登录)Api"})
public class SystemController {

    @Autowired
    private SystemService systemService;

    @Autowired
    private SystemUserService systemUserService;

    @PostMapping("/login")
    @ApiOperation(value = "用户登录")
    public Result login(@RequestBody @Validated LoginUserRequest loginUser, HttpServletRequest request) {
        LoginUserResponse loginUserRes = systemService.login(loginUser, request);
        return Result.success(loginUserRes);
    }

    @GetMapping("/logout")
    @ApiOperation(value = "用户登出")
    public Result logout(@RequestHeader(value = "Authorization") String token) {
        systemService.logout(token);
        return Result.success();
    }

    @GetMapping("/refresh")
    @ApiOperation(value = "刷新token/refreshToken")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "refreshToken", value = "刷新用token", required = true,dataTypeClass = String.class)
    })
    public Result refreshToken(@RequestParam String refreshToken) {
        LoginUserResponse res = systemService.refreshToken(refreshToken);
        return Result.success(res);
    }

    @PostMapping("/password/set")
    @ApiOperation(value = "修改密码(修改当前用户)")
    public Result setPassword(@RequestBody @Validated SystemPwdUpdateRequest request) {
        request.setId(Long.valueOf(UserContext.getUserId()));
        SystemUserPwdUpdateRequest updateRequest = new SystemUserPwdUpdateRequest();
        BeanUtils.copyProperties(request, updateRequest);
        systemUserService.setPassword(updateRequest);
        return Result.success();
    }
}
