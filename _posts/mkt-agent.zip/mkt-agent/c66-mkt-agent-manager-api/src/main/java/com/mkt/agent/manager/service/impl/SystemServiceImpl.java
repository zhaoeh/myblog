package com.mkt.agent.manager.service.impl;

import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.AesEncode;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.IPUtils;
import com.mkt.agent.common.constants.AuthConstants;
import com.mkt.agent.manager.entities.SystemUser;
import com.mkt.agent.manager.entities.request.LoginUserRequest;
import com.mkt.agent.manager.entities.response.LoginUserResponse;
import com.mkt.agent.manager.exception.MKTManagerException;
import com.mkt.agent.manager.mapper.SystemUserMapper;
import com.mkt.agent.manager.service.SystemService;
import com.mkt.agent.manager.service.ResourceComponentService;
import com.mkt.agent.manager.utils.JwtTokenUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

@Service
@Slf4j
@RefreshScope
public class SystemServiceImpl implements SystemService {

    private static final String VERIFY_CACHE_KEY = "verify:userId:";

    private static final String VERIFY_CODE = "verify_code";

    @Autowired
    private SystemUserMapper systemUserMapper;

    @Autowired
    private ResourceComponentService resourceComponentService;

    @Resource
    private StringRedisTemplate stringRedisTemplate;

    @Resource
    private JwtTokenUtil jwtTokenUtil;

    @Value(value = "${user.pwd.errors.waiting}")
    private long userPwdErrorsWaitingTime;

    @Value(value = "${user.pwd.errors.times}")
    private int userPwdErrors;

    /**
     * 登录处理
     *
     * @param loginUser 用户登录
     * @param request
     * @return 登录是否成功 是:true 否:false
     */
    @Override
    public LoginUserResponse login(LoginUserRequest loginUser, HttpServletRequest request) {
        // 1.获取登录用户
        SystemUser loginUserDb = systemUserMapper.getSystemUserByUsername(loginUser);
        // 异常处理
        if (loginUserDb == null) {
            throw new MKTManagerException(ResultEnum.USERNAME_OR_PASSWORD_ERROR);
        }

        // 2.验证是否被锁定
        if ((loginUserDb.getIsLocked() != null && loginUserDb.getIsLocked() == 1) //
                || (loginUserDb.getPwdErrors() == null ? 0 : loginUserDb.getPwdErrors()) >= userPwdErrors) {
            long time = new Date(loginUserDb.getUpdateTime()).getTime();
            long passTime = System.currentTimeMillis() - time;
            if (passTime < userPwdErrorsWaitingTime * 60 * 1000) {
                long remainTime = userPwdErrorsWaitingTime * 60 * 1000 - passTime;
                String waitTime = new SimpleDateFormat("mm:ss").format(remainTime);
                // 异常处理
                throw new MKTManagerException(String.format(ResultEnum.PASSWORD_LOCKED.getMessage(), userPwdErrors, waitTime));
            } else {
                loginUserDb.setPwdErrors(0);
                loginUserDb.setIsLocked(0);
                systemUserMapper.updateById(loginUserDb);
            }
        }

        // 3.验证密码 MD5加密
        String desPwd = AesEncode.desEncrypt(loginUser.getPwd());
        String pwd = DigestUtils.md5Hex(desPwd);
        if (!loginUserDb.getPwd().equalsIgnoreCase(pwd)) {
            loginUserDb.setPwdErrors((loginUserDb.getPwdErrors() == null ? 0 : loginUserDb.getPwdErrors()) + 1);
            if (loginUserDb.getPwdErrors() == userPwdErrors) {
                loginUserDb.setIsLocked(1);
            }
            systemUserMapper.updateById(loginUserDb);
            // 异常处理
            throw new MKTManagerException(ResultEnum.USERNAME_OR_PASSWORD_ERROR);
        }

        // 4.是否被禁用
        if (loginUserDb.getIsEnable() != null && loginUserDb.getIsEnable() == 0) {
            throw new MKTManagerException(ResultEnum.USER_DISABLED);
        }

        // 5.是否没有分配权限组
        if (loginUserDb.getUserGroupId() == null) {
            throw new MKTManagerException(ResultEnum.USER_NOT_HAVE_GROUP);
        }

        // 6.进行登录,更新登录时间
        String ip = IPUtils.getRequestIP(request);
        loginUserDb.setPwdErrors(0);
        loginUserDb.setIsLocked(0);
        loginUserDb.setLastLoginIp(ip);
        loginUserDb.setLastLoginTime(DateUtils.getCurrentDateTime());
        loginUserDb.setLoginTimes((loginUserDb.getLoginTimes() == null ? 0 : loginUserDb.getLoginTimes()) + 1);
        int update = systemUserMapper.updateById(loginUserDb);
        if (update == 0) {
            throw new MKTManagerException(ResultEnum.LOGIN_ERROR);
        }

        // 生产token/refresh_token 并存入redis
        Map<String, Object> tokenMap = jwtTokenUtil.generateTokenAndCacheToken(loginUserDb.getId().toString(), loginUserDb.getLoginName());

        LoginUserResponse res = new LoginUserResponse();
        res.setAccessToken((String) tokenMap.get(AuthConstants.ACCESS_TOKEN));
        res.setRefreshToken((String) tokenMap.get(AuthConstants.REFRESH_TOKEN));
        return res;
    }


    /**
     * 登出处理
     * @param token   token
     * */
    @Override
    public void logout(String token) {

        String userId = jwtTokenUtil.getUserIdFromToken(token);
        String userName = jwtTokenUtil.getUserNameFromToken(token);
        // 1.清空当前用户redis的token/refresh_token
        jwtTokenUtil.removeToken(userId);
        // 2.log输出
        log.info("-----用户：{}下线了------", userName);
    }

    /**
     * 刷新token
     *
     * @param refreshToken 刷新token
     * @return 登录响应实体类
     */
    @Override
    public LoginUserResponse refreshToken(String refreshToken) {
        // 1. 对refreshToken解签名，并验证refreshToken是否过期
        Boolean tokenExpired = jwtTokenUtil.isTokenExpired(refreshToken);
        // refreshToken已过期则需要重新登录
        if (tokenExpired) {
            throw new MKTManagerException(ResultEnum.LOGIN_OVERTIME);
        }
        // 2. 这里为了保证 refreshToken 只能用一次，刷新后，会从 redis 中删除。
        // 如果用的不是 redis 中的 refreshToken 进行刷新令牌，则不能刷新。
        Boolean notExist = jwtTokenUtil.isRefreshTokenNotExistCache(refreshToken);
        if (notExist) {
            throw new MKTManagerException(ResultEnum.LOGIN_OVERTIME);
        }
        Map<String, Object> tokenMap = jwtTokenUtil.refreshTokenAndGenerateToken(refreshToken);
        LoginUserResponse res = new LoginUserResponse();
        res.setAccessToken((String) tokenMap.get(AuthConstants.ACCESS_TOKEN));
        res.setRefreshToken((String) tokenMap.get(AuthConstants.REFRESH_TOKEN));
        return res;
    }

    @Override
    public void removeFrontEndTokenByCustomersId(Long customersId) {
        jwtTokenUtil.removeFrontEndTokenByCustomersId(customersId);
    }

}
