package com.mkt.agent.manager.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
@Data
@RefreshScope
public class ManagerAuthProperties {
 
    //JWT 密钥
    @Value("${mkt.manager.jwt.secret}")
    private String secret;
 
    //accessToken 有效时间
    @Value("${mkt.manager.jwt.expiration}")
    private Integer expiration;

    // 白名单
    @Value("${mkt.manager.auth.whitelist}")
    private String[] whitelist;

    public List<String> getWhitelist() {
        return Arrays.asList(whitelist);
    }
}