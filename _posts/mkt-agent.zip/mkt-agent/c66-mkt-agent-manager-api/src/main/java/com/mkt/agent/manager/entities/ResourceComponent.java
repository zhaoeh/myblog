package com.mkt.agent.manager.entities;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.beans.Transient;
import java.util.ArrayList;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "菜单", description = "后台管理菜单实体类")
@TableName("t_resource_component")
public class ResourceComponent extends ManagerOperationEntity{

    private static final long serialVersionUID = -8484446019081096956L;

    @ApiModelProperty(value = "父id")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long pid;

    @ApiModelProperty(value = "菜单名称")
    private String name;

    @ApiModelProperty(value = "菜单标识名")
    private String bsName;

    @ApiModelProperty(value = "菜单级别")
    private Integer level;

    @ApiModelProperty(value = "菜单类型 0:菜单,1:按钮")
    private Integer type;

    @ApiModelProperty(value = "菜单URL")
    private String url;

    @ApiModelProperty(value = "菜单排序")
    private Integer xh;

    @ApiModelProperty(value = "菜单描述")
    private String description;

}
