package com.mkt.agent.manager.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.SumPageResponse;
import com.mkt.agent.common.entity.api.fund.req.FundRecordReq;
import com.mkt.agent.common.entity.api.fund.resp.FundRecordResp;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.manager.feign.AgentApiClient;
import com.mkt.agent.manager.utils.FeignClientHelper;
import feign.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @ClassName FundController
 * @Author TJSAlex
 * @Date 2023/5/30 15:34
 * @Version 1.0
 **/
@RestController
@RequestMapping("/fund")
public class FundController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private AgentApiClient agentApiClient;

    @PostMapping("/list")
    public Result<SumPageResponse<FundRecordResp>> list(@RequestBody FundRecordReq req) {
        try {
            SumPageResponse<FundRecordResp> resp = agentApiClient.list(req).getData();
            logger.info("/fund/list 入参FundRecordReq：{} 返回值：{}", req.toString(), resp);
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/fund/list 出异常了，入参FundRecordReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping("/export")
    public Result export(@RequestBody FundRecordReq req, HttpServletResponse httpServletResponse) {
        try {
            Response response = agentApiClient.export(req);
            logger.info("/fund/export 入参FundRecordReq：{} 返回值：{}", req.toString(), response);
            FeignClientHelper.export(response, httpServletResponse);
            return Result.success(ResultEnum.SUCCESS);
        } catch (IOException e) {
            logger.error("/fund/export 出异常了，入参FundRecordReq：{} 异常信息：{}", req.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

}
