package com.mkt.agent.manager.exception;

import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;

public class MKTManagerException extends BusinessException {

    public MKTManagerException() {
        super();
    }

    public MKTManagerException(String message) {
        super(message);
    }

    public MKTManagerException(ResultEnum resultEnum) {
        super(resultEnum);
    }

    public MKTManagerException(String message, Integer code) {
        super(message, code);
    }

    public MKTManagerException(String message, Throwable cause) {
        super(message, cause);
    }
}
