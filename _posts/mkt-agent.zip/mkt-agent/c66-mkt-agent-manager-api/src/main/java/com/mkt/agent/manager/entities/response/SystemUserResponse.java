package com.mkt.agent.manager.entities.response;

import com.mkt.agent.manager.entities.SystemUser;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "用户响应实体类")
public class SystemUserResponse extends SystemUser {

    @ApiModelProperty(value = "用户角色名称")
    private String userGroupName;
}
