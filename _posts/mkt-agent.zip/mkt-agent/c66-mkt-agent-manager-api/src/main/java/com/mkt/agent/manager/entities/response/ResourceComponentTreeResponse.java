package com.mkt.agent.manager.entities.response;

import com.mkt.agent.manager.entities.ResourceComponent;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "菜单树", description = "菜单树实体类")
public class ResourceComponentTreeResponse extends ResourceComponent {

    @ApiModelProperty(value = "子菜单")
    private List<ResourceComponentTreeResponse> children = new ArrayList();


    @ApiModelProperty(value = "子菜单")
    private Boolean isChecked;
}
