package com.mkt.agent.manager.entities.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.entity.BasePageRequest;
import com.mkt.agent.common.enums.CustomizedValidationContents;
import com.mkt.agent.common.valid.EnumValid;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

/**
 * @ClassName CommissionPlanQueryReq
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
public class TAgentContractQueryReq extends BasePageRequest {


    @ApiModelProperty(value = "ID")
    private Long id;


    @ApiModelProperty(value = "佣金计划名称")
    private String commissionPlanName;

    /*
       0:turnover, 1:GGR
   */
    @ApiModelProperty(value = "佣金计划类型{ALL,TURNOVER,GGR}")
    @EnumValid(contents = CustomizedValidationContents.commission_plan_type_values)
    private String commissionPlanType;

    /*
       MONTH,ONE-THIRD_MONTH,WEEK,DAY
    */
    @ApiModelProperty(value = "结算周期{ALL,MONTH,ONE-THIRD_MONTH,WEEK,DAY}")
    @EnumValid(contents = CustomizedValidationContents.settlement_period_values)
    private String settlementPeriod;


    /*
       MONTH,ONE-THIRD_MONTH,WEEK,DAY
    */
    @ApiModelProperty(value = "创建者")
    private String createBy;


    @ApiModelProperty(value = "开始时间")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date startTime;

    @ApiModelProperty(value = "结束时间")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date endTime;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCommissionPlanName() {
        return commissionPlanName;
    }

    public void setCommissionPlanName(String commissionPlanName) {
        this.commissionPlanName = commissionPlanName;
    }

    public String getCommissionPlanType() {
        return commissionPlanType;
    }

    public void setCommissionPlanType(String commissionPlanType) {
        this.commissionPlanType = commissionPlanType;
    }

    public String getSettlementPeriod() {
        return settlementPeriod;
    }

    public void setSettlementPeriod(String settlementPeriod) {
        this.settlementPeriod = settlementPeriod;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    @Override
    public Integer getPageNum() {
        return pageNum;
    }

    @Override
    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    @Override
    public Integer getPageSize() {
        return pageSize;
    }

    @Override
    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }


    public TAgentContractQueryReq() {
        pageNum = null;
        pageSize =null;
    }

    @Override
    public String toString() {
        return "TAgentContractQueryReq{" +
                "pageNum=" + pageNum +
                ", pageSize=" + pageSize +
                ", id=" + id +
                ", commissionPlanName='" + commissionPlanName + '\'' +
                ", commissionPlanType='" + commissionPlanType + '\'' +
                ", settlementPeriod='" + settlementPeriod + '\'' +
                ", createBy='" + createBy + '\'' +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                '}';
    }
}
