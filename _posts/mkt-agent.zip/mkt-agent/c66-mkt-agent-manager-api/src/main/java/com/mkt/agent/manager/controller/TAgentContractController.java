package com.mkt.agent.manager.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentContractReq;
import com.mkt.agent.common.entity.api.agentapi.responses.TAgentContractDictionaryResp;
import com.mkt.agent.common.entity.api.agentapi.responses.TAgentContractResp;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.valid.InputValidationGroup;
import com.mkt.agent.manager.entities.request.TAgentContractQueryReq;
import com.mkt.agent.manager.feign.AgentApiClient;
import com.mkt.agent.manager.utils.FeignClientHelper;
import feign.Response;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.List;


/**
 * @ClassName TAgentContractController
 * @Description 佣金方案
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@RestController
@RequestMapping("/manager/agent/contract")
@Validated
public class TAgentContractController {


    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private AgentApiClient agentApiClient;

    @PostMapping(value = "/create")
    @ApiOperation(value = "创建佣金方案", notes = "创建佣金方案")
    public Result create(@Validated @RequestBody TAgentContractReq tAgentContractReq) {
        try {
            logger.info("/manager/agent/contract/create 入参tAgentContractReq：{} 返回值：void", tAgentContractReq.toString());
            return agentApiClient.create(tAgentContractReq);
        } catch (Exception e) {
            logger.error("/manager/agent/contract/create 出异常了，入参tAgentContractReq：{} 异常信息：{}", tAgentContractReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping(value = "/queryList")
    @ApiOperation(value = "查询佣金方案", notes = "查询佣金方案")
    public Result<Page<TAgentContractResp>> queryList(@RequestBody @Validated TAgentContractQueryReq tAgentContractQueryReq) {
        try {
            //后台查询数据
            Page<TAgentContractResp> resp = agentApiClient.queryList(tAgentContractQueryReq).getData();
            logger.info("/manager/agent/contract/queryList 入参tAgentContractQueryReq：{} 返回值：{}", tAgentContractQueryReq.toString(), resp);
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/manager/agent/contract/queryList 出异常了，入参tAgentContractQueryReq：{} 异常信息：{}",
                    tAgentContractQueryReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @GetMapping(value = "/delete")
    @ApiOperation(value = "逻辑删除佣金方案", notes = "逻辑删除佣金方案")
    public Result delete(@NotNull(message = "id is not null") Long id) {
        try {
            logger.info("/manager/agent/contract/delete 入参id：{} 返回值：void", id);
            return agentApiClient.delete(id);
        } catch (Exception e) {
            logger.error("/manager/agent/contract/delete 出异常了，入参id：{} 异常信息：{}", id, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping(value = "/update")
    @ApiOperation(value = "编辑佣金方案", notes = "编辑佣金方案")
    public Result update(@RequestBody @Validated(value = InputValidationGroup.Update.class) TAgentContractReq tAgentContractReq) {
        try {
            logger.info("/manager/agent/contract/update 入参tAgentContractReq：{} 返回值：void", tAgentContractReq.toString());
            return agentApiClient.update(tAgentContractReq);
        } catch (Exception e) {
            logger.error("/manager/agent/contract/update 出异常了，入参tAgentContractReq：{} 异常信息：{}", tAgentContractReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @GetMapping(value = "/queryNameList")
    @ApiOperation(value = "佣金方案下拉框", notes = "佣金方案下拉框")
    public Result<List<TAgentContractDictionaryResp>> queryNameList(@NotBlank(message = "contract name is not null") String contractName) {
        try {
            List<TAgentContractDictionaryResp> resp = agentApiClient.queryNameList(contractName).getData();
            logger.info("/manager/agent/contract/queryNameList 入参contractName：{} 返回值：{}", contractName, resp);
            return Result.success(resp);
        } catch (Exception e) {
            logger.error("/manager/agent/contract/queryNameList 出异常了，入参contractName：{} 异常信息：{}", contractName, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @PostMapping(value = "/export")
    @ApiOperation(value = "佣金方案导出", notes = "佣金方案导出")
    public Result export(@RequestBody @Validated TAgentContractQueryReq tAgentContractQueryReq, HttpServletResponse httpServletResponse) {
        try {
            logger.info("/manager/agent/contract/export 入参tAgentContractQueryReq：{} 返回值：void", tAgentContractQueryReq.toString());
            Response response = agentApiClient.export(tAgentContractQueryReq);
            FeignClientHelper.export(response, httpServletResponse);
            return Result.success(ResultEnum.SUCCESS);
        } catch (IOException e) {
            logger.error("/manager/agent/contract/export 出异常了，入参tAgentContractQueryReq：{} 异常信息：{}", tAgentContractQueryReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(ResultEnum.CONTRACT_EXPORT_FAIL);
        }

    }
}



