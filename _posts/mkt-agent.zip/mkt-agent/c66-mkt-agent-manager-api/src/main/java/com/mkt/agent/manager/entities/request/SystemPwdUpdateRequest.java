package com.mkt.agent.manager.entities.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.NotNull;

/**
 * @Description: 更新密码请求dto
 * @Author: PTMinnisLi
 * @Date: 2023/6/6
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "更新密码请求dto", description = "更新密码请求实体类(修改自己的密码)")
@ToString(exclude = {"oldPassword", "newPassword"})
public class SystemPwdUpdateRequest {

    @ApiModelProperty(value = "id", hidden = true)
    private Long id;

    @ApiModelProperty(value = "旧密码", required = true)
    @NotNull(message = "oldPassword is required!")
    private String oldPassword;

    @ApiModelProperty(value = "新密码", required = true)
    @NotNull(message = "newPassword is required!")
    private String newPassword;

}
