package com.mkt.agent.manager.entities;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.entity.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("t_group_resource")
public class GroupResource extends BaseEntity {

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long resourceId;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long groupId;
}
