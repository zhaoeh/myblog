package com.mkt.agent.manager.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mkt.agent.manager.entities.GroupResource;

public interface GroupResourceService extends IService<GroupResource> {
    int deleteByGroupId(Long userGroupId);

    Long countByGroupId(Long userGroupId);
}
