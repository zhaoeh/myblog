package com.mkt.agent.manager.service;

import com.mkt.agent.manager.entities.request.LoginUserRequest;
import com.mkt.agent.manager.entities.response.LoginUserResponse;

import javax.servlet.http.HttpServletRequest;

public interface SystemService {

    LoginUserResponse login(LoginUserRequest loginUser, HttpServletRequest request);

    void logout(String token);

    LoginUserResponse refreshToken(String refreshToken);

    void removeFrontEndTokenByCustomersId(Long customersId);

}
