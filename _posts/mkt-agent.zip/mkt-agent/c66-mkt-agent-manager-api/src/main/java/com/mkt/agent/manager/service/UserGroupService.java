package com.mkt.agent.manager.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.core.BaseService;
import com.mkt.agent.manager.entities.UserGroup;
import com.mkt.agent.manager.entities.request.*;
import com.mkt.agent.manager.entities.response.UserGroupResponse;

import java.util.List;

public interface UserGroupService extends BaseService<UserGroup> {

    void createUserGroup(UserGroupCreateRequest userGroup);

    void enableUserGroup(UserGroupEnableRequest request);

    void editUserGroup(UserGroupUpdateRequest userGroup);

    Page<UserGroupResponse> getUserGroupList(UserGroupQueryRequest request);

    void setUserGroupMenu(UserGroupMenuRequest request);

    void removeUserGroup(Long id);

    List<UserGroup> getAllUserGroupInfo();

}
