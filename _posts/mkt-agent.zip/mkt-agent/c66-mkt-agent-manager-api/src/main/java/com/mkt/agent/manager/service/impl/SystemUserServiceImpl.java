package com.mkt.agent.manager.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.config.SystemConfig;
import com.mkt.agent.common.core.BaseServiceImpl;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.AesEncode;
import com.mkt.agent.common.utils.BeanCopyUtil;
import com.mkt.agent.manager.entities.SystemUser;
import com.mkt.agent.manager.entities.request.*;
import com.mkt.agent.manager.entities.response.SystemUserResponse;
import com.mkt.agent.manager.exception.MKTManagerException;
import com.mkt.agent.manager.mapper.SystemUserMapper;
import com.mkt.agent.manager.service.SystemUserService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
@Slf4j
@RefreshScope
public class SystemUserServiceImpl extends BaseServiceImpl<SystemUserMapper, SystemUser> implements SystemUserService {

    @Autowired
    private SystemUserMapper systemUserMapper;

    @Resource
    private SystemConfig systemConfig;

    @Value("${user.pwd.defult.C66}")
    private String defaultC66Pwd;

    @Override
    public SystemUserResponse getUserDetailByUserId(Long userId) {
        return systemUserMapper.selectDetailByUserId(userId);
    }

    /**
     * 创建用户
     *
     * @param createRequest 用户创建实体类
     * @return 登录用户实体类
     */
    @Override
    public SystemUser createUser(SystemUserCreateRequest createRequest) {
        log.info("SystemUserServiceImpl_createuser params:{}",createRequest.toString());
        SystemUser systemUser = new SystemUser();
        Long nameCount = systemUserMapper.selectCount(buildWrapper(createRequest));
        if (nameCount != 0L) {
            throw new MKTManagerException(ResultEnum.SYSTEM_USER_NAME_EXIST);
        }
        BeanUtils.copyProperties(createRequest, systemUser);
        systemUser.setPwd(DigestUtils.md5Hex(createRequest.getPassword()));
        systemUser.setProductId(systemConfig.getProductId());
        log.info("SystemUser params:{}",systemUser.toString());
        int insert = systemUserMapper.insert(systemUser);
        if (insert == 0) {
            throw new MKTManagerException(ResultEnum.SYSTEM_USER_CREATE_FAIL);
        }
        return systemUser;
    }

    /**
     * 启用/禁用用户
     *
     * @param request 用户启用禁用请求类
     */
    @Override
    public void enableUser(SystemUserEnableRequest request) {
        SystemUser systemUser = new SystemUser();
        BeanUtils.copyProperties(request, systemUser);
        int update = systemUserMapper.updateById(systemUser);
        if (update == 0) {
            throw new MKTManagerException(ResultEnum.SYSTEM_USER_ENABLE_FAIL);
        }
    }

    /**
     * 更新用户
     *
     * @param request 用户更新请求实体类
     */
    @Override
    public void editUser(SystemUserUpdateRequest request) {
        if (StringUtils.isNotBlank(request.getLoginName())) {
            Long loginNameCount = systemUserMapper.selectCount(buildWrapper(request));
            if (loginNameCount != 0) {
                throw new MKTManagerException(ResultEnum.SYSTEM_USER_NAME_EXIST);
            }
        }

        SystemUser systemUser = new SystemUser();
        BeanCopyUtil.copyNotEmptyProperties(request, systemUser);
        if (StringUtils.isNotEmpty(request.getPassword())) {
            String desEncryptPwd = AesEncode.desEncrypt(request.getPassword());
            String password = DigestUtils.md5Hex(desEncryptPwd);
            systemUser.setPwd(password);
        }
        int update = systemUserMapper.updateById(systemUser);
        if (update == 0) {
            throw new MKTManagerException(ResultEnum.SYSTEM_USER_UPDATE_FAIL);
        }
    }

    /**
     * 删除用户(逻辑删除)
     *
     * @param userId userId
     */
    @Override
    public void deleteUser(Long userId) {
        if (userId == 1) {
            throw new MKTManagerException(ResultEnum.SYSTEM_USER_DELETE_FAIL);
        }
        int delete = systemUserMapper.deleteById(userId);
        if (delete == 0) {
            throw new MKTManagerException(ResultEnum.SYSTEM_USER_DELETE_FAIL);
        }
    }

    /**
     * 获取用户列表(分页查询)
     *
     * @param systemUserReq 用户查询实体类
     * @return 用户分页结果
     */
    @Override
    public Page<SystemUser> getSystemUserList(SystemUserQueryRequest systemUserReq) {
        // 过滤掉admin
        systemUserReq.setId(1L);
        systemUserReq.setSortName(StringUtils.isNotBlank(systemUserReq.getSortName())?systemUserReq.getSortName():"createTime");
        systemUserReq.setIsAsc(null==systemUserReq.getIsAsc()?false:systemUserReq.getIsAsc());
        return page(systemUserReq);
    }

    /**
     * 修改密码
     *
     * @param request 更新密码请求dto
     */
    @Override
    public void setPassword(SystemUserPwdUpdateRequest request) {

        // 校验新旧密码
        if (request.getNewPassword().equals(request.getOldPassword())) {
            throw new MKTManagerException(ResultEnum.SYSTEM_USER_PASSWORD_SAME_ERROR);
        }

        // 校验旧密码是否正确
        SystemUser systemUser = systemUserMapper.selectById(request.getId());
        String oldPassword = DigestUtils.md5Hex(AesEncode.desEncrypt(request.getOldPassword()));
        String newPassword = DigestUtils.md5Hex(AesEncode.desEncrypt(request.getNewPassword()));
        if (!oldPassword.equals(systemUser.getPwd())) {
            throw new MKTManagerException(ResultEnum.SYSTEM_USER_OLD_PASSWORD_ERROR);
        }
        systemUser.setPwd(newPassword);
        int update = systemUserMapper.updateById(systemUser);
        if (update == 0) {
            throw new MKTManagerException(ResultEnum.SYSTEM_USER_PASSWORD_UPDATE_FAIL);
        }
    }

    @Override
    public Long countByGroupId(Long id) {
        return systemUserMapper.countByGroupId(id);
    }
}
