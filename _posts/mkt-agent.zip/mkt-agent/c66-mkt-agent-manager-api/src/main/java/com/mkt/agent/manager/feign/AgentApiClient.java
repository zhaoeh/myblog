package com.mkt.agent.manager.feign;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.entity.BatchRecord;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.SumPageResponse;
import com.mkt.agent.common.entity.api.agentapi.requests.BatchQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentContractReq;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentCustomersBatchReq;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentCustomersRemarkReq;
import com.mkt.agent.common.entity.api.agentapi.responses.BatchQueryResp;
import com.mkt.agent.common.entity.api.agentapi.responses.TAgentContractDictionaryResp;
import com.mkt.agent.common.entity.api.fund.req.FundRecordReq;
import com.mkt.agent.common.entity.api.fund.resp.FundRecordResp;
import com.mkt.agent.manager.entities.request.TAgentContractQueryReq;
import com.mkt.agent.manager.entities.request.TAgentCustomersQueryReq;
import com.mkt.agent.manager.entities.request.TAgentCustomersReq;
import com.mkt.agent.manager.entities.response.TAgentContractResp;
import com.mkt.agent.manager.entities.response.TAgentCustomersResp;
import feign.Response;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * @interfaceName: AgentApiClient
 * @Description:
 * @Author: Austin
 * @Date: 2023/5/30
 */
//@FeignClient(name = "${feign.mkt-agent-api}",url = "127.0.0.1:18080")
@FeignClient(name = "${feign.mkt-agent-api}")
public interface AgentApiClient {

    @PostMapping("/agentContract/create")
    public Result create(@RequestBody TAgentContractReq TAgentContractReq);

    @PostMapping("/agentContract/queryList")
    public Result<Page<TAgentContractResp>> queryList(@RequestBody TAgentContractQueryReq tAgentContractQueryReq);

    @GetMapping("/agentContract/delete")
    public Result delete(@RequestParam("id") Long id);

    @PostMapping("/agentContract/update")
    public Result update(@RequestBody TAgentContractReq tAgentContractReq);

    @PostMapping("/fund/list")
    Result<SumPageResponse<FundRecordResp>> list(@RequestBody FundRecordReq req);

    @PostMapping(value = "/fund/export", consumes = MediaType.APPLICATION_PROBLEM_JSON_VALUE)
    Response export(@RequestBody FundRecordReq req);

    @GetMapping("/agentContract/queryNameList")
    public Result<List<TAgentContractDictionaryResp>> queryNameList(@RequestParam("contractName") String contractName);

    @PostMapping(value = "/agentContract/export", consumes = MediaType.APPLICATION_PROBLEM_JSON_VALUE)
    public Response export(@RequestBody TAgentContractQueryReq tAgentContractQueryReq);

    @PostMapping("/agentCustomers/create")
    public Result create(@RequestBody TAgentCustomersReq tAgentCustomersReq);

    @PostMapping("/agentCustomers/createTopAgentByBatch")
    Result createUserByBatch(@RequestBody TAgentCustomersBatchReq tAgentCustomersBatchReq);

    @PostMapping(value = "/agentCustomers/getTopAgentBatch")
    Result<Page<BatchQueryResp>> getTopAgentBatch(BatchQueryRequest batchQueryRequest);

    @PostMapping("/agentCustomers/queryAllAgent")
    public Result<Page<TAgentCustomersResp>> queryAllAgent(TAgentCustomersQueryReq tAgentCustomersQueryReq);

    @PostMapping("/agentCustomers/checkAgentIsTop")
    public Result checkAgentIsTop(TAgentCustomersQueryReq tAgentCustomersQueryReq);

    @PostMapping("/agentCustomers/update")
    public Result update(@RequestBody TAgentCustomersReq tAgentCustomersReq);

    @PostMapping(value = "/agentCustomers/export", consumes = MediaType.APPLICATION_PROBLEM_JSON_VALUE)
    Result<List<TAgentCustomersResp>> export(@RequestBody TAgentCustomersQueryReq req);

    @GetMapping(value = "/agentCustomers/cancelAgent")
    public Result cancelAgent(@RequestParam("customersId") Long customersId);

    @PostMapping(value = "/agentCustomers/updateAgentRemark")
    public Result updateAgentRemark(@RequestBody TAgentCustomersRemarkReq tAgentCustomersRemarkReq);

    @PostMapping(value = "/agentCustomers/userToAgent")
    public Result userToAgent(@RequestBody TAgentCustomersReq tAgentCustomersReq);


    @GetMapping(value = "/agent/migration")
    public Result migration();

    @GetMapping(value = "/player/batch-records")
    Result<List<BatchRecord>> batchRecordList(@RequestParam("batchId") String id);
}
