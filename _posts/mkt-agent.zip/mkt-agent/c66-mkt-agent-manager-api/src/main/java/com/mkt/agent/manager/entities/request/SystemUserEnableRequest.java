package com.mkt.agent.manager.entities.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "用户启用禁用请求类")
public class SystemUserEnableRequest {

    @ApiModelProperty(value = "用户ID",required = true)
    @NotNull(message = "用户ID不允许为空!")
    private Long id;

    @ApiModelProperty(value = "启用/禁用用户,启用:1/禁用0(Activition)",required = true)
    @Max(value = 1, message = "状态不允许为空!")
    @Min(value = 0, message = "状态不允许为空!")
    @NotNull(message = "状态不允许为空!")
    private Integer isEnable;
}
