package com.mkt.agent.manager.controller;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.manager.feign.AgentApiClient;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Description: 数据迁移controller
 * @Author: PTMinnisLi
 * @Date: 2023/6/30
 */
@Slf4j
@RestController
@RequestMapping("/agent")
public class MigrationController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private AgentApiClient agentApiClient;

    @GetMapping("/migration")
    public Result migration() {
        try {
            logger.info("/agent/migration 入参：void 返回值：void");
            agentApiClient.migration();
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/agent/migration 出异常了，入参：void 异常信息：{}", e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }
}
