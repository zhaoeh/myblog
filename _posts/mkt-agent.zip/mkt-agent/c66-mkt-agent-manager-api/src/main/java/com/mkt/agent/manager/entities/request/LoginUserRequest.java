package com.mkt.agent.manager.entities.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "用户登录")
public class LoginUserRequest {

    @ApiModelProperty(value = "产品ID", hidden = true)
    private String productId;

    @ApiModelProperty(value = "登录名", required = true)
    @NotBlank(message = "登录名不允许为空!")
    private String loginName;

    @NotBlank(message = "密码不允许为空!")
    @ApiModelProperty(value = "密码", required = true)
    private String pwd;

    @ApiModelProperty(value = "校验码", hidden = true)
    private String verificationCode;

    @ApiModelProperty(value = "IP", hidden = true)
    private String ip;

    @ApiModelProperty(value = "URL", hidden = true)
    private String url;

    @ApiModelProperty(value = "域名", hidden = true)
    private String domainName;

    @ApiModelProperty(value = "请求ID", hidden = true)
    private String requestId;
}
