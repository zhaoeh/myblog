package com.mkt.agent.manager.entities.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "角色编辑请求类")
public class UserGroupUpdateRequest {

    @ApiModelProperty(value = "id", required = true)
    @NotNull(message = "角色ID不允许为空!")
    private Long id;

    @ApiModelProperty(value = "启用标识：是否启用，0禁用/1启用(Activition)", required = true)
    @Max(value = 1, message = "状态不允许为空!")
    @Min(value = 0, message = "状态不允许为空!")
    @NotNull(message = "状态不允许为空!")
    private Integer isEnable;

    @ApiModelProperty(value = "角色名称(Role Name)", required = true)
    @NotBlank(message = "角色名称不允许为空!")
    private String groupName;

    @ApiModelProperty(value = "角色描述(Description)", required = true)
    private String groupDescription;

    @ApiModelProperty(value = "备注")
    private String remarks;

    @ApiModelProperty(value = "菜单id列表[不更新则不传该属性，更新为空则传空数组，正常更新传非空数组](Permission)")
    private List<Long> resourceIds;
}
