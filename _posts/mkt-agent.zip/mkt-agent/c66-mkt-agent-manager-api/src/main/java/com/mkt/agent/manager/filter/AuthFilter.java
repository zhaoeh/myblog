package com.mkt.agent.manager.filter;

import com.mkt.agent.common.constants.AuthConstants;
import com.mkt.agent.common.entity.system.LoginUserInfo;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.UserContext;
import com.mkt.agent.manager.config.ManagerAuthProperties;
import com.mkt.agent.manager.entities.ResourceComponent;
import com.mkt.agent.manager.entities.response.SystemUserResponse;
import com.mkt.agent.manager.service.ResourceComponentService;
import com.mkt.agent.manager.service.SystemUserService;
import com.mkt.agent.manager.utils.JwtTokenUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Order(1)
@Component
public class AuthFilter implements Filter {

    @Resource
    private JwtTokenUtil jwtTokenUtil;

    @Resource
    private ManagerAuthProperties authJwtProperties;

    @Autowired
    private ResourceComponentService resourceComponentService;

    @Autowired
    private SystemUserService systemUserService;

    private static final String SWAGGER_API = "/webjars";

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain) throws IOException, ServletException {
        // 1 对URL进行校验
        //1.1 获取请求和api
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        //1.2 获取响应
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        String requestAPI = request.getRequestURI();
        //1.3 如果是白名单请求则放行
        if (authJwtProperties.getWhitelist().contains(requestAPI) || requestAPI.startsWith(SWAGGER_API)) {
            chain.doFilter(request, response);
            return;
        }

        // 2 对token进行校验
        // 请求头中获取令牌
        String token = request.getHeader(AuthConstants.AUTH_HEADER);
        // 判断请求头中是否有令牌，非白名单请求必须包含token
        if (StringUtils.isEmpty(token)) {
            // 响应中放入返回的状态吗, 没有权限访问
            response.sendError(ResultEnum.FORBIDDEN.getCode());
            return;
        }

        // 3 解析token,并对权限进行校验
        //3.1 解析token
        String userId = jwtTokenUtil.getUserIdFromToken(token);
        String username = jwtTokenUtil.getUserNameFromToken(token);

        if (StringUtils.isEmpty(userId)) {
            // userId为空,说明解析jwt令牌出错,令牌过期或者伪造等不合法情况出现
            response.sendError(ResultEnum.UNAUTHORIZED.getCode());
            return;
        }
        // 3.2 token是否过期，过期则直接返回response，要求客户端拿refresh_token去访问token刷新接口
        Boolean tokenExpired = jwtTokenUtil.isTokenExpired(token);
        if (tokenExpired) {
            response.sendError(ResultEnum.UNAUTHORIZED.getCode());
            return;
        }
        // 3.3 解析后拿到userId,根据userId去redis取出token并校验
        String tokenFromCache = jwtTokenUtil.getTokenByUserIdFromCache(userId);
        Boolean tokenValidate = jwtTokenUtil.validateToken(tokenFromCache, userId);
        if (!tokenValidate) {
            // token无效则返回未授权
            response.sendError(ResultEnum.UNAUTHORIZED.getCode());
            return;
        }

        // 3.4 获取当前用户所有权限
        SystemUserResponse systemUser = systemUserService.getUserDetailByUserId(Long.valueOf(userId));
        List<ResourceComponent> resources = resourceComponentService.getResourcesByGroupId(systemUser.getUserGroupId());
        List<String> urls = resources.stream().map(ResourceComponent::getUrl).collect(Collectors.toList());
        if (urls.contains(requestAPI)) {
            // 3.5 1若当前用户权限list中包含当前请求接口则放行，并将userId/username写入threadlocal
            LoginUserInfo loginUserInfo = new LoginUserInfo();
            loginUserInfo.setUserId(userId);
            loginUserInfo.setUsername(username);
            loginUserInfo.setUserType(systemUser.getUserGroupName());
            UserContext.setContext(loginUserInfo);

            chain.doFilter(request, response);
            // 使用结束后清理RequestHolder
            UserContext.clear();
            return;
        }
        // 3.5.2否则该token无效，无权访问
        response.sendError(ResultEnum.FORBIDDEN.getCode());
    }
}
