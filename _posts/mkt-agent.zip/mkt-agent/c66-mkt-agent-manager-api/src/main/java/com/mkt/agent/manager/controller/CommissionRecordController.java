package com.mkt.agent.manager.controller;


import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordResetRequest;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordUpdateRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordPlanResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordSingleResponse;
import com.mkt.agent.common.utils.UserContext;
import com.mkt.agent.manager.feign.CommissionApiClient;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/commissionRecord")
@Api(tags = "commission_record API")
@Slf4j
public class CommissionRecordController {

    @Autowired
    private CommissionApiClient commissionApiClient;


    @PostMapping("/queryByCommissionRecordId")
    @ApiOperation("query commission records by commission id")
    public Result<CommissionRecordSingleResponse> queryByCommissionRecordId(@RequestParam("id") Long commissionRecordId) {

        log.info("commission_record_detail query param :{}", commissionRecordId);
        Result<CommissionRecordSingleResponse> data = commissionApiClient.queryByCommissionRecordId(commissionRecordId);
        log.info("commission_record_detail query result :{}", data);
        return data;
    }

    @PostMapping("/queryCommissionPlanByCommissionRecordId")
    @ApiOperation("query commission plan by commission id")
    public Result<CommissionRecordPlanResponse> queryCommissionPlanByCommissionRecordId(@RequestParam("id") Long commissionRecordId) {

        log.info("commission_record_plan query param :{}", commissionRecordId);
        Result<CommissionRecordPlanResponse> data = commissionApiClient.queryCommissionPlanByCommissionRecordId(commissionRecordId);
        log.info("commission_record_plan query result :{}", data);
        return data;
    }

    @PostMapping("/commissionRecordFirstApproveById")
    @ApiOperation("commissionRecordFirstApproveById")
    public Result<Boolean> commissionRecordFirstApproveById(@RequestBody @Valid CommissionRecordUpdateRequest req) {

        String username = UserContext.getUsername();
        req.setAgentAccount(username);
        log.info("commissionRecordFirstApproveById param :{}", req);
        Result<Boolean> data = commissionApiClient.commissionRecordFirstApproveById(req);
        log.info("commissionRecordFirstApproveById result :{}", data);
        return data;
    }


    @PostMapping("/commissionRecordSecondApproveById")
    @ApiOperation("commissionRecordSecondApproveById")
    public Result<Boolean> commissionRecordSecondApproveById(@RequestBody @Valid CommissionRecordUpdateRequest req) {

        String username = UserContext.getUsername();
        req.setAgentAccount(username);
        log.info("commissionRecordSecondApproveById param :{}", req);
        Result<Boolean> data = commissionApiClient.commissionRecordSecondApproveById(req);
        log.info("commissionRecordSecondApproveById result :{}", data);
        return data;
    }

    @PostMapping("/commissionRecordSecondPayById")
    @ApiOperation("commissionRecordSecondPayById")
    public Result<Boolean> commissionRecordSecondPayById(@RequestBody @Valid CommissionRecordUpdateRequest req) {

        String username = UserContext.getUsername();
        req.setAgentAccount(username);
        log.info("commissionRecordSecondPayById param :{}", req);
        Result<Boolean> data = commissionApiClient.commissionRecordSecondPayById(req);
        log.info("commissionRecordSecondPayById result :{}", data);
        return data;
    }

    @PostMapping("/commissionRecordSecondResetById")
    @ApiOperation("commissionRecordSecondResetById")
    public Result<Boolean> commissionRecordSecondResetById(@RequestBody @Valid CommissionRecordResetRequest req) {
        String username = UserContext.getUsername();
        req.setAgentAccount(username);
        log.info("commissionRecordSecondResetById param :{}", req);
        Result<Boolean> data = commissionApiClient.commissionRecordSecondResetById(req);
        log.info("commissionRecordSecondResetById result :{}", data);
        return data;
    }


}
