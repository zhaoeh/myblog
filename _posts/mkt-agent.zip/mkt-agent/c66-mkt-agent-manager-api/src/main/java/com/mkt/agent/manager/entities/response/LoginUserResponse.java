package com.mkt.agent.manager.entities.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "登录响应实体类")
public class LoginUserResponse {

    @ApiModelProperty("token")
    private String accessToken;

    @ApiModelProperty("刷新用token")
    private String refreshToken;
}
