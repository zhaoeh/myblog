package com.mkt.agent.manager.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.manager.entities.GroupResource;
import com.mkt.agent.manager.entities.ResourceComponent;
import com.mkt.agent.manager.entities.SystemUser;
import com.mkt.agent.manager.entities.request.ResourceComponentCreateRequest;
import com.mkt.agent.manager.entities.request.ResourceComponentEnableRequest;
import com.mkt.agent.manager.entities.request.ResourceComponentUpdateRequest;
import com.mkt.agent.manager.entities.response.ResourceComponentTreeResponse;
import com.mkt.agent.manager.exception.MKTManagerException;
import com.mkt.agent.manager.mapper.ResourceComponentMapper;
import com.mkt.agent.manager.service.GroupResourceService;
import com.mkt.agent.manager.service.ResourceComponentService;
import com.mkt.agent.manager.service.SystemUserService;
import com.mkt.agent.manager.utils.TreeUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ResourceComponentServiceImpl extends ServiceImpl<ResourceComponentMapper, ResourceComponent> implements ResourceComponentService {

    @Autowired
    private ResourceComponentMapper resourceComponentMapper;

    @Autowired
    private SystemUserService systemUserService;

    @Autowired
    private GroupResourceService groupResourceService;

    @Override
    public List<ResourceComponent> getResourcesByGroupId(Long groupId) {
        return resourceComponentMapper.listByUserGroupIdAndEnable(groupId);
    }

    /**
     * 获取角色可查询的菜单(树)
     *
     * @param userId 角色Id
     * @return 菜单(树)
     */
    @Override
    public List<ResourceComponentTreeResponse> getResourcesTreeByUserId(Long userId) {
        SystemUser systemUser = systemUserService.getById(userId);
        return getResourcesTreeByGroupId(systemUser.getUserGroupId(), false, null);
    }

    /**
     * 获取角色可查询的菜单(树)
     *
     * @param userGroupId 角色Id
     * @param needCheck   是否需要确认勾选状态
     * @param userId      当前登录角色id
     * @return 菜单(树)
     */
    @Override
    public List<ResourceComponentTreeResponse> getResourcesTreeByGroupId(Long userGroupId, Boolean needCheck, Long userId) {

        // 获取所有资源(当前所选角色)
        List<ResourceComponent> targetResources = getResourcesByGroupId(userGroupId);
        // 如果需要确认勾选状态，则以当前角色菜单为全部菜单进行比较
        if (needCheck) {
            List<Long> targetIdList = targetResources.stream().map(ResourceComponent::getId).collect(Collectors.toList());
            // 获取所有资源(当前登录角色)
            SystemUser curUser = systemUserService.getById(userId);
            List<ResourceComponent> allResources = getResourcesByGroupId(curUser.getUserGroupId());
            List<ResourceComponentTreeResponse> allResourceTree = new ArrayList<>();
            allResources.forEach(resource -> {
                var response = new ResourceComponentTreeResponse();
                BeanUtils.copyProperties(resource, response);
                allResourceTree.add(response);
            });
            // 遍历当前登录角色的每个菜单，如果当前所选角色有此权限，则设为勾选isChecked状态
            for (ResourceComponentTreeResponse resourceComponent : allResourceTree) {
                if (targetIdList.contains(resourceComponent.getId())) {
                    resourceComponent.setIsChecked(true);
                }
            }
            // 改为树结构
            return TreeUtils.constructToTree(allResourceTree);
        }
        // 否则，则为查询指定角色的所有菜单，不确认勾选情况
        List<ResourceComponentTreeResponse> targetResourceTree = new ArrayList<>();
        targetResources.forEach(resource -> {
            var response = new ResourceComponentTreeResponse();
            BeanUtils.copyProperties(resource, response);
            targetResourceTree.add(response);
        });
        // 改为树结构
        return TreeUtils.constructToTree(targetResourceTree);
    }

    /**
     * 菜单创建
     *
     * @param request 菜单创建请求实体类
     */
    @Override
    public void createUserGroup(ResourceComponentCreateRequest request) {
        // 三级菜单不允许创建子菜单
        ResourceComponent parentResource = resourceComponentMapper.selectById(request.getPid());
        if (parentResource.getLevel() == 3) {
            throw new MKTManagerException(ResultEnum.RESOURCE_CREATED_NOT_ALLOWED);
        }
        List<ResourceComponent> resources = resourceComponentMapper.selectList(Wrappers.emptyWrapper());
        // 标识名称不允许重复
        List<String> bsName = resources.stream().map(ResourceComponent::getBsName).collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(bsName) && bsName.contains(request.getBsName())) {
            throw new MKTManagerException(ResultEnum.RESOURCE_BS_NAME_EXIST);
        }
        // 菜单URL不允许重复
        List<String> urls = resources.stream().map(ResourceComponent::getUrl).collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(urls) && urls.contains(request.getUrl())) {
            throw new MKTManagerException(ResultEnum.RESOURCE_URL_EXIST);
        }
        // 同一个父目录下的子节点名称不允许重复
        List<String> nameList = resources.stream()
                .filter(r -> request.getPid().equals(r.getPid()))
                .map(ResourceComponent::getName).collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(nameList) && nameList.contains(request.getName())) {
            throw new MKTManagerException(ResultEnum.RESOURCE_NAME_EXIST);
        }
        // 设置节点顺序
        int xh = CollectionUtils.isEmpty(nameList) ? 1 : nameList.size() + 1;
        ResourceComponent resourceComponent = new ResourceComponent();
        BeanUtils.copyProperties(request, resourceComponent);
        resourceComponent.setIsEnable(1);
        resourceComponent.setXh(xh);
        resourceComponent.setLevel(parentResource.getLevel() + 1);

        // 新建菜单
        int result = resourceComponentMapper.insert(resourceComponent);
        if (result == 0) {
            throw new MKTManagerException(ResultEnum.RESOURCE_CREATED_FAIL);
        }
        // 为超级管理员默认添加菜单权限
        GroupResource groupResource = new GroupResource();
        groupResource.setResourceId(resourceComponent.getId());
        groupResource.setGroupId(1L);
        groupResourceService.save(groupResource);
    }

    /**
     * 菜单启用禁用
     *
     * @param request 菜单启用禁用请求类
     */
    @Override
    public void enableResourceComponent(ResourceComponentEnableRequest request) {
        ResourceComponent resourceComponent = new ResourceComponent();
        BeanUtils.copyProperties(request, resourceComponent);
        int update = resourceComponentMapper.updateById(resourceComponent);
        if (update == 0) {
            throw new MKTManagerException(ResultEnum.RESOURCE_ENABLE_FAIL);
        }
    }

    /**
     * 菜单更新
     *
     * @param request 菜单更新请求实体类
     */
    @Override
    public void modifyName(ResourceComponentUpdateRequest request) {
        ResourceComponent resourceComponent = new ResourceComponent();
        BeanUtils.copyProperties(request, resourceComponent);
        int update = resourceComponentMapper.updateById(resourceComponent);
        if (update == 0) {
            throw new MKTManagerException(ResultEnum.RESOURCE_UPDATE_FAIL);
        }
    }

    /**
     * 菜单上移/下移
     *
     * @param id   菜单id
     * @param isUp 是否是上移 true:上移/false:下移
     */
    @Override
    public void moveUpOrDown(Long id, boolean isUp) {
        // 先获取当前菜单
        ResourceComponent curNode = resourceComponentMapper.selectById(id);
        Integer xh = curNode.getXh();
        if (curNode.getPid() == null || xh <= 1) {
            throw new MKTManagerException(ResultEnum.RESOURCE_MOVE_FAIL);
        }
        ResourceComponent otherNode;
        if (isUp) {
            // 上移
            // 获取需要交换位置的目标菜单
            otherNode = resourceComponentMapper.selectByPidAndXh(curNode.getPid(), xh - 1);
            if (otherNode == null) {
                throw new MKTManagerException(ResultEnum.RESOURCE_MOVE_FAIL);
            }
            curNode.setXh(xh - 1);
        } else {
            // 下移
            // 获取需要交换位置的目标菜单
            otherNode = resourceComponentMapper.selectByPidAndXh(curNode.getPid(), xh + 1);
            if (otherNode == null) {
                throw new MKTManagerException(ResultEnum.RESOURCE_MOVE_FAIL);
            }
            curNode.setXh(xh + 1);
        }
        otherNode.setXh(xh);
        List<ResourceComponent> updateList = Arrays.asList(curNode, otherNode);
        // 批量更新,更新失败返回异常
        boolean b = saveOrUpdateBatch(updateList);
        if (!b) {
            throw new MKTManagerException(ResultEnum.RESOURCE_MOVE_FAIL);
        }

    }

    @Override
    public List<ResourceComponent> getResourcesByParentId(Long parentId) {
        return resourceComponentMapper.listByPid(parentId);
    }
}
