package com.mkt.agent.manager.entities.response;

import com.mkt.agent.manager.entities.UserGroup;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Description: 获取单个角色的response
 * @Author: PTMinnisLi
 * @Date: 2023/6/12
 */
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "获取单个角色响应实体类")
public class UserGroupOneResponse extends UserGroup {

    @ApiModelProperty(value = "权限列表")
    private List<ResourceComponentTreeResponse> permission;
}
