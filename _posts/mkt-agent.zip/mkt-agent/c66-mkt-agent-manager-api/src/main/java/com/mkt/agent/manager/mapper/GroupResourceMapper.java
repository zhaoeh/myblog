package com.mkt.agent.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.mkt.agent.manager.entities.GroupResource;
import org.apache.ibatis.annotations.Mapper;

import java.util.Objects;

@Mapper
public interface GroupResourceMapper extends BaseMapper<GroupResource> {

    /**
     * 根据角色id删除所有权限菜单
     *
     * @param userGroupId 角色id
     * @return result
     */
    default int deleteByGroupId(Long userGroupId) {
        return this.delete(Wrappers.<GroupResource>lambdaQuery()
                .eq(Objects.nonNull(userGroupId), GroupResource::getGroupId, userGroupId));
    }

    default Long countByGroupId(Long userGroupId){
        return this.selectCount(Wrappers.<GroupResource>lambdaQuery()
                .eq(Objects.nonNull(userGroupId), GroupResource::getGroupId, userGroupId));
    }
}
