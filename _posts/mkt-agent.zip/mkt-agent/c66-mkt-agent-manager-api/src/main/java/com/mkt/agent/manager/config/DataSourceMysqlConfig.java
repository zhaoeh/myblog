package com.mkt.agent.manager.config;


import com.alibaba.druid.pool.DruidDataSource;
import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.core.MybatisConfiguration;
import com.baomidou.mybatisplus.core.config.GlobalConfig;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import com.baomidou.mybatisplus.extension.spring.MybatisSqlSessionFactoryBean;
import com.mkt.agent.manager.handler.ManagerMetaObjectHandler;
import org.apache.ibatis.logging.stdout.StdOutImpl;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;

/**
 * @Description TODO
 * @Classname DataSourceMysqlConfig
 * @Date 2023/11/22 11:49
 * @Created by TJSLucian
 */
@Configuration
@MapperScan(sqlSessionFactoryRef = "mysqlSqlSessionFactory", basePackages = {"com.mkt.agent.manager.mapper"})
public class DataSourceMysqlConfig {

//    @Resource
//    private JdbcParamsConfig jdbcParamsConfig ;

    @Bean(name = "mysqlDataSourceProperties")
    @ConfigurationProperties(prefix = "spring.datasource.primary")
    public DataSourceProperties dataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean(name = "mysqlDataSource")
    public DataSource dataSource(@Qualifier("mysqlDataSourceProperties") DataSourceProperties properties) {

        return properties.initializeDataSourceBuilder()
                .type(DruidDataSource.class)
                .build();
    }

    @Bean("mysqlSqlSessionFactory")
    public SqlSessionFactory mysqlSqlSessionFactory(@Qualifier("mysqlDataSource")DataSource dataSource,@Qualifier("mysqlMybatisPlusInterceptor")MybatisPlusInterceptor mybatisPlusInterceptor) throws Exception {
        MybatisSqlSessionFactoryBean bean = new MybatisSqlSessionFactoryBean();

        GlobalConfig globalConfig = new GlobalConfig();
        globalConfig.setMetaObjectHandler(new ManagerMetaObjectHandler());
        globalConfig.setBanner(false);

        bean.setDataSource(dataSource);
        bean.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:mapper/*.xml"));
        bean.setPlugins(mybatisPlusInterceptor);
        bean.setGlobalConfig(globalConfig);

        MybatisConfiguration configuration = new MybatisConfiguration();
        configuration.setMapUnderscoreToCamelCase(true);
        configuration.setLogImpl(StdOutImpl.class);
        configuration.setCacheEnabled(false);
        bean.setConfiguration(configuration);

        SqlSessionFactory factory = bean.getObject();

        return factory;
    }

    @Bean(name = "mysqlMybatisPlusInterceptor")
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        interceptor.addInnerInterceptor(new PaginationInnerInterceptor(DbType.MYSQL));
        return interceptor;
    }

    @Bean
    public DataSourceTransactionManager transactionManager(@Qualifier("mysqlDataSource")DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

}



