package com.mkt.agent.manager.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mkt.agent.manager.entities.GroupResource;
import com.mkt.agent.manager.mapper.GroupResourceMapper;
import com.mkt.agent.manager.service.GroupResourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GroupResourceServiceImpl extends ServiceImpl<GroupResourceMapper, GroupResource> implements GroupResourceService {

    @Autowired
    private GroupResourceMapper groupResourceMapper;

    /**
     * 根据角色id删除角色的所有菜单权限
     *
     * @param userGroupId 角色id
     * @return 删除数量
     */
    @Override
    public int deleteByGroupId(Long userGroupId) {
        return groupResourceMapper.deleteByGroupId(userGroupId);
    }

    /**
     * 根据角色id删除角色的所有菜单权限
     *
     * @param userGroupId 角色id
     * @return 删除数量
     */
    @Override
    public Long countByGroupId(Long userGroupId) {
        return groupResourceMapper.countByGroupId(userGroupId);
    }
}
