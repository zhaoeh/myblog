package com.mkt.agent.manager.utils;

import com.mkt.agent.manager.entities.response.ResourceComponentTreeResponse;
import org.springframework.util.CollectionUtils;

import java.util.*;

public class TreeUtils {

    public static List<ResourceComponentTreeResponse> constructToTree(List<ResourceComponentTreeResponse> nodes) {

        Map<Long, List<ResourceComponentTreeResponse>> parentToChildren = new HashMap<>();

        for (ResourceComponentTreeResponse node : nodes) {
            // 查找父亲，将自己加入到父亲的孩子列表中
            List<ResourceComponentTreeResponse> children = parentToChildren.get(node.getPid());

            if (children == null) {
                children = new ArrayList<>();
                parentToChildren.put(node.getPid(), children);
            }
            children.add(node);
        }
        // 根的孩子列表
        List<ResourceComponentTreeResponse> rootChildren = parentToChildren.get(-1L);

        recurSetupChildren(rootChildren, parentToChildren);

        return rootChildren;
    }

    private static void recurSetupChildren(List<ResourceComponentTreeResponse> nodes, //
                                           Map<Long, List<ResourceComponentTreeResponse>> parentToChildren) {
        if (CollectionUtils.isEmpty(nodes)) {
            return;
        }
        for (ResourceComponentTreeResponse node : nodes) {
            List<ResourceComponentTreeResponse> children = parentToChildren.get(node.getId());
            if (!CollectionUtils.isEmpty(children)) {
                children.sort(Comparator.comparing(ResourceComponentTreeResponse::getXh));
            }
            node.setChildren(children);
            recurSetupChildren(node.getChildren(), parentToChildren);
        }
    }

}
