package com.mkt.agent.manager.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mkt.agent.manager.entities.ResourceComponent;
import com.mkt.agent.manager.entities.request.ResourceComponentCreateRequest;
import com.mkt.agent.manager.entities.request.ResourceComponentEnableRequest;
import com.mkt.agent.manager.entities.request.ResourceComponentUpdateRequest;
import com.mkt.agent.manager.entities.response.ResourceComponentTreeResponse;

import java.util.List;

public interface ResourceComponentService extends IService<ResourceComponent> {

    List<ResourceComponent> getResourcesByGroupId(Long groupId);

    List<ResourceComponentTreeResponse> getResourcesTreeByUserId(Long userGroupId);

    List<ResourceComponentTreeResponse> getResourcesTreeByGroupId(Long userGroupId, Boolean needCheck, Long userId);

    void createUserGroup(ResourceComponentCreateRequest request);

    void enableResourceComponent(ResourceComponentEnableRequest request);

    void modifyName(ResourceComponentUpdateRequest request);

    void moveUpOrDown(Long id, boolean isUp);

    List<ResourceComponent> getResourcesByParentId(Long parentId);
}
