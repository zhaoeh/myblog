package com.mkt.agent.manager.entities;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("t_user_group")
public class UserGroup extends ManagerOperationEntity {
    private static final long serialVersionUID = -809277499405470957L;

    @ApiModelProperty(value = "角色名称(Role Name)")
    private String groupName;

    @ApiModelProperty(value = "角色描述(Description)")
    private String groupDescription;

    @ApiModelProperty(value = "产品名称", hidden = true)
    private String productIdStr = null;

    @ApiModelProperty(value = "产品id", hidden = true)
    private String productId;

}
