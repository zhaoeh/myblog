package com.mkt.agent.manager.controller;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.utils.UserContext;
import com.mkt.agent.manager.entities.response.IndexMenuResponse;
import com.mkt.agent.manager.entities.response.SystemUserResponse;
import com.mkt.agent.manager.feign.AgentApiClient;
import com.mkt.agent.manager.service.ResourceComponentService;
import com.mkt.agent.manager.service.SystemUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@RequestMapping("/manager/index")
@Api(tags = {"首页Api"})
public class IndexController {

    @Autowired
    private ResourceComponentService resourceComponentService;

    @Autowired
    private SystemUserService systemUserService;

    @GetMapping("/menu")
    @ApiOperation(value = "首页菜单信息")
    public Result<IndexMenuResponse> indexMenu() {
        String userId = UserContext.getUserId();
        IndexMenuResponse indexMenuRes = new IndexMenuResponse();
        indexMenuRes.setResourcesTree(resourceComponentService.getResourcesTreeByUserId(Long.valueOf(userId)));
        return Result.success(indexMenuRes);
    }

    @GetMapping("/user")
    @ApiOperation(value = "获取当前登录用户")
    public Result<SystemUserResponse> getNowSystemUserInfo() {
        String userId = UserContext.getUserId();
        SystemUserResponse res = systemUserService.getUserDetailByUserId(Long.valueOf(userId));
        return Result.success(res);
    }
}
