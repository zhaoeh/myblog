package com.mkt.agent.manager.service;

import com.mkt.agent.common.entity.api.agentapi.dto.ConfigDto;

import java.util.List;

/**
 * @ClassName ConfigService
 * @Author TJSAlex
 * @Date 2023/5/22 16:35
 * @Version 1.0
 **/
public interface ConfigService {
    boolean save(ConfigDto req);

    boolean del(ConfigDto req);

    List<ConfigDto> list();
}
