package com.mkt.agent.manager.entities.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "菜单启用禁用请求类")
public class ResourceComponentEnableRequest {

    @ApiModelProperty(value = "菜单ID",required = true)
    @NotNull(message = "菜单ID不允许为空!")
    private Long id;

    @ApiModelProperty(value = "启用/禁用菜单,启用:1/禁用0",required = true)
    @Max(value = 1, message = "状态不允许为空!")
    @Min(value = 0, message = "状态不允许为空!")
    @NotNull(message = "状态不允许为空!")
    private Integer isEnable;
}
