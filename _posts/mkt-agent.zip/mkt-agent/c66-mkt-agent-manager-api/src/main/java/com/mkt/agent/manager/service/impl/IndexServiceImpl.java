package com.mkt.agent.manager.service.impl;

import com.mkt.agent.manager.service.IndexService;
import org.springframework.stereotype.Service;

@Service
public class IndexServiceImpl implements IndexService {
}
