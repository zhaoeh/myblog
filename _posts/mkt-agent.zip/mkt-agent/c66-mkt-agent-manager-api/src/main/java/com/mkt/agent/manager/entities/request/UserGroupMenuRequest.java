package com.mkt.agent.manager.entities.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "角色权限菜单更新请求类")
public class UserGroupMenuRequest {

    @ApiModelProperty(value = "角色id",required = true)
    @NotNull(message = "角色ID不允许为空!")
    private Long userGroupId;

    @ApiModelProperty(value = "权限id列表(Permission)")
    private List<Long> resourceIds;
}
