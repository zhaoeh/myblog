package com.mkt.agent.manager.entities.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "菜单更新", description = "菜单更新请求实体类")
public class ResourceComponentUpdateRequest {

    @ApiModelProperty(value = "id",required = true)
    @NotNull(message = "id is required!")
    private Long id;

    @ApiModelProperty(value = "菜单名称",required = true)
    @NotBlank(message = "Menu name is required!")
    private String name;

}
