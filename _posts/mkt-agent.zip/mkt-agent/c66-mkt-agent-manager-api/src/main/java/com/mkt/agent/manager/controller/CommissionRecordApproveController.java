package com.mkt.agent.manager.controller;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordApproveRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordApproveResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.base.CommissionRecordPageResponse;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.ExcelUtil;
import com.mkt.agent.manager.exception.MKTManagerException;
import com.mkt.agent.manager.feign.CommissionApiClient;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

;

@RestController
@RequestMapping("/commissionRecord-approve")
@Api(tags = "commission_record_approve API")
@Slf4j
public class CommissionRecordApproveController {

    @Autowired
    private CommissionApiClient commissionDetailApiClient;

    @PostMapping("/queryByPageAndCondition")
    @ApiOperation("query commission records list by page and conditions")
    public Result<CommissionRecordPageResponse<CommissionRecordApproveResponse>> queryByPageAndCondition(@RequestBody CommissionRecordApproveRequest req) {
        log.info("commission_record_list query parm :{}", req.toString());
        Result<CommissionRecordPageResponse<CommissionRecordApproveResponse>> data = commissionDetailApiClient.queryByPageAndCondition(req);
        log.info("commission_record_list query result :{}", data);
        return data;
    }


    @PostMapping("/exportCommissionRecord")
    @ApiOperation("export Commission Record List")
    public Result<List<CommissionRecordApproveResponse>> exportCommissionRecord(@RequestBody CommissionRecordApproveRequest req, HttpServletResponse response) {
        log.info("commission_record_approve export parm :{}", req.toString());
        Result<List<CommissionRecordApproveResponse>> data = commissionDetailApiClient.exportCommissionRecord(req);
        List<CommissionRecordApproveResponse> result = null;
        if(null!=data&& data.isSuccess()){
            result = data.getData();
        }
        log.info("commission_record_approve export result :{}", result);
        try {
            ExcelUtil.export(result, CommissionRecordApproveResponse.class, req.getFileName(), response);
        } catch (IOException e) {
            log.error("commission_record_approve export error message :{}", e.getMessage());
            throw new MKTManagerException(ResultEnum.EXCEL_EXPORT_IO_ERROR);
        }
        return data;
    }


}
