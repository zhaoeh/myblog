package com.mkt.agent.manager.entities.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.annotation.DecryptField;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.enums.CustomizedValidationContents;
import com.mkt.agent.common.valid.EnumValid;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @ClassName TAgentCustomersReq
 * @Author TJSAustin
 * @Date 2023/5/25 10:00
 * @Version 1.0
 **/
@Data
@NoArgsConstructor
public class TAgentCustomersReq {

    /*
        主键
    */
    @ApiModelProperty(value = "id")
    @NotNull(message = "id is not blank",groups = InputValidationGroup.Update.class)
    private Long id;

    /*
        登录名
    */
    @ApiModelProperty(value = "登录名")
    @NotBlank(message = "loginName is not blank",groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class})
    @DecryptField
    private String loginName;

    /*
        产品
   */
    @ApiModelProperty(value = "所属产品   C66")
    @NotBlank(message = "product id is not blank",groups = {InputValidationGroup.Insert.class,InputValidationGroup.UserToAgent.class})
    private String productId;


    /*
        佣金方案code
    */
    @ApiModelProperty(value = "佣金方案code")
    @NotNull(message = "commission contract code is not blank",groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class})
    private Long commissionContractCode;

    /*
        父级代理
   */
    @ApiModelProperty(value = "父级代理")
    private Integer parentId;

    /*
        密码
   */
    @ApiModelProperty(value = "密码")
    @NotNull(message = "pwd Id is not blank",groups = InputValidationGroup.Insert.class)
    @DecryptField
    private String pwd;


    /*
        代理类型 0:普通,1:专业代理
    */
    @ApiModelProperty(value = "代理类型 0:普通,1:专业代理")
    @NotNull(message = "agent type is not blank", groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class})
    @EnumValid(contents = CustomizedValidationContents.sub_agent_type_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class})
    private Integer agentType;


    /*
        代理可以发展最大下级代理层数
    */
    @ApiModelProperty(value = "可发展最大下级代理层数 0,1,2,3,4")
//    @NotNull(message = "developable level is not blank",groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class})
    @EnumValid(contents = CustomizedValidationContents.developable_level_values2,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class})
    private Integer developableLevel;

    /*
        启用标识 0:启用 1:禁用
    */
    @ApiModelProperty(value = "启用标识 0禁用，1启用")
    @NotNull(message = "isEnable is not blank",groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class})
    @EnumValid(contents = CustomizedValidationContents.sub_is_enable_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class})
    private Integer isEnable;

    /*
        Referral ID
    */
    @ApiModelProperty(value = "Referral ID")
    //@NotBlank(message = "Referral ID id is not blank",groups = {InputValidationGroup.Insert.class,InputValidationGroup.UserToAgent.class})
    private String referralId;

    /*
         创建人
    */
    @ApiModelProperty(value = "创建人")
    @NotBlank(message = "createBy is not blank",groups = {InputValidationGroup.Insert.class,InputValidationGroup.SubInsert.class})
    private String createBy;


    /*
        创建时间
    */
    @Column(name = "CREATE_TIME", nullable = false)
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private LocalDateTime createTime;

    /*
        修改人
    */
    @ApiModelProperty(value = "编辑者")
    @NotBlank(message = "updatedBy is not blank",groups = InputValidationGroup.Update.class )
    private String updateBy;

    /*
        修改时间
    */
    @Column(name="UPDATE_TIME")
    @JsonFormat(
            pattern = "yyyy-MM-dd HH:mm:ss"
    )
    private LocalDateTime updateTime;


    /*
        customersId
    */
    @Column(name="CUSTOMERS_ID")
    @NotNull(message = "customersId is not blank",groups = {InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class})
    private Long customersId;



    /*
        备注
    */
    @Column(name="remark")
    private String remark;

    /*
        1:Bingoplus  2:Arenaplus
    */
    @ApiModelProperty(value = "siteId 1:Bingoplus  2:Arenaplus 3:GamePlus")
    @EnumValid(contents = CustomizedValidationContents.site_id_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class} )
    private Integer siteId;


    @ApiModelProperty(value = "佣金比例集合")
    @NotEmpty(message = "settlementPercentageList array is not blank", groups = InputValidationGroup.SubInsert.class )
    private List<SettlementPercentageReq> settlementPercentageList;

    @Override
    public String toString() {
        return "AgentReq{" +
                "id=" + id +
                ", loginName='" + loginName + '\'' +
                ", productId='" + productId + '\'' +
                ", commissionContractCode='" + commissionContractCode + '\'' +
                ", parentId=" + parentId +
                ", agentType=" + agentType +
                ", developableLevel=" + developableLevel +
                ", isEnable=" + isEnable +
                ", createBy='" + createBy + '\'' +
                ", createTime=" + createTime +
                ", updateBy='" + updateBy + '\'' +
                ", updateTime=" + updateTime +
                ", remark='" + remark + '\'' +
                ", siteId='" + siteId + '\'' +
                '}';
    }
}
