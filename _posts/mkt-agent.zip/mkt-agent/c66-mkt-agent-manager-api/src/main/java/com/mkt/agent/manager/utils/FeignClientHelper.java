package com.mkt.agent.manager.utils;

import feign.Response;
import org.springframework.http.MediaType;

import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * @ClassName FeignClientHelper
 * @Description Feign客户端导出Excel辅助类
 * @Author TJSAlex
 * @Date 2023/5/30 16:46
 * @Version 1.0
 **/
public class FeignClientHelper {

    public static void export(Response serviceResponse, HttpServletResponse response) throws IOException {
        Response.Body body = serviceResponse.body();
        InputStream inputStream = body.asInputStream();
        BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
        response.setContentType(MediaType.MULTIPART_FORM_DATA_VALUE);
        response.setHeader("Content-Disposition", serviceResponse.headers().get("Content-Disposition").toString().replace("[","").replace("]",""));
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(response.getOutputStream());
        int length = 0;
        byte[] temp = new byte[1024 * 10];
        while ((length = bufferedInputStream.read(temp)) != -1) {
            bufferedOutputStream.write(temp, 0, length);
        }
        bufferedOutputStream.flush();
        bufferedOutputStream.close();
        bufferedInputStream.close();
        inputStream.close();
    }
}
