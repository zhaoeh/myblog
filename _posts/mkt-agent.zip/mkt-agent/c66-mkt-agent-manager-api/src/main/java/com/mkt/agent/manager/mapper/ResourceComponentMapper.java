package com.mkt.agent.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.mkt.agent.manager.entities.ResourceComponent;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ResourceComponentMapper extends BaseMapper<ResourceComponent> {

    List<ResourceComponent> listByUserGroupIdAndEnable(@Param("userGroupId") Long groupId);

    default List<ResourceComponent> listByPidAndName(Long pid, String name) {
        return this.selectList(Wrappers.<ResourceComponent>lambdaQuery()
                .eq(ResourceComponent::getPid, pid)
                .eq(ResourceComponent::getName, name));
    }

    default List<ResourceComponent> listByPid(Long pid) {
        return this.selectList(Wrappers.<ResourceComponent>lambdaQuery()
                .eq(ResourceComponent::getPid, pid));
    }

    default ResourceComponent selectByPidAndXh(Long pid, int i) {
        return this.selectOne(Wrappers.<ResourceComponent>lambdaQuery()
                .eq(ResourceComponent::getPid, pid)
                .eq(ResourceComponent::getXh, i));

    }
}
