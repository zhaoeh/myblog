package com.mkt.agent.manager.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.annotation.EncryptMethod;
import com.mkt.agent.common.entity.BatchRecord;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.requests.BatchQueryRequest;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentCustomersBatchReq;
import com.mkt.agent.common.entity.api.agentapi.requests.TAgentCustomersRemarkReq;
import com.mkt.agent.common.entity.api.agentapi.responses.BatchQueryResp;
import com.mkt.agent.common.entity.api.userapi.requests.TCustomerLayerReq;
import com.mkt.agent.common.entity.api.userapi.requests.UserToAgentReq;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.utils.ExcelUtil;
import com.mkt.agent.common.valid.InputValidationGroup;
import com.mkt.agent.common.valid.ValidateHelper;
import com.mkt.agent.manager.entities.request.TAgentCustomersQueryReq;
import com.mkt.agent.manager.entities.request.TAgentCustomersReq;
import com.mkt.agent.manager.entities.response.TAgentCustomersResp;
import com.mkt.agent.manager.exception.MKTManagerException;
import com.mkt.agent.manager.feign.AgentApiClient;
import com.mkt.agent.manager.feign.UserApiClient;
import com.mkt.agent.manager.service.SystemService;
import com.mkt.agent.manager.service.TAgentManageService;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.*;


/**
 * @ClassName AgentController
 * @Description 代理
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@RestController
@RequestMapping("/manager/agent/customers")
@Validated
public class TAgentCustomersController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private TAgentManageService tAgentManageService;

    @Autowired
    private AgentApiClient agentApiClient;

    @Autowired
    private UserApiClient userApiClient;

    @Autowired
    private SystemService systemService;

    @PostMapping(value = "/create")
    @ApiOperation(value = "创建代理", notes = "创建代理")
    @EncryptMethod
    public Result create(@RequestBody @Validated(value = InputValidationGroup.Insert.class) TAgentCustomersReq tAgentCustomersReq) {
        tAgentCustomersReq.setLoginName(tAgentCustomersReq.getLoginName().toLowerCase());// 用户账号:大写字母转换成小写
        String account = tAgentCustomersReq.getLoginName();
        if (!(account.length() == account.replaceAll("[^a-zA-Z0-9]", "").length())) {
            logger.error("Account are only allowed to contain numbers and English letters");
            throw new MKTManagerException(ResultEnum.LOGINNAME_CREATE_FAIL);
        }
        String password = tAgentCustomersReq.getPwd();
        ValidateHelper.validatePassword(password);
        try {
            logger.info("/manager/agent/customers/create 入参tAgentCustomersReq：{} 返回值：void", tAgentCustomersReq.toString());
            Result result = agentApiClient.create(tAgentCustomersReq);
            if(result.isSuccess()&& Objects.equals(result.getCode(), ResultEnum.SUCCESS.getCode())){
                return Result.success(ResultEnum.SUCCESS);
            }
            return Result.fail(result.getMessage());
        } catch (BusinessException e) {
            logger.error("/manager/agent/customers/create 出异常了，入参tAgentCustomersReq：{} 异常信息：{}", tAgentCustomersReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping(value = "/queryAllAgent")
    @ApiOperation(value = "代理查询", notes = "代理查询")
    public Result<Page<TAgentCustomersResp>> queryAllAgent(@RequestBody @Validated(value = InputValidationGroup.Query.class) TAgentCustomersQueryReq tAgentCustomersQueryReq) {

        logger.info("TAgentCustomersController queryAllAgent params:{}",tAgentCustomersQueryReq.toString());
        Result result = agentApiClient.checkAgentIsTop(tAgentCustomersQueryReq);
        if (result.isSuccess()) {
            Result<Page<TAgentCustomersResp>> resp = agentApiClient.queryAllAgent(tAgentCustomersQueryReq);
            logger.info("/manager/agent/customers/queryAllAgent 入参tAgentCustomersQueryReq：{} 返回值queryAllAgent：{}", tAgentCustomersQueryReq.toString(), resp);
            return resp;
        } else {
            return result;
        }

    }

    @PostMapping(value = "/update")
    @ApiOperation(value = "代理编辑", notes = "代理编辑")
    public Result update(@RequestBody @Validated(value = InputValidationGroup.Update.class) TAgentCustomersReq tAgentCustomersReq) {
        try {
            logger.info("/manager/agent/customers/update 入参tAgentCustomersReq：{} 返回值：void", tAgentCustomersReq.toString());
            agentApiClient.update(tAgentCustomersReq);
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/manager/agent/customers/update 出异常了，入参tAgentCustomersReq：{} 异常信息：{}", tAgentCustomersReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @PostMapping(value = "/updateAgentRemark")
    @ApiOperation(value = "代理编辑备注", notes = "代理编辑备注")
    public Result updateAgentRemark(@RequestBody @Validated(value = InputValidationGroup.Update.class) TAgentCustomersRemarkReq tAgentCustomersRemarkReq) {
        try {
            logger.info("/manager/agent/customers/updateAgentRemark 入参tAgentCustomersRemarkReq：{} 返回值：void", tAgentCustomersRemarkReq.toString());
            agentApiClient.updateAgentRemark(tAgentCustomersRemarkReq);
            return Result.success(ResultEnum.SUCCESS);
        } catch (Exception e) {
            logger.error("/manager/agent/customers/updateAgentRemark 出异常了，入参tAgentCustomersRemarkReq：{} 异常信息：{}", tAgentCustomersRemarkReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }


    @PostMapping("/export")
    @ApiOperation(value = "代理导出", notes = "代理导出")
    public void export(@RequestBody @Validated(value = InputValidationGroup.Query.class) TAgentCustomersQueryReq tAgentCustomersQueryReq, HttpServletResponse httpServletResponse) {
        try {
            List<TAgentCustomersResp> resp = agentApiClient.export(tAgentCustomersQueryReq).getData();
            logger.info("/manager/agent/customers/export 入参tAgentCustomersQueryReq：{} 返回值 size：{}", tAgentCustomersQueryReq.toString(), resp.size());
            ExcelUtil.export(resp, TAgentCustomersResp.class, "tAgentCustomersRespList", httpServletResponse);
        } catch (Exception e) {
            logger.error("/manager/agent/customers/export 出异常了，入参tAgentCustomersQueryReq：{} 异常信息：{}", tAgentCustomersQueryReq.toString(), e.getMessage());
            e.printStackTrace();
        }
    }

    @GetMapping(value = "/cancelAgent")
    @ApiOperation(value = "取消代理资格", notes = "取消代理资格")
    public Result cancelAgent(@Validated @NotNull(message = "customers id is not blank") Long customersId) {
        try {
            Result response = agentApiClient.cancelAgent(customersId);
            if (response.isSuccess()) {
                logger.info("/manager/agent/customers/cancelAgent 入参customersId：{} 返回值：void", customersId);
                systemService.removeFrontEndTokenByCustomersId(customersId);
            }
            return response;
        } catch (Exception e) {
            logger.error("/manager/agent/customers/cancelAgent 出异常了，入参customersId：{} 异常信息：{}", customersId, e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    @PostMapping(value = "/getUserByLoginName")
    @ApiOperation(value = "通过loginName模糊获取用户信息", notes = "通过loginName模糊获取用户信息")
    @EncryptMethod
    Result<TCustomerLayer> getUserByLoginName(@RequestBody @Validated(value = InputValidationGroup.UserToAgent.class) UserToAgentReq userToAgentReq) {
        Result<TCustomerLayer> resp = userApiClient.getUserByLoginName(userToAgentReq);
        if (!resp.isSuccess()) {
            logger.error("/manager/agent/customers/getUserByLoginName 出异常了，入参userToAgentReq：{} 异常信息：{}", userToAgentReq.toString(), resp.getMessage());
            return Result.fail(resp.getMessage());
        }
        logger.info("/manager/agent/customers/getUserByLoginName 入参userToAgentReq：{} 返回值：{}", userToAgentReq.toString(), resp.toString());
        return Result.success(resp);
    }


    @PostMapping(value = "/userToAgent")
    @ApiOperation(value = "userToAgent", notes = "userToAgent")
    @EncryptMethod
    public Result userToAgent(@RequestBody @Validated(value = InputValidationGroup.UserToAgent.class) TAgentCustomersReq tAgentCustomersReq) {
        try {
            Result result = userApiClient.userToAgent(TCustomerLayerReq.builder().customersId(tAgentCustomersReq.getCustomersId()).loginName(tAgentCustomersReq.getLoginName()).build());
            if (!result.isSuccess()) {
                return Result.fail(null);
            }
            logger.info("/manager/agent/customers/userToAgent 入参tAgentCustomersReq：{} 返回值：void", tAgentCustomersReq.toString());
            Result response = agentApiClient.userToAgent(tAgentCustomersReq);
            if(response.isSuccess()){
                return Result.success(ResultEnum.SUCCESS);
            }else{
                throw new MKTManagerException("userToAgent failed");
            }
        } catch (Exception e) {
            logger.error("/manager/agent/customers/userToAgent 出异常了，入参tAgentCustomersReq：{} 异常信息：{}", tAgentCustomersReq.toString(), e.getMessage());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }
    }

    /**
     * description: 批量创建账号
     *
     * @param: [TAgentCustomersBatchReq]
     * @return: com.mkt.agent.common.entity.Result
     * @Date: 2023/10/20 10:02
     * @Version: 1.0.0
     * @Author: Lucian
     */
    @PostMapping(value = "/createUserByBatch")
    @ApiOperation(value = "createUserByBatch", notes = "createUserByBatch")
    @EncryptMethod
    public Result createUserByBatch(@RequestBody @Validated(value = InputValidationGroup.createUserByBatch.class) TAgentCustomersBatchReq tAgentCustomersBatchReq) {

        try {
            logger.info("/manager/agent/customers/createUserByBatch tAgentCustomersBatchReq：{} 返回值：Result", tAgentCustomersBatchReq.toString());
            return agentApiClient.createUserByBatch(tAgentCustomersBatchReq);
        } catch (MKTManagerException e) {
            logger.error("/manager/agent/customers/createUserByBatch 出异常了，tAgentCustomersBatchReq：{} 异常信息：{}", tAgentCustomersBatchReq.toString(), e.toString());
            e.printStackTrace();
            return Result.fail(e.getMessage());
        }

    }

    @PostMapping(value = "/batch-query")
    @ApiOperation(value = "批量创建代理查询", notes = "批量创建代理查询")
    @EncryptMethod
    public Result<Page<BatchQueryResp>> getTopAgentBatch(@RequestBody @Validated(value = InputValidationGroup.SubInsert.class) BatchQueryRequest batchQueryRequest) {
        logger.info("BatchQueryRequest : {}", batchQueryRequest);
        return agentApiClient.getTopAgentBatch(batchQueryRequest);
    }

    @GetMapping("/export-batch-records")
    @ApiOperation(value = "我的直属玩家-批量数据导出(My Players batch-export)")
    public void exportBatchRecords(@RequestParam String batchId, HttpServletResponse response) {
        exportRecords(batchId, response);
    }

    private void exportRecords(String id, HttpServletResponse response) {
        // pageSize 配置最大值 ，pageNum = 1
        Result<List<BatchRecord>> record = agentApiClient.batchRecordList(id);
        try {
            ExcelUtil.export(record.getData(), BatchRecord.class, "file.xls", response);
        } catch (IOException e) {
            throw new MKTManagerException(ResultEnum.BAD_REQUEST);
        }
    }

    @GetMapping("/download-qr-codes")
    @ApiOperation(value = "代理-QRCode压缩包下载(download agents-QR-Codes zip file)")
    public void downloadQrCodes(@RequestParam String batchId, @RequestParam Integer siteId, HttpServletResponse response) {
        tAgentManageService.downloadQrCodes(batchId, siteId, response);
    }

}
