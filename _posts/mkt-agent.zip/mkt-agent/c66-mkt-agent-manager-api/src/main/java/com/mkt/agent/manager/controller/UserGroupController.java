package com.mkt.agent.manager.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.utils.UserContext;
import com.mkt.agent.manager.entities.ResourceComponent;
import com.mkt.agent.manager.entities.UserGroup;
import com.mkt.agent.manager.entities.request.*;
import com.mkt.agent.manager.entities.response.ResourceComponentTreeResponse;
import com.mkt.agent.manager.entities.response.UserGroupOneResponse;
import com.mkt.agent.manager.entities.response.UserGroupResponse;
import com.mkt.agent.manager.service.ResourceComponentService;
import com.mkt.agent.manager.service.UserGroupService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/manager/group")
@Api(tags = {"角色管理Api"})
public class UserGroupController {

    @Autowired
    private UserGroupService userGroupService;

    @Autowired
    private ResourceComponentService resourceComponentService;

    @GetMapping("/one")
    @ApiOperation(value = "获取一个角色")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "角色Id", required = true,dataTypeClass = Long.class)
    })
    public Result<UserGroupOneResponse> getOneUserGroupInfo(@RequestParam Long id) {
        Long userId = Long.valueOf(UserContext.getUserId());
        UserGroup userGroup = userGroupService.getById(id);
        UserGroupOneResponse response = new UserGroupOneResponse();
        BeanUtils.copyProperties(userGroup, response);
        List<ResourceComponentTreeResponse> menus = resourceComponentService.getResourcesTreeByGroupId(id, true, userId);
        response.setPermission(menus);
        return Result.success(response);
    }

    @PostMapping("/list")
    @ApiOperation(value = "获取角色列表(分页)")
    public Result<Page<UserGroupResponse>> getUserGroupInfoList(@RequestBody UserGroupQueryRequest request) {
        return Result.success(userGroupService.getUserGroupList(request));
    }

    @PostMapping("/all")
    @ApiOperation(value = "获取所有角色")
    public Result<List<UserGroup>> getAllUserGroupInfo() {
        return Result.success(userGroupService.getAllUserGroupInfo());
    }

    @PostMapping("/create")
    @ApiOperation(value = "添加角色")
    public Result createUserGroup(@RequestBody @Validated UserGroupCreateRequest request) {
        userGroupService.createUserGroup(request);
        return Result.success();
    }

    @PostMapping("/enable")
    @ApiOperation(value = "启用/禁用角色")
    public Result enableUserGroup(@RequestBody @Validated UserGroupEnableRequest request) {
        userGroupService.enableUserGroup(request);
        return Result.success();
    }

    @PostMapping("/update")
    @ApiOperation(value = "修改角色")
    public Result editUserGroup(@RequestBody @Validated UserGroupUpdateRequest request) {
        userGroupService.editUserGroup(request);
        return Result.success();
    }

    @GetMapping("/delete")
    @ApiOperation(value = "删除角色")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "角色Id", required = true,dataTypeClass = Long.class)
    })
    public Result deleteUserGroup(@RequestParam Long id) {
        userGroupService.removeUserGroup(id);
        return Result.success();
    }

    @GetMapping("/menu/all")
    @ApiOperation(value = "获取所有菜单")
    public Result<List<ResourceComponent>> getAllMenu() {
        Long userId = Long.valueOf(UserContext.getUserId());
        List<ResourceComponentTreeResponse> menus = resourceComponentService.getResourcesTreeByUserId(userId);
        return Result.success(menus);
    }

    @GetMapping("/menu/current")
    @ApiOperation(value = "获取角色菜单权限(包含勾选情况)", hidden = true)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "角色Id", required = true,dataTypeClass = Long.class)
    })
    public Result<List<ResourceComponent>> getUserGroupMenu(@RequestParam Long id) {
        Long userId = Long.valueOf(UserContext.getUserId());
        List<ResourceComponentTreeResponse> menus = resourceComponentService.getResourcesTreeByGroupId(id, true, userId);
        return Result.success(menus);
    }

    @PostMapping("/menu/set")
    @ApiOperation(value = "设置角色菜单权限", hidden = true)
    public Result setUserGroupMenu(@RequestBody @Validated UserGroupMenuRequest request) {
        userGroupService.setUserGroupMenu(request);
        return Result.success();
    }

}
