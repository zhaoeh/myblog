package com.mkt.agent.manager.feign;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.commissionapi.requests.*;
import com.mkt.agent.common.entity.api.commissionapi.responses.*;
import com.mkt.agent.common.entity.api.commissionapi.responses.base.CommissionRecordPageResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.List;

/**
 * @interfaceName: 佣金模块api
 * @Description:
 * @Author: Amida
 * @Date: 2023/5/30
 */
//@FeignClient(name = "${feign.mkt-agent-commission}", url = "127.0.0.1:18081")
@FeignClient(name = "${feign.mkt-agent-commission}")
public interface CommissionApiClient {


    // query
    @PostMapping("/commissionRecord-list/queryByPageAndCondition")
    Result<CommissionRecordPageResponse<CommissionRecordListResponse>> queryByPageAndCondition(@RequestBody CommissionRecordListRequest req);

    @PostMapping("/commissionRecord-list/exportCommissionRecord")
    Result<List<CommissionRecordListResponse>> exportCommissionRecord(@RequestBody CommissionRecordListRequest req);

    @PostMapping("/commissionRecord-detail/queryByPageAndCondition")
    Result<CommissionRecordPageResponse<CommissionRecordDetailResponse>> queryByPageAndCondition(@RequestBody CommissionRecordDetailRequest req);

    @PostMapping("/commissionRecord-detail/exportCommissionRecord")
    Result<List<CommissionRecordDetailResponse>> exportCommissionRecord(@RequestBody CommissionRecordDetailRequest req);

    @PostMapping("/commissionRecord-approve/queryByPageAndCondition")
    Result<CommissionRecordPageResponse<CommissionRecordApproveResponse>> queryByPageAndCondition(@RequestBody CommissionRecordApproveRequest req);

    @PostMapping("/commissionRecord-approve/exportCommissionRecord")
    Result<List<CommissionRecordApproveResponse>> exportCommissionRecord(@RequestBody CommissionRecordApproveRequest req);

    // update
    @PostMapping("/commissionRecord/queryByCommissionRecordId")
    Result<CommissionRecordSingleResponse> queryByCommissionRecordId(@RequestParam("id") Long commissionRecordId);

    @PostMapping("/commissionRecord/queryCommissionPlanByCommissionRecordId")
    Result<CommissionRecordPlanResponse> queryCommissionPlanByCommissionRecordId(@RequestParam("id") Long commissionRecordId);

    @PostMapping("/commissionRecord/commissionRecordFirstApproveById")
    Result<Boolean> commissionRecordFirstApproveById(@RequestBody @Valid CommissionRecordUpdateRequest req);


    @PostMapping("/commissionRecord/commissionRecordSecondApproveById")
    Result<Boolean> commissionRecordSecondApproveById(@RequestBody @Valid CommissionRecordUpdateRequest req);

    @PostMapping("/commissionRecord/commissionRecordSecondPayById")
    Result<Boolean> commissionRecordSecondPayById(@RequestBody @Valid CommissionRecordUpdateRequest req);


    @PostMapping("/commissionRecord/commissionRecordSecondResetById")
    Result<Boolean> commissionRecordSecondResetById(@RequestBody @Valid CommissionRecordResetRequest req);


}
