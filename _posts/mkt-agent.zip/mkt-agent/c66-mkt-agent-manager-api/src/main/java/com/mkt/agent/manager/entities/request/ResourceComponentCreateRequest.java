package com.mkt.agent.manager.entities.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "菜单创建", description = "菜单创建请求实体类")
public class ResourceComponentCreateRequest {

    @ApiModelProperty(value = "父id",required = true)
    @NotNull(message = "Parent Id is required!")
    private Long pid;

    @ApiModelProperty(value = "菜单名称",required = true)
    @NotBlank(message = "Name is required!")
    private String name;

    @ApiModelProperty(value = "菜单标识名",required = true)
    @NotBlank(message = "bsName is required!")
    private String bsName;

    @ApiModelProperty(value = "菜单URL",required = true)
    @NotBlank(message = "URL is required!")
    private String url;

    @ApiModelProperty(value = "备注")
    private String remark;
}
