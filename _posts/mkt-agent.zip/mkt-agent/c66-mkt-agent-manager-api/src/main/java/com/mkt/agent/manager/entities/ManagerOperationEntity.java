package com.mkt.agent.manager.entities;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.mkt.agent.common.entity.BaseOperationEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ManagerOperationEntity extends BaseOperationEntity {

    @ApiModelProperty(value = "启用/禁用菜单,启用:1/禁用0(Activition)")
    protected Integer isEnable;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "创建用户类型", hidden = true)
    protected String createUserType;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty(value = "更新用户类型", hidden = true)
    protected String updateUserType;

}
