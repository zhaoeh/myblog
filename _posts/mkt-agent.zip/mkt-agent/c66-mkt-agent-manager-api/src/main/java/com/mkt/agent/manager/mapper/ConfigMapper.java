package com.mkt.agent.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.manager.entities.TAgentGlobalConfig;
import org.apache.ibatis.annotations.Mapper;

/**
 * @ClassName ConfigMapper
 * @Author TJSAlex
 * @Date 2023/5/22 16:40
 * @Version 1.0
 **/
@Mapper
public interface ConfigMapper extends BaseMapper<TAgentGlobalConfig> {
}
