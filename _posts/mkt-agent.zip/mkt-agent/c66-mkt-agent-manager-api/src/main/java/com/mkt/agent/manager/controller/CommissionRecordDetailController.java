package com.mkt.agent.manager.controller;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordDetailRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDetailResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.base.CommissionRecordPageResponse;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.ExcelUtil;
import com.mkt.agent.manager.exception.MKTManagerException;
import com.mkt.agent.manager.feign.CommissionApiClient;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/commissionRecord-detail")
@Api(tags = "commission_record_detail API")
@Slf4j
public class CommissionRecordDetailController {

    @Autowired
    private CommissionApiClient commissionDetailApiClient;


    @PostMapping("/queryByPageAndCondition")
    @ApiOperation("query commission records detail by page and conditions")
    public Result<CommissionRecordPageResponse<CommissionRecordDetailResponse>> queryByPageAndCondition(@RequestBody CommissionRecordDetailRequest req) {
        log.info("commission_record_detail query param :{}", req.toString());
        Result<CommissionRecordPageResponse<CommissionRecordDetailResponse>> data = commissionDetailApiClient.queryByPageAndCondition(req);
        log.info("commission_record_detail query result :{}", data);
        return data;
    }


    @PostMapping("/exportCommissionRecord")
    @ApiOperation("export Commission Record")
    public Result<List<CommissionRecordDetailResponse>> exportCommissionRecord(@RequestBody CommissionRecordDetailRequest req, HttpServletResponse response) {
        log.info("commission_record_detail export param :{}", req.toString());
        Result<List<CommissionRecordDetailResponse>> data = commissionDetailApiClient.exportCommissionRecord(req);
        List<CommissionRecordDetailResponse> result = data.getData();

        log.info("commission_record_detail export result :{}", result);
        try {
            ExcelUtil.export(result, CommissionRecordDetailResponse.class, req.getFileName(), response);
        } catch (IOException e) {
            log.error("commission_record_detail export error message :{}", e.getMessage());
            throw new MKTManagerException(ResultEnum.EXCEL_EXPORT_IO_ERROR);
        }
        return data;
    }


}
