package com.mkt.agent.manager.entities;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "用户", description = "登录用户实体类")
@TableName("t_system_user")
@EqualsAndHashCode(callSuper = true)
public class SystemUser extends ManagerOperationEntity{

    private static final long serialVersionUID = -5996518127549143628L;

    @ApiModelProperty(value = "用户名(System Account)")
    private String loginName;

    @ApiModelProperty(value = "密码")
    private String pwd;

    @ApiModelProperty(value = "登陆时间")
    private Integer loginTimes;

    @ApiModelProperty(value = "密码错误次数")
    private Integer pwdErrors;

    @ApiModelProperty(value = "是否密码错误被锁定")
    private Integer isLocked;

    @ApiModelProperty(value = "上次登录IP")
    private String lastLoginIp;

    @ApiModelProperty(value = "上次登录时间")
//    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private String lastLoginTime;

    @ApiModelProperty(value = "用户角色ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long userGroupId;

    @ApiModelProperty(value = "产品ID", hidden = true)
    private String productId;
}
