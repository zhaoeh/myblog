package com.mkt.agent.manager.controller;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.agentapi.dto.ConfigDto;
import com.mkt.agent.manager.service.ConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @ClassName GlobalConfigController
 * @Description 全局配置设置
 * @Author TJSAlex
 * @Date 2023/5/22 15:55
 * @Version 1.0
 **/
@RestController
@RequestMapping("/config")
public class ConfigController {

    @Autowired
    private ConfigService configService;

    @PostMapping("/save")
    public Result<Boolean> save(@RequestBody @Validated ConfigDto req) {
        boolean success = configService.save(req);
        return Result.success(success);
    }

    @PostMapping("/del")
    public Result<Boolean> del(@RequestBody @Validated ConfigDto req) {
        boolean success = configService.del(req);
        return Result.success(success);
    }

    @GetMapping("/list")
    public Result<List<ConfigDto>> list() {
        List<ConfigDto> list = configService.list();
        list.stream().map(c->{
            Map<String, String> hashMap = new HashMap<>();
            hashMap.put(c.getParamName(),c.getParamValue());
            c.setSiteMap(hashMap);
            return c;
        }).collect(Collectors.toList());
        return Result.success(list);
    }
}
