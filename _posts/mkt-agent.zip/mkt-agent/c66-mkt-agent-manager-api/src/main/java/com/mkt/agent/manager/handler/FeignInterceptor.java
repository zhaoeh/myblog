package com.mkt.agent.manager.handler;

import com.mkt.agent.common.constants.AuthConstants;
import com.mkt.agent.common.entity.system.LoginUserInfo;
import com.mkt.agent.common.utils.UserContext;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import lombok.SneakyThrows;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.context.annotation.Configuration;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * Feign拦截配置(代理后台部分)
 * 使用FeignClient进行服务间调用，传递headers信息
 */
@Configuration
public class FeignInterceptor implements RequestInterceptor {

    @SneakyThrows
    @Override
    public void apply(RequestTemplate requestTemplate) {

        //添加用户信息,设置进请求头
        LoginUserInfo context = UserContext.getContext();
        if (ObjectUtils.isNotEmpty(context)) {
            requestTemplate.header(AuthConstants.USER_ID, URLEncoder.encode(context.getUserId(), StandardCharsets.UTF_8));
            requestTemplate.header(AuthConstants.USER_NAME, URLEncoder.encode(context.getUsername(), StandardCharsets.UTF_8));
            requestTemplate.header(AuthConstants.USER_TYPE, URLEncoder.encode(context.getUserType(), StandardCharsets.UTF_8));
        }
    }
}
