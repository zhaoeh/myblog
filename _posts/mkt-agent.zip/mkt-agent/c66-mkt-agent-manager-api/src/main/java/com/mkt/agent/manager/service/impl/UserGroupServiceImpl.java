package com.mkt.agent.manager.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.config.SystemConfig;
import com.mkt.agent.common.core.BaseServiceImpl;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.manager.entities.GroupResource;
import com.mkt.agent.manager.entities.ResourceComponent;
import com.mkt.agent.manager.entities.UserGroup;
import com.mkt.agent.manager.entities.request.*;
import com.mkt.agent.manager.entities.response.UserGroupResponse;
import com.mkt.agent.manager.exception.MKTManagerException;
import com.mkt.agent.manager.mapper.UserGroupMapper;
import com.mkt.agent.manager.service.GroupResourceService;
import com.mkt.agent.manager.service.ResourceComponentService;
import com.mkt.agent.manager.service.SystemUserService;
import com.mkt.agent.manager.service.UserGroupService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserGroupServiceImpl extends BaseServiceImpl<UserGroupMapper, UserGroup> implements UserGroupService {

    @Autowired
    private UserGroupMapper userGroupMapper;

    @Autowired
    private GroupResourceService groupResourceService;

    @Autowired
    private ResourceComponentService resourceComponentService;

    @Autowired
    private SystemUserService systemUserService;

    @Resource
    private SystemConfig systemConfig;

    /**
     * 创建角色
     *
     * @param request 角色创建请求类
     */
    @Override
    @Transactional(rollbackFor = MKTManagerException.class)
    public void createUserGroup(UserGroupCreateRequest request) {
        Long nameCount = userGroupMapper.selectCount(buildWrapper(request));
        if (nameCount != 0L) {
            throw new MKTManagerException(ResultEnum.ROLE_NAME_EXIST);
        }
        UserGroup userGroup = new UserGroup();
        BeanUtils.copyProperties(request, userGroup);
        userGroup.setProductId(systemConfig.getProductId());
        userGroup.setProductIdStr(systemConfig.getProductId());
        int insert = userGroupMapper.insert(userGroup);
        if (insert == 0) {
            throw new MKTManagerException(ResultEnum.ROLE_CREATE_FAIL);
        }
        // 权限列表未配置则直接返回
        List<GroupResource> groupResourceList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(request.getResourceIds())) {
            Long userGroupId = userGroup.getId();
            groupResourceList = request.getResourceIds().stream()
                    .map(resourceId -> getGroupResourceById(resourceId, userGroupId))
                    .collect(Collectors.toList());
        }
        addDefaultGroup(userGroup.getId(), groupResourceList);

        // 插入当前角色所有权限
        boolean b = groupResourceService.saveBatch(groupResourceList);
        if (!b) {
            throw new MKTManagerException(ResultEnum.ROLE_MENU_UPDATE_FAIL);
        }

    }

    /**
     * 启用/禁用角色
     *
     * @param request 角色启用禁用请求类
     */
    @Override
    public void enableUserGroup(UserGroupEnableRequest request) {
        UserGroup userGroup = new UserGroup();
        BeanUtils.copyProperties(request, userGroup);
        int update = userGroupMapper.updateById(userGroup);
        if (update == 0) {
            throw new MKTManagerException(ResultEnum.ROLE_ENABLE_FAIL);
        }
    }

    /**
     * 　更新角色
     *
     * @param request 　角色编辑请求类
     */
    @Override
    @Transactional(rollbackFor = MKTManagerException.class)
    public void editUserGroup(UserGroupUpdateRequest request) {
        // 更新角色基本信息
        UserGroup userGroup = new UserGroup();
        BeanUtils.copyProperties(request, userGroup);
        userGroup.setProductId(systemConfig.getProductId());
        int update = userGroupMapper.updateById(userGroup);
        if (update == 0) {
            throw new MKTManagerException(ResultEnum.ROLE_UPDATE_FAIL);
        }
        if (request.getResourceIds() == null) {
            return;
        }
        // 更新角色权限信息
        // 根据角色id删除所有权限菜单
        groupResourceService.deleteByGroupId(userGroup.getId());
        List<GroupResource> groupResourceList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(request.getResourceIds())) {
            groupResourceList = request.getResourceIds().stream()
                    .map(resourceId -> getGroupResourceById(resourceId, userGroup.getId()))
                    .collect(Collectors.toList());
        }
        // 插入当前角色所有权限
        addDefaultGroup(userGroup.getId(), groupResourceList);
        boolean b = groupResourceService.saveBatch(groupResourceList);
        if (!b) {
            throw new MKTManagerException(ResultEnum.ROLE_MENU_UPDATE_FAIL);
        }
    }

    /**
     * 添加默认权限
     *
     * @param userGroupId       角色id
     * @param groupResourceList 权限list
     */
    private void addDefaultGroup(Long userGroupId, List<GroupResource> groupResourceList) {

        // 添加默认权限
        List<ResourceComponent> resourcesByParentId = resourceComponentService.getResourcesByParentId(8000L);
        List<GroupResource> defaultMenus = resourcesByParentId.stream()
                .map(r -> getGroupResourceById(r.getId(), userGroupId)).collect(Collectors.toList());
        groupResourceList.addAll(defaultMenus);
    }

    /**
     * 角色查询
     *
     * @param request 角色查询实体类
     * @return 角色查询列表(分页)
     */
    @Override
    public Page<UserGroupResponse> getUserGroupList(UserGroupQueryRequest request) {
        // 过滤掉超级管理员
        request.setId(1L);
        request.setSortName(StringUtils.isNotBlank(request.getSortName())?request.getSortName():"createTime");
        request.setIsAsc(null==request.getIsAsc()?false:request.getIsAsc());
        return pageVO(request, UserGroupResponse.class);
    }

    /**
     * 角色权限更新
     *
     * @param request 角色权限菜单更新请求类
     */
    @Override
    @Transactional(rollbackFor = MKTManagerException.class)
    public void setUserGroupMenu(UserGroupMenuRequest request) {
        // 根据角色id删除所有权限菜单
        groupResourceService.deleteByGroupId(request.getUserGroupId());
        // 插入当前角色所有权限
        List<GroupResource> groupResourceList = request.getResourceIds().stream()
                .map(resourceId -> getGroupResourceById(resourceId, request.getUserGroupId()))
                .collect(Collectors.toList());
        addDefaultGroup(request.getUserGroupId(), groupResourceList);
        boolean b = groupResourceService.saveBatch(groupResourceList);
        if (!b) {
            throw new MKTManagerException(ResultEnum.ROLE_MENU_UPDATE_FAIL);
        }
    }

    /**
     * 删除角色
     *
     * @param id 角色id
     */
    @Override
    @Transactional
    public void removeUserGroup(Long id) {
        if (id == 1L) {
            throw new MKTManagerException(ResultEnum.ROLE_MENU_CAN_NOT_DELETE);
        }
        // 角色下有没有绑定用户，有的情况下不允许删除角色
        Long count = systemUserService.countByGroupId(id);
        if (count > 0L) {
            throw new MKTManagerException(ResultEnum.ROLE_MENU_DELETE_FAIL_FOR_USER);
        }
        // 删除角色
        int delete = userGroupMapper.deleteById(id);
        if (delete == 0) {
            throw new MKTManagerException(ResultEnum.ROLE_MENU_DELETE_FAIL);
        }
        // 删除角色所有菜单
        groupResourceService.deleteByGroupId(id);
    }

    @Override
    public List<UserGroup> getAllUserGroupInfo() {
        return this.getBaseMapper().selectList(new LambdaQueryWrapper<UserGroup>().eq(UserGroup::getIsEnable, 1));
    }

    private GroupResource getGroupResourceById(Long resourceId, Long groupId) {
        return new GroupResource(resourceId, groupId);
    }
}
