package com.mkt.agent.manager.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.core.BaseService;
import com.mkt.agent.manager.entities.SystemUser;
import com.mkt.agent.manager.entities.request.*;
import com.mkt.agent.manager.entities.response.SystemUserResponse;

public interface SystemUserService extends BaseService<SystemUser> {

    SystemUserResponse getUserDetailByUserId(Long userId);

    SystemUser createUser(SystemUserCreateRequest systemUser);

    void enableUser(SystemUserEnableRequest request);

    void editUser(SystemUserUpdateRequest systemUser);

    void deleteUser(Long systemUser);

    Page<SystemUser> getSystemUserList(SystemUserQueryRequest systemUser);

    void setPassword(SystemUserPwdUpdateRequest request);

    Long countByGroupId(Long id);
}
