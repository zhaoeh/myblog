package com.riskcontrol.common.entity.request.kyc;

import com.alibaba.fastjson.annotation.JSONField;
import com.cn.schema.customers.WSQueryKycRequest;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;


public class RiskQueryKycRequestRequest {
    @ApiModelProperty(
            required = true,
            value = "产品ID"
    )
    protected String infProductId;
    @ApiModelProperty(
            required = true,
            value = "产品密码"
    )
    protected String infPwd;
    @ApiModelProperty(
            required = true,
            value = "requestUUID"
    )
    protected String requestUUID;
    @ApiModelProperty(
            required = true,
            value = "查询参数对象"
    )
    @JSONField(
            name = "params"
    )
    @JsonProperty("params")
    protected RiskQueryKycRequest params;

    public RiskQueryKycRequestRequest() {
    }

    public String getInfProductId() {
        return this.infProductId;
    }

    public void setInfProductId(String value) {
        this.infProductId = value;
    }

    public String getInfPwd() {
        return this.infPwd;
    }

    public void setInfPwd(String value) {
        this.infPwd = value;
    }

    public RiskQueryKycRequest getParams() {
        return this.params;
    }

    public void setParams(RiskQueryKycRequest params) {
        this.params = params;
    }

    public String getRequestUUID() {
        return this.requestUUID;
    }

    public void setRequestUUID(String requestUUID) {
        this.requestUUID = requestUUID;
    }

}
