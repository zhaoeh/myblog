package com.riskcontrol.common.entity.request.ekyc;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

/**
 * @description: ekyc补充信息请求
 * @author: ErHu.Zhao
 * @create: 2024-10-08
 **/
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class EkycExtendRequest extends BaseReq {
    @ApiModelProperty(required = true, value = "提案id" )
    @NotBlank
    private String requestId;
    @ApiModelProperty(required = true, value = "登录名" )
    @NotBlank
    private String loginName;
    @ApiModelProperty(required = true, value = "首名" )
    @NotBlank
    private String firstName;
    @ApiModelProperty(required = true, value = "中间名" )
    private String middleName;
    @ApiModelProperty(required = true, value = "尾名" )
    @NotBlank
    private String lastName;
    @ApiModelProperty(required = true, value = "生日" )
    @NotBlank
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "birthday format error")
    private String birthday;
    @ApiModelProperty(required = true, value = "性别F/M" )
    @Pattern(regexp = "M|F", message = "性别只能传 M 或者 F")
    @NotBlank(message = "Sex cannot be blank")
    private String sex;
    @ApiModelProperty(required = true, value = "身份证号" )
    @NotBlank
    private String idNo;
    @ApiModelProperty(required = false, value = "企业名称" )
    private String employerName;
    @ApiModelProperty(required = false, value = "出生地" )
    private String birthPlace;
    @ApiModelProperty(required = false, value = "现居地址" )
    private String presentAddress;
    @ApiModelProperty(required = false, value = "国籍，默认 PHP" )
    private String nationality;
    @ApiModelProperty(required = false, value = "资金来源" )
    private String sourceOfIncome;
    @ApiModelProperty(required = false, value = "工作性质" )
    private String natureOfWork;
    @ApiModelProperty(required = false, value = "永久居住地" )
    private String address;
}
