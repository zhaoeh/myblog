package com.riskcontrol.common.entity.zoloz;

import com.cn.schema.customers.WSCustomers;
import com.riskcontrol.common.entity.pojo.Ekyc;
import com.riskcontrol.common.entity.pojo.EkycRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycExtendRequest;
import com.riskcontrol.common.enums.EkycManualReasonEnum;
import com.riskcontrol.common.utils.CommonUtil;
import com.riskcontrol.common.utils.CopyWsCustomerUtil;
import com.riskcontrol.common.utils.MapUtil;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Supplier;

/**
 * @description: ekyc上下文
 * @author: ErHu.Zhao
 * @create: 2024-10-09
 **/
public class EkycContext {

    /**
     * ekyc结果记录*
     */
    private Ekyc ekyc;

    /**
     * ekyc提案表记录*
     */
    private EkycRequest ekycRequest;

    /**
     * 请求实例*
     */
    private EkycExtendRequest ekycExtendRequest;

    /**
     * ws原始客户信息*
     */
    private WSCustomers oriWsCustomers;

    /**
     * 更新后的ws客户信息*
     */
    private WSCustomers upWsCustomers;

    /**
     * ekyc完善信息请求是否被三方系统审核通过 true：审核通过 false：其他状态*
     */
    private Boolean isApprovalWithThirdPart;

    /**
     * ekyc完善信息请求是否需要转人工处理 true：转人工 false：直接拒绝 null：忽略*
     */
    private Boolean isPending;

    /**
     * ekyc完善信息请求是否被拒绝 true：审核拒绝 false：其他状态*
     */
    private Boolean isReject;

    /**
     * ekyc完善信息请求核心信息是否被修改 true：被修改 false：未修改*
     */
    private Boolean isModified;

    /**
     * ekyc完善信息请求中的证件号码重复使用次数是否已达上限 true：已经达到重复使用上限  false：未达到重复使用上限*
     */
    private Boolean isDeduplicateLimit;

    /**
     * ekyc完善信息请求中的年龄是否合法 true：合法 false：不合法 *
     */
    private Boolean validateAge;

    /**
     * 产品*
     */
    private String product;

    /**
     * 拒绝原因*
     */
    private String rejectReason;

    /**
     * 消息容器*
     */
    private Map<String, String> msgContainer;

    /**
     * 短信任务*
     */
    private MsgTask smsTask;

    /**
     * push任务*
     */
    private MsgTask pushTask;

    public EkycContext() {
    }


    public EkycRequest getEkycRequest() {
        return ekycRequest;
    }

    public EkycContext setEkycRequest(EkycRequest ekycRequest) {
        this.ekycRequest = ekycRequest;
        return this;
    }

    public Ekyc getEkyc() {
        return ekyc;
    }

    public EkycContext setEkyc(Ekyc ekyc) {
        this.ekyc = ekyc;
        return this;
    }

    public EkycExtendRequest getEkycExtendRequest() {
        return ekycExtendRequest;
    }

    public EkycContext setEkycExtendRequest(EkycExtendRequest ekycExtendRequest) {
        this.ekycExtendRequest = ekycExtendRequest;
        return this;
    }

    public WSCustomers getOriWsCustomers() {
        return oriWsCustomers;
    }

    public void setOriWsCustomers(WSCustomers oriWsCustomers) {
        this.oriWsCustomers = oriWsCustomers;
    }

    public WSCustomers getUpWsCustomers() {
        if (Objects.isNull(upWsCustomers) && Objects.nonNull(oriWsCustomers) && Objects.nonNull(ekyc)) {
            upWsCustomers = new WSCustomers();
            BeanUtils.copyProperties(oriWsCustomers, upWsCustomers);
            CopyWsCustomerUtil.copy(ekyc, upWsCustomers);
        }
        return upWsCustomers;
    }

    public Boolean getApprovalWithThirdPart() {
        return isApprovalWithThirdPart;
    }

    public EkycContext setApprovalWithThirdPart(Boolean approvalWithThirdPart) {
        isApprovalWithThirdPart = approvalWithThirdPart;
        return this;
    }

    public Boolean getPending() {
        return isPending;
    }

    public EkycContext setPending(Boolean pending) {
        isPending = pending;
        return this;
    }

    public Boolean getReject() {
        return isReject;
    }

    public EkycContext setReject(Boolean reject) {
        isReject = reject;
        return this;
    }

    public Boolean getModified() {
        return isModified;
    }

    public EkycContext setModified(Boolean modified) {
        isModified = modified;
        return this;
    }

    public Boolean getDeduplicateLimit() {
        return isDeduplicateLimit;
    }

    public EkycContext setDeduplicateLimit(Boolean deduplicateLimit) {
        isDeduplicateLimit = deduplicateLimit;
        return this;
    }

    public Boolean getValidateAge() {
        return validateAge;
    }

    public EkycContext setValidateAge(Boolean validateAge) {
        this.validateAge = validateAge;
        return this;
    }

    public String getProduct() {
        return product;
    }

    public EkycContext setProduct(String product) {
        this.product = product;
        return this;
    }

    public Map<String, String> getMsgContainer() {
        return msgContainer;
    }

    public EkycContext setMsgContainer(Map<String, String> msgContainer) {
        this.msgContainer = msgContainer;
        return this;
    }

    /**
     * 获取拒绝原因*
     *
     * @param reasonMapper
     * @return
     */
    public String getRejectReason(Supplier<String> reasonMapper) {
        if (StringUtils.hasText(rejectReason)) {
            return rejectReason;
        }
        if (Objects.nonNull(reasonMapper)) {
            rejectReason = reasonMapper.get();
        }
        return rejectReason;
    }

    /**
     * 获取转人工原因*
     *
     * @return
     */
    public EkycManualReasonEnum getManualReason() {
        if (BooleanUtils.isTrue(isPending)) {
            return EkycManualReasonEnum.SAME_FACE;
        }
        if (BooleanUtils.isTrue(isDeduplicateLimit)) {
            return EkycManualReasonEnum.ID_REPEATED;
        }
        if (BooleanUtils.isTrue(isModified)) {
            return EkycManualReasonEnum.MESSAGE_UPDATE;
        }
        return EkycManualReasonEnum.OTHER;
    }

    /**
     * 获取用户姓名*
     *
     * @return
     */
    public String getLoginName() {
        if (Objects.nonNull(upWsCustomers) && StringUtils.hasText(upWsCustomers.getLoginName())) {
            return upWsCustomers.getLoginName();
        }
        if (Objects.nonNull(oriWsCustomers) && StringUtils.hasText(oriWsCustomers.getLoginName())) {
            return oriWsCustomers.getLoginName();
        }
        if (Objects.nonNull(ekycRequest) && StringUtils.hasText(ekycRequest.getLoginName())) {
            return ekycRequest.getLoginName();
        }
        if (Objects.nonNull(ekyc) && StringUtils.hasText(ekyc.getLoginName())) {
            return ekyc.getLoginName();
        }
        if (Objects.nonNull(ekycExtendRequest) && StringUtils.hasText(ekycExtendRequest.getLastName())) {
            return ekycExtendRequest.getLoginName();
        }
        return null;
    }

    /**
     * 获取用户手机号*
     *
     * @return 用户手机号，null：无效
     */
    public String getPhone() {
        String phone = null;
        if (Objects.nonNull(upWsCustomers) && StringUtils.hasText(upWsCustomers.getPhone())) {
            phone = upWsCustomers.getPhone();
        }
        if (Objects.nonNull(oriWsCustomers) && StringUtils.hasText(oriWsCustomers.getPhone())) {
            phone = oriWsCustomers.getPhone();
        }
        return phone;
    }

    /**
     * 初始化消息任务*
     *
     * @param smsTask
     * @param pushTask
     * @return
     */
    public EkycContext initMsgTasks(Map<String, String> msgContainer, MsgTask smsTask, MsgTask pushTask, BiConsumer<Map<String, Object>, String> action) {
        Assert.notEmpty(msgContainer, "msgContainer cannot be empty");
        this.msgContainer = msgContainer;
        this.smsTask = smsTask;
        this.pushTask = pushTask;
        if (msgContainer.containsKey(smsTask.msgFlag)) {
            smsTask.shouldToRun = true;
            smsTask.msgType = msgContainer.get(smsTask.msgFlag);
        }
        if (msgContainer.containsKey(pushTask.msgFlag)) {
            pushTask.shouldToRun = true;
            pushTask.msgType = msgContainer.get(pushTask.msgFlag);
        }
        return CommonUtil.doAction(this, action, MapUtil.of("msgContainer", msgContainer, "smsTask", smsTask, "pushTask", pushTask));
    }

    public MsgTask getSmsTask() {
        return smsTask;
    }

    public MsgTask getPushTask() {
        return pushTask;
    }

    public static MsgTask buildTask(String msgType, Runnable msgTask) {
        Objects.requireNonNull(msgType);
        Objects.requireNonNull(msgTask);
        return new MsgTask(msgType, msgTask);
    }

    /**
     * 执行消息任务*
     */
    public void doTasks(BiConsumer<Map<String, Object>, String> noRunAction) {
        List.of(Optional.ofNullable(this.smsTask), Optional.ofNullable(this.pushTask)).forEach(nullableTask -> {
            if (Objects.nonNull(nullableTask)) {
                nullableTask.filter(task -> task.shouldToRun && Objects.nonNull(task.msgTask)).
                        ifPresentOrElse(task -> task.msgTask.run(),
                                () -> CommonUtil.doAction(this, noRunAction, MapUtil.of("smsTask", smsTask, "pushTask", pushTask)));
            }
        });
    }

    /**
     * 消息任务*
     */
    public static class MsgTask {

        /**
         * 消息任务是否应该被执行*
         */
        private boolean shouldToRun;

        /**
         * 消息标记*
         */
        private String msgFlag;

        /**
         * 消息类型*
         */
        private String msgType;

        /**
         * 消息任务*
         */
        private Runnable msgTask;

        private MsgTask(String msgFlag, Runnable msgTask) {
            this.msgFlag = msgFlag;
            this.msgTask = msgTask;
        }

        public String getMsgType() {
            return msgType;
        }

        public boolean isShouldToRun() {
            return shouldToRun;
        }

        public String getMsgFlag() {
            return msgFlag;
        }
    }

}
