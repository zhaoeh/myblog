package com.riskcontrol.common.entity.response.api;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigInteger;

/**
 * @Description: 查询风控字典响应对象
 * @Auther: yannis
 * @create: 2024-01-11
 */
@ApiModel(value = "查询风控字典响应对象", description = "查询风控字典返回数据")
@Data
public class RiskConstantsRsp implements Serializable {
    @ApiModelProperty("ID")
    private BigInteger id;

    @ApiModelProperty("所属产品")
    private String productId;

    @ApiModelProperty("常量key")
    private String pKey;

    @ApiModelProperty("常量值")
    private String pValue;

    @ApiModelProperty("类型")
    private String pType;

    @ApiModelProperty("描述")
    private String remarks;

    @ApiModelProperty("ip地址")
    private String ipAddress;

}
