package com.riskcontrol.common.entity.request.ekyc;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @description: 查询ekyc状态请求体
 * @author: ErHu.Zhao
 * @create: 2024-10-07
 **/
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class EkycQueryStatusRequest {

    @ApiModelProperty(required = true, value = "用户id" )
    @NotNull
    private Long customerId;

    @ApiModelProperty(required = true, value = "登录名" )
    @NotBlank
    private String loginName;

    @ApiModelProperty(required = true, value = "是否需要旧kyc状态" )
    @NotNull
    private Boolean needOldKycStatus;

    @ApiModelProperty(required = true, value = "是否需要额外信息" )
    @NotNull
    private Boolean noNeedEx;
}
