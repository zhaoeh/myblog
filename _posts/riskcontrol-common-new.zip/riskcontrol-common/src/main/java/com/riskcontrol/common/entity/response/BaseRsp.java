package com.riskcontrol.common.entity.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * 响应参数基类 *
 * @author Colson
 * @since 2024-01-12
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class BaseRsp implements Serializable {

    @ApiModelProperty("创建人")
    private String createBy;

    @ApiModelProperty(value = "更新日期(Modify Time)")
    private String createTime;

    @ApiModelProperty(value = "更新日期(Modify Time)")
    private String updateTime;

    @ApiModelProperty("最后修改人")
    private String updateBy;

}