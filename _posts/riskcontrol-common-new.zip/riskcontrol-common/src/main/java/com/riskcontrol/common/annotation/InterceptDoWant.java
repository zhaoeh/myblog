package com.riskcontrol.common.annotation;

import com.riskcontrol.common.aop.CommonAspectType;

import java.lang.annotation.*;

/**
 * 自定义注解
 *
 * @program: riskcontrol-cron
 * @description: 同步requestId到process log表的注解标志
 * @author: Erhu.Zhao
 * @create: 2023-10-20 11:23
 **/
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface InterceptDoWant {

    Class<?> value();

    CommonAspectType type() default CommonAspectType.AFTER;
}
