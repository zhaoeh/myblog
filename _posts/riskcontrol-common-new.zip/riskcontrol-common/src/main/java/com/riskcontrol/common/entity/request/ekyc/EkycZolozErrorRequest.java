package com.riskcontrol.common.entity.request.ekyc;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;
import java.util.Date;

/**
 * @description: ekyc：第三方出问题修改ekyc信息
 **/
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class EkycZolozErrorRequest {

    @ApiModelProperty(required = true, value = "登录名")
    @NotBlank(message = "loginName cannot be empty")
    private String loginName;

    @ApiModelProperty(required = true, value = "提案id")
    @NotNull(message = "requestId cannot be null")
    private BigInteger requestId;

    @ApiModelProperty(required = true, value = "第三方获取结果时间")
    @NotNull(message = "ekycResultDate cannot be null")
    @JsonFormat(timezone = "GMT+8")
    private Date ekycResultDate;

    @ApiModelProperty(required = true, value = "第三方返回结果")
    @NotBlank(message = "ekycResult cannot be empty")
    private String ekycResult;
}
