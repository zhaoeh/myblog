package com.riskcontrol.common.entity.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author dante
 */
@Data
public class QueryLoginInfoReq {

    @Schema(name = "页码[若不传，则默认1]", example = "1")
    private Integer pageNo = 1;

    @Schema(name = "每页显示条数[若不传，则默认5]", example = "5")
    private Integer pageSize = 5;

    @NotBlank(message = "loginIp can not be blank")
    @Schema(name = "登录IP，无校验", example = "127.0.0.1")
    private String loginIp ;

    @Schema(name = "产品id", example = "C66")
    private String productId ;

    @NotBlank(message = "lastWithDrawalDate can not be blank")
    @Schema(name = "查询截止时间", example = "2024-09-11 13:24:00")
    private String loginTimeEnd;
}
