package com.riskcontrol.common.aop;

import com.riskcontrol.common.annotation.InterceptDoWant;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * @program: riskcontrol-cron
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-10-20 11:20
 **/
@Slf4j
@Component
@Aspect
public class CommonAspect {
    /**
     * 通用AOP切面对象收集器
     */
    private final Map<String, CommonAspectRunner> runners = new HashMap<>();

    public CommonAspect(ObjectProvider<Map<String, CommonAspectRunner>> runnerProvider) {
        Map<String, CommonAspectRunner> runnerMap = runnerProvider.getIfAvailable();
        if (!CollectionUtils.isEmpty(runnerMap)) {
            runnerMap.forEach((k, v) -> runners.put(v.getClass().getName(), v));
        }

    }

    @Pointcut(value = "@annotation(com.riskcontrol.common.annotation.InterceptDoWant)")
    public void doWant() {
    }

    @Around("doWant()")
    public Object process(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        MethodSignature methodSignature = (MethodSignature) proceedingJoinPoint.getSignature();
        InterceptDoWant interceptDoWant = methodSignature.getMethod().getAnnotation(InterceptDoWant.class);

        Object obj;
        try {
            obj = doProcess(interceptDoWant, proceedingJoinPoint);
        } catch (Throwable throwable) {
            log.error("an error occurred when process target method[" + proceedingJoinPoint.getSignature().getName() + "] by AOP!");
            throw throwable;
        }
        return obj;
    }


    private Object doProcess(InterceptDoWant interceptDoWant, ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        Class<?> clazz = interceptDoWant.value();
        CommonAspectType type = interceptDoWant.type();
        CommonAspectRunner runner = runners.get(clazz.getName());
        Object obj = null;
        if (type.equals(CommonAspectType.BEFORE)) {
            obj = doBefore(runner, proceedingJoinPoint);
        }
        if (type.equals(CommonAspectType.AFTER)) {
            obj = doAfter(runner, proceedingJoinPoint);
        }
        return obj;
    }

    private Object doBefore(CommonAspectRunner runner, ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        Object result = runner.before(BeforeParams.builder().params(proceedingJoinPoint.getArgs()).build());
        return doProceeding(result, proceedingJoinPoint);
    }

    private Object doAfter(CommonAspectRunner runner, ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        Object result = doProceeding(null, proceedingJoinPoint);
        Object afterResult = runner.after(AfterParams.builder().params(proceedingJoinPoint.getArgs()).returnValue(result).build());
        return Objects.isNull(afterResult) ? result : afterResult;
    }

    private Object doProceeding(Object result, ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        return Objects.isNull(result) ? proceedingJoinPoint.proceed(proceedingJoinPoint.getArgs()) : proceedingJoinPoint.proceed(new Object[]{result});
    }


}
