package com.riskcontrol.common.entity.request.api;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigInteger;

/*** @program: riskcontrol-common
 ** @description: 风控PBC返回接口
 ** @author: hongwei
 ** @create: 2023-11-14 14:35
 **/
@ApiModel(value = "风控PBC修改配置-请求对象", description = "风控PBC修改配置-请求对象")
@Data
public class PBCDeployUpdateRequest {

    @ApiModelProperty("id")
    protected BigInteger id;
    @ApiModelProperty("抓取系统id")
    protected String systemId;
    @ApiModelProperty("用户名")
    protected String userName;
    @ApiModelProperty("密码")
    protected String password;
    @ApiModelProperty("开始时间")
    @NotNull(message = "start time cannot be null")
    protected String startTime;
    @ApiModelProperty("停止时间")
    @NotNull(message = "end time cannot be null")
    protected String endTime;
    @ApiModelProperty("抓取频率")
    protected String frequency;
    @ApiModelProperty("配置状态 1 enable  0 disable")
    protected String status;
    @ApiModelProperty("修改时间")
    protected String updateDate;
    @ApiModelProperty("最后修改人")
    protected String updateBy;


}
