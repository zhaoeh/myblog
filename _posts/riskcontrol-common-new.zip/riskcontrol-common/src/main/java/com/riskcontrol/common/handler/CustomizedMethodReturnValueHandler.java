package com.riskcontrol.common.handler;

import com.riskcontrol.common.config.ReturnValueStrategyConfiguration;
import org.springframework.core.MethodParameter;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
import org.springframework.web.method.support.ModelAndViewContainer;

/**
 * @program: riskcontrol-common
 * @description: 自定义 HandlerMethodReturnValueHandler
 * @author: Erhu.Zhao
 * @create: 2023-12-01 15:00
 */
public class CustomizedMethodReturnValueHandler implements HandlerMethodReturnValueHandler {

    private HandlerMethodReturnValueHandler handlerMethodReturnValueHandler;

    /**
     * 逻辑策略
     */
    private ReturnValueStrategyConfiguration.ReturnValueStrategy strategy;

    public CustomizedMethodReturnValueHandler(HandlerMethodReturnValueHandler handlerMethodReturnValueHandler, ReturnValueStrategyConfiguration.ReturnValueStrategy strategy) {
        this.handlerMethodReturnValueHandler = handlerMethodReturnValueHandler;
        this.strategy = strategy;
    }

    @Override
    public boolean supportsReturnType(MethodParameter returnType) {
        return handlerMethodReturnValueHandler.supportsReturnType(returnType);
    }

    @Override
    public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest) throws Exception {
        handlerMethodReturnValueHandler.handleReturnValue(strategy.wrapperReturnValue(returnValue), returnType, mavContainer, webRequest);
    }
}