package com.riskcontrol.common.entity.request.api;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author Colson
 * @program riskcontrol-common
 * @description 创建手机号黑名单参数
 * @date 2023/9/26 10:30
 **/
@Data
@ApiModel(value = "创建手机号黑名单请求对象", description = "创建手机号黑名单参数")
public class PhoneNumberBlacklistCreateRequest {

    @ApiModelProperty("所有历史绑定的用户ID，逗号分隔，按照时间顺序增加")
    @NotBlank(message = "history cannot be empty")
    private String history;

    @ApiModelProperty("手机号码")
    private String phone;

    @ApiModelProperty("手机号码md5")
    @NotBlank(message = "phone md5 cannot be empty")
    private String phoneMd5;

    @ApiModelProperty("状态：0-失效，1-生效中")
    @Max(value =1, message = "The status can only be filled in 0 or 1 (0-invalid, 1-in effect)")
    @Min(value = 0, message = "The status can only be filled in 0 or 1 (0-invalid, 1-in effect)")
    @NotNull(message = "status cannot be empty")
    private Integer status;

    @ApiModelProperty("最后一次最后修改的account")
    @NotBlank(message = "dataModifier cannot be empty")
    private String dataModifier;

    @ApiModelProperty("所属产品，默认C66")
    private String productId;

    @ApiModelProperty("备注")
    private String remarks;

}
