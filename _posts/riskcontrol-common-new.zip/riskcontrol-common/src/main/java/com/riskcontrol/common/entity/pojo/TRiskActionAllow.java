package com.riskcontrol.common.entity.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;
import lombok.experimental.Accessors;
import java.math.BigInteger;

/**
 * @author Zhilin.Du
 */
@TableName(value = "t_risk_action_allow")
@Getter
@Setter
@Accessors(chain = true)
public class TRiskActionAllow {

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private BigInteger id;

    /**
     * 内容（IP或者设备指纹 字符串）
     */
    @TableField(value = "allow_record")
    private String allowRecord;

    /**
     * 名单类型（0:ip ; 1:设备指纹）
     */
    @TableField(value = "allow_type")
    private Integer allowType;

    /**
     * 名单规则（0：白名单；1：黑名单）
     */
    @TableField(value = "allow_rule")
    private Integer allowRule;

    /**
     * '
     * 是否启用（0：启用；1：禁用）
     */
    @TableField(value = "is_enable")
    private Integer isEnable;

    /**
     * 来源（0:人工；9：抓取）
     */
    @TableField(value = "source")
    private Integer source;

    /**
     * 备注
     */
    @TableField(value = "remark")
    private String remark;

    /**
     * 创建时间
     */
    @TableField(value = "create_date")
    private String createDate;

    /**
     * 创建人
     */
    @TableField(value = "create_by")
    private String createBy;

    /**
     * 更新时间
     */
    @TableField(value = "update_date")
    private String updateDate;

    /**
     * 更新人
     */
    @TableField(value = "update_by")
    private String updateBy;

}