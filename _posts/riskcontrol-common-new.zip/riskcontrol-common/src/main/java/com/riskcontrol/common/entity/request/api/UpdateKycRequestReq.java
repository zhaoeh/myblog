package com.riskcontrol.common.entity.request.api;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema
@Data
public class UpdateKycRequestReq extends BaseReq {

    @Schema(description = "Id, primary Key")
    private String id;
    @Schema(description ="customerId")
    private String customerId;
    @Schema(description ="customer Login Name")
    private String loginName;
    @Schema(description ="productId")
    private String productId;
    @Schema(description ="created Date")
    private String createdDate;
    @Schema(description ="open Date")
    private String openDate;
    @Schema(description ="created By")
    private String createdBy;
    @Schema(description ="update By")
    private String updateDate;
    @Schema(description ="update By")
    private String updateBy;
    @Schema(description ="id Type")
    private String idType;
    @Schema(description ="id Number")
    private String idNo;
    @Schema(description ="firstName")
    private String firstName;
    @Schema(description ="middleName")
    private String middleName;
    @Schema(description ="lastName")
    private String lastName;
    @Schema(description ="id snapshot storage address")
    private String idScan;
    @Schema(description ="id status")
    private String status;
    @Schema(description ="remark")
    private String remark;
    @Schema(description ="sex")
    private String sex;
    @Schema(description ="address")
    private String address;
    @Schema(description ="country")
    private String country;
    @Schema(description ="pbcStatus")
    private String pbcStatus;
    @Schema(description ="birthday")
    private String birthday;
}
