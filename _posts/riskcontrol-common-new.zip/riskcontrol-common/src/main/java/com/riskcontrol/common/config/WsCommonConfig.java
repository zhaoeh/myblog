package com.riskcontrol.common.config;



import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * default description.
 *
 * @author Damon.Q
 * @since 1.0
 */
@Component
public class WsCommonConfig {


    @Value("${ws.product.id}")
    private String wsProductId;

    @Value("${ws.product.pwd}")
    private String wsProductPwd;

    @Value("${ws.terminal}")
    private String wsTerminal;


    public String getWsProductId() {
        return wsProductId;
    }

    public String getWsProductPwd() {
        return wsProductPwd;
    }

    public String getWsTerminal() {
        return wsTerminal;
    }
}
