package com.riskcontrol.common.entity.request;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.riskcontrol.common.constants.PageConstant;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 分页查询基类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BasePageRequest {

    @ApiModelProperty(value = "第几页（分页），默认 1", example = "1")
    @JsonAlias({"pageNum", "pageNo"})
    protected Integer pageNum;

    @ApiModelProperty(value = "每页多少条（分页），默认 10", example = "10")
    protected Integer pageSize;

    @ApiModelProperty(value = "第几行（分页），默认 0", notes = "用于更灵活的指定从哪行开始", hidden = true)
    private Integer rowNum = null;

    @ApiModelProperty(value = "排序字段名,参考相应实体类字段名")
    private String sortName;

    @ApiModelProperty(value = "字段排序。asc:true/desc:false")
    private Boolean isAsc;

    public Integer getPageNum() {
        if (pageNum == null) {
            return PageConstant.DEFAULT_PAGE_NUM;
        }
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
        this.rowNum = (this.pageNum - 1) * getPageSize();
    }

    public Integer getPageSize() {
        if (pageSize == null) {
            return PageConstant.DEFAULT_PAGE_SIZE;
        }
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
        this.rowNum = (getPageNum() - 1) * this.pageSize;
    }


    public Integer getRowNum() {
        if (rowNum == null) {
            return (getPageNum() - 1) * getPageSize();
        }
        return rowNum;
    }

    public Boolean getIsAsc() {
        if (isAsc == null) {
            return true;
        }
        return isAsc;
    }

}
