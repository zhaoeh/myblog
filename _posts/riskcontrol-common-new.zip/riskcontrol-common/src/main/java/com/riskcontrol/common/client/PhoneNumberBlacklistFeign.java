package com.riskcontrol.common.client;


import com.riskcontrol.common.entity.request.api.*;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.api.PhoneCoolingDownPeriodRsp;
import com.riskcontrol.common.entity.response.api.PhoneNumberBlacklistRsp;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * @program: riskcontrol-common
 * @description: 手机号码黑名单服务接口
 * @author: Colson
 * @create: 2023-09-28 14:16
 */
@FeignClient(name = "riskcontrol-cron",contextId = "risk-cron-api-third")
public interface PhoneNumberBlacklistFeign {

    @PostMapping(value = "/phoneNumberBlacklist/page")
    Response<PageModel<PhoneNumberBlacklistRsp>> getPage(@RequestBody PhoneNumberBlacklistPageRequest request);

    @PostMapping(value = "/phoneNumberBlacklist/list")
    Response<List<PhoneNumberBlacklistRsp>> getList(@RequestBody PhoneNumberBlacklistRequest request);

    @PostMapping(value = "/phoneNumberBlacklist/one")
    Response<PhoneNumberBlacklistRsp> getOne(@RequestBody PhoneNumberBlacklistGetOneRequest request);

    @PostMapping("/phoneNumberBlacklist/create")
    Response<Boolean> create(@RequestBody PhoneNumberBlacklistCreateRequest request);

    @PostMapping(value = "/phoneNumberBlacklist/updateHistory")
    Response<Boolean> updateHistory(@RequestBody PhoneNumberBlacklistUpdateHistoryRequest request);

    @PostMapping(value = "/phoneNumberBlacklist/updateStatus")
    Response<Boolean> updateStatus(@RequestBody PhoneNumberBlacklistUpdateStatusRequest request);

    @PostMapping(value = "/phoneNumberBlacklist/coolingDownPeriod")
    Response<PhoneCoolingDownPeriodRsp> coolingDownPeriod(@RequestBody PhoneCoolingDownPeriodRequest request);

}
