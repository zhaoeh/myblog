package com.riskcontrol.common.entity.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * @description: customer/account/getCustomerByLoginName
 * @author: Colson
 * @create: 2023-09-15 12:20
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class UserQueryCustomersBasicByLoginNameRequest {

    private String requestUUID;

    private String infProductId;

    private String infPwd;

    private String loginName;

    private String customerId;

    private Boolean onlyOpenUser;
}
