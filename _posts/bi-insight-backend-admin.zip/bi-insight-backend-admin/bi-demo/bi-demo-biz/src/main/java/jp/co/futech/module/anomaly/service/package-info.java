/**
 * service层
 */
package jp.co.futech.module.anomaly.service;
