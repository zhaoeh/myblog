/**
 * 占位，构建admin包，以供b端进行rest访问
 */
package jp.co.futech.module.anomaly.controller.admin;
