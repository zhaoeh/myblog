/**
 * 用户操作日志：记录用户的操作，用于对用户的操作的审计与追溯，永久保存。
 *
 * @author futech.co.jp
 */
package jp.co.futech.framework.operatelog;
