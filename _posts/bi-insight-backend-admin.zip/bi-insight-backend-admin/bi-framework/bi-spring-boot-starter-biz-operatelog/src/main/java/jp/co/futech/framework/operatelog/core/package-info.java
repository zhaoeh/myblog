package jp.co.futech.framework.operatelog.core;
