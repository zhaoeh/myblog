<http://www.iocoder.cn/Spring-Cloud/Feign/?bi>
