<https://www.iocoder.cn/Spring-Boot/Actuator/?bi>
