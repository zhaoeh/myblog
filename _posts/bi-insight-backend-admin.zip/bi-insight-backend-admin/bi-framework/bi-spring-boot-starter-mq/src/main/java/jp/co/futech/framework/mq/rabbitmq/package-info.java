/**
 * 消息队列，基于 RabbitMQ 提供
 */
package jp.co.futech.framework.mq.rabbitmq;
