/**
 * 基于 mzt-log 框架
 * 实现操作日志功能
 *
 * @author HUIHUI
 */
package jp.co.futech.framework.operatelog;
