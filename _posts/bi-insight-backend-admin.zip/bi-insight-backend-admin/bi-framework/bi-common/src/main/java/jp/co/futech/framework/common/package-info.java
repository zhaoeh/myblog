/**
 * 基础的通用类，和框架无关
 *
 * 例如说，CommonResult 为通用返回
 */
package jp.co.futech.framework.common;
