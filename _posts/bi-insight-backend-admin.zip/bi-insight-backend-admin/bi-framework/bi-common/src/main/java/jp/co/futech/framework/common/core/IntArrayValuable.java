package jp.co.futech.framework.common.core;

/**
 * 可生成 Int 数组的接口
 *
 * @author futech.co.jp
 */
public interface IntArrayValuable {

    /**
     * @return int 数组
     */
    int[] array();

}
