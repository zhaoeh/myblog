/**
 * 占位
 */
package jp.co.futech.framework.dict.core;
