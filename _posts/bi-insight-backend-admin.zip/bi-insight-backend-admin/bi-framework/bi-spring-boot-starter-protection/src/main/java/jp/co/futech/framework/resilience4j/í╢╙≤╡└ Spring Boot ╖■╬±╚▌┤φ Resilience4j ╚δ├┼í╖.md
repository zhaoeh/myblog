<https://www.iocoder.cn/Spring-Boot/Resilience4j/?bi>
