package jp.co.futech.framework.jackson.core;
