/**
 * OpenFeign：提供 RESTful API 的调用
 *
 * @author futech.co.jp
 */
package jp.co.futech.framework.rpc;
