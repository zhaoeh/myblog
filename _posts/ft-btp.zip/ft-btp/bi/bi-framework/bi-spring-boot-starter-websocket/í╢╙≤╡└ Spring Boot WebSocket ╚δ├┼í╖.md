<http://www.iocoder.cn/Spring-Boot/WebSocket/?bi>
