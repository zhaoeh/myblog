/**
 * 基于 Spring Security 框架
 * 实现安全认证功能
 *
 * @author futech.co.jp
 */
package jp.co.futech.framework.security;
