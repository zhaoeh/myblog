/**
 * 提供单元测试 Unit Test 的基类
 */
package jp.co.futech.framework.test.core.ut;
