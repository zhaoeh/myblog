/**
 * 使用 Hibernate Validator 实现参数校验
 */
package jp.co.futech.framework.common.validation;
