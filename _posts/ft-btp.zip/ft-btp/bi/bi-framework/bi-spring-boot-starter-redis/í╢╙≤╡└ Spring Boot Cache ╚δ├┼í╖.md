<http://www.iocoder.cn/Spring-Boot/Cache/?bi>
