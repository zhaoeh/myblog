/**
 * 1. 定时任务，基于 XXL-Job 实现。
 * 2. 异步任务，采用 Spring Async 异步执行。
 */
package jp.co.futech.framework.quartz;
