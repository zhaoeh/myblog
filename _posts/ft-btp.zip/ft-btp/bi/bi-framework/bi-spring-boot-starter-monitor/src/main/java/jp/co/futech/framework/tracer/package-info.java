/**
 * 使用 SkyWalking 组件，作为链路追踪、日志中心。
 *
 * @author futech.co.jp
 */
package jp.co.futech.framework.tracer;
