/**
 * 基于部门的数据权限规则
 *
 * @author futech.co.jp
 */
package jp.co.futech.framework.datapermission.core.rule.dept;
