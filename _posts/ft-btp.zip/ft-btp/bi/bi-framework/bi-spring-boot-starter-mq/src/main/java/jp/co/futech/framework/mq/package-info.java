/**
 * 消息队列，支持 Redis、RocketMQ、RabbitMQ、Kafka 四种
 */
package jp.co.futech.framework.mq;
