/**
 * 占位符，无特殊逻辑
 */
package jp.co.futech.framework.mq.rabbitmq.core;