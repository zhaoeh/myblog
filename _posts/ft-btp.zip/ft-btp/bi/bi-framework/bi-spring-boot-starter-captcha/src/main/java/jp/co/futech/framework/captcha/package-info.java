/**
 * 验证码拓展
 * 1. 基于 aj-captcha 实现滑块验证码，文档：https://ajcaptcha.beliefteam.cn/captcha-doc/
 *
 * @author 星语
 */
package jp.co.futech.framework.captcha;
