package jp.co.futech.module.anomaly.service;

import jp.co.futech.module.anomaly.vo.DemoReqVO;

/**
 * @description: demo service
 * @author: ErHu.Zhao
 * @create: 2024-06-07
 **/
public interface DemoService {

    Long testDemo(DemoReqVO testVO);

}
