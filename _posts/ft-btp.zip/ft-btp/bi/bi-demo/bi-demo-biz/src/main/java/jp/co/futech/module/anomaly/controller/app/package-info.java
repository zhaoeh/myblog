/**
 * 占位，构建app包，以供c端进行rest访问
 */
package jp.co.futech.module.anomaly.controller.app;
