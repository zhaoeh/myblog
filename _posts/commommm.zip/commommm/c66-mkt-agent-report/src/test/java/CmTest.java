// import com.mkt.agent.common.entity.api.integration.bi.responses.UserGameSummerResponse;
// import com.mkt.agent.common.enums.GameTypeEnum;
//
// import java.math.BigDecimal;
// import java.util.ArrayList;
// import java.util.List;
// import java.util.stream.Collectors;
//
// public class CmTest {
//
//     public static void main(String[] args) {
//
//         List<UserGameSummerResponse> allData = new ArrayList<>();
//         UserGameSummerResponse v1 = new UserGameSummerResponse();
//         v1.setGameType("1");
//         v1.setTurnoverSum(BigDecimal.valueOf(500));
//         v1.setGgrSum(BigDecimal.valueOf(100));
//
//         UserGameSummerResponse v2 = new UserGameSummerResponse();
//         v2.setGameType("22");
//         v2.setTurnoverSum(BigDecimal.valueOf(500));
//         v2.setGgrSum(BigDecimal.valueOf(100));
//         allData.add(v1);
//         allData.add(v2);
//
//         List<UserGameSummerResponse> transformedData = allData.stream()
//                 .peek(data -> {
//                     if (GameTypeEnum.Sport_22.getValue().toString().equals(data.getGameType())) {
//                         // Convert Sport_22 to Sport
//                         data.setGameType(GameTypeEnum.Sport.getValue().toString());
//                     }
//                 })
//                 .collect(Collectors.toList());
//
//         List<UserGameSummerResponse> resultData = new ArrayList<>();
//         transformedData.stream().collect(Collectors.groupingBy(UserGameSummerResponse::getGameType))
//                 .forEach((gameType, list) -> {
//                     UserGameSummerResponse gameTypeSum = new UserGameSummerResponse();
//                     String gameTypeStr = GameTypeEnum.getNameByCode(Integer.valueOf(gameType));
//                     gameTypeSum.setGameType(gameTypeStr);
//                     gameTypeSum.setTurnoverSum(BigDecimal.ZERO);
//                     gameTypeSum.setGgrSum(BigDecimal.ZERO);
//                     gameTypeSum.setOutcomeSum(BigDecimal.ZERO);
//                     for (UserGameSummerResponse userGameSummerResponse : list) {
//                         gameTypeSum.setTurnoverSum(addBigDecimal(gameTypeSum.getTurnoverSum(), userGameSummerResponse.getTurnoverSum()));
//                         gameTypeSum.setGgrSum(addBigDecimal(gameTypeSum.getGgrSum(), userGameSummerResponse.getGgrSum()));
//                         gameTypeSum.setOutcomeSum(addBigDecimal(gameTypeSum.getOutcomeSum(), userGameSummerResponse.getOutcomeSum()));
//                     }
//                     resultData.add(gameTypeSum);
//                 });
//
//         System.out.println(resultData);
//     }
//     private static BigDecimal addBigDecimal(BigDecimal source, BigDecimal target) {
//         source = source == null ? BigDecimal.ZERO : source;
//         return source.add(target == null ? BigDecimal.ZERO : target);
//     }
// }
