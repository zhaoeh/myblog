package com.mkt.agent.report.utils;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.userapi.requests.AgentListRequest;;
import com.mkt.agent.report.fegin.AgentApiClient;
import com.mkt.agent.report.fegin.UserFeignService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.List;
import java.util.stream.Collectors;

/*** @program: mkt
 ** @description: 校验上下级
 ** @author: hongwei
 ** @create: 2023-12-07 16:39
 **/
@Component
public class AgentLevelUtil {


    @Autowired
    private UserFeignService userFeignService;
    @Autowired
    private AgentApiClient agentApiClient;
    /**
     * 判断被查寻用户是否存在登录用户下级
     * @param parentName
     * @param agentAccount
     * @return
     */
    public boolean agentAccountExist(String parentName, String agentAccount) {
        if (parentName.equals(agentAccount)) {
            return true;
        } else {
            AgentListRequest agentListRequest = new AgentListRequest();
            agentListRequest.setRootParentName(parentName);
            agentListRequest.setIsQueryTree(true);
            Result<List<TAgentCustomers>> listResult = agentApiClient.getAgentList(agentListRequest);
            if (listResult.getData().size() > 0) {
                List<String> payers = listResult.getData().stream().map(TAgentCustomers::getLoginName).collect(Collectors.toList()); //查詢代理下的用戶数据
                boolean match = payers.stream().anyMatch(str -> str.equals(agentAccount));
                return match;
            }else {
                return false;
            }
        }
    }
}
