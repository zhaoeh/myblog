package com.mkt.agent.report.mapper;

import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse;
import com.mkt.agent.report.req.TAgentCustomers;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface UserMapper {


    List<TCustomerLayer> selectUserTreeByParentNTime (
            @Param("parent") String parent, @Param("createTimeStart") String createTimeStart, @Param("createTimeEnd") String createTimeEnd);

    Long getPlayReportDataAp(Map<String, Object> parame);

    List<PlayerReportResponse> getPlayReportDataApList(Map<String, Object> parame);

    Long getPlayReportDataBp(Map<String, Object> parame);

    List<PlayerReportResponse> getPlayReportDataBpList(Map<String, Object> parame);

    Long getPlayReportDataGp(Map<String, Object> parame);

    List<PlayerReportResponse> getPlayReportDataGpList(Map<String, Object> parame);

    Long selectUserTreeByParentNTimeByCount( @Param("parent") String parent, @Param("playerAccount") String playerAccount);

    TAgentCustomers getUserData(Map<String, Object> ppp);

    Long getPlayCountUserAp(Map<String, Object> parame);

    Long getPlayCountUserBp(Map<String, Object> parame);

    Long getPlayCountUserGp(Map<String, Object> parame);

    CommissionRecordDashBoardResponse getPlayCountUserApOther(Map<String, Object> parame);

    CommissionRecordDashBoardResponse getPlayCountUserBpOther(Map<String, Object> parame);

    CommissionRecordDashBoardResponse getPlayCountUserGpOther(Map<String, Object> parame);
}
