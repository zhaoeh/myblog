package com.mkt.agent.report.req;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
@ApiModel(description = "t_team_report_history_type")
@TableName("t_team_report_history_type")
public class TeamReportHistoryType {
    private String loginNameDate ;
    private String id ;

    private BigDecimal turnover ;
    private BigDecimal ggr ;
    private BigDecimal winorloss ;

    private String gameType ;

    public String getId() {
        return id;
    }

    public String getGameType() {
        return gameType;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setGameType(String gameType) {
        this.gameType = gameType;
    }

    public String getLoginNameDate()  {


        return loginNameDate;
    }

    public BigDecimal getTurnover() {
        if(turnover == null) {
            turnover  =  new BigDecimal(0) ;
        }
        return turnover;
    }

    public BigDecimal getGgr() {
        if(ggr == null) {
            ggr  =  new BigDecimal(0) ;
        }

        return ggr;
    }

    public BigDecimal getWinorloss() {
        if(winorloss == null) {
            winorloss  =  new BigDecimal(0) ;
        }
        return winorloss;
    }

    public void setLoginNameDate(String loginNameDate) {
        this.loginNameDate = loginNameDate;
    }


    public void setTurnover(BigDecimal turnover) {
        this.turnover = turnover;
    }

    public void setGgr(BigDecimal ggr) {
        this.ggr = ggr;
    }

    public void setWinorloss(BigDecimal winorloss) {
        this.winorloss = winorloss;
    }
}
