package com.mkt.agent.report.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description TODO
 * @Classname A2PTransferMapper
 * @Date 2023/6/22 13:38
 * @Created by TJSLucian
 */
@Mapper
public interface BatchInsertCommonMapper<T> extends BaseMapper<T> {


    // 批量插入
    int insertBatchSomeColumn(@Param("list") List<T> batchList);

}
