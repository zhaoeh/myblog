package com.mkt.agent.report.utils;

import com.google.common.collect.Lists;
import com.mkt.agent.common.config.DashBoardConfig;
import com.mkt.agent.common.config.PlayerReportConfig;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.dto.TAgentCountGroupMonthDTO;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.api.reportapi.PlayerReportResponseVo1;
import com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonth;
import com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonthVo1;
import com.mkt.agent.common.entity.api.reportapi.requests.PlayerReportRequest;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.base.ReportPageResponse;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.player.model.PlayerOperatorModel;
import com.mkt.agent.common.utils.*;
import com.mkt.agent.report.clickhouse.mapper.ClDashBoardV1Mapper;
import com.mkt.agent.report.exception.MKTRportException;
import com.mkt.agent.report.fegin.AgentApiClient;
import com.mkt.agent.report.fegin.UserFeignService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;


@Component
@Slf4j
public class PlayerReportByMonthUtil {

    @Autowired
    private AgentApiClient agentApiClient;

    @Value("${playerReport.batchSizeByMonth:5000}")
    private Integer batchSizeByMonth;

    @Value("${playerReport.threadPoolSize:5}")
    private Integer threadPoolSize;

    private static ExecutorService executorService;

    private final ClDashBoardV1Mapper clDashBoardV1Mapper;

    private final PlayerReportUtil playerReportUtil;

    private final PlayerReportConfig config;

    public PlayerReportByMonthUtil(ClDashBoardV1Mapper clDashBoardV1Mapper, PlayerReportUtil playerReportUtil,PlayerReportConfig config) {
        this.clDashBoardV1Mapper = clDashBoardV1Mapper;
        this.playerReportUtil = playerReportUtil;
        this.config = config;
    }

    @PostConstruct
    public void initTheadPool() {
        log.info("begin to init thread pool of PlayerReportByMonthUtil");
        executorService = Executors.newFixedThreadPool(this.threadPoolSize);
        log.info("end to init thread pool of PlayerReportByMonthUtil, threadPoolSize is {}", this.threadPoolSize);
    }

    public void getResponseForOne(ReportPageResponse<PlayerReportResponse> response, String startDate, String endDate, String loginName){
        log.info("[getResponseForOne]The params are: startDate:{},endDate:{},loginName:{}",startDate,endDate,loginName);
        List<String> monthList = DateUtils.getMonthRangeForStr(startDate, endDate);
        if(CollectionUtils.isEmpty(monthList)){
            log.info("[getResponseForOne]get monthList failed!");
            return;
        }
        //封装查询条件
        List<PlayerReportResponse> playerReportResponseList = this.getPlayerReportResponseByMonth(this.buildQueryReqListForOne(monthList,loginName));

        if(CollectionUtils.isEmpty(playerReportResponseList)){
            log.info("[getResponseForOne]The data after querying is null!");
            return;
        }
        response.setTotal(playerReportResponseList.size());
        response.setRecords(playerReportResponseList);
        response.setPages(1L);
    }

    /**
     * description: 根据传入的条件获取需要进行查询的代理名称列表
     * @param:  [parent, agentAccount, level]
     * @return: java.util.List<java.lang.String>
     * @Date: 2024/2/6 14:03
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public List<String> getAgentNameListByNameNLevel(PlayerReportRequest req,Boolean totalCountFlag){

        if(totalCountFlag){
            return List.of(req.getLoginName());
        }

        String parentAccount = Objects.isNull(req.getParentAccount()) ? "" : req.getParentAccount();
        String agentAccount = Objects.isNull(req.getPlayerAccount()) ? "" : req.getPlayerAccount();
        Integer level = Objects.isNull(req.getParentLevel()) ? 0 : Integer.parseInt(req.getParentLevel());

        Result<List<String>> agentNameListResult = agentApiClient.getAgentNameListByNameNLevel(req.getLoginName(),parentAccount,agentAccount,level);

        if(!agentNameListResult.isSuccess() || CollectionUtils.isEmpty(agentNameListResult.getData())){
            return null;
        }

        return agentNameListResult.getData();

    }


    /**
     * description: 根据下标确定查询clickhouse的封装条件
     * @param:  [groupMonthList, startIndex, endIndex, totalCountFlag, teamNameList]
     * @return: java.util.List<com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq>
     * @Date: 2024/2/6 14:04
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public List<ClDashBoardCreateQueryReq> getQueryReqList(List<TAgentCountGroupMonth> groupMonthList, Integer startIndex, Integer endIndex, Boolean totalCountFlag, List<String> teamNameList, TAgentCountGroupMonthDTO dto){

        if(CollectionUtils.isEmpty(groupMonthList) || CollectionUtils.isEmpty(teamNameList)){
            return null;
        }

        //封装条件
        List<ClDashBoardCreateQueryReq> queryReqList = new ArrayList<>();

        //按照下标计算
        Integer minusCount = 0;
        int addCount = 0;

        for(int i=0; i<groupMonthList.size(); i++){

            TAgentCountGroupMonth next = groupMonthList.get(i);

            if(totalCountFlag){
                minusCount = minusCount + next.getTotalCount();
            }else {
                minusCount = minusCount + next.getDirectCount();
            }

            if(startIndex <= minusCount){

                addCount = addCount + 1;
                queryReqList.add(ClDashBoardCreateQueryReq.builder().loginNameList(teamNameList)
                        .recordDateStart(DateUtils.getFirstDayOfMonth(next.getAgentMonth()).toString())
                        .recordDateEnd(DateUtils.getLastDayOfMonth(next.getAgentMonth()).toString())
                        .agentMonth(next.getAgentMonth()).build());

                if(addCount == 1){
                    dto.setMinusCount(totalCountFlag ? minusCount - next.getTotalCount() : minusCount - next.getDirectCount());
                }

                if(endIndex <= minusCount){
                    break;
                }

            }


        }

        return queryReqList;
    }

    /**
     * description: 根据下标截取目标列表，返回原列表的映射
     * @param:  [responseList, startIndex, endIndex]
     * @return: java.util.List<com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse>
     * @Date: 2024/2/6 15:08
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public List<PlayerReportResponse> cutPlayerReportResponse(List<PlayerReportResponse> responseList,Integer startIndex, Integer pageSize,TAgentCountGroupMonthDTO dto){

        if(CollectionUtils.isEmpty(responseList)){
            return Collections.emptyList();
        }

        //计算原始下标在查询出的结果里的真实下标
        Integer minusCount = dto.getMinusCount();
        log.info("[cutPlayerReportResponse] The minusCount is:{}", minusCount);
        startIndex = startIndex - minusCount;
        Integer endIndex = startIndex + pageSize - 1;

        log.info("[cutPlayerReportResponse] The real startIndex is:{}",startIndex);

        if(!CollectionUtils.isEmpty(responseList) && startIndex >= 0 && startIndex < responseList.size()){
            return responseList.subList(startIndex,endIndex >= responseList.size() ? responseList.size() : endIndex + 1);
        }
        return Collections.emptyList();
    }

    /**
     * description: 前端输入playerAccount条件后的 封装查询条件
     * @param:  [monthList, playerAccount]
     * @return: java.util.List<com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq>
     * @Date: 2024/2/6 16:00
     * @Version: 1.0.0
     * @Author: Lucian
     */
    private List<ClDashBoardCreateQueryReq> buildQueryReqListForOne(List<String> monthList,String playerAccount){

        if(CollectionUtils.isEmpty(monthList) || Objects.isNull(playerAccount)){
            return null;
        }
        log.info("[buildQueryReqListForOne]The params are: playerAccount:{}, monthList:{}",playerAccount,Arrays.toString(monthList.toArray()));
        //封装条件
        List<ClDashBoardCreateQueryReq> queryReqList = new ArrayList<>();

        monthList.forEach(month -> {

            queryReqList.add(ClDashBoardCreateQueryReq.builder().loginNameList(List.of(playerAccount))
                    .recordDateStart(DateUtils.getFirstDayOfMonth(month).toString())
                    .recordDateEnd(DateUtils.getLastDayOfMonth(month).toString())
                    .agentMonth(month).build());

        });

        log.info("[buildQueryReqListForOne]after building queryReq is:{}",Arrays.toString(queryReqList.toArray()));

        return queryReqList;
    }



    private Future<PlayerReportResponseVo1> submitTaskForPlayerByMonth(PlayerReportResponseVo1 vo1){

        if(Objects.isNull(vo1)){
            return null;
        }

        Future<PlayerReportResponseVo1> vo1Future = this.executorService.submit(() ->{

            try {
                List<PlayerReportResponse> record = this.doSearchByMonth(vo1.getQueryReq());
                vo1.setResList(record);
                vo1.setAsyncSucess(true);
            }catch (Exception e){
                log.error("Error while async querying ck!");
                vo1.setAsyncSucess(false);
            }

            return vo1;
        });

        return vo1Future;
    }


    /**
     * description: 执行异步查询 提交任务 返回成功后的结果
     * @param:  [queryReq, asyncLimit]
     * @return: java.util.List<com.mkt.agent.common.entity.api.reportapi.PlayerReportResponseVo1>
     * @Date: 2024/3/19 14:50
     * @Version: 1.0.0
     * @Author: Lucian
     */
    private List<PlayerReportResponseVo1> doAsyncQueryByMonth(ClDashBoardCreateQueryReq queryReq, Integer asyncLimit){

        List<String> loginNameList = queryReq.getLoginNameList();

        //拆分任务
        List<List<String>> partLoginNameList = Lists.partition(loginNameList,asyncLimit);

        //提交任务
        List<Future<PlayerReportResponseVo1>> futureList = partLoginNameList.stream().map(p -> submitTaskForPlayerByMonth(PlayerReportResponseVo1.builder().queryReq(ClDashBoardCreateQueryReq.builder().recordDateStart(queryReq.getRecordDateStart())
                .recordDateEnd(queryReq.getRecordDateEnd()).agentMonth(queryReq.getAgentMonth()).loginNameList(p).build()).build())).collect(Collectors.toList());

        //获取任务结果
        List<PlayerReportResponseVo1> vo1List = getResultFromFuture(futureList);

        if(CollectionUtils.isEmpty(vo1List)){
            return null;
        }

        List<PlayerReportResponseVo1> response = new ArrayList<>();

        //获取成功的任务
        List<PlayerReportResponseVo1> sucessedList = vo1List.stream().filter(PlayerReportResponseVo1::isAsyncSucess).collect(Collectors.toList());
        if(!CollectionUtils.isEmpty(sucessedList)){
            response.addAll(sucessedList);
        }

        //获取失败的任务
        List<PlayerReportResponseVo1> failedList = vo1List.stream().filter(v -> !v.isAsyncSucess()).collect(Collectors.toList());
        if(!CollectionUtils.isEmpty(failedList)){
            //处理失败任务
            List<PlayerReportResponseVo1> retryResList = doAsyncQueryWithRetry(failedList);
            if(!CollectionUtils.isEmpty(retryResList)){
                response.addAll(retryResList);
            }
        }

        return response;

    }

    /**
     * description: 处理失败的任务
     * @param:  [failedList]
     * @return: java.util.List<com.mkt.agent.common.entity.api.reportapi.PlayerReportResponseVo1>
     * @Date: 2024/3/19 14:51
     * @Version: 1.0.0
     * @Author: Lucian
     */
    private List<PlayerReportResponseVo1> doAsyncQueryWithRetry(List<PlayerReportResponseVo1> failedList){

        if(!CollectionUtils.isEmpty(failedList)){
            return null;
        }

        List<PlayerReportResponseVo1> response = new ArrayList<>();

        for(int i=0; i < config.getRetryTimeWithFailedTask(); i++){
            List<Future<PlayerReportResponseVo1>> futureList = failedList.stream().map(f -> submitTaskForPlayerByMonth(f)).collect(Collectors.toList());

            //获取任务结果
            List<PlayerReportResponseVo1> vo1List = getResultFromFuture(futureList);

            List<PlayerReportResponseVo1> sucessedList = vo1List.stream().filter(PlayerReportResponseVo1::isAsyncSucess).collect(Collectors.toList());
            if(!CollectionUtils.isEmpty(sucessedList)){
                response.addAll(sucessedList);
            }

            List<PlayerReportResponseVo1> partFailedList = vo1List.stream().filter(v -> !v.isAsyncSucess()).collect(Collectors.toList());
            if(CollectionUtils.isEmpty(partFailedList)){
                return response;
            }

            failedList = partFailedList;

            if(i > 1){
                try {
                    Thread.currentThread().sleep(2000);
                }catch (InterruptedException e) {
                    log.error("Interrupted!", e);
                    // Restore interrupted state...
                    Thread.currentThread().interrupt();
                }catch (Exception ignoredSleep){
                    log.error("Failed to make thread sleep while retrying async query. Now pass it and keep on querying!",ignoredSleep);
                }

            }

        }

        if(CollectionUtils.isEmpty(response)){
            response = null;
            return null;
        }

        return response;

    }


    private List<PlayerReportResponseVo1> getResultFromFuture(List<Future<PlayerReportResponseVo1>> futureList){

        if(CollectionUtils.isEmpty(futureList)){
            return null;
        }

        List<PlayerReportResponseVo1> vo1List = futureList.stream().map(f -> {
            try {
                return f.get();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
            return null;
        }).filter(Objects::nonNull).collect(Collectors.toList());

        return vo1List;

    }


    /**
     * description: 异步查询 获取结果
     * @param:  [agentAccount, queryReqList, asyncLimit, response]
     * @return: java.util.List<com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse>
     * @Date: 2024/3/19 13:42
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public List<PlayerReportResponse> getPlayerReportResponseByMonthAsync(String agentAccount,List<ClDashBoardCreateQueryReq> queryReqList, Integer asyncLimit){

        if(CollectionUtils.isEmpty(queryReqList)){
            return null;
        }

        log.info("[getPlayerReportResponseByMonthAsync]Begin to query ck async for agent:{}",agentAccount);

        List<PlayerReportResponse> responses = new ArrayList<>();

        for(int i=0; i < queryReqList.size(); i++){

            try {
                //执行异步查询
                List<PlayerReportResponseVo1> recordList = doAsyncQueryByMonth(queryReqList.get(i),asyncLimit);

                if(!CollectionUtils.isEmpty(recordList)){
                    List<PlayerReportResponse> monthRes = recordList.stream().map(r -> r.getResList()).filter(Objects::nonNull).reduce((r1,r2) -> Stream.concat(r1.stream(),r2.stream()).collect(Collectors.toList())).orElse(null);
                    if(!CollectionUtils.isEmpty(monthRes)){
                        responses.addAll(monthRes);
                    }
                }

            }catch (Exception e){
                log.error("Failed to query ck async for agent:{}",agentAccount,e);
            }
            //超过最大查询条数 停止
            if(responses.size() >= BaseConstants.PLAYER_REPORT_MAX_PAGECOUNT){
                break;
            }

        }

        if(CollectionUtils.isEmpty(responses)){
            responses = null;
            return null;
        }

        playerReportUtil.sortPlayerReportResponse(responses);
        return responses;
    }


    /*public List<PlayerReportResponse> getPlayerReportResponseByMonthAsync(String agentAccount,List<ClDashBoardCreateQueryReq> queryReqList, Integer asyncLimit,List<PlayerReportResponse> response){

        if(CollectionUtils.isEmpty(queryReqList)){
            return response;
        }

        log.info("Begin to query ck async for agent:{}",agentAccount);

        for(int i=0; i < queryReqList.size(); i++){

            try {

                ClDashBoardCreateQueryReq currentQueryReq = queryReqList.get(i);
                List<String> loginNameList = currentQueryReq.getLoginNameList();

                List<List<String>> partLoginNameList = Lists.partition(loginNameList,asyncLimit);

                int count = partLoginNameList.size();
                CountDownLatch latch = new CountDownLatch(count);
                log.info("The async partition size for PlayerReportByMonthUtil for agent:{}, userNameList size is:{}",agentAccount,count);
                List<Future<List<PlayerReportResponse>>> futureRecords = IntStream.range(0, count)
                        .mapToObj(index -> this.executorService.submit(() -> {
                            log.info("Begin to handle the partList:{}",index);
                            try {
                                List<String> mockLoginNameList = partLoginNameList.get(index);
                                currentQueryReq.setLoginNameList(mockLoginNameList);
                                List<PlayerReportResponse> mockRes = this.doSearchByMonth(currentQueryReq);
                                latch.countDown();
                                return mockRes;
                            } catch (Exception ignored) {
                                log.error("Failed to async query from CK for index:{}!",index,ignored);
                                latch.countDown();
                                return null;
                            }

                        })).collect(Collectors.toList());
                latch.await();

                List<PlayerReportResponse> asyncRecord = futureRecords.stream().map(f -> {
                    try {
                        return f.get();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    }
                    return null;
                }).filter(Objects::nonNull).reduce((r1,r2) -> Stream.concat(r1.stream(),r2.stream()).collect(Collectors.toList())).orElse(Collections.emptyList());

                if(!CollectionUtils.isEmpty(asyncRecord)){
                    response.addAll(asyncRecord);
                }

                if(response.size() >= BaseConstants.PLAYER_REPORT_MAX_PAGECOUNT){
                    break;
                }

            }catch (Exception e){
                log.error("Failed to query ck async for agent:{}",agentAccount,e);
            }

        }
        playerReportUtil.sortPlayerReportResponse(response);
        return response;
    }*/


    public List<PlayerReportResponse> getPlayerReportResponseByMonth(List<ClDashBoardCreateQueryReq> queryReqList){
        if(CollectionUtils.isEmpty(queryReqList)){
            return null;
        }

        log.info("[getPlayerReportResponseByMonth]The queryReqList is:{}",Arrays.toString(queryReqList.toArray()));

        List<PlayerReportResponse> responses = new ArrayList<>();
        queryReqList.stream().sorted(Comparator.comparing(ClDashBoardCreateQueryReq::getAgentMonth).reversed());

        for(int i=0; i<queryReqList.size(); i++){
            List<PlayerReportResponse> record = doSearchByMonth(queryReqList.get(i));
            if(!CollectionUtils.isEmpty(record)){
                responses.addAll(record);
            }
            if(responses.size() >= BaseConstants.PLAYER_REPORT_MAX_PAGECOUNT){
                break;
            }
        }

        if(CollectionUtils.isEmpty(responses)){
            responses = null;
            return null;
        }
        log.info("[getPlayerReportResponseByMonth]After querying the response is:{}",responses);

        return responses;
    }

    /**
     * description: 根据传入条件查询clickhouse 获取按月维度的玩家数据
     * @param:  [queryReqList]
     * @return: java.util.List<com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse>
     * @Date: 2024/2/6 14:08
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public List<PlayerReportResponse> doSearchByMonth(ClDashBoardCreateQueryReq queryReq){

        if(Objects.isNull(queryReq)){
            return Collections.emptyList();
        }
        log.info("[doSearchByMonth]Begin to search from CK!");

        List<PlayerReportResponse> responseList = new ArrayList<>();

        if (queryReq.getLoginNameList().size() <= batchSizeByMonth) {
            List<PlayerReportResponse> smallTeamResponse = clDashBoardV1Mapper.queryPlayerReportByMonth(queryReq);
            if(!CollectionUtils.isEmpty(smallTeamResponse)){
                responseList.addAll(smallTeamResponse);
                playerReportUtil.sortPlayerReportResponse(responseList);
            }
        } else {

            List<List<String>> batches = Lists.partition(queryReq.getLoginNameList(), batchSizeByMonth);

            List<ClDashBoardCreateQueryReq> batchQuerys = batches.stream().map(b -> ClDashBoardCreateQueryReq.builder()
                    .loginNameList(b).recordDateStart(queryReq.getRecordDateStart()).recordDateEnd(queryReq.getRecordDateEnd())
                    .agentMonth(queryReq.getAgentMonth()).build()).collect(Collectors.toList());

            for(int j=0; j<batchQuerys.size(); j++){
                ClDashBoardCreateQueryReq q = batchQuerys.get(j);
                List<PlayerReportResponse> partResponse = clDashBoardV1Mapper.queryPlayerReportByMonth(q);
                if(!CollectionUtils.isEmpty(partResponse)){
                    responseList.addAll(partResponse);
                }

                if(responseList.size() > BaseConstants.PLAYER_REPORT_MAX_PAGECOUNT){
                    playerReportUtil.sortPlayerReportResponse(responseList);
                    responseList = responseList.subList(0,BaseConstants.PLAYER_REPORT_MAX_PAGECOUNT);
                }
            }

        }


        return responseList;

    }


}
