package com.mkt.agent.report.component;

import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse;
import com.mkt.agent.common.player.core.PlayerCache;
import com.mkt.agent.common.player.model.PlayerOperatorModel;
import com.mkt.agent.common.player.model.TAgentCountGroup;
import com.mkt.agent.common.player.processor.TransProcessor;
import com.mkt.agent.common.utils.CommonUtil;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.report.clickhouse.mapper.ClDashBoardV1Mapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @description: 按天维度查询某一页的玩家详情数据(分阶段查询和直接查询两种策略)
 * @author: ErHu.Zhao
 * @create: 2024-02-05
 **/
@Component
@Slf4j
public class PlayerForPageQueryByDay {

    private final Integer threadPoolSize;
    private final ClDashBoardV1Mapper clDashBoardV1Mapper;
    private final TransProcessor transProcessor;
    private final PlayerCache playerCache;
    private ExecutorService executorService;

    @PostConstruct
    public void init() {
        if (Objects.isNull(executorService)) {
            log.info("begin init executorService in PlayerForPageQueryByDay");
            executorService = Executors.newFixedThreadPool(this.threadPoolSize);
            log.info("end init executorService in PlayerForPageQueryByDay");
        }
    }

    public PlayerForPageQueryByDay(@Value("${playerReport.threadPoolSize:5}")Integer threadPoolSize, ClDashBoardV1Mapper clDashBoardV1Mapper, TransProcessor transProcessor, PlayerCache playerCache) {
        this.threadPoolSize = threadPoolSize;
        this.clDashBoardV1Mapper = clDashBoardV1Mapper;
        this.transProcessor = transProcessor;
        this.playerCache = playerCache;
    }

    /**
     * 异步查询
     *
     * @param model
     * @return
     */
    public List<PlayerReportResponse> queryPlayerInfoByDayWithAsync(PlayerOperatorModel model) {
        TAgentCountGroup queryReq = buildQueryParam(model);
        List<PlayerReportResponse> responses = supplyPlayerResponse(queryReq, executorService);
        log.info("responses size from BI is {}", responses.size());
        return responses;
    }

    /**
     * 同步查询（增加缓存）
     *
     * @param model
     * @return
     */
    public List<PlayerReportResponse> queryPlayerInfoByDay(PlayerOperatorModel model) {
        List<PlayerReportResponse> responses = new ArrayList<>();
        TAgentCountGroup queryReq = buildQueryParam(model);

        // today data
        List<PlayerReportResponse> todayData = null;
        String today = DateUtils.localDateToString(DateUtils.getNDaysAgo(0));
        int todayDate = CommonUtil.convertToInt(today);
        if (queryReq.getEndDate().equals(today)) {
            queryReq.setEndDate(DateUtils.localDateToString(DateUtils.getNDaysAgo(1)));
            log.info("开始查询今天的交易明细");
            TAgentCountGroup todayQuery = TAgentCountGroup.builder().agentName(model.getAgentName()).beginDate(today).
                    endDate(today).queryUsers(queryReq.getQueryUsers()).build();
            todayData = supplyPlayerResponse(todayQuery, null);
        }

        // before data
        List<PlayerReportResponse> beforeData = null;
        int beginDate = CommonUtil.convertToInt(queryReq.getBeginDate());
        if (beginDate < todayDate) {
            log.info("开始查询今天之前的历史交易明细");
            String cacheKey = playerCache.obtainCacheKey(model.getPrepareKey(), queryReq.getBeginDate(), queryReq.getEndDate());
            beforeData = playerCache.obtainPlayersByDay(cacheKey);
            if (Objects.isNull(beforeData)) {
                beforeData = supplyPlayerResponse(queryReq, null);
            }
            // 更新缓存
            playerCache.cachePlayersByDay(cacheKey, beforeData);
        }
        if (!CollectionUtils.isEmpty(todayData)) {
            responses.addAll(todayData);
        }
        if (!CollectionUtils.isEmpty(beforeData)) {
            responses.addAll(beforeData);
        }
        log.info("responses size from BI is {}", responses.size());
        return responses;
    }

    private TAgentCountGroup buildQueryParam(PlayerOperatorModel model){
        List<String> targetUsers = model.getTargetQueryUsers();
        if (model.isDirectQuery()) {
            log.info("直接输入player account，直接查询BI");
            // 直接查询
            return TAgentCountGroup.builder().agentName(model.getAgentName()).beginDate(model.getBeginDate()).endDate(model.getEndDate()).queryUsers(targetUsers).build();
        } else {
            // 分阶段查询某一页数据
            List<String> targetDates = model.getTargetDates();
            log.info("其他条件分阶段查询，targetDates is {}", targetDates);
            String beginDate = targetDates.get(0);
            String endDate = targetDates.get(targetDates.size() - 1);
            return TAgentCountGroup.builder().agentName(model.getAgentName()).beginDate(beginDate).endDate(endDate).queryUsers(targetUsers).build();
        }
    }

    private List<PlayerReportResponse> supplyPlayerResponse(TAgentCountGroup param, ExecutorService executorService) {
        return transProcessor.batchQueryTransDetails(clDashBoardV1Mapper::queryPlayerReportByDay, param, executorService);
    }

}
