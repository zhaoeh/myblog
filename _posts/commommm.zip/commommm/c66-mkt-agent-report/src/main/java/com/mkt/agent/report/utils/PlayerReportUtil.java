package com.mkt.agent.report.utils;

import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.reportapi.requests.PlayerReportRequest;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse;
import com.mkt.agent.common.entity.clickhouse.req.DashBoardUserTreeQueryReq;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.UserContext;
import com.mkt.agent.report.exception.MKTRportException;
import com.mkt.agent.report.fegin.AgentApiClient;
import com.mkt.agent.report.fegin.UserFeignService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;




@Component
@Slf4j
public class PlayerReportUtil {


    @Autowired
    private UserFeignService userFeignService;

    @Autowired
    private AgentApiClient agentApiClient;

    /**
     * 判断用户指定的 Account 是否满足查询条件（parentAccount, parentLevel, 团队成员）
     * @param req
     * @return
     */
    public boolean checkIfPlayerMeetCondition(PlayerReportRequest req){
        String playerAccount = req.getPlayerAccount();

        Result<TCustomerLayer> playerInfoResult = userFeignService.getNotDeletedOneByLoginName(playerAccount);

        /* 1.1 查询系统有无此用户 */
        if (playerInfoResult == null || playerInfoResult.getData() == null){
            return false;
        }
        TCustomerLayer customerLayer = playerInfoResult.getData();
        /* 1.2 用户指定了 parentAccount 条件但不符合 */
        if (StringUtils.isNotEmpty(req.getParentAccount()) && !req.getParentAccount().equals(customerLayer.getParentLoginName())){
            return false;
        }
        /* 1.3 用户指定了 parentLevel 条件但不符合 */
        if (StringUtils.isNotEmpty(req.getParentLevel())){
            // select count(1) from t_agent_customers where login_name = #{playerInfoResult.getData().getParentLoginName()} AND is_deleted = 0 AND is_enable = 1 AND agent_level = #{req.getParentLevel()}
            Result<TAgentCustomers> tAgentCustomersResult = agentApiClient.selectParentAgentByNameAndLevelEnable(customerLayer.getParentLoginName(), req.getParentLevel());
            if (tAgentCustomersResult == null)
                throw new MKTRportException(ResultEnum.FAIL);
            if (tAgentCustomersResult.getData() == null)
            // count(1) == 0 ;
                return false;
        }

        /* 1.4 判断该查询到的玩家是否属于用户团队或自身 */
        // 属于用户自身，进行 clickhouse 查询列表分页数据
        if (playerAccount.equals(req.getLoginName()))
            return true;

        if(customerLayer.getCustomerType().equals(Constants.AGENT)){
            //查询代理系统
            Result<TAgentCustomers> agentResult = agentApiClient.getAgentByLoginName(req.getPlayerAccount());
            if(agentResult.isSuccess() && Objects.nonNull(agentResult.getData())){
                if(!agentResult.getData().getIsEnable().equals(BaseConstants.AGENTS_IS_ABLE)){
                    return false;
                }
            }
        }

        // 判断该玩家是否属于该当前登录用户团队成员, 如果不是返回 false
        if (playerIsNotTeamMember(req.getLoginName(), playerAccount)) {
            log.info("判断该玩家是否属于该当前登录用户团队成员, 如果不是返回 false: false");
            return false;
        }
        log.info("判断该玩家是否属于该当前登录用户团队成员, 如果不是返回 false: true");
        /* 1.5 用户都满足上诉条件，才进行 clickhouse 查询列表分页数据 */
        return true;
    }

    /**
     * 判断玩家是否属于上级代理团队成员（不包括上级代理自己
     * @param parentAccountName 上级账号名称
     * @param playerAccountName 玩家名称
     * @return true 则代表不属于
     */
    public boolean playerIsNotTeamMember(String parentAccountName, String playerAccountName) {
        if (StringUtils.isEmpty(parentAccountName) || StringUtils.isEmpty(playerAccountName)){
            throw new MKTRportException(ResultEnum.BAD_REQUEST);
        }
        Result<TCustomerLayer> subPlayerResult = userFeignService.selectUserFromParentTeam(parentAccountName, playerAccountName);
        log.info("判断该玩家是否属于该当前登录用户团队成员: {}", subPlayerResult);
        return subPlayerResult == null || subPlayerResult.getData() == null;
    }


    /**
     * description: 根据传入的代理列表获取代理团队 包含代理本身
     * @param:  [agentNameList, totalCountFlag]
     * @return: java.util.List<java.lang.String>
     * @Date: 2024/2/6 14:03
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public List<String> getTeamNameList(List<String> agentNameList,Boolean totalCountFlag){

        if(CollectionUtils.isEmpty(agentNameList)){
            return null;
        }

        DashBoardUserTreeQueryReq queryEntity = DashBoardUserTreeQueryReq.builder().parentList(agentNameList).build();

        Result<List<String>> teamNameResult = null;
        if(totalCountFlag){
            //获取团队用户
            teamNameResult = userFeignService.selectUserTreeByParentNTimeOfPart(queryEntity);

            if(Objects.nonNull(teamNameResult) && teamNameResult.isSuccess() && !CollectionUtils.isEmpty(teamNameResult.getData())){
                return teamNameResult.getData();
            }

            return agentNameList;

        }else {
            //获取直属用户
            teamNameResult = userFeignService.selectDirectUsersByParentListNTime(queryEntity);
            if(Objects.nonNull(teamNameResult) && teamNameResult.isSuccess() && !CollectionUtils.isEmpty(teamNameResult.getData())){
                return teamNameResult.getData();
            }
        }

        return null;
    }


    /**
     * description: 根据日期和用户名倒序排序
     * @param:  [responseList]
     * @return: void
     * @Date: 2024/2/6 14:58
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public void sortPlayerReportResponse(List<PlayerReportResponse> responseList){

        //排序
        if(!CollectionUtils.isEmpty(responseList)){

            Comparator<PlayerReportResponse> comparator = Comparator
                    .comparing(PlayerReportResponse::getAgentDate, Comparator.reverseOrder())
                    .thenComparing(PlayerReportResponse::getAccount, Comparator.reverseOrder());

            // 排序
            responseList.sort(comparator);

        }

    }

    public void selectParentNParentLevelByUsersForPReport(List<PlayerReportResponse> playerReportResponseList){

        if(CollectionUtils.isEmpty(playerReportResponseList)){
            return;
        }

        List<String> userNames = playerReportResponseList.stream().map(r -> r.getAccount()).collect(Collectors.toList());

        Result<List<PlayerReportResponse>> parentResponseResult = userFeignService.selectParentNParentLevelByUsersForPReport(userNames);

        if(parentResponseResult.isSuccess() && !CollectionUtils.isEmpty(parentResponseResult.getData())){

            List<PlayerReportResponse> parentResponse = parentResponseResult.getData();

            Map<String,PlayerReportResponse> parentMap = parentResponse.stream().collect(Collectors.toMap(PlayerReportResponse::getAccount, p -> p));

            playerReportResponseList.forEach(p -> {
                PlayerReportResponse parent = parentMap.get(p.getAccount());
                if(Objects.isNull(parent)){
                    p.setParent(BaseConstants.C66_ADMIN);
                    p.setParentLevel(BaseConstants.C66_ADMIN);
                }else {
                    p.setParent(parent.getParent());
                    p.setParentLevel(parent.getParentLevel());
                }
            });
        }else {
            playerReportResponseList.forEach(p -> {
                p.setParent(BaseConstants.C66_ADMIN);
                p.setParentLevel(BaseConstants.C66_ADMIN);
            });
        }

    }

    public TAgentCustomers selectAgentByName(String agentAccount){

        Result<TAgentCustomers> agentResult = agentApiClient.getAgentByLoginName(agentAccount);
        if(agentResult.isSuccess() && Objects.nonNull(agentResult.getData())){
            return agentResult.getData();
        }
        return null;
    }

}
