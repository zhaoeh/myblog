package com.mkt.agent.report.req;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import java.math.BigDecimal;
import java.util.Date;

public class TUserFinanceOrderTreed {

    private String recordDate  ;

    private String  loginName  ;

    private String gameType  ;

    private BigDecimal turnoverAmount  ;

    private BigDecimal ggrAmount  ;

    private BigDecimal outcomeAmount  ;

    private Date createTime  ;

    private Date updateTime  ;


    public void setRecordDate(String recordDate) {
        this.recordDate = recordDate;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public void setGameType(String gameType) {
        this.gameType = gameType;
    }

    public void setTurnoverAmount(BigDecimal turnoverAmount) {
        this.turnoverAmount = turnoverAmount;
    }

    public void setGgrAmount(BigDecimal ggrAmount) {
        this.ggrAmount = ggrAmount;
    }

    public void setOutcomeAmount(BigDecimal outcomeAmount) {
        this.outcomeAmount = outcomeAmount;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getRecordDate() {
        return recordDate;
    }

    public String getLoginName() {
        return loginName;
    }

    public String getGameType() {
        return gameType;
    }

    public BigDecimal getTurnoverAmount() {
        return turnoverAmount;
    }

    public BigDecimal getGgrAmount() {
        return ggrAmount;
    }

    public BigDecimal getOutcomeAmount() {
        return outcomeAmount;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }
}
