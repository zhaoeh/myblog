package com.mkt.agent.report.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonth;
import com.mkt.agent.common.entity.api.reportapi.requests.TAgentCountGroupMonthRequest;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description TODO
 * @Classname TAgentCountGroupMonthMapper
 * @Date 2024/2/5 15:06
 * @Created by TJSLucian
 */
@Mapper
public interface TAgentCountGroupMonthMapper extends BatchInsertCommonMapper<TAgentCountGroupMonth> {

    List<TAgentCountGroupMonth> queryGroupMonthListForThreeMonth(@Param("request") TAgentCountGroupMonthRequest request);

    List<TAgentCountGroupMonth> getDownlineAgentsData(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    Integer deleteGroupByNameNMonth(@Param("neededDeleteAgents") List<String> neededDeleteAgents, @Param("agentMonth")String agentMonth);
}
