package com.mkt.agent.report.service;


import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.reportapi.requests.PlayerReportRequest;
import com.mkt.agent.common.entity.api.reportapi.requests.TeamReportByGameRequest;
import com.mkt.agent.common.entity.api.reportapi.requests.TeamReportRequest;
import com.mkt.agent.common.entity.api.reportapi.requests.base.ReportBaseRequest;
import com.mkt.agent.common.entity.api.reportapi.responses.*;
import com.mkt.agent.common.entity.api.reportapi.responses.base.ReportBaseResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.base.ReportPageResponse;
import com.mkt.agent.common.entity.clickhouse.resp.ClDashBoardDataRes;
import com.mkt.agent.report.req.TAgentCustomers;
import com.mkt.agent.report.req.TUserFinanceOrderTreed;
import com.mkt.agent.report.req.TeamReportHistory;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface ReportService<Req extends ReportBaseRequest, Res extends ReportBaseResponse> {

    ReportPageResponse<Res> queryByPageAndCondition(Req req);

    TeamReportByGameResponse getGameReport(TeamReportByGameRequest req);

    List<TeamReportResponse> export(Req req);

    List<TeamReportResponse> exportHistory(Req req);

    ReportPageResponse<Res> history(TeamReportRequest req);

    List<TAgentCustomers> findAllAgent();

    public  void  setIsCache(String isCache);


    Object testClickHouse();

    TeamReportHistory getDataByDate(Date today, String loginName);

    TeamReportHistory getDataByMonth(Date firstMonth, Date endMonth, String loginName);

    List<TUserFinanceOrderTreed> getReport(String date, String loginName);

    List<TUserFinanceOrderTreed> getReport(Date min, Date max, String loginName);


    CommissionRecordDashBoardResponse getDashboardTeamSummary(TeamReportRequest req);

    ClDashBoardDataRes saveLocalData(Date date, int i, int i1, String loginName);

    ReportPageResponse<TeamReportResponse> queryPlayerByPageAndCondition(TeamReportRequest req);

    ReportPageResponse<PlayerReportResponse> playerQueryByPageAndCondition(PlayerReportRequest req);
}
