package com.mkt.agent.report.req;

import java.math.BigDecimal;

/**
 * 充值 和 提现数据
 */
public class TUserFinanceDwTreed {


  private String  recordDate  ;

    private String  loginName  ;

    private BigDecimal withdrawAmount  ;

    private BigDecimal  depositAmount  ;
    private String   createTime  ;
    private String  updateTime  ;

    public String getRecordDate() {
        return recordDate;
    }


    public BigDecimal getWithdrawAmount() {
        return withdrawAmount;
    }

    public BigDecimal getDepositAmount() {
        return depositAmount;
    }

    public String getCreateTime() {
        return createTime;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setRecordDate(String recordDate) {
        this.recordDate = recordDate;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public void setWithdrawAmount(BigDecimal withdrawAmount) {
        this.withdrawAmount = withdrawAmount;
    }

    public void setDepositAmount(BigDecimal depositAmount) {
        this.depositAmount = depositAmount;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }
}
