package com.mkt.agent.report.service.impl;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.gson.Gson;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.dto.TAgentCountGroupMonthDTO;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonth;
import com.mkt.agent.common.entity.api.reportapi.requests.PlayerReportByGameRequest;
import com.mkt.agent.common.entity.api.reportapi.requests.PlayerReportRequest;
import com.mkt.agent.common.entity.api.reportapi.requests.TAgentCountGroupMonthRequest;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportByGameResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.base.ReportPageResponse;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.player.model.PlayerOperatorModel;
import com.mkt.agent.common.player.model.TAgentCountGroup;
import com.mkt.agent.common.player.processor.TransProcessor;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.UserContext;
import com.mkt.agent.report.clickhouse.mapper.ClDashBoardV1Mapper;
import com.mkt.agent.report.component.QueryForDayDispatcher;
import com.mkt.agent.report.component.QueryForDayDispatcherNew;
import com.mkt.agent.report.exception.MKTRportException;
import com.mkt.agent.report.fegin.AgentApiClient;
import com.mkt.agent.report.mapper.*;
import com.mkt.agent.report.service.PlayerReportService;
import com.mkt.agent.report.utils.PlayerReportByMonthUtil;
import com.mkt.agent.report.utils.PlayerReportUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;

import javax.annotation.Resource;
import java.util.*;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;


@Service
@RefreshScope
@Slf4j
public class PlayerReportServiceImpl implements PlayerReportService {

    @Autowired
    private PlayerReportUtil playerReportUtil;

    @Value("${playerReport.asyncLimit:50000}")
    private Integer asyncLimit;

    @Resource
    private TAgentCountGroupMonthMapper tAgentCountGroupMonthMapper;

    @Autowired
    private QueryForDayDispatcher queryForDayDispatcher;

    @Autowired
    private QueryForDayDispatcherNew queryForDayDispatcherNew;

    @Resource
    private PlayerReportByMonthUtil playerReportByMonthUtil;

    @Resource
    private ClDashBoardV1Mapper clDashBoardV1Mapper;

    @Resource
    private PlayerReportMapper playerReportMapper;

    @Resource
    private Gson gson;

    @Resource
    private TransProcessor transProcessor;


    @Override
    public ReportPageResponse<PlayerReportResponse> queryByPageNConditionForMonth(PlayerReportRequest req) {

        if(Objects.isNull(req)){
            return null;
        }

        log.info("Begin to handle player report by month！ The param is:{}",req);

        ReportPageResponse<PlayerReportResponse> response = new ReportPageResponse<>();
        response.setSize(req.getPageSize());
        response.setCurrent(1L);
        response.setTotal(0);
        response.setPages(1L);

        try {
            //获取满足条件的代理
            if(StringUtils.isBlank(req.getPlayerAccount())){

                String parentAccount = req.getParentAccount();

                String parentLevel = req.getParentLevel();

                TAgentCustomers agent = playerReportUtil.selectAgentByName(req.getLoginName());
                if(Objects.isNull(agent)){
                    log.info("The agent:{} is null",req.getLoginName());
                    return response;
                }

                String agentAccount = agent.getLoginName();

                if(StringUtils.isNotBlank(parentAccount) && parentAccount.equals(agent.getParentName())){

                    if(agent.getParentName().equals(BaseConstants.C66_ADMIN) && StringUtils.isNotBlank(req.getParentLevel())){
                        return response;
                    }

                    if(!agent.getParentName().equals(BaseConstants.C66_ADMIN) && StringUtils.isNotBlank(req.getParentLevel()) && !req.getParentLevel().equals(String.valueOf(agent.getAgentLevel()-1))){
                        return response;
                    }


                    //查询clickhouse获取结果, 汇总、排序后返回
                    playerReportByMonthUtil.getResponseForOne(response,req.getStartDate(),req.getEndDate(),req.getLoginName());

                }else if(StringUtils.isBlank(parentAccount) && StringUtils.isNotBlank(parentLevel) && parentLevel.equals(String.valueOf(agent.getAgentLevel() - 1)) && !agent.getAgentLevel().equals(Integer.valueOf(Constants.ONE))){

                    //查询clickhouse获取结果, 汇总、排序后返回
                    playerReportByMonthUtil.getResponseForOne(response,req.getStartDate(),req.getEndDate(),req.getLoginName());

                } else {
                    //可合并
                    //如果不带条件 获取 totalCount 进行计算
                    Boolean totalCountFlag = true;

                    if(Objects.nonNull(req.getParentLevel()) || Objects.nonNull(req.getParentAccount())){
                        //如果带条件 获取 directCount 进行计算
                        totalCountFlag = false;
                    }

                    log.info("[queryByPageNConditionForMonth] totalCountFlag = {}",totalCountFlag);

                    List<String> agentNameList = playerReportByMonthUtil.getAgentNameListByNameNLevel(req,totalCountFlag);
                    if(CollectionUtils.isEmpty(agentNameList)){
                        return response;
                    }
                    log.info("The agentNameList for agent:{} is:{}",agentAccount,gson.toJson(agentNameList));

                    List<String> monthList = DateUtils.getMonthRangeForStr(req.getStartDate(), req.getEndDate());

                    //执行查询
                    List<TAgentCountGroupMonth> groupMonthList = tAgentCountGroupMonthMapper.queryGroupMonthListForThreeMonth(TAgentCountGroupMonthRequest.builder().agentAccountList(agentNameList).agentMonthList(monthList).build());
                    if(CollectionUtils.isEmpty(groupMonthList)){
                        monthList = null;
                        return response;
                    }
                    log.info("The groupMonthList for agent:{} is:{}",agentAccount,groupMonthList);

                    //获取团队用户
                    List<String> teamNameList = playerReportUtil.getTeamNameList(agentNameList,totalCountFlag);

                    if(CollectionUtils.isEmpty(teamNameList)){
                        return response;
                    }
                    log.info("[queryByPageNConditionForMonth]The teamNameList for agent:{} is:{}",agentAccount,gson.toJson(teamNameList));

                    //按照月份降序
                    Collections.sort(groupMonthList);

                    //所选月份内的总count
                    Integer count = 0;

                    if(totalCountFlag){
                        count = groupMonthList.stream().map(g -> g.getTotalCount() + g.getSelfCount()).reduce((c1,c2) -> c1 + c2).get();
                    }else {
                        count = groupMonthList.stream().map(g -> g.getDirectCount() + g.getSelfCount()).reduce((c1,c2) -> c1 + c2).get();
                    }

                    if(count == 0){
                        return response;
                    }

                    TAgentCountGroupMonthDTO dto = new TAgentCountGroupMonthDTO();

                    response.setCurrent(req.getPageNum());
                    if(count >= BaseConstants.PLAYER_REPORT_MAX_PAGECOUNT){
                        response.setTotal(BaseConstants.PLAYER_REPORT_MAX_PAGECOUNT);
                    }else {
                        response.setTotal(count);
                    }
                    response.setPages((long) Math.ceil((double) response.getTotal() / response.getSize()));

                    //判断页码是否越界
                    if(req.getPageNum() > response.getPages()){
                        req.setPageNum(Integer.valueOf(Constants.ONE));
                    }

                    //原始下标
                    Integer startIndex = req.getPageSize() * (req.getPageNum() - 1);
                    Integer endIndex = startIndex + req.getPageSize() - 1;

                    //封装查询条件
                    List<ClDashBoardCreateQueryReq> queryReqList = playerReportByMonthUtil.getQueryReqList(groupMonthList,startIndex,endIndex,totalCountFlag,teamNameList,dto);

                    List<PlayerReportResponse> playerReportResponseList;
                    //查询clickhouse获取结果, 汇总、排序后返回
                    if(teamNameList.size() > asyncLimit){
                        //异步查询
                        playerReportResponseList = playerReportByMonthUtil.getPlayerReportResponseByMonthAsync(agentAccount,queryReqList,asyncLimit);
                    }else {
                        //同步查询
                        playerReportResponseList = playerReportByMonthUtil.getPlayerReportResponseByMonth(queryReqList);
                    }

                    if(!CollectionUtils.isEmpty(playerReportResponseList)){
                        //计算真实下标，按照真实下标截取
                        response.setRecords(playerReportByMonthUtil.cutPlayerReportResponse(playerReportResponseList,startIndex,req.getPageSize(),dto));
                    }
                    dto = null;
                }


            }else {

                if(playerReportUtil.checkIfPlayerMeetCondition(req)){
                    //查询clickhouse获取结果, 汇总、排序后返回
                    playerReportByMonthUtil.getResponseForOne(response,req.getStartDate(),req.getEndDate(),req.getPlayerAccount());
                }

            }
        }catch (Exception e){
            log.error("Error while processing the month data for agent:{}",req.getLoginName(),e);
        }

        log.info("[queryByPageNConditionForMonth]The result after paging is :{}",gson.toJson(response.getRecords()));

        if(!CollectionUtils.isEmpty(response.getRecords())){
            playerReportUtil.selectParentNParentLevelByUsersForPReport(response.getRecords());
        }

        return response;
    }


    @Override
    public ReportPageResponse<PlayerReportResponse> queryByPageAndConditionByDay(PlayerReportRequest req) {
        if (Objects.isNull(req)) {
            return null;
        }
        StopWatch stopWatch = new StopWatch();
        stopWatch.start("supplyDataWithModel");
        ReportPageResponse<PlayerReportResponse> response =  queryForDayDispatcher.playerForDayDispatch(req, Boolean.FALSE);
        stopWatch.stop();
        log.info("suspend time of supplyDataWithModel is {} ms", stopWatch.getTotalTimeMillis());
        return response;
    }

    @Override
    public Page<PlayerReportResponse> queryByPageAndConditionByDayNico(PlayerReportRequest req, IPage<PlayerReportResponse> page) {
        if (Objects.isNull(req)) {
            return null;
        }
        StopWatch stopWatch = new StopWatch();
        stopWatch.start("supplyDataWithModel");
        Page<PlayerReportResponse> response = queryForDayDispatcherNew.playerForDayDispatch(req,page, Boolean.FALSE);
        stopWatch.stop();
        log.info("suspend time of supplyDataWithModel is {} ms", stopWatch.getTotalTimeMillis());
        return response;
    }

    @Override
    public List<PlayerReportResponse> queryAndExportByMonth(PlayerReportRequest req) {
        return this.queryByPageNConditionForMonth(req).getRecords();
    }

    @Override
    public List<PlayerReportResponse> queryAndExportByDay(PlayerReportRequest req) {
        return this.queryForDayDispatcher.playerForDayDispatch(req, Boolean.TRUE).getRecords();
    }

    @Override
    public PlayerReportByGameResponse getGameReport(PlayerReportByGameRequest req) {
        // 校验用户是否属于登录用户的团队
        if (!UserContext.getUsername().equals(req.getAgentAccount()) && playerReportUtil.playerIsNotTeamMember(UserContext.getUsername(), req.getAgentAccount())){
            throw new MKTRportException("You can only view your own team information");
        }
        if (StringUtils.isEmpty(req.getDate()) && StringUtils.isEmpty(req.getMonth())){
            throw new MKTRportException(ResultEnum.BAD_REQUEST);
        }
        // 月份查询则设置具体开始日期和结束日期
        if (StringUtils.isNotEmpty(req.getMonth())){
            req.setFirstAndEndDateOfMonth();
        }
        List<PlayerReportByGameResponse> playerReportByGameResponses = clDashBoardV1Mapper.queryPlayerReportGameDetail(req);
        if (CollectionUtils.isEmpty(playerReportByGameResponses)) {
            return null;
        }
        // 添加汇总数据 Summary
        return PlayerReportByGameResponse.buildSummary(playerReportByGameResponses);
    }

    @Override
    public Page<PlayerReportResponse> queryByDayPage(PlayerReportRequest req) {
        List<PlayerReportResponse> playerReportResponseList = playerReportMapper.selectListByDay(req);
        return getPlayerReportResponsePage(req, playerReportResponseList);
    }

    private Page<PlayerReportResponse> getPlayerReportResponsePage(PlayerReportRequest req, List<PlayerReportResponse> playerReportResponseList) {
        Integer pageSize = req.getPageSize();
        Integer pageNum = req.getPageNum();
        Page<PlayerReportResponse> page = new Page<>(pageNum, pageSize);
        int total = playerReportResponseList.size();
        List<PlayerReportResponse> subList = playerReportResponseList.stream()
                .skip((long) (pageNum - 1) * pageSize)
                .limit(pageSize)
                .collect(Collectors.toList());
        page.setRecords(subList);
        page.setTotal(total);
        page.setPages((total + pageSize - 1) / pageSize);
        return page;
    }

    @Override
    public List<PlayerReportResponse> queryByDayPageMaxPageCount(PlayerReportRequest req) {
        return playerReportMapper.selectListByDay(req);
    }


    @Override
    public Page<PlayerReportResponse> queryByMonthPage(PlayerReportRequest req) {
        req.setEndDate(DateUtils.dateToString(DateUtils.getLastDayOfMonth(DateUtils.stringToDate(req.getEndDate()))));
        List<PlayerReportResponse> playerReportResponseList = playerReportMapper.selectListByMonth(req);
        return getPlayerReportResponsePage(req, playerReportResponseList);
    }

    @Override
    public List<PlayerReportResponse> queryByMonthPageMaxPageCount(PlayerReportRequest req) {
        req.setEndDate(DateUtils.dateToString(DateUtils.getLastDayOfMonth(DateUtils.stringToDate(req.getEndDate()))));
        return playerReportMapper.selectListByMonth(req);
    }

}

