package com.mkt.agent.report.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.entity.api.reportapi.requests.PlayerReportByGameRequest;
import com.mkt.agent.common.entity.api.reportapi.requests.PlayerReportRequest;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportByGameResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.base.ReportPageResponse;

import java.util.List;

public interface PlayerReportService {

    ReportPageResponse<PlayerReportResponse> queryByPageNConditionForMonth(PlayerReportRequest req);

    ReportPageResponse<PlayerReportResponse> queryByPageAndConditionByDay(PlayerReportRequest req);

    Page<PlayerReportResponse> queryByPageAndConditionByDayNico(PlayerReportRequest req, IPage<PlayerReportResponse> page);

    List<PlayerReportResponse> queryAndExportByMonth(PlayerReportRequest req);

    List<PlayerReportResponse> queryAndExportByDay(PlayerReportRequest req);

    PlayerReportByGameResponse getGameReport(PlayerReportByGameRequest req);

    Page<PlayerReportResponse> queryByDayPage(PlayerReportRequest req);

    Page<PlayerReportResponse> queryByMonthPage(PlayerReportRequest req);

    List<PlayerReportResponse> queryByDayPageMaxPageCount(PlayerReportRequest req);

    List<PlayerReportResponse> queryByMonthPageMaxPageCount(PlayerReportRequest req);
}
