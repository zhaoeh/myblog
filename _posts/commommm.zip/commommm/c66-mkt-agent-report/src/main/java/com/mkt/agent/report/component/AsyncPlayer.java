package com.mkt.agent.report.component;

import com.mkt.agent.common.annotation.RequestLimit;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.reportapi.requests.PlayerReportRequest;
import com.mkt.agent.common.player.model.PlayerReportByMonthMapperHolder;
import com.mkt.agent.common.player.model.PlayerMapperHolder;
import com.mkt.agent.common.player.model.PlayerReportByMonthProcessorModel;
import com.mkt.agent.common.player.processor.AgentTransProcessor;
import com.mkt.agent.common.player.processor.PlayerReportByMonthProcessor;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.report.clickhouse.mapper.ClDashBoardV1Mapper;
import com.mkt.agent.report.mapper.TAgentCountGroupMonthMapper;
import com.mkt.agent.report.mapper.UsersGroupMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.time.LocalDate;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @description: 异步更新
 * @author: ErHu.Zhao
 * @create: 2024-02-15
 **/
@Component
@Slf4j
public class AsyncPlayer {

    private static ExecutorService executorService;

    @Resource
    private AgentTransProcessor agentTransProcessor;

    @Resource
    private PlayerReportByMonthProcessor playerReportByMonthProcessor;

    @Resource
    private ClDashBoardV1Mapper clDashBoardV1Mapper;

    @Value("${player.threadPoolSize:10}")
    private Integer threadPoolSize;

    @Resource
    private UsersGroupMapper usersGroupMapper;

    @Resource
    TAgentCountGroupMonthMapper agentCountGroupMonthMapper;

    @Autowired
    private UsersSupplier usersSupplier;

    @PostConstruct
    public void initTheadPool() {
        log.info("begin to init thread pool of AsyncPlayer");
        executorService = Executors.newFixedThreadPool(this.threadPoolSize);
        log.info("end to init thread pool of AsyncPlayer, threadPoolSize is {}", this.threadPoolSize);
    }

    @RequestLimit(keyField = "loginName", period = 300, count = 1, limitConfigurer = PlayerLimitConfigurer.class, handlerPolicy = RequestLimit.HandlerPolicy.REFUSE_RUN)
    public void asyncUpdate(PlayerReportRequest req) {
//        asyncUpdateForDay(req);
        asyncUpdateForMonth(req);
    }

    /**
     * 按天异步更新
     *
     * @param req
     */
    public void asyncUpdateForDay(PlayerReportRequest req) {
        executorService.execute(() -> {
            try {
                log.info("[asyncUpdate method] 按天查询异步更新开始");
                PlayerMapperHolder holder = PlayerMapperHolder.builder().
                        biDateRangeMapper(clDashBoardV1Mapper::queryAgentDateRange).
                        countDateRangeMapper(usersGroupMapper::queryDashDateRange).
                        groupInsertMapper(usersGroupMapper::insertUsersGroup).
                        groupDeleteMapper(usersGroupMapper::deleteUsersGroup).
                        targetAgentsTransCountMapper(clDashBoardV1Mapper::getTransCountByAgents).
                        transCountsMapper(usersGroupMapper::queryDownLineCount).
                        lowerDirectsMapper(usersSupplier::supplyLowerDirectUsers).
                        lowerAgentsMapper(usersSupplier::supplyLowerAgentUsers).
                        lowerUsersMapper(usersSupplier::supplyLowerAllUsers).
                        teamAgentsMapper(usersSupplier::supplyDownlineTeamAgents).
                        agentsByLevelMapper(agentTransProcessor::obtainAgentsByLevel).
                        build();
                agentTransProcessor.dealWithData(holder, req.getLoginName());
                log.info("[asyncUpdate method] 按天查询异步更新结束");
            } catch (Exception e) {
                log.error("[asyncUpdate method] 按天查询异步更新异常, e is :", e);
            }
        });
    }


    public void asyncUpdateForMonth(PlayerReportRequest req) {
        executorService.execute(() -> {
            try {
                log.info("[asyncUpdate month method] begin to asyncUpdate for agent:{}",req.getLoginName());
                LocalDate currentMonthFirstDay = DateUtils.getLastNMonthFirstDay(0);
                LocalDate currentMonthLastDay = DateUtils.getLastNMonthLastDay(0);
                String currentMonth = DateUtils.getFormattedMonth(0);
                playerReportByMonthProcessor.preHandlePlayerReportByMonth(PlayerReportByMonthProcessorModel.builder().level(Constants.DASH_BOARD_DATA_START_LEVEL).startDate(currentMonthFirstDay.toString())
                        .endDate(currentMonthLastDay.toString()).month(currentMonth).operatorType(Constants.FROM_ASYNC).parent(req.getLoginName()).isCurrentMonth(true).holder(buildMonthMapper()).build());
                log.info("[asyncUpdate month method] end to asyncUpdate for agent:{}",req.getLoginName());
            } catch (Exception e) {
                log.error("[asyncUpdate method] asyncUpdate caught an exception, e is :", e);
            }
        });
    }

    private PlayerReportByMonthMapperHolder buildMonthMapper(){
        return PlayerReportByMonthMapperHolder.builder().queryAgentByNameMapper(usersSupplier::doSupplyAgent).directUsersMapper(usersSupplier::doSupplyLowerDirectUsers)
                .teamAgentsByLevelMapper(usersSupplier::supplyDownlineTeamAgents).allAgentByLevelWithoutStatusMapper(null)
                .uncheckedAgentsByLevelNMonth(null).groupInsertMapper(agentCountGroupMonthMapper::insertBatchSomeColumn).deleteByNamesNMonth(agentCountGroupMonthMapper::deleteGroupByNameNMonth)
                .deleteByLevelNMonth(null).downlineAgentCountMapper(agentCountGroupMonthMapper::getDownlineAgentsData)
                .queryDirectCountByMonthMapper(clDashBoardV1Mapper::getDirectCountByMonth)
                .querySelfCountByMonthMapper(clDashBoardV1Mapper::getSelfCountByMonth).build();

    }

}
