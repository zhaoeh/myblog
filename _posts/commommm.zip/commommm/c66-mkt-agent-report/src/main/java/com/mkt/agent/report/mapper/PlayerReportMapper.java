package com.mkt.agent.report.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonth;
import com.mkt.agent.common.entity.api.reportapi.requests.PlayerReportRequest;
import com.mkt.agent.common.entity.api.reportapi.requests.TAgentCountGroupMonthRequest;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.base.ReportPageResponse;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Description TODO
 * @Classname TAgentCountGroupMonthMapper
 * @Date 2024/2/5 15:06
 * @Created by TJSLucian
 */
@Mapper
public interface PlayerReportMapper {

    List<PlayerReportResponse> selectListByDay(@Param("req") PlayerReportRequest req);

    List<PlayerReportResponse> selectListByMonth(@Param("req") PlayerReportRequest req);

}
