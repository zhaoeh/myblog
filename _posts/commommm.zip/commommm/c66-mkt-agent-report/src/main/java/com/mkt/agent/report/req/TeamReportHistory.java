package com.mkt.agent.report.req;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
@ApiModel(description = "t_team_report_history")
@TableName("t_team_report_history")
public class TeamReportHistory {
    private String loginNameDate ;
    private BigDecimal withdrawAmount ;
    private BigDecimal depositAmount ;
    private BigDecimal turnover ;
    private BigDecimal ggr ;
    private BigDecimal winorloss ;
    private String type ;
    private Date   createDateTime ;
    private BigDecimal   firstDeposit ;  //首充金额
    private Long    firstDepositCount ;//首充人数
    private  Integer  betPlayers ;




    public void setFirstDeposit(BigDecimal firstDeposit) {
        this.firstDeposit = firstDeposit;
    }

    public void setFirstDepositCount(Long firstDepositCount) {
        this.firstDepositCount = firstDepositCount;
    }

    public Long getFirstDepositCount() {

        if(firstDepositCount == null) {
            firstDepositCount  =0L;
        }
        return firstDepositCount;
    }

    public BigDecimal getFirstDeposit() {


        if(firstDeposit == null) {
            firstDeposit  = new BigDecimal(0) ;
        }
        return firstDeposit;
    }


    public Date getCreateDateTime() {
        return createDateTime;
    }

    public void setCreateDateTime(Date createDateTime) {
        this.createDateTime = createDateTime;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLoginNameDate()  {


        return loginNameDate;
    }

    public BigDecimal getWithdrawAmount() {


        if(withdrawAmount == null) {
            withdrawAmount  = new BigDecimal(0) ;
        }
        return withdrawAmount;
    }

    public BigDecimal getDepositAmount() {
        if(depositAmount == null) {
            depositAmount  = new BigDecimal(0) ;
        }

        return depositAmount;
    }

    public BigDecimal getTurnover() {
        if(turnover == null) {
            turnover  = new BigDecimal(0) ;
        }
        return turnover;
    }

    public BigDecimal getGgr() {
        if(ggr == null) {
            ggr  = new BigDecimal(0) ;
        }

        return ggr;
    }

    public BigDecimal getWinorloss() {
        if(winorloss == null) {
            winorloss  = new BigDecimal(0) ;
        }
        return winorloss;
    }

    public void setLoginNameDate(String loginNameDate) {
        this.loginNameDate = loginNameDate;
    }

    public void setWithdrawAmount(BigDecimal withdrawAmount) {
        this.withdrawAmount = withdrawAmount;
    }

    public void setDepositAmount(BigDecimal depositAmount) {
        this.depositAmount = depositAmount;
    }

    public void setTurnover(BigDecimal turnover) {
        this.turnover = turnover;
    }

    public void setGgr(BigDecimal ggr) {
        this.ggr = ggr;
    }

    public void setWinorloss(BigDecimal winorloss) {
        this.winorloss = winorloss;
    }
}
