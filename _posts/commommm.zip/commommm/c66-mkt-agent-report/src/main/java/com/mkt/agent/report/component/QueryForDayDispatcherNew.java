package com.mkt.agent.report.component;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.reportapi.requests.PlayerReportRequest;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse;
import com.mkt.agent.common.enums.DashboardChosenTimeEnum;
import com.mkt.agent.common.fast.core.FastCore;
import com.mkt.agent.common.fast.pojo.AgentCustomersMapping;
import com.mkt.agent.common.fast.pojo.FastQueryModel;
import com.mkt.agent.common.utils.PageUtils;
import com.mkt.agent.report.clickhouse.mapper.FastByteHouseMapper;
import com.mkt.agent.report.mapper.FastMapper;
import com.mkt.agent.report.utils.PlayerReportUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @description: 按天查询player转发器
 * @author: ErHu.Zhao
 * @create: 2024-02-05
 **/
@Component
@Slf4j
public class QueryForDayDispatcherNew {

    @Autowired
    private FastByteHouseMapper fastByteHouseMapper;

    @Autowired
    private FastMapper fastMapper;

    @Autowired
    private PlayerReportUtil playerReportUtil;

    @Autowired
    private FastCore fastCore;


    public Page<PlayerReportResponse> playerForDayDispatch(PlayerReportRequest request, IPage<PlayerReportResponse> page, boolean ignorePagination) {
        Assert.isTrue(DashboardChosenTimeEnum.ChosenType_Day.getName().equals(request.getDataDate()), "dataDate must be \"" + DashboardChosenTimeEnum.ChosenType_Day.getName() + "\"");
        Assert.notNull(request, "request cannot be null");
        Page<PlayerReportResponse> response = null;
        TAgentCustomers agent = playerReportUtil.selectAgentByName(request.getLoginName());
        if (Objects.isNull(agent)) {
            return null;
        }
        FastQueryModel.FastQueryModelBuilder<?, ?> model = FastQueryModel.builder();
        model.startIndex(PageUtils.calculateStartIndex(request.getPageNum(), request.getPageSize())).
                endIndex(PageUtils.calculateEndIndex(request.getPageNum(), request.getPageSize()));
        Integer loginLevel = agent.getAgentLevel();
        List<String> normalAgents = new ArrayList<>();
        normalAgents.add(request.getLoginName());
        if (StringUtils.isNotBlank(request.getPlayerAccount())) {
            normalAgents.add(request.getPlayerAccount());
        }
        List<String> agentMappingParams = fastCore.buildAgentMappingParams(normalAgents);

        List<AgentCustomersMapping> agentCustomersMappings = fastMapper.queryAgentsMapping(agentMappingParams);
        Map<String, String> agentMappings = fastCore.agentCustomersMapping2Map(agentCustomersMappings);
        String playerAccount = request.getPlayerAccount();
        // 玩家直属上级代理账号
        String parentAccount = request.getParentAccount();
        // 玩家直属上级代理等级
        String parentLevel = request.getParentLevel();
        // case1：直接查询player account
        if (StringUtils.isNotBlank(playerAccount)) {
            if (!playerReportUtil.checkIfPlayerMeetCondition(request)) {
                return null;
            }
            model.beginDate(request.getStartDate()).endDate(request.getEndDate()).loginName(request.getPlayerAccount()).build();
            response = fastByteHouseMapper.queryPlayerDetails(model.build(), page);

        } else if (StringUtils.isNotBlank(parentLevel) || StringUtils.isNotBlank(parentAccount)) {
            log.info("处理parentAccount or parentLevel case");


            if (Objects.isNull(loginLevel) || loginLevel < Integer.valueOf(Constants.ONE)) {
                return response;
            }
            String loginParentName = agent.getParentName();

            if (StringUtils.isNotBlank(parentAccount) && StringUtils.isNotBlank(parentLevel)) {
                if (isBelowOneLevelAgent(agent) && parentAccount.equals(loginParentName) && loginLevel - 1 == Integer.valueOf(parentLevel)) {
                    model.beginDate(request.getStartDate()).endDate(request.getEndDate()).loginName(request.getLoginName()).build();
                    response = fastByteHouseMapper.queryPlayerDetails(model.build(), page);
                }

                // parentAccount是当前登录者，且parentLevel是当前登录者level，则查询当前登录者的直属用户
                if (parentAccount.equals(request.getLoginName()) && loginLevel.equals(Integer.valueOf(parentLevel))) {
                    model.beginDate(request.getStartDate()).endDate(request.getEndDate()).parentDirect(agentMappings.get(request.getLoginName())).build();
                    response = fastByteHouseMapper.queryDirectDetailsWithAgentAndLevel(model.build(), page);
                }
            }

            if (StringUtils.isBlank(parentAccount) && StringUtils.isNotBlank(parentLevel)) {
                if (isBelowOneLevelAgent(agent) && loginLevel - 1 == Integer.valueOf(parentLevel)) {
                    model.beginDate(request.getStartDate()).endDate(request.getEndDate()).loginName(request.getLoginName()).build();
                    response = fastByteHouseMapper.queryPlayerDetails(model.build(), page);
                }

                if (loginLevel.equals(Integer.valueOf(parentLevel))) {
                    model.beginDate(request.getStartDate()).endDate(request.getEndDate()).parentDirect(agentMappings.get(request.getLoginName())).build();
                    response = fastByteHouseMapper.queryDirectDetailsWithAgentAndLevel(model.build(), page);
                }
            }

            if (StringUtils.isNotBlank(parentAccount) && StringUtils.isBlank(parentLevel)) {
                if (BaseConstants.C66_ADMIN.equals(parentAccount) && isOneLevelAgent(agent)) {
                    model.beginDate(request.getStartDate()).endDate(request.getEndDate()).loginName(request.getLoginName()).build();
                    response = fastByteHouseMapper.queryPlayerDetails(model.build(), page);
                }

                if (isBelowOneLevelAgent(agent) && parentAccount.equals(loginParentName)) {
                    model.beginDate(request.getStartDate()).endDate(request.getEndDate()).loginName(request.getLoginName()).build();
                    response = fastByteHouseMapper.queryPlayerDetails(model.build(), page);
                }
                if (parentAccount.equals(request.getLoginName())) {
                    model.beginDate(request.getStartDate()).endDate(request.getEndDate()).parentDirect(agentMappings.get(request.getLoginName())).build();
                    response = fastByteHouseMapper.queryDirectDetailsWithAgentAndLevel(model.build(), page);
                }
            }

            if (Objects.isNull(response)) {
                model.beginDate(request.getStartDate()).endDate(request.getEndDate()).parentDirect(agentMappings.get(parentAccount)).agentLevel(Objects.isNull(parentLevel) ? null : Integer.valueOf(parentLevel)).build();
                response = fastByteHouseMapper.queryDirectDetailsWithAgentAndLevel(model.build(), page);
            }

        } else {
            // 查询当前登录者的团队用户
            FastQueryModel model1 = fastCore.buildFastQueryModel(loginLevel, agentMappings.get(request.getLoginName()));
            model1.setBeginDate(request.getStartDate());
            model1.setEndDate(request.getEndDate());
            model1.setAgentLevel(loginLevel);
            model1.setStartIndex(PageUtils.calculateStartIndex(request.getPageNum(), request.getPageSize()));
            model1.setEndIndex(PageUtils.calculateEndIndex(request.getPageNum(), request.getPageSize()));
            response = fastByteHouseMapper.queryTeamAndSelfDetailsWithLevelAgent(model1, page);
        }
        playerReportUtil.selectParentNParentLevelByUsersForPReport(response.getRecords());
        return response;
    }


    /**
     * 判断目标代理是否是一级代理的属下代理
     *
     * @param targetAgent
     * @return
     */
    private boolean isBelowOneLevelAgent(TAgentCustomers targetAgent) {
        Assert.notNull(targetAgent, "targetAgent cannot be null");
        Integer agentLevel = targetAgent.getAgentLevel();
        Assert.notNull(agentLevel, "agentLevel cannot be null");
        return targetAgent.getAgentLevel() > Integer.valueOf(Constants.ONE);
    }

    /**
     * 判断目标代理是否是一级代理
     *
     * @param targetAgent
     * @return
     */
    private boolean isOneLevelAgent(TAgentCustomers targetAgent) {
        Assert.notNull(targetAgent, "targetAgent cannot be null");
        Integer agentLevel = targetAgent.getAgentLevel();
        Assert.notNull(agentLevel, "agentLevel cannot be null");
        return Integer.valueOf(Constants.ONE).equals(targetAgent.getAgentLevel());
    }


}
