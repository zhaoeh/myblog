package com.mkt.agent.report.component;

import com.google.gson.Gson;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.clickhouse.req.DashBoardUserTreeQueryReq;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.player.model.TAgentCountGroup;
import com.mkt.agent.report.fegin.AgentApiClient;
import com.mkt.agent.report.fegin.UserFeignService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @description: 用户集供应器
 * @author: ErHu.Zhao
 * @create: 2024-02-15
 **/
@Component
@Slf4j
public class UsersSupplier {

    private final UserFeignService userFeignService;

    private final AgentApiClient agentApiClient;

    public UsersSupplier(UserFeignService userFeignService, AgentApiClient agentApiClient) {
        this.userFeignService = userFeignService;
        this.agentApiClient = agentApiClient;
    }

    /**
     * 获取目标代理集的下级直属用户
     *
     * @param request
     * @return
     */
    public List<String> supplyLowerDirectUsers(TAgentCountGroup request) {
        Assert.notNull(request, "request cannot be null");
        return doSupplyLowerDirectUsers(request.getTargetAgents());
    }

    public List<String> doSupplyLowerDirectUsers(List<String> targetAgents) {
        if (CollectionUtils.isEmpty(targetAgents)) {
            return Collections.emptyList();
        }
        Result<List<String>> directNameResult = userFeignService.selectDirectUsersByParentListNTime(DashBoardUserTreeQueryReq.builder().
                parentList(targetAgents).build());
        if (Objects.nonNull(directNameResult) && directNameResult.isSuccess()) {
            List<String> lowerDirects = CollectionUtils.isEmpty(directNameResult.getData()) ? Collections.emptyList() : directNameResult.getData();
            log.info("获取目标代理集的直属用户集，目标代理集size为：{}，获取到下级直属用户集size为：{}", targetAgents.size(), lowerDirects.size());
            return lowerDirects;
        }
        log.error("/user/directUsers/byParentListNTime api response error, {}", new Gson().toJson(directNameResult));
        throw new BusinessException("call /user/directUsers/byParentListNTime api response failed");
    }

    /**
     * 获取目标代理集的下级代理用户
     *
     * @param request
     * @return
     */
    public List<String> supplyLowerAgentUsers(TAgentCountGroup request) {
        Assert.notNull(request, "request cannot be null");
        return doSupplyLowerAgentUsers(request.getTargetAgents());
    }

    public List<String> doSupplyLowerAgentUsers(List<String> targetAgents) {
        if (CollectionUtils.isEmpty(targetAgents)) {
            return Collections.emptyList();
        }
        Result<List<String>> teamNameResult = agentApiClient.selectDirectAgentNamesByParentList(DashBoardUserTreeQueryReq.builder().
                parentList(targetAgents).build());
        if (Objects.nonNull(teamNameResult) && teamNameResult.isSuccess()) {
            List<String> lowerAgents = CollectionUtils.isEmpty(teamNameResult.getData()) ? Collections.emptyList() : teamNameResult.getData();
            log.info("获取目标代理集的下级代理集，目标代理集size为：{}，获取到下级代理集size为：{}", targetAgents.size(), lowerAgents.size());
            return lowerAgents;
        }
        log.error("/agentCustomers/selectDirectAgentNamesByParentList api response error, {}", new Gson().toJson(teamNameResult));
        throw new BusinessException("call /agentCustomers/selectDirectAgentNamesByParentList api response failed");
    }


    /**
     * 根据parentLevel 或者 parentAccount 获取目标代理集
     *
     * @param parentLevel
     * @param parentAccount
     * @return
     */
    public List<String> supplyTargetAgents(String parentLevel, String parentAccount, String currentAgent) {
        log.info("根据parentLevel，parentAccount，和currentAgent获取目标代理集开始,parentLevel is {},parentAccount is {},currentAgent is {}", parentLevel, parentAccount, currentAgent);

        parentAccount = StringUtils.isBlank(parentAccount) ? Strings.EMPTY : parentAccount;
        Integer level = StringUtils.isBlank(parentLevel) ? 0 : Integer.valueOf(parentLevel);
        Result<List<String>> agentNameListResult = agentApiClient.getAgentNameListByNameNLevel(currentAgent,parentAccount, "", level);

        if (Objects.nonNull(agentNameListResult) && agentNameListResult.isSuccess()) {
            List<String> targetAgents = CollectionUtils.isEmpty(agentNameListResult.getData()) ? Collections.emptyList() : agentNameListResult.getData();
            log.info("根据parentLevel，parentAccount，和currentAgent获取目标代理集结束，targetAgents size is {},first target agent is {}", targetAgents.size(), targetAgents.stream().findFirst().orElse(null));
            return targetAgents;
        }
        log.error("/agentCustomers/list/byNameNLevel api response error, {}", new Gson().toJson(agentNameListResult));
        throw new BusinessException("call /agentCustomers/list/byNameNLevel api response failed");
    }

    /**
     * 获取目标代理团队用户，包含自己
     *
     * @param request
     * @return
     */
    public List<String> supplyLowerAllUsersWithSelf(TAgentCountGroup request) {
        Assert.notNull(request, "request cannot be null");
        List<String> allUsers = new ArrayList<>(List.of(request.getAgentName()));
        List<String> result = supplyLowerAllUsers(request);
        if (!CollectionUtils.isEmpty(result)) {
            allUsers.addAll(result);
        }
        log.info("下级团队包含自己总size为:{}", allUsers.size());
        return allUsers;
    }

    /**
     * 获取目标代理用户集所有下级用户(团队用户)
     *
     * @param request
     * @return
     */
    public List<String> supplyLowerAllUsers(TAgentCountGroup request) {
        Assert.notNull(request, "request cannot be null");
        return doSupplyLowerAllUsers(request.getTargetAgents());
    }

    public List<String> doSupplyLowerAllUsers(List<String> targetAgents) {
        if (CollectionUtils.isEmpty(targetAgents)) {
            return Collections.emptyList();
        }
        DashBoardUserTreeQueryReq queryEntity = new DashBoardUserTreeQueryReq();
        queryEntity.setParentList(targetAgents);
        Result<List<String>> userListResult = userFeignService.selectUserTreeByParentNTimeOfPart(queryEntity);
        if (Objects.nonNull(userListResult) && userListResult.isSuccess()) {
            List<String> userNameList = CollectionUtils.isEmpty(userListResult.getData()) ? Collections.emptyList() : userListResult.getData();
            log.info("获取的目标代理集合size为:{} ，其对应的下级团队size为:{}", targetAgents.size(), userNameList.size());
            return userNameList;
        }

        log.error("/user/tree/byParentListNTime api response error, {}", new Gson().toJson(userListResult));
        throw new BusinessException("call /user/tree/byParentListNTime api response failed");
    }

    /**
     * 根据parentLevel 或者 parentAccount 获取目标团队代理集
     *
     * @param parentLevel
     * @return
     */
    public List<String> supplyLowerTeamAgents(String parentLevel, String currentAgent) {
        log.info("supplyLowerTeamAgents开始,parentLevel is {},currentAgent is {}", parentLevel, currentAgent);

        Integer level = StringUtils.isBlank(parentLevel) ? 0 : Integer.valueOf(parentLevel);
        Result<List<String>> agentNameListResult = agentApiClient.getAgentNameListByNameNLevel(currentAgent, "","", level);

        if (Objects.nonNull(agentNameListResult) && agentNameListResult.isSuccess()) {
            List<String> targetTeamAgents = CollectionUtils.isEmpty(agentNameListResult.getData()) ? Collections.emptyList() : agentNameListResult.getData();
            log.info("supplyLowerTeamAgents结束，targetAgents size is {},first target agent is {}", targetTeamAgents.size(), targetTeamAgents.stream().findFirst().orElse(null));
            return targetTeamAgents;
        }
        log.error("/agentCustomers/list/byNameNLevel api response error, {}", new Gson().toJson(agentNameListResult));
        throw new BusinessException("call /agentCustomers/list/byNameNLevel api response failed");
    }

    public List<TAgentCustomers> supplyDownlineTeamAgents(String parentLevel, String currentAgent) {
        log.info("supplyLowerTeamAgents开始,parentLevel is {},currentAgent is {}", parentLevel, currentAgent);

        Integer level = StringUtils.isBlank(parentLevel) ? 0 : Integer.valueOf(parentLevel);
        Result<List<TAgentCustomers>> agentListResult = agentApiClient.getTeamAgentListByNameNLevel(currentAgent,"", "", level);

        if (Objects.nonNull(agentListResult) && agentListResult.isSuccess()) {
            List<TAgentCustomers> targetTeamAgents = CollectionUtils.isEmpty(agentListResult.getData()) ? Collections.emptyList() : agentListResult.getData();
            log.info("supplyLowerTeamAgents结束，targetAgents size is {},first target agent is {}", targetTeamAgents.size(), targetTeamAgents.stream().findFirst().orElse(null));
            return targetTeamAgents;
        }
        log.error("/agentCustomers/list/byNameNLevel api response error, {}");
        throw new BusinessException("call /agentCustomers/list/byNameNLevel api response failed");
    }


    public TAgentCustomers doSupplyAgent(String loginName){

        Result<TAgentCustomers> result = agentApiClient.getAgentByLoginName(loginName);
        if(result.isSuccess() && Objects.nonNull(result.getData())){
            return result.getData();
        }

        return null;
    }
}
