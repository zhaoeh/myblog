package com.mkt.agent.report.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.clickhouse.resp.ClDashBoardDataRes;
import com.mkt.agent.report.req.TeamReportHistory;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface TeamReportHistoryMapper  extends BaseMapper<TeamReportHistory>  {
    TeamReportHistory getRowByLoginDate(Map<String,String> loginDate) ;


    TeamReportHistory getDateByMonth(Map<String, String> parame);

    void delParame(Map<String, String> delParame);

    Long getCountRow(Map<String, String> parame);

    TeamReportHistory getRowByLoginDate2(Map<String, Object> parame);

    Long getCountRow2(Map<String, Object> parame);
}
