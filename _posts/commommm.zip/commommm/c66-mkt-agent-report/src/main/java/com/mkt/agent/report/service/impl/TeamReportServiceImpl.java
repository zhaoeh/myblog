package com.mkt.agent.report.service.impl;

import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.thread.ThreadUtil;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.AgentCommissionRecord;
import com.mkt.agent.common.entity.api.integration.bi.requests.UserGameSummerRequest;
import com.mkt.agent.common.entity.api.integration.bi.requests.UserSummerRequest;
import com.mkt.agent.common.entity.api.integration.bi.responses.UserGameSummerResponse;
import com.mkt.agent.common.entity.api.integration.bi.responses.UserSummerResponse;
import com.mkt.agent.common.entity.api.reportapi.requests.PlayerReportRequest;
import com.mkt.agent.common.entity.api.reportapi.requests.TeamReportByGameRequest;
import com.mkt.agent.common.entity.api.reportapi.requests.TeamReportRequest;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.TeamReportByGameResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.TeamReportResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.base.ReportPageResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.sum.TeamReportSumResponse;
import com.mkt.agent.common.entity.api.userapi.requests.AgentListRequest;
import com.mkt.agent.common.entity.clickhouse.req.DashBoardUserTreeQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.ClDashBoardDataRes;
import com.mkt.agent.common.enums.CustomerTypeEnum;
import com.mkt.agent.common.enums.GameTypeEnum;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.*;
import com.mkt.agent.integration.template.BiApiTemplate;
import com.mkt.agent.report.clickhouse.mapper.TDailyOrderMapper;
import com.mkt.agent.report.exception.MKTRportException;
import com.mkt.agent.report.fegin.AgentApiClient;
import com.mkt.agent.report.fegin.CommissionApiGateClient;
import com.mkt.agent.report.fegin.JobFeignReportService;
import com.mkt.agent.report.fegin.UserFeignService;
import com.mkt.agent.report.mapper.*;
import com.mkt.agent.report.req.*;
import com.mkt.agent.report.service.ReportService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;


@Service
@RefreshScope
@Slf4j
public class TeamReportServiceImpl implements ReportService<TeamReportRequest, TeamReportResponse> {

    @Value("${BI.user_data_url:http://c66-bi-report-api.c66.svc.cluster.local/forMarketPlatform/userUnionAllSummary}")
    private String userDataUrl;

    @Value("${BI.game_data_url:http://c66-bi-report-api.c66.svc.cluster.local/forMarketPlatform/userDaySummary}")
    private String gameDataUrl;

    @Autowired
    private TeamReportMapper teamReportMapper;

    @Autowired
    private JobFeignReportService jobFeignReportService;

    @Autowired
    private AgentApiClient agentApiClient;

    @Autowired
    private UserFeignService userFeignService;

    @Autowired
    private TUserFinanceOrderTreedMapper tUserFinanceOrderTreedMapper;

    @Autowired
    private TUserFinanceDwTreedMapper tUserFinanceDwTreedMapper;

    @Autowired
    private TeamReportHistoryMapper teamReportHistoryMapper;

    @Autowired
    private  UserMapper userMapper   ;

    /**
     * 是否缓存*
     * 2缓存  1 不缓存* 默认2
     */
    @Value("${tempReport.isCache:2}")
    private String isCache;

    /**
     * 是否缓存*
     * 2缓存  1 不缓存* 默认2
     */
    @Value("${tempReport.isCacheDetail:2}")
    private String isCacheDetail;

    /**
     * 是否缓存*
     * 2缓存  1 不缓存* 默认2
     */
    @Value("${tempReport.isCacheHistory:2}")
    private String isCacheHistory;

    @Value("${tempReport.biMaxDetailThread:1000}")
    private Long biMaxDetailThread;

    @Value("${tempReport.biMaxListThread:10}")
    private Long biMaxListThread;

    @Value("${tempReport.postThread:20}")
    private int postThread;

    @Value("${tempReport.expireLongTime:900}") //半小时
    private Long expireLongTime;


    @Value("${tempReport.newBi:2}") //
    private int newBi;

    @Value("${tempReport.splitDate:2023-09-01}") //
    private String splitDate;


    @Value("${tempReport.splitDateForamt:yyyy-MM-dd}") //
    private String splitDateForamt;


    @Value("${tempReport.splitRow:6500}") //
    private Integer splitRow;

    private <T> List<List<T>> splitArrayList(List<T> list, int splitSize) {
        List<List<T>> subLists = new ArrayList<>();
        for (int i = 0; i < list.size(); i += splitSize) {
            int endIndex = Math.min(i + splitSize, list.size());
            subLists.add(list.subList(i, endIndex));
        }
        return subLists;
    }

    @Override
    public void setIsCache(String isCache) {

        this.isCache = isCache;
        log.info("设置缓存状态:{}", isCache);

    }

    @Override
    public Object testClickHouse() {
        return null;
    }

    @Override
    public TeamReportHistory getDataByDate(Date today, String loginName) {

        /**
         *
         TeamReportHistory teamReportHistory = new TeamReportHistory();
         teamReportHistory.setType("current");
         teamReportHistory.setTurnover(0D);
         teamReportHistory.setWinorloss(0D);
         teamReportHistory.setLoginNameDate(loginName + DateUtils.dateToString(today, "yyyy-MM-dd"));
         teamReportHistory.setGgr(0D);
         teamReportHistory.setDepositAmount(0D);
         teamReportHistory.setWithdrawAmount(0D);


         String dailiName = loginName;
         DashBoardUserTreeQueryReq entity = new DashBoardUserTreeQueryReq();
         entity.setParent(dailiName);

         Result<List<TCustomerLayer>> layers = new Result<>();

         try {
         layers = userFeignService.selectUserTreeByParentNTime(entity);

         log.info("查询用户数---------={}"    ,new Gson().toJson(layers)  );
         if (layers.getData().size() > 0) {
         List<String> payers = layers.getData().stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList()); //查詢代理下的用戶数据

         Map<String, Object> parame = new HashMap<>();

         parame.put("playInfoDateStart", DateUtils.dateToString(today, "yyyy-MM-dd"));
         parame.put("playInfoDateEnd", DateUtils.dateToString(today, "yyyy-MM-dd"));

         List<TUserFinanceOrderTreed> totalDayLi = new ArrayList<>(); //  游戏指标  开始
         List<TUserFinanceDwTreed> cz = new ArrayList<>();
         List<TUserFinanceDwTreed> tx = new ArrayList<>();


         try {

         List<List<String>> splitLists = splitArrayList(payers, splitRow);
         for (List<String> sublist : splitLists) {
         parame.put("loginName", sublist);

         totalDayLi = (tDailyOrderMapper.findListByPayers(parame));   //游戏指标  开始
         //
         //
         if (totalDayLi.size() > 0) {
         teamReportHistory.setTurnover(totalDayLi.get(0).getTurnoverAmount().add(new BigDecimal(teamReportHistory.getTurnover())).doubleValue());
         teamReportHistory.setWinorloss(totalDayLi.get(0).getOutcomeAmount().add(new BigDecimal(teamReportHistory.getWinorloss())).doubleValue());
         teamReportHistory.setGgr(totalDayLi.get(0).getGgrAmount().add(new BigDecimal(teamReportHistory.getGgr())).doubleValue());
         }
         //
         cz = tDailyOrderMapper.findListByCzByPayers(parame);  //充值数据
         if (cz.size() > 0) {
         teamReportHistory.setDepositAmount(cz.get(0).getDepositAmount().add(new BigDecimal(teamReportHistory.getDepositAmount())).doubleValue());
         }

         //
         tx = tDailyOrderMapper.findListByTxByPayers(parame);
         if (tx.size() > 0) {
         teamReportHistory.setWithdrawAmount(tx.get(0).getDepositAmount().add(new BigDecimal(teamReportHistory.getWithdrawAmount())).doubleValue());
         }
         //
         //


         }


         } catch (Exception e) {

         }
         }


         } catch (Exception e) {

         }


         return teamReportHistory;
         */

        return  null;
    }

    @Override
    public TeamReportHistory getDataByMonth(Date firstMonth, Date endMonth, String loginName) {
        TeamReportHistory teamReportHistory = new TeamReportHistory();
//        teamReportHistory.setType("current");
//        teamReportHistory.setTurnover(0D);
//        teamReportHistory.setWinorloss(0D);
//        teamReportHistory.setLoginNameDate(loginName + DateUtils.dateToString(firstMonth, "yyyy-MM"));
//        teamReportHistory.setGgr(0D);
//        teamReportHistory.setDepositAmount(0D);
//        teamReportHistory.setWithdrawAmount(0D);
//
//
//        String dailiName = loginName;
//        DashBoardUserTreeQueryReq entity = new DashBoardUserTreeQueryReq();
//        entity.setParent(dailiName);
//
//        Result<List<TCustomerLayer>> layers = new Result<>();
//
//        try {
//            layers = userFeignService.selectUserTreeByParentNTime(entity);
//            if (layers.getData().size() > 0) {
//                List<String> payers = layers.getData().stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList()); //查詢代理下的用戶数据
//
//                Map<String, Object> parame = new HashMap<>();
//
//                parame.put("playInfoDateStart", DateUtils.dateToString(firstMonth, "yyyy-MM-dd"));
//                parame.put("playInfoDateEnd", DateUtils.dateToString(endMonth, "yyyy-MM-dd"));
//
//                List<TUserFinanceOrderTreed> totalDayLi = new ArrayList<>(); //  游戏指标  开始
//                List<TUserFinanceDwTreed> cz = new ArrayList<>();
//                List<TUserFinanceDwTreed> tx = new ArrayList<>();
//
//
//                try {
//
//                    List<List<String>> splitLists = splitArrayList(payers, splitRow);
//                    for (List<String> sublist : splitLists) {
//                        parame.put("loginName", sublist);
//
//                        totalDayLi = (tDailyOrderMapper.findListByPayers(parame));   //游戏指标  开始
////
////
//                        if (totalDayLi.size() > 0) {
//                            teamReportHistory.setTurnover(totalDayLi.get(0).getTurnoverAmount().add(new BigDecimal(teamReportHistory.getTurnover())).doubleValue());
//                            teamReportHistory.setWinorloss(totalDayLi.get(0).getOutcomeAmount().add(new BigDecimal(teamReportHistory.getWinorloss())).doubleValue());
//                            teamReportHistory.setGgr(totalDayLi.get(0).getGgrAmount().add(new BigDecimal(teamReportHistory.getGgr())).doubleValue());
//                        }
////
//                        cz = tDailyOrderMapper.findListByCzByPayers(parame);  //充值数据
//                        if (cz.size() > 0) {
//                            teamReportHistory.setDepositAmount(cz.get(0).getDepositAmount().add(new BigDecimal(teamReportHistory.getDepositAmount())).doubleValue());
//                        }
//
////
//                        tx = tDailyOrderMapper.findListByTxByPayers(parame);
//                        if (tx.size() > 0) {
//                            teamReportHistory.setWithdrawAmount(tx.get(0).getDepositAmount().add(new BigDecimal(teamReportHistory.getWithdrawAmount())).doubleValue());
//                        }
////
////
//
//
//                    }
//
//
//                } catch (Exception e) {
//
//                }
//            }
//
//
//        } catch (Exception e) {
//
//        }


        return teamReportHistory;

    }

    private Map<String, String> gameTypes = new HashMap<>();


    @Resource
    private TDailyOrderMapper tDailyOrderMapper;


    @PostConstruct
    public void init() {
        //  初始化Redis数据的逻辑 从 nacos 读取


//        redisUtil.set("biMaxDetailThread", biMaxDetailThread);
//        redisUtil.set("biMaxListThread", biMaxListThread);

        gameTypes.put("1", "Sports");
        gameTypes.put("22", "Sports");
        gameTypes.put("3", "Poker ");
        gameTypes.put("8", "Fishing");
        gameTypes.put("5", "Slot");
        gameTypes.put("17", "Casino ");
        gameTypes.put("21", "Ebingo");
        gameTypes.put("27", "Bingo");
        gameTypes.put("30", "Specialty Game");


    }

    @Override
    public ReportPageResponse<TeamReportResponse> queryByPageAndCondition(TeamReportRequest req) {
        ReportPageResponse<TeamReportResponse> reportPageResponse = new ReportPageResponse<TeamReportResponse>();
        //
        Date pre = DateUtils.stringToDate(splitDate, splitDateForamt);

        Date searchEndDate = DateUtils.stringToDate(req.getPlayInfoDateEnd(), "yyyy-MM-dd");

        //查询时间为 2023-10-22  切割时间为 10-23  走 BI   如果  切割时间为 20-21 走Flink
        if (searchEndDate.getTime() >= pre.getTime()) {
            log.info("走第二条数据");

            if (newBi == 2) {
                reportPageResponse = queryRealTimeRecord4(req);  //查询clickHouse

            } else {
                reportPageResponse = queryRealTimeRecord2(req);  //查询flink 数据

            }

        } else {
            log.info("走第1条数据");

            int monthFlg = req.getMonthFlg();

            String key = req.getMonthFlg() + "-" + req.getPageNum() + "-" + req.getPageSize() + "-" + req.getPlayInfoDateStart() + "-" + req.getPlayInfoDateEnd() + req.getLoginName();

            log.info("缓存状态:{}", isCache);
            if (isCache.equals("2")) {
                if (!StringUtils.isBlank(req.getAgentAccount())) {
                    key = key + "-" + req.getAgentAccount();
                }
                if (!StringUtils.isBlank(req.getParentAccount())) {
                    key = key + "-" + req.getParentAccount();
                }
                if (req.getAgentLevel() != null) {
                    key = key + "-" + req.getAgentLevel();
                }
                String lostTime = key + "_lostTime";
                if (redisUtil.hasKey(key)) {
                    //有缓存数据
                    String json = redisUtil.get(key).toString();
                    log.info("teamReportList缓存Key:{},json数据:{}", key, json);

                    JSONObject jsonObject = new JSONObject(json);

                    //解析JSON 到对象

                    reportPageResponse = getObjectList(jsonObject);

                    String finalKey = key;


                    if (!redisUtil.hasKey(lostTime)) {


                        new Thread(() -> {
                            ReportPageResponse<TeamReportResponse> lastData = queryRealTimeRecord(req);

                            redisUtil.set(finalKey, new Gson().toJson(lastData));

                            redisUtil.set(lostTime, "1");
                            redisUtil.setExpire(lostTime, expireLongTime);

//                        List<TeamReportResponse> reportResponses = lastData.getRecords();
//
//                        for (TeamReportResponse object : reportResponses
//                        ) {
//                            String listDetailKey = object.getAgentAccount() + object.getPlayInfoDate() + "_detail";
//                            Map<String, BigDecimal> oData = new HashMap<>();
//                            oData.put("turnoverSum", object.getTurnover());
//                            oData.put("ggrSum", object.getGGR());
//                            oData.put("outcomeSum", object.getWinOrLoss());
//                            redisUtil.set(listDetailKey, new Gson().toJson(oData));
//
//                        }


                        }).start();


                    }
                } else {
                    //没有缓存数据

                    reportPageResponse = queryRealTimeRecord(req);

                    redisUtil.set(key, new Gson().toJson(reportPageResponse));
                    redisUtil.set(lostTime, "1");
                    redisUtil.setExpire(lostTime, expireLongTime);

                    log.info("teamReportList设置缓存Key:{},json数据:{}", key, new Gson().toJson(reportPageResponse));

                    //没有缓存就读取到数据设置缓存

                    List<TeamReportResponse> reportResponses = reportPageResponse.getRecords();

                    for (TeamReportResponse object : reportResponses
                    ) {
                        String listDetailKey = object.getAgentAccount() + object.getPlayInfoDate() + "_detail";
                        Map<String, BigDecimal> oData = new HashMap<>();
                        oData.put("turnoverSum", object.getTurnover());
                        oData.put("ggrSum", object.getGGR());
                        oData.put("outcomeSum", object.getWinOrLoss());
                        redisUtil.set(listDetailKey, new Gson().toJson(oData));

                    }
                }


            } else {
                reportPageResponse = queryRealTimeRecord(req);

            }
        }


        return reportPageResponse;
    }

    /**
     * 最新算法  当月
     *
     * @param req
     * @return
     */
    private ReportPageResponse<TeamReportResponse> queryRealTimeRecord4(TeamReportRequest req) {

        // 0.初始化返回值
        ReportPageResponse<TeamReportResponse> response = new ReportPageResponse<>();
        response.setTotal(0);
        response.setPages(0);
        response.setSize(req.getPageSize());
        response.setCurrent(req.getPageNum());
        List<TeamReportResponse> records = new ArrayList<>();
        String loginName = req.getLoginName();


        List<TAgentCustomers> agents = new ArrayList<>();

        try {
            agents = getAllAgent(req);//先查询所有代理
        } catch (Exception e) {
//            TAgentCustomers agentCustomers =new TAgentCustomers();
//            agentCustomers.setLoginName("acc66");
//            agents.add(agentCustomers) ;

        }
//
//
        //getAllAgent(req);//先查询所有代理




        int monthFlg = req.getMonthFlg();

        if (monthFlg == 1) {
            //按月计算
            Date minDate = DateUtils.stringToDate(req.getPlayInfoDateStart(), "yyyy-MM-dd");
            Date maxDate = DateUtils.stringToDate(req.getPlayInfoDateEnd(), "yyyy-MM-dd");

            List<TeamReportResponse> responseList = new ArrayList<>();

            //先计算一共多少数据
            for (TAgentCustomers tAgentCustomers : agents) {
                while (minDate.getTime() <= maxDate.getTime()) {

                    TeamReportResponse teamReportResponse = new TeamReportResponse();
                    teamReportResponse.setPlayInfoDate(DateUtils.dateToString(minDate, "yyyy-MM"));
                    teamReportResponse.setAgentAccount(tAgentCustomers.getLoginName());
                    teamReportResponse.setParentAccount(tAgentCustomers.getParentName());
                    teamReportResponse.setAgentLevel(tAgentCustomers.getAgentLevel());

                    teamReportResponse.setTurnover(BigDecimal.ZERO);
                    teamReportResponse.setWinOrLoss(BigDecimal.ZERO);
                    teamReportResponse.setGGR(BigDecimal.ZERO);
                    teamReportResponse.setDeposit(BigDecimal.ZERO);

                    teamReportResponse.setWithdrawal(BigDecimal.ZERO);


                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(minDate);
                    calendar.add(Calendar.MONTH, 1);
                    minDate = calendar.getTime();

                    responseList.add(teamReportResponse);

                }

                minDate = DateUtils.stringToDate(req.getPlayInfoDateStart(), "yyyy-MM-dd");

            }

            log.info("一共记录数={},数量为={}", new Gson().toJson(responseList),responseList.size());

            int pageRow = (req.getPageNum() - 1) * req.getPageSize();
            int pageSize = req.getPageSize();
            if (responseList.size() < (pageRow + req.getPageSize())) {
                pageSize = responseList.size();
            } else {
                pageSize = pageRow + pageSize;
            }


            String sortName = req.getSortName();
            boolean isAsc = req.getIsAsc();
            if (StringUtils.isEmpty(req.getSortName())) {
                sortName = "playInfoDate";
                isAsc = false;
            }


            setOrder(sortName, isAsc, responseList, true, loginName);
            List<TeamReportResponse> result = responseList.subList(pageRow, pageSize);

            //
            log.info("排序后的数据={}", new Gson().toJson(responseList));


            List<TeamReportResponse> pageResult = responseList.stream()
                    .skip((long) req.getPageSize() * (req.getPageNum() - 1))
                    .limit(req.getPageSize())
                    .collect(Collectors.toList());
            response.setTotal(responseList.size());
            response.setPages(responseList.size() / req.getPageSize() + 1);

            log.info("分页后的数据代理数据={}", new Gson().toJson(pageResult));

            for (TeamReportResponse reportResponse : pageResult) {
                Date date   = new Date() ;
                Map<String, Object> p = new HashMap<>();
                p.put("min",DateUtils.dateToString(date,"yyyy-MM-dd")) ;
                p.put("max",DateUtils.dateToString(date,"yyyy-MM-dd")) ;
                p.put("loginName" ,reportResponse.getAgentAccount() );

                String key = reportResponse.getAgentAccount() + DateUtils.dateToString(new Date())+"_newToday";   //今天的key

                String json = (String) redisUtil.get(key);

                ClDashBoardDataRes   today =  new ClDashBoardDataRes();
                if(json == null) {
                       //  今天没有缓存数据  ，去查询bi
                    today  =    saveLocalData(new Date(),1,1 , reportResponse.getAgentAccount() ) ;  //1  不保存

                    redisUtil.set(key,new Gson().toJson(today)) ;

                    //设置缓存过期时间
                    redisUtil.set(key+"_lostTime",new Gson().toJson(today)) ;
                    redisUtil.setExpire(key+"_lostTime", expireLongTime);


                }else {
                    today =  new Gson().fromJson(json,ClDashBoardDataRes.class) ;  //读取缓存
                    //
                    boolean  flag  =   isExpired(key);

                    if(flag == false) {
                        new Thread(() -> {
                            ClDashBoardDataRes today2 = saveLocalData(new Date(), 1, 1, reportResponse.getAgentAccount());  //1  不保存

                            redisUtil.set(key, new Gson().toJson(today2));

                            redisUtil.set(key+"_lostTime",new Gson().toJson(today2)) ;
                            redisUtil.setExpire(key+"_lostTime", expireLongTime);

                        }).start();  //去更新
                    }

                }

                TeamReportHistory before = getBeforeDataByDate(new Date(), reportResponse.getAgentAccount());
                if (before == null) {
                    before = new TeamReportHistory();
                }

                getBeforeCount(new Date() , reportResponse.getAgentAccount()); // 看1到昨天的数量

                log.info("-----查询历史天的数据为:={},今天的数据={}", new Gson().toJson(before) ,  new Gson().toJson(today));

                reportResponse.setTurnover(getFormat(today.getTurnover().add((before.getTurnover())))  );
                reportResponse.setGGR(getFormat(today.getGgr().add((before.getGgr()))));
                reportResponse.setDeposit( getFormat(today.getDepositAmount().add((before.getDepositAmount()))));
                reportResponse.setWithdrawal(  getFormat(today.getWithdrawalAmount().add((before.getWithdrawAmount()))));
                reportResponse.setWinOrLoss(  getFormat(today.getWinOrLoss().add(before.getWinorloss())));

            }
            response.setRecords(pageResult) ;

        } else {
            int start = Integer.valueOf(req.getPlayInfoDateStart().split("-")[2]);
            int end = Integer.valueOf(req.getPlayInfoDateEnd().split("-")[2]);
            response.setTotal(agents.size()  *(end -start +1));
            response.setPages(response.getTotal() / req.getPageSize() + 1);

            List<TeamReportResponse> responseList = new ArrayList<>();

            List<TAgentCustomers> result =  getPageData(agents,req.getPageNum(),req.getPageSize(),start,end) ;

            Date today = DateUtils.stringToDate(DateUtils.dateToString(new Date()), "yyyy-MM-dd");

            for (TAgentCustomers tAgentCustomers : result) {

                String day = tAgentCustomers.getCreateBy();
                log.info("currrrr={}"  ,day   );

                Date curr = DateUtils.stringToDate(day, "yyyy-MM-dd");


                TeamReportResponse teamReportResponse = new TeamReportResponse();
                teamReportResponse.setPlayInfoDate(day);
                teamReportResponse.setAgentAccount(tAgentCustomers.getLoginName());
                teamReportResponse.setParentAccount(tAgentCustomers.getParentName());
                teamReportResponse.setAgentLevel(tAgentCustomers.getAgentLevel());

                teamReportResponse.setTurnover(BigDecimal.ZERO);
                teamReportResponse.setWinOrLoss(BigDecimal.ZERO);
                teamReportResponse.setGGR(BigDecimal.ZERO);
                teamReportResponse.setDeposit(BigDecimal.ZERO);

                teamReportResponse.setWithdrawal(BigDecimal.ZERO);




                if(curr.getTime()  < today.getTime()) {   //查询 日期 <  今天  查询缓存
                    String key = teamReportResponse.getAgentAccount() +    day ;

                    Map<String, String> p = new HashMap<>();
                    p.put("loginName", key);
                    TeamReportHistory teamReportHistory = teamReportHistoryMapper.getRowByLoginDate(p);   // 查詢緩存

                    if(teamReportHistory !=null) {
                        teamReportHistory.setCreateDateTime(curr);
                        teamReportHistory.setLoginNameDate(tAgentCustomers.getLoginName() +   DateUtils.dateToString(curr,"yyyy-MM-dd"));

                        teamReportResponse.setTurnover((teamReportHistory.getTurnover()));
                        teamReportResponse.setWinOrLoss((teamReportHistory.getWinorloss()));
                        teamReportResponse.setGGR((teamReportHistory.getGgr()));
                        teamReportResponse.setWithdrawal((teamReportHistory.getWithdrawAmount()));
                        teamReportResponse.setDeposit((teamReportHistory.getDepositAmount()));


                        long ts = DateUtils.getDayByMinusDate(curr,new Date()) ;

                        if(ts < 7 ) {
                            new Thread(() -> {
                            saveLocalData(curr,1,2,teamReportResponse.getAgentAccount()) ;
                            }).start();

                        }


                    }else {
                        ClDashBoardDataRes dataRes =    saveLocalData(curr,1,2,teamReportResponse.getAgentAccount()) ; //查询Bi


                        teamReportResponse.setTurnover((dataRes.getTurnover()));
                        teamReportResponse.setWinOrLoss((dataRes.getWinOrLoss()));
                        teamReportResponse.setGGR((dataRes.getGgr()));
                        teamReportResponse.setWithdrawal((dataRes.getWithdrawalAmount()));
                        teamReportResponse.setDeposit((dataRes.getDepositAmount()));


                    }





                }else if(curr.getTime()  ==  today.getTime()){
                    String key = tAgentCustomers.getLoginName() + DateUtils.dateToString(new Date())+"_newToday";

                    String json = (String) redisUtil.get(key);
                    ClDashBoardDataRes  today3 =  new Gson().fromJson(json,ClDashBoardDataRes.class) ;  //读取缓存


                    boolean  flag  =   isExpired(key);

                    log.info("ClDashBoardDataRes today3={},  flag={}",today3,flag);

                    //
                    if(flag == false) {
                        new Thread(() -> {
                            ClDashBoardDataRes today2 = saveLocalData(new Date(), 1, 1, tAgentCustomers.getLoginName());  //1  不保存

                            log.info("ClDashBoardDataRes,today2={} ",today2);

                            redisUtil.set(key, new Gson().toJson(today2));

                            redisUtil.set(key+"_lostTime",new Gson().toJson(today2)) ;
                            redisUtil.setExpire(key+"_lostTime", expireLongTime);
                        }).start();  //去更新
                    }
                    if(today3 ==null) {
                        today3 = new ClDashBoardDataRes();
                    }
                    teamReportResponse.setTurnover(getFormat(today3.getTurnover())  );
                    teamReportResponse.setGGR(getFormat(today3.getGgr()));
                    teamReportResponse.setDeposit( getFormat(today3.getDepositAmount() ));
                    teamReportResponse.setWithdrawal(  getFormat(today3.getWithdrawalAmount() ));
                    teamReportResponse.setWinOrLoss(  getFormat(today3.getWinOrLoss()));

                }


                responseList.add(teamReportResponse) ;

            }

            response.setRecords(responseList) ;


        }



        /**
         *
         */


        //查询这个账户下所有代理


        return response;
    }

    private BigDecimal getFormat(BigDecimal add) {

        if(add.doubleValue() > 0) {
            return  add.add(new BigDecimal(0.00002)) ;
        }else {
            return  add.subtract(new BigDecimal(0.00002));
        }
    }
    private void getBeforeCount2(  List<String> keys) {


        Map<String,Object>  parame =  new HashMap<>() ;
        parame.put("loginName",keys) ;


     Long    day   =   teamReportHistoryMapper.getCountRow2(parame );

     log.info("------day={},,,keysziue={}",day,keys.size());

     if(day.intValue() !=  keys.size()){

         for(String string : keys) {
             String  longName  =  string.substring(0,string.length()- 10) ;
             String  date  =    string.replaceAll(longName,"") ;
             TeamReportError obj = new TeamReportError() ;
             obj.setType("month");
             obj.setStatus("1");
                 obj.setId(string);
                 obj.setCreatetime(DateUtils.stringToDate(date  + " 03:00:01","yyyy-MM-dd HH:mm:ss"));

             obj.setLoginName(longName);

             try {
                 teamReportErrorMapper.insert(obj) ;
             }catch (Exception e) {

             }

         }
     }

    }
    private Long getBeforeCount(Date date, String agentAccount) {
        Long day = 0L ;
        //如果是1号 直接返回  0
        int days =   DateUtils.getDayOfDate(date) ;
        if(days == 1) {
            return    0L ;
        }
        String keys = agentAccount + DateUtils.dateToString(DateUtils.stringToDate(DateUtils.dateToString(date), "yyyy-MM-"), "yyyy-MM-");
        Map<String, String> parame = new HashMap<>();

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);

        calendar.add(Calendar.DAY_OF_MONTH, -1);

        String dayMonth =   DateUtils.dateToString(date,"yyyy-MM") ;



        parame.put("agentAccount", keys + "%");
        day   =   teamReportHistoryMapper.getCountRow(parame );

        //如果不一样 就更新 1号到 昨天的 如果是 一样 就更新 7天的
        if((day +1) != days ) {
            //去更新1号到 昨天的
            for (var i  =1 ; i <  days;i++) {



                TeamReportError obj = new TeamReportError() ;
                obj.setType("month");
                obj.setStatus("1");
                if( i <10 ) {
                    obj.setId(agentAccount+dayMonth+"-0" +  i);
                    obj.setCreatetime(DateUtils.stringToDate(dayMonth+"-0" +  i+  " 03:00:01","yyyy-MM-dd HH:mm:ss"));
                }else {
                    obj.setId(agentAccount+dayMonth+"-" +  i);
                    obj.setCreatetime(DateUtils.stringToDate(dayMonth+"-" +  i + " 03:00:01","yyyy-MM-dd HH:mm:ss"));

                }
                obj.setLoginName(agentAccount);

                try {
                    teamReportErrorMapper.insert(obj) ;
                }catch (Exception e) {

                }
            }
        }else {
            int s    =  days -7;
            if(s <1) {
                s =1 ;
            }
            for (var i  =s ; i <  days;i++) {

                TeamReportError obj = new TeamReportError() ;
                obj.setType("month");
                obj.setStatus("1");
                if( i <10 ) {
                    obj.setId(agentAccount+dayMonth+"-0" +  i);

                    obj.setCreatetime(DateUtils.stringToDate(dayMonth+"-0" +  i+  " 03:00:01","yyyy-MM-dd HH:mm:ss"));
                }else {
                    obj.setId(agentAccount+dayMonth+"-" +  i);

                    obj.setCreatetime(DateUtils.stringToDate(dayMonth+"-" +  i + " 03:00:01","yyyy-MM-dd HH:mm:ss"));

                }
                obj.setLoginName(agentAccount);
                try {
                    teamReportErrorMapper.insert(obj) ;
                }catch (Exception e) {

                }
            }

        }


        return  day;
    }

    @Autowired
    private TeamReportErrorMapper teamReportErrorMapper ;

    /**
     * 获取 本月 第一天 到昨天的数据
     *
     * @param date
     * @param agentAccount
     * @return
     */
    private TeamReportHistory getBeforeDataByDate(Date date, String agentAccount) {

        String keys = agentAccount + DateUtils.dateToString(DateUtils.stringToDate(DateUtils.dateToString(date), "yyyy-MM-"), "yyyy-MM-");
        ;

        Map<String, String> parame = new HashMap<>();

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);

        calendar.add(Calendar.DAY_OF_MONTH, -1);


        parame.put("agentAccount", keys + "%");

        log.info("查询前1天的数据参数为:={}", new Gson().toJson(parame));

        TeamReportHistory history = teamReportHistoryMapper.getDateByMonth(parame);


        return history;
    }


    /**
     * 查询clickHouse 数据
     *
     * @param req
     * @return
     */
    private ReportPageResponse<TeamReportResponse> queryRealTimeRecord3(TeamReportRequest req) {

        // 0.初始化返回值
        ReportPageResponse<TeamReportResponse> response = new ReportPageResponse<>();
        response.setTotal(0);
        response.setPages(0);
        response.setSize(req.getPageSize());
        response.setCurrent(req.getPageNum());
        List<TeamReportResponse> records = new ArrayList<>();
        Map<String, BigDecimal> pageSumMap = response.getPageSumMap();
        initMap(pageSumMap);
        Map<String, BigDecimal> searchSumMap = response.getSearchSumMap();
        initMap(searchSumMap);
        String loginName = req.getLoginName();

        // 1.根据loginName查询所有下线代理
//        List<TAgentCustomers> allAgent = getAllAgent(req);//线上环境  ,,,,,
//
        List<TAgentCustomers> allAgent = new ArrayList<>();

        TAgentCustomers ooo = new TAgentCustomers();
        ooo.setLoginName("bingoplus60ekm4");
//        allAgent.add(ooo) ;

        ooo = new TAgentCustomers();
        ooo.setLoginName("zya2023112811");

        allAgent.add(ooo);


        List<TAgentCustomers> agents = allAgent.stream().filter(a -> {
                    // Account 过滤
                    if (StringUtils.isNotEmpty(req.getAgentAccount()) && !a.getLoginName().equals(req.getAgentAccount())) {
                        return false;
                    }
                    if (StringUtils.isNotEmpty(req.getParentAccount()) && !a.getParentName().equals(req.getParentAccount())) {
                        return false;
                    }
                    if (req.getAgentLevel() != null && !Objects.equals(a.getAgentLevel(), req.getAgentLevel())) {
                        return false;
                    }
                    return true;
                }
        ).collect(Collectors.toList());
        agents = allAgent;
        TeamReportResponse reportResponse = new TeamReportResponse();

        if (agents.size() == 0) {
            response.setTotal(0L);
            response.setRecords(null);
            response.setPageSumMap(pageSumMap);
            response.setSearchSumMap(searchSumMap);
            return response;
        }


        Integer monthFlg = req.getMonthFlg();

        List<String> agentNames = agents.stream().map(TAgentCustomers::getLoginName).collect(Collectors.toList());

        if (monthFlg == 1) {
            //按月 统计


            BigDecimal searchSumMapGGR = new BigDecimal(0);
            BigDecimal searchSumMapDposit = new BigDecimal(0);
            BigDecimal searchSumMapTurnover = new BigDecimal(0);
            BigDecimal searchSumMapWinAndLoss = new BigDecimal(0);
            BigDecimal searchSumMapWithdrawal = new BigDecimal(0);


            Map<String, Object> parame = new HashMap<>();
//            if(agentNames.)
            parame.put("loginName", agentNames);
            parame.put("playInfoDateStart", req.getPlayInfoDateStart());
            parame.put("playInfoDateEnd", req.getPlayInfoDateEnd());

            List<TUserFinanceOrderTreed> list = tDailyOrderMapper.findList(parame); // 查询 游戏数据 按月统计 查询最新clickHouse 数据

            Map<String, TUserFinanceOrderTreed> orderTreedMap = new HashMap<>();

            for (TUserFinanceOrderTreed obj : list) {
                orderTreedMap.put(obj.getRecordDate() + "_" + obj.getLoginName(), obj);
            }

            Map<String, TUserFinanceDwTreed> czTreedMap = new HashMap<>();

            List<TUserFinanceDwTreed> list2 = tDailyOrderMapper.findListByCz(parame);// 查询 充值数据  查询最新clickHouse 数据

            List<TUserFinanceDwTreed> list3 = tDailyOrderMapper.findListByTx(parame);// 查询 提现数据  查询最新clickHouse 数据


            for (TUserFinanceDwTreed obj : list2) {
                czTreedMap.put(obj.getRecordDate() + "_" + obj.getLoginName(), obj);
            }

            Map<String, TUserFinanceDwTreed> txTreedMap = new HashMap<>();
            for (TUserFinanceDwTreed obj : list3) {
                txTreedMap.put(obj.getRecordDate() + "_" + obj.getLoginName(), obj);
            }

            List<TeamReportResponse> responseList = new ArrayList<>();
            Date minDate = DateUtils.stringToDate(req.getPlayInfoDateStart(), "yyyy-MM-dd");
            Date maxDate = DateUtils.stringToDate(req.getPlayInfoDateEnd(), "yyyy-MM-dd");


            for (TAgentCustomers tAgentCustomers : agents) {
                while (minDate.getTime() <= maxDate.getTime()) {

                    TeamReportResponse teamReportResponse = new TeamReportResponse();
                    teamReportResponse.setPlayInfoDate(DateUtils.dateToString(minDate, "yyyy-MM"));
                    teamReportResponse.setAgentAccount(tAgentCustomers.getLoginName());
                    teamReportResponse.setParentAccount(tAgentCustomers.getParentName());
                    teamReportResponse.setAgentLevel(tAgentCustomers.getAgentLevel());
                    TUserFinanceOrderTreed userData = orderTreedMap.get(DateUtils.dateToString(minDate, "yyyyMM") + "_" + tAgentCustomers.getLoginName());
                    TUserFinanceDwTreed userCzData = czTreedMap.get(DateUtils.dateToString(minDate, "yyyMM") + "_" + tAgentCustomers.getLoginName());
                    TUserFinanceDwTreed userTxData = txTreedMap.get(DateUtils.dateToString(minDate, "yyyMM") + "_" + tAgentCustomers.getLoginName());

                    if (userData != null) {
                        teamReportResponse.setTurnover(userData.getTurnoverAmount());
                        teamReportResponse.setGGR(userData.getGgrAmount());
                        teamReportResponse.setWinOrLoss(userData.getOutcomeAmount());
                    } else {
                        teamReportResponse.setTurnover(BigDecimal.ZERO);
                        teamReportResponse.setGGR(BigDecimal.ZERO);
                        teamReportResponse.setWinOrLoss(BigDecimal.ZERO);
                    }


                    if (userCzData != null) {
                        teamReportResponse.setDeposit(userCzData.getDepositAmount());
                    } else {
                        teamReportResponse.setDeposit(BigDecimal.ZERO);
                    }

                    if (userTxData != null) {
                        teamReportResponse.setWithdrawal(userTxData.getWithdrawAmount());
                    } else {
                        teamReportResponse.setWithdrawal(BigDecimal.ZERO);

                    }

                    searchSumMapGGR = searchSumMapGGR.add(teamReportResponse.getGGR());
                    searchSumMapDposit = searchSumMapDposit.add(teamReportResponse.getDeposit());
                    searchSumMapTurnover = searchSumMapTurnover.add(teamReportResponse.getTurnover());
                    searchSumMapWinAndLoss = searchSumMapWinAndLoss.add(teamReportResponse.getWinOrLoss());
                    searchSumMapWithdrawal = searchSumMapWithdrawal.add(teamReportResponse.getWithdrawal());


                    responseList.add(teamReportResponse);
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(minDate);
                    calendar.add(Calendar.MONTH, 1);
                    minDate = calendar.getTime();

                }

                minDate = DateUtils.stringToDate(req.getPlayInfoDateStart(), "yyyy-MM-dd");
            }

            searchSumMap.put("GGR", searchSumMapGGR.setScale(2, RoundingMode.DOWN));
            searchSumMap.put("deposit", searchSumMapDposit.setScale(2, RoundingMode.DOWN));

            searchSumMap.put("turnover", searchSumMapTurnover.setScale(2, RoundingMode.DOWN));
            searchSumMap.put("winAndLoss", searchSumMapWinAndLoss.setScale(2, RoundingMode.DOWN));
            searchSumMap.put("withdrawal", searchSumMapWithdrawal.setScale(2, RoundingMode.DOWN));


            String sortName = req.getSortName();
            boolean isAsc = req.getIsAsc();
            if (StringUtils.isEmpty(req.getSortName())) {
                sortName = "playInfoDate";
                isAsc = false;
            }
            setOrder(sortName, isAsc, responseList, true, loginName);
            List<TeamReportResponse> pageResult = responseList.stream()
                    .skip((long) req.getPageSize() * (req.getPageNum() - 1))
                    .limit(req.getPageSize())
                    .collect(Collectors.toList());
            response.setRecords(pageResult);
            response.setTotal(responseList.size());
            response.setPages(records.size() / req.getPageSize() + 1);
            log.info("查询结果 :{}" + new Gson().toJson(list));


            BigDecimal pageGGR = new BigDecimal(0);
            BigDecimal pageDposit = new BigDecimal(0);
            BigDecimal pageTurnover = new BigDecimal(0);
            BigDecimal pageWinAndLoss = new BigDecimal(0);
            BigDecimal pageWithdrawal = new BigDecimal(0);

            for (TeamReportResponse teamReportResponse : pageResult) {
                pageGGR = pageGGR.add(teamReportResponse.getGGR());
                pageDposit = pageDposit.add(teamReportResponse.getDeposit());
                pageTurnover = pageTurnover.add(teamReportResponse.getTurnover());
                pageWinAndLoss = pageWinAndLoss.add(teamReportResponse.getWinOrLoss());
                pageWithdrawal = pageWithdrawal.add(teamReportResponse.getWithdrawal());
            }

            pageSumMap.put("GGR", pageGGR.setScale(2, RoundingMode.DOWN));
            pageSumMap.put("deposit", pageDposit.setScale(2, RoundingMode.DOWN));
            pageSumMap.put("turnover", pageTurnover.setScale(2, RoundingMode.DOWN));
            pageSumMap.put("winAndLoss", pageWinAndLoss.setScale(2, RoundingMode.DOWN));
            pageSumMap.put("withdrawal", pageWithdrawal.setScale(2, RoundingMode.DOWN));
            response.setSearchSumMap(searchSumMap);
            response.setPageSumMap(pageSumMap);


            log.info("返回数据mmmm:{}", searchSumMap);

        } else {
            {
                //按天 统计

                Map<String, Object> parame = new HashMap<>();
                parame.put("loginName", agentNames);
                parame.put("playInfoDateStart", req.getPlayInfoDateStart());
                parame.put("playInfoDateEnd", req.getPlayInfoDateEnd());

                int start = Integer.valueOf(req.getPlayInfoDateStart().split("-")[2]);
                int end = Integer.valueOf(req.getPlayInfoDateEnd().split("-")[2]);

                BigDecimal searchSumMapGGR = new BigDecimal(0);
                BigDecimal searchSumMapDposit = new BigDecimal(0);
                BigDecimal searchSumMapTurnover = new BigDecimal(0);
                BigDecimal searchSumMapWinAndLoss = new BigDecimal(0);
                BigDecimal searchSumMapWithdrawal = new BigDecimal(0);


                List<TUserFinanceOrderTreed> list = tDailyOrderMapper.findListByDay(parame); // 查询 游戏数据 按天统计 查询clickHouse

                Map<String, TUserFinanceOrderTreed> orderTreedMap = new HashMap<>();

                for (TUserFinanceOrderTreed obj : list) {
                    orderTreedMap.put(obj.getRecordDate() + "_" + obj.getLoginName(), obj);
                }

                Map<String, TUserFinanceDwTreed> czTreedMap = new HashMap<>();

                List<TUserFinanceDwTreed> list2 = tDailyOrderMapper.findListByDayCz(parame);// 查询 存取数据  按天统计 查询clickHouse

                for (TUserFinanceDwTreed obj : list2) {
                    czTreedMap.put(obj.getRecordDate() + "_" + obj.getLoginName(), obj);
                }


                List<TUserFinanceDwTreed> list3 = tDailyOrderMapper.findListByDayTx(parame);// 查询 存取数据  按天统计 查询clickHouse
                Map<String, TUserFinanceDwTreed> txTreedMap = new HashMap<>();
                for (TUserFinanceDwTreed obj : list3) {
                    txTreedMap.put(obj.getRecordDate() + "_" + obj.getLoginName(), obj);
                }

                List<TeamReportResponse> responseList = new ArrayList<>();
                for (TAgentCustomers tAgentCustomers : agents) {

                    for (int i = start; i <= end; i++) {
                        String day = "";
                        if (i < 10) {
                            day = req.getPlayInfoDateStart().substring(0, 7) + "-0" + i;
                        } else {
                            day = req.getPlayInfoDateStart().substring(0, 7) + "-" + i;
                        }


                        TeamReportResponse teamReportResponse = new TeamReportResponse();
                        teamReportResponse.setPlayInfoDate(day);
                        teamReportResponse.setAgentAccount(tAgentCustomers.getLoginName());
                        teamReportResponse.setParentAccount(tAgentCustomers.getParentName());
                        teamReportResponse.setAgentLevel(tAgentCustomers.getAgentLevel());
                        TUserFinanceOrderTreed userData = orderTreedMap.get(day.replaceAll("-", "") + "_" + tAgentCustomers.getLoginName());
                        TUserFinanceDwTreed userCzData = czTreedMap.get(day.replaceAll("-", "") + "_" + tAgentCustomers.getLoginName());
                        TUserFinanceDwTreed userTxData = txTreedMap.get(day.replaceAll("-", "") + "_" + tAgentCustomers.getLoginName());

                        if (userData != null) {
                            teamReportResponse.setTurnover(userData.getTurnoverAmount());
                            teamReportResponse.setGGR(userData.getGgrAmount());
                            teamReportResponse.setWinOrLoss(userData.getOutcomeAmount());
                        } else {
                            teamReportResponse.setTurnover(BigDecimal.ZERO);
                            teamReportResponse.setGGR(BigDecimal.ZERO);
                            teamReportResponse.setWinOrLoss(BigDecimal.ZERO);
                        }


                        if (userCzData != null) {
                            teamReportResponse.setDeposit(userCzData.getDepositAmount());
                        } else {
                            teamReportResponse.setDeposit(BigDecimal.ZERO);
                        }

                        if (userTxData != null) {
                            teamReportResponse.setWithdrawal(userTxData.getDepositAmount());
                        } else {
                            teamReportResponse.setWithdrawal(BigDecimal.ZERO);
                        }

                        searchSumMapGGR = searchSumMapGGR.add(teamReportResponse.getGGR());
                        searchSumMapDposit = searchSumMapDposit.add(teamReportResponse.getDeposit());
                        searchSumMapTurnover = searchSumMapTurnover.add(teamReportResponse.getTurnover());
                        searchSumMapWinAndLoss = searchSumMapWinAndLoss.add(teamReportResponse.getWinOrLoss());
                        searchSumMapWithdrawal = searchSumMapWithdrawal.add(teamReportResponse.getWithdrawal());

                        responseList.add(teamReportResponse);
                    }

                }

                searchSumMap.put("GGR", searchSumMapGGR.setScale(2, RoundingMode.DOWN));
                searchSumMap.put("deposit", searchSumMapDposit.setScale(2, RoundingMode.DOWN));
                searchSumMap.put("turnover", searchSumMapTurnover.setScale(2, RoundingMode.DOWN));
                searchSumMap.put("winAndLoss", searchSumMapWinAndLoss.setScale(2, RoundingMode.DOWN));
                searchSumMap.put("withdrawal", searchSumMapWithdrawal.setScale(2, RoundingMode.DOWN));


                String sortName = req.getSortName();
                boolean isAsc = req.getIsAsc();
                if (StringUtils.isEmpty(req.getSortName())) {
                    sortName = "playInfoDate";
                    isAsc = false;
                }
                setOrder(sortName, isAsc, responseList, true, loginName);
                List<TeamReportResponse> pageResult = responseList.stream()
                        .skip((long) req.getPageSize() * (req.getPageNum() - 1))
                        .limit(req.getPageSize())
                        .collect(Collectors.toList());
                response.setRecords(pageResult);
                response.setTotal(responseList.size());
                response.setPages(responseList.size() / req.getPageSize() + 1);
                log.info("查询结果 :{}" + new Gson().toJson(list));

                BigDecimal pageGGR = new BigDecimal(0);
                BigDecimal pageDposit = new BigDecimal(0);
                BigDecimal pageTurnover = new BigDecimal(0);
                BigDecimal pageWinAndLoss = new BigDecimal(0);
                BigDecimal pageWithdrawal = new BigDecimal(0);

                for (TeamReportResponse teamReportResponse : pageResult) {
                    pageGGR = pageGGR.add(teamReportResponse.getGGR());
                    pageDposit = pageDposit.add(teamReportResponse.getDeposit());
                    pageTurnover = pageTurnover.add(teamReportResponse.getTurnover());
                    pageWinAndLoss = pageWinAndLoss.add(teamReportResponse.getWinOrLoss());
                    pageWithdrawal = pageWithdrawal.add(teamReportResponse.getWithdrawal());
                }
                pageSumMap.put("GGR", pageGGR.setScale(2, RoundingMode.DOWN));
                pageSumMap.put("deposit", pageDposit.setScale(2, RoundingMode.DOWN));
                pageSumMap.put("turnover", pageTurnover.setScale(2, RoundingMode.DOWN));
                pageSumMap.put("winAndLoss", pageWinAndLoss.setScale(2, RoundingMode.DOWN));
                pageSumMap.put("withdrawal", pageWithdrawal.setScale(2, RoundingMode.DOWN));


                response.setSearchSumMap(searchSumMap);
                response.setPageSumMap(pageSumMap);

            }
        }


        return response;
    }

    private ReportPageResponse<TeamReportResponse> getObjectList(JSONObject jsonObject) {

        ReportPageResponse<TeamReportResponse> data = new ReportPageResponse<TeamReportResponse>();

        int current = jsonObject.getInt("current");

        boolean optimizeCountSql = jsonObject.getBoolean("optimizeCountSql");

        int total = jsonObject.getInt("total");


        int size = jsonObject.getInt("size");

        data.setCurrent(current);
        data.setOptimizeCountSql(optimizeCountSql);
        data.setTotal(total);
        int pages = total / size;
        if (total % size != 0) {
            pages++;
        }
        data.setPages(pages);
        data.setSize(size);

        List<TeamReportResponse> list = new ArrayList<>();

        JSONArray array = jsonObject.getJSONArray("records");
        log.info("解析前Array数据:{}", array.toString());

        for (int i = 0; i < array.length(); i++) {

            TeamReportResponse object = new TeamReportResponse();

            JSONObject jsonO = array.getJSONObject(i);

            //查看列表明细的有无Key

            String listKey = jsonO.get("agentAccount").toString() + jsonO.get("playInfoDate").toString() + "_detail";


            if (redisUtil.hasKey(listKey)) {
                String json = redisUtil.get(listKey).toString();
                log.info("处理列表缓存:{},json:{}", listKey, json);

                JSONObject ooo = new JSONObject(json);


                if (ooo.has("turnoverSum")) {
                    object.setTurnover(new BigDecimal(ooo.get("turnoverSum").toString()));
                } else {
                    object.setTurnover(jsonO.getBigDecimal("turnover"));

                }

                if (ooo.has("ggrSum")) {
                    object.setGGR(new BigDecimal(ooo.get("ggrSum").toString()));
                } else {
                    object.setGGR(jsonO.getBigDecimal("GGR"));

                }

                if (ooo.has("outcomeSum")) {
                    object.setWinOrLoss(new BigDecimal(ooo.get("outcomeSum").toString()));
                } else {
                    object.setWinOrLoss(jsonO.getBigDecimal("winOrLoss"));
                }

            } else {
                object.setGGR(jsonO.getBigDecimal("GGR"));
                object.setWinOrLoss(jsonO.getBigDecimal("winOrLoss"));
                object.setTurnover(jsonO.getBigDecimal("turnover"));

            }
            object.setPlayInfoDate(jsonO.getString("playInfoDate"));
            object.setAgentAccount(jsonO.getString("agentAccount"));
            object.setParentAccount(jsonO.getString("parentAccount"));
            object.setAgentLevel(Integer.valueOf(Double.valueOf(jsonO.get("agentLevel").toString()).intValue()));
            object.setDeposit(jsonO.getBigDecimal("deposit"));
            object.setWithdrawal(jsonO.getBigDecimal("withdrawal"));
            list.add(object);
        }


        data.setRecords(list);

        return data;
    }

    @Override
    public List<com.mkt.agent.report.req.TAgentCustomers> findAllAgent() {

        List<com.mkt.agent.report.req.TAgentCustomers> list = teamReportMapper.findAllAgent();

        return list;
    }

    @Override
    public ReportPageResponse<TeamReportResponse> history(TeamReportRequest req) {

        // 0.初始化返回值
        ReportPageResponse<TeamReportResponse> response = new ReportPageResponse<>();
        response.setTotal(0);
        response.setPages(0);
        response.setSize(req.getPageSize());
        response.setCurrent(req.getPageNum());
        List<TeamReportResponse> records = new ArrayList<>();
        Map<String, BigDecimal> pageSumMap = response.getPageSumMap();
        initMap(pageSumMap);
        Map<String, BigDecimal> searchSumMap = response.getSearchSumMap();
        initMap(searchSumMap);
        String loginName = req.getLoginName();

        List<TAgentCustomers> allAgent = new ArrayList<>();

        try {
            allAgent = getAllAgent(req);//先查询所有代理
        } catch (Exception e) {

        }
//
//

//        agents = allAgent;

        BigDecimal pageSumMapGGR = new BigDecimal(0);
        BigDecimal pageSumMapDposit = new BigDecimal(0);
        BigDecimal pageSumMapTurnover = new BigDecimal(0);
        BigDecimal pageSumMapWinAndLoss = new BigDecimal(0);
        BigDecimal pageSumMapWithdrawal = new BigDecimal(0);


        int monthFlg = req.getMonthFlg();

        if (monthFlg == 1) {
            //按月计算
            Date minDate = DateUtils.stringToDate(req.getPlayInfoDateStart(), "yyyy-MM-dd");
            Date maxDate = DateUtils.stringToDate(req.getPlayInfoDateEnd(), "yyyy-MM-dd");

            List<TeamReportResponse> responseList = new ArrayList<>();

            //先计算一共多少数据
            for (TAgentCustomers tAgentCustomers : allAgent) {
                while (minDate.getTime() <= maxDate.getTime()) {

                    TeamReportResponse teamReportResponse = new TeamReportResponse();

                    teamReportResponse.setTurnover(BigDecimal.ZERO);
                    teamReportResponse.setWinOrLoss(BigDecimal.ZERO);
                    teamReportResponse.setGGR(BigDecimal.ZERO);
                    teamReportResponse.setDeposit(BigDecimal.ZERO);

                    teamReportResponse.setWithdrawal(BigDecimal.ZERO);

                    teamReportResponse.setPlayInfoDate(DateUtils.dateToString(minDate, "yyyy-MM"));
                    teamReportResponse.setAgentAccount(tAgentCustomers.getLoginName());
                    teamReportResponse.setParentAccount(tAgentCustomers.getParentName());
                    teamReportResponse.setAgentLevel(tAgentCustomers.getAgentLevel());

                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(minDate);
                    calendar.add(Calendar.MONTH, 1);
                    minDate = calendar.getTime();

                    responseList.add(teamReportResponse);


                }

                minDate = DateUtils.stringToDate(req.getPlayInfoDateStart(), "yyyy-MM-dd");

            }

            log.info("一共记录数={}", new Gson().toJson(responseList));

            int pageRow = (req.getPageNum() - 1) * req.getPageSize();
            int pageSize = req.getPageSize();
            if (responseList.size() < (pageRow + req.getPageSize())) {
                pageSize = responseList.size();
            } else {
                pageSize = pageRow + pageSize;
            }


            String sortName = req.getSortName();
            boolean isAsc = req.getIsAsc();
            if (StringUtils.isEmpty(req.getSortName())) {
                sortName = "playInfoDate";
                isAsc = false;
            }


            setOrder(sortName, isAsc, responseList, true, loginName);
            List<TeamReportResponse> result = responseList.subList(pageRow, pageSize);

            //
            log.info("排序后的数据={}", new Gson().toJson(responseList));


            List<TeamReportResponse> pageResult = responseList.stream()
                    .skip((long) req.getPageSize() * (req.getPageNum() - 1))
                    .limit(req.getPageSize())
                    .collect(Collectors.toList());
            response.setTotal(responseList.size());
            response.setPages(responseList.size() / req.getPageSize() + 1);

            log.info("分页后的数据代理数据={}", new Gson().toJson(pageResult));

            for (TeamReportResponse reportResponse : pageResult) {
                log.info("------按月的数据={}" ,new Gson().toJson(reportResponse));

                Date first  = DateUtils.stringToDate(reportResponse.getPlayInfoDate() + "-01") ;

                Date  end =   DateUtils.getLastDayOfMonth(first) ;

                String key  =  reportResponse.getAgentAccount() +  reportResponse.getPlayInfoDate() ;

                Date t = DateUtils.getFirstDayOfMonth(new Date());

                Map<String, String> p = new HashMap<>();
                p.put("loginName", key);
                TeamReportHistory teamReportHistory = teamReportHistoryMapper.getRowByLoginDate(p);   // 查詢緩存

                long mius =   DateUtils.getMonthByMinusDate(first,t);

                log.info("---月数,,,,={}",mius);
                boolean  flag = isExpired(reportResponse.getAgentAccount() + reportResponse.getPlayInfoDate()) ;

                if(teamReportHistory == null  ||  flag  == false  ) {
                    Date date = DateUtils.stringToDate(reportResponse.getPlayInfoDate() + "-01", "yyyy-MM-dd");

                    ClDashBoardDataRes data2 = saveLocalData(date, 2, 2, reportResponse.getAgentAccount());

                    reportResponse.setTurnover(data2.getTurnover());
                    reportResponse.setWithdrawal(data2.getWithdrawalAmount());
                    reportResponse.setGGR(data2.getGgr());
                    reportResponse.setWinOrLoss(data2.getWinOrLoss());
                    reportResponse.setDeposit(data2.getDepositAmount());

                    redisUtil.set(reportResponse.getAgentAccount() + reportResponse.getPlayInfoDate()+"_lostTime", new Gson().toJson(reportResponse));
                    redisUtil.setExpire(reportResponse.getAgentAccount() + reportResponse.getPlayInfoDate()+"_lostTime",expireLongTime);

                }else {
                    reportResponse.setTurnover(teamReportHistory.getTurnover());
                    reportResponse.setWithdrawal(teamReportHistory.getWithdrawAmount());
                    reportResponse.setGGR(teamReportHistory.getGgr());
                    reportResponse.setWinOrLoss(teamReportHistory.getWinorloss());
                    reportResponse.setDeposit(teamReportHistory.getDepositAmount());
                }

            }

            response.setRecords(pageResult);


        }




        return response;
    }


    public  boolean  isExpired(String key){
        boolean  f   =  false ;
        Object  data   =   redisUtil.get(key +"_lostTime");
        if(data != null   &&  !StringUtils.isBlank(data.toString())){
            f  = true;
        }
        return  f ;
    }



    @Resource
    private RedisUtil redisUtil;

    /**
     * @param req req
     * @return 结果VO
     */
    @Override
    public TeamReportByGameResponse getGameReport(TeamReportByGameRequest req) {
        TeamReportByGameResponse data = null; //返回的数据


        Date pre = DateUtils.stringToDate(splitDate, splitDateForamt);

        Date searchEndDate = new Date();
        if (!StringUtils.isBlank(req.getDate())) {

            searchEndDate = DateUtils.stringToDate(req.getDate(), "yyyy-MM-dd");
        } else {
            searchEndDate = DateUtils.stringToDate(req.getMonth() + "-01", "yyyy-MM-dd");
        }

        //查询时间为 2023-10-22  切割时间为 10-23  走 BI   如果  切割时间为 20-21 走Flink
        if (searchEndDate.getTime() >= pre.getTime()) {
            log.info("走第二条数据");
            if (newBi == 2) {
                data = getGameReportData4(req);

            } else {
                data = getGameReportData2(req);
            }
        } else {


            log.info("缓存状态 isCacheDetail:{}", isCacheDetail);

            if (isCacheDetail.equals("2")) {
                String key1 = "";
                if (!StringUtils.isBlank(req.getMonth())) {
                    key1 = req.getAgentAccount() + req.getMonth() + "_listDetail";
                } else {
                    key1 = req.getAgentAccount() + req.getDate() + "_listDetail";

                }
                String lostTime = key1 + "_lostTime";

                if (redisUtil.hasKey(key1)) {
                    //去解析成对象
                    String json = redisUtil.get(key1).toString();
                    data = new Gson().fromJson(json, TeamReportByGameResponse.class);
                    key1 = "";
                    if (!StringUtils.isBlank(req.getMonth())) {
                        key1 = req.getAgentAccount() + req.getMonth() + "_detail";
                    } else {
                        key1 = req.getAgentAccount() + req.getDate() + "_detail";

                    }
                    Map<String, BigDecimal> oData2 = new HashMap<>();
                    oData2.put("turnoverSum", data.getTurnoverSum());
                    oData2.put("ggrSum", data.getGgrSum());
                    oData2.put("outcomeSum", data.getOutcomeSum());
                    redisUtil.set(key1, new Gson().toJson(oData2));

                    log.info("读取到缓存就去更新数据:{},key:{}", new Gson().toJson(oData2), key1);

                    //读取完缓存  再线程 去查询最新数据


                    if (!redisUtil.hasKey(lostTime)) {
                        new Thread(() -> {

                            try {
                                TeamReportByGameResponse reportByGameResponse = getGameReportData(req);
                                String key11 = "";
                                if (!StringUtils.isBlank(req.getMonth())) {
                                    key11 = req.getAgentAccount() + req.getMonth() + "_listDetail";
                                } else {
                                    key11 = req.getAgentAccount() + req.getDate() + "_listDetail";

                                }
                                log.info("列表详情key:{},数据为:{}", key11, new Gson().toJson(reportByGameResponse));


                                redisUtil.set(key11, new Gson().toJson(reportByGameResponse));

                                key11 = "";
                                if (!StringUtils.isBlank(req.getMonth())) {
                                    key11 = req.getAgentAccount() + req.getMonth() + "_detail";
                                } else {
                                    key11 = req.getAgentAccount() + req.getDate() + "_detail";

                                }
                                Map<String, BigDecimal> oData = new HashMap<>();
                                oData.put("turnoverSum", reportByGameResponse.getTurnoverSum());
                                oData.put("ggrSum", reportByGameResponse.getGgrSum());
                                oData.put("outcomeSum", reportByGameResponse.getOutcomeSum());
                                redisUtil.set(key11, new Gson().toJson(oData));

                                log.info("teamReportList缓存KeyDetail:{},json数据:{}", key11, new Gson().toJson(oData));
                                redisUtil.set(lostTime, "1");
                                redisUtil.setExpire(lostTime, expireLongTime);


                            } catch (Exception e) {
                                log.info("错误数据:{}", e.getMessage());
                            } finally {

                            }

                        }).start();
                    }

                } else {
                    data = getGameReportData(req);

                    log.info("缓存详情keyDetail:{},json数据:{}", key1, new Gson().toJson(data));


                    redisUtil.set(key1, new Gson().toJson(data));  //先缓存详情的列表数据

                    redisUtil.set(lostTime, "1");
                    redisUtil.setExpire(lostTime, expireLongTime);


                    //再更新 列表中明细数据

                    key1 = "";
                    if (!StringUtils.isBlank(req.getMonth())) {
                        key1 = req.getAgentAccount() + req.getMonth() + "_detail";
                    } else {
                        key1 = req.getAgentAccount() + req.getDate() + "_detail";

                    }
                    Map<String, BigDecimal> oData = new HashMap<>();
                    oData.put("turnoverSum", data.getTurnoverSum());
                    oData.put("ggrSum", data.getGgrSum());
                    oData.put("outcomeSum", data.getOutcomeSum());
                    redisUtil.set(key1, new Gson().toJson(oData));

                    log.info("teamReportList缓存Key:{},json数据:{}", key1, new Gson().toJson(oData));


                }

            } else {
                data = getGameReportData(req);

            }
        }


        return data;


    }

    private TeamReportByGameResponse getGameReportData4(TeamReportByGameRequest req) {
        TeamReportByGameResponse reportByGameResponse = new TeamReportByGameResponse();

        BigDecimal ggrSum = new BigDecimal(0);
        BigDecimal turnoverSum = new BigDecimal(0);
        BigDecimal outcomeSum = new BigDecimal(0);

        String  agentAccount   =  req.getAgentAccount() ;

        String  date  = req.getDate() ;

        String  month  = req.getMonth() ;

        String time = "" ;
        List<UserGameSummerResponse> list =   new ArrayList<>() ;

        Map<String, UserGameSummerResponse> map2 = new HashMap<>() ;

        if(!StringUtils.isBlank(date)) {
            //查询天的详情
            Date current =   DateUtils.stringToDate(DateUtils.dateToString(new Date()) ,"yyyy-MM-dd") ;
            Date  d = DateUtils.stringToDate(date,"yyyy-MM-dd") ;
            if(d.getTime() == current.getTime()){
                String key = agentAccount  + DateUtils.dateToString(current)+"_newToday";
                String json = (String) redisUtil.get(key);

                ClDashBoardDataRes res   =   new Gson().fromJson(json,ClDashBoardDataRes.class) ;

                List<Map<String,Object>>  subList = res.getTeamReportHistoryType() ;

                for (Map maps  : subList) {
                    String gameType =   (String)maps.get("gameType");
                    if(gameType.equals("1") ||  gameType.equals("22")) {
                        gameType = "1" ;
                    }

                    UserGameSummerResponse userGameSummerResponse = map2.get(gameType) ;

                    if(userGameSummerResponse  == null) {
                        userGameSummerResponse = new UserGameSummerResponse()  ;
                        userGameSummerResponse.setGgrSum(new BigDecimal(0));
                        userGameSummerResponse.setTurnoverSum(new BigDecimal(0));
                        userGameSummerResponse.setOutcomeSum(new BigDecimal(0));
                        userGameSummerResponse.setGameType(gameType);
                    }

                    userGameSummerResponse.setOutcomeSum(userGameSummerResponse.getOutcomeSum().add(new BigDecimal(maps.get("winorloss").toString())));
                    userGameSummerResponse.setGgrSum(userGameSummerResponse.getGgrSum().add(new BigDecimal(maps.get("ggr").toString())));
                    userGameSummerResponse.setTurnoverSum(userGameSummerResponse.getTurnoverSum().add(new BigDecimal(maps.get("turnover").toString())));
                    map2.put(gameType,userGameSummerResponse) ;

                }

                Set<String> keys =    map2.keySet();

                for (String  k : keys) {
                    list.add(map2.get(k)) ;
                }




            }else if(d.getTime() < current.getTime()) {
                Map<String, String> parame = new HashMap<>() ;
                parame.put("login_name_date", agentAccount   +  date +"%");
                List<TeamReportHistoryType> teamReportHistoryTypes =    teamReportHistoryTypeMapper.listParame(parame)  ;

                for(TeamReportHistoryType teamReportHistoryType : teamReportHistoryTypes){
                    UserGameSummerResponse  gameSummerResponse    = new UserGameSummerResponse();
                    gameSummerResponse.setOutcomeSum((teamReportHistoryType.getWinorloss()));
                    gameSummerResponse.setGgrSum((teamReportHistoryType.getGgr()));
                    gameSummerResponse.setTurnoverSum((teamReportHistoryType.getTurnover()));
                    gameSummerResponse.setGameType((teamReportHistoryType.getGameType()));
                    list.add(gameSummerResponse) ;
                }

            }


        }else {
            String month1  =  DateUtils.dateToString(new Date(),"yyyy-MM") ;
            if(month1.equals(month)) {
                //当月
                Map<String, String> parame = new HashMap<>() ;
                parame.put("login_name_date", agentAccount   +  month +"-%");
                List<TeamReportHistoryType> teamReportHistoryTypes =    teamReportHistoryTypeMapper.listParame(parame)  ;
                Date current =   DateUtils.stringToDate(DateUtils.dateToString(new Date()) ,"yyyy-MM-dd") ;

                String key = agentAccount  + DateUtils.dateToString(current)+"_newToday";
                String json = (String) redisUtil.get(key);

                ClDashBoardDataRes res   =   new Gson().fromJson(json,ClDashBoardDataRes.class) ;

                List<Map<String,Object>>  subList = res.getTeamReportHistoryType() ;

                for (Map maps  : subList) {
                    String gameType =   (String)maps.get("gameType");
                    if(gameType.equals("1") ||  gameType.equals("22")) {
                        gameType = "1" ;
                    }

                    UserGameSummerResponse userGameSummerResponse = map2.get(gameType) ;

                    if(userGameSummerResponse  == null) {
                        userGameSummerResponse = new UserGameSummerResponse()  ;
                        userGameSummerResponse.setGgrSum(new BigDecimal(0));
                        userGameSummerResponse.setTurnoverSum(new BigDecimal(0));
                        userGameSummerResponse.setOutcomeSum(new BigDecimal(0));
                        userGameSummerResponse.setGameType(gameType);
                    }

                    userGameSummerResponse.setOutcomeSum(userGameSummerResponse.getOutcomeSum().add(new BigDecimal(maps.get("winorloss").toString())));
                    userGameSummerResponse.setGgrSum(userGameSummerResponse.getGgrSum().add(new BigDecimal(maps.get("ggr").toString())));
                    userGameSummerResponse.setTurnoverSum(userGameSummerResponse.getTurnoverSum().add(new BigDecimal(maps.get("turnover").toString())));
                    map2.put(gameType,userGameSummerResponse) ;

                }

                for(TeamReportHistoryType teamReportHistoryType : teamReportHistoryTypes){
                    String type  =  teamReportHistoryType.getGameType()  +""  ;
                    if(type.equals("1") ||  type.equals("22")) {
                        type = "1" ;
                    }
                    UserGameSummerResponse userGameSummerResponse = map2.get(type) ;

                    if(userGameSummerResponse  == null) {
                        userGameSummerResponse = new UserGameSummerResponse()  ;
                        userGameSummerResponse.setGgrSum(new BigDecimal(0));
                        userGameSummerResponse.setTurnoverSum(new BigDecimal(0));
                        userGameSummerResponse.setOutcomeSum(new BigDecimal(0));
                        userGameSummerResponse.setGameType(type);
                    }

                    userGameSummerResponse.setOutcomeSum(userGameSummerResponse.getOutcomeSum().add((teamReportHistoryType.getWinorloss())));
                    userGameSummerResponse.setGgrSum(userGameSummerResponse.getGgrSum().add((teamReportHistoryType.getGgr())));
                    userGameSummerResponse.setTurnoverSum(userGameSummerResponse.getTurnoverSum().add((teamReportHistoryType.getTurnover())));
                    map2.put(type,userGameSummerResponse) ;
                }

                Set<String> keys =    map2.keySet();

                for (String  k : keys) {
                    list.add(map2.get(k)) ;
                }

            }else{
                Map<String, String> parame = new HashMap<>() ;
                parame.put("login_name_date", agentAccount   +  month );
                List<TeamReportHistoryType> teamReportHistoryTypes =    teamReportHistoryTypeMapper.listParame2(parame)  ;

                for(TeamReportHistoryType teamReportHistoryType : teamReportHistoryTypes){
                    String type  =  teamReportHistoryType.getGameType()  +""  ;
                    if(type.equals("1") ||  type.equals("22")) {
                        type = "1" ;
                    }
                    UserGameSummerResponse userGameSummerResponse = map2.get(type) ;

                    if(userGameSummerResponse  == null) {
                        userGameSummerResponse = new UserGameSummerResponse()  ;
                        userGameSummerResponse.setGgrSum(new BigDecimal(0));
                        userGameSummerResponse.setTurnoverSum(new BigDecimal(0));
                        userGameSummerResponse.setOutcomeSum(new BigDecimal(0));
                        userGameSummerResponse.setGameType(type);
                    }

                    userGameSummerResponse.setOutcomeSum(userGameSummerResponse.getOutcomeSum().add((teamReportHistoryType.getWinorloss())));
                    userGameSummerResponse.setGgrSum(userGameSummerResponse.getGgrSum().add((teamReportHistoryType.getGgr())));
                    userGameSummerResponse.setTurnoverSum(userGameSummerResponse.getTurnoverSum().add((teamReportHistoryType.getTurnover())));
                    map2.put(type,userGameSummerResponse) ;
                }

                Set<String> keys =    map2.keySet();

                for (String  k : keys) {
                    list.add(map2.get(k)) ;
                }
            }
        }

        for (UserGameSummerResponse summerResponse : list) {
            summerResponse.setOutcomeSum(getFormat(summerResponse.getOutcomeSum()));
            summerResponse.setTurnoverSum(getFormat(summerResponse.getTurnoverSum()));
            summerResponse.setGgrSum(getFormat(summerResponse.getGgrSum()));

            outcomeSum = outcomeSum.add(summerResponse.getOutcomeSum());
            turnoverSum =  turnoverSum.add(summerResponse.getTurnoverSum()) ;
            ggrSum = ggrSum.add(summerResponse.getGgrSum())  ;
            summerResponse.setGameType(gameTypes.get(summerResponse.getGameType()));
        }
        reportByGameResponse.setUserGameSummerResponses(list);
        reportByGameResponse.setOutcomeSum(getFormat(outcomeSum));
        reportByGameResponse.setTurnoverSum(getFormat(turnoverSum));
        reportByGameResponse.setGgrSum(getFormat(ggrSum));

        return  reportByGameResponse ;
    }

    private TeamReportByGameResponse getGameReportData3(TeamReportByGameRequest req) {

        List<UserGameSummerResponse> data = new ArrayList<>();

        TeamReportByGameResponse reportByGameResponse = new TeamReportByGameResponse();


        BigDecimal ggrSum = new BigDecimal(0);
        BigDecimal turnoverSum = new BigDecimal(0);
        BigDecimal outcomeSum = new BigDecimal(0);

        String  agentAccount   =  req.getAgentAccount() ;

        String  date  = req.getDate() ;

        String  month  = req.getMonth() ;

        String time = "" ;

        Date current  =  DateUtils.stringToDate(DateUtils.dateToString(Calendar.getInstance().getTime()));


        if(!StringUtils.isBlank(date)) {
            return  getDayReport(current,date,agentAccount) ;

        }else {

            String curr =    DateUtils.dateToString(new Date(),"yyyy-MM");
            Map<String,String> parame = new HashMap<>() ;
            parame.put("login_name_date", agentAccount   +  month +"-%");

            List<TeamReportHistoryType>  teamReportHistoryTypes =  teamReportHistoryTypeMapper.listParame(parame) ;
            Map<String , TeamReportHistoryType> map2 = new HashMap<>() ;

            for(TeamReportHistoryType historyType : teamReportHistoryTypes) {

                map2.put(gameTypes.get(historyType.getGameType()),historyType) ;
            }



            if(curr.equals(month)) {
                //加上今天的
                TeamReportByGameResponse  temp  =  getDayReport(current,DateUtils.dateToString(new Date()),agentAccount) ;

                List<UserGameSummerResponse>  list  = temp.getUserGameSummerResponses() ;

                log.info("list 今天的数据 ----,={}",new Gson().toJson(list) );

                for (UserGameSummerResponse userGameSummerResponse:list) {
                    TeamReportHistoryType t  =  map2.get(userGameSummerResponse.getGameType()) ;
                    if(t == null) {
                        t  = new TeamReportHistoryType();
                    }
                    t.setTurnover(userGameSummerResponse.getTurnoverSum().add((t.getTurnover())));
                    t.setGgr(userGameSummerResponse.getGgrSum().add((t.getGgr())));
                    t.setWinorloss(userGameSummerResponse.getOutcomeSum().add((t.getWinorloss())));
                    map2.put(userGameSummerResponse.getGameType(),t) ;

                }

            }

            Set<String> keys =     map2.keySet();
            List<TeamReportHistoryType> list33  = new ArrayList<>()  ;
            for(String key:keys) {
                list33.add(map2.get(key)) ;
            }

            for (TeamReportHistoryType userFinanceOrderTreed :list33) {
                UserGameSummerResponse  gameSummerResponse    = new UserGameSummerResponse();
                gameSummerResponse.setOutcomeSum((userFinanceOrderTreed.getWinorloss()));
                gameSummerResponse.setGgrSum((userFinanceOrderTreed.getGgr()));
                gameSummerResponse.setTurnoverSum((userFinanceOrderTreed.getTurnover()));
                gameSummerResponse.setGameType((userFinanceOrderTreed.getGameType()));
                data.add(gameSummerResponse) ;
                ggrSum =  ggrSum.add(gameSummerResponse.getGgrSum());
                turnoverSum =  turnoverSum.add(gameSummerResponse.getTurnoverSum());
                outcomeSum =  outcomeSum.add(gameSummerResponse.getOutcomeSum());
            }


            reportByGameResponse.setUserGameSummerResponses(data);
            reportByGameResponse.setGgrSum(ggrSum);
            reportByGameResponse.setTurnoverSum(turnoverSum);
            reportByGameResponse.setOutcomeSum(outcomeSum);



        }




        return reportByGameResponse;
    }



    public  TeamReportByGameResponse getDayReport(Date current,String date,String agentAccount){
        TeamReportByGameResponse reportByGameResponse = new TeamReportByGameResponse();
        List<UserGameSummerResponse> data = new ArrayList<>();

        BigDecimal ggrSum = new BigDecimal(0);
        BigDecimal turnoverSum = new BigDecimal(0);
        BigDecimal outcomeSum = new BigDecimal(0);
        //按天
        if (current.getTime() ==   DateUtils.stringToDate(date).getTime()) {
            String  key  =   agentAccount  +  "_detail" +  date   ;
            String json =    (String)redisUtil.get(key)  ;

            if (StringUtils.isBlank(json)) {
                List<TUserFinanceOrderTreed> list =  getReport(date,agentAccount);

                for (TUserFinanceOrderTreed userFinanceOrderTreed :list) {
                    UserGameSummerResponse  gameSummerResponse    = new UserGameSummerResponse();
                    gameSummerResponse.setOutcomeSum(userFinanceOrderTreed.getOutcomeAmount());
                    gameSummerResponse.setGgrSum(userFinanceOrderTreed.getGgrAmount());
                    gameSummerResponse.setTurnoverSum(userFinanceOrderTreed.getTurnoverAmount());
                    gameSummerResponse.setGameType(gameTypes.get(userFinanceOrderTreed.getGameType()));
                    data.add(gameSummerResponse) ;
                    ggrSum =  ggrSum.add(userFinanceOrderTreed.getGgrAmount());
                    turnoverSum =  turnoverSum.add(userFinanceOrderTreed.getTurnoverAmount());
                    outcomeSum =  outcomeSum.add(userFinanceOrderTreed.getOutcomeAmount());
                }

                reportByGameResponse.setOutcomeSum(outcomeSum);
                reportByGameResponse.setTurnoverSum(turnoverSum);
                reportByGameResponse.setGgrSum(ggrSum);
                log.info("-------JSON={}",new Gson().toJson(data));
                reportByGameResponse.setUserGameSummerResponses(data);
                redisUtil.set(key,new Gson().toJson(reportByGameResponse));
                redisUtil.set(key+"_time",  new Date().getTime());
            }else {
                Long _time  =  (Long) redisUtil.get(key+"_time");
                Long time2 = new Date().getTime()   -  Long.valueOf(_time)  ;
                reportByGameResponse  = new Gson().fromJson(json,TeamReportByGameResponse.class) ;

                if(time2 >90000){  //15分钟解析
                    new Thread(()-> {
                        List<TUserFinanceOrderTreed> list =  getReport(date,agentAccount);
                        List<UserGameSummerResponse> data2  = new ArrayList<>() ;
                        BigDecimal  ggrSum2 = BigDecimal.ZERO ;
                        BigDecimal  outcomeSum2 = BigDecimal.ZERO ;
                        BigDecimal  turnoverSum2 = BigDecimal.ZERO ;
                        TeamReportByGameResponse reportByGameResponse2 = new TeamReportByGameResponse();
                        for (TUserFinanceOrderTreed userFinanceOrderTreed :list) {
                            UserGameSummerResponse  gameSummerResponse    = new UserGameSummerResponse();
                            gameSummerResponse.setOutcomeSum(userFinanceOrderTreed.getOutcomeAmount());
                            gameSummerResponse.setGgrSum(userFinanceOrderTreed.getGgrAmount());
                            gameSummerResponse.setTurnoverSum(userFinanceOrderTreed.getTurnoverAmount());
                            gameSummerResponse.setGameType(gameTypes.get(userFinanceOrderTreed.getGameType()));
                            data2.add(gameSummerResponse) ;
                            ggrSum2 =  ggrSum2.add(userFinanceOrderTreed.getGgrAmount());
                            turnoverSum2 =  turnoverSum2.add(userFinanceOrderTreed.getTurnoverAmount());
                            outcomeSum2 =  outcomeSum2.add(userFinanceOrderTreed.getOutcomeAmount());
                        }

                        reportByGameResponse2.setOutcomeSum(outcomeSum2);
                        reportByGameResponse2.setTurnoverSum(turnoverSum2);
                        reportByGameResponse2.setGgrSum(ggrSum2);
                        log.info("-------JSON={}",new Gson().toJson(data2));
                        reportByGameResponse2.setUserGameSummerResponses(data2);
                        redisUtil.set(key,new Gson().toJson(reportByGameResponse2));
                        redisUtil.set(key+"_time",  new Date().getTime());
                    }).start();

                }

            }

        }else {
            Map<String,String> parame = new HashMap<>() ;
            parame.put("login_name_date", agentAccount   +  date);

            List<TeamReportHistoryType>  teamReportHistoryTypes =  teamReportHistoryTypeMapper.listParame(parame) ;

            List<UserGameSummerResponse> data2  = new ArrayList<>() ;
            BigDecimal  ggrSum2 = BigDecimal.ZERO ;
            BigDecimal  outcomeSum2 = BigDecimal.ZERO ;
            BigDecimal  turnoverSum2 = BigDecimal.ZERO ;
            TeamReportByGameResponse reportByGameResponse2 = new TeamReportByGameResponse();
            for (TeamReportHistoryType userFinanceOrderTreed :teamReportHistoryTypes) {
                UserGameSummerResponse  gameSummerResponse    = new UserGameSummerResponse();
                gameSummerResponse.setOutcomeSum((userFinanceOrderTreed.getWinorloss()));
                gameSummerResponse.setGgrSum((userFinanceOrderTreed.getGgr()));
                gameSummerResponse.setTurnoverSum((userFinanceOrderTreed.getTurnover()));
                gameSummerResponse.setGameType(gameTypes.get(userFinanceOrderTreed.getGameType()));
                data2.add(gameSummerResponse) ;
                ggrSum2 =  ggrSum2.add(gameSummerResponse.getGgrSum());
                turnoverSum2 =  turnoverSum2.add(gameSummerResponse.getTurnoverSum());
                outcomeSum2 =  outcomeSum2.add(gameSummerResponse.getOutcomeSum());
            }

            reportByGameResponse2.setOutcomeSum(outcomeSum2);
            reportByGameResponse2.setTurnoverSum(turnoverSum2);
            reportByGameResponse2.setGgrSum(ggrSum2);
            log.info("-------JSON={}",new Gson().toJson(data2));
            reportByGameResponse2.setUserGameSummerResponses(data2);

            reportByGameResponse  = reportByGameResponse2 ;

        }

        return reportByGameResponse;
    }


    public  List<TUserFinanceOrderTreed> getReport(String day,String loginName) {
        DashBoardUserTreeQueryReq entity = new DashBoardUserTreeQueryReq();
        entity.setParent(loginName);
        Result<List<TCustomerLayer>> layers = userFeignService.selectUserTreeByParentNTime(entity);
        Map<String, Object> parame = new HashMap<>();
        List<TUserFinanceOrderTreed> data = new ArrayList<>();

        if(layers.getData().size() >  0 ) {
            parame.put("date",day) ;
            List<String> payers = layers.getData().stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList());
            List<List<String>> splitLists = splitArrayList(payers, splitRow);

            log.info("----切割数据  开始={}"  ,   splitLists.size() );
            Map<String, TUserFinanceOrderTreed> maps = new HashMap<>();

            for (List<String> sublist : splitLists) {

                parame.put("loginName", sublist);


                List<TUserFinanceOrderTreed> list = tDailyOrderMapper.findListByGameType(parame);
//

                log.info("数据集为---" +  new Gson().toJson(list));
                for (TUserFinanceOrderTreed tUserFinanceOrderTreed : list
                ) {

                    String key = loginName + tUserFinanceOrderTreed.getGameType() + "__"+ day;
                    TUserFinanceOrderTreed init = maps.get(key);
                    log.info("initinitinit={} ,,,,value={}" ,key, init);

                    if (init == null) {
                        init = new TUserFinanceOrderTreed();
                        init.setOutcomeAmount(new BigDecimal(0));
                        init.setGgrAmount(new BigDecimal(0));
                        init.setTurnoverAmount(new BigDecimal(0));
                    }
                    init.setOutcomeAmount(init.getOutcomeAmount().add(tUserFinanceOrderTreed.getOutcomeAmount()));
                    init.setGgrAmount(init.getGgrAmount().add(tUserFinanceOrderTreed.getGgrAmount()));
                    init.setTurnoverAmount(init.getTurnoverAmount().add(tUserFinanceOrderTreed.getTurnoverAmount()));
                    init.setLoginName(tUserFinanceOrderTreed.getLoginName());
                    init.setGameType(tUserFinanceOrderTreed.getGameType());
                    maps.put(key, init);


                }
            }

            Set<String> sets   =  maps.keySet();

            log.info("mapsmaps:{}" ,maps);

            List<TUserFinanceOrderTreed> resultDataAll   =  new ArrayList<>() ;


            for (String s : sets) {

                resultDataAll.add(maps.get(s)) ;

            }

            TUserFinanceOrderTreed result = null;
            List<TUserFinanceOrderTreed> resultData = new ArrayList<>();
            for (TUserFinanceOrderTreed tUserFinanceOrderTreed : resultDataAll) {
                if (tUserFinanceOrderTreed.getGameType().equals("1") || tUserFinanceOrderTreed.getGameType().equals("22")) {
                    if (result == null) {
                        result = tUserFinanceOrderTreed;
                        resultData.add(0, result);

                    } else {
                        result = resultData.get(0);
                        result.setGgrAmount(tUserFinanceOrderTreed.getGgrAmount().add(result.getGgrAmount()));
                        result.setTurnoverAmount(tUserFinanceOrderTreed.getTurnoverAmount().add(result.getTurnoverAmount()));

                        result.setOutcomeAmount(tUserFinanceOrderTreed.getOutcomeAmount().add(result.getOutcomeAmount()));
//                    resultData.add(result) ;
                        resultData.set(0, result);
                    }
                } else {
                    resultData.add(tUserFinanceOrderTreed);

                }


            }

            log.info("resultDataresultDataresultData={}" ,resultData.size());

            data  =  resultData ;




        }



        return  data;
    }

    @Override
    public List<TUserFinanceOrderTreed> getReport(Date min, Date max, String loginName) {

        DashBoardUserTreeQueryReq entity = new DashBoardUserTreeQueryReq();
        entity.setParent(loginName);
        Result<List<TCustomerLayer>> layers = userFeignService.selectUserTreeByParentNTime(entity);
        Map<String, Object> parame = new HashMap<>();
        List<TUserFinanceOrderTreed> data = new ArrayList<>();

        if(layers.getData().size() >  0 ) {

            parame.put("min",DateUtils.dateToString(min)) ;
            parame.put("max",DateUtils.dateToString(max)) ;

            List<String> payers = layers.getData().stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList());
            List<List<String>> splitLists = splitArrayList(payers, splitRow);

            log.info("----切割数据  开始={}"  ,   splitLists.size() );
            Map<String, TUserFinanceOrderTreed> maps = new HashMap<>();

            for (List<String> sublist : splitLists) {

                parame.put("loginName", sublist);


                List<TUserFinanceOrderTreed> list = tDailyOrderMapper.findListByGameType(parame);
//

                log.info("数据集为---" +  new Gson().toJson(list));
                for (TUserFinanceOrderTreed tUserFinanceOrderTreed : list
                ) {

                    String key = loginName + tUserFinanceOrderTreed.getGameType() + "__"+ DateUtils.dateToString(min ,"yyyy-MM");
                    TUserFinanceOrderTreed init = maps.get(key);
                    log.info("initinitinit={} ,,,,value={}" ,key, init);

                    if (init == null) {
                        init = new TUserFinanceOrderTreed();
                        init.setOutcomeAmount(new BigDecimal(0));
                        init.setGgrAmount(new BigDecimal(0));
                        init.setTurnoverAmount(new BigDecimal(0));
                    }
                    init.setOutcomeAmount(init.getOutcomeAmount().add(tUserFinanceOrderTreed.getOutcomeAmount()));
                    init.setGgrAmount(init.getGgrAmount().add(tUserFinanceOrderTreed.getGgrAmount()));
                    init.setTurnoverAmount(init.getTurnoverAmount().add(tUserFinanceOrderTreed.getTurnoverAmount()));
                    init.setLoginName(tUserFinanceOrderTreed.getLoginName());
                    init.setGameType(tUserFinanceOrderTreed.getGameType());
                    maps.put(key, init);


                }
            }

            Set<String> sets   =  maps.keySet();

            log.info("mapsmaps:{}" ,maps);

            List<TUserFinanceOrderTreed> resultDataAll   =  new ArrayList<>() ;


            for (String s : sets) {

                resultDataAll.add(maps.get(s)) ;

            }

            TUserFinanceOrderTreed result = null;
            List<TUserFinanceOrderTreed> resultData = new ArrayList<>();
            for (TUserFinanceOrderTreed tUserFinanceOrderTreed : resultDataAll) {
                if (tUserFinanceOrderTreed.getGameType().equals("1") || tUserFinanceOrderTreed.getGameType().equals("22")) {
                    if (result == null) {
                        result = tUserFinanceOrderTreed;
                        resultData.add(0, result);

                    } else {
                        result = resultData.get(0);
                        result.setGgrAmount(tUserFinanceOrderTreed.getGgrAmount().add(result.getGgrAmount()));
                        result.setTurnoverAmount(tUserFinanceOrderTreed.getTurnoverAmount().add(result.getTurnoverAmount()));

                        result.setOutcomeAmount(tUserFinanceOrderTreed.getOutcomeAmount().add(result.getOutcomeAmount()));
//                    resultData.add(result) ;
                        resultData.set(0, result);
                    }
                } else {
                    resultData.add(tUserFinanceOrderTreed);

                }


            }

            log.info("resultDataresultDataresultData={}" ,resultData.size());

            data  =  resultData ;




        }



        return  data;

    }
        //弃用

//    @Override
//    public List<ClDashBoardDataRes> getAllData(Map<String, Object> p) {
//        List<ClDashBoardDataRes>  returnData = new ArrayList<>() ;
//        ClDashBoardDataRes  data=     new ClDashBoardDataRes();
//
//        DashBoardUserTreeQueryReq entity = new DashBoardUserTreeQueryReq();
//        entity.setParent(p.get("loginName").toString());
//        Result<List<TCustomerLayer>> layers =  new Result<>();
//        try{
//            List<TCustomerLayer>  list = userMapper.selectUserTreeByParentNTime(entity.getParent(),null,null) ;
//            layers.setData(list);
//        }catch (Exception e) {
//
//        }
//
//        Map<String,ClDashBoardDataRes >  result= new HashMap<>() ;
//
//        if(layers.getData() != null   && layers.getData().size() >   0 ) {
//            List<String> payers = layers.getData().stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList());
//
//            List<List<String>> splitLists = splitArrayList(payers, splitRow);
//
//            for (List<String> sublist : splitLists) {
//                p.put("loginName", sublist);
//
//                List<ClDashBoardDataRes>   subData =     new ArrayList<>() ;
//            //<!-- winOrLoss 提现   ,amount 充值 , turnover 首充人数, ggr 首充 金额 -->
//
//
//                 List<ClDashBoardDataRes>  ctList  =    tDailyOrderMapper.getNewAllDataNew(p) ;    //winOrLoss  = sum(withdrawal_amount) , amount = SUM(deposit_amount)
//
//                    if(ctList    != null   &&  ctList.size() > 0  )  {
//                        ClDashBoardDataRes    ct =   ctList.get(0)  ;
//
//                         //9999  是充值  9998  提现
//                        BigDecimal winOrLoss      =  ct.getWinOrLoss() ;   //withdrawal_amount 提现
//                        BigDecimal amount      =  ct.getAmount() ;   //deposit_amount 充值
//
//                        if (winOrLoss != null) {
//                            ClDashBoardDataRes tixianObj  =     new ClDashBoardDataRes() ;
//                            tixianObj.setGameType(9998);
//                            tixianObj.setAmount(winOrLoss);
////                            congzhi.setGgr(ct.getGgr());
//                            tixianObj.setLoginName(ct.getLoginName());
//                            tixianObj.setAgentDate(ct.getAgentDate());
//                            subData.add(tixianObj)  ;
//
//                        }
//
//
//                        if (amount != null) {
//                            ClDashBoardDataRes congzhi  =     new ClDashBoardDataRes() ;
//                            congzhi.setGameType(9999);
//                            congzhi.setAmount(amount);
////                            congzhi.setGgr(ct.getGgr());
//                            congzhi.setLoginName(ct.getLoginName());
//                            congzhi.setAgentDate(ct.getAgentDate());
//                            subData.add(congzhi)  ;
//
//                        }
//
//
//                    }
//
//                List<ClDashBoardDataRes>   subData2 =    tDailyOrderMapper.getNewAllDataGameType(p) ;  //读取分类数据
//
//                if (subData2 ==null  ) {
//                    subData2  =new ArrayList<>() ;
//                }
//
//
//                subData.addAll(subData2);
//
//                log.info("getNewAllData={},参数未={}",new Gson().toJson(subData),p);
//
//                if (subData!= null  &&  subData.size() >  0 ) {
//
//                    for (ClDashBoardDataRes sub:subData) {
//                        ClDashBoardDataRes temp =  result.get(sub.getGameType()+"")  ;
//                        if( temp==  null)  {
//                            temp   = new ClDashBoardDataRes();
//                        }
//                        temp.setGgr(temp.getGgr().add(sub.getGgr()));
//                        temp.setTurnover(temp.getTurnover().add(sub.getTurnover()));
//                        temp.setWinOrLoss(temp.getWinOrLoss().add(sub.getWinOrLoss()));
//                        temp.setAmount(temp.getAmount().add(sub.getAmount()));
//                        temp.setGameType(sub.getGameType());
//
//                        result.put(sub.getGameType()+"",temp);
//                    }
//                }
//
//            }
//
//            log.info("结果集为:={}" ,new Gson().toJson(result));
//
//
//            // DEPOSIT("Deposit","存款",99999),
//            //    WITHDRAW("Withdraw","取款",99998),
//            Set<String> keys =   result.keySet();
//            for (String k : keys) {
//
//                ClDashBoardDataRes  temp =    result.get(k) ;
//                returnData.add(temp) ;
//
//
//            }
//
//        }else {
//
//        }
//
//
//        return returnData;
//    }

    public List<ClDashBoardDataRes> getNewAllData(Map<String, Object> p) {
        List<ClDashBoardDataRes>  returnData = new ArrayList<>() ;
        ClDashBoardDataRes  data=     new ClDashBoardDataRes();

        DashBoardUserTreeQueryReq entity = new DashBoardUserTreeQueryReq();
        entity.setParent(p.get("loginName").toString());
        Result<List<TCustomerLayer>> layers =  new Result<>();
        try{
            List<TCustomerLayer>  list = userMapper.selectUserTreeByParentNTime(entity.getParent(),null,null) ;
            layers.setData(list);
        }catch (Exception e) {

        }

        Map<String,ClDashBoardDataRes >  result= new HashMap<>() ;

        if(layers.getData() != null   && layers.getData().size() >   0 ) {
            List<String> payers = layers.getData().stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList());

            List<List<String>> splitLists = splitArrayList(payers, splitRow);

            for (List<String> sublist : splitLists) {
                p.put("loginName", sublist);

                List<ClDashBoardDataRes>   subData =     new ArrayList<>() ;


                List<ClDashBoardDataRes>  listData   =    tDailyOrderMapper.getNewAllDataNew(p) ;   //获取总的 游戏数据 +  充值 提现

                List<ClDashBoardDataRes>   gameTypeList  =    tDailyOrderMapper.getNewAllDataGameType(p) ;  //读取分类数据

                subData.addAll(listData);

                subData.addAll(gameTypeList);

                log.info("getNewAllData={}",new Gson().toJson(subData));

                if (subData!= null  &&  subData.size() >  0 ) {

                    for (ClDashBoardDataRes sub:subData) {
                        ClDashBoardDataRes temp =  result.get(sub.getGameType()+"")  ;
                        if( temp==  null)  {
                            temp   = new ClDashBoardDataRes();
                        }
                        temp.setGgr(temp.getGgr().add(sub.getGgr()));
                        temp.setTurnover(temp.getTurnover().add(sub.getTurnover()));
                        temp.setWinOrLoss(temp.getWinOrLoss().add(sub.getWinOrLoss()));
                        temp.setAmount(temp.getAmount().add(sub.getAmount()));

                        temp.setGameType(sub.getGameType());
                        temp.setFirstDeposit(temp.getFirstDeposit() + sub.getFirstDeposit()  ); //首充人数
                        temp.setFirstDepositAmount(temp.getFirstDepositAmount().add(sub.getFirstDepositAmount()));//首充金额
                        temp.setWithdrawalAmount(temp.getWithdrawalAmount().add(sub.getWithdrawalAmount())); // 提现金额
                        temp.setDepositAmount(temp.getDepositAmount().add(sub.getDepositAmount()));//充值金额

                        result.put(sub.getGameType()+"",temp);
                    }
                }

            }

            log.info("结果集为:={}" ,new Gson().toJson(result));


            // DEPOSIT("Deposit","存款",99999),
            //    WITHDRAW("Withdraw","取款",99998),
            Set<String> keys =   result.keySet();
            for (String k : keys) {

                ClDashBoardDataRes  temp =    result.get(k) ;
                returnData.add(temp) ;


            }

        }else {

        }


        return returnData;
    }

    /**
     *
     * {
     *     "chosenPeriod": "current",
     *     "chosenType": "Month"
     * }
     *
     * @param req
     * @return
     */
    @Override
    public CommissionRecordDashBoardResponse  getDashboardTeamSummary(TeamReportRequest req) {


        Map<String,Date>  value =   getRange( req.getChosenPeriod(),req.getChosenType()) ;

        //

        Date min =  value.get("min");
        Date max =  value.get("max");



        /**
         * 查询注册人数
         */
        Result<Long> registerUserResult = userFeignService.selectUserTreeByParentNTimeCount(new DashBoardUserTreeQueryReq(req.getLoginName(),DateUtils.dateToString(min,"yyyy-MM-dd HH:mm:ss"),DateUtils.dateToString(max,"yyyy-MM-dd HH:mm:ss")));

        log.info("registerUserResult  ----={}",registerUserResult);




        CommissionRecordDashBoardResponse dashBoardResponse =getBetPlayers(req.getLoginName() ,min,max) ;


        dashBoardResponse.setRegistrationNumber(registerUserResult.getData());


        Map<String, String> parame1 =  new HashMap<String,String>();


        String loginName  = req.getLoginName();
        String isSave  = "-1" ;
        String startDate  =  DateUtils.dateToString(min) ;
        String endDate  =  DateUtils.dateToString(max) ;


        Object v  =   redisUtil.get(loginName + startDate + endDate) ;

        Object v1  =   redisUtil.get(loginName + startDate + endDate  +   "_lost") ;

        log.info("获取的key={}",loginName+startDate+endDate);
        if(v!= null   && !StringUtils.isBlank(v.toString()) ) {
            dashBoardResponse.setCommissionAmount( new BigDecimal(v.toString()));

            if(v1 ==null  ||  StringUtils.isBlank(v1.toString())){
                new Thread(() -> {
                    parame1.put("loginName",  loginName) ;
                    parame1.put("isSave",  isSave) ;
                    parame1.put("startDate",  startDate) ;
                    parame1.put("endDate",  endDate) ;
                    commissionApiGateClient.commissionGen(parame1) ;

                }).start();  //去更新
            }
        }else {
            dashBoardResponse.setCommissionAmount( BigDecimal.ZERO);


            new Thread(() -> {
                parame1.put("loginName",  loginName) ;
                parame1.put("isSave",  isSave) ;
                parame1.put("startDate",  startDate) ;
                parame1.put("endDate",  endDate) ;
                commissionApiGateClient.commissionGen(parame1) ;

            }).start();  //去更新

        }






        return dashBoardResponse;
    }
        @Autowired
        private CommissionApiGateClient commissionApiGateClient;

    private List<String> getRowKey(String loginName, Date min, Date max) {
        List<String>  keys  =new ArrayList<>();

        Calendar calendar =  Calendar.getInstance();
        calendar.setTime(min);
//        calendar.add(Calendar.DAY_OF_MONTH,-1);



        max = DateUtils.stringToDate(DateUtils.dateToString(max));
        min = DateUtils.stringToDate(DateUtils.dateToString(min));

        while (min.getTime() <= max.getTime()) {


            if(!DateUtils.dateToString(new Date()).equals(DateUtils.dateToString(min))) {
                keys.add(loginName + DateUtils.dateToString(min));
            }
            calendar.add(Calendar.DAY_OF_MONTH,1);

            System.out.println(keys);

            min   =   calendar.getTime()  ;
        }

        return  keys ;
    }

    /**
     * 获取投注人数
     * @param loginName
     * @param min
     * @param max
     * @return
     */
    private CommissionRecordDashBoardResponse getBetPlayers(String loginName, Date min, Date max) {

        CommissionRecordDashBoardResponse  players =    getDataPlayers(loginName, DateUtils.dateToString(min), DateUtils.dateToString(max));


        return  players;


    }

    private CommissionRecordDashBoardResponse getDataPlayers(String loginName, String minString, String maxString) {
        Long  players =  0L  ;
        //获取我的子代理
        List<TAgentCustomers> agents = new ArrayList<>();

        CommissionRecordDashBoardResponse response2 = new CommissionRecordDashBoardResponse();

        TeamReportRequest reportRequest  =new TeamReportRequest();
        reportRequest.setLoginName(loginName);
        agents = getAllAgent(reportRequest);//先查询所有代理

        if(agents!= null &&   agents.size() >  0) {

            List<String> dailis = agents.stream().map(TAgentCustomers::getLoginName).collect(Collectors.toList());

            log.info("----查询出的代理22={}", new Gson().toJson(dailis));
            
            //统计投注人数 
            Map<String,Object> parame =  new HashMap<>() ;
            parame.put("min",minString);
            parame.put("max",maxString);
            parame.put("daili",dailis);

            TAgentCustomers  agentCustomers   =  agents.get(0);

            if(agentCustomers.getSiteId() == 1){
                players = userMapper.getPlayCountUserAp(parame);

                response2 =  userMapper.getPlayCountUserApOther(parame);





            }else if(agentCustomers.getSiteId() == 2){
                players = userMapper.getPlayCountUserBp(parame);

                response2 =  userMapper.getPlayCountUserBpOther(parame);


            }else if(agentCustomers.getSiteId() == 3){
                players = userMapper.getPlayCountUserGp(parame);

                response2 =  userMapper.getPlayCountUserGpOther(parame);


            }
        }
            if(response2  == null) {
                response2  = new CommissionRecordDashBoardResponse();
            }

        if(players  == null) {
            players = 0L;
        }
        response2.setBetPlayers(players);
            return  response2;
    }


    public static void main(String[] args) {

        Map<String,Date> team = new TeamReportServiceImpl().getRange("current","Day") ;
        System.out.println(team + ",,,2");


        List<String>   value =  new TeamReportServiceImpl().getRowKey("ss",team.get("min"), team.get("max"));

    System.out.println(value.size() + ",,,");


    }

     public  Map<String ,Date>  getRange(String chosenPeriod ,String  chosenType ){
         Map<String ,Date>   range=  new HashMap<>() ;
            Calendar calendar = Calendar.getInstance() ;

         Date min   =  null ;
         Date max   =  null ;

         if(chosenType.equals("Month")) {
            int pre = 0 ;
              if(chosenPeriod.equals("last")){
                pre = -1 ;
            }else  if(chosenPeriod.equals("last_two")){
                pre = -2 ;
            }
             calendar.add(Calendar.MONTH, pre);
           min =  DateUtils.getFirstDayOfMonth(calendar.getTime());
              max   =  DateUtils.getLastDayOfMonth(calendar.getTime()) ;
             min = DateUtils.stringToDate(DateUtils.dateToString(min) + " 00:00:01", "yyyy-MM-dd HH:mm:ss") ;
             max = DateUtils.stringToDate(DateUtils.dateToString(max) + " 23:59:59", "yyyy-MM-dd HH:mm:ss") ;

         }else if(chosenType.equals("Week")){
             int pre = 0 ;
               if(chosenPeriod.equals("last")){
                 pre = -7 ;
             }else  if(chosenPeriod.equals("last_two")){
                 pre = -14 ;
             }
             calendar.add(Calendar.DAY_OF_MONTH, pre);

             DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
             LocalDate givenDate = LocalDate.parse(DateUtils.dateToString(calendar.getTime()), formatter);

             // 计算给定日期所在周的开始日期（星期一）
             LocalDate startOfWeek = givenDate.with(DayOfWeek.MONDAY);

             // 计算给定日期所在周的结束日期（星期日）
             LocalDate endOfWeek = givenDate.with(DayOfWeek.SUNDAY);

             min = DateUtils.stringToDate(startOfWeek.format(formatter) + " 00:00:01", "yyyy-MM-dd HH:mm:ss") ;
             max   =  DateUtils.stringToDate(endOfWeek.format(formatter) + " 23:59:59", "yyyy-MM-dd HH:mm:ss") ;

         }else if(chosenType.equals("Day")){
             int pre = 0 ;
              if(chosenPeriod.equals("last")){
                 pre = -1 ;
             }else  if(chosenPeriod.equals("last_two")){
                 pre = -2 ;
             }
             calendar.add(Calendar.DAY_OF_MONTH, pre);
             min = DateUtils.stringToDate(DateUtils.dateToString(calendar.getTime()) + " 00:00:01", "yyyy-MM-dd HH:mm:ss") ;
             max   =  DateUtils.stringToDate(DateUtils.dateToString(calendar.getTime()) + " 23:59:59", "yyyy-MM-dd HH:mm:ss") ;

         }

         if(max.getTime() >=  new Date().getTime()) {
             max   =  DateUtils.stringToDate(DateUtils.dateToString( new Date()) + " 23:59:59", "yyyy-MM-dd HH:mm:ss") ;

         }

         range.put("min",min) ;
         range.put("max",max) ;

         log.info("时间区间为  min={},max={}" ,DateUtils.dateToString(min),DateUtils.dateToString(max));

         return  range;
     }

    @Autowired
    private TeamReportHistoryTypeMapper teamReportHistoryTypeMapper ;

    private TeamReportByGameResponse getGameReportData2(TeamReportByGameRequest req) {

        TeamReportByGameResponse reportByGameResponse = new TeamReportByGameResponse();
//
//        //  开始查询本地数据库
//
//        Map<String, String> parame = new HashMap<>();
//        parame.put("agentAccount", req.getAgentAccount());
//
//        if (!StringUtils.isBlank(req.getDate())) {
//
//            parame.put("date", req.getDate());
//
//        } else {
//            parame.put("month", req.getMonth().replaceAll("-", ""));
//
//        }
//        List<UserGameSummerResponse> data = new ArrayList<>();
//
//        BigDecimal ggrSum = new BigDecimal(0);
//        BigDecimal turnoverSum = new BigDecimal(0);
//        BigDecimal outcomeSum = new BigDecimal(0);
//
//
////        List<TUserFinanceOrderTreed> list = tDailyOrderMapper.findListByGameType(parame);
//        TUserFinanceOrderTreed result = null;
//        List<TUserFinanceOrderTreed> resultData = new ArrayList<>();
//        for (TUserFinanceOrderTreed tUserFinanceOrderTreed : list) {
//            if (tUserFinanceOrderTreed.getGameType().equals("1") || tUserFinanceOrderTreed.getGameType().equals("22")) {
//                if (result == null) {
//                    result = tUserFinanceOrderTreed;
//                    resultData.add(0, result);
//
//                } else {
//                    result = resultData.get(0);
//                    result.setGgrAmount(tUserFinanceOrderTreed.getGgrAmount().add(result.getGgrAmount()));
//                    result.setTurnoverAmount(tUserFinanceOrderTreed.getTurnoverAmount().add(result.getTurnoverAmount()));
//
//                    result.setOutcomeAmount(tUserFinanceOrderTreed.getOutcomeAmount().add(result.getOutcomeAmount()));
////                    resultData.add(result) ;
//                    resultData.set(0, result);
//                }
//            } else {
//                resultData.add(tUserFinanceOrderTreed);
//
//            }
//
//
//        }
//
//        for (TUserFinanceOrderTreed tUserFinanceOrderTreed : resultData) {
//
//
//            UserGameSummerResponse gameSummerResponse = new UserGameSummerResponse();
//            gameSummerResponse.setGameType(gameTypes.get(tUserFinanceOrderTreed.getGameType()));
//            gameSummerResponse.setGgrSum(tUserFinanceOrderTreed.getGgrAmount());
//            gameSummerResponse.setTurnoverSum(tUserFinanceOrderTreed.getTurnoverAmount());
//            gameSummerResponse.setOutcomeSum(tUserFinanceOrderTreed.getOutcomeAmount());
//            data.add(gameSummerResponse);
//            ggrSum = ggrSum.add(tUserFinanceOrderTreed.getGgrAmount());
//            turnoverSum = turnoverSum.add(tUserFinanceOrderTreed.getTurnoverAmount());
//            outcomeSum = outcomeSum.add(tUserFinanceOrderTreed.getOutcomeAmount());
//
//        }
//        reportByGameResponse.setUserGameSummerResponses(data);
//
//        reportByGameResponse.setGgrSum(ggrSum.setScale(2, RoundingMode.DOWN));
//        reportByGameResponse.setTurnoverSum(turnoverSum.setScale(2, RoundingMode.DOWN));
//        reportByGameResponse.setOutcomeSum(outcomeSum.setScale(2, RoundingMode.DOWN));

        return reportByGameResponse;

    }

    private TeamReportByGameResponse getGameReportData(TeamReportByGameRequest req) {

        TeamReportByGameResponse reportByGameResponse = new TeamReportByGameResponse();
        reportByGameResponse.setTurnoverSum(BigDecimal.ZERO);
        reportByGameResponse.setGgrSum(BigDecimal.ZERO);
        reportByGameResponse.setOutcomeSum(BigDecimal.ZERO);
        reportByGameResponse.setAgentAccount(req.getAgentAccount());
        reportByGameResponse.setDate(req.getDate());
        reportByGameResponse.setMonth(req.getMonth());

        try {
            // 1.获取当前代理下所有玩家代理
            // AgentListRequest agentListRequest = new AgentListRequest();
            // agentListRequest.setRootParentName(UserContext.getUsername());
            // agentListRequest.setIsQueryTree(true);
            // Result<List<TAgentCustomers>> agentList = agentApiClient.getAgentList(agentListRequest);
            // if (!agentList.isSuccess() || CollectionUtils.isEmpty(agentList.getData())) {
            //     throw new MKTRportException(ResultEnum.AGENT_NOT_EXIST);
            // }
            // List<TAgentCustomers> players = agentList.getData();

            StopWatch stopWatch3 = new StopWatch();
            stopWatch3.start();
            // 获取单个代理下所有玩家(包含可投注的代理)
            Result<List<TCustomerLayer>> result = userFeignService
                    .selectUserTree(
                            req.getAgentAccount(),
                            List.of(CustomerTypeEnum.AGENT.getValue(), CustomerTypeEnum.PLAYER.getValue())
                    );
            stopWatch3.stop();
            // log.info("获取所有玩家耗时:{}秒", stopWatch3.getTime(TimeUnit.SECONDS));
            if (!result.isSuccess()) {
                throw new MKTRportException("Get User Info Error");
            }
            if (CollectionUtils.isEmpty(result.getData())) {
                // 该代理没有下级代理或玩家
                // throw new MKTRportException("This agent has no subordinate agents or players");
                return reportByGameResponse;
            }
            List<String> nameList = result.getData()
                    .stream()
                    .map(TCustomerLayer::getLoginName).collect(Collectors.toList());
            // 2.按代理/玩家查询bi游戏投注数据
            List<UserGameSummerResponse> allData = new ArrayList<>();
            long timeStart = System.currentTimeMillis();
            StopWatch stopWatch4 = new StopWatch();
            stopWatch4.start();

            // 多线程查询 start
            //  log.info("多线程查询 start");
            int threadNum = postThread;
            int splitSize;
            int moreNum = nameList.size() % threadNum;
            if (moreNum == 0) {
                splitSize = nameList.size() / threadNum;
            } else {
                splitSize = nameList.size() / threadNum + moreNum;
            }
            List<List<String>> nameSplitList = ListUtil.split(nameList, splitSize);
            CopyOnWriteArrayList<UserGameSummerResponse> copyList = new CopyOnWriteArrayList<>();
            ExecutorService executorService = ThreadUtil.newExecutor(threadNum);
            CountDownLatch countDownLatch = ThreadUtil.newCountDownLatch(nameSplitList.size());
            for (int i = 0; i < nameSplitList.size(); i++) {
                int finalI = i;
                executorService.submit(() -> {
                    for (String s : nameSplitList.get(finalI)) {
                        Thread.currentThread().setName(s + finalI);
                        List<UserGameSummerResponse> responses = getBiData(req, s);
                        // log.info("多线程查询 线程名->{}, 返回值size->{}, 返回值->{}", Thread.currentThread().getName(), responses.size(), responses);
                        if (null != responses) {
                            copyList.addAll(new CopyOnWriteArrayList<>(responses));
                        }
                    }
                    countDownLatch.countDown();
                    //  log.info("多线程查询 线程名->{} countDownLatch getCount->{}", Thread.currentThread().getName(), countDownLatch.getCount());
                });
            }
            try {
                countDownLatch.await();
                executorService.shutdown();
                // log.info("多线程查询 await after copyList size={}, copyList={}", copyList.size(), copyList);
            } catch (InterruptedException e) {
                if (!executorService.isShutdown()) {
                    executorService.shutdown();
                }
                //  log.error("TeamReportServiceImpl getGameReportData countDownLatch await", e);
            }
            // log.info("多线程查询 end");
            allData = new ArrayList<>(copyList);

//        for (String s : nameList) {
//            List<UserGameSummerResponse> responses = getBiData(req, s);
//            if (null != responses) {
//                allData.addAll(responses);
//            }
//        }
            stopWatch4.stop();
            long timeEnd = System.currentTimeMillis();
//        log.info("bi 按游戏获取玩家投注额完成,循环结束StopWatch，总耗时:{}秒", stopWatch4.getTime(TimeUnit.SECONDS));
//        log.info("bi 按游戏获取玩家投注额完成,循环结束currentTimeMillis，总耗时:{}秒", (timeEnd - timeStart) / 1000);

            // 2.按代理/玩家查询bi游戏投注数据
            // List<UserGameSummerResponse> allData = new ArrayList<>();
            // for (TAgentCustomers player : players) {
            //     List<UserGameSummerResponse> responses = getBiData(req, player.getLoginName());
            //     if(null!=responses&&responses.size()>=0){
            //         allData.addAll(responses);
            //     }
            // }

            //log.info("返回的数据集:{}", new Gson().toJson(allData));

            if (CollectionUtils.isEmpty(allData)) {
                return reportByGameResponse;
            }

            // 3.按游戏类型数据汇总
            // 先将 Sport_22 的 gameType 转换为 Sport 的 gameType
            List<UserGameSummerResponse> transformedData = allData.stream()
                    .peek(data -> {
                        if (GameTypeEnum.Sport_22.getValue().toString().equals(data.getGameType())) {
                            // Convert Sport_22 to Sport
                            data.setGameType(GameTypeEnum.Sport.getValue().toString());
                        }
                    })
                    .collect(Collectors.toList());

            List<UserGameSummerResponse> resultData = new ArrayList<>();
            transformedData.stream().collect(Collectors.groupingBy(UserGameSummerResponse::getGameType))
                    .forEach((gameType, list) -> {
                        UserGameSummerResponse gameTypeSum = new UserGameSummerResponse();
                        gameTypeSum.setLoginName(req.getAgentAccount());
                        String gameTypeStr = GameTypeEnum.getNameByCode(Integer.valueOf(gameType));
                        gameTypeSum.setGameType(gameTypeStr);
                        gameTypeSum.setTurnoverSum(BigDecimal.ZERO);
                        gameTypeSum.setGgrSum(BigDecimal.ZERO);
                        gameTypeSum.setOutcomeSum(BigDecimal.ZERO);
                        for (UserGameSummerResponse userGameSummerResponse : list) {
                            gameTypeSum.setTurnoverSum(addBigDecimal(gameTypeSum.getTurnoverSum(), userGameSummerResponse.getTurnoverSum()));
                            gameTypeSum.setGgrSum(addBigDecimal(gameTypeSum.getGgrSum(), userGameSummerResponse.getGgrSum()));
                            gameTypeSum.setOutcomeSum(addBigDecimal(gameTypeSum.getOutcomeSum(), userGameSummerResponse.getOutcomeSum()));
                        }
                        resultData.add(gameTypeSum);
                    });

            reportByGameResponse.setUserGameSummerResponses(resultData);

            // 4.所有游戏汇总
            for (UserGameSummerResponse gameSummerRespon : resultData) {
                // 数据累计
                reportByGameResponse.setTurnoverSum(addBigDecimal(reportByGameResponse.getTurnoverSum(), gameSummerRespon.getTurnoverSum()));
                reportByGameResponse.setGgrSum(addBigDecimal(reportByGameResponse.getGgrSum(), gameSummerRespon.getGgrSum()));
                reportByGameResponse.setOutcomeSum(addBigDecimal(reportByGameResponse.getOutcomeSum(), gameSummerRespon.getOutcomeSum()));
            }
        } catch (Exception e) {
        }

        log.info("返回的数据集:{}", new Gson().toJson(reportByGameResponse));

        return reportByGameResponse;
    }


    private List<UserGameSummerResponse> getBiData(TeamReportByGameRequest req, String loginName) {
        BiApiTemplate biApiTemplate = new BiApiTemplate(gameDataUrl);
        UserGameSummerRequest userGameSummerRequest = new UserGameSummerRequest();
        userGameSummerRequest.setDate(req.getDate());
        userGameSummerRequest.setMonth(req.getMonth());
        userGameSummerRequest.setName(loginName);
        List<UserGameSummerResponse> gameSummerResponses = biApiTemplate.queryUserGameSummary(userGameSummerRequest);
        return gameSummerResponses;
    }

    /**
     * @param req TeamReportRequest
     */
    @Override
    public List<TeamReportResponse> export(TeamReportRequest req) {
        // 获取导出最大值
        req.setPageSize(10000);
        return this.queryByPageAndCondition(req).getRecords();
    }

    /**
     * @param req TeamReportRequest
     */
    @Override
    public List<TeamReportResponse> exportHistory(TeamReportRequest req) {
        // 获取导出最大值
        req.setPageSize(10000);
        return this.history(req).getRecords();
    }

    /**
     * 查询实时记录
     *
     * @param req req
     * @return 分页记录
     */
    private ReportPageResponse<TeamReportResponse> queryRealTimeRecord(TeamReportRequest req) {

        // 0.初始化返回值
        ReportPageResponse<TeamReportResponse> response = new ReportPageResponse<>();
        response.setTotal(0);
        response.setPages(0);
        response.setSize(req.getPageSize());
        response.setCurrent(req.getPageNum());
        List<TeamReportResponse> records = new ArrayList<>();
        Map<String, BigDecimal> pageSumMap = response.getPageSumMap();
        initMap(pageSumMap);
        Map<String, BigDecimal> searchSumMap = response.getSearchSumMap();
        initMap(searchSumMap);
        String loginName = req.getLoginName();

        // 1.根据loginName查询所有下线代理
        List<TAgentCustomers> allAgent = getAllAgent(req);
        List<TAgentCustomers> agents = allAgent.stream().filter(a -> {
                    // Account 过滤
                    if (StringUtils.isNotEmpty(req.getAgentAccount()) && !a.getLoginName().equals(req.getAgentAccount())) {
                        return false;
                    }
                    if (StringUtils.isNotEmpty(req.getParentAccount()) && !a.getParentName().equals(req.getParentAccount())) {
                        return false;
                    }
                    if (req.getAgentLevel() != null && !Objects.equals(a.getAgentLevel(), req.getAgentLevel())) {
                        return false;
                    }
                    return true;
                }
        ).collect(Collectors.toList());


        // 2.以代理为单位查询数据，再以时间单位(月/日)生成数据
        // 循环
        long timeStart = System.currentTimeMillis();
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        for (TAgentCustomers agent : agents) {
            calculateByAgent(req, records, agent);
        }
        stopWatch.stop();
        long timeEnd = System.currentTimeMillis();
        log.info("bi获取玩家游戏维度汇总请求结束StopWatch,代理数量:{}, 接口总耗时:{}秒", agents.size(), stopWatch.getTime(TimeUnit.SECONDS));
        log.info("bi获取玩家游戏维度汇总请求结束currentTimeMillis,代理数量:{}, 接口总耗时:{}秒", agents.size(), (timeEnd - timeStart) / 1000);

        // 并发流
//        ForkJoinPool forkJoinPool = new ForkJoinPool(10);
//        ForkJoinTask<?> forkJoinTask = forkJoinPool.submit(() -> {
//            allAgent.parallelStream().forEach(agent -> calculateByAgent(req, records, agent));
//        });
//        // 阻塞,等线程执行完毕
//        try {
//            forkJoinTask.get();
//        } catch (Exception e) {
//            log.warn("Team Report sub task execute fail");
//        }
        long timeStart1 = System.currentTimeMillis();
        StopWatch stopWatch2 = new StopWatch();
        stopWatch2.start();
        //下级代理没有数据，补全数据为0，展示出来
        completeTeamReportData(records, req.getPlayInfoDateStart(), req.getPlayInfoDateEnd(), req.getMonthFlg(), agents);

        // 3.数据汇总(全量)
        if (CollectionUtils.isEmpty(records)) {
            return response;
        }
        response.setTotal(records.size());
        for (TeamReportResponse reportResponse : records) {
            searchSumMap.put(BaseConstants.Turnover, addBigDecimal(searchSumMap.get(BaseConstants.Turnover), reportResponse.getTurnover()));
            searchSumMap.put(BaseConstants.GGR, addBigDecimal(searchSumMap.get(BaseConstants.GGR), reportResponse.getGGR()));
            searchSumMap.put(BaseConstants.WinAndLoss, addBigDecimal(searchSumMap.get(BaseConstants.WinAndLoss), reportResponse.getWinOrLoss()));
            searchSumMap.put(BaseConstants.Deposit, addBigDecimal(searchSumMap.get(BaseConstants.Deposit), reportResponse.getDeposit()));
            searchSumMap.put(BaseConstants.Withdrawal, addBigDecimal(searchSumMap.get(BaseConstants.Withdrawal), reportResponse.getWithdrawal()));
        }

        // 4.数据分页及汇总
        // 4.1 数据排序及分页
        String sortName = req.getSortName();
        boolean isAsc = req.getIsAsc();
        if (StringUtils.isEmpty(req.getSortName())) {
            sortName = "playInfoDate";
            isAsc = false;
        }
        setOrder(sortName, isAsc, records, true, loginName);
        List<TeamReportResponse> pageResult = records.stream()
                .skip((long) req.getPageSize() * (req.getPageNum() - 1))
                .limit(req.getPageSize())
                .collect(Collectors.toList());
        response.setRecords(pageResult);
        response.setPages(records.size() / req.getPageSize() + 1);
        // 4.2 分页汇总
        if (CollectionUtils.isEmpty(pageResult)) {
            return response;
        }
        for (TeamReportResponse pageResponse : pageResult) {
            pageSumMap.put(BaseConstants.Turnover, addBigDecimal(pageSumMap.get(BaseConstants.Turnover), pageResponse.getTurnover()));
            pageSumMap.put(BaseConstants.GGR, addBigDecimal(pageSumMap.get(BaseConstants.GGR), pageResponse.getGGR()));
            pageSumMap.put(BaseConstants.WinAndLoss, addBigDecimal(pageSumMap.get(BaseConstants.WinAndLoss), pageResponse.getWinOrLoss()));
            pageSumMap.put(BaseConstants.Deposit, addBigDecimal(pageSumMap.get(BaseConstants.Deposit), pageResponse.getDeposit()));
            pageSumMap.put(BaseConstants.Withdrawal, addBigDecimal(pageSumMap.get(BaseConstants.Withdrawal), pageResponse.getWithdrawal()));
        }
        stopWatch2.stop();
        long timeEnd1 = System.currentTimeMillis();
        log.info("封装数据stopWatch, 总耗时:{}秒", stopWatch2.getTime(TimeUnit.SECONDS));
        log.info("封装数据currentTimeMillis, 总耗时:{}秒", (timeEnd1 - timeStart1) / 1000);

        if (isCache.equals("2")) {
            String key = req.getMonthFlg() + "-" + req.getPageNum() + "-" + req.getPageSize() + "-" + req.getPlayInfoDateStart() + "-" + req.getPlayInfoDateEnd() + req.getLoginName();
            if (!StringUtils.isBlank(req.getAgentAccount())) {
                key = key + "-" + req.getAgentAccount();
            }
            if (!StringUtils.isBlank(req.getParentAccount())) {
                key = key + "-" + req.getParentAccount();
            }
            if (req.getAgentLevel() != null) {
                key = key + "-" + req.getAgentLevel();
            }
            redisUtil.set(key, new Gson().toJson(response));

        }
        return response;
    }

    /**
     * 新的读取BI 内容
     *
     * @param req
     * @return
     */

    private ReportPageResponse<TeamReportResponse> queryRealTimeRecord2(TeamReportRequest req) {

        // 0.初始化返回值
        ReportPageResponse<TeamReportResponse> response = new ReportPageResponse<>();
        response.setTotal(0);
        response.setPages(0);
        response.setSize(req.getPageSize());
        response.setCurrent(req.getPageNum());
        List<TeamReportResponse> records = new ArrayList<>();
        Map<String, BigDecimal> pageSumMap = response.getPageSumMap();
        initMap(pageSumMap);
        Map<String, BigDecimal> searchSumMap = response.getSearchSumMap();
        initMap(searchSumMap);
        String loginName = req.getLoginName();

        // 1.根据loginName查询所有下线代理
        List<TAgentCustomers> allAgent = getAllAgent(req);//线上环境  ,,,,,
//
//        List<TAgentCustomers> allAgent  =   new ArrayList<>() ;
//
//        TAgentCustomers ooo   = new TAgentCustomers();
//        ooo.setLoginName("mptest388");
//        allAgent.add(ooo) ;
//
//        ooo   = new TAgentCustomers();
//        ooo.setLoginName("mptest397");
//
//        allAgent.add(ooo) ;


        List<TAgentCustomers> agents = allAgent.stream().filter(a -> {
                    // Account 过滤
                    if (StringUtils.isNotEmpty(req.getAgentAccount()) && !a.getLoginName().equals(req.getAgentAccount())) {
                        return false;
                    }
                    if (StringUtils.isNotEmpty(req.getParentAccount()) && !a.getParentName().equals(req.getParentAccount())) {
                        return false;
                    }
                    if (req.getAgentLevel() != null && !Objects.equals(a.getAgentLevel(), req.getAgentLevel())) {
                        return false;
                    }
                    return true;
                }
        ).collect(Collectors.toList());
        TeamReportResponse reportResponse = new TeamReportResponse();

        if (agents.size() == 0) {
            response.setTotal(0L);
            response.setRecords(null);
            response.setPageSumMap(pageSumMap);
            response.setSearchSumMap(searchSumMap);
            return response;
        }


        Integer monthFlg = req.getMonthFlg();

        List<String> agentNames = agents.stream().map(TAgentCustomers::getLoginName).collect(Collectors.toList());

        if (monthFlg == 1) {
            //按月 统计


            BigDecimal searchSumMapGGR = new BigDecimal(0);
            BigDecimal searchSumMapDposit = new BigDecimal(0);
            BigDecimal searchSumMapTurnover = new BigDecimal(0);
            BigDecimal searchSumMapWinAndLoss = new BigDecimal(0);
            BigDecimal searchSumMapWithdrawal = new BigDecimal(0);


            Map<String, Object> parame = new HashMap<>();
//            if(agentNames.)
            parame.put("loginName", agentNames);
            parame.put("playInfoDateStart", req.getPlayInfoDateStart());
            parame.put("playInfoDateEnd", req.getPlayInfoDateEnd());

            List<TUserFinanceOrderTreed> list = tUserFinanceOrderTreedMapper.findList(parame); // 查询 游戏数据 按月统计

            Map<String, TUserFinanceOrderTreed> orderTreedMap = new HashMap<>();

            for (TUserFinanceOrderTreed obj : list) {
                orderTreedMap.put(obj.getRecordDate() + "_" + obj.getLoginName(), obj);
            }

            Map<String, TUserFinanceDwTreed> dwTreedMap = new HashMap<>();

            List<TUserFinanceDwTreed> list2 = tUserFinanceDwTreedMapper.findList(parame);// 查询 存取数据

            for (TUserFinanceDwTreed obj : list2) {
                dwTreedMap.put(obj.getRecordDate() + "_" + obj.getLoginName(), obj);
            }
            List<TeamReportResponse> responseList = new ArrayList<>();
            Date minDate = DateUtils.stringToDate(req.getPlayInfoDateStart(), "yyyy-MM-dd");
            Date maxDate = DateUtils.stringToDate(req.getPlayInfoDateEnd(), "yyyy-MM-dd");


            for (TAgentCustomers tAgentCustomers : agents) {
                while (minDate.getTime() <= maxDate.getTime()) {


                    TeamReportResponse teamReportResponse = new TeamReportResponse();
                    teamReportResponse.setPlayInfoDate(DateUtils.dateToString(minDate, "yyyy-MM"));
                    teamReportResponse.setAgentAccount(tAgentCustomers.getLoginName());
                    teamReportResponse.setParentAccount(tAgentCustomers.getParentName());
                    teamReportResponse.setAgentLevel(tAgentCustomers.getAgentLevel());
                    TUserFinanceOrderTreed userData = orderTreedMap.get(DateUtils.dateToString(minDate, "yyyy-MM") + "_" + tAgentCustomers.getLoginName());
                    TUserFinanceDwTreed userDwData = dwTreedMap.get(DateUtils.dateToString(minDate, "yyyy-MM") + "_" + tAgentCustomers.getLoginName());
                    if (userData != null) {
                        teamReportResponse.setTurnover(userData.getTurnoverAmount());
                        teamReportResponse.setGGR(userData.getGgrAmount());
                        teamReportResponse.setWinOrLoss(userData.getOutcomeAmount());
                    } else {
                        teamReportResponse.setTurnover(BigDecimal.ZERO);
                        teamReportResponse.setGGR(BigDecimal.ZERO);
                        teamReportResponse.setWinOrLoss(BigDecimal.ZERO);
                    }


                    if (userDwData != null) {
                        teamReportResponse.setDeposit(userDwData.getDepositAmount());
                        teamReportResponse.setWithdrawal(userDwData.getWithdrawAmount());
                    } else {
                        teamReportResponse.setDeposit(BigDecimal.ZERO);
                        teamReportResponse.setWithdrawal(BigDecimal.ZERO);
                    }

                    searchSumMapGGR = searchSumMapGGR.add(teamReportResponse.getGGR());
                    searchSumMapDposit = searchSumMapDposit.add(teamReportResponse.getDeposit());
                    searchSumMapTurnover = searchSumMapTurnover.add(teamReportResponse.getTurnover());
                    searchSumMapWinAndLoss = searchSumMapWinAndLoss.add(teamReportResponse.getWinOrLoss());
                    searchSumMapWithdrawal = searchSumMapWithdrawal.add(teamReportResponse.getWithdrawal());


                    responseList.add(teamReportResponse);
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(minDate);
                    calendar.add(Calendar.MONTH, 1);
                    minDate = calendar.getTime();

                }

                minDate = DateUtils.stringToDate(req.getPlayInfoDateStart(), "yyyy-MM-dd");
            }

            searchSumMap.put("GGR", searchSumMapGGR.setScale(2, RoundingMode.DOWN));
            searchSumMap.put("deposit", searchSumMapDposit.setScale(2, RoundingMode.DOWN));

            searchSumMap.put("turnover", searchSumMapTurnover.setScale(2, RoundingMode.DOWN));
            searchSumMap.put("winAndLoss", searchSumMapWinAndLoss.setScale(2, RoundingMode.DOWN));
            searchSumMap.put("withdrawal", searchSumMapWithdrawal.setScale(2, RoundingMode.DOWN));


            String sortName = req.getSortName();
            boolean isAsc = req.getIsAsc();
            if (StringUtils.isEmpty(req.getSortName())) {
                sortName = "playInfoDate";
                isAsc = false;
            }
            setOrder(sortName, isAsc, responseList, true, loginName);
            List<TeamReportResponse> pageResult = responseList.stream()
                    .skip((long) req.getPageSize() * (req.getPageNum() - 1))
                    .limit(req.getPageSize())
                    .collect(Collectors.toList());
            response.setRecords(pageResult);
            response.setTotal(responseList.size());
            response.setPages(records.size() / req.getPageSize() + 1);
            log.info("查询结果 :{}" + new Gson().toJson(list));


            BigDecimal pageGGR = new BigDecimal(0);
            BigDecimal pageDposit = new BigDecimal(0);
            BigDecimal pageTurnover = new BigDecimal(0);
            BigDecimal pageWinAndLoss = new BigDecimal(0);
            BigDecimal pageWithdrawal = new BigDecimal(0);

            for (TeamReportResponse teamReportResponse : pageResult) {
                pageGGR = pageGGR.add(teamReportResponse.getGGR());
                pageDposit = pageDposit.add(teamReportResponse.getDeposit());
                pageTurnover = pageTurnover.add(teamReportResponse.getTurnover());
                pageWinAndLoss = pageWinAndLoss.add(teamReportResponse.getWinOrLoss());
                pageWithdrawal = pageWithdrawal.add(teamReportResponse.getWithdrawal());
            }

            pageSumMap.put("GGR", pageGGR.setScale(2, RoundingMode.DOWN));
            pageSumMap.put("deposit", pageDposit.setScale(2, RoundingMode.DOWN));
            pageSumMap.put("turnover", pageTurnover.setScale(2, RoundingMode.DOWN));
            pageSumMap.put("winAndLoss", pageWinAndLoss.setScale(2, RoundingMode.DOWN));
            pageSumMap.put("withdrawal", pageWithdrawal.setScale(2, RoundingMode.DOWN));
            response.setSearchSumMap(searchSumMap);
            response.setPageSumMap(pageSumMap);


            log.info("返回数据mmmm:{}", searchSumMap);

        } else {
            {
                //按天 统计

                Map<String, Object> parame = new HashMap<>();
                parame.put("loginName", agentNames);
                parame.put("playInfoDateStart", req.getPlayInfoDateStart());
                parame.put("playInfoDateEnd", req.getPlayInfoDateEnd());

                int start = Integer.valueOf(req.getPlayInfoDateStart().split("-")[2]);
                int end = Integer.valueOf(req.getPlayInfoDateEnd().split("-")[2]);

                BigDecimal searchSumMapGGR = new BigDecimal(0);
                BigDecimal searchSumMapDposit = new BigDecimal(0);
                BigDecimal searchSumMapTurnover = new BigDecimal(0);
                BigDecimal searchSumMapWinAndLoss = new BigDecimal(0);
                BigDecimal searchSumMapWithdrawal = new BigDecimal(0);


                List<TUserFinanceOrderTreed> list = tUserFinanceOrderTreedMapper.findListByDay(parame); // 查询 游戏数据 按天统计

                Map<String, TUserFinanceOrderTreed> orderTreedMap = new HashMap<>();

                for (TUserFinanceOrderTreed obj : list) {
                    orderTreedMap.put(obj.getRecordDate() + "_" + obj.getLoginName(), obj);
                }

                Map<String, TUserFinanceDwTreed> dwTreedMap = new HashMap<>();

                List<TUserFinanceDwTreed> list2 = tUserFinanceDwTreedMapper.findListByDay(parame);// 查询 存取数据  按天统计

                for (TUserFinanceDwTreed obj : list2) {
                    dwTreedMap.put(obj.getRecordDate() + "_" + obj.getLoginName(), obj);
                }
                List<TeamReportResponse> responseList = new ArrayList<>();
                for (TAgentCustomers tAgentCustomers : agents) {

                    for (int i = start; i <= end; i++) {
                        String day = "";
                        if (i < 10) {
                            day = req.getPlayInfoDateStart().substring(0, 7) + "-0" + i;
                        } else {
                            day = req.getPlayInfoDateStart().substring(0, 7) + "-" + i;
                        }


                        TeamReportResponse teamReportResponse = new TeamReportResponse();
                        teamReportResponse.setPlayInfoDate(day);
                        teamReportResponse.setAgentAccount(tAgentCustomers.getLoginName());
                        teamReportResponse.setParentAccount(tAgentCustomers.getParentName());
                        teamReportResponse.setAgentLevel(tAgentCustomers.getAgentLevel());
                        TUserFinanceOrderTreed userData = orderTreedMap.get(day + "_" + tAgentCustomers.getLoginName());
                        TUserFinanceDwTreed userDwData = dwTreedMap.get(day + "_" + tAgentCustomers.getLoginName());
                        if (userData != null) {
                            teamReportResponse.setTurnover(userData.getTurnoverAmount());
                            teamReportResponse.setGGR(userData.getGgrAmount());
                            teamReportResponse.setWinOrLoss(userData.getOutcomeAmount());
                        } else {
                            teamReportResponse.setTurnover(BigDecimal.ZERO);
                            teamReportResponse.setGGR(BigDecimal.ZERO);
                            teamReportResponse.setWinOrLoss(BigDecimal.ZERO);
                        }


                        if (userDwData != null) {
                            teamReportResponse.setDeposit(userDwData.getDepositAmount());
                            teamReportResponse.setWithdrawal(userDwData.getWithdrawAmount());
                        } else {
                            teamReportResponse.setDeposit(BigDecimal.ZERO);
                            teamReportResponse.setWithdrawal(BigDecimal.ZERO);
                        }
                        searchSumMapGGR = searchSumMapGGR.add(teamReportResponse.getGGR());
                        searchSumMapDposit = searchSumMapDposit.add(teamReportResponse.getDeposit());
                        searchSumMapTurnover = searchSumMapTurnover.add(teamReportResponse.getTurnover());
                        searchSumMapWinAndLoss = searchSumMapWinAndLoss.add(teamReportResponse.getWinOrLoss());
                        searchSumMapWithdrawal = searchSumMapWithdrawal.add(teamReportResponse.getWithdrawal());

                        responseList.add(teamReportResponse);
                    }

                }

                searchSumMap.put("GGR", searchSumMapGGR.setScale(2, RoundingMode.DOWN));
                searchSumMap.put("deposit", searchSumMapDposit.setScale(2, RoundingMode.DOWN));
                searchSumMap.put("turnover", searchSumMapTurnover.setScale(2, RoundingMode.DOWN));
                searchSumMap.put("winAndLoss", searchSumMapWinAndLoss.setScale(2, RoundingMode.DOWN));
                searchSumMap.put("withdrawal", searchSumMapWithdrawal.setScale(2, RoundingMode.DOWN));


                String sortName = req.getSortName();
                boolean isAsc = req.getIsAsc();
                if (StringUtils.isEmpty(req.getSortName())) {
                    sortName = "playInfoDate";
                    isAsc = false;
                }
                setOrder(sortName, isAsc, responseList, true, loginName);
                List<TeamReportResponse> pageResult = responseList.stream()
                        .skip((long) req.getPageSize() * (req.getPageNum() - 1))
                        .limit(req.getPageSize())
                        .collect(Collectors.toList());
                response.setRecords(pageResult);
                response.setTotal(responseList.size());
                response.setPages(responseList.size() / req.getPageSize() + 1);
                log.info("查询结果 :{}" + new Gson().toJson(list));

                BigDecimal pageGGR = new BigDecimal(0);
                BigDecimal pageDposit = new BigDecimal(0);
                BigDecimal pageTurnover = new BigDecimal(0);
                BigDecimal pageWinAndLoss = new BigDecimal(0);
                BigDecimal pageWithdrawal = new BigDecimal(0);

                for (TeamReportResponse teamReportResponse : pageResult) {
                    pageGGR = pageGGR.add(teamReportResponse.getGGR());
                    pageDposit = pageDposit.add(teamReportResponse.getDeposit());
                    pageTurnover = pageTurnover.add(teamReportResponse.getTurnover());
                    pageWinAndLoss = pageWinAndLoss.add(teamReportResponse.getWinOrLoss());
                    pageWithdrawal = pageWithdrawal.add(teamReportResponse.getWithdrawal());
                }
                pageSumMap.put("GGR", pageGGR.setScale(2, RoundingMode.DOWN));
                pageSumMap.put("deposit", pageDposit.setScale(2, RoundingMode.DOWN));
                pageSumMap.put("turnover", pageTurnover.setScale(2, RoundingMode.DOWN));
                pageSumMap.put("winAndLoss", pageWinAndLoss.setScale(2, RoundingMode.DOWN));
                pageSumMap.put("withdrawal", pageWithdrawal.setScale(2, RoundingMode.DOWN));


                response.setSearchSumMap(searchSumMap);
                response.setPageSumMap(pageSumMap);

            }
        }


        return response;
    }


    private void calculateByAgent(TeamReportRequest req, List<TeamReportResponse> records, TAgentCustomers agent) {
        // 计算单个代理的汇总投注信息
        // 2.1 获取单个代理下所有玩家(包含可投注的代理)
        Result<List<TCustomerLayer>> result = userFeignService.selectUserTree(
                agent.getLoginName(),
                List.of(CustomerTypeEnum.AGENT.getValue())
        );
        if (!result.isSuccess() || CollectionUtils.isEmpty(result.getData())) {
            // 没有玩家的情况下则跳过
            return;
        }

        // 2.2 根据玩家loginName获取投注数据
        List<UserSummerResponse> customerPlayInfoList = readBiData(req.getMonthFlg(), result.getData(),
                req.getPlayInfoDateStart(), req.getPlayInfoDateEnd());

        if (CollectionUtils.isEmpty(customerPlayInfoList)) {
            // 没有投注数据的情况下则跳过
            return;
        }

        log.info("读取BI入参: {} ,出参:", new com.google.gson.Gson().toJson(result), new Gson().toJson(customerPlayInfoList));

        // 2.3 汇总当前代理的投注信息
        Map<String, List<UserSummerResponse>> biRecords;
        if (req.getMonthFlg() == 1) {
            // 2.3.1 月度查询以月为单位生成记录
            biRecords = customerPlayInfoList.stream().collect(Collectors.groupingBy(UserSummerResponse::getRecordStr));
        } else {
            // 2.3.2 日度查询以日为单位生成记录
            biRecords = customerPlayInfoList.stream().collect(Collectors.groupingBy(UserSummerResponse::getRecordDate));
        }
        // 2.4 单位汇总记录
        biRecords.forEach(
                (date, biRecord) -> {
                    TeamReportResponse teamReportResponse = initTeamReportRequest(date, agent, req.getMonthFlg());
                    records.add(teamReportResponse);
                    for (UserSummerResponse userSummerResponse : biRecord) {
                        teamReportResponse.setTurnover(addBigDecimal(teamReportResponse.getTurnover(), userSummerResponse.getTurnoverSum()));
                        teamReportResponse.setGGR(addBigDecimal(teamReportResponse.getGGR(), userSummerResponse.getGgrSum()));
                        teamReportResponse.setWinOrLoss(addBigDecimal(teamReportResponse.getWinOrLoss(), userSummerResponse.getOutcomeSum()));
                        teamReportResponse.setDeposit(addBigDecimal(teamReportResponse.getDeposit(), userSummerResponse.getDepositAmount()));
                        teamReportResponse.setWithdrawal(addBigDecimal(teamReportResponse.getWithdrawal(), userSummerResponse.getWithdrawAmount()));
                    }
                }
        );
    }

    private ReportPageResponse<TeamReportResponse> queryHistoryRecordByBi(TeamReportRequest req) {
        //当前月不显示数据
        String playInfoDateStart = req.getPlayInfoDateStart();
        String playInfoDateEnd = req.getPlayInfoDateEnd();
        if (StringUtils.isNotEmpty(playInfoDateStart) && StringUtils.isNotEmpty(playInfoDateEnd)) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate dateStart = LocalDate.parse(playInfoDateStart, formatter);
            LocalDate dateEnd = LocalDate.parse(playInfoDateEnd, formatter);
            //当前月不显示
            if (YearMonth.from(dateStart).equals(YearMonth.now())) {
                return null;
            }
            if (YearMonth.from(dateEnd).equals(YearMonth.now())) {
                dateEnd = dateEnd.minusMonths(1);
                playInfoDateEnd = dateEnd.format(formatter);
                req.setPlayInfoDateEnd(playInfoDateEnd);
            }
        }
        log.info("queryHistoryRecordByBi req={}", JsonUtil.toJson(req));
        ReportPageResponse<TeamReportResponse> reportPageResponse = queryRealTimeRecord(req);
        return reportPageResponse;
    }

    private ReportPageResponse<TeamReportResponse> queryHistoryRecord(TeamReportRequest req) {
        // 1.根据loginName查询所有下线代理
        List<TAgentCustomers> allAgent = getAllAgent(req);
        List<TAgentCustomers> agents = allAgent.stream().filter(a -> {
                    // Account 过滤
                    if (StringUtils.isNotEmpty(req.getAgentAccount()) && !a.getLoginName().equals(req.getAgentAccount())) {
                        return false;
                    }
                    if (StringUtils.isNotEmpty(req.getParentAccount()) && !a.getParentName().equals(req.getParentAccount())) {
                        return false;
                    }
                    if (req.getAgentLevel() != null && !Objects.equals(a.getAgentLevel(), req.getAgentLevel())) {
                        return false;
                    }
                    return true;
                }
        ).collect(Collectors.toList());
        // 获取代理loginName list(作为 佣金记录分页查询的in条件)
        List<String> agentNames = allAgent.stream().map(TAgentCustomers::getLoginName).collect(Collectors.toList());

        // 2.查询记录总数
        String sortName = "";
        if (StringUtils.isNotBlank(req.getSortName())) {
            sortName = CommonUtil.toUnderlineCase(req.getSortName());
            if (req.getSortName().equals("winOrLoss")) {
                sortName = "win_loss";
            }
        }
        Wrapper<AgentCommissionRecord> queryWrapper = teamReportMapper.getRecordQueryWrapper(req, agentNames, sortName);
        Long total = teamReportMapper.selectCount(queryWrapper);
        log.info("TeamReportServiceImpl-queryByPageAndCondition total={}", total);

        // 3.如果记录为0，则触发自动任务 TODO
        if (Objects.equals(0L, total)) {
//            executeJob(req, loginName);
        }

        // 结果集VO
        ReportPageResponse<TeamReportResponse> reportPageResponse = new ReportPageResponse<>();

        // 4.分页查询
        Page<AgentCommissionRecord> pageRequest = getPageRequest(req, sortName);
        Page<AgentCommissionRecord> resultPage = teamReportMapper.selectPage(pageRequest, queryWrapper);

        BeanCopyUtil.copyProperties(resultPage, reportPageResponse);
        List<TeamReportResponse> teamReportResponses = copyTeamReportResponse(resultPage, req.getMonthFlg());

        //下级代理没有数据，补全数据为0，展示出来
        completeTeamReportDataHistory(teamReportResponses, req.getPlayInfoDateStart(), req.getPlayInfoDateEnd(), req.getMonthFlg(), agents);
        //排序
        if (StringUtils.isEmpty(req.getSortName())) {
            setOrder("playInfoDate", false, teamReportResponses, true, req.getLoginName());
        }

        List<TeamReportResponse> pageResult = teamReportResponses.stream()
                .skip((long) req.getPageSize() * (req.getPageNum() - 1))
                .limit(req.getPageSize())
                .collect(Collectors.toList());
        reportPageResponse.setTotal(teamReportResponses.size());
        reportPageResponse.setPages(teamReportResponses.size() / req.getPageSize() + 1);

        reportPageResponse.setRecords(pageResult);

        // 5.聚合数据整理
        Map<String, BigDecimal> pageSumMap = reportPageResponse.getPageSumMap();
        // 分页数据聚合
        for (TeamReportResponse reportResponse : reportPageResponse.getRecords()) {

            if (Objects.isNull(pageSumMap.get(BaseConstants.Turnover))) {
                initMap(pageSumMap);
            }

            // 分页聚合
            pageSumMap.put(BaseConstants.Turnover, pageSumMap.get(BaseConstants.Turnover).add(reportResponse.getTurnover()));
            pageSumMap.put(BaseConstants.GGR, pageSumMap.get(BaseConstants.GGR).add(reportResponse.getGGR()));
            pageSumMap.put(BaseConstants.WinAndLoss, pageSumMap.get(BaseConstants.WinAndLoss).add(reportResponse.getWinOrLoss()));
            pageSumMap.put(BaseConstants.Deposit, pageSumMap.get(BaseConstants.Deposit).add(reportResponse.getDeposit()));
            pageSumMap.put(BaseConstants.Withdrawal, pageSumMap.get(BaseConstants.Withdrawal).add(reportResponse.getWithdrawal()));

        }

        TeamReportSumResponse sumResponse = teamReportMapper.queryByPageAndConditionSum(req, queryWrapper);
        if (Objects.nonNull(sumResponse)) {
            Map<String, BigDecimal> searchSumMap = reportPageResponse.getSearchSumMap();

            if (Objects.isNull(searchSumMap.get(BaseConstants.Turnover))) {
                initMap(searchSumMap);
            }

            searchSumMap.put(BaseConstants.Turnover, sumResponse.getSumTurnover());
            searchSumMap.put(BaseConstants.GGR, sumResponse.getSumGGR());
            searchSumMap.put(BaseConstants.WinAndLoss, sumResponse.getSumWinAndLoss());
            searchSumMap.put(BaseConstants.Deposit, sumResponse.getSumDeposit());
            searchSumMap.put(BaseConstants.Withdrawal, sumResponse.getSumWithdrawal());

        }
        return reportPageResponse;
    }

    /**
     * 获取当前代理下所有代理
     *
     * @param req req
     * @return 所有代理
     */
    private List<TAgentCustomers> getAllAgent(TeamReportRequest req) {
        AgentListRequest agentListRequest = new AgentListRequest();
        agentListRequest.setRootParentName(req.getLoginName());
        agentListRequest.setIsQueryTree(true);
        if (req.getAgentLevel() != null) {
            agentListRequest.setLevelStart(req.getAgentLevel());
            agentListRequest.setLevelEnd(req.getAgentLevel());
        }
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        Result<List<TAgentCustomers>> agentList = agentApiClient.getAgentList(agentListRequest);
        log.info("/agentCustomers/list 入参TeamReportRequest：{} 返回值：{}", req.toString(), agentList);
        stopWatch.stop();
        log.info("获取所有代理请求 接口耗时:{}秒", stopWatch.getTime(TimeUnit.SECONDS));
        if (!agentList.isSuccess() || CollectionUtils.isEmpty(agentList.getData())) {
            throw new MKTRportException(ResultEnum.AGENT_NOT_EXIST);
        }

        List<TAgentCustomers> agents = agentList.getData().stream().filter(a -> {
                    // Account 过滤
                    if (StringUtils.isNotEmpty(req.getAgentAccount()) && !a.getLoginName().equals(req.getAgentAccount())) {
                        return false;
                    }
                    if (StringUtils.isNotEmpty(req.getParentAccount()) && !a.getParentName().equals(req.getParentAccount())) {
                        return false;
                    }
                    if (req.getAgentLevel() != null && !Objects.equals(a.getAgentLevel(), req.getAgentLevel())) {
                        return false;
                    }
                    return true;
                }
        ).collect(Collectors.toList());
        return agents;
    }

    /**
     * 下级代理没有数据，补全数据为0，展示出来
     *
     * @param records
     * @param playInfoDateStart
     * @param playInfoDateEnd
     * @param monthFlag
     * @param agents
     */
    private void completeTeamReportData(List<TeamReportResponse> records, String playInfoDateStart, String playInfoDateEnd, Integer monthFlag, List<TAgentCustomers> agents) {
        //按日期将数据分组，方便后续比对
        Map<String, List<TeamReportResponse>> playInfoForDateMap = records.stream().collect(Collectors.groupingBy(TeamReportResponse::getPlayInfoDate));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter formatterMM = DateTimeFormatter.ofPattern("yyyy-MM");
        LocalDate dateStart = LocalDate.parse(playInfoDateStart, formatter);
        LocalDate dateEnd = LocalDate.parse(playInfoDateEnd, formatter);
        //循环遍历日期补全数据
        for (LocalDate date = dateStart; !date.isAfter(dateEnd); date = monthFlag == 1 ? date.plusMonths(1) : date.plusDays(1)) {

            String playInfoDate = null;
            if (monthFlag == 1) {
                playInfoDate = date.format(formatterMM);
            } else {
                playInfoDate = date.format(formatter);
            }
            Map<String, List<TeamReportResponse>> teamReportForUser = null;
            List<TeamReportResponse> teamReportForDate = playInfoForDateMap.get(playInfoDate);
            if (!CollectionUtils.isEmpty(teamReportForDate)) {
                teamReportForUser = teamReportForDate.stream().collect(Collectors.groupingBy(TeamReportResponse::getAgentAccount));
            }

            for (TAgentCustomers agent : agents) {
                if (teamReportForUser == null || !teamReportForUser.containsKey(agent.getLoginName())) {
                    //设置默认值
                    TeamReportResponse teamReportResponse = initTeamReportRequest(null, agent, monthFlag);
                    teamReportResponse.setPlayInfoDate(playInfoDate);
                    records.add(teamReportResponse);
                }
            }
        }
    }

    /**
     * 历史数据下级代理没有数据，补全数据为0，展示出来
     *
     * @param records
     * @param playInfoDateStart
     * @param playInfoDateEnd
     * @param monthFlag
     * @param agents
     */
    private void completeTeamReportDataHistory(List<TeamReportResponse> records, String playInfoDateStart, String playInfoDateEnd, Integer monthFlag, List<TAgentCustomers> agents) {
        //按日期将数据分组，方便后续比对
        Map<String, List<TeamReportResponse>> playInfoForDateMap = records.stream().collect(Collectors.groupingBy(TeamReportResponse::getPlayInfoDate));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter formatterMM = DateTimeFormatter.ofPattern("yyyy-MM");
        LocalDate dateStart = LocalDate.parse(playInfoDateStart, formatter);
        LocalDate dateEnd = LocalDate.parse(playInfoDateEnd, formatter);
        //当前月不显示
        if (YearMonth.from(dateStart).equals(YearMonth.now())) {
            return;
        }
        if (YearMonth.from(dateEnd).equals(YearMonth.now())) {
            dateEnd = dateEnd.minusMonths(1);
        }
        //循环遍历日期补全数据
        for (LocalDate date = dateStart; !date.isAfter(dateEnd); date = date.plusMonths(1)) {
            String playInfoDate;
            if (monthFlag == 1) {
                playInfoDate = date.format(formatterMM);
            } else {
                playInfoDate = date.format(formatter);
            }
            Map<String, List<TeamReportResponse>> teamReportForUser = null;
            List<TeamReportResponse> teamReportForDate = playInfoForDateMap.get(playInfoDate);
            if (!CollectionUtils.isEmpty(teamReportForDate)) {
                teamReportForUser = teamReportForDate.stream().collect(Collectors.groupingBy(TeamReportResponse::getAgentAccount));
            }

            for (TAgentCustomers agent : agents) {
                if (teamReportForUser == null || !teamReportForUser.containsKey(agent.getLoginName())) {
                    //设置默认值
                    TeamReportResponse teamReportResponse = initTeamReportRequest(null, agent, monthFlag);
                    teamReportResponse.setPlayInfoDate(playInfoDate);

                    records.add(teamReportResponse);
                }
            }
        }
    }


    /**
     * 主动执行任务
     *
     * @param req       req
     * @param loginName 当前登录用户
     */
    private void executeJob(TeamReportRequest req, String loginName) {
        String playInfoDateStart = req.getPlayInfoDateStart();
        String playInfoDateEnd = req.getPlayInfoDateEnd();
        if (StringUtils.isNoneBlank(playInfoDateStart) && StringUtils.isNoneBlank(playInfoDateEnd)) {
            LocalDate playInfoDateStartLocal = DateUtils.stringToLocalDate(playInfoDateStart);
            LocalDate playInfoDateEndLocal = DateUtils.stringToLocalDate(playInfoDateEnd);

            LocalDate lastMonthFirstDay = DateUtils.getLastMonthFirstDay();
            LocalDate lastMonthLastDay = DateUtils.getLastMonthLastDayV1();
            boolean lastMonthTask = playInfoDateStartLocal.equals(lastMonthFirstDay) && playInfoDateEndLocal.equals(lastMonthLastDay);

            TeamReportRequest teamReportRequest = new TeamReportRequest();
            teamReportRequest.setAgentAccount(loginName);
            teamReportRequest.setMonthFlg(req.getMonthFlg());
            teamReportRequest.setPlayInfoDateStart(playInfoDateStart);
            teamReportRequest.setPlayInfoDateEnd(playInfoDateEnd);
            log.info("页面触发月玩家数据任务开始：执行条件为为：{}", lastMonthTask);

            if (lastMonthTask) {
                try {
                    jobFeignReportService.redo(teamReportRequest);
                } catch (Exception e) {
                    log.error("team trigger error message :{}", e.getMessage());
                }
            }
        }
    }

    /**
     * 结果集VO处理
     *
     * @param resultPage 分页结果集
     * @param monthFlag  月处理flag
     * @return 结果集VO
     */
    private List<TeamReportResponse> copyTeamReportResponse(Page<AgentCommissionRecord> resultPage, Integer monthFlag) {

        List<TeamReportResponse> resultList = resultPage.getRecords().stream().map(r -> {
            TeamReportResponse teamReportResponse = BeanCopyUtil.copyProperties(r, TeamReportResponse::new);
            setDate(monthFlag, r.getSettleDateStart(), teamReportResponse);
            return teamReportResponse;
        }).collect(Collectors.toList());
        // 将当前代理的信息移到首位
        TeamReportResponse currentAgent = resultList.stream()
                .filter(t -> t.getAgentAccount().equals(UserContext.getUsername()))
                .findFirst()
                .orElse(null);
        if (!Objects.isNull(currentAgent)) {
            resultList.remove(currentAgent);
            resultList.add(0, currentAgent);
        }

        return resultList;
    }

    private void setDate(Integer monthFlag, LocalDate date, TeamReportResponse teamReportResponse) {
        if (monthFlag == 1) {
            String playInfoDate = date.toString();
            DateTime parse = DateUtil.parse(playInfoDate);
            String dateYYYYmm = DateUtil.format(parse, DatePattern.NORM_MONTH_FORMAT);
            teamReportResponse.setPlayInfoDate(dateYYYYmm);
        } else {
            teamReportResponse.setPlayInfoDate(date.toString());
        }
    }

    /**
     * 排序抽共通,默认登录人不特殊处理
     *
     * @param sortName 排序名
     * @param isAsc    是否升序
     * @param target   目标数组
     */
    public void setOrder(String sortName, Boolean isAsc, List<TeamReportResponse> target) {
        setOrder(sortName, isAsc, target, false, null);
    }

    /**
     * 排序抽共通 TODO
     *
     * @param sortName         排序名
     * @param isAsc            是否升序
     * @param target           目标数组
     * @param loginNameIsFirst 登录人是否排在最前面
     * @param loginName        登录人名字
     */
    public void setOrder(String sortName, Boolean isAsc, List<TeamReportResponse> target, boolean loginNameIsFirst, String loginName) {
        if (StringUtils.isEmpty(sortName)) {
            return;
        }
        switch (sortName) {
            case "GGR":
                if (isAsc) {
                    target.sort(Comparator.nullsLast(Comparator.comparing(TeamReportResponse::getGGR)));
                } else {
                    target.sort(Comparator.nullsLast(Comparator.comparing(TeamReportResponse::getGGR).reversed()));
                }
                break;
            case "turnover":
                if (isAsc) {
                    target.sort(Comparator.nullsLast(Comparator.comparing(TeamReportResponse::getTurnover)));
                } else {
                    target.sort(Comparator.nullsLast(Comparator.comparing(TeamReportResponse::getTurnover).reversed()));
                }
                break;
            case "winOrLoss":
                if (isAsc) {
                    target.sort(Comparator.nullsLast(Comparator.comparing(TeamReportResponse::getWinOrLoss)));
                } else {
                    target.sort(Comparator.nullsLast(Comparator.comparing(TeamReportResponse::getWinOrLoss).reversed()));
                }
                break;
            case "deposit":
                if (isAsc) {
                    target.sort(Comparator.nullsLast(Comparator.comparing(TeamReportResponse::getDeposit)));
                } else {
                    target.sort(Comparator.nullsLast(Comparator.comparing(TeamReportResponse::getDeposit).reversed()));
                }
                break;
            case "withdrawal":
                if (isAsc) {
                    target.sort(Comparator.nullsLast(Comparator.comparing(TeamReportResponse::getWithdrawal)));
                } else {
                    target.sort(Comparator.nullsLast(Comparator.comparing(TeamReportResponse::getWithdrawal).reversed()));
                }
                break;
            case "playInfoDate":

                if (loginNameIsFirst) {
                    // 当前登录人排在最前面
                    target.sort((o1, o2) -> {
                        boolean accountO1 = o1.getAgentAccount().equals(loginName);
                        boolean accountO2 = o2.getAgentAccount().equals(loginName);
                        int dateCompare;
                        if (isAsc) {
                            dateCompare = o1.getPlayInfoDate().compareTo(o2.getPlayInfoDate());
                        } else {
                            dateCompare = o2.getPlayInfoDate().compareTo(o1.getPlayInfoDate());
                        }
                        if (accountO1 && accountO2) {
                            return dateCompare;
                        }
                        if (accountO1) return -1;
                        if (accountO2) return 1;

                        return dateCompare;
                    });
                } else {
                    if (isAsc) {
                        target.sort(Comparator.nullsLast(Comparator.comparing(TeamReportResponse::getPlayInfoDate)));
                    } else {
                        target.sort(Comparator.nullsLast(Comparator.comparing(TeamReportResponse::getPlayInfoDate).reversed()));
                    }
                }
                break;
            default:
                break;
        }
    }

    /**
     * 创建分页请求
     *
     * @param req req
     * @return 分页请求
     */
    private Page<AgentCommissionRecord> getPageRequest(TeamReportRequest req, String sortName) {
        Page<AgentCommissionRecord> page = new Page<>(req.getPageNum(), req.getPageSize());
        if (StringUtils.isNotBlank(req.getSortName())) {
            OrderItem orderItem = new OrderItem(sortName, req.getIsAsc());
            page.setOrders(List.of(orderItem));
        }
        return page;
    }

    private List<UserSummerResponse> readBiData(Integer monthFlag, List<TCustomerLayer> players, String startDate,
                                                String endDate) {
        // 获取代理玩家的loginName
        List<String> names = players.stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList());
        // 配置bi查询参数
        BiApiTemplate biApiTemplate = new BiApiTemplate(userDataUrl);
        UserSummerRequest biRequest = new UserSummerRequest();
        biRequest.setNames(names);
        biRequest.setMonthFlg(monthFlag);
        biRequest.setStartDate(startDate);
        biRequest.setEndDate(endDate);
        return biApiTemplate.queryUserSummary(biRequest);
    }

    private void initMap(Map<String, BigDecimal> pageSumMap) {
        pageSumMap.put(BaseConstants.Turnover, new BigDecimal(0));
        pageSumMap.put(BaseConstants.GGR, new BigDecimal(0));
        pageSumMap.put(BaseConstants.WinAndLoss, new BigDecimal(0));
        pageSumMap.put(BaseConstants.Deposit, new BigDecimal(0));
        pageSumMap.put(BaseConstants.Withdrawal, new BigDecimal(0));
    }

    private BigDecimal addBigDecimal(BigDecimal source, BigDecimal target) {
        source = source == null ? BigDecimal.ZERO : source; // TODO
        return source.add(target == null ? BigDecimal.ZERO : target);
    }

    private TeamReportResponse initTeamReportRequest(String date, TAgentCustomers agent, int monthFlag) {
        TeamReportResponse teamReportResponse = new TeamReportResponse();
        // data YYYYmm转 YYYY-mm
        if (StringUtils.isNotEmpty(date)) {
            if (monthFlag == 1) {
                StringBuilder dateStr = new StringBuilder(date);
                dateStr.insert(4, "-");
                teamReportResponse.setPlayInfoDate(dateStr.toString());
            } else {
                teamReportResponse.setPlayInfoDate(date);
            }
        }
        teamReportResponse.setAgentAccount(agent.getLoginName());
        teamReportResponse.setParentAccount(agent.getParentName());
        teamReportResponse.setAgentLevel(agent.getAgentLevel());
        teamReportResponse.setTurnover(BigDecimal.ZERO);
        teamReportResponse.setGGR(BigDecimal.ZERO);
        teamReportResponse.setWinOrLoss(BigDecimal.ZERO);
        teamReportResponse.setDeposit(BigDecimal.ZERO);
        teamReportResponse.setWithdrawal(BigDecimal.ZERO);

        return teamReportResponse;
    }

    private List<TAgentCustomers> getPageData(List<TAgentCustomers> list, int pageNumber, int pageSize, int start, int end) {

        List<TAgentCustomers> pageData = new ArrayList<>();


        int day = end - start + 1;
        int totalSize = list.size() * day; //
        int startIndex = (pageNumber - 1) * pageSize;
        int endIndex = Math.min(startIndex + pageSize, totalSize);

        int max  =0  ;
        for (int i = startIndex; i < endIndex; i++) {
//            System.out.println);
            TAgentCustomers letter = list.get(i / day);
            int number = day - i;
            while (number <= (0)) {
                number = number + day;
            }
//
//            if(number ==0) {
//                number  =  day +1 ;
//            }else {
//                number = number +1;
//
//            }

//                        number = number+start  ;

//            letter.setLoginName(letter.getLoginName() + ","  +  number);

            String  createBy = "";

            number   =   number + 1 ;
            if(number < 10){
                createBy   =   DateUtils.dateToString(new Date() ,"yyyy-MM-")  +  "0" + number;
            }else {
                createBy    =  DateUtils.dateToString(new Date() ,"yyyy-MM-")  +  number +"" ;
            }

            max  = Math.max(number,max) ;


            TAgentCustomers    temp  =new TAgentCustomers();
            temp.setLoginName(letter.getLoginName());
            temp.setAgentLevel(letter.getAgentLevel());
            temp.setParentName(letter.getParentName());
            temp.setCreateBy( createBy+"");
//            temp.setA

            pageData.add(temp);

        }

        log.info("-------max={},     min={}" ,  max   , end );

        if(max > end) {
            System.out.println(max +"" +end);

            for(TAgentCustomers agentCustomers :  pageData ) {
                String date =  agentCustomers.getCreateBy() ;
                date =  DateUtils.getBeforeDateTime2(DateUtils.stringToDate(date),-1) ;
                agentCustomers.setCreateBy(date);

            }
        } else if(max <end) {
            int mius = end  -max  ;
            for(TAgentCustomers agentCustomers :  pageData ) {
                String date =  agentCustomers.getCreateBy() ;
                date =  DateUtils.getBeforeDateTime2(DateUtils.stringToDate(date),mius) ;
                agentCustomers.setCreateBy(date);

            }
        }


        return pageData;
    }
    /**
     * 判断被查寻用户是否存在登录用户下级
     * @param loginName
     * @param agentAccount
     * @return
     */
    private boolean agentAccountExist(String loginName, String agentAccount) {
        if (loginName.equals(agentAccount)) {
            return true;
        } else {
            DashBoardUserTreeQueryReq dashBoardUserTreeQueryReq = new  DashBoardUserTreeQueryReq();
            dashBoardUserTreeQueryReq.setParent(loginName);
            Result<List<TCustomerLayer>> layers = userFeignService.selectUserTreeByParentNTime(dashBoardUserTreeQueryReq);
            if (layers.getData().size() > 0) {
                List<String> payers = layers.getData().stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList()); //查詢代理下的用戶数据
                boolean match = payers.stream().anyMatch(str -> str.equals(agentAccount));
                return match;
            }else {
                return false;
            }
        }
    }

    /**
     * 保存  当天或是 当月数据
     * @param day  日期
     * @param flag //  1 为天  2  为月
     * @param    saveFlag 是否 保存  2 为保存
     * @param    loginName 代理账号
     */
    public  ClDashBoardDataRes   saveLocalData( Date day  ,int  flag ,int  saveFlag,String loginName){

        List<ClDashBoardDataRes> data = new ArrayList<>() ;
        ClDashBoardDataRes  value = new ClDashBoardDataRes() ;
        Date min   = new Date() ;
        Date max   = new Date() ;
        String key  = "";
        if(flag ==1) {
            //天
            min   =DateUtils.stringToDate(DateUtils.dateToString(day,"yyyy-MM-dd") + " 00:00:01","yyyy-MM-dd HH:mm:ss") ;
              max   =   DateUtils.stringToDate(DateUtils.dateToString(day,"yyyy-MM-dd") + " 23:59:59","yyyy-MM-dd HH:mm:ss");

            key  =  loginName + DateUtils.dateToString(min,"yyyy-MM-dd") ;

            log.info("查询开始时间={},结束时间={}", DateUtils.dateToString(min,"yyyy-MM-dd HH:mm:ss"),DateUtils.dateToString(max,"yyyy-MM-dd HH:mm:ss"));

            value.setAgentDate(DateUtils.dateToString(min));




        }else {
            //月

            min   = DateUtils.getFirstDayOfMonth(day) ;
            Calendar calendar =  Calendar.getInstance();
            calendar.setTime(min);
            calendar.add(Calendar.MONTH,1);
            calendar.add(Calendar.DAY_OF_MONTH,-1);
            max   =   calendar.getTime();

            key  = loginName +  DateUtils.dateToString(min,"yyyy-MM") ;

            value.setAgentDate( DateUtils.dateToString(min,"yyyy-MM"));

            log.info("查询开始时间={},结束时间={}", DateUtils.dateToString(min,"yyyy-MM-dd HH:mm:ss"),DateUtils.dateToString(max,"yyyy-MM-dd HH:mm:ss"));

        }
        Map<String, Object> p = new HashMap<>();
        p.put("min",DateUtils.dateToString(min,"yyyy-MM-dd")) ;
        p.put("max",DateUtils.dateToString(max,"yyyy-MM-dd")) ;
        p.put("loginName" ,loginName );

        data = getNewAllData(p);
        List<Map<String,Object>>  list =   new ArrayList<>() ;

        for (ClDashBoardDataRes temp : data) {
            value.setWithdrawalAmount(value.getWithdrawalAmount().add(temp.getWithdrawalAmount()));
            value.setDepositAmount(value.getDepositAmount().add(temp.getDepositAmount()));
            if(temp.getGameType()!= -1) {
                value.setTurnover(value.getTurnover().add(temp.getTurnover()));
            }
            value.setGgr(value.getGgr().add(temp.getGgr()));
            value.setWinOrLoss(value.getWinOrLoss().add(temp.getWinOrLoss()));
            value.setFirstDeposit(value.getFirstDeposit()+ temp.getFirstDeposit());
            value.setFirstDepositAmount(value.getFirstDepositAmount().add(temp.getFirstDepositAmount()));
            value.setBetPlayers(value.getBetPlayers()+ temp.getBetPlayers());
            value.setLoginName(key);

                if(temp.getGameType()!= -1) {

                    Map<String,Object>  tempParame = new HashMap<>() ;
                    TeamReportHistoryType teamReportHistoryType = new TeamReportHistoryType();
                    teamReportHistoryType.setId(UUID.randomUUID().toString());
                    teamReportHistoryType.setGameType(temp.getGameType() + "");
                    teamReportHistoryType.setWinorloss(temp.getWinOrLoss());
                    teamReportHistoryType.setGgr(temp.getGgr());
                    teamReportHistoryType.setLoginNameDate(key);
                    teamReportHistoryType.setTurnover(temp.getTurnover());
                    tempParame.put("id",teamReportHistoryType.getId()) ;
                    tempParame.put("gameType",teamReportHistoryType.getGameType()) ;
                    tempParame.put("winorloss",teamReportHistoryType.getWinorloss()) ;
                    tempParame.put("ggr",teamReportHistoryType.getGgr()) ;
                    tempParame.put("loginNameDate",key) ;
                    tempParame.put("turnover",teamReportHistoryType.getTurnover()) ;
                    list.add(tempParame) ;
                    Map<String, String> delParame = new HashMap<>();
                    delParame.put("loginName", key);
                    delParame.put("type", teamReportHistoryType.getGameType());
                    if (saveFlag == 2) {
                    teamReportHistoryTypeMapper.delete2(delParame);

                    teamReportHistoryTypeMapper.insert(teamReportHistoryType);
                }
            }


        }

        value.setTeamReportHistoryType(list);
        value.setBetPlayers( getCommissionData(p,value));



        if (saveFlag == 2) {
            Map<String,String>  delParame = new HashMap<>() ;
            delParame.put("loginName" ,key );
            teamReportHistoryMapper.delParame(delParame) ;
            TeamReportHistory history = new TeamReportHistory();

            log.info("插入前的数据={}" ,new Gson().toJson(value));

            history.setFirstDeposit(value.getFirstDepositAmount());
            history.setFirstDepositCount(value.getFirstDeposit());
            history.setTurnover(value.getTurnover());
            history.setGgr(value.getGgr());
            history.setWithdrawAmount(value.getWithdrawalAmount());
            history.setDepositAmount(value.getDepositAmount());
            history.setWinorloss(value.getWinOrLoss());
            history.setLoginNameDate(key);
            history.setType(flag+"");
            history.setBetPlayers( value.getBetPlayers());

            history.setCreateDateTime(new Date());


            teamReportHistoryMapper.insert(history) ;

        }


        return  value;
    }

    @Override
    public ReportPageResponse<TeamReportResponse> queryPlayerByPageAndCondition(TeamReportRequest req) {
        return null;
    }

    @Override
    public ReportPageResponse<PlayerReportResponse> playerQueryByPageAndCondition(PlayerReportRequest req) {

        log.info("---- 开始查询={}",new Gson().toJson(req));
        ReportPageResponse<PlayerReportResponse> response = new ReportPageResponse<>();
        response.setTotal(0);
        response.setPages(0);
        response.setSize(req.getPageSize());
        response.setCurrent(req.getPageNum());
        List<PlayerReportResponse> records = new ArrayList<>();
        String loginName = req.getLoginName();

        String  playerAccount   =req.getPlayerAccount() ;


        String key  = req.getDataDate()+"_" +  req.getStartDate() +"_" +  req.getEndDate()+"_" +  req.getLoginName();

        if(!StringUtils.isBlank(req.getPlayerAccount())){
            key  =   key + "_" +  req.getPlayerAccount();
        }

        if(!StringUtils.isBlank(req.getParentAccount())){
            key  =   key + "_" +  req.getParentAccount();
        }
        if(!StringUtils.isBlank(req.getParentLevel())){
            key  =   key + "_" +  req.getParentLevel();
        }
        key = key + "_" + req.getPageNum() + "_" +  req.getPageSize() ;

        String  lostKey =    key + "_lost" ;

        Object jsonData    =    redisUtil.get(key) ;

        log.info("返回的数据={}" ,jsonData);

        if (jsonData != null   &&   !StringUtils.isBlank(jsonData.toString())){
            String json  =   jsonData.toString() ;
            JSONObject jsonObject    =  new JSONObject(json);
            Long total  =jsonObject.getLong("total") ;
            JSONArray  array  =  jsonObject.getJSONArray("list");
            List<PlayerReportResponse>  ll   =  getPlayerReportResponse(array) ;

            response.setRecords(ll);
            response.setTotal(total) ;

            if (!redisUtil.hasKey(lostKey)) {
                String finalKey = key;
                new Thread(() -> {
                     getPageDataRespon(loginName, playerAccount, finalKey, lostKey, req, records);

                }).start();
            }

            }else {

            response = getPageDataRespon(loginName, playerAccount, key, lostKey, req, records);
        }






        return response;
    }

    private ReportPageResponse<PlayerReportResponse> getPageDataRespon(String loginName, String playerAccount, String key, String lostKey, PlayerReportRequest req, List<PlayerReportResponse> records) {
        ReportPageResponse<PlayerReportResponse> response = new ReportPageResponse<>();

        if(!StringUtils.isBlank(playerAccount)){
            //如果查询指定账号
            Long  cc   =  userMapper.selectUserTreeByParentNTimeByCount(loginName, playerAccount);
            log.info("查询到的用户数据------={}",cc);
            if(cc > 0) {
                //标识有数据。
                Map<String, Object> ppp = new HashMap<>();
                ppp.put("playerAccount",playerAccount);

                com.mkt.agent.report.req.TAgentCustomers agentCustomers  = new com.mkt.agent.report.req.TAgentCustomers() ;
                agentCustomers = userMapper.getUserData(ppp);
                if(!StringUtils.isBlank(req.getParentAccount())  ||!StringUtils.isBlank(req.getParentLevel())  ){

                    log.info("agentCustomers={}",agentCustomers.toString());
                    log.info("req.getParentAccount()={}",req.getParentAccount());

                    if(!StringUtils.isBlank(req.getParentAccount())   && !agentCustomers.getLoginName().equals(req.getParentAccount())){
                        return  response ;
                    }
                    log.info("req.getParentLevel()={}",req.getParentLevel());

                    if(!StringUtils.isBlank(req.getParentLevel())   && !(agentCustomers.getAgentLevel()+"").equals(req.getParentLevel())){
                        return  response ;
                    }



                }

                // 有数据 直接查询 clickhose
                //开始计算总数
                if (!StringUtils.isBlank(req.getStartDate())) {
                    ppp.put("startDate",req.getStartDate());
                }

                if (!StringUtils.isBlank(req.getEndDate())) {

                    if(req.getDataDate().equals("Month")){
                        String d =  req.getEndDate();
                        Date  d1 = DateUtils.stringToDate(d);
                        Calendar c  = Calendar.getInstance();
                        c.setTime(d1);
                        c.add(Calendar.MONTH,1);
                        c.add(Calendar.DAY_OF_MONTH,-1);
                        d  =  DateUtils.dateToString(c.getTime()) ;
                        ppp.put("endDate", d);

                    }else {

                        ppp.put("endDate", req.getEndDate());
                    }
                }
                ppp.put(req.getDataDate(),req.getDataDate()) ;

                Long toatlCount   =   tDailyOrderMapper.getCountByAccount(ppp);

                log.info("查询处总数为={}",toatlCount);

                // 开始查询明细
//                 List<>

                int start   =   (req.getPageNum()  -1  ) *  req.getPageSize() ;
                int limit  =    req.getPageSize() ;
                ppp.put("start",start);
                ppp.put("limit",limit);
                if(toatlCount> 10000){
                    toatlCount = 10000L;
                }
                records  =  tDailyOrderMapper.findPlayerData(ppp);
                for(PlayerReportResponse l:records) {
                    l.setParent(agentCustomers.getLoginName());
                    l.setParentLevel(agentCustomers.getAgentLevel()+"");
                    if(req.getDataDate().equals("Month")){
                        l.setAgentDate(l.getAgentDate().substring(0,4) +"-" + l.getAgentDate().substring(4));
                    }
                }
                response.setRecords(records);
                response.setTotal(toatlCount);

                Map<String,Object>  objectMap  = new HashMap<>();
                objectMap.put("list",records);
                objectMap.put("total",toatlCount) ;

                redisUtil.set(key,new Gson().toJson(objectMap));
                redisUtil.set(lostKey,new Gson().toJson(objectMap));
                redisUtil.setExpire(lostKey,expireLongTime);



            }
        }else {


            List<TAgentCustomers> agents = new ArrayList<>();

            try {
                TeamReportRequest reportRequest = new TeamReportRequest();
                reportRequest.setLoginName(req.getLoginName());
                if (req.getParentLevel() != null) {
                    reportRequest.setAgentLevel(Integer.valueOf(req.getParentLevel()));
                }
                if (req.getParentAccount() != null) {
                    reportRequest.setAgentAccount(req.getParentAccount());

                }
                agents = getAllAgent(reportRequest);//先查询所有代理


                if(agents!= null &&   agents.size() >  0) {

                    List<String> dailis = agents.stream().map(TAgentCustomers::getLoginName).collect(Collectors.toList());

                    log.info("----查询出的代理={}", new Gson().toJson(dailis));

                    //查询出他有用的玩家
                    Map<String, Object> parame = new HashMap<>();
                    parame.put("daili", dailis); //根据代理取查询数据 查询所有代理的直属玩家 在查询
                    if (!StringUtils.isBlank(req.getStartDate())) {
                        parame.put("startDate", req.getStartDate());
                    }

                    if (!StringUtils.isBlank(req.getEndDate())) {
//                        parame.put("endDate", req.getEndDate());
                        if(req.getDataDate().equals("Month")){
                            String d =  req.getEndDate();
                            Date  d1 = DateUtils.stringToDate(d);
                            Calendar c  = Calendar.getInstance();
                            c.setTime(d1);
                            c.add(Calendar.MONTH,1);
                            c.add(Calendar.DAY_OF_MONTH,-1);
                            d  =  DateUtils.dateToString(c.getTime()) ;
                            parame.put("endDate", d);

                        }else {

                            parame.put("endDate", req.getEndDate());
                        }
                    }
                    parame.put(req.getDataDate(), req.getDataDate());


                    int start   =   (req.getPageNum()  -1  ) *  req.getPageSize() ;
                    int limit  =    req.getPageSize() ;
                    parame.put("start",start);
                    parame.put("limit",limit);

                    TAgentCustomers  agentCustomers   =  agents.get(0);
                    Long totalCount = 0L;
                    if(agentCustomers.getSiteId() == 1){
                        totalCount = userMapper.getPlayReportDataAp(parame);
                        records   = userMapper.getPlayReportDataApList(parame);

                    }else if(agentCustomers.getSiteId() == 2){
                        totalCount = userMapper.getPlayReportDataBp(parame);
                        records   = userMapper.getPlayReportDataBpList(parame);

                    }else if(agentCustomers.getSiteId() == 3){
                        totalCount = userMapper.getPlayReportDataGp(parame);
                        records   = userMapper.getPlayReportDataGpList(parame);

                    }

                    log.info("----查询出的数据总数={} ", totalCount);

                    if(totalCount> 10000){
                        totalCount = 10000L;
                    }

                    response.setTotal(totalCount);
                    response.setRecords(records) ;


//                    redisUtil.set(key,new Gson().toJson(response));
//                    redisUtil.set(lostKey,new Gson().toJson(response));
                    Map<String,Object>  objectMap  = new HashMap<>();
                    objectMap.put("list",records);
                    objectMap.put("total",totalCount) ;

                    redisUtil.set(key,new Gson().toJson(objectMap));
                    redisUtil.set(lostKey,new Gson().toJson(objectMap));
                    redisUtil.setExpire(lostKey,expireLongTime);


                }
            } catch (Exception e) {
                e.printStackTrace();
            }


        }
        return  response;

    }

    private List<PlayerReportResponse> getPlayerReportResponse(JSONArray array) {
        List<PlayerReportResponse>  datas =   new ArrayList<>() ;
        for (int i =0 ;i < array.length() ;i++) {
//            PlayerReportResponse  o =
//            String j  =   new Gson().toJson(array.getJSONObject(i)) ;

//            log.info("json数据={}",j);

            JSONObject  object =   array.getJSONObject(i) ;

//            String agentDate =

            PlayerReportResponse   t  =   new PlayerReportResponse();
            t.setAgentDate(object.getString("agentDate"));
            t.setParent(object.getString("parent"));
            t.setParentLevel(object.getString("parentLevel"));
            t.setDeposit(object.getBigDecimal("deposit"));
            t.setTurnover(object.getBigDecimal("turnover"));
            t.setAccount(object.getString("account"));
            t.setGgr(object.getBigDecimal("ggr"));
            t.setWithdrawal(object.getBigDecimal("withdrawal"));
            t.setWinOrLoss(object.getBigDecimal("winOrLoss"));

            datas.add(t)  ;
        }
        return  datas;

    }


    private Integer getCommissionData(Map<String, Object> p, ClDashBoardDataRes value) {
        Integer  commission  = 0  ;

        //先找佣金方案
//        t_agent_contractbind


        return  commission ;
    }


}

