package com.mkt.agent.report.mapper;

import com.baomidou.mybatisplus.annotation.TableName;
import com.mkt.agent.common.player.model.TAgentCountGroup;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
@TableName("t_agent_count_group_day")
public interface UsersGroupMapper {

    int insertUsersGroup(@Param(value = "list") List<TAgentCountGroup> list);

    /**
     * 查询指定日期范围内，指定代理用户的direct_count
     *
     * @param queryReq
     * @return
     */
    List<TAgentCountGroup> queryDownLineCount(@Param("queryReq") TAgentCountGroup queryReq);


    /**
     * 查询某个时间段内某批代理的交易总数
     *
     * @param queryReq
     * @return
     */
    List<TAgentCountGroup> queryTransCountByAgentsAndDate(@Param("queryReq") TAgentCountGroup queryReq);

    /**
     * 获取t_agent_count_group_day中最大最小日期
     *
     * @return
     */
    TAgentCountGroup queryDashDateRange(@Param("param") TAgentCountGroup queryReq);

    /**
     * 删除指定时间区间内的数据
     *
     * @param param
     * @return
     */
    int deleteUsersGroup(@Param("param") TAgentCountGroup param);

}
