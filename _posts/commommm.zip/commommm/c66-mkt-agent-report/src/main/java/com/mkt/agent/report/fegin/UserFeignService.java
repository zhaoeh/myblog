package com.mkt.agent.report.fegin;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse;
import com.mkt.agent.common.entity.clickhouse.req.DashBoardUserTreeQueryReq;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

//@FeignClient(name = "${feign.mkt-user}", url = "127.0.0.1:18088")
@FeignClient(name = "${feign.mkt-user}")
public interface UserFeignService {

    @GetMapping("/user/tree/by-parent")
    Result<List<TCustomerLayer>> selectUserTree (
            @RequestParam("parent") String parent,
            @RequestParam("customerTypeList") List<Integer> customerTypeList
    );

    @PostMapping("/user/tree/byParentNTime")
    Result<List<TCustomerLayer>> selectUserTreeByParentNTime(@RequestBody DashBoardUserTreeQueryReq queryEntity);

    /**
     * 查询一批用户在指定时间范围内的所有团队用户
     *
     * @param queryEntity 请求
     * @return 响应
     */
    @PostMapping("/user/tree/byParentListNTime")
    Result<List<String>> selectUserTreeByParentNTimeOfPart(@RequestBody DashBoardUserTreeQueryReq queryEntity);

    @PostMapping("/user/directUsers/byParentListNTime")
    Result<List<String>> selectDirectUsersByParentListNTime(@RequestBody DashBoardUserTreeQueryReq queryEntity);

    @PostMapping("/user/tree/byParentNTimeCount")
    Result<Long> selectUserTreeByParentNTimeCount(@RequestBody DashBoardUserTreeQueryReq queryEntity);

    @GetMapping(value = "/v1/customer/layer/getNotDeletedOneByLoginName")
    Result<TCustomerLayer> getNotDeletedOneByLoginName(@RequestParam("loginName")String loginName);


    @GetMapping(value = "/user/one/fromParentTeam")
    Result<TCustomerLayer> selectUserFromParentTeam(@RequestParam("parent")String parent, @RequestParam("loginName")String loginName);

    @PostMapping("/user/selectParentNParentLevelByUsersForPReport")
    Result<List<PlayerReportResponse>> selectParentNParentLevelByUsersForPReport(@RequestBody List<String> userNames);

}
