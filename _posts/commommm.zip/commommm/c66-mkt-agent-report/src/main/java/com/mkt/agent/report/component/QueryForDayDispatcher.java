package com.mkt.agent.report.component;

import com.mkt.agent.common.config.PlayerReportConfig;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.reportapi.requests.PlayerReportRequest;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.base.ReportPageResponse;
import com.mkt.agent.common.enums.DashboardChosenTimeEnum;
import com.mkt.agent.common.player.core.PlayerCache;
import com.mkt.agent.common.player.core.PlayerOperator;
import com.mkt.agent.common.player.model.PlayerMapperHolder;
import com.mkt.agent.common.player.model.PlayerOperatorModel;
import com.mkt.agent.common.player.model.TAgentCountGroup;
import com.mkt.agent.common.utils.CommonUtil;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.PageUtils;
import com.mkt.agent.report.clickhouse.mapper.ClDashBoardV1Mapper;
import com.mkt.agent.report.mapper.UsersGroupMapper;
import com.mkt.agent.report.utils.PlayerReportUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;

import java.util.*;

/**
 * @description: 按天查询player转发器
 * @author: ErHu.Zhao
 * @create: 2024-02-05
 **/
@Component
@Slf4j
public class QueryForDayDispatcher {

    @Autowired
    private UsersGroupMapper usersGroupMapper;

    @Autowired
    private PlayerOperator playerOperator;

    @Autowired
    private UsersSupplier usersSupplier;

    @Autowired
    private ClDashBoardV1Mapper clDashBoardV1Mapper;

    @Autowired
    private PlayerForPageQueryByDay playerForPageQueryByDay;

    @Autowired
    private PlayerReportUtil playerReportUtil;

    @Autowired
    private PlayerReportConfig playerReportConfig;

    @Autowired
    private PlayerCache playerCache;

    public ReportPageResponse<PlayerReportResponse> playerForDayDispatch(PlayerReportRequest request, boolean ignorePagination) {
        ReportPageResponse<PlayerReportResponse> response = new ReportPageResponse();
        if (Objects.isNull(request)) {
            return response;
        }
        Assert.isTrue(DashboardChosenTimeEnum.ChosenType_Day.getName().equals(request.getDataDate()), "dataDate must be \"" + DashboardChosenTimeEnum.ChosenType_Day.getName() + "\"");
        response.setSize(request.getPageSize());
        PlayerMapperHolder holder = initMappersHolder();
        PlayerOperatorModel model = initModel(request, ignorePagination);
        log.info("init model is {}", model);
        this.prepareContext(request, holder, model);
        this.processContext(holder, model);
        List<PlayerReportResponse> data = supplyDataWithModel(model);
        data = this.afterHandle(data, model);
        return wrapperResponse(response, data, model);
    }

    /**
     * 准备环境
     *
     * @param request
     * @param holder
     * @param model
     */
    private void prepareContext(PlayerReportRequest request, PlayerMapperHolder holder, PlayerOperatorModel model) {
        Assert.notNull(request, "request cannot be null");
        Assert.notNull(holder, "holder cannot be null");
        Assert.notNull(model, "model cannot be null");
        String playerAccount = request.getPlayerAccount();
        // case1：直接查询player account
        if (StringUtils.isNotBlank(playerAccount)) {
            if (!playerReportUtil.checkIfPlayerMeetCondition(request)) {
                // 不满足条件直接终止
                model.setKilled(Boolean.TRUE);
                log.info("playerAccount {} is not meet condition,stop to search", playerAccount);
                return;
            }
            // 当playerAccount不为空时，说明直接查询
            model.setDirectQuery(Boolean.TRUE);
            // 设置查询用户参数集
            model.setTargetQueryUsers(List.of(request.getPlayerAccount()));
            log.info("begin to search by playerAccount {}", playerAccount);
            return;
        }

        // 当playerAccount为空时，说明需要分阶段查询
        model.setDirectQuery(Boolean.FALSE);
        // 玩家直属上级代理账号
        String parentAccount = request.getParentAccount();
        // 玩家直属上级代理等级
        String parentLevel = request.getParentLevel();
        if (StringUtils.isNotBlank(parentLevel) || StringUtils.isNotBlank(parentAccount)) {
            // case2：查询parentAccount或者parentLevel
            handleParentThings(holder, model, parentAccount, parentLevel);
            if (model.isKilled()) {
                return;
            }
        } else {
            // case3：查询当前登录者
            handleCurrentThings(holder, model);
        }
        if (CollectionUtils.isEmpty(model.getTargetAgents())) {
            log.info("targetAgents is empty,stop to search");
            model.setKilled(Boolean.TRUE);
        }
    }

    /**
     * 处理环境
     *
     * @param holder
     * @param model
     */
    private void processContext(PlayerMapperHolder holder, PlayerOperatorModel model) {
        if (model.isKilled() || model.isDirectQuery()) {
            log.info("model is killed or is directQuery,stop to search");
            return;
        }

        if(CollectionUtils.isEmpty(model.getTargetAgents())){
            log.info("target agents is empty,stop to search");
            return;
        }

        // 命中当前页查询日期集合
        playerOperator.phasedHandle(holder, model);

        List<String> targetDates = model.getTargetDates();
        if (CollectionUtils.isEmpty(targetDates)) {
            log.info("targetDates is empty,stop to search");
            model.setKilled(Boolean.TRUE);
            return;
        }

        // 设置查询用户参数集
        List<String> targetQueryUsers = holder.getTargetUsersMapper().apply(model.getAgentCountGroup());
        if (CollectionUtils.isEmpty(targetQueryUsers)) {
            model.setKilled(Boolean.TRUE);
            log.info("targetQueryUsers is empty,stop to search");
            return;
        }
        model.setTargetQueryUsers(targetQueryUsers);
    }

    /**
     * 根据model供应数据
     */
    private List<PlayerReportResponse> supplyDataWithModel(PlayerOperatorModel model) {
        if (model.isKilled()) {
            return Collections.emptyList();
        }
        return playerForPageQueryByDay.queryPlayerInfoByDayWithAsync(model);
    }

    /**
     * 后置处理
     *
     * @param data
     * @param model
     * @return
     */
    private List<PlayerReportResponse> afterHandle(List<PlayerReportResponse> data, PlayerOperatorModel model) {
        if (CollectionUtils.isEmpty(data) || model.isKilled()) {
            return Collections.emptyList();
        }
        if (model.isDirectQuery()) {
            playerOperator.refreshTotal(model, data.size());
            playerOperator.refactorIndexWhenIgnorePagination(model);
        }
        Comparator<PlayerReportResponse> comparator = Comparator
                .comparing(PlayerReportResponse::getAgentDate, Comparator.reverseOrder())
                .thenComparing(PlayerReportResponse::getAccount, Comparator.reverseOrder());
        List<PlayerReportResponse> afterData = playerOperator.pagingSources(data, comparator, model.getTotalSizeWhenFirstHitStartIndex(), model.getStartIndex(), model.getEndIndex());
        playerReportUtil.selectParentNParentLevelByUsersForPReport(afterData);
        return afterData;

    }

    /**
     * 包装response
     *
     * @param response
     * @param data
     * @param model
     * @return
     */
    private ReportPageResponse<PlayerReportResponse> wrapperResponse(ReportPageResponse<PlayerReportResponse> response, List<PlayerReportResponse> data, PlayerOperatorModel model) {
        Assert.notNull(response, "response cannot be null");
        Assert.notNull(model, "model cannot be null");
        if (model.isKilled() || CollectionUtils.isEmpty(data)) {
            return response;
        }
        response.setRecords(data);
        response.setTotal(model.getTotalSize());
        return response;
    }

    /**
     * 初始化model
     *
     * @param request
     * @return
     */
    private PlayerOperatorModel initModel(PlayerReportRequest request, boolean ignorePagination) {
        TAgentCountGroup group = TAgentCountGroup.builder().agentName(request.getLoginName()).
                beginDate(resetStartDate(request.getStartDate())).endDate(resetEndDate(request.getEndDate())).build();
        return PlayerOperatorModel.builder().
                agentCountGroup(group).
                prepareKey(playerCache.prepareCacheKey(request)).
                killed(Boolean.FALSE).
                targetDates(new ArrayList<>()).
                startIndex(PageUtils.calculateStartIndex(request.getPageNum(), request.getPageSize())).
                endIndex(PageUtils.calculateEndIndex(request.getPageNum(), request.getPageSize())).
                iterationDate(request.getEndDate()).
                maxCountLimit(playerReportConfig.getMaxCountLimit()).
                ignorePagination(ignorePagination).
                totalSize(0).
                totalSizeWhenFirstHitStartIndex(Constants.DEFAULT_FIRST_HIT_START_INDEX).
                totalSizeWhenHitEndIndex(0).build();
    }

    private String resetStartDate(String startDate) {
        if (StringUtils.isBlank(startDate)) {
            return startDate;
        }
        // 2个月前的今天
        String todayOf3MonthAgo = DateUtils.getNMonthAgoDate(3).toString();
        int needStartDate  = CommonUtil.convertToInt(todayOf3MonthAgo);
        int startDateInt = CommonUtil.convertToInt(startDate);
        if (startDateInt < needStartDate) {
            return todayOf3MonthAgo;
        }
        return startDate;
    }

    private String resetEndDate(String endDate) {
        if (StringUtils.isBlank(endDate)) {
            return endDate;
        }

        String today = DateUtils.getNDaysAgo(0).toString();
        int todayInt = CommonUtil.convertToInt(today);
        int endDateInt = CommonUtil.convertToInt(endDate);
        if (endDateInt > todayInt) {
            return today;
        }
        return endDate;
    }

    /**
     * 初始化 PlayerMapperHolder
     *
     * @return
     */
    private PlayerMapperHolder initMappersHolder() {
        PlayerMapperHolder holder = PlayerMapperHolder.builder().agentCountMapper(usersGroupMapper::queryTransCountByAgentsAndDate).
                targetAgentsTransCountMapper(clDashBoardV1Mapper::getTransCountByAgents).build();
        return holder;
    }

    /**
     * 处理parent相关case
     *
     * @param holder
     * @param model
     * @param parentAccount
     * @param parentLevel
     */
    private void handleParentThings(PlayerMapperHolder holder, PlayerOperatorModel model, String parentAccount, String parentLevel) {
        log.info("处理parentAccount or parentLevel case");
        TAgentCustomers agent = playerReportUtil.selectAgentByName(model.getAgentName());
        if (Objects.isNull(agent)) {
            model.setKilled(Boolean.TRUE);
            log.info("login user is null,stop to search");
            return;
        }
        Integer loginLevel = agent.getAgentLevel();
        if (Objects.isNull(loginLevel) || loginLevel < Integer.valueOf(Constants.ONE)) {
            model.setKilled(Boolean.TRUE);
            log.info("login user level is null or less than 1");
            return;
        }
        String loginParentName = agent.getParentName();

        if (StringUtils.isNotBlank(parentAccount) && StringUtils.isNotBlank(parentLevel)) {
            if (isBelowOneLevelAgent(agent) && parentAccount.equals(loginParentName) && loginLevel - 1 == Integer.valueOf(parentLevel)) {
                selfSettings(holder, model);
                return;
            }

            // parentAccount是当前登录者，且parentLevel是当前登录者level，则查询当前登录者的直属用户
            if (parentAccount.equals(model.getAgentName()) && loginLevel.equals(Integer.valueOf(parentLevel))) {
                directSettings(holder, model, List.of(model.getAgentName()));
                return;
            }
        }

        if (StringUtils.isBlank(parentAccount) && StringUtils.isNotBlank(parentLevel)) {
            if (isBelowOneLevelAgent(agent) && loginLevel - 1 == Integer.valueOf(parentLevel)) {
                selfSettings(holder, model);
                return;
            }

            if (loginLevel.equals(Integer.valueOf(parentLevel))) {
                directSettings(holder, model, List.of(model.getAgentName()));
                return;
            }
        }

        if (StringUtils.isNotBlank(parentAccount) && StringUtils.isBlank(parentLevel)) {
            if (BaseConstants.C66_ADMIN.equals(parentAccount) && isOneLevelAgent(agent)) {
                selfSettings(holder, model);
                return;
            }

            if (isBelowOneLevelAgent(agent) && parentAccount.equals(loginParentName)) {
                selfSettings(holder, model);
                return;
            }
            if (parentAccount.equals(model.getAgentName())) {
                directSettings(holder, model, List.of(model.getAgentName()));
                return;
            }
        }

        // 设置命中逻辑中所需要的目标代理集合为根据parentLevel或者parentAccount查询出的代理集合
        List<String> targetAgents = usersSupplier.supplyTargetAgents(parentLevel, parentAccount, model.getAgentName());
        if (CollectionUtils.isEmpty(targetAgents)) {
            log.info("targetAgents is empty,stop to search");
            model.setKilled(Boolean.TRUE);
            return;
        }

        directSettings(holder, model, targetAgents);
        log.info("begin to search by parentAccount {} or parentLevel {}", parentAccount, parentLevel);

    }

    private void handleCurrentThings(PlayerMapperHolder holder, PlayerOperatorModel model) {
        // 设置命中逻辑中所需要的目标代理为当前登录用户
        model.setTargetAgents(List.of(model.getAgentName()));
        model.setQueryType(Constants.TEAM_COUNT);
        holder.setTargetUsersMapper(usersSupplier::supplyLowerAllUsersWithSelf);
        log.info("begin to search by currentUser {}", model.getAgentName());
    }

    private void selfSettings(PlayerMapperHolder holder, PlayerOperatorModel model) {
        // 目标代理为当前登录者
        model.setQueryType(Constants.SELF_COUNT);
        model.setTargetAgents(List.of(model.getAgentName()));
        holder.setTargetUsersMapper(TAgentCountGroup::getTargetAgents);
    }


    private void directSettings(PlayerMapperHolder holder, PlayerOperatorModel model, List<String> targetAgents) {
        model.setQueryType(Constants.DIRECT_COUNT);
        model.setTargetAgents(targetAgents);
        holder.setTargetUsersMapper(usersSupplier::supplyLowerDirectUsers);
    }

    /**
     * 判断目标代理是否是一级代理的属下代理
     *
     * @param targetAgent
     * @return
     */
    private boolean isBelowOneLevelAgent(TAgentCustomers targetAgent) {
        Assert.notNull(targetAgent, "targetAgent cannot be null");
        Integer agentLevel = targetAgent.getAgentLevel();
        Assert.notNull(agentLevel, "agentLevel cannot be null");
        return targetAgent.getAgentLevel() > Integer.valueOf(Constants.ONE);
    }

    /**
     * 判断目标代理是否是一级代理
     *
     * @param targetAgent
     * @return
     */
    private boolean isOneLevelAgent(TAgentCustomers targetAgent) {
        Assert.notNull(targetAgent, "targetAgent cannot be null");
        Integer agentLevel = targetAgent.getAgentLevel();
        Assert.notNull(agentLevel, "agentLevel cannot be null");
        return Integer.valueOf(Constants.ONE).equals(targetAgent.getAgentLevel());
    }

}
