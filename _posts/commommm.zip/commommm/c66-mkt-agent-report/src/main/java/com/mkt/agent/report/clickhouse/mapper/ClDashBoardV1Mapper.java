package com.mkt.agent.report.clickhouse.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonth;
import com.mkt.agent.common.entity.api.reportapi.requests.PlayerReportByGameRequest;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportByGameResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.player.model.TAgentCountGroup;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @Description TODO
 * @Classname DashBoardMapper
 * @Date 2023/11/22 14:42
 * @Created by TJSLucian
 */
@Mapper
public interface ClDashBoardV1Mapper extends BaseMapper<DashBoardHistoryEntity> {

    List<PlayerReportResponse> queryPlayerReportByDay(@Param("queryReq") TAgentCountGroup queryReq);

    List<PlayerReportResponse> queryPlayerReportByMonth(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    List<PlayerReportByGameResponse> queryPlayerReportGameDetail(PlayerReportByGameRequest req);

    /**
     * 查询t_daily_mkt_agent_all表最大最小日期
     *
     * @return
     */
    Map<String, Object> queryAgentDateRange();

    List<TAgentCountGroup> getTransCountByAgents(@Param("queryReq") TAgentCountGroup queryReq);

    List<TAgentCountGroupMonth> getDirectCountByMonth(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

    List<TAgentCountGroupMonth> getSelfCountByMonth(@Param("queryReq") ClDashBoardCreateQueryReq queryReq);

}
