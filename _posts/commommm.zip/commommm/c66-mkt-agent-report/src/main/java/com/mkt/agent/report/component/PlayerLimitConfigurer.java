package com.mkt.agent.report.component;

import com.mkt.agent.common.config.PlayerReportConfig;
import com.mkt.agent.common.limit.PriorityLimitConfigurer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @description: 额外的限流配置器
 * @author: ErHu.Zhao
 * @create: 2024-01-15
 **/
@Component
@Slf4j
public class PlayerLimitConfigurer implements PriorityLimitConfigurer {

    private final PlayerReportConfig playerReportConfig;

    public PlayerLimitConfigurer(PlayerReportConfig playerReportConfig) {
        this.playerReportConfig = playerReportConfig;
    }

    @Override
    public boolean forceLimit() {
        return playerReportConfig.getForceLimit();
    }

    @Override
    public String limitKeyConfigurer(Object target) {
        return null;
    }

    @Override
    public Long limitPeriodConfigurer(Object target) {
        return playerReportConfig.getLimitPeriod();
    }

    @Override
    public Long limitCountConfigurer(Object target) {
        return playerReportConfig.getLimitCount();
    }
}
