package com.mkt.agent.report.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mkt.agent.common.annotation.Convert2NullIfInvalidMethod;
import com.mkt.agent.common.annotation.Validate;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.api.reportapi.requests.PlayerReportByGameRequest;
import com.mkt.agent.common.entity.api.reportapi.requests.PlayerReportRequest;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportByGameResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse;
import com.mkt.agent.common.entity.api.reportapi.responses.base.ReportPageResponse;
import com.mkt.agent.common.enums.DashboardChosenTimeEnum;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.report.component.AsyncPlayer;
import com.mkt.agent.report.service.PlayerReportService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/player-report")
@Api(tags = "player-report API")
@Slf4j
@RefreshScope
public class PlayerReportController {

    @Resource(name = "playerReportServiceImpl")
    private PlayerReportService reportService;

    @Autowired
    private AsyncPlayer asyncPlayer;

    /**
     * PlayerReport 列表数据获取--
     * @param req
     * @return
     */
    @PostMapping("/queryByPageAndCondition")
    @ApiOperation("player report realtime data by page")
    @Convert2NullIfInvalidMethod
    public Page<PlayerReportResponse> queryByPageAndCondition(@RequestBody @Validated PlayerReportRequest req) {
        log.info("player report param :{}", req.toString());

        if(Objects.isNull(req.getLoginName())){
            throw new BusinessException(ResultEnum.SYSTEM_BUSY);
        }

        // asyncPlayer.asyncUpdate(req);
        Page<PlayerReportResponse> playerReportResponsePage = null;
        log.info("report start");
        IPage<PlayerReportResponse> page = new Page<>(req.getPageNum(), req.getPageSize());
        if(req.getDataDate().equals(DashboardChosenTimeEnum.ChosenType_Month.getName())){
            //月
            // return reportService.queryByPageNConditionForMonth(req);
            playerReportResponsePage = reportService.queryByMonthPage(req);
        }else {
            //日
            // reportPageResponse = reportService.queryByPageAndConditionByDay(req);
            playerReportResponsePage = reportService.queryByPageAndConditionByDayNico(req,page);
        }
        log.info("report end :{}", playerReportResponsePage.getRecords());
        return playerReportResponsePage;

    }

    /**
     * 用户点击 Turnover/GGR/Win\Loss 查看 DataDetail 详情数据
     * @param req
     * @return
     */
    @PostMapping("/getGameReport")
    @ApiOperation("get game report")
    @Validate
    public PlayerReportByGameResponse getGameReport(@RequestBody PlayerReportByGameRequest req) {
        log.info("player report param :{}", req.toString());
        return reportService.getGameReport(req);
    }

    /**
     * PlayerReport 数据导出
     * @param req
     * @return
     */
    @PostMapping("/export")
    @ApiOperation("export player report")
    public List<PlayerReportResponse> export(@RequestBody PlayerReportRequest req) {
        log.info("player report export param :{}", req.toString());
        req.setIsPage(false);
        req.setParentLevel(BaseConstants.PARENT_LEVEL_ALL.equals(req.getParentLevel()) ? null : req.getParentLevel());
        req.setPageSize(BaseConstants.PLAYER_REPORT_MAX_PAGECOUNT);
        req.setPageNum(1);
        List<PlayerReportResponse> result = new ArrayList<>();
        if(DashboardChosenTimeEnum.ChosenType_Month.getName().equals(req.getDataDate())){
            //月
            result = reportService.queryAndExportByMonth(req);
        }else {
            //日
            result = reportService.queryAndExportByDay(req);
        }
        log.info("player report export result :{}", result);
        return result;
    }


}
