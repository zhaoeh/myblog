package com.mkt.agent.report.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.report.req.TeamReportHistory;
import com.mkt.agent.report.req.TeamReportHistoryType;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface TeamReportHistoryTypeMapper extends BaseMapper<TeamReportHistoryType>  {
    List<TeamReportHistoryType> listParame(Map<String, String> parame);

    void delete2(Map<String, String> delParame);

    List<TeamReportHistoryType> listParame2(Map<String, String> parame);
}
