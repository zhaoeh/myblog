package com.mkt.agent.report.fegin;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.TAgentUpdateLog;
import com.mkt.agent.common.entity.api.userapi.requests.AgentListRequest;
import com.mkt.agent.common.entity.clickhouse.req.DashBoardUserTreeQueryReq;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * @interfaceName: AgentApiClient
 * @Description:
 * @Author: Austin
 * @Date: 2023/5/30
 */
//@FeignClient(name = "${feign.mkt-agent-api}", url = "127.0.0.1:18082")
@FeignClient(name = "${feign.mkt-agent-api}")
public interface AgentApiClient {

    @PostMapping(value = "/agentCustomers/list")
    Result<List<TAgentCustomers>> getAgentList(AgentListRequest request);

    @GetMapping(value ="/agentCustomers/one/byName")
    Result<TAgentCustomers> getAgentByLoginName(@RequestParam("loginName")String loginName);

    @GetMapping(value ="/agentCustomers/list/byNameNLevel")
    Result<List<String>> getAgentNameListByNameNLevel(@RequestParam("parent") String parent, @RequestParam("parentAccount") String parentAccount, @RequestParam("agentAccount") String agentAccount, @RequestParam("level") Integer level);

    @GetMapping(value ="/agentCustomers/team/byNameNLevel")
    Result<List<TAgentCustomers>> getTeamAgentListByNameNLevel(@RequestParam("parent") String parent,@RequestParam("parentAccount") String parentAccount, @RequestParam("agentAccount") String agentAccount, @RequestParam("level") Integer level);

    @GetMapping(value = "/agentCustomers/selectParentAgentByNameAndLevel")
    Result<TAgentCustomers> selectParentAgentByNameAndLevel(@RequestParam("parentLoginName") String parentLoginName, @RequestParam("parentLevel") String parentLevel);

    @GetMapping(value = "/agentCustomers/selectParentAgentByNameAndLevelEnable")
    Result<TAgentCustomers> selectParentAgentByNameAndLevelEnable(@RequestParam("parentLoginName") String parentLoginName, @RequestParam("parentLevel") String parentLevel);

    @PostMapping("/agentCustomers/selectDirectAgentNamesByParentList")
    Result<List<String>> selectDirectAgentNamesByParentList(@RequestBody DashBoardUserTreeQueryReq queryEntity);

}
