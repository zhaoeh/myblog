package com.mkt.agent.report.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mkt.agent.report.req.TUserFinanceOrderTreed;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface TUserFinanceOrderTreedMapper extends BaseMapper<TUserFinanceOrderTreed> {


    List<TUserFinanceOrderTreed> findList(Map<String, Object> parame);

    List<TUserFinanceOrderTreed> findListByDay(Map<String, Object> parame);

    List<TUserFinanceOrderTreed> findListByGameType(Map<String, String> parame);
}
