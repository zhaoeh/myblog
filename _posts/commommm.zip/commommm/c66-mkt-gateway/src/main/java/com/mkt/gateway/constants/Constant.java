package com.mkt.gateway.constants;

public class Constant {
    public static final String applyTokenUrl = "/v1/authorizations/applyToken.htm";
    public static final String cancelTokenUrl = "/v1/authorizations/cancelToken.htm";
    public static final String getUserInfoUrl = "/v1/customers/user/inquiryUserInfoByAccessToken.htm";
    public static final String suffix = ".htm";
    public static final String GLIFE_SIGN = "GLIFE";
    public static final String LAZADA_SIGN = "LAZADA";
    public static final String GPO_SIGN = "GPO";
    public static final String result = "result";
    public static final String resultStatus = "resultStatus";
    public static final String S = "S";
    public static final String userInfo = "userInfo";
    public static final String extendInfo = "extendInfo";
    public static final String GCASH_NUMBER = "GCASH_NUMBER";
    public static final String DATE_OF_BIRTH = "DATE_OF_BIRTH";
    public static final String FIRST_NAME = "FIRST_NAME";
    public static final String LAST_NAME = "LAST_NAME";
    public static final String EMAIL_ADDRESS = "EMAIL_ADDRESS";

    public static final String DES_KEY_SURFIX = "_DES_KEY_SURFIX";

    public static final String AUTHORIZATION_CODE = "AUTHORIZATION_CODE";
    public static final String REFRESH_TOKEN = "REFRESH_TOKEN";
    public static final String _LOGIN_SIMPLE_CACHE = "_LOGIN_SIMPLE_CACHE";
    public static final String USER_IN_GAME_OPT_LOCK_KEY = "_USER_IN_GAME_OPT_LOCK_KEY";
    public static final String USER_CREDIT_OPT_LOCK_KEY = "_CREDIT_UPDATE_REQUEST_LOCK";
    public static final String USER_WITHDRAWAL_OPT_LOCK_KEY = "_WITHDRAW_REQUEST_LOCK";
    public static final String USER_LOCAL_BALANCE_CACHE = "_USER_LOCAL_BALANCE_CACHE";
    public static final String USER_TRANS_ALL_TO_LOCAL_LOCK_KEY = "_USER_TRANS_ALL_TO_LOCAL_KEY";
    public static final String USER_GAME_BALANCE_CACHE_KEY = "_USER_GAME_BALANCE_CACHE_KEY";
    public static final String USER_GAME_BALANCE_MQ_SEND_LIMIT_KEY = "_USER_GAME_BALANCE_MQ_SEND_LIMIT_KEY";
    public static final String BALANCE_REFRESH_QUEUE_NAME = ".gi.customer.refresh.balance";
    public static final String BALANCE_REFRESH_LAST_GAME_QUEUE_NAME = ".gi.customer.last.game.balance";



    public static final String SignatureHeaderKey = "Signature";
    public static final String clientId = "2022040512530200023793";
    public static final String FORMAT_yyyy_MM_dd_T_HHmmss_08_00 = "yyyy-MM-dd'T'HH:mm:ss'+08:00'";
    public static final String algorithm = "RSA256";
    public static final String keyVersion = "0";
    public static final String testCode = "gw_test*1";
    public static final String glifeDomainName = "glife.bingoplus.com";
    public static final String glifeAgent = "1003022226";
    public static final String gpoAgent = "1003817941";
    public static final String accessTokenParam = "accessToken";
    public static final String GpoRegisterType = "4";
    public static final String GlifeRegisterType = "3";
    public static final String REAL_ACCOUNT_TYPE = "1";
    public static final String AGENT_ACCOUNT_TYPE = "3";
    public static final String playerType = "player";
    public static final String agentType = "agent";
    public static final String update_account_type = "1";

}
