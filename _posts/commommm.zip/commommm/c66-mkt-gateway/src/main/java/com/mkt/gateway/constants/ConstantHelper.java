package com.mkt.gateway.constants;

import org.springframework.stereotype.Component;

@Component
public class ConstantHelper {

    public static final String CUSTTYPE_NORMAL = "Normal";
    public static final String CUSTTYPE_PREVIP = "PreVIP";
    public static final String CUSTTYPE_VIP = "VIP";
    public static final String SYSTEM_ACCOUNT = "C66Admin";
    public static final String ZERO = "0";
    public static final String ONE = "1";
    public static final String TWO = "2";
    public static final String THREE = "3";
    public static final String FOUR = "4";
    // 注册短信验证码redis key
    public final static String REGISTER_SMS_CODE = "REGISTER_SMS_CODE:";


    final static int FLAG_DEL = 0;

}
