package com.mkt.gateway.constants;

import com.mkt.gateway.enums.Module;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.*;
import java.util.stream.Collectors;

public class ConstantVars {
    private static final Logger logger = LoggerFactory.getLogger(ConstantVars.class);
    public static final String APP_NAME = "大圣APP";

    public static final String TRUE = "true";
    public static final String FALSE = "false";

    public static final String ZERO = "0";
    public static final String ONE = "1";
    public static final String TWO = "2";
    public static final String THREE = "3";
    public static final String FOUR = "4";
    public static final String FIVE = "5";
    public static final String SIX = "6";
    public static final String SEVEN = "7";
    public static final String EIGHT = "8";
    public static final String NINE = "9";
    public static final String TEN = "10";
    public static final String ELEVEN = "11";
    public static final String TWELVE = "12";
    public static final String THIRTEEN = "13";
    public static final String FOURTEEN = "14";

    public static final Integer TIME_SECONDS = 60;

    public static final String SMS_PROVIDER_S87 = "S87";
    public static final String SMS_PROVIDER_S88 = "S88";
    public static final String SMS_PROVIDER_S89 = "S89";
    public static final String TIME_SUFFIX = " 00:00:00";
    public static final String TIME_PREFIX = " 23:59:59";

    // 优惠活动flag
    public static final String PRE_PROMOTION_BET_FLAG = "2";
    public static final String PRE_PROMOTION_BET_RTG_FLAG = "77";
    public static final String PRE_PROMOTION_DEPOSIT_FLAG = "1";

    /**
     * redis 集群接入规范http://confluence.pai9.net:8090/pages/viewpage.action?pageId=10093485#Redis%E9%9B%86%E7%BE%A4%E7%94%A8%E9%80%94%E6%94%B6%E9%9B%86-%E4%BA%8C%E3%80%81Rediskey%E4%BF%9D%E7%95%99%E6%97%B6%E9%97%B4
     */
    public static final String CACHE_KEY = Module.NEPTUNE_WEB.getCacheKey();

    public static final String CODE_PREFIX_GW = "GW_";
    public static final String CODE_PREFIX_WS = "WS_";
    public static final String CODE_PREFIX_GI = "GI_";
    public static final String CODE_PREFIX_WALLET ="NW_";
    public static final String CODE_PREFIX_PI = "PI_"; //优惠系统
    public static final String CODE_PREFIX_PAY = "PAY_"; //支付系统
    public static final String CODE_PREFIX_WMS = "WMS_"; //支付系统

    //IP限制
    public static final String USER_AVATAR_PATH = "USER_AVATAR_PATH";
    public static final String REQUEST_AVATAR_URL = "REQUEST_AVATAR_URL";
    public static final String AVATAR_USER_PASS = "AVATAR_USER_PASS";
    public static final String MARGIN_LIMIT_IP = "MARGIN_LIMIT_IP";
    public static final String MARGIN_SWITCH = "MARGIN_SWITCH";
    public static final String SILENT_PHOTO_SWITCH = "SILENT_PHOTO_SWITCH";
    public static final String SWITCH_REGISTER = "SWITCH_REGISTER";
    public static final String CONSTANT_SWITCH = "switch";
    public static final String ROOM_SWITCH = "ROOM_SWITCH";
    public static final String GAME_ONLINE_USERS = "gameOnlineUsers";
    public static final String GAME_ONLINE_USERS_V2 = "gameOnlineUsersV2";
    public static final String BINGO_RANK_CONFIG = "BINGO_RANK_CONFIG";
    public static final String COMPLETE_REGIST_SWITCH = "COMPLETE_REGIST_SWITCH";
    public static final String NEWS_JSON = "NEWS_JSON";
    public static final String NEWS_ARENAPLUS_JSON = "NEWS_ARENAPLUS_JSON";
    public static final String PROMO_JSON = "PROMO_JSON";
    public static final String PROMOMAIN_JSON = "PROMOMAIN_JSON";
    public static final String PROMO_INTEGRAL_JSON = "PROMO_INTEGRAL_JSON";
    public static final String PROMO_ARENAPLUS_JSON = "PROMO_ARENAPLUS_JSON";
    public static final String BANNER_JSON = "BANNER_JSON";
    public static final String GAME_JSON = "GAME_JSON";
    public static final String switchRegister = "COMPLETE_REGIST_SWITCH";

    //  门店内容系统
    public static final String STORE_WEBSITE_GAME_JSON = "STORE_WEBSITE_GAME_JSON";
    public static final String STORE_WEBSITE_BLOG_JSON = "STORE_WEBSITE_BLOG_JSON";
    public static final String STORE_WEBSITE_BRANCH_JSON = "STORE_WEBSITE_BRANCH_JSON";
    public static final String STORE_WEBSITE_EVENT_JSON = "STORE_WEBSITE_EVENT_JSON";
    public static final String STORE_WEBSITE_WINNER_JSON = "STORE_WEBSITE_WINNER_JSON";
    public static final String STORE_WEBSITE_TERMINUS = "STORE_WEBSITE_TERMINUS";
    public static final String  HEAD_IMAGE = "HEAD_IMAGE";
    public static final String  PHONE_BIND_SWITCH = "PHONE_BIND_SWITCH";
    public static final String IS_ROOM_MODE = "isRoomMode";
    public static final String DELIMITER_COLON = ":";
    public static final String TRY_OUT = "true";

    public static final String METHOD_UNIQUE_SIGN_BANNERV1 = "bannerV1";
    public static final String METHOD_UNIQUE_SIGN_PROMOTIONLISTV2 = "promotionListV2";
    public static final String COUNT_GAME_ONLINE_USERS = "COUNT_GAME_ONLINE_USERS";
    public static final String URI_PROMOTION = "promotion";
    public static final String URI_APPLY = "apply";
    public static final String LOGGER_SWITCH = "LOGGER_SWITCH";
    public static final String FRONT_DEPOSIT_LIST_TYPE_800 = "new player Voucher";
    public static final String FRONT_DEPOSIT_LIST_TYPE_801 = "top up Voucher";
    public static final String getAdvicePromotionKey(String loginName,String appId){

        return loginName+appId+ URI_PROMOTION+URI_APPLY;
    }
    public static final String AUTHORIZATION = "Authorization";

    /** yyyy-MM-dd HH:mm:ss */
    public static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    /** M/d/yyyy h:mm:ss a */
    public static final DateTimeFormatter DATE_TIME_FORMATTER2 = new DateTimeFormatterBuilder().appendPattern("M/d/yyyy h:mm:ss a").parseCaseInsensitive().toFormatter(Locale.US);
    /** yyyy-MM-dd */
    public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    // 分号
    public static final String SEMICOLON = ";";
    // 分号
    public static final String COMMA = ",";
    // hash
    public static final String IDENTIFIER = "#";

    //后台用户请求标识
    public static final String REQUEST_INFO_FLAG = "0";

    public static final String PAY_KEY = "88zh04yi16long";

    //校验客户敏感信息
    /*1 电话号码检测、2 真实姓名检测、3  微信账号检测、4 faceBook账号检测 、5 邮件检测、
      6 银行卡检测、7 绑定的电话检测、8 绑定的邮箱检测 、9 匹配密码 、10 存款人匹配*/
    public static final int WS_CODE_PH = 1;
    public static final int WS_CODE_RN = 2;
    public static final int WS_CODE_WX = 3;
    public static final int WS_CODE_FB = 4;
    public static final int WS_CODE_EM = 5;
    public static final int WS_CODE_BC = 6;
    public static final int WS_CODE_BPH = 7;
    public static final int WS_CODE_BEM = 8;
    public static final int WS_CODE_PWD = 9;
    public static final int WS_CODE_DES = 10;
    public static final int PAGE_SIZE = 100;

    // 快速注册
    public static final String FAST_REG_PARENT_PREFIX="b";

    // 前端deposit list type and status
    public static final String FRONT_DEPOSIT_LIST_TYPE_99 = "Cash at Branch";
    public static final String FRONT_DEPOSIT_LIST_TYPE_98 = "Gcash at Branch";
    public static final String FRONT_DEPOSIT_LIST_TYPE_97 = "Adjustment";
    public static final String FRONT_DEPOSIT_LIST_TYPE_0 = "Online Banking";
    public static final String FRONT_DEPOSIT_LIST_TYPE_2 = "Gcash QR Code";

    // Waiting Approved Denied Processing
    public static final String FRONT_DEPOSIT_LIST_STATUS_0 = "Waiting";
    public static final String FRONT_DEPOSIT_LIST_STATUS_01 = "Pending";//线上存款
    public static final String FRONT_DEPOSIT_LIST_STATUS_02 = "Reviewing";//门店存款调账
    public static final String FRONT_DEPOSIT_LIST_STATUS_1 = "Processing";
    public static final String FRONT_DEPOSIT_LIST_STATUS_2 = "Approved";
    public static final String FRONT_DEPOSIT_LIST_STATUS_3 = "Denied";//-3
    public static final String FRONT_DEPOSIT_LIST_STATUS_4 = "cancel";//-1


    public static final String SLOT_STATUS = "SLOT_STATUS";
    public static final String BINGO_STATUS = "BINGO_STATUS";
    public static final String EBINGO_STATUS = "EBINGO_STATUS";
    public static final String LIVE_DEALER_STATUS = "LIVE_DEALER_STATUS";
    public static final String LIVE_SPORTS_STATUS = "LIVE_SPORTS_STATUS";
    public static final String VIRTUAL_SPORTS_STATUS = "VIRTUAL_SPORTS_STATUS";


    public static final String DEPOSIT_TYPE_GCASH = "Gcash qr ";
    public static final String DEPOSIT_TYPE_BRANCH = "Branch ";
    public static final String DEPOSIT_TYPE_BANK = "Bank account ";
    public static final String DEPOSIT_TYPE_EPAY = "Epayment";
    public static final String DEPOSIT_TYPE_GCASHPAY = "Gcash Pay";
    public static final String DEPOSIT_TYPE_PAYNAMICS = "Paynamics";
    public static final String DEPOSIT_TYPE_VOUCHER = "Voucher";


    // export data info
    public static final String EXPORT_DATA_TEMPPACKAGE = "tempPackage/";
    public static final String PXOFFICE_EXPORT_DATA_INFO_REDIS = "rds:pxoffice_export_data_info_key";
    public static final String EXPORT_DATA_INFO_NORMALLOCK_REDIS = "rds:export_data_info_normallock_key";
    public static final String EXPORT_DATA_INFO_EXITSWITCH_REDIS = "rds:export_data_info_exitswitch_key";

    public static final String EXPORT_DATA_INFO_RUNING_REDIS = "rds:EXPORT_DATA_INFO_RUNING_KEY";


    public static final String CATA_LOG_TYPE_97 = "97";

    public static final String CHECK_AMOUNT = "1000.00";


    /**
     * sendSmsType
     * 60001  注册
     * 60012  登陆
     * 60022 激活
     * 60008 存款
     * 60023 校验用户密码
     * 60004 修改密码
     * 60018 修改取款密码
     * 60021 绑定谷歌验证器
     * 60022 手机号快速注册成功,给用户发送短信
     */
    public static final String LOGIN_CREATE_SMS_TYPE = "60012";
    public static final String REGISTER_CREATE_SMS_TYPE = "60001";
    public static final String ACTIVATION_CREATE_SMS_TYPE = "60022";
    public static final String DEPOSIT_SMS_TYPE = "60008";
    public static final String VERIFY_PASSWORD_SMS_TYPE = "60004";
    public static final String UPDATE_PASSWORD_SMS_TYPE = "60004";
    public static final String UPDATE_WITHDRAWAL_PASS_SMS_TYPE = "60018";
    public static final String MODIFY_CUSTOMER_INFO_SMS_TYPE = "60019";
    /**KYC审核成功短信类型**/
    public static final String CUSTOMER_KYC_SUCCESS_SMS_TYPE = "600191";
    /**KYC审核失败短信类型**/
    public static final String CUSTOMER_KYC_FAIL_SMS_TYPE = "600192";
    public static final String AVAILABLE_BONUS_AMOUNT_TRANSFER_TYPE = "60026";
    public static final String DISCOUNT_RED_ENVELOPES = "60020";
    public static final String BIND_GOOGLE_AUTH_SMS_TYPE = "60029";
    public static final String QUICK_REGISTER_BY_PHONE_TYPE = "60094";
    public static final String JACKPOT_WIN_CUSTOMER_TYPE = "60095";
    public static final String JACKPOT_WIN_TYPE = "60096";
    public static final String JACKPOT_BINGO_WINNERS = "60101";
    /** 银行账号 */
    public static final String BANK_ACCOUNT_TYPE = "60016";
    /** 取款 */
    public static final String WITHDRAWAL_TYPE = "60009";
    public static final String WITHDRAWAL_FAILED_TYPE = "60030";
    public static final String ADD_BANK_CARD_TYPE = "60016";
    public static final String DEL_BANK_CARD_TYPE = "60015";
    public static final String EDIT_BANK_CARD_TYPE = "60024";
    public static final String SET_CUSTOMER_INFO_SMS_TYPE = "60080";

    // 活动优惠大类
    public static final String TDDH_ACTIVITY_CODE = "TDDH";
    public static final String XSSCYH_ACTIVITY_CODE = "XSSCYH";
    public static final String MATRIX_ACTIVITY_CODE = "MATRIX";
    // RTG投注活动类型
    public static final String PROMOTION_TYPE_RTGBET = "RTGBET";

    public static final String TDDH_GANG_PROMOTION_CONFIG = "TDDH_GANG";// 团队红利优惠
    public static final String TDDH_INDIVIDUAL_PROMOTION_CONFIG = "TDDH_INDIVIDUAL"; // 个人红利优惠

    public static final String FRONT_PUBLIC_CONFIG = "FRONT_PUBLIC_CONFIG"; // 提供给前端配置信息key
    public static final String FRONT_QUERY_CUST_BILL_FLAG = "FRONT_QUERY_CUST_BILL_FLAG"; // 交易记录走新接口标识

    // appid keyword
    public static final String AGENT = "AGENT";

    public static final String VERIFY_EMAIL_ENDPOINT = "VERIFY_EMAIL_ENDPOINT";
    public static final String VERIFY_EMAIL_CONFIG = "VERIFY_EMAIL_CONFIG";

    public static final String ACCOUNT_TEMP_TOKEN = "ACCOUNT-TEMP-TOKEN";
    // 反洗钱发送邮件配置
    public static final String ANTI_MONEY_LAUNDERING_EMAIL_CONFIG = "ANTI_MONEY_LAUNDERING_EMAIL_CONFIG";
    public static final String ANTI_MONEY_LAUNDERING_CONFIG = "ANTI_MONEY_LAUNDERING_CONFIG";
    public static final String ANTI_MONEY_LAUNDERING_AMOUNT_EXCEEDED = "ANTI_MONEY_LAUNDERING_AMOUNT_EXCEEDED";

    // GOOGLE人机校验配置
    public static final String GOOGLE_RECAPTCHER_SECRET_KEY = "GOOGLE_RECAPTCHER_SECRET_KEY";
    public static final String GOOGLE_RECAPTCHER_SITEVERIFY_URL = "GOOGLE_RECAPTCHER_SITEVERIFY_URL";
    public static final String GOOGLE_RECAPTCHER_FLAG = "GOOGLE_RECAPTCHER_FLAG";

    // 跑马灯金额阈值
    public static final String HOME_MARQUEE_CONFIG = "HOME_MARQUEE_CONFIG";
    // ip时间限制常量key
    public static final String IP_TIME_LIMIT = "IP_TIME_LIMIT";

    // 第三方登录KEY
    public static final String THIRD_PARTY_LOGIN = "THIRD_PARTY_LOGIN";
    public static final String BINGO_DOMAIN_VAL = "BINGO_DOMAIN_VAL";

    // 邮箱模板KEY
    public static final String EMAIL_REGISTER_TEMPLATE_BINGOPLUS = "EMAIL_REGISTER_TEMPLATE_BINGOPLUS";
    public static final String EMAIL_REGISTER_TEMPLATE_ARENAPLUS = "EMAIL_REGISTER_TEMPLATE_ARENAPLUS";
    public static final String EMAIL_VERIFICATION_CODE_TEMPLATE_BINGOPLUS = "EMAIL_VERIFICATION_CODE_TEMPLATE_BINGOPLUS";
    public static final String EMAIL_VERIFICATION_CODE_TEMPLATE_ARENAPLUS = "EMAIL_VERIFICATION_CODE_TEMPLATE_ARENAPLUS";
    public static final String EMAIL_PRE_REGISTER_TEMPLATE_ARENAPLUS = "EMAIL_PRE_REGISTER_TEMPLATE_ARENAPLUS";
    public static final String EMAIL_REGISTER = "20001";
    public static final String EMAIL_LOGIN = "20012";

    // 动态表单--存取款跑马灯bizCode
    public static final String DEPOSIT_WITHDRAWAL_BIZCODE = "deposit_withdrawal";

    public static final String INGAME_FREQUENT_ACCESS = "RDS:INGAME_FREQUENT_ACCESS_KEY";
    public static final String TRANS_OUT_GAME_FREQUENT_ACCESS = "RDS:TRANS_OUT_GAME_FREQUENT_ACCESS";
    public static final String TRANS_OUT_GAME_FREQUENT_ACCESS_TIME_LIMIT = "RDS:TRANS_OUT_GAME_FREQUENT_ACCESS_TIME_LIMIT";
    public static final String TOKEN_EXPIRE_MAXIMUM = "TOKEN_EXPIRE_MAXIMUM";

    public static final String LOGIN_ERROR_COUNT="LOGIN_ERROR_COUNT";
    public static final String LAST_LOGIN_DATETIME="LAST_LOGIN_DATETIME";
    public static final String SPORTS_DOMAIN_NAME="SPORTS_DOMAIN_NAME";
    public static final String BINGOPLUS_DOMAIN_NAME="BINGOPLUS_DOMAIN_NAME";
    public static final String GLI_DOMAIN_NAME="GLI_DOMAIN_NAME";

    //体育赛事
    public static final String HOT_MATCH="HOT_MATCH";
    public static final String SPORT_TYPE_CONTENT="SPORT_TYPE_CONTENT";
    public static final String NEW_SPORT_CONTENT="NEW_SPORT_CONTENT";
    public static final String SPORT_VIDEO_USE="SPORT_VIDEO_USE";
    public static final String NEW_UPDATE_SPORT_CONTENT="NEW_UPDATE_SPORT_CONTENT";
    public static final String NEW_OTHER_SPORT_CONTENT="NEW_OTHER_SPORT_CONTENT";

    //体育项目类型
    public static final String DAWN_FOOTBALL="101";
    public static final String DAWN_BASKETBALL="102";
    public static final String DAWN_AMERICA_FOOTBALL="105";
    public static final String DAWN_ICE_HOCKET="106";
    public static final String DAWN_TENNIS="107";
    public static final String DAWN_VOLLEYBALL="108";
    public static final String DAWN_ESPORT_LOL="1";
    public static final String DAWN_ESPORT_DOTA2="2";
    public static final String DAWN_ESPORT_CSGO="3";
    public static final String DAWN_ESPORT_KPL="1";

    //    BINGO-2014
    public static final String BINGO_LOTTERY_WINNER="BINGO_LOTTERY_WINNER";
    // BINGO-1584
    public static final String FB_DOMAIN_NAME="FB_DOMAIN_NAME";

    // BINGO-1775
    public static final String AVATAR_AUTO_APPROVE="AVATAR_AUTO_APPROVE";



    public enum Cache {
        // 图形验证码失效期[5分钟]
        CAPTCHA("CAPTCHA", 5 * 60),
        // token失效期[30天]
        APP_TOKEN_EXPIRE("TOKEN", 24 * 60 * 60),
        // Web Token失效期[30 天]
        WEB_TOKEN_EXPIRE("WEB_TOKEN_EXPIRE", 24 * 60 * 60),
        // 余额查询默认缓存时间[5分钟]
        QUERY_BALANCE("QUERY_BALANCE", 2 * 60),
        GET_BALANCE("GET_BALANCE", 1 * 30),
        QUERY_BALANCE_LIMIT("QUERY_BALANCE_LIMIT", 1 * 60),
        // 余额查询手动刷新缓存时间[15秒]
        QUERY_BALANCE_EX("QUERY_BALANCE_EX", 300),
        BALANCE_INGAME("BALANCE_INGAME", 300),
        //优惠金额
        PROMO_AMOUNT("PROMO_AMOUNT", 2 * 60),
        //洗码金额
        REBATE_AMOUNT("REBATE_AMOUNT", 2 * 60),
        //厅方状态[5分钟]
        GAME_STATUS("GAME_STATUS", 5 * 60),
        LOGIN_CAPTCHA("LOGIN_CAPTCHA", 5 * 60),
        //登录账号或密码错误
        LOGIN_ERROR("LOGIN_ERROR",24 * 60 * 60),
        //周有效投注额[15m]
        WEEKLY_BET_AMOUNT("WEEKLY_BET_AMOUNT", 15 * 60),
        //上周有效投注额[15m]
        LAST_WEEKLY_BET_AMOUNT("LAST_WEEKLY_BET_AMOUNT", 24*60 * 60),
        // 试玩账号缓存时间
        TRY_ACCOUNT_TIME_LIMIT("TRY_ACCOUNT_TIME_LIMIT", 24 * 60 * 60),
        // 修改密码错误[24小时]
        MODIFY_PWD_ERROR_MORE_LIMIT("PWD_ERROR_MORE_LIMIT", 24 * 60 * 60),
        // 修改PT密码错误[24小时]
        MODIFY_PT_PWD_ERROR_MORE_LIMIT("PWD_ERROR_MORE_LIMIT", 24 * 60 * 60),

        //短信验证码错误禁止验证时间[3分钟]
        SMS_ERROR_FROBID("SMS_ERROR_FROBID", 3 * 60),
        //短信验证码错误次数缓存[5分钟]
        SMS_ERROR_COUNT("SMS_ERROR_COUNT", 15 * 60),
        //短信验证码错误禁止验证时间[5分钟]
        CUS_ERROR_FROBID("CUS_ERROR_FROBID", 5 * 60),
        //短信验证码错误次数缓存[15分钟]
        CUS_ERROR_COUNT("CUS_ERROR_COUNT", 15 * 60),

        // 区间内总额[优惠][2分钟]
        SUM_AMOUNT_PROMO("SUM_AMOUNT_PROMO", 2 * 60),
        // 动态表单查询结果
        DYNAMIC_BIZ_QUERY_DATA("DYNAMIC_BIZ_QUERY_DATA", 2 * 60),
        MAIN_PAGE_DATA("MAIN_PAGE_DATA", 30 * 60),
        GET_BINGO_INFO("GET_BINGO_INFO", 2 * 60),
        GET_BRAND_NEW_INFO("GET_BRAND_NEWS_INFO", 60 * 60),
        GET_BRAND_NEW_DETAIL_INFO("GET_BRAND_NEWS_INFO", 60 * 60),
        QUERY_GAME_LIST("QUERY_GAME_LIST", 60 * 60),
        DEPOSIT_SWITCH("DEPOSIT_SWITCH", 30 * 60),
        PAY_WAY("PAY_WAY", 30 * 60),
        REWARD_COLLECTION_INFO("REWARD_COLLECTION_INFO", 1 * 60),
        GET_BY_LOGIN_NAME("GET_BY_LOGIN_NAME", 1 * 60),
        CUSTOMER("CUSTOMER", 60 * 60),
        SIMPLE_CUSTOMER("CUSTOMER", 60 * 60),
        HOME_DATA("HOME_DATA", 2 * 60),
        WORLD_CUP_DATA("WORLD_CUP_DATA", 24 * 60 * 60),

        //查询人工存款银行卡列表[USDT使用]
        QUERY_DEPOSIT_BANK_INFO("QUERY_DEPOSIT_BANK_INFO", 10* 60),

        //查询三级分销币商信息
        PAY_WAY_AGENT_CUSTOMER("PAY_WAY_AGENT_CUSTOMER", 60),
        //MG游戏奖金池列表信息
        MG_TICKER_XML_All("MG_TICKER_XML_All", 20 * 60),
        //PT游戏奖金池
        PT_GAME_TICKER("PT_GAME_TICKER", 20 * 60),

        //APP跳转H5临时凭证失效期
        APP_TO_H5_TEMP_TICKET("APP_TO_H5_TEMP_TICKET", 2 * 60),

        //默认5分钟
        LOGIN_LOCK("LOGIN_LOCK", 5 * 60),
        LOGIN_LOCK_CURRENT("LOGIN_LOCK_CURRENT", 5 * 60),



        GOODWAY_BINGO_TABLE_DETAIL("GOODWAY_BINGO_TABLE_DETAIL", 0),
        GOODWAY_BINGO_WIN_RANK("GOODWAY_BINGO_WIN_RANK", 0),
        GOODWAY_BINGO_BET_RANK("GOODWAY_BINGO_BET_RANK", 0),
        GOODWAY_BINGO_WINNER_RANK("GOODWAY_BINGO_WINNER_RANK", 0),
        GOODWAY_BINGO_JACKPOT_BINGO_LIST("GOODWAY_BINGO_JACKPOT_BINGO_LIST", 0),
        // 首页跑马灯
        MARQUEE_CASH_REDIS("MARQUEE_CASH_REDIS", 60 * 60),
        NICKNAME_CACHE("NICKNAME_CACHE", 60 * 60 * 24),
        HOME_OTHER_GAME_DATA("HOME_OTHER_GAME_DATA", 60 * 60),
        HOME_OTHER_GAME_DATA_FOREVER("HOME_OTHER_GAME_DATA_FOREVER", 60 * 60),
        MARQUEE_DATA("MARQUEE_CASH_REDIS", 20 * 60),
        MARQUEE_CASH_REDIS_FOREVER("MARQUEE_CASH_REDIS_FOREVER", 1 * 60),
        USER_BASIC_INFO_CACHE("USER_BASIC_INFO_CACHE", 2 * 60),
        LOGIN_CACHE_RETENTION("LOGIN_CACHE_RETENTION", 1 * 60),
        LOGIN_TRY_DELAY("LOGIN_TRY_DELAY", 1 * 60),
        WORLD_CUP_VIDEO("WORLD_CUP_VIDEO",10*60),
        WORLD_CUP_VIDEO_NUM("WORLD_CUP_VIDEO",24*60*60),
        WORLD_CUP_VIDEO_VERIFY("WORLD_CUP_VIDEO",24*60*60),

        //体育赛事订阅
        LOGIN_NAME_MATH_SMS("LOGIN_NAME_MATH_SMS",0),
        ;

        private String key;

        // 缓存时长[秒]
        private int duration;

        Cache(String key, int duration) {
            this.key = key;
            this.duration = duration;
        }

        /**
         * 获取redis的key
         * @param appGroup 请单纯地传appGroup，如果需要拼接其他信息，请使用{@link #getKey(String appGroup, String... keys) String}
         * @return
         */
        public String getKey(String appGroup) {
            return getProductId() + ":" + CACHE_KEY + appGroup + ":" + this.key;
        }

        /**
         * 获取redis的key
         * @param appGroup
         * @param keys 拼接的其他信息
         * @return
         */
        public String getKey(String appGroup, String... keys) {
            StringBuilder sb = new StringBuilder();
            if (Objects.nonNull(keys)) {
                for (String key : keys) {
                    sb.append("_").append(key);
                }
            }
            return getProductId() + ":" + CACHE_KEY + appGroup + ":" + this.key + sb.toString();
        }
        private String getProductId() {
            return "C66";
        }

        public int getDuration() {
            return duration;
        }

        public String getKeyByPid(String productId, String appGroup, String... keys) {
            StringBuilder sb = new StringBuilder();
            if (Objects.nonNull(keys)) {
                for (String key : keys) {
                    sb.append("_").append(key);
                }
            }
            return productId + ":" + CACHE_KEY + appGroup + ":" + this.key + sb.toString();
        }
    }

    public enum AppType {
        WEB(1, "WEB", EndpointType.PC),
        ANDROID(2, "ANDROID", EndpointType.MOB),
        IOS(3, "IOS", EndpointType.MOB),
        HTML5(4, "H5", EndpointType.MOB),
        API(5, "API", EndpointType.API);

        private int code;
        private String name;
        private EndpointType endpointType;

        private static final Map<Integer, AppType> lookup = Collections.unmodifiableMap(initialize());

        private static Map<Integer, AppType> initialize() {
            Map<Integer, AppType> map = new HashMap<>();
            for (AppType item : AppType.values()) {
                map.put(item.code, item);
            }
            return map;
        }

        AppType(int code, String name, EndpointType endpointType) {
            this.code = code;
            this.name = name;
            this.endpointType = endpointType;
        }

        public int getCode() {
            return code;
        }

        public String getName() {
            return name;
        }

        public EndpointType getEndpointType() {
            return endpointType;
        }

        public static AppType fromCode(int code) {
            return lookup.get(code);
        }
    }

    public enum EndpointType {
        PC(1, "大屏PC"),
        MOB(2, "小屏移动设备"),
        API(3, "API接入");

        private int code;
        private String name;

        private static final Map<Integer, EndpointType> lookup = Collections.unmodifiableMap(initialize());

        private static Map<Integer, EndpointType> initialize() {
            Map<Integer, EndpointType> map = new HashMap<>();
            for (EndpointType item : EndpointType.values()) {
                map.put(item.code, item);
            }
            return map;
        }

        EndpointType(int code, String name) {
            this.code = code;
            this.name = name;
        }

        public int getCode() {
            return code;
        }

        public String getName() {
            return name;
        }

        public static EndpointType fromCode(int code) {
            return lookup.get(code);
        }
    }

    public enum XmType {
        AG_ZR("XM33", "AGQJ视讯", GamePlatform.AG, GameKind.ZR),
        TT_DZ("XM527", "TTG电游", GamePlatform.TT, GameKind.DY),
        TLB_ZR("XM236", "TLB视讯", GamePlatform.TLB, GameKind.DT),
        SABA_TY("XM131", "SABA体育", GamePlatform.SABA, GameKind.TY),
        RGS_TY("XM146", "RGS体育", GamePlatform.RGS, GameKind.TY),
        PT_ZR("XM339", "PT视讯", GamePlatform.PT, GameKind.ZR),
        PT_DZ("XM539", "PT电游", GamePlatform.PT, GameKind.DY),
        OPUS_ZR("XM343", "OPUS视讯", GamePlatform.OPUS, GameKind.ZR),
        OPUS_DZ("XM543", "OPUS电游", GamePlatform.OPUS, GameKind.DY),
        NSS_TY("XM161", "NSS体育", GamePlatform.NSS, GameKind.TY),
        MG_ZR("XM335", "MG视讯", GamePlatform.MG, GameKind.ZR),
        MG_DZ("XM535", "MG电游", GamePlatform.MG, GameKind.DY),
        K8_CP("XM44", "K8彩票", GamePlatform.KENO, GameKind.CP),
        HG_ZR("XM38", "HG视讯", GamePlatform.HG, GameKind.ZR),
        BSG_DZ("XM551", "BSG电游", GamePlatform.BSG, GameKind.DY),
        BBIN_ZR("XM36", "BBIN视讯", GamePlatform.BBIN, GameKind.ZR),
        BBIN_TY("XM16", "BBIN体育", GamePlatform.BBIN, GameKind.TY),
        BBIN_DZ("XM56", "BBIN电游", GamePlatform.BBIN, GameKind.DY),
        BBIN_CP("XM46", "BBIN彩票", GamePlatform.BBIN, GameKind.CP),
        AP_Poker("XM744", "AP棋牌", GamePlatform.AP, GameKind.QP),
        AGIN_ZR("XM326", "AGIN视讯", GamePlatform.AGIN, GameKind.ZR),
        AGIN_TY("XM126", "AGIN体育", GamePlatform.AGIN, GameKind.TY),
        AGIN_DZ("XM526", "AGIN电游", GamePlatform.AGIN, GameKind.DY),
        AGIN_BY("XM826", "AGIN捕鱼", GamePlatform.AGIN, GameKind.BY),
        AS_ZR("XM364", "AS视讯", GamePlatform.AS, GameKind.ZR),
        SBT_TY("XM162", "SBT体育", GamePlatform.SBT, GameKind.TY),
        NB_TY("XM169", "NB体育", GamePlatform.NB, GameKind.TY),
        AG_TY("XM13", "AGQJ体育", GamePlatform.AG, GameKind.TY),
        //        PNG_DZ("XM552", "PNG电游", GamePlatform.PNG, GameKind.DY),
        PP_DZ("XM567","PP电游", GamePlatform.PPG, GameKind.DY),
        QG_CP("XM480", "QG彩票", GamePlatform.QG, GameKind.CP),
        NT_DZ("XM565", "NT电游", GamePlatform.NETENT, GameKind.DY),
        IM_TY("XM186", "IM体育", GamePlatform.IM, GameKind.TY),
        IM_DJ("XM990", "IM电竞", GamePlatform.IMDJ, GameKind.DJ),
        EBET_ZR("XM359", "EBET视讯", GamePlatform.EBET, GameKind.ZR),
        CS_TY("XM187","CS体育",GamePlatform.CS, GameKind.TY),
        VN_CP("XM475","VNLOTO彩票",GamePlatform.VN, GameKind.CP),
        SBO_TY("XM193","SBO体育",GamePlatform.SBO, GameKind.TY),
        PS_DY("XM594","PS电游",GamePlatform.PS, GameKind.DY),
        PS_BY("XM894","PS捕鱼",GamePlatform.PS, GameKind.BY)
        ;

        private String code;
        private String desc;
        private GamePlatform gamePlatform;
        private GameKind gameKind;

        private static final Map<String, XmType> lookup = Collections.unmodifiableMap(initialize());

        private static Map<String, XmType> initialize() {
            Map<String, XmType> map = new HashMap<>();
            for (XmType item : XmType.values()) {
                map.put(item.code, item);
            }
            return map;
        }

        XmType(String code, String desc, GamePlatform gamePlatform, GameKind gameKind) {
            this.code = code;
            this.desc = desc;
            this.gamePlatform = gamePlatform;
            this.gameKind = gameKind;
        }

        public String getCode() {
            return code;
        }

        public String getDesc() {
            return desc;
        }

        public String getPlatformName() {
            return  gamePlatform.getName();
        }

        public String getGameKindName() {
            return gameKind.getName();
        }

        public Integer getGameKind() {
            return gameKind.getCode();
        }

        public String getPlatform() {
            return gamePlatform.getCode();
        }

        public static XmType fromCode(String code) {
            return lookup.get(code);
        }
    }

    /**
     * 游戏平台
     */
    private enum GamePlatform {
        AG("003", "AG旗舰"),
        KENO("004", "K8"),
        BBIN("006", "BBIN"),
        HG("008", "HG"),
        AGIN("026", "AG国际"),
        TT("027", "TTG电游"),
        SABA("031", "SHABA"),
        SABA_V2("131", "SHABA_V2"),
        MG("035", "MG"),
        TLB("036", "TLB"),
        PT("039", "PT"),
        OPUS("043", "OPUS"),
        AP("044", "AP"),
        RGS("046", "RGS"),
        BSG("051", "BSG"),
        //        PNG("052", "PNG"),
        EBET("059", "EBET"),
        NSS("061", "NSS"),
        SBT("062", "SBT"),
        AS("064", "AS电玩城"),
        PPG("067", "PP"),
        NB("069", "NB"),
        QG("080", "QG"),
        NETENT("065", "NETENT"),
        IM("086", "IM"),
        IMDJ("090", "IMDJ"),
        CS("087","CS"),
        VN("075","VN"),
        SBO("093","SBO"),
        PS("094","PS")
        ;

        private String code;
        private String name;
        GamePlatform(String code, String name){
            this.code = code;
            this.name = name;
        }

        public String getCode() {
            return this.code;
        }

        public String getName() {
            return this.name;
        }
    }

    public enum GameKind {

        TY(1, "体育"),
        DT(2, "电投"),
        ZR(3, "真人"),
        DY(5, "电游"),
        QP(7, "棋牌"),
        BY(8, "捕鱼"),
        DJ(9, "电竞"),
        CP(12, "彩票"),
        BINGO(21, "缤果"),
        VIRTUAL(22, "虚拟体育");

        private Integer code;
        private String name;

        private static final Map<Integer, GameKind> lookup = Collections.unmodifiableMap(initialize());

        private static Map<Integer, GameKind> initialize() {
            Map<Integer, GameKind> map = new HashMap<>();
            for (GameKind item : GameKind.values()) {
                map.put(item.code, item);
            }
            return map;
        }

        GameKind(Integer code, String name) {
            this.code = code;
            this.name = name;
        }

        public Integer getCode() {
            return code;
        }

        public String getCodeAsStr() {
            return String.valueOf(code);
        }

        public String getName() {
            return name;
        }

        public static GameKind fromCode(Integer code) {
            return lookup.get(code);
        }

        public static Map<Integer, String> asMap() {
            return Arrays.stream(GameKind.values()).collect(Collectors.toMap(GameKind::getCode, GameKind::getName));
        }
    }

    public enum SubscribeType {
        DEPOSIT("存款"),
        WITHDRAW("取款"),
        PROMOTION("优惠"),
        MODIFY_PWD("修改密码"),
        MODIFY_BANKCARD("修改银行资料"),
        MODIFY_ACCOUNT_NAME("修改账号姓名"),
        NEW_WEBSITE("域名变更"),
        PROMO_ACTIVITY("优惠活动通知"),
        PAYMENT_ACCOUNT("收款账号更改"),
        MODIFY_PHONE("修改电话"),
        REGARDS("网站问候"),
        SPECIFIC("特殊短信"),
        LOGIN("登录短信"),
        NOBLE_METAL("贵金属评论"),
        FOREX("外汇评论"),
        REBATE("洗码");

        private String name;

        SubscribeType(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }
    }
    //gwType用途[1:注册; 2:登录; 3:手机绑定; 4:找回密码; 5:手机修改; 7:资料修改; 8.银行卡修改; 9:常规验证；10:密码修改；11:找回账号; 12:邮箱绑定； 13:邮箱修改；17=语音验证
    // 18=USDT账号修改
    public enum SmsCodeUse {
        REGIST(1)/*不验证登录名*/, LOGIN(2)/*不验证登录名*/, BIND_PHONE(3), FORGET_PWD(4),
        MODIFY_PHONE(5), UNBIND_PHONE(6), MODIFY_INFO(7), MODIFY_ACCOUNT(8), NORMAL(9),
        MODIFY_PWD(10), FORGET_ACCOUNT(11), BIND_EMAIL(12), MODIFY_EMAIL(13),
        VALID_VOICE(17), USDT_MODIFY(18),PHONE_LOGIN(19);

        private Integer use;

        SmsCodeUse(Integer use) {
            this.use = use;
        }

        public Integer value() {
            return use;
        }

        public static boolean in(Integer v) {
            for (SmsCodeUse smsCodeUse : SmsCodeUse.values()) {
                if (Objects.equals(v, smsCodeUse.use)) {
                    return true;
                }
            }
            return false;
        }
    }

    /**
     * 常量开关枚举
     */
    public enum Switch{
        ON("1"),OFF("0");
        private String value;
        Switch(String value){
            this.value = value;
        }
        public  String value(){return value;}
        public static boolean in(String v){
            for (Switch sw : Switch.values()){
                if(Objects.equals(v,sw.value)){
                    return true;
                }
            }
            return false;
        }
    }

    public enum OperationType {
        DEPOSIT("存款"),
        WITHDRAW("取款"),
        XM("洗码"),
        GAME("进游戏");

        private String name;

        OperationType(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }
    }

    public enum AccountType {
        CNY(1, "CNY主账户", "CNY"),
        USDT(2, "USDT账户", "USDT"),
        MBTC(3, "MBTC账户", "MBTC"),
        ETH(4, "ETH账户", "ETH");

        private Integer code;
        private String name;
        private String currency;

        private static final Map<Integer, AccountType> codeAccountTypeMap = Collections.unmodifiableMap(initializeCodeAccountTypeMap());

        private static Map<Integer, AccountType> initializeCodeAccountTypeMap() {
            Map<Integer, AccountType> map = new HashMap<>();
            for (AccountType item : AccountType.values()) {
                map.put(item.code, item);
            }
            return map;
        }
        private static final Map<String, AccountType> currencyAccountTypeMap = Collections.unmodifiableMap(initializeCurrencyAccountTypeMap());

        private static Map<String, AccountType> initializeCurrencyAccountTypeMap() {
            Map<String, AccountType> map = new HashMap<>();
            for (AccountType item : AccountType.values()) {
                map.put(item.currency, item);
            }
            return map;
        }

        AccountType(Integer code, String name, String currency) {
            this.code = code;
            this.name = name;
            this.currency = currency;
        }

        public Integer getCode() {
            return code;
        }

        public String getName() {
            return name;
        }

        public String getCurrency() {
            return currency;
        }

        public static AccountType fromCode(Integer code) {
            return codeAccountTypeMap.get(code);
        }

        public static AccountType fromCurrency(String currency) {
            return currencyAccountTypeMap.get(currency);
        }

        public static Map<Integer, String> asMap() {
            return Arrays.stream(AccountType.values()).collect(Collectors.toMap(AccountType::getCode, AccountType::getName));
        }
    }

    /**
     * 語系對照
     */
    public enum Language {
        /** 中文 */
        CN,
        /** 英文 */
        EN,
        /** 越文 */
        VI,
        /** 泰文 */
        TH
    }

    /**
     * URI's in this list will not be logged IF 'LOGGER_SWITCH' constant is set to 0.
     */
    public static final List<String> loggerSwitchURIsForHighConcurrency = Arrays.asList(
            "/appHealth",
            "/front/siteinfo",
            "/h5game/getBingoInfo",
            "/customer/getByLoginName",
            "/customer/getById",
            "/constant/query",
            "/userAuth/loginByPhone");

    public static final List<String> loggerSwitchURIsForAnalysis = Arrays.asList(
            "/applets/auth",
            "/applets/checkBind",
            "/applets/loginAndRegister",
            "/applets/gpo/auth",
            "/applets/gpo/checkBind",
            "/applets/gpo/register",
            "/game/inGameV2");



}
