package com.mkt.gateway.config;

import com.mkt.agent.common.config.ReturnValueStrategyConfiguration;
import com.mkt.agent.common.entity.Result;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * @program: c66-mkt-gateway
 * @description: c66-mkt-gateway服务controller返回对象统一包装处理配置
 * @author: Erhu.Zhao
 * @create: 2024-01-04 16:12
 */
@Component
public class GateWayReturnValueStrategyConfiguration implements ReturnValueStrategyConfiguration {

    @Override
    public boolean supportsDoThis() {
        return false;
    }

    @Override
    public Map<String, ReturnValueStrategyConfiguration.ReturnValueStrategy> replacedHandlerAndStrategy() {
        Map<String, ReturnValueStrategyConfiguration.ReturnValueStrategy> target = new HashMap<>(12);
        target.put(RequestResponseBodyMethodProcessor.class.getName(), this::handleReturnValue);
        return target;
    }

    private Object handleReturnValue(Object returnValue) {
        if (Objects.isNull(returnValue) || Result.class.isInstance(returnValue) || ResponseEntity.class.isInstance(returnValue)) {
            return returnValue;
        }
        return Result.success(returnValue);
    }
}