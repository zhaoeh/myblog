package com.mkt.gateway.constants;

public  class AgentTransCode {
        public static final String DEPOSIT_COMMISSION = "113502";
        public static final String TRANS_TO_CREDIT = "113504";
        public static final String TRANS_WITHDRAWAL = "113505";
        public static final String TRANS_TO_DOWNLINE = "113506";
        public static final String TRANS_TO_DOWNLINE_COMMISSION = "113514";
        public static final String TRANS_TO_CASHTOCOMM = "113507";
        public static final String TRANS_TO_CANCELCASHTOCOMM = "113508";
        public static final String TRANS_TO_BISHANGCREDIT = "113509";
        public static final String TRANS_TO_RETURN = "113511";
        public static final String TRANS_CAL = "112706";
        public static final String TRANS_TO_COMMISSION_MODIFY = "113512";
        public static final String TRANS_PROFESSION_COMMISSION = "112707";
        public static final String RETURN_TO_COMMISSION_MODIFY = "113513";

}