package com.mkt.gateway.controller;


import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordDashBoardRequest;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordUpdateRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordPlanResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordSingleResponse;
import com.mkt.agent.common.utils.UserContext;
import com.mkt.gateway.feign.AgentApiClient;
import com.mkt.gateway.feign.CommissionApiGateClient;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;

@RestController
@RequestMapping("/commissionRecord")
@Api(tags = "commission_record API")
@Slf4j
public class CommissionRecordController {

    @Autowired
    private CommissionApiGateClient commissionApiGateClient;


    @PostMapping("/queryByCommissionRecordId")
    @ApiOperation("query commission records by commission id")
    public Result<CommissionRecordSingleResponse> queryByCommissionRecordId(@RequestParam("id") Long id) {

        log.info("commission_record_detail query param :{}", id);
        Result<CommissionRecordSingleResponse> data = commissionApiGateClient.queryByCommissionRecordId(id);
        log.info("commission_record_detail query result :{}", data);
        return data;
    }

    @PostMapping("/queryCommissionPlanByCommissionRecordId")
    @ApiOperation("query commission plan by commission id")
    public Result<CommissionRecordPlanResponse> queryCommissionPlanByCommissionRecordId(@RequestParam("id") Long id) {

        log.info("commission_record_plan query param :{}", id);
        Result<CommissionRecordPlanResponse> data = commissionApiGateClient.queryCommissionPlanByCommissionRecordId(id);
        log.info("commission_record_plan query result :{}", data);
        return data;
    }

}
