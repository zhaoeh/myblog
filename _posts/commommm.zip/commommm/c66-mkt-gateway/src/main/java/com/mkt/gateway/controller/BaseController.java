package com.mkt.gateway.controller;

import com.cn.schema.customers.WSCustomers;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.integration.config.UserCenterConfig;
import com.mkt.agent.integration.config.WSConfig;
import com.mkt.agent.integration.entities.request.ValidatePwdReq;
import com.mkt.agent.integration.template.UserCenterTemplate;
import com.mkt.agent.integration.template.WsTemplate;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.Objects;

/**
 * @Description TODO
 * @Classname BaseController
 * @Date 2023/6/22 14:18
 * @Created by TJSLucian
 */
@Component
public class BaseController {

    @Autowired
    private WSConfig wsConfig;

    @Autowired
    private UserCenterConfig userCenterConfig;

    protected String getRequestIP(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
//        logger.debug("1. 请求的ip:{}", ip);
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
//        logger.info("获取请求的ip:{}", ip);
        if (StringUtils.isNotBlank(ip) && ip.contains(",")) {
            String[] ips = ip.split(",");
            ip = ips[0];
//            logger.info("截取后的ip为:{}", ip);
        }
        return ip;
    }


    protected Result<Boolean> validatePwd(ValidatePwdReq req){

        Result<Boolean> response = Result.fail();
        response.setData(false);
        // 获取玩家信息
//        WsTemplate wsTemplate = new WsTemplate(wsConfig.getWsDefaultUrl(),wsConfig.getPwd());
        UserCenterTemplate userCenterTemplate = new UserCenterTemplate(userCenterConfig.getUserCenterDefaultUrl(),userCenterConfig.getPwd());
        WSCustomers wsCustomer = userCenterTemplate.queryCustomerByLoginName(req.getProductId(), req.getLoginName());
        if (Objects.isNull(wsCustomer)) {
            response.setMessage(ResultEnum.ERROR_LOGINNAME_EMPTY.getMessage());
            return response;
        }

        // 玩家状态判断
        if (!"1".equals(wsCustomer.getFlag())) {
            response.setMessage(ResultEnum.LOGIN_ERROR.getMessage());
            return response;
        }

        String password = DigestUtils.md5Hex(req.getPassword());

        if (StringUtils.equals(password, wsCustomer.getWithdrawalPassword())) {
            Result<Boolean> success = Result.success();
            success.setData(true);
            return success;
        }
        return response;
    }

}
