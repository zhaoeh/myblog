package com.mkt.gateway.controller;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordDetailRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDetailResponse;
import com.mkt.agent.common.entity.api.commissionapi.responses.base.CommissionRecordPageResponse;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.utils.ExcelUtil;
import com.mkt.agent.common.utils.UserContext;
import com.mkt.gateway.exception.MKTGatewayException;
import com.mkt.gateway.feign.CommissionApiGateClient;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/commissionRecord-detail")
@Api(tags = "commission_record_detail API")
@Slf4j
public class CommissionRecordDetailController {

    @Autowired
    private CommissionApiGateClient commissionApiGateClient;


    @PostMapping("/queryByPageAndCondition")
    @ApiOperation("query commission records detail by page and conditions")
    public Result<CommissionRecordPageResponse<CommissionRecordDetailResponse>> queryByPageAndCondition(@RequestBody CommissionRecordDetailRequest req) {


        String loginName = UserContext.getUsername();
        req.setLoginName(loginName);
        log.info("commission_record_detail query parm :{}", req.toString());
        Result<CommissionRecordPageResponse<CommissionRecordDetailResponse>> result = commissionApiGateClient.queryDetailByPageAndCondition(req);
        log.info("commission_record_detail query result :{}", result);
        return result;
    }


    @PostMapping("/exportCommissionRecord")
    @ApiOperation("export Commission Record")
    public Result<List<CommissionRecordDetailResponse>> exportCommissionRecord(@RequestBody CommissionRecordDetailRequest req, HttpServletResponse response) {

        String loginName = UserContext.getUsername();
        req.setLoginName(loginName);
        log.info("commission_record_detail export parm :{}", req.toString());
        Result<List<CommissionRecordDetailResponse>> data = commissionApiGateClient.exportCommissionRecord(req);
        List<CommissionRecordDetailResponse> result = data.getData();
        log.info("commission records pay export result :{}", data);
        try {
            ExcelUtil.export(result, CommissionRecordDetailResponse.class, req.getFileName(), response);
        } catch (IOException e) {
            log.error("commission records pay export error message :{}", e.getMessage());
            throw new MKTGatewayException(ResultEnum.EXCEL_EXPORT_IO_ERROR);
        }

        return data;
    }


}
