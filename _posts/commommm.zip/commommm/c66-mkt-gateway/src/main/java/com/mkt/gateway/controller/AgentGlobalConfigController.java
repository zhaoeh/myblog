package com.mkt.gateway.controller;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TAgentGlobalConfigEntity;
import com.mkt.agent.common.entity.api.agentapi.requests.AgentGlobalConfigSaveRequest;
import com.mkt.agent.common.entity.system.LoginUserInfo;
import com.mkt.agent.common.utils.UserContext;
import com.mkt.gateway.feign.AgentApiClient;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Description 获取代理系统常量
 * @Classname AgentGlobalConfigController
 * @Date 2023/6/28 15:35
 * @Created by TJSLucian
 */
@RestController
@RequestMapping("/global/config")
@Api(tags = {"代理系统常量操作类(门店端接口)"})
public class AgentGlobalConfigController {

    @Resource
    private AgentApiClient agentApiClient;

    @PostMapping("/getValuesByName")
    @ApiOperation(value = "通过常量名称查询常量值")
    @ResponseBody
    public Result<List<TAgentGlobalConfigEntity>> getValuesByName(@RequestBody List<String> names){
        return agentApiClient.getValuesByName(names);
    }

    @PostMapping("/save")
    @ApiOperation(value = "新增/更新常量值")
    @ResponseBody
    public Result saveGlobalConfig(@RequestBody @Validated AgentGlobalConfigSaveRequest request) {
        UserContext.createBranchContext(request.getUpdateBy() == null ? request.getCreateBy() : request.getUpdateBy());
        return agentApiClient.saveGlobalConfig(request);
    }
}
