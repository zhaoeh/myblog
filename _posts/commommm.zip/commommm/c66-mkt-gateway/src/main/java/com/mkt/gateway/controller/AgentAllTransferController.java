package com.mkt.gateway.controller;

import com.mkt.agent.common.annotation.EncryptMethod;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.atransferapi.request.AgentAllTransferReq;
import com.mkt.gateway.feign.AgentApiClient;
import com.mkt.gateway.service.AgentAllTransferService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

/**
 * @Description TODO
 * @Classname AgentAllTransferController
 * @Date 2023/7/11 18:02
 * @Created by TJSLucian
 */
@RestController
@RequestMapping("/Agent/transfer")
@Api(tags = {"对接代理前台系统-代理转账提案"})
public class AgentAllTransferController extends BaseController{

    @Autowired
    private AgentAllTransferService agentAllTransferService ;

    @ApiOperation(value = "创建转账提案", httpMethod = "POST")
    @PostMapping(value = "create")
    @ResponseBody
    @EncryptMethod
    public Result<Boolean> create( @RequestBody @Valid AgentAllTransferReq req,HttpServletRequest request) throws Exception {
        req.setIpAddress(this.getRequestIP(request));
        return agentAllTransferService.verifyPassword(req);
    }

}
