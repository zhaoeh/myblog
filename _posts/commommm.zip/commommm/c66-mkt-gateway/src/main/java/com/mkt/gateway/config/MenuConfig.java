//package com.mkt.gateway.config;
//
//import lombok.Data;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Component;
//
//import java.util.Arrays;
//import java.util.List;
//import java.util.stream.Collectors;
//import java.util.stream.Stream;
//
///**
// * 菜单配置类
// */
//@Component
//@Data
//public class MenuConfig {
//
//    /**
//     * 所有的菜单列表
//     */
//    private List<String> allMenuList;
//
//    /**
//     * 【普通代理线的代理、专业代理线的最后一级代理】的菜单列表
//     */
//    private List<String> normalOrLastAgentMenuList;
//
//    /**
//     * 控制台
//     */
//    @Value("${mkt.menu-list.dashboard.name}")
//    private String dashboard;
//    @Value("${mkt.menu-list.dashboard.url}")
//    private String dashboardUrl;
//
//    /**
//     * 资金记录
//     */
//    @Value("${mkt.menu-list.fund-record.name}")
//    private String fundRecord;
//    @Value("${mkt.menu-list.fund-record.url}")
//    private String fundRecordUrl;
//
//    /**
//     * 推荐链接
//     */
//    @Value("${mkt.menu-list.referral-link.name}")
//    private String referralLink;
//    @Value("${mkt.menu-list.referral-link.url}")
//    private String referralLinkUrl;
//
//    /**
//     * 推荐id
//     */
//    @Value("${mkt.menu-list.referral-id.name}")
//    private String referralId;
//    @Value("${mkt.menu-list.referral-id.url}")
//    private String referralIdUrl;
//
//    /**
//     * 存款
//     */
//    @Value("${mkt.menu-list.deposit.name}")
//    private String deposit;
//    @Value("${mkt.menu-list.deposit.url}")
//    private String depositUrl;
//
//    /**
//     * 取款
//     */
//    @Value("${mkt.menu-list.withdrawal.name}")
//    private String withdrawal;
//    @Value("${mkt.menu-list.withdrawal.url}")
//    private String withdrawalUrl;
//
//    /**
//     * 转账
//     */
//    @Value("${mkt.menu-list.transfer.name}")
//    private String transfer;
//    @Value("${mkt.menu-list.transfer.url}")
//    private String transferUrl;
//
//    /**
//     * 我的玩家
//     */
//    @Value("${mkt.menu-list.my-players.name}")
//    private String myPlayers;
//    @Value("${mkt.menu-list.my-players.url}")
//    private String myPlayersUrl;
//
//    /**
//     * 我的代理
//     */
//    @Value("${mkt.menu-list.my-agents.name}")
//    private String myAgents;
//    @Value("${mkt.menu-list.my-agents.url}")
//    private String myAgentsUrl;
//
//    /**
//     * 我的佣金
//     */
//    @Value("${mkt.menu-list.my-commission.name}")
//    private String myCommission;
//    @Value("${mkt.menu-list.my-commission.url}")
//    private String myCommissionUrl;
//
//    /**
//     * 代理佣金记录
//     */
//    @Value("${mkt.menu-list.agent-commission-record.name}")
//    private String agentCommissionRecord;
//    @Value("${mkt.menu-list.agent-commission-record.url}")
//    private String agentCommissionRecordUrl;
//
//    /**
//     * 支付佣金
//     */
//    @Value("${mkt.menu-list.pay-commission.name}")
//    private String payCommission;
//    @Value("${mkt.menu-list.pay-commission.url}")
//    private String payCommissionUrl;
//
//    /**
//     * 追加佣金
//     */
//    @Value("${mkt.menu-list.append-commission.name}")
//    private String appendCommission;
//    @Value("${mkt.menu-list.append-commission.url}")
//    private String appendCommissionUrl;
//
//    /**
//     * 玩家报告
//     */
//    @Value("${mkt.menu-list.player-report.name}")
//    private String playerReport;
//    @Value("${mkt.menu-list.player-report.url}")
//    private String playerReportUrl;
//
//    /**
//     * 团队报告
//     */
//    @Value("${mkt.menu-list.team-report.name}")
//    private String teamReport;
//    @Value("${mkt.menu-list.team-report.url}")
//    private String teamReportUrl;
//
//    /**
//     * 团队报告
//     */
//    @Value("${mkt.menu-list.account-info.name}")
//    private String accountInfo;
//    @Value("${mkt.menu-list.account-info.url}")
//    private String accountInfoUrl;
//
//    /**
//     * 系统接口
//     */
//    @Value("${mkt.menu-list.system.name}")
//    private String system;
//    @Value("${mkt.menu-list.system.url}")
//    private String[] systemUrls;
//
//    /**
//     * 获取所有菜单名称
//     *
//     * @return 菜单名称
//     */
//    public List<String> getAllMenuList() {
//        return Arrays.asList(dashboard, fundRecord, referralLink, referralId, deposit, withdrawal, transfer,
//                myPlayers, myAgents, myCommission, agentCommissionRecord, payCommission, appendCommission,
//                playerReport, teamReport, accountInfo);
//    }
//
//    /**
//     * 获取所有菜单Url
//     *
//     * @return 菜单名称
//     */
//    public List<String> getAllMenuListUrl() {
//        List<String> allPermission = Arrays.asList(dashboardUrl, fundRecordUrl, referralLinkUrl, referralIdUrl, depositUrl, withdrawalUrl,
//                transferUrl, myPlayersUrl, myAgentsUrl, myCommissionUrl, agentCommissionRecordUrl, payCommissionUrl,
//                appendCommissionUrl, playerReportUrl, teamReportUrl, accountInfoUrl);
//        return Stream.concat(allPermission.stream(), Arrays.stream(systemUrls)).collect(Collectors.toList());
//    }
//
//    /**
//     * 获取【普通代理线的代理、专业代理线的最后一级代理】菜单名称
//     *
//     * @return 菜单名称
//     */
//    public List<String> getNormalOrLastAgentMenuList() {
//        return Arrays.asList(dashboard, fundRecord, referralLink, referralId, deposit, withdrawal, transfer,
//                myPlayers, myCommission, playerReport, accountInfo);
//    }
//
//    /**
//     * 获取【普通代理线的代理、专业代理线的最后一级代理】url名称
//     *
//     * @return 菜单名称
//     */
//    public List<String> getNormalOrLastAgentUrlListUrl() {
//        List<String> permission = Arrays.asList(dashboardUrl, fundRecordUrl, referralLinkUrl, referralIdUrl, depositUrl, withdrawalUrl,
//                transferUrl, myPlayersUrl, myCommissionUrl, playerReportUrl, accountInfoUrl);
//        return Stream.concat(permission.stream(), Arrays.stream(systemUrls)).collect(Collectors.toList());
//    }
//}
