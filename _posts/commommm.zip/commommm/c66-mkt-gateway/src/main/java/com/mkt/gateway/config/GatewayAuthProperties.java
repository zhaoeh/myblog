package com.mkt.gateway.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
@Data
@RefreshScope
public class GatewayAuthProperties {
 
    //JWT 密钥
    @Value("${mkt.gateway.jwt.secret}")
    private String secret;
 
    //accessToken 有效时间
    @Value("${mkt.gateway.jwt.expiration}")
    private Integer expiration;

    // 白名单
    @Value("${mkt.gateway.auth.whitelist}")
    private String[] whitelist;

    public List<String> getWhitelist() {
        return Arrays.asList(whitelist);
    }
}