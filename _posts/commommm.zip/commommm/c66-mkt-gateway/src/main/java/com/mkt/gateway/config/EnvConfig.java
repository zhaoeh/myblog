package com.mkt.gateway.config;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * 系统相关配置
 */
@RefreshScope
@ConfigurationProperties(prefix = "env")
@EnableConfigurationProperties(EnvConfig.class)
@Component
@Data
public class EnvConfig {
    /**
     * 是否打印请求体
     */
    private boolean enableLogRequest;


}
