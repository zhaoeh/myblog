package com.mkt.gateway.controller;

import com.mkt.agent.common.annotation.EnableHtmlEscape;
import com.mkt.agent.common.annotation.EncryptMethod;
import com.mkt.agent.common.annotation.Validate;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.integration.pay.BankListResponse;
import com.mkt.gateway.entities.request.*;
import com.mkt.gateway.entities.response.AccountInfoResponse;
import com.mkt.gateway.entities.response.CustomersBankListResponse;
import com.mkt.gateway.service.AccountInfoService;
import com.mkt.gateway.service.SystemService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * @Description: 账户信息Api
 * @Author: PTMinnisLi
 * @Date: 2023/6/2
 */
@RestController
@RequestMapping("/account")
@Api(tags = {"代理前台用户中心(Account Info)Api"})
public class AccountInfoController {

    @Autowired
    private AccountInfoService accountInfoService;

    @Autowired
    private SystemService systemService;

    @GetMapping("/info")
    @ApiOperation(value = "查询当前账户信息(Account Info首页)")
    public Result<AccountInfoResponse> getAccountInfo() {
        AccountInfoResponse currentAccount = accountInfoService.getCurrentAccount();
        return Result.success(currentAccount);
    }

    @PostMapping("/email/bind")
    @ApiOperation(value = "绑定邮箱")
    @EncryptMethod
    public Result boundEmail(@RequestBody @Validated BindEmailRequest req, HttpServletRequest httpServletRequest) {
        accountInfoService.bindEmail(req, httpServletRequest);
        return Result.success();
    }

    @PostMapping("/email/modify")
    @ApiOperation(value = "修改邮箱（会先校验验证码）")
    @EncryptMethod
    public Result modifyEmail(@RequestBody @Validated ModifyEmailRequest req, HttpServletRequest httpServletRequest) {
        systemService.checkEmailAllType(ModifyEmailRequest.toCheckMailRequest(req));
        accountInfoService.modifyEmail(req, httpServletRequest);
        return Result.success();
    }

    @PostMapping("/phone/bind")
    @ApiOperation(value = "绑定手机")
    @EncryptMethod
    public Result boundPhone(@RequestBody @Validated BindPhoneRequest req, HttpServletRequest httpServletRequest) {
        accountInfoService.bindPhone(req, httpServletRequest);
        return Result.success();
    }

    @PostMapping("/phone/modify")
    @ApiOperation(value = "修改手机（会先校验验证码）")
    @EncryptMethod
    @Validate
    public Result modifyPhone(@RequestBody ModifyPhoneRequest req, HttpServletRequest httpServletRequest) {
        systemService.checkSmsAllType(ModifyPhoneRequest.toCheckSmsRequest(req));
        accountInfoService.modifyPhone(req, httpServletRequest);
        return Result.success();
    }

    @PostMapping("/login-password/set")
    @ApiOperation(value = "修改登录密码")
    @EncryptMethod
    public Result setLoginPassword(@RequestBody @Validated ModifyPwdRequest req, HttpServletRequest httpServletRequest) {
        accountInfoService.modifyLoginPassword(req, httpServletRequest, systemService::checkSmsAllType);
        return Result.success();
    }

    @PostMapping("/forget-password/set")
    @ApiOperation(value = "忘记密码，修改登录密码")
    @EncryptMethod
    public Result setLoginPasswordForForgetPassword(@RequestBody @Validated ForgetPwdRequest req, HttpServletRequest httpServletRequest) {
        accountInfoService.modifyLoginPasswordForForgetPassword(req, httpServletRequest);
        return Result.success();
    }

    @PostMapping("/wallet-password/set")
    @ApiOperation(value = "修改钱包密码")
    @EncryptMethod
    public Result setWalletPassword(@RequestBody @Validated ModifyWalletPwdRequest req, HttpServletRequest httpServletRequest) {
        accountInfoService.modifyWalletPassword(req, httpServletRequest);
        return Result.success();
    }

    @GetMapping("/found/bank/list")
    @ApiOperation(value = "查询银行绑定情况")
    public Result<List<CustomersBankListResponse>> getBankList() {
        List<CustomersBankListResponse> foundDetail = accountInfoService.getBankList();
        return Result.success(foundDetail);
    }

    @GetMapping("/found/gcash/list")
    @ApiOperation(value = "查询gcash绑定情况")
    public Result<List<CustomersBankListResponse>> getGcashList() {
        List<CustomersBankListResponse> foundDetail = accountInfoService.getGcashList();
        return Result.success(foundDetail);
    }

    @GetMapping("/found/paymaya/list")
    @ApiOperation(value = "查询paymaya绑定情况")
    public Result<List<CustomersBankListResponse>> getPaymayaList() {
        List<CustomersBankListResponse> foundDetail = accountInfoService.getPayMayaList();
        return Result.success(foundDetail);
    }

    @PostMapping("/found/bank/bind")
    @ApiOperation(value = "绑定银行卡")
    @EncryptMethod
    @Validate
    @EnableHtmlEscape
    public Result setBankList(@RequestBody FoundBankBindRequest request, HttpServletRequest httpRequest) {
        accountInfoService.bindBankCard(request, httpRequest);
        return Result.success();
    }

    @PostMapping("/found/gcash/bind")
    @ApiOperation(value = "绑定gcash")
    @EncryptMethod
    public Result setGcashList(@RequestBody @Validated FoundGCashBindRequest request, HttpServletRequest httpRequest) {
        accountInfoService.bindGcash(request, httpRequest);
        return Result.success();
    }

    @PostMapping("/found/paymaya/bind")
    @ApiOperation(value = "绑定paymaya")
    @EncryptMethod
    public Result setPaymayaList(@RequestBody @Validated FoundPayMayaBindRequest request, HttpServletRequest httpRequest) {
        accountInfoService.bindPayMaya(request, httpRequest);
        return Result.success();
    }

    @GetMapping("/pay/bank/list")
    @ApiOperation(value = "查询银行列表(绑定银行卡时)")
    public Result<List<BankListResponse>> searchBankList() {
        List<BankListResponse> s = accountInfoService.searchBankList();
        return Result.success(s);
    }


    @PostMapping("/phone/check")
    @ApiOperation(value = "验证手机号是否已占用")
    @EncryptMethod
    public Result checkPhone(@RequestBody @Validated CheckAccountRequest request) {
        boolean checkPhone = accountInfoService.checkPhone(request);
        return Result.success(checkPhone);
    }

    @PostMapping("/email/check")
    @ApiOperation(value = "验证邮箱是否已占用")
    @EncryptMethod
    public Result checkEmail(@RequestBody @Validated CheckAccountRequest request) {
        accountInfoService.checkEmail(request);
        return Result.success();
    }
}
