package com.mkt.gateway.controller;

import com.mkt.agent.common.entity.api.atransferapi.A2PTransferEntity;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.atransferapi.request.A2PTransferListReq;
import com.mkt.agent.common.entity.api.atransferapi.request.A2PTransferReq;
import com.mkt.agent.integration.entities.PageModelExt;
import com.mkt.agent.integration.entities.Response;
import com.mkt.gateway.feign.AgentApiClient;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * @Description TODO
 * @Classname A2ATransferController
 * @Date 2023/6/21 19:03
 * @Created by TJSLucian
 */
@RestController
@RequestMapping("/A2P")
@Api(tags = {"对接门店系统-代理转玩家转账提案"})
public class A2PTransferController extends BaseController{

    @Autowired
    private AgentApiClient agentApiClient;

    @ApiOperation(value = "创建代理转玩家转账提案", httpMethod = "POST")
    @PostMapping(value = "createA2PTransfer")
    @ResponseBody
    public Result<Boolean> create(HttpServletRequest request, @RequestBody A2PTransferReq req) throws Exception {
        req.setIpAddress(this.getRequestIP(request));
        return agentApiClient.createA2PTrans(req);
    }


    @ApiOperation(value = "查询代理转玩家提案列表", httpMethod = "POST")
    @PostMapping(value = "queryA2PTransferList")
    @ResponseBody
    public Result<PageModelExt<A2PTransferEntity>> queryA2PTransList(@RequestBody A2PTransferListReq req) throws Exception {
        return agentApiClient.queryA2PTransList(req);
    }

}
