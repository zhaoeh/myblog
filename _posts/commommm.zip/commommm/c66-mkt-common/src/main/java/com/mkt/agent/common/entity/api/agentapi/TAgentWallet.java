package com.mkt.agent.common.entity.api.agentapi;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.entity.BaseEntity;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import javax.persistence.Table;
import java.math.BigDecimal;

/**
 * @ClassName TAgentWallet
 * @Description 佣金钱包
 * @Author JOJO
 * @Date 2023/8/7 14:00
 * @Version 1.0
 **/
@Table(name="代理佣金钱包表")
@TableName("t_agent_wallet")
@Data
@SuperBuilder
@NoArgsConstructor
public class TAgentWallet extends BaseEntity {

    /*
       所属产品
    */
    @Column(name="product_id",nullable = false)
    private String productId;
    /*
       代理ID
    */
    @Column(name="agent_id",nullable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long agentId;
    /*
       代理用户名称
    */
    @Column(name="login_name",nullable = false)
    private String loginName;
    /*
       币种
    */
    @Column(name="currency",nullable = false)
    private String currency;
    /*
       佣金额度
    */
    @Column(name="balance",nullable = false)
    private BigDecimal balance;
    /*
       钱包状态：1-启用，0-停用
    */
    @Column(name="is_enable",nullable = false)
    private Integer isEnable;
    /*
       创建人
    */
    @Column(name="create_by",nullable = false)
    private String createBy;
    /*
       最后修改人
    */
    @Column(name="update_by",nullable = false)
    private String updateBy;

    @Override
    public String toString() {
        return "TAgentWallet{" +
                "id=" + id +
                ", createTime='" + createTime + '\'' +
                ", updateTime='" + updateTime + '\'' +
                ", productId='" + productId + '\'' +
                ", agentId=" + agentId +
                ", loginName='" + loginName + '\'' +
                ", currency='" + currency + '\'' +
                ", balance=" + balance +
                ", isEnable=" + isEnable +
                ", createBy='" + createBy + '\'' +
                ", updateBy='" + updateBy + '\'' +
                '}';
    }
}
