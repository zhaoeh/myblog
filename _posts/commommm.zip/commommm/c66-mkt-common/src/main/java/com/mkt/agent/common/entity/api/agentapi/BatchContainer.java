package com.mkt.agent.common.entity.api.agentapi;

import com.mkt.agent.common.entity.TCustomerLayer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @description: 批量容器
 * @author: ErHu.Zhao
 * @create: 2024-04-17
 **/
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BatchContainer {

    /**
     * 代理信息
     */
    private TAgentCustomers tAgentCustomers;

    /**
     * 玩家信息
     */
    private TCustomerLayer tCustomerLayer;


    /**
     * 门店记录信息
     */
    private TAgentCustomersBranch tAgentCustomersBranch;

}
