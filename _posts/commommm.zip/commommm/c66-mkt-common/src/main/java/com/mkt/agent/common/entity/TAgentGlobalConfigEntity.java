package com.mkt.agent.common.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

/**
 * @Description 代理系统数据库常量配置实体类
 * @Classname TAgentGlobalConfigEntity
 * @Date 2023/6/28 15:52
 * @Created by TJSLucian
 */
@Data
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@TableName("t_agent_global_config")
public class TAgentGlobalConfigEntity extends BaseEntity{

    private String productId;
    private String paramName;
    private String paramValue;
    private Integer isEnable;
    private String paramDesc;

    @TableField(fill = FieldFill.INSERT)
    private String createBy;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private String updateBy;

}
