package com.mkt.agent.common.entity.api.agentapi;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.entity.BaseOperationEntity;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import javax.persistence.Table;

@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@Table(name="代理绑定佣金方案表")
@TableName("t_agent_contract_bind")
@SuperBuilder
@Data
public class TAgentContractBind extends BaseOperationEntity {

    @Column(name="COMMISSION_CONTRACT_ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long commissionContractId;

    @Column(name="LOGIN_NAME")
    private String loginName;

    @Column(name="PERCENTAGE_DETAILS")
    private String percentageDetails;




}
