package com.mkt.agent.common.fast.core;

import com.alibaba.nacos.common.utils.CollectionUtils;
import com.alibaba.nacos.common.utils.UuidUtils;
import com.mkt.agent.common.fast.pojo.DailyMktUserMapping;
import com.mkt.agent.common.fast.pojo.SimpleCustomers;
import org.apache.commons.collections.MapUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-04-01
 **/
public class FastUtils {

    private static final String BATCH_INSERT_PREFIX_DAILY = "insert into t_daily_mkt_user_mapping (login_name,self_status,parent_direct,parent_direct_status,parent_direct_level,parent_five,parent_five_status,parent_four,parent_four_status,parent_three,parent_three_status,parent_two,parent_two_status,parent_one,parent_one_status,parent_root,is_deleted,create_date) VALUES ";

    private static final String BATCH_DELETE_PREFIX_DAILY = "delete from t_daily_mkt_user_mapping where 1=1";

    /**
     * 生成对应size的uuid集合
     *
     * @param size
     * @return
     */
    public static List<String> generateUuid(int size) {
        Set<String> uuids = new HashSet<>();
        while (true) {
            if (uuids.size() == size) {
                return new ArrayList<>(uuids);
            }
            uuids.add(UuidUtils.generateUuid().replaceAll("-", ""));
        }
    }

    public static String buildInsertSqlWithUserMapping(List<DailyMktUserMapping> dataSources) {
        if (CollectionUtils.isEmpty(dataSources)) {
            return null;
        }
        StringBuilder builder = new StringBuilder();
        builder.append(BATCH_INSERT_PREFIX_DAILY);
        dataSources.stream().forEach(map -> {
            builder.append("(").
                    append("\'" + map.getLoginName() + "\'").
                    append(", ").
                    append(map.getSelfStatus()).
                    append(", ").
                    append("\'" + map.getParentDirect() + "\'").
                    append(", ").
                    append(map.getParentDirectStatus()).
                    append(", ").
                    append(map.getParentDirectLevel()).
                    append(", ").
                    append("\'" + map.getParentFive() + "\'").
                    append(", ").
                    append(map.getParentFiveStatus()).
                    append(", ").
                    append("\'" + map.getParentFour() + "\'").
                    append(", ").
                    append(map.getParentFourStatus()).
                    append(", ").
                    append("\'" + map.getParentThree() + "\'").
                    append(", ").
                    append(map.getParentThreeStatus()).append(", ").
                    append("\'" + map.getParentTwo() + "\'").
                    append(", ").
                    append(map.getParentTwoStatus()).
                    append(", ").
                    append("\'" + map.getParentOne() + "\'").
                    append(", ").
                    append(map.getParentOneStatus()).
                    append(", ").
                    append("\'" + map.getParentRoot() + "\'").
                    append(", ").
                    append(map.getIsDeleted()).
                    append(", ").
                    append("\'" + map.getCreateDate() + "\'").
                    append("),");
        });

        String sql = builder.toString();
        sql = sql.substring(0, sql.length() - 1);
        return sql;
    }


    public static String buildDeleteSqlWithUserMapping(List<String> dataSources) {
        if (CollectionUtils.isEmpty(dataSources)) {
            return null;
        }
        StringBuilder builder = new StringBuilder();
        builder.append(BATCH_DELETE_PREFIX_DAILY);

        if (dataSources.size() == 1) {
            builder.append(" and login_name = " + dataSources.get(0));
        } else {
            builder.append("and login_name in ");
        }


        dataSources.stream().forEach(name -> {
            builder.append("(").
                    append("\'" + name + "\'").
                    append("),");
        });

        String sql = builder.toString();
        sql = sql.substring(0, sql.length() - 1);
        return sql;
    }

    /**
     * 转换map的key为list
     *
     * @param map
     * @return
     */
    public static List<String> mapKey2List(Map<String, String> map) {

        if (MapUtils.isEmpty(map)) {
            return Collections.emptyList();
        }
        return map.keySet().stream().collect(Collectors.toList());
    }

    /**
     * 获取目标代理状态
     *
     * @param agent
     * @return
     */
    public static int obtainStatusOfAgent(SimpleCustomers agent) {
        return agent.getIsEnable().equals(0) || agent.getIsDeleted().equals(1) ? 0 : 1;
    }
}
