package com.mkt.agent.common.utils;

import com.cn.schema.request.WSOddNumbersGen;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.enums.GenerateOrderNumEnum;
import com.mkt.agent.common.exception.BusinessException;
import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * @ClassName TransIdGenerator
 * @Description 交易流水号生成工具
 * @Author TJSAlex
 * @Date 2023/6/9 10:51
 * @Version 1.0
 **/
public class TransIdGenerator {

    private static final char serial_start = 'A';
    private static final  char serial_end = 'Z';
    private static final int num_start = 1;
    private static final int requestid_num_end = 99;

    //使用雪花算法
    public static String getSingleId(String productId){
        SnowFlakeUtil snowFlakeUtil = SnowFlakeUtil.getInstance(productId);
        return snowFlakeUtil.nextId()+"";
    }

    //以下方法有问题，不再使用
//    public static String singleGenRequestId(String productId, String requestType) {
//        productId = StringUtils.isBlank(productId) ? Constants.C66: productId;
//
//        WSOddNumbersGen loadOdd = lockOddNumbersBeforeGen(productId, requestType, "1");
//        String finalBillNo = doGenerateRequestId(productId, requestType, loadOdd);
//        return finalBillNo;
//    }

    private static WSOddNumbersGen lockOddNumbersBeforeGen(String productId, String requestType, String serialType) throws BusinessException {
        // 查出单号生成记录，不存在则创建一条
            String serialNumber = "";
            String specialStr = "";
            if(StringUtils.equals(serialType, "1")){
                serialNumber = (int) (serial_start)+getNumberTwo(num_start);
                specialStr = String.valueOf(serial_start);
            } else if(StringUtils.equals(serialType, "2")){
                serialNumber = getNumberThree(num_start);
                specialStr = String.valueOf((int)serial_start);
            } else if(StringUtils.equals(serialType, "3")){
                serialNumber = getNumberThree(num_start);
                specialStr = String.valueOf(serial_start);
            } else {
                throw new BusinessException("MSG_500539");
            }
            WSOddNumbersGen createNewOdd = new WSOddNumbersGen();
            createNewOdd.setProductId(productId);
            createNewOdd.setRequestType(requestType);
            createNewOdd.setSerialNumber(serialNumber);
            createNewOdd.setSerialType(serialType);
            createNewOdd.setSpecialStr(specialStr);
            createNewOdd.setTimeStr(System.currentTimeMillis()+"");
        return createNewOdd;
    }

    /**
     * 生成提案类的单号：A03021902221148AA01(A03 02 1902221148 A A 01)
     * A03(产品ID) + 02(业务类型requestType) + 1902221148(当前时间串yyMMddHHmm) + A(特殊位) + A(流水字母位) + 01(数字流水)
     * @param productId
     * @param requestType
     * @param loadOdd
     * @return
     * @throws BusinessException
     */
    private static String doGenerateRequestId(String productId, String requestType, WSOddNumbersGen loadOdd) throws BusinessException {
        String finalBillNo = "";

        String timeStr = loadOdd.getTimeStr();
        String randomNum = NumberUtils.getRNum(4);

        char oldSpecialChar = loadOdd.getSpecialStr().charAt(0);
        char serialChar = loadOdd.getSerialNumber().substring(0, 1).charAt(0);
        String serialNum = loadOdd.getSerialNumber().substring(1);
        int intSerialNum = Integer.parseInt(serialNum);
        if(intSerialNum+1> requestid_num_end){
            // 如果超出最大数字流水，则字母流水+1，流水用起始值
            if((int) serialChar+1>(int) serial_end){
                // 如果超出字母最大流水号，特殊字母位+1，数字流水、字母流水位用起始值
                if((int) oldSpecialChar+1>(int) serial_end){
                    // 如果特殊位流水也超过字母最大流水号，则异常
//                        ValidationUtils.exceptionMsg(ErrCodeEnum.MSG_500540);
                    throw new BusinessException("MSG_500540");
                }else{
                    finalBillNo = genRequestId(productId, requestType, timeStr, randomNum, String.valueOf((char)((int) oldSpecialChar+1)), String.valueOf(serial_start), getNumberTwo(num_start));
                }
            }else{
                finalBillNo = genRequestId(productId, requestType, timeStr, randomNum, String.valueOf(oldSpecialChar), String.valueOf((char)((int) serialChar+1)), getNumberTwo(num_start));
            }
        }else{
            finalBillNo = genRequestId(productId, requestType, timeStr, randomNum,String.valueOf(oldSpecialChar), String.valueOf(serialChar), String.valueOf(getNumberTwo(intSerialNum+1)));
        }


        // 更新单号生成记录，返回单号
        loadOdd.setTimeStr(timeStr);
        loadOdd.setSpecialStr(finalBillNo.substring(finalBillNo.length()-4, finalBillNo.length()-3));
        loadOdd.setSerialNumber(finalBillNo.substring(finalBillNo.length()-3));
        return finalBillNo;
    }

    private static String genRequestId(String productId, String requestType, String timeStr, String randomNum, String specialStr, String serialStr, String numStr) {
        return productId+requestType+timeStr+randomNum;
    }

    private static String getNumberThree(int num){
        if(num<10){
            return "00" + String.valueOf(num);
        } else if(num < 100){
            return "0" + String.valueOf(num);
        } else{
            return String.valueOf(num);
        }
    }

    private static String getNumberTwo(int num){
        return num >= 10 ? String.valueOf(num) : "0" + String.valueOf(num);
    }
}
