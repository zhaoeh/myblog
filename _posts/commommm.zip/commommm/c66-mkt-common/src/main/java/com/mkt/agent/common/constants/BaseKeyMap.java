package com.mkt.agent.common.constants;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

// 字典类
public class BaseKeyMap {


    {

        COMMISSION_RECORD_MAP.put(BaseConstants.CommissionAmount, new BigDecimal(0));
        COMMISSION_RECORD_MAP.put(BaseConstants.ActualCommissionAmount, new BigDecimal(0));
        COMMISSION_RECORD_MAP.put(BaseConstants.AppendCommissionAmount, new BigDecimal(0));
        COMMISSION_RECORD_MAP.put(BaseConstants.Turnover, new BigDecimal(0));
        COMMISSION_RECORD_MAP.put(BaseConstants.GGR, new BigDecimal(0));
        COMMISSION_RECORD_MAP.put(BaseConstants.WinAndLoss, new BigDecimal(0));
        COMMISSION_RECORD_MAP.put(BaseConstants.Deposit, new BigDecimal(0));
        COMMISSION_RECORD_MAP.put(BaseConstants.Withdrawal, new BigDecimal(0));

    }

    // 佣金记录总字典树
    public static Map<String, BigDecimal> COMMISSION_RECORD_MAP = new HashMap<String, BigDecimal>();


    {

        COMMISSION_RECORD_LIST_MAP.put(BaseConstants.CommissionAmount, new BigDecimal(0));
        COMMISSION_RECORD_LIST_MAP.put(BaseConstants.ActualCommissionAmount, new BigDecimal(0));
        COMMISSION_RECORD_LIST_MAP.put(BaseConstants.AppendCommissionAmount, new BigDecimal(0));

    }

    // 佣金记录一级代理列表聚合字典map
    public static Map<String, BigDecimal> COMMISSION_RECORD_LIST_MAP = new HashMap<String, BigDecimal>();


    {
        COMMISSION_RECORD_DETAIL_MAP.put(BaseConstants.Turnover, new BigDecimal(0));
        COMMISSION_RECORD_DETAIL_MAP.put(BaseConstants.GGR, new BigDecimal(0));
        COMMISSION_RECORD_DETAIL_MAP.put(BaseConstants.WinAndLoss, new BigDecimal(0));
        COMMISSION_RECORD_DETAIL_MAP.put(BaseConstants.Deposit, new BigDecimal(0));
        COMMISSION_RECORD_DETAIL_MAP.put(BaseConstants.Withdrawal, new BigDecimal(0));

    }

    // 佣金记录下级代理详细列表聚合字典map
    public static Map<String, BigDecimal> COMMISSION_RECORD_DETAIL_MAP = new HashMap<String, BigDecimal>();


}
