package com.mkt.agent.common.constants;

import com.mkt.agent.common.utils.DateUtils;
import org.springframework.util.unit.DataUnit;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description: 共通常量
 * @Author: PTMinnisLi
 * @Date: 2023/6/7
 */
public class Constants {

    // 敏感信息遮蔽的字符
    public static final String HIDE_CHAR = "*";
    // 敏感信息遮蔽的占位符
    public static final String HIDE_PLACEHOLDER = "A";
    public static final String REGEX_EMAIL = "^(\\w+([-+.]\\w+)*)(@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*)$";

    public static final String C66 = "C66";


    /**
     * mkt-agent-api项目生成用户时用户名去重
     */
    public static final String MKT_PREFIX = "MKT_";


    // 历史数据供应器策略标识（历史月）
    public static final String HISTORY_DATA = "history_data";

    // 当前数据供应器策略标识（当前月）
    public static final String CURRENT_DATA = "current_data";

    // 仪表盘当前用户统计数据缓存前缀
    public static final String CURRENT_USER_DASH_BOARD_CACHE_PREFIX = MKT_PREFIX + "DASHBOARD_";

    // 仪表盘当前用户统计数据补救前缀
    public static final String CURRENT_USER_DASH_BOARD_REPAIR_CACHE_PREFIX = MKT_PREFIX + "REPAIR_";

    // 仪表盘柱状图缓存前缀
    public static final String CURRENT_USER_TURNOVER_TOP_CACHE_PREFIX = MKT_PREFIX + "TURNOVER_TOP_";

    // 仪表盘饼状图缓存前缀
    public static final String CURRENT_USER_TURNOVER_DSITRI_CACHE_PREFIX = MKT_PREFIX + "TURNOVER_DSITRI_";

    //仪表盘佣金缓存前缀
    public static final String COMMISSION_CACHE_PREFIX = MKT_PREFIX + "COMMISSION_CACHE_PREFIX_";

    //仪表盘投注人数缓存前缀
    public static final String BETPLAYERS_CACHE_PREFIX = MKT_PREFIX + "BETPLAYERS_CACHE_PREFIX_";

    //存储mkt项目已有的用户名用于去重
    public static final String UNIQUE_NAME_PREFIX = MKT_PREFIX  + "UNIQUE_NAME_PREFIX_";

    //当前生成用户名的位数
    public static final String CURRENT_LENGTH = MKT_PREFIX  + "CURRENT_LENGTH";
    //判断去重的最大判断次数
    public static final String MAX_TRY_TIMES = MKT_PREFIX  + "MAX_TRY_TIMES";

    //用户名最长位数限制
    public static final Integer MAX_ACCOUNT_LENGTH = 16;

    //注册用户或修改用户时 用户类型 前缀 customer_type
    public static final String REGISTER_CUSTOMER_TYPE = MKT_PREFIX + "CUSTOMER_TYPE_";

    //注册用户或修改用户时 用户messages 前缀
    public static final String REGISTER_CUSTOMER_MESSAGES = MKT_PREFIX + "CUSTOMER_MESSAGES_";

    //计算所有代理的仪表盘数据时的开始级别
    public static final int DASH_BOARD_DATA_START_LEVEL = 5;

    //user服务加载所有代理loginName到缓存  注册用户时判断用户身份使用
    public static final String ALL_AGENT_LOGINNAME = MKT_PREFIX + "ALL_AGENT_LOGINNAME_";

    public static final int AGENT_LEVEL_ONE = 1;

    public static final String CURRENT_MONTH = "CURRENT_MONTH";
    public static final String LAST_MONTH = "LAST_MONTH";
    public static final String LAST2_MONTH = "LAST2_MONTH";
    public static final String CURRENT_WEEK = "CURRENT_WEEK";
    public static final String LAST_WEEK = "LAST_WEEK";
    public static final String LAST2_WEEK = "LAST2_WEEK";
    public static final String CURRENT_DAY = "CURRENT_DAY";
    public static final String LAST_DAY = "LAST_DAY";
    public static final String LAST2_DAY = "LAST2_DAY";

    /**
     * 限流器相关常量
     */
    public static final String CHOSEN_PERIOD_KEY = "chosenPeriod";
    public static final String CHOSEN_TYPE_KEY = "chosenType";
    public static final String LOGIN_NAME_KEY = "loginName";


    /** request id:request type */
    /** REQUEST TYPE:01----DEPOSIT */
    public static final String REQUEST_TYPE_DEPOSIT = "01";
    /** REQUEST TYPE:02---WITHDRAW */
    public static final String REQUEST_TYPE_WITHDRAWAL = "02";
    /** REQUEST TYPE:03---TRANSFER */
    public static final String REQUEST_TYPE_TRANSFER = "03";

    public static final String ALL_TYPE = "ALL";

    //请求是否来自于佣金--用于发放佣金时调用账变记录接口
    public static final Integer ISCOMMISSION = 1;
    public static final Integer ISNCOMMISSION = 0;

    /** 短信常量 */
    public static class SMSConstants {
        public static final String BIND_PHONE_SMS_CONTENT = "Welcome to  bind phone number .your OTP number is %s,please enter within 15 minutes ";
        public static final String BIND_EMAIL_SMS_CONTENT = "Welcome to  bind email number .your OTP number is %s,please enter within 15 minutes ";
        public static final String MODIFY_PHONE_SMS_CONTENT = "Welcome to  modify phone number .your OTP number is %s,please enter within 15 minutes ";
        public static final String MODIFY_EMAIL_SMS_CONTENT = "Welcome to  modify email number .your OTP number is %s,please enter within 15 minutes ";
        public static final String MODIFY_LOGIN_PASSWORD_SMS_CONTENT = "Welcome to  modify login password .your OTP number is %s,please enter within 15 minutes ";
        public static final String MODIFY_WALLET_PASSWORD_SMS_CONTENT = "Welcome to  modify wallet password .your OTP number is %s,please enter within 15 minutes ";
        public static final String LOGIN_SMS_CONTENT = "Welcome to login. Your OTP number for login is %s & will expire in 15 minutes.";
    }

    /** 短信常量 */
    public static class EMailConstants {
        /**
         * EmailSendUtil Constants
         */
        public static final String EMAIL_SEND_CODE_BINGOPLUS = "20018";
        public static final String EMAIL_SEND_CODE_ARENAPLUS = "20024";
        public static final String VERIFY_CODE_EMAIL_SUBJECT_BINGOPLUS = "verification code";
        public static final String VERIFY_CODE_EMAIL_SUBJECT_ARENAPLUS = "[ArenaPlus] verification code";
        public static final String CHANGE_WITHDRAW_PASSWORD = "changing";
        public static final String CHANGE_WITHDRAW_PASSWORD_FIRSTTIME = "setting";
        public static final String BIND_GCASH = "Gcash";
        public static final String BIND_BANK = "Bank";
    }

    /** 门店相关常量 */
    public static class BranchConstants {
        /**
         * 门店端接口默认更新人
         */
        public static final String BRANCH_DEFAULT_CREATE_UPDATE_BY = "BRANCH_SITE";
        public static final Long BRANCH_DEFAULT_CREATE_UPDATE_ID = -1L;

        public static final String CONFIG_KEY_WITHDRAWAL_RISK_RECEIVE = "WITHDRAWAL_RISK_RECEIVE";

        public static final String CONFIG_KEY_WITHDRAWAL_RISK_AMOUNT = "WITHDRAWAL_RISK_AMOUNT";
    }

    // BANK_CARD , GCASH： GCASH_A , PAYMAYA：PAYMAYA_A
    public static final String[] DEPOSIT_ACCOUNT_TYPE = new String[]{"BANK_CARD","GCASH","GCASH_A","PAYMAYA","PAYMAYA_A","GLIFE","GLIFE_A"};


    // 取款审批状态
    public static final String Withdraw_APPROVE_STATE = "2";

    //数字型常量
    public static final String ZERO = "0";
    public static final String ONE = "1";
    public static final String TWO = "2";
    public static final String THREE = "3";
    public static final String FOUR = "4";
    public static final String FIVE = "5";
    public static final String SIX = "6";
    public static final String SEVEN = "7";
    public static final String EIGHT = "8";
    public static final String NINE = "9";
    public static final String TEN = "10";
    public static final String ELEVEN = "11";
    public static final String TWELVE = "12";
    public static final String THIRTEEN = "13";
    public static final String FOURTEEN = "14";

    public static final Integer INT_ONE = 1;

    public static final String START_TIME=" 00:00:00";
    public static final String END_TIME=" 23:59:59";


    //符号型常量
    // 分号
    public static final String SEMICOLON = ";";
    // 逗号
    public static final String COMMA = ",";
    // hash
    public static final String IDENTIFIER = "#";

    /** 代理存款相关常量 */
    // 前端deposit list type and status
    public static final String FRONT_DEPOSIT_LIST_TYPE_99 = "Cash at Branch";
    public static final String FRONT_DEPOSIT_LIST_TYPE_98 = "Gcash at Branch";
    public static final String FRONT_DEPOSIT_LIST_TYPE_97 = "Adjustment";
    public static final String FRONT_DEPOSIT_LIST_TYPE_0 = "Online Banking";
    public static final String FRONT_DEPOSIT_LIST_TYPE_2 = "Gcash QR Code";
    public static final String FRONT_DEPOSIT_LIST_TYPE_800 = "new player Voucher";
    public static final String FRONT_DEPOSIT_LIST_TYPE_801 = "top up Voucher";

    // Waiting Approved Denied Processing
    public static final String FRONT_DEPOSIT_LIST_STATUS_0 = "Waiting";
    public static final String FRONT_DEPOSIT_LIST_STATUS_01 = "Pending";//线上存款
    public static final String FRONT_DEPOSIT_LIST_STATUS_02 = "Reviewing";//门店存款调账
    public static final String FRONT_DEPOSIT_LIST_STATUS_1 = "Processing";
    public static final String FRONT_DEPOSIT_LIST_STATUS_2 = "Approved";
    public static final String FRONT_DEPOSIT_LIST_STATUS_3 = "Denied";//-3
    public static final String FRONT_DEPOSIT_LIST_STATUS_4 = "cancel";//-1

    public static final String REQUEST_FlAG_PROCESSING = "1";
    /** request_flag:2:approve */
    public static final String REQUEST_FLAG_APPROVE = "2";
    /** request_flag:9:approve */
    public static final String REQUEST_FLAG_WAITAPPROVE = "9";

    public static final String DEFAULT_CURRENCY="PHP";

    //系统创建人
    public static final String CREATED_BY_SYSTEM = "System";

    //佣金是否需要二审金额阈值
    public static final String COMMISSION_NEED_SECOND_APPROVAL_AMOUNT = "Commission approval need second approval amount";

    // 在命中日期之前，当前代理用户的交易总数key
    public static final String AGENT_TOTAL_COUNT_BEFORE_HIT = "agentTotalCountBeforeHit";

    // 缓存当天的明细总数信息key
    public static final String CURRENT_DAY_COUNT = "currentDayCount";

    // 在命中日期之前，当前代理用户的交易总数key  月维度
    public static final String AGENT_TOTAL_COUNT_BEFORE_HIT_BY_MONTH = "agentTotalCountBeforeHitByMonth";

    public static final String TOTAL_SIZE = "totalSize";

    public static final int DEFAULT_FIRST_HIT_START_INDEX = -1;

    public static final Integer SELF = 1;
    public static final Integer DIRECT = 2;
    public static final Integer AGENT = 3;

    public static final Integer REFRESH = 1;
    public static final Integer SYNC = 2;
    public static final Integer CLEAR = 3;

    public static final String FROM_JOB = "0";
    public static final String FROM_ASYNC = "1";
    public static final String FROM_SCHEDULED = "2";

    public static final Integer SELF_COUNT = 1;
    public static final Integer DIRECT_COUNT = 2;
    public static final Integer TEAM_COUNT = 3;

    /**
     * player report按天明细缓存前缀
     */
    public static final String PLAYER_REPORT_BY_DAY = MKT_PREFIX + "PLAYER_DAY_";

    /**
     * 按天统计明细常量名
     */
    public static final String SYNC_TRANS_BY_DAY_HANDLER = "SyncTransByDayHandler";

    /**
     * 用户登录来源-前台
     */
    public static final String FROM_FRONTEND = "frontend";

    /**
     * 用户登录来源-后台
     */
    public static final String FROM_BACKEND = "backend";

}
