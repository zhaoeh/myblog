package com.mkt.agent.common.entity.api.jobapi.responses;

import com.mkt.agent.common.constants.BaseConstants;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class CustomerPlayInfoMonthSumResponse {


    private BigDecimal sumTurnover;

    private BigDecimal sumGGR;

    private BigDecimal sumWinAndLoss;

    private BigDecimal sumDeposit;

    private BigDecimal sumWithdrawal;


    public void defaultValueSet() {

        this.sumTurnover = new BigDecimal(BaseConstants.DEFAULT_AMOUNT);
        this.sumGGR = new BigDecimal(BaseConstants.DEFAULT_AMOUNT);

        this.sumWinAndLoss = new BigDecimal(BaseConstants.DEFAULT_AMOUNT);
        this.sumDeposit = new BigDecimal(BaseConstants.DEFAULT_AMOUNT);
        this.sumWithdrawal = new BigDecimal(BaseConstants.DEFAULT_AMOUNT);

    }

}
