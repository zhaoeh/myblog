package com.mkt.agent.common.aop;

import com.mkt.agent.common.annotation.Convert2NullIfInvalidField;
import com.mkt.agent.common.annotation.DecryptField;
import com.mkt.agent.common.annotation.EncryptField;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.utils.AesEncode;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.util.Objects;

/**
 * @Description TODO --
 * @Classname ConvertToNullIfEmptyAop
 * @Date 2024/2/14 16:23
 * @Created by TJSLucian
 */
@Aspect
@Component
@Slf4j
public class ConvertToNullIfInvalidAop {

    @SneakyThrows
    @Before("@annotation(com.mkt.agent.common.annotation.Convert2NullIfInvalidMethod)")
    public void convertToNullIfInvalid(JoinPoint joinPoint) throws Throwable {
        Object[] args = joinPoint.getArgs();
        for (Object arg : args) {
            checkFields(arg);
        }

    }


    private void checkFields(Object arg) throws IllegalAccessException {
        if (Objects.isNull(arg)) {
            return;
        }
        Field[] fields = arg.getClass().getDeclaredFields();
        for (Field field : fields) {

            if (field.isAnnotationPresent(Convert2NullIfInvalidField.class)) {
                field.setAccessible(true);
                Object value = field.get(arg);
                if(Objects.isNull(value)){
                    return;
                }
                Convert2NullIfInvalidField annotation = field.getAnnotation(Convert2NullIfInvalidField.class);
                String[] inValidValues = annotation.inValidValues();
                boolean isDefault = annotation.isDefault();
                // 检查属性值是否为有效值，如果不是，则设置为 null
                if (isInValidValue(inValidValues, isDefault, value)) {
                    setValueToNull(field,arg);
                }
            }

        }
    }


    private boolean isInValidValue(String[] inValidValues, boolean isDefault, Object field) {

        boolean flag = false;
        if(Objects.nonNull(inValidValues) && inValidValues.length > 0){
            if(inValidValues.length == 1){
                flag = field.equals(inValidValues[0]);
            }else {
                for(int i=0; i<inValidValues.length; i++){
                    if(field.equals(inValidValues[i])){
                        flag = true;
                        break;
                    }
                }
            }
        }

        //如果带上默认值
        if(isDefault){
            return flag || ((String) field).length() == 0 || field.equals(BaseConstants.PARENT_LEVEL_ALL);
        }

        return flag;
    }

    private void setValueToNull(Field field,Object arg) throws IllegalAccessException {
        field.setAccessible(true);
        field.set(arg,null);
    }

}
