package com.mkt.agent.common.fast.enums;

/**
 * @description: 策略枚举
 * @author: ErHu.Zhao
 * @create: 2024-04-08
 **/
public enum StrategyEnums {

    CheckPointDesensMappingStrategy("CheckPointDesensMappingStrategy", "check point方式进行代理脱敏"),
    CheckPointTransferOfAgentStrategy("CheckPointTransferOfAgentStrategy", "check point方式以代理维度进行玩家-代理关系映射"),
    InitDesensMappingStrategy("InitDesensMappingStrategy", "初始化方式进行代理脱敏"),
    InitTransferOfAgentStrategy("InitTransferOfAgentStrategy", "初始化方式以代理维度进行玩家-代理关系映射"),
    ListenerDesensMappingStrategy("ListenerDesensMappingStrategy", "监听器方式进行代理脱敏"),
    ListenerTransferOfAgentStrategy("ListenerTransferOfAgentStrategy", "监听器方式以代理维度进行玩家-代理关系映射"),
    CheckPointTransferOfUserStrategy("CheckPointTransferOfUserStrategy", "check point方式以玩家维度进行玩家-代理关系映射"),
    InitTransferOfUserStrategy("InitTransferOfUserStrategy", "初始化方式以玩家维度进行玩家-代理关系映射"),
    ListenerTransferOfUserStrategy("ListenerTransferOfUserStrategy", "监听器方式以玩家维度进行玩家-代理关系映射");
    String strategyName;

    String desc;

    StrategyEnums(String strategyName, String desc) {
        this.strategyName = strategyName;
        this.desc = desc;
    }

    public String getStrategyName() {
        return strategyName;
    }

    public String getDesc() {
        return desc;
    }
}
