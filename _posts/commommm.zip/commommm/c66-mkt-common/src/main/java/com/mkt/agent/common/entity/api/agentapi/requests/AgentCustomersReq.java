package com.mkt.agent.common.entity.api.agentapi.requests;

import com.mkt.agent.common.entity.BasePageRequest;
import com.mkt.agent.common.entity.PageReq;
import com.mkt.agent.common.entity.PageRequest;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @ClassName AgentCustomersReq
 * @Author Jojo
 * @Date 2023/8/30 10:00
 * @Version 1.0
 **/
@Data
public class AgentCustomersReq extends PageReq {

    @ApiModelProperty(value = "customerIdStart")
    private String customerIdStart;

    @ApiModelProperty(value = "customerIds")
    private List<String> customerIds;
}
