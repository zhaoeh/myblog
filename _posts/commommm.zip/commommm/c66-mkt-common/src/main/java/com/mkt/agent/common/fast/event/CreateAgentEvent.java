package com.mkt.agent.common.fast.event;

import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.fast.core.FastContext;
import org.springframework.context.ApplicationEvent;

import java.util.List;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-04-02
 **/
public class CreateAgentEvent extends ApplicationEvent {

    /**
     * 新增的代理名称
     */
    private List<TAgentCustomers> agents;

    private FastContext fastContext;

    public CreateAgentEvent(Object source, List<TAgentCustomers> agents, FastContext fastContext) {
        super(source);
        this.agents = agents;
        this.fastContext = fastContext;
    }

    public List<TAgentCustomers> getAgents() {
        return agents;
    }

    public FastContext getFastContext() {
        return fastContext;
    }
}
