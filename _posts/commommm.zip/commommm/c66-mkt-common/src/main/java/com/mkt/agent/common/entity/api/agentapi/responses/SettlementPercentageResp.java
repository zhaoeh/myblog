package com.mkt.agent.common.entity.api.agentapi.responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @ClassName SettlementPercentageResp 提供方案给佣金记录
 * @Author TJSAustin
 * @Date 2023/7/14 10:00
 * @Version 1.0
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SettlementPercentageResp implements Serializable {

    private BigDecimal rangeOfTurnoverStart;

    private BigDecimal rangeOfTurnoverEnd;

    private BigDecimal allGamesPercentage;

    private BigDecimal bingoPercentage;

    private BigDecimal slotPercentage;

    private BigDecimal sportsPercentage;

    private BigDecimal pokerPercentage;

    private BigDecimal ebingoPercentage;

    private BigDecimal casinoPercentage;

    private BigDecimal fishingPercentage;

    private int order;

    public BigDecimal getAllGamesPercentage() {
        return allGamesPercentage.divide(denominator());
    }

    public BigDecimal getBingoPercentage() {
        return bingoPercentage.divide(denominator());
    }

    public BigDecimal getSlotPercentage() {
        return slotPercentage.divide(denominator());
    }

    public BigDecimal getSportsPercentage() {
        return sportsPercentage.divide(denominator());
    }

    public BigDecimal getPokerPercentage() {
        return pokerPercentage.divide(denominator());
    }

    public BigDecimal getEbingoPercentage() {
        return ebingoPercentage.divide(denominator());
    }

    public BigDecimal getCasinoPercentage() {
        return casinoPercentage.divide(denominator());
    }

    public BigDecimal getFishingPercentage() {
        return fishingPercentage.divide(denominator());
    }

    public BigDecimal denominator(){
        return new BigDecimal("100");
    }
}
