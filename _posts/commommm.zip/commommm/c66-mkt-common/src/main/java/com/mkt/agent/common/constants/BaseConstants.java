package com.mkt.agent.common.constants;

public class BaseConstants {


    // 分页佣金记录常量

    public static final String pageFlag = "page-sum-";
    public static final String searchFlag = "search-sum-";

    // 查询佣金记录常量
    public static final String CommissionAmount = "commissionAmount";
    public static final String ActualCommissionAmount = "actualCommissionAmount";
    public static final String AppendCommissionAmount = "appendCommissionAmount";

    public static final String Turnover = "turnover";
    public static final String GGR = "GGR";
    public static final String WinAndLoss = "winAndLoss";
    public static final String GenerateCommission = "GenerateCommission";

    public static final String Deposit = "deposit";
    public static final String Withdrawal = "withdrawal";

    public static final String Insert = "Insert";
    public static final String Current = "Current";
    public static final String Total = "Total";

    public static final String CommissionRecordListServiceFlag = "CommissionRecordListServiceFlag";
    public static final String CommissionRecordDetailServiceFlag = "CommissionRecordDetailServiceFlag";

    public static final String ShaSignFormatX = "%02X";

    public static final String ExecutorCommission = "commission";
    public static final String ExecutorReport = "report";

    public static final String ExecutorJob = "Job";

    public static final String PHP = "PHP";

    public static final String ORG_CODE_SEP = "-";

    public static final Integer MONTH_FLAG = 1;

    public static final Integer DAY_FLAG = 0;

    public static final String START_TIME=" 00:00:00";
    public static final String END_TIME=" 23:59:59";

    // 第三方接口返回常量

    public static final String DATA = "data";
    public static final String STATUS = "status";


    public static final String DEFAULT_AMOUNT = "0.00";

    public static final String DEFAULT_AMOUNT4 = "4.00";


    public static final String MONTH_APPEND_DAY = "01";


    public static final Integer DELETE_FLAG = 0;

    public static final String SYSTEM = "SYSTEM";

    public static final Integer BIG_DECIMAL_NUMS = 2;

    public static final Integer BIG_DECIMAL_DIV_NUM = 6;


    public static final String C66_ADMIN = "acc66";

    public static final String NULL_AGENT = "&null&agent&";

    public static final Integer C66_AGENT_LEVEL = 0;

    public static final Integer WS_AGENT = 3;

    public static final Integer WS_PLAYER = 1;


    public static final String LOG_START_FLAG = "--------------";

    public static final String LOG_END_FLAG = ">>>>>>>>>>>>>>";


    public static final String ASC = "ASC";
    public static final String DESC = "DESC";

    public static final String TOKEN_PREFIX = "accessToken";

    //返回结果码-成功
    public static final String SUCCESS = "0000";
    public static final String SUCCESS_STR = "sucess!";

    //返回结果码-失败
    public static final String FAILURE = "1111";

    //default date
    public static final String DEFAULT_DATE = "2023-01-01";

    // Fund Record
    public static final String FundRecordAmount = "fundRecordAmount";
    public static final String FundRecordAmountSum = "fundRecordAmountSum";

    //代理发生关系变更  未消费
    public static final int AGENT_UPDATE_LOG_STATUS_VILID = 0;

    //已消费
    public static final int AGENT_UPDATE_LOG_STATUS_INVILID = 1;

    public static final String DATETIMEPATTERN = "yyyy-MM-dd HH:ss:mm";

    //代理是否已删除 1 已删除
    public static final int AGENTS_IS_DELETED = 1;
    //0 未删除
    public static final int AGENTS_NO_DELETED = 0;

    //代理是否被禁用 0 禁用
    public static final int AGENTS_IS_ENABLE = 0;
    //1 启用
    public static final int AGENTS_IS_ABLE = 1;

    public static final int PLAYER_REPORT_MAX_PAGECOUNT = 10000;

    public static final String PARENT_LEVEL_ALL = "-1";
}
