package com.mkt.agent.common.fast.strategy;

import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.common.fast.core.FastPersist;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @description: 玩家-代理-关系 代理维度 初始化策略
 * @author: ErHu.Zhao
 * @create: 2024-04-08
 **/
@Component
@Slf4j
public class InitTransferOfAgentStrategy implements RemediationStrategy {
    private final FastPersist fastPersist;

    public InitTransferOfAgentStrategy(FastPersist fastPersist) {
        this.fastPersist = fastPersist;
    }

    @Override
    public String strategy() {
        return StrategyEnums.InitTransferOfAgentStrategy.getStrategyName();
    }

    @Override
    public void afterSuccess(FastContext fastContext, String callable, List<String> params) {
        log.info("afterSuccess with InitTransferOfAgentStrategy，初始化-代理维度更新玩家转移成功");
//        fastPersist.batchUpdateUsersStatus(holder, params);
    }

    @Override
    public void afterFailed(FastContext fastContext, String callable, List<String> params) {
        log.info("afterFailed with InitTransferOfAgentStrategy，初始化-代理维度更新玩家转移失败");
    }
}
