package com.mkt.agent.common.annotation;

import com.mkt.agent.common.config.CommonConfig;
import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

/**
 * @program: mkt-agent
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-12-06 16:34
 */
@Target({ElementType.TYPE, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
@Import(CommonConfig.class)
public @interface EnableCommon {
}
