package com.mkt.agent.common.annotation;

import com.mkt.agent.common.hook.ApplicationStartedListener;
import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

/**
 * @program: mkt-agent
 * @description: 开启容器启动监听
 * @author: Erhu.Zhao
 * @create: 2024-01-04 16:34
 */
@Target({ElementType.TYPE, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
@Import(ApplicationStartedListener.class)
public @interface EnableStartedListener {
}
