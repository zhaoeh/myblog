package com.mkt.agent.common.player.processor;

import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.mkt.agent.common.config.DashBoardConfig;
import com.mkt.agent.common.config.PlayerReportConfig;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse;
import com.mkt.agent.common.player.model.PlayerMapperHolder;
import com.mkt.agent.common.player.model.TAgentCountGroup;
import com.mkt.agent.common.entity.TAgentRefreshLog;
import com.mkt.agent.common.utils.CommonUtil;
import com.mkt.agent.common.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @description: player report 公共组件
 * @author: ErHu.Zhao
 * @create: 2024-01-31
 **/
@Component
@Slf4j
public class TransProcessor {

    private final PlayerReportConfig playerReportConfig;
    private final Gson gson;
    private final Integer asyncLimit;

    public TransProcessor(PlayerReportConfig playerReportConfig, Gson gson, @Value("${playerReport.asyncLimit:50000}") Integer asyncLimit) {
        this.playerReportConfig = playerReportConfig;
        this.gson = gson;
        this.asyncLimit = asyncLimit;
    }

    /**
     * 对当前代理直属用户某个时间范围内的交易总数按照日期进行分组聚合
     *
     * @param currentAgentTransCount
     */
    public List<TAgentCountGroup> groupCurrentAgentDirectCount(String agentName, List<TAgentCountGroup> currentAgentTransCount) {
        if (CollectionUtils.isEmpty(currentAgentTransCount)) {
            return currentAgentTransCount;
        }
        List<TAgentCountGroup> currentAgentDirectCount = groupByDashDate(currentAgentTransCount).
                stream().map(list -> list.stream().reduce(this::reduceDirectCount).orElse(null)).filter(a -> Objects.nonNull(a)).map(e -> {
                    e.setAgentName(agentName);
                    e.setTotalCount(e.getSelfCount() + e.getDirectCount() + e.getDownCount());
                    return e;
                }).collect(Collectors.toList());
        return currentAgentDirectCount;
    }

    /**
     * 根据dashDate分组
     *
     * @param sources
     * @return
     */
    public Collection<List<TAgentCountGroup>> groupByDashDate(List<TAgentCountGroup> sources) {
        if (CollectionUtils.isEmpty(sources)) {
            return Collections.emptyList();
        }
        return sources.stream().filter(a -> Objects.nonNull(a)).collect(Collectors.groupingBy(TAgentCountGroup::getDashDate)).values();
    }

    public Collection<List<TAgentCountGroup>> groupAndSortByActionType(List<TAgentCountGroup> sources) {
        if (CollectionUtils.isEmpty(sources)) {
            return Collections.emptyList();
        }
        return sources.stream().filter(a -> Objects.nonNull(a)).collect(Collectors.groupingBy(TAgentCountGroup::getActionType)).values().
                stream().sorted(Comparator.comparing(l->l.stream().findFirst().orElse(TAgentCountGroup.builder().build()).getActionType(),Comparator.reverseOrder())).collect(Collectors.toList());
    }

    public Map<Integer,List<TAgentCustomers>> groupByAgentLevel(List<TAgentCustomers> sources) {
        if (CollectionUtils.isEmpty(sources)) {
            return Collections.emptyMap();
        }
        return sources.stream().filter(a -> Objects.nonNull(a)).collect(Collectors.groupingBy(TAgentCustomers::getAgentLevel));
    }

    /**
     * 聚合两个 TAgentCountGroup 对象
     *
     * @param left
     * @param right
     * @return
     */
    public TAgentCountGroup reduceDirectCount(TAgentCountGroup left, TAgentCountGroup right) {
        if (Objects.nonNull(left) && Objects.nonNull(right)) {
            left.setDirectCount(left.getDirectCount() + right.getDirectCount());
            left.setDownCount(left.getDownCount() + right.getDownCount());
            left.setSelfCount(left.getSelfCount() + right.getSelfCount());
        }
        return left;
    }

    /**
     * 聚合两个 TAgentCountGroup 对象(包含total count)
     *
     * @param left
     * @param right
     * @return
     */
    public TAgentCountGroup reduceAllDirectCount(TAgentCountGroup left, TAgentCountGroup right) {
        if (Objects.nonNull(left) && Objects.nonNull(right)) {
            reduceDirectCount(left, right);
            left.setTotalCount(left.getTotalCount() + right.getTotalCount());
        }
        return left;
    }


    /**
     * 查询目标代理用户在指定日期范围内的下级用户的明细count
     *
     * @param commonLowerUsersMapper
     * @param targetAgentsTransCountMapper
     * @return
     */
    public List<TAgentCountGroup> collectUsersCounts(Function<TAgentCountGroup, List<String>> commonLowerUsersMapper,
                                                     Function<TAgentCountGroup, List<TAgentCountGroup>> targetAgentsTransCountMapper,
                                                     TAgentCountGroup request) {
        if (CollectionUtils.isEmpty(request.getTargetAgents())) {
            return Collections.emptyList();
        }
        // 查询查询目标代理(目标代理可能是一个，也可能是多个)的下级用户（可能是所有下级团队，也可能是下级代理，也可能是下级直属用户，主要以commonLowerUsersMapper做区分）
        List<String> lowerUsers = commonLowerUsersMapper.apply(request);
        log.info("collectUsersCounts for current agentAccount {},targetAgents size is {},the lowerUsers size is {}", request.getAgentName(), request.getTargetAgents().size(), lowerUsers.size());
        if (CollectionUtils.isEmpty(lowerUsers)) {
            return Collections.emptyList();
        }
        request.setQueryUsers(lowerUsers);
        return queryTargetUsersCount(targetAgentsTransCountMapper, request);
    }

    /**
     * 查询目标用户集的count列表
     *
     * @param targetAgentsTransCountMapper
     * @return
     */
    public List<TAgentCountGroup> queryTargetUsersCount(Function<TAgentCountGroup, List<TAgentCountGroup>> targetAgentsTransCountMapper, TAgentCountGroup request) {
        //查询查询目标代理(目标代理可能是一个，也可能是多个)的指定用户集的交易总数
        if (!CollectionUtils.isEmpty(request.getQueryUsers())) {
            List<TAgentCountGroup> transCounts = this.queryTargetUsersTransCountByDay(targetAgentsTransCountMapper, request);
            return transCounts;
        }
        return Collections.emptyList();
    }

    /**
     * 查询目标用户集按天分组后的交易总数
     *
     * @param targetAgentsTransCountMapper
     * @param queryReq
     * @return
     */
    public List<TAgentCountGroup> queryTargetUsersTransCountByDay(Function<TAgentCountGroup, List<TAgentCountGroup>> targetAgentsTransCountMapper, TAgentCountGroup queryReq) {
        log.info("Begin to queryTargetUsersTransCountByDay data for agent:{}", queryReq.getAgentName());
        if (queryReq.getQueryUsers().size() <= playerReportConfig.getBatchSizeByDay()) {
            return targetAgentsTransCountMapper.apply(queryReq);
        } else {
            List<TAgentCountGroup> response = buildBatchQueryForUsers(queryReq.getQueryUsers(), queryReq).stream().map(q -> targetAgentsTransCountMapper.apply(q))
                    .reduce((r1, r2) -> Stream.concat(r1.stream(), r2.stream()).collect(Collectors.toList())).orElse(Collections.emptyList());
            return this.groupCurrentAgentDirectCount(queryReq.getAgentName(), response);
        }
    }


    /**
     * 分批查询目标玩家按天为维度的明细详情
     *
     * @param transMapper
     * @param request
     * @return
     */
    public List<PlayerReportResponse> batchQueryTransDetails(Function<TAgentCountGroup, List<PlayerReportResponse>> transMapper, TAgentCountGroup request, ExecutorService executorService) {
        Assert.notNull(request, "request cannot be null");
        log.info("开始查询目标代理的交易明细数据，anentName is {}, queryUsers的 size is {}", request.getAgentName(), request.getQueryUsers().size());
        if (CollectionUtils.isEmpty(request.getQueryUsers())) {
            return Collections.emptyList();
        }
        if (request.getQueryUsers().size() <= playerReportConfig.getBatchSizeByDay()) {
            return transMapper.apply(request);
        } else {
            if (Objects.nonNull(executorService) && request.getQueryUsers().size() > asyncLimit) {
                //异步查询
                return batchQueryTransDetailsWithAsync(transMapper, request, executorService);
            } else {
                // 同步查询
                return batchQueryTransDetailsWithSync(transMapper, request);
            }
        }
    }

    /**
     * 同步查询明细
     *
     * @param transMapper
     * @param request
     * @return
     */
    public List<PlayerReportResponse> batchQueryTransDetailsWithSync(Function<TAgentCountGroup, List<PlayerReportResponse>> transMapper, TAgentCountGroup request) {
        List<PlayerReportResponse> responses = new ArrayList<>();

        Set<TAgentCountGroup> requests = buildBatchQueryForUsers(request.getQueryUsers(), request);
        for (TAgentCountGroup group : requests) {
            List<PlayerReportResponse> currentResult = transMapper.apply(group);
//            if (!playerReportConfig.ignoreMaxCountLimit()) {
//                if (responses.size() > playerReportConfig.getMaxCountLimit()) {
//                    return responses;
//                }
//            }
            if (Objects.nonNull(currentResult)) {
                responses.addAll(currentResult);
            }
        }
        return responses;
    }

    /**
     * 异步查询明细
     *
     * @param transMapper
     * @param request
     * @param executorService
     * @return
     */
    public List<PlayerReportResponse> batchQueryTransDetailsWithAsync(Function<TAgentCountGroup, List<PlayerReportResponse>> transMapper, TAgentCountGroup request, ExecutorService executorService) {
        Assert.notNull(executorService, "executorService cannot be null");
        List<PlayerReportResponse> responses = new ArrayList<>();
        ExecutorCompletionService<List<PlayerReportResponse>> executorCompletionService = new ExecutorCompletionService<>(executorService);

        Set<TAgentCountGroup> requests = buildBatchQueryForUsers(request.getQueryUsers(), request);
        List<Future<List<PlayerReportResponse>>> futures = requests.stream().map(q -> executorCompletionService.submit(() -> transMapper.apply(q))).collect(Collectors.toList());
        try {
            for (int i = 0; i < futures.size(); i++) {
                List<PlayerReportResponse> currentResult = executorCompletionService.take().get();
//                if (!playerReportConfig.ignoreMaxCountLimit()) {
//                    if (responses.size() > playerReportConfig.getMaxCountLimit()) {
//                        return responses;
//                    }
//                }
                if (Objects.nonNull(currentResult)) {
                    responses.addAll(currentResult);
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } finally {
            futures.stream().forEach(future -> future.cancel(true));
        }
        return responses;
    }

    /**
     * 构建批量查询参数
     *
     * @param queryReq
     * @return
     */
    public Set<TAgentCountGroup> buildBatchQueryForAgents(List<String> agents, TAgentCountGroup queryReq) {
        List<List<String>> batches = Lists.partition(agents, playerReportConfig.getBatchSizeByDay());
        Set<TAgentCountGroup> batchQueries = batches.stream().map(q -> newGroupBuilder(queryReq).targetAgents(q).build()).
                collect(Collectors.toSet());
        return batchQueries;
    }

    /**
     * 构建批量查询参数
     *
     * @param queryReq
     * @return
     */
    public Set<TAgentCountGroup> buildBatchQueryForUsers(List<String> users, TAgentCountGroup queryReq) {
        List<List<String>> batches = Lists.partition(users, playerReportConfig.getBatchSizeByDay());
        Set<TAgentCountGroup> batchQueries = batches.stream().map(q -> newGroupBuilder(queryReq).queryUsers(q).build()).
                collect(Collectors.toSet());
        return batchQueries;
    }

    /**
     * 重构一个新的入参对象builder
     *
     * @param old
     * @return
     */
    public TAgentCountGroup.TAgentCountGroupBuilder<?, ?> newGroupBuilder(TAgentCountGroup old) {
        return TAgentCountGroup.builder().totalType(old.getTotalType()).actionType(old.getActionType()).dataSourceType(old.getDataSourceType()).
                agentName(old.getAgentName()).parentAgentName(old.getParentAgentName()).beginDate(old.getBeginDate()).endDate(old.getEndDate())
                .dataSourceType(old.getDataSourceType()).isDeleted(old.getIsDeleted()).maxDateWithTiming(old.getMaxDateWithTiming()).isEnable(old.getIsEnable());
    }

    /**
     * 合并总数
     *
     * @param currentAgentDirectCount
     * @param downCountOfCurrentAgentGroupByDashDate
     */
    public List<TAgentCountGroup> mergeTotalCount(String agentName, List<TAgentCountGroup> selfCount, List<TAgentCountGroup> currentAgentDirectCount, List<TAgentCountGroup> downCountOfCurrentAgentGroupByDashDate) {
        List<TAgentCountGroup> merged = new ArrayList<>();
        if (!CollectionUtils.isEmpty(selfCount)) {
            merged.addAll(selfCount);
        }
        if (!CollectionUtils.isEmpty(currentAgentDirectCount)) {
            merged.addAll(currentAgentDirectCount);
        }
        if (!CollectionUtils.isEmpty(downCountOfCurrentAgentGroupByDashDate)) {
            merged.addAll(downCountOfCurrentAgentGroupByDashDate);
        }
        return this.groupCurrentAgentDirectCount(agentName, merged);
    }


    /**
     * 构建数据请求上下文集合
     *
     * @param holder
     * @return
     */
    public List<TAgentCountGroup> buildGroupCountContexts(PlayerMapperHolder holder, TAgentCountGroup param) {
        Assert.notNull(holder, "holder cannot be null");
        Assert.notNull(holder.getBiDateRangeMapper(), "biDateRangeMapper cannot be null");
        Assert.notNull(holder.getCountDateRangeMapper(), "countDateRangeMapper cannot be null");
        Assert.notNull(param, "param cannot be null");
        String dataSourceType = param.getDataSourceType();
        Assert.isTrue(Constants.FROM_ASYNC.equals(dataSourceType) || Constants.FROM_JOB.equals(dataSourceType) || Constants.FROM_SCHEDULED.equals(dataSourceType), "dataSourceType error");
        int counts = playerReportConfig.getSyncDays();

        // 查询bi表的max date
        Map<String, Object> rangeDatesOfBi = Optional.ofNullable(holder.getBiDateRangeMapper().get()).orElse(Collections.emptyMap());

        List<TAgentCountGroup> groups = new ArrayList<>();

        // 默认统计开始时间
        String begin = DateUtils.getNDaysAgo(counts).toString();
        // 默认统计结束时间(今天)
        String today = DateUtils.getNDaysAgo(0).toString();

        TAgentCountGroup.TAgentCountGroupBuilder<?, ?> defaultGroupBuilder = TAgentCountGroup.builder().isNeedAsyncUpdate(Boolean.FALSE).actionType(Constants.CLEAR).
                dataSourceType(dataSourceType);
        if (MapUtils.isEmpty(rangeDatesOfBi)) {
            groups.add(defaultGroupBuilder.build());
            return groups;
        }
        String maxBiDateInTable = DateUtils.dateToString((Date) rangeDatesOfBi.get("maxDate"));
        if (StringUtils.isBlank(maxBiDateInTable)) {
            groups.add(defaultGroupBuilder.forceClearAll(Boolean.TRUE).build());
            return groups;
        }

        // 指定清除几天前的数据
        Integer clearDays = param.getClearDays();
        // clearDays是否有效
        boolean isValidClearDays = Objects.nonNull(clearDays) && clearDays > -1;
        // 根据指定天数判断是否暴力清除count表
        boolean rsyncAfterForceClean = isValidClearDays && clearDays >= counts;

        // 异步更新，满足异步更新条件，则优先执行
        if (resetParamForAsync(param, begin, today)) {
            groups.add(param);
            return groups;
        }

        // 默认数据同步对象
        TAgentCountGroup.TAgentCountGroupBuilder<?, ?> defaultSyncWithFull  = TAgentCountGroup.builder().actionType(Constants.SYNC).
                dataSourceType(dataSourceType).beginDate(begin).endDate(today);
        // 查找count表job有效值的最新date
        String maxDateWithJobInTable = findMaxDate(holder);
        List<TAgentRefreshLog> failedRecordsWithLastTime = holder.getCountLogFailedRecordsMapper().apply(TAgentRefreshLog.builder().handlerName(Constants.SYNC_TRANS_BY_DAY_HANDLER).build());
        // job历史没有成功记录，则重新全量同步
        if (StringUtils.isBlank(maxDateWithJobInTable)) {
            groups.add(defaultGroupBuilder.forceClearAll(Boolean.TRUE).build());
            groups.add(defaultSyncWithFull.build());
            return groups;
        }

        String finalMaxBiDateInTable = maxBiDateInTable;
        int maxBiInTable = CommonUtil.convertToInt(maxBiDateInTable);
        int maxCountInTable = CommonUtil.convertToInt(maxDateWithJobInTable);

        Supplier<String> beginDateSupplier = null;
        Function<String, List<TAgentCountGroup>> others = null;
        Function<String, TAgentCountGroup> needSync = null;
        if (maxCountInTable > maxBiInTable) {
            beginDateSupplier = () -> {
                int minus = maxCountInTable - maxBiInTable;
                String beginDate = DateUtils.stringToLocalDate(maxDateWithJobInTable).minusDays(isValidClearDays && clearDays > minus ? clearDays : minus).toString();
                return beginDate;
            };
            others = beginDate -> List.of(defaultGroupBuilder.beginDate(beginDate).endDate(maxDateWithJobInTable).build());
            needSync = beginDate -> defaultGroupBuilder.actionType(Constants.SYNC).maxDateWithTiming(maxDateWithJobInTable).beginDate(beginDate).endDate(finalMaxBiDateInTable).build();

        }
        if (maxCountInTable <= maxBiInTable) {
            beginDateSupplier = () -> {
                String beginDate = isValidClearDays && CommonUtil.convertToInt(DateUtils.localDateToString(DateUtils.getNDaysAgo(clearDays))) < maxCountInTable ? DateUtils.localDateToString(DateUtils.getNDaysAgo(clearDays)) : maxDateWithJobInTable;
                return beginDate;
            };
            others = beginDate -> List.of(defaultGroupBuilder.beginDate(beginDate).endDate(maxDateWithJobInTable).build(),
                    defaultGroupBuilder.beginDate(DateUtils.getNDaysAgo(counts + 1).toString()).endDate(DateUtils.getNDaysAgo(counts + 1).toString()).build());
            needSync = beginDate -> defaultGroupBuilder.actionType(Constants.SYNC).maxDateWithTiming(maxDateWithJobInTable).beginDate(beginDate).endDate(finalMaxBiDateInTable).build();

        }
        rsyncAfterForceClean(rsyncAfterForceClean, groups, () -> defaultGroupBuilder.forceClearAll(Boolean.TRUE).build(), () -> defaultSyncWithFull.maxDateWithTiming(maxDateWithJobInTable).build(), beginDateSupplier, needSync, others, begin, failedRecordsWithLastTime);
        return groups;
    }

    private boolean resetParamForAsync(TAgentCountGroup param, String beginDate, String endDate) {
        if (Constants.FROM_ASYNC.equals(param.getDataSourceType())) {
            param.setIsNeedAsyncUpdate(Boolean.TRUE);
            param.setBeginDate(beginDate);
            param.setEndDate(endDate);
            return true;
        }
        return false;
    }

    /**
     * 新增一个同步对象
     * @param groups
     * @param syncObject
     */
    private void addSync(List<TAgentCountGroup> groups, TAgentCountGroup syncObject, String defaultBeginDate, List<TAgentRefreshLog> failedRecordsWithLastTime) {
        if(Objects.isNull(groups)){
            return;
        }
        if (Objects.isNull(syncObject)) {
            return;
        }
        TAgentCountGroup sync = operatorSyncObjectWithFail(syncObject, defaultBeginDate, failedRecordsWithLastTime);
        if (Objects.isNull(sync)) {
            return;
        }
        groups.add(sync);
    }

    /**
     * 切割日期范围，将当前日期范围切割为与上次失败日期集合范围的交集分段
     *
     * @param syncObject
     */
    public TAgentCountGroup operatorSyncObjectWithFail(TAgentCountGroup syncObject, String defaultBeginDate, List<TAgentRefreshLog> failedRecordsWithLastTime) {
        TAgentCountGroup sync = newGroupBuilder(syncObject).build();
        List<TAgentCountGroup> operators = new ArrayList<>();
        String beginDateWithSync = syncObject.getBeginDate();
        int beginWithSync = CommonUtil.convertToInt(beginDateWithSync);
        int defaultBegin = CommonUtil.convertToInt(defaultBeginDate);
        if (beginWithSync <= defaultBegin) {
            return sync;
        }

        // 上一次没有失败记录，则直接返回原始同步对象
        if (CollectionUtils.isEmpty(failedRecordsWithLastTime)) {
            return sync;
        }

        // 排序，方便下面从老到新遍历
        Collections.sort(failedRecordsWithLastTime, Comparator.comparing(TAgentRefreshLog::getBeginDate));
        TAgentCountGroup waitForHandle = newGroupBuilder(syncObject).beginDate(defaultBeginDate).endDate(DateUtils.stringToLocalDate(beginDateWithSync).minusDays(1).toString()).build();

        // 失败条数
        List<TAgentCountGroup> subDateRanges = failedRecordsWithLastTime.stream().map(record -> newGroupBuilder(waitForHandle).beginDate(record.getBeginDate()).endDate(record.getEndDate()).build()).collect(Collectors.toList());
        for (TAgentCountGroup subRange : subDateRanges) {
            if (hasIntersection(waitForHandle, subRange)) {
                int beginWithWaitFor = CommonUtil.convertToInt(waitForHandle.getBeginDate());
                int endWithWaitFor = CommonUtil.convertToInt(waitForHandle.getEndDate());

                // 如果存在交集，则根据条件收集失败集合
                if (beginWithWaitFor >= CommonUtil.convertToInt(subRange.getBeginDate()) && endWithWaitFor > CommonUtil.convertToInt(subRange.getEndDate())) {
                    operators.add(newGroupBuilder(waitForHandle).endDate(DateUtils.stringToLocalDate(subRange.getEndDate()).toString()).build());
                    continue;
                }

                if (beginWithWaitFor >= CommonUtil.convertToInt(subRange.getBeginDate()) && endWithWaitFor <= CommonUtil.convertToInt(subRange.getEndDate())) {
                    continue;
                }

                if (beginWithWaitFor <= CommonUtil.convertToInt(subRange.getBeginDate()) && endWithWaitFor >= CommonUtil.convertToInt(subRange.getEndDate())) {
                    operators.add(newGroupBuilder(waitForHandle).beginDate(subRange.getBeginDate()).endDate(subRange.getEndDate()).build());
                    continue;
                }

                if (beginWithWaitFor <= CommonUtil.convertToInt(subRange.getBeginDate()) && endWithWaitFor <= CommonUtil.convertToInt(subRange.getEndDate())) {
                    operators.add(newGroupBuilder(waitForHandle).beginDate(subRange.getBeginDate()).build());
                    continue;
                }
            }
        }
        log.info("切割后的数据同步请求集：{}", gson.toJson(operators));
        sync.setWillRetrySyncs(operators);
        return sync;
    }

    /**
     * 判断两个日期范围对象是否存在交集
     *
     * @param source
     * @param target
     * @return
     */
    private boolean hasIntersection(TAgentCountGroup source, TAgentCountGroup target) {
        Assert.notNull(source, "source cannot be null");
        Assert.notNull(target, "target cannot be null");
        return !(CommonUtil.convertToInt(source.getEndDate()) < CommonUtil.convertToInt(target.getBeginDate()) || CommonUtil.convertToInt(source.getBeginDate()) > CommonUtil.convertToInt(target.getEndDate()));
    }

    /**
     * 查找 t_agent_refresh_log 表中最新日期
     *
     * @return
     */
    private String findMaxDate(PlayerMapperHolder holder) {
        String maxDate = holder.getCountLogRangeMapper().apply(TAgentRefreshLog.builder().handlerName(Constants.SYNC_TRANS_BY_DAY_HANDLER).build());
        return maxDate;
    }

    /**
     * 根据暴力删除属性，重构组装参数
     *
     * @param rsyncAfterForceClean
     * @param groups
     * @param forceClean
     * @param fullSync
     * @param needSync
     * @param
     */
    private void rsyncAfterForceClean(Boolean rsyncAfterForceClean,
                                      List<TAgentCountGroup> groups,
                                      Supplier<TAgentCountGroup> forceClean,
                                      Supplier<TAgentCountGroup> fullSync,
                                      Supplier<String> beginDateSupplier,
                                      Function<String, TAgentCountGroup> needSync,
                                      Function<String, List<TAgentCountGroup>> othersWithClear,
                                      String defaultBeginDate,
                                      List<TAgentRefreshLog> failedRecordsWithLastTime) {
        Assert.notNull(groups, "groups cannot be null");
        if (BooleanUtils.isTrue(rsyncAfterForceClean)) {
            // 暴力删除
            groups.add(forceClean.get());
            // 重新全量同步
            addSync(groups, fullSync.get(), defaultBeginDate, failedRecordsWithLastTime);
            return;
        }
        if (Objects.isNull(beginDateSupplier)) {
            return;
        }
        String beginDate = beginDateSupplier.get();
        Assert.isTrue(StringUtils.isNotBlank(beginDate), "beginDate cannot be blank");
        if (Objects.nonNull(othersWithClear) && Objects.nonNull(needSync)) {
            groups.addAll(othersWithClear.apply(beginDate));
            addSync(groups, needSync.apply(beginDate), defaultBeginDate, failedRecordsWithLastTime);
        }
    }

    /**
     * 根据分段值切割param日期
     *
     * @param context
     * @param numSegments
     * @return
     */
    public List<TAgentCountGroup> splitDates(TAgentCountGroup context, int numSegments) {
        Assert.notNull(context, "context cannot be null");
        Assert.state(numSegments > 0, "numSegments must be more than 0");
        int thresholdOfSegments = 5;
        String beginDate = context.getBeginDate();
        String endDate = context.getEndDate();
        List<TAgentCountGroup> segments = new ArrayList<>();
        // 补充附加请求区域
        appendRetries(segments, context);
        if (StringUtils.isBlank(beginDate) || StringUtils.isBlank(endDate)) {
            segments.add(context);
            return segments;
        }
        LocalDate begin = DateUtils.stringToLocalDate(beginDate);
        LocalDate end = DateUtils.stringToLocalDate(endDate);

        long totalDays = end.toEpochDay() - begin.toEpochDay();
        // 当时间区间小于当前分批数或者小于5天，则不进行拆解（即numSegments天数或者5天内的数据，不进行拆解）
        if (totalDays < numSegments || totalDays < thresholdOfSegments) {
            segments.add(context);
            return segments;
        }
        long segmentLength = totalDays / numSegments;
        for (int i = 0; i < numSegments; i++) {
            String segmentBegin = DateUtils.localDateToString(begin.plusDays(i * segmentLength));
            String segmentEnd;
            if (i == numSegments - 1) {
                // 最后一次遍历
                segmentEnd = endDate;
            } else {
                segmentEnd = DateUtils.localDateToString(begin.plusDays((i + 1) * segmentLength).minusDays(1));
            }

            segments.add(newGroupBuilder(context).beginDate(segmentBegin).endDate(segmentEnd).build());
        }
        return segments;
    }

    private void appendRetries(List<TAgentCountGroup> segments,TAgentCountGroup context){
        List<TAgentCountGroup> retries = context.getWillRetrySyncs();
        if(CollectionUtils.isEmpty(retries)){
            return;
        }
        segments.addAll(retries);
        retries.clear();
    }
}
