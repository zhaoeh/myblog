package com.mkt.agent.common.valid.refrence.annotation;

import org.hibernate.validator.constraints.Range;

import java.lang.annotation.*;

/**
 * @description: 取值范围校验注解
 * @author: ErHu.Zhao
 * @create: 2024-01-25
 **/
@Target({ElementType.TYPE, ElementType.FIELD, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
public @interface ReferenceHolder {

    ReferenceField referenceField();

    Range range();
}
