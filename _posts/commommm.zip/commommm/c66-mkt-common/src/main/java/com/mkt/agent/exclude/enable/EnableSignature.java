package com.mkt.agent.exclude.enable;

import com.mkt.agent.exclude.config.SignatureConfig;
import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

/**
 * @program: mkt-agent
 * @description: 开启后端验签
 * @author: Erhu.Zhao
 * @create: 2024-01-04 16:34
 */
@Target({ElementType.TYPE, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
@Import(SignatureConfig.class)
public @interface EnableSignature {
}
