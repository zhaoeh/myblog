package com.mkt.agent.common.config;

import com.alibaba.nacos.api.config.annotation.NacosConfigurationProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @Description: 调用ws敏感信息加解密key配置类
 * @Author: PTMinnisLi
 * @Date: 2023/6/7
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Component
@NacosConfigurationProperties(dataId = "mkt-integration-channel.yml", prefix = "executor", autoRefreshed = true)
@RefreshScope
public class ProductKeyConfig {

    /**
     */
    @Value("${C66.ws.key01}")
    private String key01;

    /**
     * 地址
     */
    @Value("${C66.ws.key02}")
    private String key02;

    /**
     * 电话号码
     */
    @Value("${C66.ws.key03}")
    private String key03;

    /**
     * 邮箱
     */
    @Value("${C66.ws.key04}")
    private String key04;

    /**
     * 网路联系方式
     */
    @Value("${C66.ws.key05}")
    private String key05;

    /**
     * 银行帐号
     */
    @Value("${C66.ws.key06}")
    private String key06;

    /**
     * 银行卡号
     */
    @Value("${C66.ws.key07}")
    private String key07;

    @Value("${C66.ws.key08}")
    private String key08;

    /**
     * 身份证
     */
    @Value("${C66.ws.key09}")
    private String key09;


}
