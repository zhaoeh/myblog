package com.mkt.agent.common.entity.api.userapi.requests;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Description: 代理列表查询
 * @Author: PTMinnisLi
 * @Date: 2023/6/22
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AgentListCopyRequest extends AgentListRequest{

    private String levelOneAgent;

    public String getLevelOneAgent() {
        return super.getRootParentName();
    }
}
