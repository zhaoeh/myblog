package com.mkt.agent.common.fast.core;

import com.alibaba.nacos.common.utils.CollectionUtils;
import com.alibaba.nacos.common.utils.StringUtils;
import com.google.common.collect.Lists;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import com.mkt.agent.common.fast.pojo.*;
import com.mkt.agent.common.fast.strategy.RemediationStrategy;
import com.mkt.agent.common.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import java.sql.Date;
import java.sql.SQLException;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-04-01
 **/
@Component
@Slf4j
public class FastCore {
    public static final Map<String, Map<String, List<SimpleCustomers>>> CACHE = new HashMap<>();

    private static final String CACHE_KEY = "AgentsOfCurrentMap";

    private Map<String, RemediationStrategy> remediationStrategyMap = new HashMap<>();

    private final FastPersist fastPersist;

    private final FailureAnalyzer failureAnalyzer;

    private final Integer fastRetryTimes;

    private final Integer fastUsersBatchSize;

    private final FastPersist persist;


    public FastCore(ObjectProvider<Map<String, RemediationStrategy>> objectProvider,
                    FastPersist fastPersist,
                    FailureAnalyzer failureAnalyzer, FastPersist persist, FastConfig fastConfig) {
        this.fastPersist = fastPersist;
        this.failureAnalyzer = failureAnalyzer;
        this.fastRetryTimes = fastConfig.getFastRetryTimes();
        this.fastUsersBatchSize = fastConfig.getFastUsersBatchSize();
        this.persist = persist;
        Map<String, RemediationStrategy> strategyMap = objectProvider.getIfAvailable();
        if (MapUtils.isNotEmpty(strategyMap)) {
            strategyMap.forEach((k, v) -> remediationStrategyMap.put(v.strategy(), v));
        }
    }


    /**
     * 带重试机制，处理代理脱敏映射
     *
     * @param mapping
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public int handleAgentMappingWithRetry(FastContext fastContext, StrategyEnums strategy, List<AgentCustomersMapping> mapping, int initStart) {
        if (CollectionUtils.isEmpty(mapping)) {
            return 0;
        }

        RemediationStrategy remediationStrategy = remediationStrategyMap.get(strategy.getStrategyName());
        int updateResult;
        try {
            updateResult = fastPersist.batchInsertAgentMapping(fastContext, mapping);
            doSuccess(remediationStrategy, fastContext, "代理脱敏映射", mapping.stream().map(AgentCustomersMapping::getAgentName).collect(Collectors.toList()));
            return updateResult;
        } catch (Exception e) {
            // 超过重试次数还是失败，直接抛出异常，事务回滚
            if (initStart > fastRetryTimes) {
                doFailed(remediationStrategy, fastContext, "代理脱敏映射", mapping.stream().map(AgentCustomersMapping::getAgentName).collect(Collectors.toList()));
                throw e;
            }
            mapping = failureAnalyzer.failureAnalysisOfHandleAgentMappingWithRetry(fastContext, initStart, mapping);
            initStart++;
            // 每次重试，重新生成当前批次的uuid，防止uuid意外重复
            mapping = packageAgentMappings(mapping.stream().map(AgentCustomersMapping::getAgentName).collect(Collectors.toList()), FastUtils.generateUuid(mapping.size()));
            updateResult = handleAgentMappingWithRetry(fastContext, strategy, mapping, initStart);
        }
        return updateResult;
    }

    /**
     * 带重试机制，插入玩家-代理关系
     *
     * @param sql
     * @param factory
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public int batchInsertWithUserMappingWithRetry(FastContext fastContext, StrategyEnums strategy, List<DailyMktUserMapping> currentUsers, String sql, SqlSessionFactory factory, int initStart) {
        if (StringUtils.isBlank(sql)) {
            return 0;
        }

        RemediationStrategy remediationStrategy = remediationStrategyMap.get(strategy.getStrategyName());

        int updateResult;
        SqlSession sqlSession = factory.openSession(ExecutorType.BATCH);
        try {
//            sqlSession.getConnection().setAutoCommit(false);
            // 开启事务
//            log.info("sql is : {}", sql);

            updateResult = sqlSession.getConnection().createStatement().executeUpdate(sql);
            doSuccess(remediationStrategy, fastContext, "玩家-代理关系更新（玩家维度）", currentUsers.stream().map(DailyMktUserMapping::getLoginName).collect(Collectors.toList()));
            sqlSession.commit();
            return updateResult;
        } catch (SQLException e) {
            log.error("SQLException is ", e);
        } catch (Exception e) {
            if (initStart > fastRetryTimes) {
                sqlSession.rollback();
                doFailed(remediationStrategy, fastContext, "玩家-代理关系更新（玩家维度）", currentUsers.stream().map(DailyMktUserMapping::getLoginName).collect(Collectors.toList()));
                log.error("插入 t_daily_mkt_user_mapping 出错,", e);
                throw e;
            }

            initStart++;
            batchInsertWithUserMappingWithRetry(fastContext, strategy, currentUsers, sql, factory, initStart);
        } finally {
            sqlSession.close();
        }
        return 0;
    }

    /**
     * 带重试机制，更新玩家-代理关系
     *
     * @param fastContext
     * @param strategy
     * @param agentNames
     * @param sql
     * @param factory
     * @param initStart
     * @param <T>
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public <T> int batchUpdateWithUserMappingWithRetry(FastContext fastContext,
                                                       StrategyEnums strategy,
                                                       List<String> agentNames,
                                                       String sql,
                                                       SqlSessionFactory factory,
                                                       int initStart) {
        if (StringUtils.isBlank(sql)) {
            return 0;
        }
        RemediationStrategy remediationStrategy = remediationStrategyMap.get(strategy.getStrategyName());

        int updateResult;
        SqlSession sqlSession = factory.openSession(ExecutorType.BATCH);
        try {
//            log.info("sql is : {}", sql);
            updateResult = sqlSession.getConnection().createStatement().executeUpdate(sql);
            sqlSession.commit();
            doSuccess(remediationStrategy, fastContext, "玩家-代理关系更新（代理维度）", agentNames);
            return updateResult;
        } catch (Exception e) {
            if (initStart > fastRetryTimes) {
                sqlSession.rollback();
                doFailed(remediationStrategy, fastContext, "玩家-代理关系更新（代理维度）", agentNames);
                log.error("更新 t_daily_mkt_user_mapping 出错,", e);
                return 0;
            }
            initStart++;
            batchUpdateWithUserMappingWithRetry(fastContext, strategy, agentNames, sql, factory, initStart);
        } finally {
            sqlSession.close();
        }
        return 0;
    }

    /**
     * 组装脱敏映射插入集合
     *
     * @param allLoginNames
     * @param uuids
     * @return
     */
    public List<AgentCustomersMapping> packageAgentMappings(List<String> allLoginNames, List<String> uuids) {
        return IntStream.range(0, allLoginNames.size()).mapToObj(item -> AgentCustomersMapping.builder().agentName(allLoginNames.get(item)).agentMapping(uuids.get(item)).build()).collect(Collectors.toList());
    }

    /**
     * 将代理脱敏映射集合转换成map(agentName->agentMapping)
     *
     * @param mapping
     * @return
     */
    public Map<String, String> agentCustomersMapping2Map(List<AgentCustomersMapping> mapping) {
        return mapping.stream().collect(Collectors.toMap(AgentCustomersMapping::getAgentName, AgentCustomersMapping::getAgentMapping, (k1, k2) -> k2));
    }

    /**
     * 获取批次
     *
     * @param totalSize
     * @param batchSize
     * @return
     */
    public int obtainsBatches(int totalSize, int batchSize) {
        if (totalSize <= batchSize) {
            return 1;
        }
        return (int) Math.ceil((double) totalSize / batchSize);
    }

    /**
     * 获取玩家集中有效的关联代理
     *
     * @param users
     * @return
     */
    public List<TAgentCustomers> obtainRelationAgentsFromUsers(List<TCustomerLayer> users) {
        if (CollectionUtils.isEmpty(users)) {
            return Collections.emptyList();
        }
        users = users.stream().filter(user -> StringUtils.isNotBlank(user.getParentLoginName()) && StringUtils.isNotBlank(user.getLoginName())).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(users)) {
            return Collections.emptyList();
        }
        List<TAgentCustomers> agents = Stream.concat(users.stream().map(TCustomerLayer::getParentLoginName),
                        users.stream().filter(user -> BaseConstants.WS_AGENT.equals(user.getCustomerType())).map(TCustomerLayer::getLoginName)).
                distinct().filter(item -> !BaseConstants.C66_ADMIN.equals(item)).map(name -> TAgentCustomers.builder().loginName(name).build()).collect(Collectors.toList());
        return agents;
    }

    /**
     * 获取目标代理的状态
     *
     * @param agent
     * @return
     */
    public int obtainTargetStatusOfAgent(TAgentCustomers agent) {
        return BaseConstants.AGENTS_NO_DELETED == agent.getIsDeleted() && BaseConstants.AGENTS_IS_ABLE == agent.getIsEnable() ? 1 : 0;
    }

    /**
     * 获取目标代理的状态
     *
     * @param agent
     * @return
     */
    public int obtainTargetStatusOfAgent(SimpleCustomers agent) {
        return BaseConstants.AGENTS_NO_DELETED == agent.getIsDeleted() && BaseConstants.AGENTS_IS_ABLE == agent.getIsEnable() ? 1 : 0;
    }

    /**
     * 获取当前玩家集和中本身是玩家且直属是acc66的玩家集
     *
     * @param users
     * @return
     */
    public List<TCustomerLayer> obtainWithSelfIsPlayerAndParentIsAcc66(List<TCustomerLayer> users) {
        if (CollectionUtils.isEmpty(users)) {
            return Collections.emptyList();
        }
        users = users.stream().filter(user -> StringUtils.isNotBlank(user.getLoginName()) &&
                BaseConstants.WS_PLAYER.equals(user.getLoginName()) &&
                BaseConstants.C66_ADMIN.equals(user.getParentLoginName())).collect(Collectors.toList());
        return users;
    }


    /**
     * 获取目标代理集的状态
     *
     * @param agents
     * @return
     */
    public Integer obtainTargetStatus(List<TAgentCustomers> agents) {
        if (CollectionUtils.isEmpty(agents)) {
            return null;
        }
        Integer targetStatus = agents.stream().map(e -> obtainTargetStatusOfAgent(e)).findFirst().orElse(null);
        return targetStatus;
    }

    /**
     * 查询null代理或者acc66顶级代理的脱敏映射
     *
     * @return
     */
    public Map<String, String> queryNullOrAcc66AgentMapping(FastContext fastContext) {
        List<AgentCustomersMapping> nullOrAcc66AgentsMappings = fastPersist.queryAgentsMappingList(fastContext, List.of(BaseConstants.C66_ADMIN, BaseConstants.NULL_AGENT));
        Map<String, String> nullOrAcc66AgentsMapping = new HashMap<>(12);
        if (CollectionUtils.isNotEmpty(nullOrAcc66AgentsMappings)) {
            nullOrAcc66AgentsMapping = nullOrAcc66AgentsMappings.stream().collect(Collectors.toMap(AgentCustomersMapping::getAgentName, AgentCustomersMapping::getAgentMapping, (k1, k2) -> k2));
        }
        return nullOrAcc66AgentsMapping;
    }

    /**
     * 获取所有待脱敏映射的代理名集合
     *
     * @param nullOrAcc66AgentsMapping
     * @return
     */
    public List<String> obtainWaitForMappingAgents(FastContext fastContext, Map<String, String> nullOrAcc66AgentsMapping) {
        List<String> waitForMappingAgents = packageNullOrAcc66AgentContainerIfNeed(nullOrAcc66AgentsMapping);
        List<String> allNotMappingLoginNames = fastContext.getSelectSimpleCustomers().apply(null, 0).stream().map(SimpleCustomers::getLoginName).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(allNotMappingLoginNames)) {
            waitForMappingAgents.addAll(allNotMappingLoginNames);
        }
        log.info("allNotMappingLoginNames(contains null or acc66 agents) size is {}", allNotMappingLoginNames.size());
        return waitForMappingAgents;
    }


    /**
     * 根据条件添加null代理和acc66代理作为脱敏映射容器
     *
     * @param nullOrAcc66AgentsMapping
     * @return
     */
    public List<String> packageNullOrAcc66AgentContainerIfNeed(Map<String, String> nullOrAcc66AgentsMapping) {
        List<String> waitForMappingAgents = new ArrayList<>();
        if (MapUtils.isEmpty(nullOrAcc66AgentsMapping)) {
            waitForMappingAgents.add(BaseConstants.C66_ADMIN);
            waitForMappingAgents.add(BaseConstants.NULL_AGENT);
        } else {
            String acc66Mapping = nullOrAcc66AgentsMapping.get(BaseConstants.C66_ADMIN);
            if (StringUtils.isBlank(acc66Mapping)) {
                // 生成acc66的uuid
                waitForMappingAgents.add(BaseConstants.C66_ADMIN);
            }
            String nullMapping = nullOrAcc66AgentsMapping.get(BaseConstants.NULL_AGENT);
            if (StringUtils.isBlank(nullMapping)) {
                // 生成null代理的uuid
                waitForMappingAgents.add(BaseConstants.NULL_AGENT);
            }
        }
        return waitForMappingAgents;
    }


    /**
     * 查询代理表中未脱敏映射的差集
     *
     * @param agents
     * @return
     */
    public List<String> queryDiffs(FastContext fastContext, List<String> agents) {
        if (CollectionUtils.isEmpty(agents)) {
            return Collections.emptyList();
        }
        agents = agents.stream().filter(d -> !BaseConstants.C66_ADMIN.equals(d)).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(agents)) {
            return Collections.emptyList();
        }
        // 查询当前请求集中已经被脱敏的代理集合
        List<SimpleCustomers> requestAgents = fastContext.getSelectSimpleCustomers().apply(agents, null);
        Map<String, SimpleCustomers> map = requestAgents.stream().collect(Collectors.toMap(SimpleCustomers::getLoginName, Function.identity()));
        agents = agents.stream().filter(item -> map.containsKey(item)).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(agents)) {
            return Collections.emptyList();
        }
        List<String> isMappingAgents = requestAgents.stream().filter(item -> item.getIsMappingDone() == 1).map(SimpleCustomers::getLoginName).collect(Collectors.toList());
        if (agents.size() == 1) {
            return CollectionUtils.isEmpty(isMappingAgents) ? agents : Collections.emptyList();
        }
        return agents.stream().filter(e -> !isMappingAgents.contains(e)).collect(Collectors.toList());
    }

    /**
     * 针对创建代理补救
     *
     * @param mapping
     */
    @Transactional(rollbackFor = Exception.class)
    public boolean wrapHandleAgentMappingWithRetry(FastContext fastContext, StrategyEnums strategy, List<AgentCustomersMapping> mapping) {
        try {
            int result = handleAgentMappingWithRetry(fastContext, strategy, mapping, 0);
            log.info("代理映射补救完毕，本次补救个数为：{}", result);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 获取目标代理集的上级代理链路
     */
    public Map<String, List<SimpleCustomers>> obtainSuperAgentChainsMap(FastContext fastContext, List<String> agentNames, boolean supportCache) {
        if (supportCache) {
            Map<String, List<SimpleCustomers>> value = CACHE.get(CACHE_KEY);
            if (Objects.isNull(value)) {
                value = doObtainSuperAgentsChainsMap(fastContext, agentNames);
                CACHE.put(CACHE_KEY, value);
            }
            return value;
        }
        return doObtainSuperAgentsChainsMap(fastContext, agentNames);
    }

    private Map<String, List<SimpleCustomers>> doObtainSuperAgentsChainsMap(FastContext fastContext, List<String> agentNames) {
        Map<String, List<SimpleCustomers>> value;
        List<SimpleCustomers> superAgentsOfCurrent = persist.querySuperAgentsByNames(fastContext, agentNames);
        if (CollectionUtils.isEmpty(superAgentsOfCurrent)) {
            return Collections.emptyMap();
        }
        value = superAgentsOfCurrent.stream().collect(Collectors.groupingBy(SimpleCustomers::getCurentLogin));
        if (CollectionUtils.isEmpty(superAgentsOfCurrent)) {
            return Collections.emptyMap();
        }
        return value;
    }


    /**
     * 获取指定代理集的脱敏映射表（包含null代理和acc66）
     *
     * @param fastContext
     * @param agents
     * @return
     */
    public Map<String, String> obtainDesensMapping(FastContext fastContext, List<TAgentCustomers> agents) {
        List<String> nullOrAcc66AgentsMappings = new ArrayList<>();
        nullOrAcc66AgentsMappings.add(BaseConstants.C66_ADMIN);
        nullOrAcc66AgentsMappings.add(BaseConstants.NULL_AGENT);
        List<String> params;
        if (CollectionUtils.isNotEmpty(agents)) {
            params = Stream.concat(agents.stream().map(TAgentCustomers::getLoginName), nullOrAcc66AgentsMappings.stream()).collect(Collectors.toList());
        } else {
            params = nullOrAcc66AgentsMappings;
        }
        List<AgentCustomersMapping> mapping = persist.queryAgentsMappingList(fastContext, params);
        return agentCustomersMapping2Map(mapping);
    }


    /**
     * 封装直属上级为acc66的玩家映射实体
     *
     * @param users
     * @param nullAgent
     * @param adminAgent
     * @return
     */
    public List<DailyMktUserMapping> packageUsersMappingsWithAcc66(List<TCustomerLayer> users,
                                                                   String nullAgent, String adminAgent) {
        if (CollectionUtils.isEmpty(users)) {
            return Collections.emptyList();
        }

        List<DailyMktUserMapping> currentBatchUserMappings = users.stream().map(user -> agentList2ObjWithAcc66(user, nullAgent, adminAgent, 1)).
                filter(Objects::nonNull).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(currentBatchUserMappings)) {
            return Collections.emptyList();
        }
        log.info("currentBatchUserMappingsWithAcc66 size is {}", currentBatchUserMappings.size());
        return currentBatchUserMappings;
    }

    /**
     * 组装直属上级是acc66，且自身是玩家的玩家映射实体，null代理默认为有效代理
     *
     * @param player
     * @param nullAgent
     * @param adminAgent
     * @return
     */
    private DailyMktUserMapping agentList2ObjWithAcc66(TCustomerLayer player, String nullAgent, String adminAgent, int selfStatus) {
        if (Objects.isNull(player)) {
            return null;
        }
        DailyMktUserMapping object = new DailyMktUserMapping();
        object.setLoginName(player.getLoginName());
        // 当前玩家自己的状态
        object.setSelfStatus(selfStatus);
        object.setParentDirect(adminAgent);
        object.setParentDirectStatus(1);
        object.setParentDirectLevel(0);
        object.setParentRoot(adminAgent);
        object.setCreateDate(Date.valueOf(DateUtils.stringToLocalDateTime(player.getCreateTime()).toLocalDate()));
        object.setParentOne(nullAgent);
        object.setParentOneStatus(1);
        object.setParentTwo(nullAgent);
        object.setParentTwoStatus(1);
        object.setParentThree(nullAgent);
        object.setParentThreeStatus(1);
        object.setParentFour(nullAgent);
        object.setParentFourStatus(1);
        object.setParentFive(nullAgent);
        object.setParentFiveStatus(1);
        object.setIsDeleted(0);
        return object;
    }

    /**
     * 用户下沉，统计下沉到底，null代理默认为有效代理
     *
     * @param object
     * @param nullAgent
     */
    private void refactorObject(DailyMktUserMapping object, String nullAgent) {
        if (Objects.isNull(object.getParentFive())) {
            object.setParentFive(nullAgent);
            object.setParentFiveStatus(1);
        }
        if (Objects.isNull(object.getParentFour())) {
            object.setParentFour(nullAgent);
            object.setParentFourStatus(1);
        }
        if (Objects.isNull(object.getParentThree())) {
            object.setParentThree(nullAgent);
            object.setParentThreeStatus(1);
        }
        if (Objects.isNull(object.getParentTwo())) {
            object.setParentTwo(nullAgent);
            object.setParentTwoStatus(1);
        }
        if (Objects.isNull(object.getParentOne())) {
            object.setParentOne(nullAgent);
            object.setParentOneStatus(1);
        }
        object.setIsDeleted(0);
    }


    /**
     * 组装直属用户是普通代理的玩家映射实体
     *
     * @param player
     * @param superAgentChainsMap
     * @param currentAgentsMapping
     * @param nullAgent
     * @param adminAgent
     * @return
     */
    private DailyMktUserMapping agentList2Obj(TCustomerLayer player,
                                              Map<String, List<SimpleCustomers>> superAgentChainsMap,
                                              Map<String, String> currentAgentsMapping,
                                              String nullAgent, String adminAgent) {
        if (Objects.isNull(player)) {
            return null;
        }
        DailyMktUserMapping object = new DailyMktUserMapping();
        String playerName = player.getLoginName();
        String playerParentName = player.getParentLoginName();
        object.setLoginName(playerName);
        object.setParentRoot(adminAgent);
        object.setCreateDate(Date.valueOf(DateUtils.stringToLocalDateTime(player.getCreateTime()).toLocalDate()));

        List<SimpleCustomers> superAgentList;
        if (BaseConstants.WS_AGENT.equals(player.getCustomerType())) {
            // 当前玩家本身是代理
            if (MapUtils.isEmpty(superAgentChainsMap)) {
                object.setIsDeleted(1);
                return object;
            }
            if (MapUtils.isEmpty(currentAgentsMapping)) {
                object.setIsDeleted(1);
                return object;
            }
            // 当前玩家是代理，获取当前玩家的所有上级代理链
            superAgentList = superAgentChainsMap.get(playerName);
            if (CollectionUtils.isEmpty(superAgentList)) {
                object.setIsDeleted(1);
                return object;
            }

            // 获取当前玩家自己的代理信息
            SimpleCustomers agent = superAgentList.stream().filter(item -> playerName.equals(item.getCurentLogin())).findFirst().orElse(null);
            if (Objects.isNull(agent)) {
                object.setIsDeleted(1);
                return object;
            }
            int selfStatus = FastUtils.obtainStatusOfAgent(agent);
            // 直属是acc66
            if (BaseConstants.C66_ADMIN.equals(playerParentName)) {
                object = agentList2ObjWithAcc66(player, nullAgent, adminAgent, selfStatus);
            } else {
                object.setSelfStatus(selfStatus);
                object.setIsDeleted(0);
                test1(object, superAgentList, currentAgentsMapping, playerParentName);
            }

        } else {
            // 当前玩家自身是玩家
            // 直属是acc66
            if (BaseConstants.C66_ADMIN.equals(playerParentName)) {
                object = agentList2ObjWithAcc66(player, nullAgent, adminAgent, 1);
            } else {
                if (MapUtils.isEmpty(currentAgentsMapping)) {
                    object.setIsDeleted(1);
                    return object;
                }
                if (MapUtils.isEmpty(superAgentChainsMap)) {
                    object.setIsDeleted(1);
                    return object;
                }
                // 当前玩家是普通玩家，获取当前玩家直属代理的所有上级代理链
                superAgentList = superAgentChainsMap.get(player.getParentLoginName());
                if (CollectionUtils.isEmpty(superAgentList)) {
                    object.setIsDeleted(1);
                    return object;
                }
                object.setSelfStatus(1);
                object.setIsDeleted(0);
                test1(object, superAgentList, currentAgentsMapping, playerParentName);
            }
        }

        refactorObject(object, nullAgent);
        return object;
    }


    private void test2(DailyMktUserMapping object, List<SimpleCustomers> superAgentList, Map<String, String> currentAgentsMapping, String playerName, String playerParentName) {
        Map<Integer, SimpleCustomers> mapp = superAgentList.stream().collect(Collectors.toMap(SimpleCustomers::getAgentLevel, Function.identity()));

        IntStream.range(1, 6).forEach(agentLevel -> {
            SimpleCustomers ag = mapp.get(agentLevel);
            if (Objects.isNull(ag)) {
                return;
            }
            String loginName = ag.getLoginName();
            if (1 == agentLevel) {
                object.setParentOne(currentAgentsMapping.get(loginName));
                object.setParentOneStatus(ag.getIsEnable().equals(0) || ag.getIsDeleted().equals(1) ? 0 : 1);
            }
            if (2 == agentLevel) {
                object.setParentTwo(currentAgentsMapping.get(loginName));
                object.setParentTwoStatus(ag.getIsEnable().equals(0) || ag.getIsDeleted().equals(1) ? 0 : 1);
            }
            if (3 == agentLevel) {
                object.setParentThree(currentAgentsMapping.get(loginName));
                object.setParentThreeStatus(ag.getIsEnable().equals(0) || ag.getIsDeleted().equals(1) ? 0 : 1);
            }
            if (4 == agentLevel) {
                object.setParentFour(currentAgentsMapping.get(loginName));
                object.setParentFourStatus(ag.getIsEnable().equals(0) || ag.getIsDeleted().equals(1) ? 0 : 1);
            }
            if (5 == agentLevel) {
                object.setParentFive(currentAgentsMapping.get(loginName));
                object.setParentFiveStatus(ag.getIsEnable().equals(0) || ag.getIsDeleted().equals(1) ? 0 : 1);
            }
            if (loginName.equals(playerName)) {
                // 说明当前玩家是代理
                object.setSelfStatus(ag.getIsEnable().equals(0) || ag.getIsDeleted().equals(1) ? 0 : 1);
            } else {
                object.setSelfStatus(1);
            }
            if (loginName.equals(playerParentName)) {
                // 当前玩家的直属上级信息
                object.setParentDirect(currentAgentsMapping.get(loginName));
                object.setParentDirectStatus(ag.getIsEnable().equals(0) || ag.getIsDeleted().equals(1) ? 0 : 1);
            }

        });
    }


    private void test1(DailyMktUserMapping object, List<SimpleCustomers> superAgentList, Map<String, String> currentAgentsMapping, String playerParentName) {
        superAgentList.stream().forEach(ag -> {
            if (Objects.isNull(ag)) {
                return;
            }
            // 当前代理层级
            Integer agentLevel = ag.getAgentLevel();
            if (Objects.isNull(agentLevel)) {
                return;
            }
            int status = FastUtils.obtainStatusOfAgent(ag);
            // 当前代理名称
            String loginName = ag.getLoginName();
            if (1 == agentLevel) {
                object.setParentOne(currentAgentsMapping.get(loginName));
                object.setParentOneStatus(status);
            }
            if (2 == agentLevel) {
                object.setParentTwo(currentAgentsMapping.get(loginName));
                object.setParentTwoStatus(status);
            }
            if (3 == agentLevel) {
                object.setParentThree(currentAgentsMapping.get(loginName));
                object.setParentThreeStatus(status);
            }
            if (4 == agentLevel) {
                object.setParentFour(currentAgentsMapping.get(loginName));
                object.setParentFourStatus(status);
            }
            if (5 == agentLevel) {
                object.setParentFive(currentAgentsMapping.get(loginName));
                object.setParentFiveStatus(status);
            }

            if (playerParentName.equals(loginName)) {
                // 当前玩家的直属上级信息
                object.setParentDirect(currentAgentsMapping.get(loginName));
                object.setParentDirectStatus(status);
                object.setParentDirectLevel(agentLevel);
            }
        });
    }

    public List<DailyMktUserMapping> packageUsersMappings(FastContext fastContext,
                                                          List<TCustomerLayer> users,
                                                          Map<String, List<SimpleCustomers>> superAgentChainsMap,
                                                          Map<String, String> currentAgentsMapping,
                                                          String nullAgent, String adminAgent) {
        if (CollectionUtils.isEmpty(users)) {
            return Collections.emptyList();
        }
        List<DailyMktUserMapping> currentAllValidUserMappings = users.stream().map(user ->
                agentList2Obj(user, superAgentChainsMap, currentAgentsMapping, nullAgent, adminAgent)).filter(Objects::nonNull).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(currentAllValidUserMappings)) {
            return Collections.emptyList();
        }
//        List<DailyMktUserMapping> ddd = currentAllValidUserMappings.stream().filter(e -> e.getLoginName().equals("apjo02")).collect(Collectors.toList());
//        handleInvalidPlayers(holder, currentAllValidUserMappings);
        List<DailyMktUserMapping> currentValidUserMappings = currentAllValidUserMappings.stream().filter(e -> e.getIsDeleted() != 1).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(currentValidUserMappings)) {
            return Collections.emptyList();
        }
        log.info("currentValidUserMappings size is {}", currentValidUserMappings.size());
        return currentValidUserMappings;
    }

    @Transactional(rollbackFor = Exception.class)
    public int batchHandleUsersMappingWithRetry(FastContext fastContext, StrategyEnums strategy, List<DailyMktUserMapping> currentUsers, SqlSessionFactory factory) {
        if (CollectionUtils.isEmpty(currentUsers)) {
            return 0;
        }
        if (currentUsers.size() <= fastUsersBatchSize) {
            return batchInsertWithUserMappingWithRetry(fastContext, strategy, currentUsers, FastUtils.buildInsertSqlWithUserMapping(currentUsers), factory, 0);
        }

        List<List<DailyMktUserMapping>> partitionList = Lists.partition(currentUsers, fastUsersBatchSize);
        if (CollectionUtils.isEmpty(partitionList)) {
            return 0;
        }
        int update = partitionList.stream().map(b -> batchInsertWithUserMappingWithRetry(fastContext, strategy, currentUsers, FastUtils.buildInsertSqlWithUserMapping(b), factory, 0)).reduce((r1, r2) -> r1 + r2).orElse(0);
        log.info("插入 t_daily_mkt_user_mapping 结束，本次共插入{}条", update);
        return update;
    }


    /**
     * 根据上级level重构玩家-代理映射状态信息
     *
     * @param mapping
     * @param agentName2Map
     * @return
     */
    public DailyMktUserMapping refactorMappingStatusInfoByLevel(DailyMktUserMapping mapping, int level, Map<String, FastCustomers> agentName2Map) {
        FastCustomers newAgent = null;

        // 当前玩家直属用户
        String direct = mapping.getParentDirect();
        // 当前玩家名称
        String userName = mapping.getLoginName();
        String parentAgent = null;

        if (level == 1) {
            parentAgent = mapping.getParentOne();
            newAgent = agentName2Map.get(parentAgent);
            mapping.setParentOneStatus(newAgent.getTargetStatus());
        }
        if (level == 2) {
            parentAgent = mapping.getParentTwo();
            newAgent = agentName2Map.get(parentAgent);
            mapping.setParentTwoStatus(newAgent.getTargetStatus());
        }
        if (level == 3) {
            parentAgent = mapping.getParentThree();
            newAgent = agentName2Map.get(parentAgent);
            mapping.setParentThreeStatus(newAgent.getTargetStatus());
        }
        if (level == 4) {
            parentAgent = mapping.getParentFour();
            newAgent = agentName2Map.get(parentAgent);
            mapping.setParentFourStatus(newAgent.getTargetStatus());
        }
        if (level == 5) {
            parentAgent = mapping.getParentFive();
            newAgent = agentName2Map.get(parentAgent);
            mapping.setParentFiveStatus(newAgent.getTargetStatus());
        }
        if (Objects.equals(direct, parentAgent)) {
            // 当前记录中直属用户和parent相等时，同步更新直属代理状态
            mapping.setParentDirectStatus(newAgent.getTargetStatus());
        }
        if (Objects.equals(userName, parentAgent)) {
            // 当前玩家本身命中目标代理
            mapping.setSelfStatus(newAgent.getTargetStatus());
        }
        return mapping;
    }

    /**
     * 根据上级level重构玩家-代理映射上级代理链信息
     *
     * @param mapping
     * @param level
     * @param superAgentChainsMap
     * @return
     */
    public DailyMktUserMapping refactorMappingChainsInfoByLevel(DailyMktUserMapping mapping,
                                                                int level,
                                                                Map<String, List<SimpleCustomers>> superAgentChainsMap) {
        if (MapUtils.isEmpty(superAgentChainsMap)) {
            mapping.setIsDeleted(1);
            return mapping;
        }
        String parentAgent;
        if (level == 1) {
            parentAgent = mapping.getParentOne();
            return updateAgentChains(level, parentAgent, mapping, superAgentChainsMap);
        }
        if (level == 2) {
            parentAgent = mapping.getParentTwo();
            return updateAgentChains(level, parentAgent, mapping, superAgentChainsMap);
        }
        if (level == 3) {
            parentAgent = mapping.getParentThree();
            return updateAgentChains(level, parentAgent, mapping, superAgentChainsMap);
        }
        if (level == 4) {
            parentAgent = mapping.getParentFour();
            return updateAgentChains(level, parentAgent, mapping, superAgentChainsMap);
        }
        if (level == 5) {
            parentAgent = mapping.getParentFive();
            return updateAgentChains(level, parentAgent, mapping, superAgentChainsMap);
        }
        return mapping;
    }

    /**
     * 更新当前用户代理链路
     *
     * @param level
     * @param agentName
     * @param mapping
     * @param superAgentChainsMap
     * @return
     */
    private DailyMktUserMapping updateAgentChains(int level, String agentName, DailyMktUserMapping mapping, Map<String, List<SimpleCustomers>> superAgentChainsMap) {
        Assert.notNull(mapping, "mapping cannot be null");
        Assert.notNull(agentName, "agentName cannot be null");
        if (MapUtils.isEmpty(superAgentChainsMap)) {
            mapping.setIsDeleted(1);
            return mapping;
        }
        // 当前代理新的上级链路
        List<SimpleCustomers> newChain = superAgentChainsMap.get(agentName);
        if (CollectionUtils.isEmpty(newChain)) {
            mapping.setIsDeleted(1);
            return mapping;
        }
        // 新的链路映射
        Map<String, SimpleCustomers> newChainNamesMap = newChain.stream().collect(Collectors.toMap(SimpleCustomers::getLoginName, Function.identity()));
        if (MapUtils.isEmpty(newChainNamesMap)) {
            mapping.setIsDeleted(1);
            return mapping;
        }
        SimpleCustomers currentNewAgent = newChainNamesMap.get(agentName);
        if (Objects.isNull(currentNewAgent)) {
            mapping.setIsDeleted(1);
            return mapping;
        }
        String currentPlayer = mapping.getLoginName();
        if (StringUtils.isBlank(currentPlayer)) {
            mapping.setIsDeleted(1);
            return mapping;
        }
        int newStatus = obtainTargetStatusOfAgent(currentNewAgent);
        // 当前玩家为当前等级的新代理，说明当前玩家是代理，修改玩家自身状态
        if (currentPlayer.equals(agentName)) {
            mapping.setSelfStatus(newStatus);
        }
        // 当前玩家直属
        String parentDirect = mapping.getParentDirect();
        if (StringUtils.isBlank(parentDirect)) {
            mapping.setIsDeleted(1);
            return mapping;
        }
        // 当前玩家直属为当前等级的新代理，同步修改直属信息
        if (parentDirect.equals(agentName)) {
            mapping.setParentDirect(currentNewAgent.getLoginName());
            mapping.setParentDirectStatus(newStatus);
            mapping.setParentDirectLevel(currentNewAgent.getAgentLevel());
        }
        if (level == 1) {
            mapping.setParentOne(currentNewAgent.getLoginName());
            mapping.setParentOneStatus(newStatus);
            return mapping;
        }

        Map<String, SimpleCustomers> newChainLevelMap = newChain.stream().collect(Collectors.toMap(SimpleCustomers::getLoginName, Function.identity()));
        if (MapUtils.isEmpty(newChainLevelMap)) {
            mapping.setIsDeleted(1);
            return mapping;
        }
        if (level == 2) {
            // 处理一级代理
            SimpleCustomers oneAgent = newChainLevelMap.get(level - 1);
            if (Objects.isNull(oneAgent)) {
                mapping.setIsDeleted(1);
                return mapping;
            }
            mapping.setParentOne(oneAgent.getLoginName());
            mapping.setParentOneStatus(obtainTargetStatusOfAgent(oneAgent));

            // 设置当前代理的信息
            mapping.setParentTwo(currentNewAgent.getLoginName());
            mapping.setParentTwoStatus(newStatus);
            return mapping;
        }
        if (level == 3) {
            SimpleCustomers oneAgent = newChainLevelMap.get(level - 2);
            if (Objects.isNull(oneAgent)) {
                mapping.setIsDeleted(1);
                return mapping;
            }
            mapping.setParentOne(oneAgent.getLoginName());
            mapping.setParentOneStatus(obtainTargetStatusOfAgent(oneAgent));


            SimpleCustomers twoAgent = newChainLevelMap.get(level - 1);
            if (Objects.isNull(twoAgent)) {
                mapping.setIsDeleted(1);
                return mapping;
            }
            mapping.setParentTwo(twoAgent.getLoginName());
            mapping.setParentTwoStatus(obtainTargetStatusOfAgent(twoAgent));

            // 设置当前代理的信息
            mapping.setParentThree(currentNewAgent.getLoginName());
            mapping.setParentThreeStatus(newStatus);
            return mapping;
        }

        if (level == 4) {
            // 处理一级代理
            SimpleCustomers oneAgent = newChainLevelMap.get(level - 3);
            if (Objects.isNull(oneAgent)) {
                mapping.setIsDeleted(1);
                return mapping;
            }
            mapping.setParentOne(oneAgent.getLoginName());
            mapping.setParentOneStatus(obtainTargetStatusOfAgent(oneAgent));

            // 处理二级代理
            SimpleCustomers twoAgent = newChainLevelMap.get(level - 2);
            if (Objects.isNull(twoAgent)) {
                mapping.setIsDeleted(1);
                return mapping;
            }
            mapping.setParentTwo(twoAgent.getLoginName());
            mapping.setParentTwoStatus(obtainTargetStatusOfAgent(twoAgent));

            // 处理三级代理
            SimpleCustomers threeAgent = newChainLevelMap.get(level - 1);
            if (Objects.isNull(threeAgent)) {
                mapping.setIsDeleted(1);
                return mapping;
            }
            mapping.setParentThree(threeAgent.getLoginName());
            mapping.setParentThreeStatus(obtainTargetStatusOfAgent(threeAgent));

            // 设置当前代理的信息
            mapping.setParentFour(currentNewAgent.getLoginName());
            mapping.setParentFourStatus(newStatus);
            return mapping;
        }

        if (level == 5) {
            // 处理一级代理
            SimpleCustomers oneAgent = newChainLevelMap.get(level - 4);
            if (Objects.isNull(oneAgent)) {
                mapping.setIsDeleted(1);
                return mapping;
            }
            mapping.setParentOne(oneAgent.getLoginName());
            mapping.setParentOneStatus(obtainTargetStatusOfAgent(oneAgent));

            // 处理二级代理
            SimpleCustomers twoAgent = newChainLevelMap.get(level - 3);
            if (Objects.isNull(twoAgent)) {
                mapping.setIsDeleted(1);
                return mapping;
            }
            mapping.setParentTwo(twoAgent.getLoginName());
            mapping.setParentTwoStatus(obtainTargetStatusOfAgent(twoAgent));

            // 处理三级代理
            SimpleCustomers threeAgent = newChainLevelMap.get(level - 2);
            if (Objects.isNull(threeAgent)) {
                mapping.setIsDeleted(1);
                return mapping;
            }
            mapping.setParentThree(threeAgent.getLoginName());
            mapping.setParentThreeStatus(obtainTargetStatusOfAgent(threeAgent));


            // 处理四级代理
            SimpleCustomers fourAgent = newChainLevelMap.get(level - 2);
            if (Objects.isNull(fourAgent)) {
                mapping.setIsDeleted(1);
                return mapping;
            }
            mapping.setParentFour(fourAgent.getLoginName());
            mapping.setParentFourStatus(obtainTargetStatusOfAgent(fourAgent));

            // 设置当前代理的信息
            mapping.setParentFive(currentNewAgent.getLoginName());
            mapping.setParentFiveStatus(newStatus);
            return mapping;
        }
        return mapping;
    }

    private void doSuccess(RemediationStrategy strategy, FastContext fastContext, String callable, List<String> params) {
        if (Objects.nonNull(strategy)) {
            strategy.afterSuccess(fastContext, callable, params);
        }
    }

    private void doFailed(RemediationStrategy strategy, FastContext fastContext, String callable, List<String> params) {
        if (Objects.nonNull(strategy)) {
            strategy.afterFailed(fastContext, callable, params);
        }
    }

    /**
     * 处理无效玩家
     *
     * @param fastContext
     * @param currentAllUserMappings
     */
    private void handleInvalidPlayers(FastContext fastContext, List<DailyMktUserMapping> currentAllUserMappings) {
        if (CollectionUtils.isEmpty(currentAllUserMappings)) {
            return;
        }
        List<DailyMktUserMapping> currentInvalidUserMappings = currentAllUserMappings.stream().filter(e -> e.getIsDeleted() == 1).collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(currentInvalidUserMappings)) {
            List<String> invalidPlayers = currentInvalidUserMappings.stream().map(DailyMktUserMapping::getLoginName).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(invalidPlayers)) {
                fastPersist.batchUpdateUsersStatus(fastContext, invalidPlayers, -1);
            }
        }
    }

    /**
     * 构建FastQueryModel
     *
     * @param level
     * @param mappedAgent
     * @return
     */
    public FastQueryModel buildFastQueryModel(int level, String mappedAgent) {
        FastQueryModel model = new FastQueryModel();
        if (level == 1) {
            model.setParentOne(mappedAgent);
        }
        if (level == 2) {
            model.setParentTwo(mappedAgent);
        }
        if (level == 3) {
            model.setParentThree(mappedAgent);
        }
        if (level == 4) {
            model.setParentFour(mappedAgent);
        }
        if (level == 5) {
            model.setParentFive(mappedAgent);
        }
        return model;
    }

    /**
     * 构建代理脱敏映射查询参数(包含null代理和acc66代理)
     *
     * @param normalAgentNames
     * @return
     */
    public List<String> buildAgentMappingParams(List<String> normalAgentNames) {
        List<String> agentMappingParams = new ArrayList<>();
        agentMappingParams.add(BaseConstants.NULL_AGENT);
        agentMappingParams.add(BaseConstants.C66_ADMIN);
        if (CollectionUtils.isNotEmpty(normalAgentNames)) {
            agentMappingParams.addAll(normalAgentNames);
        }
        return agentMappingParams;
    }

    /**
     * 构建代理脱敏映射查询参数(包含null代理和acc66代理)
     *
     * @param normalAgentNames
     * @return
     */
    public List<String> buildAgentMappingParams(String... normalAgentNames) {
        List<String> agentMappingParams = new ArrayList<>();
        agentMappingParams.add(BaseConstants.NULL_AGENT);
        agentMappingParams.add(BaseConstants.C66_ADMIN);
        if (Objects.nonNull(normalAgentNames)) {
            for (int i = 0; i < normalAgentNames.length; i++) {
                String normal = normalAgentNames[i];
                if (StringUtils.isNotBlank(normal)) {
                    agentMappingParams.add(normal);
                }
            }
        }
        return agentMappingParams;
    }

    /**
     * 查询checkpoint表中需要补救的代理
     *
     * @param param
     * @return
     */
    public List<SimpleCustomers> queryAgentWithCheckPoint(FastContext fastContext, IncrementCheckPoint param) {
        return fastContext.getSelectAgentWithCheckPoint().apply(param);
    }

    /**
     * 查询checkPoints
     *
     * @param param
     * @return
     */
    public List<IncrementCheckPoint> queryCheckPoints(FastContext fastContext, IncrementCheckPoint param) {
        return fastContext.getSelectTargetCheckPoints().apply(param);
    }

    /**
     * 查询checkPoints count
     *
     * @param fastContext
     * @param param
     * @return
     */
    public int queryCheckPointsCount(FastContext fastContext, IncrementCheckPoint param) {
        return fastContext.getSelectTargetCheckPointsOfCount().apply(param);
    }

    /**
     * 查询代理信息
     *
     * @param fastContext
     * @param agentNames
     * @return
     */
    public List<SimpleCustomers> querySimpleCustomers(FastContext fastContext, List<String> agentNames) {
        return fastContext.getSelectSimpleCustomers().apply(agentNames, null);
    }

}
