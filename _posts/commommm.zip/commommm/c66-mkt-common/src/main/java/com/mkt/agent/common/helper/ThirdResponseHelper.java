package com.mkt.agent.common.helper;

import com.alibaba.fastjson.JSONObject;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.exception.ThirdDefaultErrorResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Objects;
import java.util.Optional;

/**
 * @description: 三方系统响应处理工具类
 * @author: ErHu.Zhao
 * @create: 2023-12-22
 **/
@Slf4j
public class ThirdResponseHelper {

    private static final String TIMESTAMP = "timestamp";

    private static final String STATUS = "status";

    private static final String ERROR = "error";

    private static final String PATH = "path";

    private static final String OBJECT_START_FLAG = "{";
    private static final String OBJECT_END_FLAG = "}";
    private static final String ARRAY_START_FLAG = "[";
    private static final String ARRAY_END_FLAG = "]";

    private static final Integer SUCCESS_CODE = 200;

    /**
     * 当三方系统异常响应采用springmvc的默认响应结构时，从三方系统获取指定类型的正常响应，并同时校验异常，不支持三方系统返回空字符串
     *
     * @param thirdResponse 三方系统原始响应
     * @param clazz         三方系统正常响应对象结构
     * @param <T>           泛型
     * @return 三方系统正常响应后的对象
     */
    public static <T> T pullDataIfExistsDefaultError(String thirdResponse, String systemFlag, Class<T> clazz) {
        log.info("third system of {} response is: {}", systemFlag, thirdResponse);
        if (StringUtils.isBlank(thirdResponse)) {
            log.error("third system of {} response is blank", systemFlag);
            throw new BusinessException(ResultEnum.THIRD_SYSTEM_RETURN_ERROR);
        }
        return (T) Optional.ofNullable(thirdResponse).filter(ThirdResponseHelper::isJsonFormat).
                map(JSONObject::parseObject).
                filter(ThirdResponseHelper::isDefaultErrorOfSpringMvc).
                map(ThirdResponseHelper::convert2ThirdDefaultErrorResponse).
                filter(ThirdResponseHelper::isDefaultErrorResponse).
                map(e -> {
                    log.error("the third system of {} return error,error code is {},error message is {}", systemFlag, e.getStatus(), e.getError());
                    throw new BusinessException(ResultEnum.THIRD_SYSTEM_RETURN_ERROR);
                }).orElseGet(() -> JSONObject.parseObject(thirdResponse, clazz));

    }

    private static boolean isJsonFormat(String source) {
        return isJsonObject(source) || isJsonArray(source);
    }

    private static boolean isJsonObject(String source) {
        return StringUtils.startsWith(source, OBJECT_START_FLAG) && StringUtils.endsWith(source, OBJECT_END_FLAG);
    }

    private static boolean isJsonArray(String source) {
        return StringUtils.startsWith(source, ARRAY_START_FLAG) && StringUtils.endsWith(source, ARRAY_END_FLAG);
    }

    /**
     * 判断三方系统返回的异常响应是否为springmvc默认包装的异常结构
     *
     * @param response 三方系统响应
     * @return 是否为springmvc默认的异常结构 true:是 false:否
     */
    private static boolean isDefaultErrorOfSpringMvc(JSONObject response) {
        return response.containsKey(TIMESTAMP) && response.containsKey(STATUS) && response.containsKey(ERROR) && response.containsKey(PATH);
    }

    /**
     * 将三方系统默认异常响应转换为对应的实体
     *
     * @param response 三方系统默认的异常响应信息
     * @return 转换后的对应实体
     */
    private static ThirdDefaultErrorResponse convert2ThirdDefaultErrorResponse(JSONObject response) {
        if (Objects.isNull(response) || response.isEmpty()) {
            return new ThirdDefaultErrorResponse();
        }
        try {
            return JSONObject.parseObject(response.toJSONString(), ThirdDefaultErrorResponse.class);
        } catch (Exception e) {
            return new ThirdDefaultErrorResponse();
        }
    }

    /**
     * 判断三方系统的响应是否包含异常信息
     *
     * @param response 三方系统的响应实体
     * @return 是否包含异常信息 true:是 false：否
     */
    private static boolean isDefaultErrorResponse(ThirdDefaultErrorResponse response) {
        return Objects.nonNull(response.getStatus()) && !SUCCESS_CODE.equals(response.getStatus());
    }

    /**
     * 包装为自定义异常
     *
     * @param ex         原始异常
     * @param message    自定义error message
     * @param resultEnum 自定义error枚举
     * @return 自定义异常
     */
    public static BusinessException businessException(Exception ex, String message, ResultEnum resultEnum) {
        if (BusinessException.class.isInstance(ex)) {
            return (BusinessException) ex;
        } else {
            log.error(message, ex);
            return new BusinessException(resultEnum);
        }
    }

    /**
     * 重载方法
     *
     * @param ex      原始异常
     * @param message 自定义 error message
     * @param code    自定义 error code
     * @return 自定义异常
     */
    public static BusinessException businessException(Exception ex, String message, Integer code) {
        if (BusinessException.class.isInstance(ex)) {
            return (BusinessException) ex;
        } else {
            log.error(message, ex);
            return new BusinessException(message, code);
        }
    }
}
