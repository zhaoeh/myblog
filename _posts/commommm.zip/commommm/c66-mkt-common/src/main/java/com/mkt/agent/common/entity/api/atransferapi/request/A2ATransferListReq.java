package com.mkt.agent.common.entity.api.atransferapi.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.entity.PageReq;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @Description 代理转代理提案实体类
 * @Classname A2ATransferListReq
 * @Date 2023/6/21 14:49
 * @Created by TJSLucian
 */
@Data
public class A2ATransferListReq extends PageReq implements Serializable{


    @ApiModelProperty(value = "产品类型 1:Bingoplus 2:Arenaplus 3:Gameplus", example = "1")
    private Integer siteId;

    @ApiModelProperty(value = "开始创建时间", example = "2023-06-10 12:31:20")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startCreateTime;

    @ApiModelProperty(value = "结束创建时间", example = "2023-06-10 12:31:20")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endCreateTime;

    @ApiModelProperty(value = "提案状态 -1:Pending 待审核 0:Approved 审核通过 -2:Pending2 待二审 2:Rejected 拒绝", example = "0")
    private Integer status;

    @ApiModelProperty(value = "提案编号 ", example = "T2023062118227813")
    private String transactionId;

    @ApiModelProperty(value = "出账玩家账号", example = "Lucian")
    private String fromAccount;

    @ApiModelProperty(value = "入账代理账号", example = "Alex")
    private String toAccount;

    @ApiModelProperty( value = "开始提案金额", example = "100")
    private BigDecimal startAmount;

    @ApiModelProperty( value = "结束提案金额", example = "120")
    private BigDecimal endAmount;

    @ApiModelProperty(required = true,value = "转账类型 0: Transfer 1: Paid Commission 2: Append Commission", example = "0")
    @NotBlank(message = "transfer_type can not be blank",groups = InputValidationGroup.Insert.class)
    private Integer transferType;

    @ApiModelProperty(value = "排序字段")
    private String order;




}
