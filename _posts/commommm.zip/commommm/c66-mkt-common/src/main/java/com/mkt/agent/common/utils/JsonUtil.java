package com.mkt.agent.common.utils;

import com.alibaba.fastjson.serializer.ValueFilter;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public abstract class JsonUtil {
    public static final ObjectMapper JSON_MAPPER=new ObjectMapper();

    static {
        JSON_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    }
    /**
     * json 字符串转list
     * @param json
     * @param clazz
     * @param <T>
     * @return
     */
    public  static  <T> List<T> toList(String json, Class<T> clazz){
        try {
            JavaType javaType = JSON_MAPPER.getTypeFactory().constructCollectionType(List.class, clazz);
            return JSON_MAPPER.readValue(json, javaType);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * json 转实体类
     * @param json
     * @param tClass
     * @param <T>
     * @return
     */
    public static <T> T toObject(String json,Class<T> tClass){
        try {
            return JSON_MAPPER.readValue(json,tClass);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * obj 转json
     * @param obj
     * @return
     */
    public static String toJson(Object obj){
        try {
            return JSON_MAPPER.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 创建 Gson 对象，忽略某些关键字参与序列化
     *
     * @param fieldNames
     * @return
     */
    public static Gson skipFieldGson(String... fieldNames) {
        Gson gson = new GsonBuilder().setExclusionStrategies(new ExclusionStrategy() {
            @Override
            public boolean shouldSkipField(FieldAttributes fieldAttributes) {
                if (Objects.isNull(fieldNames) || fieldNames.length == 0) {
                    return false;
                }
                return Arrays.stream(fieldNames).collect(Collectors.toList()).contains(fieldAttributes.getName());
            }

            @Override
            public boolean shouldSkipClass(Class<?> aClass) {
                return false;
            }
        }).create();
        return gson;
    }

    /**
     * 针对Fast json 的value添加脱敏过滤器
     *
     * @param desenstiveMap
     * @return
     */
    public static ValueFilter[] obtainValueFilter(Map<String, Function<String, String>> desenstiveMap) {
        if (MapUtils.isEmpty(desenstiveMap)) {
            return new ValueFilter[0];
        }
        ValueFilter[] filters = new ValueFilter[desenstiveMap.size()];
        List<Map.Entry<String, Function<String, String>>> mapper = new ArrayList<>(desenstiveMap.entrySet());
        for (int i = 0; i < mapper.size(); i++) {
            Map.Entry<String, Function<String, String>> entry = mapper.get(i);
            String fieldName = entry.getKey();
            Function<String, String> desensitiveMapper = entry.getValue();
            ValueFilter filter = (o, s, o1) -> {
                if (StringUtils.isBlank(fieldName)) {
                    return o1;
                }
                if (fieldName.equalsIgnoreCase(s) && o1 instanceof String) {
                    if (Objects.isNull(o1)) {
                        return o1;
                    }
                    String value = Objects.toString(o1);
                    if (StringUtils.isBlank(value)) {
                        return o1;
                    }
                    if (Objects.nonNull(desensitiveMapper)) {
                        String afterValue = desensitiveMapper.apply(value);
                        if (Objects.equals(value, afterValue)) {
                            return "***";
                        }
                        return afterValue;
                    }
                    return "***";
                }
                return o1;
            };
            filters[i] = filter;
        }
        return filters;
    }

}
