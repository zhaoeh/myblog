package com.mkt.agent.common.entity.api.fund.req;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @ClassName FundAgentReq
 * @Description 代理用户信息
 * @Author TJSAlex
 * @Date 2023/6/14 10:38
 * @Version 1.0
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FundAgentReq implements Serializable {
    @ApiModelProperty(value = "agentId")
    @NotNull(message = "agentId is required!")
    private Long agentId;
    @ApiModelProperty(value = "loginName")
    @NotBlank(message = "loginName is required!")
    private String loginName;
}
