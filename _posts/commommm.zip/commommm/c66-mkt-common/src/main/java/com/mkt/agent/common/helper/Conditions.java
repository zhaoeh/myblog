package com.mkt.agent.common.helper;

import lombok.extern.slf4j.Slf4j;

/**
 * @description: 条件工具
 * @author: ErHu.Zhao
 * @create: 2024-01-05
 **/
@Slf4j
public class Conditions {

    /**
     * 访问userCenter开关标志
     */
    private static final String USER_CENTER_OPEN_FLAG = "1";

    public static boolean userCenterIsOpen(String switches) {
        log.info("current of userCenter switches is {}", switches);
        return USER_CENTER_OPEN_FLAG.equals(switches);
    }
}
