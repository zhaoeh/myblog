package com.mkt.agent.common.player.core;

import com.google.gson.Gson;
import com.mkt.agent.common.utils.RedisUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * @description: 日志持有器
 * @author: ErHu.Zhao
 * @create: 2024-03-13
 **/
@Data
@Builder
@Slf4j
@Component
public class LogHolder {

    private static final String KEY = "MKT_LOG_HOLDER_CACHE_QUEUE";

    /**
     * redis缓存最大存储值
     */
    private static final Integer MAX_SIZE = 100;

    /**
     * 旧数据清理阈值
     */
    private static final Integer SKIP_SIZE = 40;

    private final RedisUtil redisUtil;

    private static RedisUtil redisUtilToUse;

    private final Gson gson;

    private static Gson gsonToUse;

    private final RedisTemplate<String, String> redisTemplate;

    private static RedisTemplate<String, String> redisTemplateToUse;

    public LogHolder(RedisUtil redisUtil, Gson gson, RedisTemplate<String, String> redisTemplate) {
        this.redisUtil = redisUtil;
        this.gson = gson;
        this.redisTemplate = redisTemplate;
    }

    @PostConstruct
    public void init() {
        redisUtilToUse = this.redisUtil;
        redisTemplateToUse = this.redisTemplate;
        gsonToUse = this.gson;
    }

    public static void addLogContainer(LogContainer container) {
        if (Objects.isNull(container)) {
            return;
        }
        container.setCurrentInfo("runner is :" + Thread.currentThread().getName() + ";occurring time is :" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")));
        container.setStackTrace(stackTraceToMap(Thread.currentThread().getStackTrace()[2]));
        ListOperations<String, String> operations = redisTemplateToUse.opsForList();
        operations.leftPush(KEY, gsonToUse.toJson(container));
        redisTemplateToUse.expire(KEY, 1, TimeUnit.DAYS);
    }

    public static void printLog() {

        ListOperations<String, String> operations = redisTemplateToUse.opsForList();
        List<String> sources = operations.range(KEY, 0, -1);
        if (CollectionUtils.isEmpty(sources)) {
            return;
        }
        log.info("*** begin to print logs,it's size was {}", sources.size());
        sources.stream().map(e -> gsonToUse.fromJson(e, LogContainer.class)).forEach(l -> {
            if (!CollectionUtils.isEmpty(l.log)) {
                log.info("currentInfo is {},stackTrace is {},",
                        l.getCurrentInfo(), CustomizeStackTrace.getCurrentMethodStackTrace(l.getStackTrace()));
                log.info(l.logStatement, l.log.toArray());
                return;
            }
            if (Objects.nonNull(l.throwable)) {
                log.info("currentInfo is {},stackTrace is {}, error is {}" +
                        l.logStatement, l.getCurrentInfo(), CustomizeStackTrace.getCurrentMethodStackTrace(l.getStackTrace()), l.throwable);
                return;
            }
            log.info("currentInfo is {},stackTrace is {}," + l.logStatement,
                    l.getCurrentInfo(), CustomizeStackTrace.getCurrentMethodStackTrace(l.getStackTrace()));
        });

        if (sources.size() > MAX_SIZE) {
            operations.trim(KEY, SKIP_SIZE, -1);
        }
    }

    public static String toStr(Throwable throwable) {
        if (Objects.nonNull(throwable)) {
            StringWriter stringWriter = new StringWriter();
            PrintWriter printWriter = new PrintWriter(stringWriter);
            throwable.printStackTrace(printWriter);
            return stringWriter.toString();
        }
        return "";
    }

    public static Map<String, Object> stackTraceToMap(StackTraceElement element) {
        Map<String, Object> map = new HashMap<>();
        map.put("fileName", element.getFileName());
        map.put("className", element.getClassName());
        map.put("methodName", element.getMethodName());
        map.put("lineNumber", element.getLineNumber());
        return map;
    }

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class LogContainer {
        private String currentInfo;

        private Map<String, Object> stackTrace;

        private String logStatement;

        private List<Object> log;

        private String throwable;
    }

}
