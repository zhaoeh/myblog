package com.mkt.agent.common.task;

import com.mkt.agent.common.core.TiConsumer;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

import java.util.function.BiConsumer;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-02-28
 **/
@Component
@EnableAsync
public class AsyncTasks {

    @Async
    public <T, U, W> void asyncTask(TiConsumer<T, U, W> consumer, T t, U u, W w) {
        consumer.accept(t, u, w);
    }

    @Async
    public <T, U> void asyncTask(BiConsumer<T, U> consumer, T t, U u) {
        consumer.accept(t, u);
    }

}
