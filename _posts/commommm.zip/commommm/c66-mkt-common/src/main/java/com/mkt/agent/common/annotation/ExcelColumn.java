package com.mkt.agent.common.annotation;


import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @Author TJSAlex
 */
@Target({ ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
public @interface ExcelColumn {

    /** 列顺序，默认从0开始 */
    int order() default 0;
    /** 列名称 */
    String value() default "";

}
