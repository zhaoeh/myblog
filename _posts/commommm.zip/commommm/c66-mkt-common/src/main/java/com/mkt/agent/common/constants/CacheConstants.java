package com.mkt.agent.common.constants;

/**
 * @Description: 缓存常量
 * @Author: PTMinnisLi
 * @Date: 2023/6/5
 */
public class CacheConstants {

    /**
     * 代理前台 token hashKey
     */
    public static final String FRONTEND_JWT_CACHE_KEY = "mkt:token:frontend:userId:";

    /**
     * 代理后台 token hashKey
     */
    public static final String BACKEND_JWT_CACHE_KEY = "mkt:token:backend:userId:";

    /**
     * 验证码绑定手机 hashKey
     */
    public static final String SMS_CODE_BIND_PHONE = "mkt:smsCode:bindPhone:userId:";

    /**
     * 验证码修改手机 hashKey
     */
    public static final String SMS_CODE_CHANGE_PHONE = "mkt:smsCode:changePhone:userId:";

    /**
     * 验证码绑定邮箱 hashKey
     */
    public static final String SMS_CODE_BIND_EMAIL = "mkt:smsCode:bindEmail:userId:";

    /**
     * 验证码修改邮箱 hashKey
     */
    public static final String SMS_CODE_CHANGE_EMAIL = "mkt:smsCode:changeEmail:userId:";

    /**
     * 验证码修改登录密码 hashKey
     */
    public static final String SMS_CODE_CHANGE_LOGIN_PASSWORD = "mkt:smsCode:changeLoginPassword:userId:";

    /**
     * 验证码修改钱包密码 hashKey
     */
    public static final String SMS_CODE_CHANGE_WALLET_PASSWORD = "mkt:smsCode:changeWalletPassword:userId:";

    /**
     * 验证码修改钱包密码 hashKey
     */
    public static final String SMS_CODE_BIND_GCASH = "mkt:smsCode:bindGCash:userId:";

    /**
     * 验证码修改钱包密码 hashKey
     */
    public static final String SMS_CODE_BIND_PAYMAYA = "mkt:smsCode:bindPayMaya:userId:";
}
