package com.mkt.agent.common.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.Table;

/**
 * @description: 数据刷新日志表，主要用于定时任务补数
 * @author: ErHu.Zhao
 * @create: 2024-03-13
 **/
@Table(name = "数据刷新日志表")
@TableName("t_agent_refresh_log")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@ToString
public class TAgentRefreshLog {

    /**
     * 开始日期
     */
    private String beginDate;

    /**
     * 结束日期
     */
    private String endDate;

    /**
     * 刷新日期
     */
    private String refreshDate;

    /**
     * 是否被删除：0未删除，1已删除
     */
    private Integer isDeleted;

    /**
     * 是否执行成功 0：未成功 1：成功
     */
    private Integer isSuccess;

    /**
     * 当前调度线程名称
     */
    private String runner;

    /**
     * 当前插入t_agent_count_group_day的总数
     */
    private Integer recordSize;

    /**
     * 分页大小
     */
    private Integer limit;

    /**
     * 当前调度业务名称
     */
    private String handlerName;

    /**
     * 定时器跑数的最大结束日期
     */
    private String maxDateWithTiming;
}
