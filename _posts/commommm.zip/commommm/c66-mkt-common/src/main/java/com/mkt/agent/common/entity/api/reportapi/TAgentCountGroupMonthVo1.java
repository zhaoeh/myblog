package com.mkt.agent.common.entity.api.reportapi;

import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Description player report 月维度 异步查询实体类
 * @Classname TAgentCountGroupMonthVo1
 * @Date 2024/3/18 18:40
 * @Created by TJSLucian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TAgentCountGroupMonthVo1 {

    //查询条件
    private ClDashBoardCreateQueryReq queryReq;

    //是否查询成功
    private boolean asyncSuccess;

}
