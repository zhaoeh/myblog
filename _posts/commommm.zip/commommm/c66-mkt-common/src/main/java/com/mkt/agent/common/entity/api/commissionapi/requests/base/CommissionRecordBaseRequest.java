package com.mkt.agent.common.entity.api.commissionapi.requests.base;

import com.mkt.agent.common.entity.BasePageRequest;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class CommissionRecordBaseRequest extends BasePageRequest implements Serializable {


    private static final long serialVersionUID = 1l;

    // 登录账号
    @ApiModelProperty(value = "loginName")
    private String loginName;

    // 导出文件名称
    @ApiModelProperty(value = "fileName", example = "commissionRecord")
    private String fileName;

    // 佣金记录查询开始产生时间
    //@ApiModelProperty(value = "createTimeStart", example = "2023-05-01 00:00:00")
    private String createTimeStart;

    // 佣金记录查询结束时间产生时间
    //@ApiModelProperty(value = "createTimeEnd", example = "2023-05-31 00:00:00")
    private String createTimeEnd;

    // 佣金计算开始日期
    @ApiModelProperty(value = "settleDateStart", example = "2023-05-01")
    private String settleDateStart;

    // 佣金计算结束日期
    @ApiModelProperty(value = "createTimeEnd", example = "2023-05-31")
    private String settleDateEnd;

}


