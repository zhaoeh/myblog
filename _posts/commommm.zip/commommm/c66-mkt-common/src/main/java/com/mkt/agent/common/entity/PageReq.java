package com.mkt.agent.common.entity;

import com.mkt.agent.common.constants.PageConstant;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Objects;

/**
 * @ClassName BaseReq
 * @Author TJSAlex
 * @Date 2023/5/19 10:06
 * @Version 1.0
 **/
public class PageReq implements Serializable {

    @ApiModelProperty(value = "当前页数",example = "1")
    protected Integer pageNum;
    @ApiModelProperty(value = "每页条数",example = "10")
    protected Integer pageSize;
    @ApiModelProperty(value = "第几行（分页），默认 0", notes = "用于更灵活的指定从哪行开始",hidden = true)
    private Integer rowNum;
    public PageReq() {
        if(Objects.isNull(pageNum) || Objects.isNull(pageSize) || pageNum<1 || pageSize <1) {
            pageNum = PageConstant.DEFAULT_PAGE_NUM;
            pageSize = PageConstant.DEFAULT_PAGE_SIZE;
        }
    }

    public PageReq(Integer pageNum,Integer pageSize) {
        if(Objects.isNull(pageNum) || Objects.isNull(pageSize) || pageNum<1 || pageSize <1) {
            pageNum = PageConstant.DEFAULT_PAGE_NUM;
            pageSize = PageConstant.DEFAULT_PAGE_SIZE;
        } else{
            setPageNum(pageNum);
            setPageSize(pageSize);
        }
    }

    public Integer getPageNum() {
        if (Objects.isNull(pageNum)) {
            return PageConstant.DEFAULT_PAGE_NUM;
        }
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
        this.rowNum = (this.pageNum - 1) * getPageSize();
    }

    public Integer getPageSize() {
        if (Objects.isNull(pageSize)) {
            return PageConstant.DEFAULT_PAGE_SIZE;
        }
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
        this.rowNum = (getPageNum() - 1) * this.pageSize;
    }


    public Integer getRowNum() {
        if (Objects.isNull(rowNum)) {
            if (!Objects.isNull(getPageNum())&&!Objects.isNull(getPageSize())) {
                return (getPageNum() - 1) * getPageSize();
            }
        }
        return rowNum;
    }

}
