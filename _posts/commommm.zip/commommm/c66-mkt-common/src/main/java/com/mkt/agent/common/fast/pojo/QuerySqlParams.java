package com.mkt.agent.common.fast.pojo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @description: sql query参数实体
 * @author: ErHu.Zhao
 * @create: 2024-03-05
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class QuerySqlParams {

    private String dataSourceType;

    private String querySql;

}
