package com.mkt.agent.common.entity.api.referral;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @ClassName ReferralReq
 * @Description 推荐ID请求参数
 * @Author TJSAlex
 * @Date 2023/5/25 11:14
 * @Version 1.0
 **/
@Data
public class ReferralReq implements Serializable {

//    @NotNull(message = "loginName is required!")
    @ApiModelProperty(value = "loginName",hidden = true)
    private String loginName;
    @NotNull(message = "referralId is required!")
    @ApiModelProperty(value = "referralId")
    private String referralId;
}
