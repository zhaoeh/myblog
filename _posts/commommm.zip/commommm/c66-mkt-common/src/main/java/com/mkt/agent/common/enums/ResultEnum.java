package com.mkt.agent.common.enums;

/**
 * 返回结果枚举
 * @Author TJSAlex
 * @Date 2023/5/18 15:42
 * @Version 1.0
 **/
public enum ResultEnum {

    // 基本异常枚举
    SUCCESS(Boolean.TRUE, 200, "Request Success"),
    BAD_REQUEST(Boolean.FALSE, 400, "Parameter Error"),
    UNAUTHORIZED(Boolean.FALSE, 401, "Unauthorized, illegal access"),
    FORBIDDEN(Boolean.FALSE, 403, "No permission to access"),
    NOT_EXIST(Boolean.FALSE, 404, "Access address does not exist"),
    SYSTEM_BUSY(Boolean.FALSE, 405, "The system is busy now. Please try again."),
    PAGENUM_ERROR(Boolean.FALSE, 406, "There are not enough pages!"),
    DATE_RANGE_ERROR(Boolean.FALSE, 407, "The startDate or endDate input error!"),
    FAIL(Boolean.FALSE, 500, "Business exception, request failed"),

    UNEXPECTED_FAIL(Boolean.FALSE, 501, "UNEXPECTED_FAIL"),


    DATA_IS_NULL(Boolean.FALSE, 502, "DATA_IS_NULL"),
    OUT_SYSTEM_ERROR(Boolean.FALSE, 503, "OUT_SYSTEM_ERROR"),

    EXCEL_EXPORT_IO_ERROR(Boolean.FALSE, 504, "EXCEL_EXPORT_IO_ERROR"),
    ENCRYPT_DECRYPT_ERROR(Boolean.FALSE, 505, "encrypt/decrypt error"),

    FRAMEWORK_ERROR(Boolean.FALSE, 506, "Framework error"),

    WS_EXCEPTION(Boolean.FALSE,507,"Call WS failed! Please check if the ws service is ok!"),
    USER_CENTER_EXCEPTION(Boolean.FALSE,508,"Call userCenter failed! Please check if the userCenter service is ok!"),

    THIRD_SYSTEM_RETURN_ERROR(Boolean.FALSE,600,"Third system return error response! Please contact the third system!"),


    // 业务异常枚举 以大写六位数字为业务异常，第一位为服务模块排序，如报表为第五位
    /*=======100000===========agent-api代理模块异常枚举==START============================*/
    /**
     * 我的直属玩家模块
     */
    MY_PLAYER_CREATE_FAIL(Boolean.FALSE, 100101, "my player create fail！"),
    MY_PLAYER_SEARCH_FAIL(Boolean.FALSE, 100102, "my player search fail！"),
    MY_PLAYER_SET_FAIL(Boolean.FALSE, 100103, "The current login account does not find the direct player account！"),

    /**
     * 推广码模块
     */
    REGISTER_ID_NOT_EXIST(Boolean.FALSE, 100201, "Register ID not exist"),
    REGISTER_ID_NOT_ONE(Boolean.FALSE, 100202, "Register ID exist multiple user,please check it again"),

    /**
     * 代理模块
     */
    AGENT_NOT_EXIST(Boolean.FALSE, 100301, "agent not exist！"),
    AGENT_ALREADY_EXIST(Boolean.FALSE, 100312, "agent already exist！"),
    AGENT_HAVE_POWER(Boolean.TRUE, 100302, "this agent has the power！"),
    AGENT_HAVE_NOT_POWER(Boolean.FALSE, 100303, "this agent has not the power！"),
    WS_CREATE_CUSTOMER_FAIL(Boolean.FALSE, 100304, "create customer fail！"),
    PARENT_AGENT_NULL(Boolean.FALSE, 100305, "parent agent null！"),
    REFERRALID_LOGINNAME_DUPLICATE(Boolean.FALSE, 100306, "ReferralId or login name Duplicate！"),
    AGENT_TYPE_UPDATE(Boolean.FALSE, 100307, "update tAgentCustomers type must follow 【General Line】 -> 【Professional Line】"),
    AGENT_DEVELOPABLE_LEVEL_UPDATE(Boolean.FALSE, 100308, "update tAgentCustomers developable level must follow from small to big"),
    AGENT_EXPORT_FAIL(Boolean.FALSE, 100309, "agent export fail"),
    WS_QUERY_CUSTOMER_FAIL(Boolean.FALSE, 100310, "ws query parent customer fail！"),
    WS_CREATE_CUSTOMER_RESPONSE_NULL(Boolean.FALSE, 100311, "ws create customer response fail！"),
    AGENT_NOT_TOP_ONE(Boolean.FALSE, 100312, "agent not top one！"),
    REFERRAL_LINK_FAIL(Boolean.FALSE, 100313, "get referral link fail！"),
    SITE_ID_IS_ERROR(Boolean.FALSE, 100314, "siteId is error！"),
    PREFIX_IS_INCORRECT(Boolean.FALSE, 100315, "Prefix format is incorrect or prefix has been used too many times！"),
    ACCOUNT_IS_INCORRECT(Boolean.FALSE, 100316, "Account length out of range！"),

    /**
     * 佣金模块
     */
    AGENT_CONTRACT_NOT_EXIST(Boolean.FALSE, 100401, "AGENT_CONTRACT_NOT_EXIST！"),
    CONTRACT_NAME_DUPLICATE(Boolean.FALSE, 100402, "agent contract name Duplicate"),
    CONTRACT_EXPORT_FAIL(Boolean.FALSE, 100403, "contract export fail"),
    CONTRACT_DELETE_USING(Boolean.FALSE, 100404, "there are agent is using this agent contract id"),
    PERCENTAGE_INCORRECT(Boolean.FALSE, 100405, "commission percentage entered incorrectly"),
    CONTRACT_CONDITION_ERROR(Boolean.FALSE, 100405, "Settlement conditions config error"),
    CONTRACT_CONDITION_NOT_CONFIGURED(Boolean.FALSE, 100406, "Please configure at least one rule"),
    CONTRACT_CONDITION_CANT_ALL_CONFIGURED(Boolean.FALSE, 100407, "It's not allowed to select Active Users and Turnover/GGR at the same time"),
    CONTRACT_CONDITION_CANT_ONLY_FD(Boolean.FALSE, 100408, "It's Not allowed to select only FD"),
    CONTRACT_CONDITION_PERCENTAGE_EXCEED(Boolean.FALSE, 100409, "Percentage has exceed the limit"),
    CONTRACT_CONDITION_PERCENTAGE_INVALID(Boolean.FALSE, 100410, "Percentage is invalid"),

    /**
     * 全局配置(门店接口)模块
     */
    PARAM_NAME_EXIST(Boolean.FALSE, 100501, "Param name existed"),
    CONFIG_UPDATE_OR_INSERT_FAIL(Boolean.FALSE, 100502, "Config update or insert fail"),
    CAN_ONLY_SET_NUMBER(Boolean.FALSE, 100503, "These keys can only set number"),
    CONFIG_VALUE_IS_NULL(Boolean.FALSE, 100504, "Can't find the global config or the config's value is null"),

    /*=======199999===========agent-api代理模块异常枚举==END==============================*/


    /*=======200000===========agent-commission佣金模块异常枚举==START========================*/
    RECORD_NOT_EXIST(Boolean.FALSE, 200000, "RECORD_NOT_EXIST!"),

    RECORD_STATUS_ILLEGAL_FOR_FIRST_APPROVE(Boolean.FALSE, 200001, "RECORD_STATUS_ILLEGAL_FOR_FIRST_APPROVE!"),

    RECORD_STATUS_ILLEGAL_FOR_SECOND_APPROVE(Boolean.FALSE, 200002, "RECORD_STATUS_ILLEGAL_FOR_SECOND_APPROVE!"),

    APPROVE_AMOUNT_ILLEGAL(Boolean.FALSE, 200003, "APPROVE_AMOUNT_ILLEGAL!"),


    APPROVED_BY_SAME_MANAGER(Boolean.FALSE, 200004, "APPROVED_BY_SAME_MANAGER!"),

    RECORD_STATUS_ILLEGAL_FOR_PAY(Boolean.FALSE, 200005, "RECORD_STATUS_ILLEGAL_FOR_PAY!"),

    PAY_AMOUNT_ILLEGAL(Boolean.FALSE, 200006, "PAY_AMOUNT_ILLEGAL!"),

    RECORD_STATUS_ILLEGAL_FOR_RESET(Boolean.FALSE, 200006, "RECORD_STATUS_ILLEGAL_FOR_RESET!"),

    RECORD_RESET_TIME_IS_OVERDUE(Boolean.FALSE, 200007, "RECORD_RESET_TIME_IS_OVERDUE!"),


    COMMISSION_RECORD_NOT_EXIST(Boolean.FALSE, 200008, "COMMISSION_RECORD_NOT_EXIST!"),


    AGREE_OR_REJECT_NO_OTHER_CHOICE(Boolean.FALSE, 200009, "AGREE_OR_REJECT_NO_OTHER_CHOICE!"),

    NO_AUTH_TO_TRANSFER(Boolean.FALSE, 200010, "No_AUTH_TO_TRANSFER!"),

    TRANSFER_FAIL(Boolean.FALSE, 200011, "TRANSFER_FAIL!"),

    COMMISSION_RECORD_APPROVE_EXPORT_FAIL(Boolean.FALSE, 200012, "commission_record_approve export fail"),

    COMMISSION_RECORD_DETAIL_EXPORT_FAIL(Boolean.FALSE, 200012, "commission_record_detail export fail"),

    COMMISSION_RECORD_LIST_EXPORT_FAIL(Boolean.FALSE, 200012, "commission_record_list export fail"),

    COMMISSION_RECORD_PAY_EXPORT_FAIL(Boolean.FALSE, 200012, "commission_record_pay export fail"),

    WALLET_BALANCE_INSUFFICIENT(Boolean.FALSE, 200016, "The balance is insufficient!"),

    /*=======299999===========agent-commission佣金模块异常枚举==END========================*/


    /*=======300000===========agent-integration外部接口模块异常枚举==START===================*/
    /*=======399999===========agent-integration外部接口模块异常枚举==END====================*/



    /*=======400000=========manager后台管理模块异常枚举==START========================*/
    /**
     * 角色模块
     */
    ROLE_CREATE_FAIL(Boolean.FALSE,400101,"role create fail！"),
    ROLE_NAME_EXIST(Boolean.FALSE,400102,"role name exist！"),
    ROLE_ENABLE_FAIL(Boolean.FALSE,400103,"role enable/disable FAIL！"),
    ROLE_UPDATE_FAIL(Boolean.FALSE,400104,"role update fail！"),
    ROLE_MENU_UPDATE_FAIL(Boolean.FALSE,400105,"role menu update fail!"),
    ROLE_MENU_DELETE_FAIL(Boolean.FALSE,400106,"role menu delete fail!"),
    ROLE_MENU_DELETE_FAIL_FOR_USER(Boolean.FALSE,400106,"This role cannot be deleted, because there are still system accounts under it."),
    ROLE_MENU_CAN_NOT_DELETE(Boolean.FALSE,400107,"role menu can not delete!"),

    /** 用户模块 */
    SYSTEM_USER_NAME_EXIST (Boolean.FALSE, 400201, "system user name exist！"),
    SYSTEM_USER_CREATE_FAIL(Boolean.FALSE, 400202,  "system user create fail！"),
    SYSTEM_USER_ENABLE_FAIL(Boolean.FALSE, 400203,  "system user enable/disable fail！"),
    SYSTEM_USER_UPDATE_FAIL(Boolean.FALSE, 400204,  "system user update fail！"),
    SYSTEM_USER_DELETE_FAIL(Boolean.FALSE, 400205,  "system user delete fail！"),
    SYSTEM_USER_PASSWORD_SAME_ERROR(Boolean.FALSE, 400206,  "system user password same error！"),
    SYSTEM_USER_OLD_PASSWORD_ERROR(Boolean.FALSE, 400207,  "system user old password error！"),
    SYSTEM_USER_PASSWORD_UPDATE_FAIL(Boolean.FALSE, 400208,  "system user password update fail！"),
    SYSTEM_USER_CAN_NOT_DELETE(Boolean.FALSE, 400209,  "system user can not delete！"),
    LOGINNAME_CREATE_FAIL(Boolean.FALSE, 400210,  "Account are only allowed to contain numbers and English letters！"),
    PASSWORD_CREATE_FAIL(Boolean.FALSE, 400211,  "Password are only allowed to contain numbers and English letters！"),
    PASSWORD_TOO_SIMPLE(Boolean.FALSE, 400212,  "Password must contain numbers and English letters！"),
    PASSWORD_LENGTH_INVALIDATED(Boolean.FALSE, 400213,  "Password must be 8-16 characters and number！"),

    /** 登录模块 */
//    USERNAME_NOT_EXIST(Boolean.FALSE, 400301, "username not exist!"),
    PASSWORD_LOCKED(Boolean.FALSE, 400302, "password failed for %d times!account is locked,please wait %s for login again!"),
    USERNAME_OR_PASSWORD_ERROR(Boolean.FALSE, 400303, "incorrect username or password"),
    USER_DISABLED(Boolean.FALSE, 400304, "user disabled!"),
    USER_NOT_HAVE_GROUP(Boolean.FALSE, 400305, "user not have group!"),
    LOGIN_OVERTIME(Boolean.FALSE, 400306, "login overtime"),
    LOGIN_ERROR(Boolean.FALSE, 400307, "login error！"),

    /** 登录模块 */
    RESOURCE_CREATED_NOT_ALLOWED(Boolean.FALSE, 400401, "resource created not allowed！"),
    RESOURCE_NAME_EXIST(Boolean.FALSE, 400402, "resource name exist!"),
    RESOURCE_BS_NAME_EXIST(Boolean.FALSE, 400403, "resource bs name exist!"),
    RESOURCE_URL_EXIST(Boolean.FALSE, 400404, "resource url exist!"),
    RESOURCE_CREATED_FAIL(Boolean.FALSE, 400405, "resource created fail！"),
    RESOURCE_ENABLE_FAIL(Boolean.FALSE, 400406, "resource enable/disable fail！"),
    RESOURCE_UPDATE_FAIL(Boolean.FALSE, 400407, "resource update fail！"),
    RESOURCE_MOVE_FAIL(Boolean.FALSE, 400408, "resource move fail！"),

    /*=======499999=========manager后台管理模块异常枚举==END========================*/






    /*=======500000=========report 系统异常枚举==START========================*/
    AGENT_INFO_ACCESSED_FAIL(Boolean.FALSE, 500001, "AGENT_INFO_ACCESSED_FAIL"),

    AGENT_ACCOUNT_IS_NULL(Boolean.FALSE, 500002, "AGENT_ACCOUNT_IS_NULL"),
    /*=======599999=========report 系统异常枚举==END========================*/






    /*=======700000=========gateway代理前台模块异常枚举==START========================*/
    /**
     * 前台登录模块
     */
    ERROR_PRODUCT_ID(Boolean.FALSE, 700101, "ProductId error"),
    ERROR_LOGINNAME_EMPTY(Boolean.FALSE, 700102, "error loginname empty"),
    ERROR_MOBILE_EMPTY(Boolean.FALSE, 700103, "error mobile empty"),
    ERROR_MAIL_EMPTY(Boolean.FALSE, 700104, "error mail empty"),
    GATEWAY_LOGIN_OVERTIME(Boolean.FALSE, 700105, "gateway login overtime"),
    SMS_CODE_ERROR(Boolean.FALSE, 700106, "sms code error"),
    FIRST_LOGIN(Boolean.FALSE, 700107, "It's you first time login, please change the password first"),
    USER_OR_PHONE_NUMBER_NOT_EXIST(Boolean.FALSE, 700108, "user or phone number not exist"),
    AGENT_DISABLED(Boolean.FALSE, 700109, "Agent disabled"),
    OPERATION_TIMEOUT(Boolean.FALSE, 700110, "The operation timed out, please try again"),

    /** Account Info模块 */
    GET_CUSTOMER_FAIL(Boolean.FALSE, 700201, "get customer fail"),
    MODIFY_CUSTOMER_FAIL(Boolean.FALSE, 700201, "modify customer fail"),
    BOUND_EMAIL_FAIL(Boolean.FALSE, 700202, "bound email fail"),
    GET_FOUND_DETAIL_FAIL(Boolean.FALSE, 700203, "get found detail fail"),
    UPDATE_ACCOUNT_FAILED(Boolean.FALSE, 700204, "update account failed"),
    BOUND_PHONE_FAIL(Boolean.FALSE, 700205, "bound phone fail"),
    MODIFY_EMAIL_FAIL_FOR_SAME(Boolean.FALSE, 700206, "modify email fail for same"),
    MODIFY_EMAIL_FAIL(Boolean.FALSE, 700207, "modify email fail"),
    MODIFY_PHONE_FAIL_FOR_SAME(Boolean.FALSE, 700208, "modify phone fail for same"),
    MODIFY_PHONE_FAIL(Boolean.FALSE, 700209, "modify phone fail"),
    PHONE_CANNOT_NULL(Boolean.FALSE, 700210, "phone cannot null"),
    EMAIL_CANNOT_NULL(Boolean.FALSE, 700211, "email cannot null"),
    BANK_CARD_EXIST(Boolean.FALSE, 700212, "bank card exist"),
    ERROR_CUSTOMER_EMPTY(Boolean.FALSE, 700213, "error customer empty"),
    BANK_CARD_CREATE_FAIL(Boolean.FALSE, 700214, "bank card create fail"),
    BANK_CARD_CREATE_FAIL_FOR_WALLET_PASSWORD(Boolean.FALSE, 700214, "bank card create fail for wallet password"),
    MODIFY_WS_PASSWORD_FAIL(Boolean.FALSE, 700215, "modify password fail"),
    MODIFY_WS_WITHDRAW_PASSWORD_FAIL(Boolean.FALSE, 700216, "modify wallet password fail"),
    WITHDRAW_PASSWORD_ERROR(Boolean.FALSE, 700217, "wallet password error"),
    BOUND_PHONE_FAIL_FOR_EXISTED(Boolean.FALSE, 700218, "phone has been bounded"),
    BOUND_MAIL_FAIL_FOR_EXISTED(Boolean.FALSE, 700219, "Mail has been bounded"),
    BOUND_PHONE_FAIL_FOR_INVALID(Boolean.FALSE, 700220, "invalid mobile number"),

    /**
     * Fund 账变模块
     */
    ERROR_AMOUNT_EMPTY(Boolean.FALSE, 700301, "ERROR_AMOUNT_EMPTY"),
    ERROR_WITHDRAW_PWD_EMPTY(Boolean.FALSE, 700302, "ERROR_WITHDRAW_PWD_EMPTY"),
    ERROR_WITHDRAW_LIMIT(Boolean.FALSE, 700303, "ERROR_WITHDRAW_LIMIT"),
    ERROR_WITHDRAW_PWD_INCORRECT(Boolean.FALSE, 700304, "ERROR_WITHDRAW_PWD_INCORRECT"),
    ERROR_WITHDRAW_ORDER_PENDING(Boolean.FALSE, 700305, "have unfinished withdrawal,try it later!"),
    ERROR_ACCOUNT_NOTEXIST(Boolean.FALSE, 700306, "ERROR_ACCOUNT_NOTEXIST"),
    ERROR_WITHDRAW_FAILED(Boolean.FALSE, 700307, "ERROR_WITHDRAW_FAILED"),
    ERROR_WITHDRAW_REPEAT_REFUSE(Boolean.FALSE, 700308, "ERROR_WITHDRAW_REPEAT_REFUSE"),
    ERROR_GLIFE_PHONE_MODIFY_FORBID(Boolean.FALSE, 700309, "ERROR_GLIFE_PHONE_MODIFY_FORBID"),
    ERROR_MOBILE_INVAILD(Boolean.FALSE, 700310, "ERROR_MOBILE_INVAILD"),
    ERROR_PWD_LENGTH(Boolean.FALSE, 700311, "ERROR_PWD_LENGTH"),
    ERROR_CUSTOMER_MODIFY_FAILED(Boolean.FALSE, 700312, "ERROR_CUSTOMER_MODIFY_FAILED"),
    ERROR_EMAIL_INVAILD(Boolean.FALSE, 700313, "ERROR_EMAIL_INVAILD"),
    ERROR_BIND_EMAIL_EXIST(Boolean.FALSE, 700314, "ERROR_BIND_EMAIL_EXIST"),
    ERROR_WITHDRAW_PWD_INVALID(Boolean.FALSE, 700315, "ERROR_WITHDRAW_PWD_INVALID"),
    ERROR_PARAM_ABSENT(Boolean.FALSE, 700316, "ERROR_PARAM_ABSENT"),
    ERROR_WITHDRAW_GAME_CASH(Boolean.FALSE, 700317, "ERROR_WITHDRAW_GAME_CASH"),
    ERROR_WITHDRAW_NOT_EXISTS(Boolean.FALSE, 700318, "withdrawal request id not found"),
    /**
     * My Player模块
     */
    REGISTER_ID_ACCOUNT_CONFLICT(Boolean.FALSE, 700401, "Parent conflict with Register ID/Link"),
    REGISTER_ID_SEARCH_FAIL(Boolean.FALSE, 700402, "Register ID search fail"),
    MY_PLAYERS_EXPORT_FAIL(Boolean.FALSE, 700403, "my players export fail"),
    MY_PLAYERS_PARENT_NOT_EXIST(Boolean.FALSE, 700404, "parent not exist"),
    MY_PLAYERS_REGISTER_REFERRAL_ID_NOT_EXIST(Boolean.FALSE, 700405, "Register Referral ID not exist"),
    PARENT_LEVEL_CONFLICT(Boolean.FALSE, 700406, "Parent level conflict with Parent/RegisterID/Link"),
    AGENT_DATA_ERROR(Boolean.FALSE, 700407, "agent data error"),
    HAVE_NO_AUTH_TO_SEE_OTHER_AGENT(Boolean.FALSE, 700408, "The agent you searched belongs to other team.You have no authority to see other agent"),
    ACCOUNT_NOT_EXIST(Boolean.FALSE, 700409, "Account not exist"),
    MY_PLAYERS_EXIST_OR_SEARCH_FAIL(Boolean.FALSE, 700403, "my players existed or search fail"),
    /** Agent Commission Record模块 */
    AGENT_COMMISSION_RECORD_EXPORT_FAIL(Boolean.FALSE, 700501, "agent commission record export fail"),
    /*=======799999=========gateway代理前台模块异常枚举==END========================*/




    /*=======800000=========user模块异常枚举==START========================*/
    /*=======899999=========user模块异常枚举==END========================*/



    /*=======900000=========第三方接口返回异常==START========================*/
    BI_GAME_DATA_ACESSED_FAIL(Boolean.FALSE, 910001, "BI_GAME_DATA_ACESSED_FAIL"),

    /*=======999999=========user模块异常枚举==END========================*/



    /*=======1000000=========自动任务job服务==START========================*/
    NEED_TASK_STATUS_NOT_SUCCESS(Boolean.FALSE, 10000000, "NEED_TASK_STATUS_NOT_SUCCESS");

    /*=======1000000=========自动任务job服务==END========================*/
    private Boolean success;
    private Integer code;
    private String message;

    ResultEnum(Boolean success, Integer code, String message) {
        this.success = success;
        this.code = code;
        this.message = message;
    }

    public Boolean getSuccess() {
        return success;
    }

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
