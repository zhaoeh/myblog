package com.mkt.agent.common.entity.clickhouse.req;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

/**
 * @Description 获取仪表盘数据时用户查询数据库的实体类封装
 * @Classname ClDashBoardCreateQuery
 * @Date 2023/12/1 15:28
 * @Created by TJSLucian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ClDashBoardCreateQueryReq {

    public ClDashBoardCreateQueryReq(List<String> loginNameList){
        this.loginNameList = loginNameList;
    }

    //当前登录用户
    private String agentAccount;

    private String parentAgentAccount;

    @ApiModelProperty(value = "选中的时间开始日期,冗余字段,前端暂时不需要", hidden = true, example = "2023-10-30")
    private String recordDateStart;
    @ApiModelProperty(value = "选中的时间结束日期", hidden = true, example = "2023-10-30")
    private String recordDateEnd;

    private String recordDateTimeStart;

    private String recordDateTimeEnd;

    //用于查询的用户的用户名
    private List<String> loginNameList;

    //用于查询的代理的用户名
    private List<String> agentAccountList;

    //用于查询的代理
    private List<TAgentCustomers> agentCustomersList;

    //用于佣金方案条件设置的金额
    private int activeAmount;

    //一级代理的佣金方案类型
    private String planType;

    //当前代理的层级
    private int agentLevel;

    //需要计算的月份- player_report
    private String agentMonth;

    private Integer isDeleted = BaseConstants.AGENTS_NO_DELETED;

    private Integer isEnable;

}
