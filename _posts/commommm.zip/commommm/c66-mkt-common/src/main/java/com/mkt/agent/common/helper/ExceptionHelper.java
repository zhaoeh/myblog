package com.mkt.agent.common.helper;

import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;
import org.apache.commons.lang3.ObjectUtils;

import java.util.Objects;

/**
 * @description: 异常工具
 * @author: ErHu.Zhao
 * @create: 2024-01-05
 **/
public class ExceptionHelper {

    public static void businessExceptionIfSourceIsNotEmpty(Object source, ResultEnum error) {
        if (ObjectUtils.isNotEmpty(source)) {
            throw new BusinessException(error);
        }
    }

    public static void businessExceptionIfSourceIsEmpty(Object source, ResultEnum error) {
        if (ObjectUtils.isEmpty(source)) {
            throw new BusinessException(error);
        }
    }

    public static void businessExceptionIfNotTrue(Boolean source, ResultEnum error) {
        if (Objects.isNull(source) || !source) {
            throw new BusinessException(error);
        }
    }


}
