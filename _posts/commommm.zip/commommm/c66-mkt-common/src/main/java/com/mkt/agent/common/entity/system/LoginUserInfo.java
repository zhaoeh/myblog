package com.mkt.agent.common.entity.system;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Description: 当前登录用户信息实体类
 * @Author: PTMinnisLi
 * @Date: 2023/6/16
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LoginUserInfo {

    /**
     * 代理后台:userId（当前登录的管理员用户id）,代理前台:customerId当前登录的代理用户id）
     */
    public String userId;

    /**
     * 代理后台:userName（当前登录的管理员用户名）,代理前台:loginName当前登录的代理用户名）
     */
    public String username;

    /**
     * 代理后台:用户类型
     */
    public String userType;

    /**
     * 登录用户是前台登录还是后台登录，frontend-前台，backend-后台
     */
    public String from;
}
