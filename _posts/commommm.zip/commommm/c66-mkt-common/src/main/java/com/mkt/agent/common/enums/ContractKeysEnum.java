package com.mkt.agent.common.enums;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.ApiModel;

import java.math.BigDecimal;
import java.util.Objects;

@ApiModel(value = "GameTypeEnum", description = "GameType Enum")
public enum ContractKeysEnum {

    Sport("sportsPercentage", 1),
    Poker("pokerPercentage", 3),
    Slot("slotPercentage", 5),
    Bingo("bingoPercentage", 27),
    EBingo("eBingoPercentage", 21),

    Casino("casinoPercentage", 17),

    Fishing("fishingPercentage", 8),

    All("allGamesPercentage", 0),

    RangeOfTurnoverStart("rangeOfTurnoverStart", 0),

    RangeOfTurnoverEnd("rangeOfTurnoverEnd", 0),

    Order("order", 0),

    ;

    private String des;

    private Integer value;

    ContractKeysEnum(String des, Integer value) {

        this.des = des;
        this.value = value;

    }

    public String getDes() {
        return des;
    }

    public Integer getValue() {
        return value;
    }


    public static JSONObject getHitContract(String percentageDetails, BigDecimal turnover) {
        JSONArray array = JSON.parseArray(percentageDetails);
        JSONObject jsonObject = null;
        for (Object o : array) {

            JSONObject json = (JSONObject) o;

            Integer startInteger = (Integer) json.get(ContractKeysEnum.RangeOfTurnoverStart.getDes());
            BigDecimal beginTurnover = new BigDecimal(String.valueOf(startInteger));

            Integer endInteger = (Integer) json.get(ContractKeysEnum.RangeOfTurnoverEnd.getDes());
            BigDecimal endTurnover = new BigDecimal(String.valueOf(endInteger));

            boolean hit = turnover.compareTo(beginTurnover) >= 0; /*&& turnover.compareTo(endTurnover) != 1*/

            if (hit) {
                jsonObject = json;
            }

        }

        // 取不到取第一个
        if (Objects.isNull(jsonObject)) {
            jsonObject = (JSONObject) array.get(0);
        }

        return jsonObject;
    }


    public static JSONObject getHitContractForGame(String percentageDetails, BigDecimal turnover) {
        JSONArray array = JSON.parseArray(percentageDetails);
        JSONObject jsonObject = null;
        for (Object o : array) {

            JSONObject json = (JSONObject) o;
            BigDecimal beginTurnover = (BigDecimal) json.get(ContractKeysEnum.RangeOfTurnoverStart.getDes());
            BigDecimal endTurnover = (BigDecimal) json.get(ContractKeysEnum.RangeOfTurnoverEnd.getDes());

            //TODO 二期补充后面的匹配逻辑
            boolean hit = turnover.compareTo(beginTurnover) >= 0; /*&& turnover.compareTo(endTurnover) != 1;*/

            if (hit) {
                jsonObject = json;
            }

        }

        // 取不到取第一个
        if (Objects.isNull(jsonObject)) {
            jsonObject = (JSONObject) array.get(0);
        }

        jsonObject.remove(ContractKeysEnum.All.getDes());
        return jsonObject;
    }
}
