package com.mkt.agent.common.entity.api.integration.pay;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("银行列表响应体")
public class BankListResponse {

    @ApiModelProperty(value = "银行名称")
    private String bankName;

    @ApiModelProperty(value = "银行code")
    private String bankCode;

}