package com.mkt.agent.common.sql;

import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.utils.StatementHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * @description: SQL常量语句
 * @author: ErHu.Zhao
 * @create: 2023-12-20
 **/
public class StatementConstant {

    /**
     *  querySumAgentGgrTData
     */
    public static final String querySumAgentGgrTData1 = " where t.agent_date >= ";
    public static final String querySumAgentGgrTData2 = " and t.agent_date <= ";
    public static final String querySumAgentGgrTData3 = " and (t.turnover > 0 or t.ggr > 0) and t.login_name in ";

    /**
     * queryGgrActivePlayerCount
     */
    public static final String queryGgrActivePlayerCount1 = " where t.agent_date >= ";
    public static final String queryGgrActivePlayerCount2 = " and t.agent_date <= ";
    public static final String queryGgrActivePlayerCount3 = " and t.ggr > 0 and t.login_name in ";
    public static final String queryGgrActivePlayerCount4 = " GROUP BY t.login_name  HAVING ggr > ";

    /**
     * queryTurnoverActivePlayerCount
     */
    public static final String queryTurnoverActivePlayerCount1 = " where t.agent_date >= ";
    public static final String queryTurnoverActivePlayerCount2 = " and t.agent_date <= ";
    public static final String queryTurnoverActivePlayerCount3 = " and t.turnover > 0 and t.login_name in ";
    public static final String queryTurnoverActivePlayerCount4 = " GROUP BY t.login_name  HAVING turnover > ";

    /**
     * topList
     */
    public static final String topList1 = " where DATE_SUB(NOW(), interval 30 day) <= t.agent_date and t.login_name in ";
    public static final String topList2 = " GROUP BY t.login_name ORDER BY turnoverSum DESC LIMIT 10 ";

    /**
     * queryFirstPlayerAndAmountData
     */
    public static final String queryFirstPlayerAndAmountData1 = " where t.first_deposit = 1 and t.status = 2 and t.last_update >= ";
    public static final String queryFirstPlayerAndAmountData2 = " and t.last_update <= ";
    public static final String queryFirstPlayerAndAmountData3 = " and t.login_name in ";

    /**
     * queryDashBoardData
     */
    public static final String queryDashBoardData1 = " where t.agent_date >= ";
    public static final String queryDashBoardData2 = " and t.agent_date <= ";
    public static final String queryDashBoardData3 = " and t.login_name in ";
    public static final String queryDashBoardData4 = " group by t.login_name, t.game_type, t.agent_date ";



    public static final String AGENT_DATE = "agent_date";
    public static final String LOGIN_NAME = "login_name";
    public static final String BLANK = " ";
    public static final String GREATER_EQUALS = " >= ";
    public static final String GREATER = " > ";
    public static final String LESS_EQUALS = " <= ";
    public static final String LESS = " < ";
    public static final String AND = " and ";
    public static final String OR = " or ";
    public static final String IN = " in ";
    public static final String LEFT_BRACKET = " ( ";
    public static final String RIGHT_BRACKET = " ) ";
    public static final String COMMA = ",";
    public static final String WHERE = " where ";
    public static final String TURNOVER = "turnover";
    public static final String GGR = "ggr";


    public static void main(String[] args) {

        ClDashBoardCreateQueryReq queryReq = new ClDashBoardCreateQueryReq();
        queryReq.setRecordDateStart("2023-12-01");
        queryReq.setRecordDateEnd("2023-12-25");
        queryReq.setActiveAmount(1230);


        List<String> loginNameList = new ArrayList<>();
        loginNameList.add("Eric");
        loginNameList.add("Daisy");
        loginNameList.add("spoc");
        queryReq.setLoginNameList(loginNameList);

        System.out.println(StatementHelper.helperQuerySumAgentGgrTData(queryReq));

        System.out.println(StatementHelper.helperQueryGgrActivePlayerCount(queryReq));

    }
}
