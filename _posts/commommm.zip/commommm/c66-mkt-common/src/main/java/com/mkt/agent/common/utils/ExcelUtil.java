package com.mkt.agent.common.utils;

import com.alibaba.excel.EasyExcel;
import com.mkt.agent.common.annotation.ExcelColumn;
import com.mkt.agent.common.converter.LocalDateConverter;
import com.mkt.agent.common.converter.LocalDateTimeConverter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * @ClassName ExcelUtil
 * @Description Excel导出工具类
 * @Author TJSAlex
 **/
@Slf4j
public class ExcelUtil {

    /**
     * @Author TJSAlex
     * @Description 通用导出方法
     * @Date 10:44 2023/5/18
     * @Param 数据列表
     */
    public static <T> void export(List<T> dataList, Class<T> clazz,String fileName, HttpServletResponse response) throws IOException {

        Field[] fields = clazz.getDeclaredFields();
        Arrays.sort(fields, (f1, f2) -> {
            ExcelColumn c1 = f1.getAnnotation(ExcelColumn.class);
            ExcelColumn c2 = f2.getAnnotation(ExcelColumn.class);
            if (Objects.nonNull(c1) && Objects.nonNull(c2)) {
                int res = c1.order() - c2.order();
                if (res == 0) {
                    String v1 = StringUtils.isNotBlank(c1.value()) ? c1.value() : f1.getName();
                    String v2 = StringUtils.isNotBlank(c2.value()) ? c2.value() : f2.getName();
                    res = v1.compareTo(v2);
                }
                return res;
            }
           return 0;
        });
        //创建excel工作簿
        XSSFWorkbook workbook = new XSSFWorkbook();
        //创建工作表sheet
        XSSFSheet sheet = workbook.createSheet();
        //创建第一行
        XSSFRow row = sheet.createRow(0);
        XSSFCell cell;
        CellStyle cs = workbook.createCellStyle();
        cs.setWrapText(true);

        //去除没有ExcelColumn 注解的元素
        Field[] newFields = Arrays.stream(fields).filter(field-> Objects.nonNull(field.getAnnotation(ExcelColumn.class)) ).toArray(Field[]::new);

        //插入第一行的表头
        for (int i = 0; i < newFields.length; i++) {
            ExcelColumn column = newFields[i].getAnnotation(ExcelColumn.class);
            //没有ExcelColumn 注解的列跳过
            if(Objects.nonNull(column)){
                cell = row.createCell(i);
                cell.setCellStyle(cs);
                String value = StringUtils.isNotBlank(column.value()) ? column.value() : firstToUpperCase(newFields[i].getName());
                cell.setCellValue(value);
            }
        }
        if(null!=dataList&&dataList.size()>0){
            for (int i = 0; i < dataList.size(); i++) {
                row = sheet.createRow(i + 1);
                for (int j = 0; j < newFields.length; j++) {
                    //没有ExcelColumn 注解的列跳过
                    ExcelColumn column = newFields[j].getAnnotation(ExcelColumn.class);
                    if(Objects.nonNull(column)){
                        cell = row.createCell(j);
                        cell.setCellStyle(cs);
                        Field field = newFields[j];
                        field.setAccessible(true);
                        try {
//                        Object obj = field.get(dataList.get(i));

                            Object obj = PropertyUtils.getProperty(dataList.get(i), field.getName());
                            if (Objects.nonNull(obj)) {
                                if(obj instanceof Date){
                                    cell.setCellValue(DateUtils.dateToDateTime((Date) obj));
                                }else{
                                    cell.setCellValue(obj.toString());
                                }
                            }
                        } catch (IllegalAccessException e) {
                            e.printStackTrace();
                        } catch (InvocationTargetException e) {
                            e.printStackTrace();
                        } catch (NoSuchMethodException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }

        response.addHeader("Content-Disposition","attachment; filename="+fileName+".xlsx");
        response.setContentType("application/vnd.ms-excel");
        OutputStream stream = response.getOutputStream();
        //创建excel文件
        try (stream) {
            workbook.write(stream);
        }
    }

    /**
     * @return 转换后首字母大写字符串
     * @Author TJSAlex
     * @Description 字符串首字母小写转大写
     * @Date 11:33 2023/5/19
     * @Param 首字母小写原始字符串
     */
    private static String firstToUpperCase(String str) {
        char[] chars = str.toCharArray();
        chars[0] -= 32;
        return String.valueOf(chars);
    }


    /**
     * @Author Amida
     * @Description 通用导出方法1
     * @Date 10:44 2023/5/18
     * @Param 数据列表
     */
    public static <T> void export1(List<T> dataList, Class<T> clazz, String filePath, HttpServletResponse response) throws IOException {

        response.setContentType("application/vnd.ms-excel;charset=utf-8");
        response.setCharacterEncoding("utf-8");
        response.addHeader("Content-Disposition", "attachment; filename=" + filePath + ".xlsx");
        EasyExcel.write(response.getOutputStream(), clazz).registerConverter(new LocalDateTimeConverter()).
                registerConverter(new LocalDateConverter()).
                sheet("test").doWrite(dataList);

    }
}
