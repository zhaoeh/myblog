package com.mkt.agent.exclude.signature.exception;

/**
 * 签名异常类
 * @author yiqiang
 * @date 2024/05/14
 */
public abstract class AbstractSignatureException extends RuntimeException{
    private static final long serialVersionUID = -83904050176855L;

    public AbstractSignatureException() {
        super();
    }

    public AbstractSignatureException(String message) {
        super(message);
    }

    public AbstractSignatureException(String message, Throwable cause) {
        super(message, cause);
    }

    public AbstractSignatureException(Throwable cause) {
        super(cause);
    }

    protected AbstractSignatureException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
