package com.mkt.agent.common.valid.refrence.annotation;

import com.mkt.agent.common.valid.refrence.validtor.ReferenceValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

/**
 * @description: 依赖校验管理注解
 * @author: ErHu.Zhao
 * @create: 2024-01-25
 **/
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {ReferenceValidator.class})
@Documented
public @interface ReferenceManager {

    //默认错误消息
    String message() default "必须为指定值";

    //分组
    Class<?>[] groups() default {};

    //负载
    Class<? extends Payload>[] payload() default {};
}
