package com.mkt.agent.common.fast.strategy;

import com.mkt.agent.common.fast.core.FastContext;

import java.util.List;

/**
 * @description: 补救策略
 * @author: ErHu.Zhao
 * @create: 2024-04-08
 **/
public interface RemediationStrategy {

    String strategy();

    void afterSuccess(FastContext fastContext, String callable, List<String> params);


    void afterFailed(FastContext fastContext, String callable, List<String> params);


}
