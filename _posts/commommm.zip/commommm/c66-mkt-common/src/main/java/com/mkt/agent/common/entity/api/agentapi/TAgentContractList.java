package com.mkt.agent.common.entity.api.agentapi;

import com.baomidou.mybatisplus.annotation.TableName;
import com.mkt.agent.common.entity.BaseOperationEntity;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import javax.persistence.Table;
import java.math.BigDecimal;

@Table(name="佣金明细表 ")
@TableName("t_agent_contract_list")
@NoArgsConstructor
@Data
public class TAgentContractList    {
    @Column(name="contract_list_id",nullable = false)
    private String contractListId ;

    @Column(name="turnover_ggr",nullable = false)
    private BigDecimal  turnoverGgr ;

    @Column(name="commission",nullable = false)
    private  BigDecimal commission ;

    @Column(name="contract_id",nullable = false)
    private String contractId;

    @Column(name="is_checked",nullable = false)
    private String isChecked;

}
