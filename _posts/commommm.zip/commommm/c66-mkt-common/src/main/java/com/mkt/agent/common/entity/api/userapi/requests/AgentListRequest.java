package com.mkt.agent.common.entity.api.userapi.requests;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Description: 代理列表查询
 * @Author: PTMinnisLi
 * @Date: 2023/6/22
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AgentListRequest {

    @ApiModelProperty("查询父级代理级别start")
    private Integer levelStart = 1;

    @ApiModelProperty("查询父级代理级别end")
    private Integer levelEnd = 5;

    @ApiModelProperty("查询根父级代理名称")
    private String rootParentName;

    @ApiModelProperty("是否根据查询所有树状下级")
    private Boolean isQueryTree = false;
}
