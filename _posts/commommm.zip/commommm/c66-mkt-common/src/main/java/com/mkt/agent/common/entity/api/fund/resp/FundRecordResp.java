package com.mkt.agent.common.entity.api.fund.resp;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.mkt.agent.common.annotation.ExcelColumn;
import lombok.Data;

import java.io.Serializable;

/**
 * @ClassName FundDto
 * @Description 账变记录DTO
 * @Author TJSAlex
 * @Date 2023/5/18 14:55
 * @Version 1.0
 **/
public class FundRecordResp implements Serializable {
    @ExcelColumn
    @ExcelProperty("Account")
    private String account;

    @JsonIgnore
    @ExcelIgnore
    private Integer type;

    @ExcelProperty("FundType")
    @ExcelColumn(order = 1)
    private String fundType;

    @ExcelProperty("Amount")
    @ExcelColumn(order = 2)
    private String amount;

    @ExcelProperty("Status")
    @ExcelColumn(order = 3)
    private String status;

    @JsonIgnore
    @ExcelIgnore
    private Integer fundStatus;

    @ExcelProperty("From")
    @ExcelColumn(order = 4,value = "From")
    private String fromAccount;

    @ExcelColumn(order = 5,value = "To")
    @ExcelProperty("To")
    private String toAccount;

    @ExcelProperty("TransactionId")
    @ExcelColumn(order = 6)
    private String transactionId;

    @ExcelProperty("Generate Time")
    @ExcelColumn(order = 7,value = "Generate Time")
    private String createTime;

    @JsonIgnore
    @ExcelIgnore
    private String transAmount;

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getFundType() {
        return fundType;
    }

    public void setFundType(String fundType) {
        this.fundType = fundType;
    }

    public String getAmount() {
        return getTransAmount();
    }

    public void setAmount(String amount) {
        setTransAmount(amount);
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getFundStatus() {
        return fundStatus;
    }

    public void setFundStatus(Integer fundStatus) {
        this.fundStatus = fundStatus;
    }

    public String getFromAccount() {
        return fromAccount;
    }

    public void setFromAccount(String fromAccount) {
        this.fromAccount = fromAccount;
    }

    public String getToAccount() {
        return toAccount;
    }

    public void setToAccount(String toAccount) {
        this.toAccount = toAccount;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getTransAmount() {
        return transAmount;
    }

    public void setTransAmount(String transAmount) {
        this.transAmount = transAmount;
    }
}
