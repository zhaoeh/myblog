package com.mkt.agent.common.entity.api.jobapi.table;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;

@Data
@TableName("t_daily_mkt_agent_all")
public class DailyMktAgentAll {

    @TableField("agent_date")
    private String agentDate;

    @TableField("login_name")
    private String loginName;

    @TableField("ggr")
    private BigDecimal ggr = BigDecimal.ZERO;

    @TableField("turnover")
    private BigDecimal turnover = BigDecimal.ZERO;

    @TableField("winorloss")
    private BigDecimal winOrLoss = BigDecimal.ZERO;

    @TableField("first_deposit")
    private int firstDeposit;

    @TableField("first_deposit_amount")
    private BigDecimal firstDepositAmount = BigDecimal.ZERO;

    @TableField("deposit_amount")
    private BigDecimal depositAmount = BigDecimal.ZERO;

    @TableField("withdrawal_amount")
    private BigDecimal withdrawalAmount = BigDecimal.ZERO;

}
