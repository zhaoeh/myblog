package com.mkt.agent.common.entity.api.agentapi.requests;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(value = "AgentCustomerContractQueryByPageRequest")
public class AgentCustomerContractQueryByPageRequest extends AgentCustomerQueryByPageRequest implements Serializable {

    // 佣金方案名称
    @ApiModelProperty(value = "commissionPlanName")
    private String commissionPlanName;

    // 佣金方案类型：TURNOVER,1:GGR
    @ApiModelProperty(value = "CommissionTypeEnum")
    private String commissionPlanType;

    // 结算周期：ex:10 perday,7 perday,30 perday
    @ApiModelProperty(value = "SettlementPeriodEnum")
    private String settlementPeriod;

    // 佣金计算类型 BY_GAME_TYPE,ALL_GAME_TYPES
    @ApiModelProperty(value = "commissionValues")
    private String commissionValues;


}


