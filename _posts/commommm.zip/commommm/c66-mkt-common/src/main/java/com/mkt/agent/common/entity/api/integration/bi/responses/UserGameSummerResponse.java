package com.mkt.agent.common.entity.api.integration.bi.responses;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.mkt.agent.common.jackson.serializer.BigDecimalSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
@ApiModel(description = "BI原始数据")
public class UserGameSummerResponse {

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "loginName", example = "Amida001")
    private String loginName;

    @ApiModelProperty(value = "turnoverSum", example = "10000")
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal turnoverSum;
    // 平台收入金额：GGR类型佣金计算使用'
    @ApiModelProperty(value = "ggrSum")
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal ggrSum;

    // 玩家输赢金额
    @ApiModelProperty(value = "win or loss")
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal outcomeSum;

    // 游戏类型
    @ApiModelProperty(value = "gameType")
    private String gameType;

}
