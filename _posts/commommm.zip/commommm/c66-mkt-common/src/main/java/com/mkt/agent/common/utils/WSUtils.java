package com.mkt.agent.common.utils;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;


/**
 * @Description: ws系统调用相关工具类
 * @Author: PTMinnisLi
 * @Date: 2023/6/20
 */
public class WSUtils {

    /**
     * ws登录密码加密方法
     *
     * @param plainPwd  密码
     * @param loginName 账号(转小写)
     * @return 加密后的密码
     */
    public static String encryptedPasswordOf(String plainPwd, String loginName) {
        return DigestUtils.md5Hex(plainPwd + "{" + loginName.toLowerCase() + "}");
    }

    /**
     * 解密wsCustomers内容
     *
     * @param productId      C66
     * @param decryptContent 加密内容
     * @param encryptCode    encryptCode
     * @param key            key
     * @return 解密邮箱
     */
    public static String decryptContentFromWSCustomers(String productId, String decryptContent, String encryptCode, String key) {
        if (StringUtils.isEmpty(decryptContent)) {
            return StringUtils.EMPTY;
        }
        PHPDESEncrypt phpDESEncrypt = new PHPDESEncrypt(productId, encryptCode, key);
        return phpDESEncrypt.decrypt(decryptContent);
    }
}
