package com.mkt.agent.common.entity.api.agentapi.requests;


import com.mkt.agent.common.enums.CustomizedValidationContents;
import com.mkt.agent.common.valid.EnumValid;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * description: 批量创建代理实体类
 * @Date: 2023/10/19 18:36
 * @Version: 1.0.0
 * @Author: Lucian
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TAgentCustomersBatchReq {

    /*
    批量创建的代理数量
     */
    private Integer agentNumber;

    @ApiModelProperty(value = "批量创建代理的前缀", example = "gto")
    private String prefix;

    @ApiModelProperty(value = "所属产品   C66")
    private String productId = "C66";

    /*
        代理类型 0:普通,1:专业代理
    */
    @ApiModelProperty(value = "代理类型 0:普通,1:专业代理")
    @NotNull(message = "agent type is not blank", groups = {InputValidationGroup.createUserByBatch.class})
    @EnumValid(contents = CustomizedValidationContents.sub_agent_type_values,groups = {InputValidationGroup.createUserByBatch.class})
    private Integer agentType;

    /*
        代理可以发展最大下级代理层数
    */
    @ApiModelProperty(value = "可发展最大下级代理层数 0,1,2,3,4")
    @EnumValid(contents = CustomizedValidationContents.developable_level_values2,groups = {InputValidationGroup.createUserByBatch.class})
    private Integer developableLevel;

    private String commissionPlanName;

    @ApiModelProperty(value = "佣金方案code")
    @NotNull(message = "commission contract code is not blank",groups = {InputValidationGroup.createUserByBatch.class})
    private Long commissionContractCode;

    @ApiModelProperty(value = "父级代理")
    private String parentId;

    @ApiModelProperty(value = "创建人")
    private String createBy;
    /*
        1:Bingoplus  2:Arenaplus  3:Gameplus
    */
    @ApiModelProperty(value = "siteId 1:Bingoplus  2:Arenaplus  3:Gameplus")
    @EnumValid(contents = CustomizedValidationContents.site_id_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class} )
    private Integer siteId;

    @ApiModelProperty(value = "佣金比例集合")
    @NotEmpty(message = "settlementPercentageList array is not blank", groups = InputValidationGroup.SubInsert.class )
    private List<SettlementPercentageReq> settlementPercentageList;

}
