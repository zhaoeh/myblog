package com.mkt.agent.exclude.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * 公共配置类
 *
 * @program: riskcontrol-common
 * @description: riskcontrol-common模块-公共配置类--
 * @author: Erhu.Zhao
 * @create: 2023-10-18 15:28
 **/
@Configuration
@ComponentScan(basePackages = {"com.mkt.agent.exclude.signature"})
@Data
@RefreshScope
public class SignatureConfig {

    @Value(value = "${signature.validationPeriodOfMinute:10}")
    private long validationPeriodOfMinute;

}
