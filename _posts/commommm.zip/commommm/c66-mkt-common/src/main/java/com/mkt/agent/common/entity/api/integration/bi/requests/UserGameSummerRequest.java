package com.mkt.agent.common.entity.api.integration.bi.requests;

import com.mkt.agent.common.entity.api.integration.base.BaseRequest;
import lombok.Data;

@Data
public class UserGameSummerRequest extends BaseRequest {

    private String date;

    private String month;

    private String name;
}
