package com.mkt.agent.common.entity.api.jobapi.requests;

import lombok.Data;

/**
 * @author Colson
 * @date 8/29/2023
 */
@Data
public class AgentContractBindUpdateRequest {

    /**
     * t_agent_contract_bind_test id*
     */
    private Long id;

    private Long agentCount;

}
