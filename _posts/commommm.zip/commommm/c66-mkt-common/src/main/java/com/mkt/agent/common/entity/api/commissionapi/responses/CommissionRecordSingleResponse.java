package com.mkt.agent.common.entity.api.commissionapi.responses;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.mkt.agent.common.jackson.serializer.BigDecimalSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
@ApiModel(description = "佣金记录信息")
public class CommissionRecordSingleResponse {

    // 佣金记录id：佣金记录唯一标识
    @ApiModelProperty(value = "commission record ID", example = "1,auto increment")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private Long id;
    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount", example = "Amida001")
    private String agentAccount;
    // 代理类型：0：General Line (普通代理)，1：Professional Line(专业代理可发展下级)
    @ApiModelProperty(value = "agentType", example = "0:General line 1:Professional line")
    private Integer agentType;
    // 代理上级代理账号：父级代理的账号
    @ApiModelProperty(value = "parentAccount", example = "level1 agent's parent account is acc66")
    private String parentAccount;
    // 产品名称：ex:bingoplus,areana 默认值all_type
    @ApiModelProperty(value = "productId", example = "game name like bingo plus default all_type")
    private String productId;
    // 佣金方案名称
    @ApiModelProperty(value = "commissionPlanName", example = "name of commission plan")
    private String commissionPlanName;

    @ApiModelProperty(value = "settleDateStart", example = "5.1")
    private String settleDateStart;
    @ApiModelProperty(value = "settleDateEnd", example = "5.10")
    private String settleDateEnd;
    // 实际结算日期（月份）
    @ApiModelProperty(value = "settleMonth", example = "5.1")
    private String settleMonth;
    // 佣金记录状态：0:清算中pending,1:同意agreed,2:拒绝rejected
    @ApiModelProperty(value = "actualSettlementPeriod",
            example = "0:initial status meaning pending," +
                    "1:FIRST_AGREED," +
                    "2:FIRST_REJECTED," +
                    "3:SECOND_AGREED," +
                    "4:SECOND_REJECTED," +
                    "5:PAID,"+
                    "6:AGREE")
    private Integer status;
    // 佣金金额：根据佣金方案以及投注金额或平台收益金额计算得出
    @ApiModelProperty(value = "commissionAmount", example = "1000")
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal commissionAmount;
    // 实际佣金金额：由管理运营人员结算给订单代理或代理结算给下级代理
    @ApiModelProperty(value = "actualCommissionAmount", example = "900")
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal actualCommissionAmount;
    // 补发佣金:有上级代理根据实际情况补发给下级代理的佣金金额
    @ApiModelProperty(value = "appendCommissionAmount", example = "100")
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal appendCommissionAmount;

    // 本身代理等级:数据来自于代理表，共五级：1，2，3，4，5
    @ApiModelProperty(value = "agentLevel", example = "the level of agent like 1,2,3,4,5")
    private Integer agentLevel;
    // 代理所属顶级代理账号：顶级代理账号为系统简称：acc66
    @ApiModelProperty(value = "level1AgentAccount", example = "the acount of parent agent like acc66")
    private String level1AgentAccount;


    // 佣金记录创建时间
    @ApiModelProperty(value = "createTime", example = "05/18/2023 08:30:45")
    private String createTime;


}
