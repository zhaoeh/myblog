package com.mkt.agent.common.entity.api.jobapi.responses;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.entity.api.agentapi.TAgentContract;
import com.mkt.agent.common.entity.api.agentapi.responses.SettlementPercentageResp;
import com.mkt.agent.common.utils.SerializationUti;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.List;

@Data
public class AgentDetails extends TAgentContract {

    /*
       客户id
   */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long customersId;

    /*
        登录名
    */
    private String loginName;

    /*
        产品
   */
    private String productId;

    /*
        父级代理
   */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long parentId;

    /*
        顶级代理
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long topAgentId;

    /*
         创建人
    */
    private String parentName;

    /*
        代理类型 0:普通 1:专业代理
    */
    private Integer agentType;

    /*
        代理级别
    */
    private Integer agentLevel;

    /*
        备注
    */
    private String remarks;

    /*
        siteId 1:Bingoplus  2:Arenaplus  3:Gameplus
    */
    private Integer siteId;

    //真实的佣金方案
    private String bindPercentageDetails;

    private List<SettlementPercentageResp> settlementPercentageResp;


    @Override
    public String toString() {
        return "AgentDetails{" +
                "customersId=" + customersId +
                ", loginName='" + loginName + '\'' +
                ", productId='" + productId + '\'' +
                ", parentId=" + parentId +
                ", parentName='" + parentName + '\'' +
                ", agentType=" + agentType +
                ", agentLevel=" + agentLevel +
                ", remarks='" + remarks + '\'' +
                ", siteId=" + siteId +
                ", bindPercentageDetails='" + bindPercentageDetails + '\'' +
                ", settlementPercentageResp=" + settlementPercentageResp +
                ",  id=" + super.getId() +
                ", commissionPlanName='" + super.getCommissionPlanName() + '\'' +
                ", commissionPlanType='" + super.getCommissionPlanType() + '\'' +
                ", settlementPeriod='" + super.getSettlementPeriod() + '\'' +
                ", settlementConditions=" + super.getSettlementConditions() +
                ", activeUserTurnover=" + super.getActiveUserTurnover() +
                ", activeUserHeadcount=" + super.getActiveUserHeadcount() +
                ", commissionValues='" + super.getCommissionValues() + '\'' +
                ", createdBy='" + super.createBy + '\'' +
                ", isDeleted=" + isDeleted +
                ", createTime=" + createTime +
                ", updatedBy='" + super.updateBy + '\'' +
                ", updateTime=" + updateTime +
                '}';
    }

    public List<SettlementPercentageResp> getSettlementPercentageResp() {
        if(StringUtils.isNoneBlank(bindPercentageDetails)){
            return SerializationUti.deserializeFromString(bindPercentageDetails,SettlementPercentageResp.class);
        }
        return Arrays.asList();
    }
}
