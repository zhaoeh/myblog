package com.mkt.agent.common.fast.remediation;

import com.alibaba.nacos.common.utils.CollectionUtils;
import com.mkt.agent.common.core.TiFunction;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.fast.core.FastCore;
import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.common.fast.core.FastUtils;
import com.mkt.agent.common.fast.enums.CheckPointTypeEnums;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import com.mkt.agent.common.fast.pojo.DailyMktUserMapping;
import com.mkt.agent.common.fast.pojo.FastCustomers;
import com.mkt.agent.common.fast.pojo.SimpleCustomers;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @description: 玩家-代理-关系转移补救器（以代理为维度）
 * @author: ErHu.Zhao
 * @create: 2024-04-08
 **/
@Component
@Slf4j
public class TransferOfAgentRemediation {

    private final FastCore fastCore;

    public TransferOfAgentRemediation(FastCore fastCore) {
        this.fastCore = fastCore;
    }

    public void doTransferOfAgentRemediation(FastContext fastContext,
                                             StrategyEnums strategy,
                                             SqlSessionFactory factory,
                                             List<TAgentCustomers> agents,
                                             TiFunction<FastContext, List<String>, Boolean, Map<String, List<SimpleCustomers>>> superAgentChainsMapSupply) {
        log.info("begin doTransferOfAgentRemediation");
        if (CollectionUtils.isEmpty(agents)) {
            return;
        }
        Map<String, String> currentAgentsMapping = fastCore.obtainDesensMapping(fastContext, agents);
        if (MapUtils.isEmpty(currentAgentsMapping)) {
            return;
        }
        Map<String, List<SimpleCustomers>> superAgentChainsMap = null;
        if (Objects.nonNull(superAgentChainsMapSupply)) {
            superAgentChainsMap = superAgentChainsMapSupply.apply(fastContext, agents.stream().map(TAgentCustomers::getLoginName).collect(Collectors.toList()), false);
        }
        Map<Integer, List<FastCustomers>> level2AgentsMapping = agents.stream().collect(Collectors.groupingBy(TAgentCustomers::getAgentLevel, Collectors.mapping(ag -> FastCustomers.builder().
                agentLevel(ag.getAgentLevel()).loginName(currentAgentsMapping.get(ag.getLoginName())).
                targetStatus(fastCore.obtainTargetStatusOfAgent(ag)).build(), Collectors.toList())));
        this.doTransferOfAgent(fastContext, strategy, factory, level2AgentsMapping, superAgentChainsMap);
        log.info("end doTransferOfAgentRemediation");
    }


    /**
     * 执行代理编辑补救
     *
     * @param level2AgentsMapping
     */
    public void doTransferOfAgent(FastContext fastContext, StrategyEnums strategy, SqlSessionFactory factory,
                                  Map<Integer, List<FastCustomers>> level2AgentsMapping,
                                  Map<String, List<SimpleCustomers>> superAgentChainsMap) {
        if (MapUtils.isEmpty(level2AgentsMapping)) {
            return;
        }
        level2AgentsMapping.forEach((level, agents) -> {
            if (Objects.isNull(level)) {
                return;
            }
            if (CollectionUtils.isEmpty(agents)) {
                return;
            }
            // 获取当前level的所有代理名称
            List<String> agentNames = agents.stream().map(FastCustomers::getLoginName).collect(Collectors.toList());
            // 获取当前level级别所有代理的 玩家-代理 关系映射表
            List<DailyMktUserMapping> user2AgentsMappingOfLevel = fastContext.getQueryUserMappingByNames().apply(level, agentNames);
            if (CollectionUtils.isEmpty(user2AgentsMappingOfLevel)) {
                return;
            }
            Map<String, FastCustomers> agentName2Map = agents.stream().collect(Collectors.toMap(FastCustomers::getLoginName, Function.identity()));
            if (MapUtils.isEmpty(agentName2Map)) {
                return;
            }
            if (Objects.isNull(superAgentChainsMap)) {
                fastContext.setEvent(CheckPointTypeEnums.TransferStatusOfAgent);
                user2AgentsMappingOfLevel = user2AgentsMappingOfLevel.stream().map(m -> fastCore.refactorMappingStatusInfoByLevel(m, level, agentName2Map)).collect(Collectors.toList());
            } else {
                fastContext.setEvent(CheckPointTypeEnums.TransferChainsOfAgent);
                user2AgentsMappingOfLevel = user2AgentsMappingOfLevel.stream().map(m -> fastCore.refactorMappingChainsInfoByLevel(m, level, superAgentChainsMap)).collect(Collectors.toList());
            }

            if (CollectionUtils.isEmpty(user2AgentsMappingOfLevel)) {
                return;
            }
            fastCore.batchUpdateWithUserMappingWithRetry(fastContext, strategy, agentNames, FastUtils.buildInsertSqlWithUserMapping(user2AgentsMappingOfLevel), factory, 0);
        });
    }

}
