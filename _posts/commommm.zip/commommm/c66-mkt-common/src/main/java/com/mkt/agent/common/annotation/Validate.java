package com.mkt.agent.common.annotation;

import org.springframework.core.annotation.Order;

import javax.validation.groups.Default;
import java.lang.annotation.*;

/**
 * @Description: 参数校验注解
 * @Author: PTMinnisLi
 * @Date: 2023/7/26
 */
@Documented
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Order(999)
public @interface Validate {
    Class<?>[] value() default {Default.class};
}
