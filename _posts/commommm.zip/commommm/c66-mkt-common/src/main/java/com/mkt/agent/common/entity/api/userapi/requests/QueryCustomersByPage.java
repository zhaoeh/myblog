package com.mkt.agent.common.entity.api.userapi.requests;

import com.mkt.agent.common.entity.PageRequest;
import lombok.Data;

@Data
public class QueryCustomersByPage extends PageRequest {

    private String loginName;

    private int flag;


}
