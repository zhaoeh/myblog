package com.mkt.agent.common.entity.api.agentapi.responses;

import com.mkt.agent.common.annotation.ExcelColumn;
import com.mkt.agent.common.entity.api.agentapi.TAgentContractList;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import com.mkt.agent.common.utils.SerializationUti;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * @ClassName CommissionPlanResp
 * @Description 佣金方案
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Data
public class TAgentContractResp implements Serializable {

    @ApiModelProperty(value = "PLAN_ID")
    @ExcelColumn(value = "Plan Id",order = 1)
    private String id;

    /*
        佣金方案类型
    */
    @ApiModelProperty(value = "COMMISSION_PLAN_NAME")
    @ExcelColumn(value = "Commission Plan Name",order = 2)
    private String commissionPlanName;

    /*
        佣金方案类型
        0:turnover, 1:GGR
   */
    @ApiModelProperty(value = "COMMISSION_PLAN_TYPE")
    @ExcelColumn(value = "Commission Plan Type",order = 3)
    private String commissionPlanType;

    /*
        结算周期
        MONTH,ONE-THIRD_MONTH,WEEK,DAY
    */

    @ApiModelProperty(value = "SETTLEMENT_PERIOD")
    @ExcelColumn(value = "Settlement Period",order = 4)
    private String settlementPeriod;

    /*
        结算条件
        0,1
   */
    @ApiModelProperty(value = "SETTLEMENT_CONDITIONS [0,1]")
    private int settlementConditions;

    /*
        活跃用户投注额
        SETTLEMENT_PERIOD 为1时必填,支持小数
    */
    @ApiModelProperty(value = "ACTIVE_USER_TURNOVER [SETTLEMENT_PERIOD 为1时必填,支持小数]")
    private int activeUserTurnover;

    @ApiModelProperty(value = "ACTIVE_USER_TURNOVER [SETTLEMENT_PERIOD 为1时必填,支持小数]")
    private BigDecimal activeUserTurnover1;
    /*
        活跃用户数量
        SETTLEMENT_PERIOD 为1时必填,整数
    */
    @ApiModelProperty(value = "ACTIVE_USER_HEADCOUNT [SETTLEMENT_PERIOD 为1时必填,支持小数]")
    private int activeUserHeadcount;

    /*
        结算类型
        ALL_GAME_TYPES,BY_GAME_TYPE
    */
    @ApiModelProperty(value = "COMMISSION_VALUES")
    private String commissionValues;

    /*
     ALL_GAME_TYPES:[{'Range_Turnover_Start':'0','Range_Turnover_END':'1000','Percentage':'1%','order':0}.{'Range_Turnover_Start':'1001','Range_Turnover_END':'5000','Percentage':'3%','order':1}….]
     BY_GAME_TYPE:[{'Range_Turnover_Start':'0','Range_Turnover_END':'1000','GAME1':'0.2%','GAME2':'0.2%'....,'order':0}.{'Range_Turnover_Start':'1001','Range_Turnover_END':'5000','GAME1':'0.5%','GAME2':'0.5%'....,'order':1}….]
    */

    /*
        计划内容
    */
    @ApiModelProperty(value ="PERCENTAGE_DETAILS")
    private String percentageDetails;

    /*
        被代理聚合
    */
    @ApiModelProperty(value ="AGENT_COUNT")
    @ExcelColumn(value = "Agent Count",order = 5)
    private int agentCount;

    /*
         创建人
    */
    @ApiModelProperty(value ="CREATED_BY")
    @ExcelColumn(value = "creator",order = 7)
    private String createBy;

    /*
        创建时间
    */
    @ApiModelProperty(value = "CREATE_TIME")
    @ExcelColumn(value = "Create Time",order = 6)
    private String createTime;

    @ApiModelProperty(value = "结算比例")
    private List<SettlementPercentageReq> settlementPercentageList;


    @ApiModelProperty(value = "结算比例")
    private  List<TAgentContractList> agentContractListReqList ;


    @ApiModelProperty(value = "发展层级")
    private Integer developableLevel;



    @ApiModelProperty(value = "结算比例")
    private String   isFd ;

    @ApiModelProperty(value = "结算比例")
    private int fdCount ;

    @ApiModelProperty(value = "结算比例")
    private BigDecimal fdCommission;

    @ApiModelProperty(value = "结算比例")
    private BigDecimal activeUserCommission;


    public void handleSettlementPercentageList(String percentage_details) {
        this.settlementPercentageList = SerializationUti.deserializeFromString(percentage_details,SettlementPercentageReq.class);
    }


}
