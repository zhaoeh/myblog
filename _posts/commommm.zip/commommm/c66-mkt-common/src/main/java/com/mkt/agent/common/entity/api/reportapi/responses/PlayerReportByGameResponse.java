package com.mkt.agent.common.entity.api.reportapi.responses;


import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.mkt.agent.common.enums.GameTypeEnum;
import com.mkt.agent.common.jackson.serializer.BigDecimalSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Data
@ApiModel(description = "PlayerReportByGameResponse")
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PlayerReportByGameResponse {

    @ApiModelProperty(value = "gameTypeName", example = "Sport")
    private String gameTypeName;

    @ApiModelProperty(value = "turnoverSum", example = "10000.00")
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal turnover;

    @ApiModelProperty(value = "ggrSum", example = "1000.00")
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal ggr;

    @ApiModelProperty(value = "outcomeSum", example = "10000.00")
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal winOrLoss;

    @ApiModelProperty(value = "gameType", example = "1")
    private Integer gameType;

    @ApiModelProperty(value = "game", example = "'Sport', 10000.00, 1000.00, 10000.00, 1")
    private List<PlayerReportByGameResponse> game;

    public void setGameType(Integer gameType) {
        this.gameType = gameType;
        this.gameTypeName = GameTypeEnum.getNameByCode(gameType);
    }

    /**
     * 按照游戏类型新增 Summary 汇总数据
     * @param playerReportByGameResponses
     */
    public static PlayerReportByGameResponse buildSummary(List<PlayerReportByGameResponse> playerReportByGameResponses) {
        BigDecimal turnover = BigDecimal.ZERO;
        BigDecimal ggr = BigDecimal.ZERO;
        BigDecimal winOrLoss = BigDecimal.ZERO;
        for (PlayerReportByGameResponse playerReportByGameRespons : playerReportByGameResponses) {
            turnover = turnover.add(playerReportByGameRespons.getTurnover());
            ggr = ggr.add(playerReportByGameRespons.getGgr());
            winOrLoss = winOrLoss.add(playerReportByGameRespons.getWinOrLoss());
        }

        return PlayerReportByGameResponse.builder()
                .gameType(-1)
                .turnover(turnover)
                .ggr(ggr)
                .winOrLoss(winOrLoss)
                .game(playerReportByGameResponses)
                .build();
    }
}
