package com.mkt.agent.common.entity.api.agentapi.requests;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * @Description: 全局配置更新/新增请求类
 * @Author: PTMinnisLi
 * @Date: 2023/6/29
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
//@ApiModel(value = "全局配置更新/新增请求类")
public class AgentGlobalConfigSaveRequest {

    @ApiModelProperty(value = "产品id" ,example = "C66")
    private String productId;

    @ApiModelProperty(value = "配置项名称-key[未设置时为新增]", example = "WITHDRAWAL_RISK_RECEIVE/WITHDRAWAL_RISK_AMOUNT")
    @NotEmpty(message = "Config name cannot be empty")
    private String paramName;

    @ApiModelProperty(value = "配置项值-value，必须为数值类型", required = true)
    @NotEmpty(message = "Config value cannot be empty")
    private String paramValue;

    @ApiModelProperty(value = "描述")
    private String paramDesc;

    @ApiModelProperty(value = "启用/禁用配置,启用:1/禁用0", required = true, example = "1")
    @NotNull(message = "isEnable cannot be empty")
    private Integer isEnable;

    @ApiModelProperty(value = "创建人")
    private String createBy;

    @ApiModelProperty(value = "更新人")
    private String updateBy;
}
