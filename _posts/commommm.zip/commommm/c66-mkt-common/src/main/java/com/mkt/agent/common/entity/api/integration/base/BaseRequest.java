package com.mkt.agent.common.entity.api.integration.base;

import java.util.UUID;

public class BaseRequest {

    private String serialNumber = UUID.randomUUID().toString();

}
