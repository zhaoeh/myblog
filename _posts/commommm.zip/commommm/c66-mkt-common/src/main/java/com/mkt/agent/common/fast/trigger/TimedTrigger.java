package com.mkt.agent.common.fast.trigger;

import com.mkt.agent.common.core.TiFunction;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.fast.core.FastCore;
import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.common.fast.enums.CheckPointTypeEnums;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import com.mkt.agent.common.fast.flow.FlowCenter;
import com.mkt.agent.common.fast.pojo.IncrementCheckPoint;
import com.mkt.agent.common.fast.pojo.SimpleCustomers;
import com.mkt.agent.common.fast.remediation.DesensMappingOfAgentRemediation;
import com.mkt.agent.common.fast.remediation.TransferOfAgentRemediation;
import com.mkt.agent.common.fast.remediation.TransferOfUserRemediation;
import com.mkt.agent.common.task.AsyncTasks;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @description: 定时触发器（全量补救/checkPoint定时补救）--
 * @author: ErHu.Zhao
 * @create: 2024-04-16
 **/
@Component
@Slf4j
public class TimedTrigger {

    private final AsyncTasks asyncTasks;

    private final FastCore fastCore;

    private final DesensMappingOfAgentRemediation desensMappingOfAgentRemediation;

    private final TransferOfAgentRemediation transferOfAgentRemediation;

    private final TransferOfUserRemediation transferOfUserRemediation;

    private final FlowCenter flowCenter;

    public TimedTrigger(AsyncTasks asyncTasks,
                        FastCore fastCore,
                        DesensMappingOfAgentRemediation desensMappingOfAgentRemediation,
                        TransferOfAgentRemediation transferOfAgentRemediation,
                        TransferOfUserRemediation transferOfUserRemediation,
                        FlowCenter flowCenter) {
        this.asyncTasks = asyncTasks;
        this.fastCore = fastCore;
        this.desensMappingOfAgentRemediation = desensMappingOfAgentRemediation;
        this.transferOfAgentRemediation = transferOfAgentRemediation;
        this.transferOfUserRemediation = transferOfUserRemediation;
        this.flowCenter = flowCenter;
    }

    /**
     * 定时器checkpoint补救
     *
     * @param fastContext
     * @param factory
     */
    public void triggerOnCheckPoint(FastContext fastContext, SqlSessionFactory factory) {
        asyncTasks.asyncTask(this::doTriggerCheckPoint, fastContext, factory);
    }

    /**
     * 定时器全量补救
     *
     * @param fastContext
     * @param factory
     */
    public void triggerOnFlowCenter(FastContext fastContext, SqlSessionFactory factory) {
        asyncTasks.asyncTask(flowCenter::doFlows, fastContext, factory);
    }

    /**
     * 补救代理脱敏
     */
    private void doTriggerCheckPoint(FastContext fastContext, SqlSessionFactory factory) {
        if (fastCore.queryCheckPointsCount(fastContext, IncrementCheckPoint.builder().build()) == 0) {
            return;
        }
        log.info("begin doTriggerCheckPoint");
        List<SimpleCustomers> agents = fastCore.queryAgentWithCheckPoint(fastContext,
                IncrementCheckPoint.builder().eventType(CheckPointTypeEnums.DesensMappingOfAgent.getEventType()).build());
        desensMappingOfAgentRemediation.doDesensMappingOfAgentRemediation(fastContext, StrategyEnums.CheckPointDesensMappingStrategy,
                agents.stream().map(SimpleCustomers::getLoginName).collect(Collectors.toList()));
        processTransferOfAgentRemediation(fastContext, factory, CheckPointTypeEnums.TransferStatusOfAgent.getEventType(), null);
        processTransferOfAgentRemediation(fastContext, factory, CheckPointTypeEnums.TransferChainsOfAgent.getEventType(), fastCore::obtainSuperAgentChainsMap);

        /**
         * 以玩家维度执行玩家-代理关系转移checkpoint补救
         */
        List<IncrementCheckPoint> checkPoints = fastCore.queryCheckPoints(fastContext,
                IncrementCheckPoint.builder().eventType(CheckPointTypeEnums.TransferOfUser.getEventType()).build());
        if (!CollectionUtils.isEmpty(checkPoints)) {
            List<TCustomerLayer> players = fastContext.getQueryPlayersByNames().apply(checkPoints.stream().map(IncrementCheckPoint::getResourceName).collect(Collectors.toList()));
            transferOfUserRemediation.doTransferOfUserRemediation(fastContext, StrategyEnums.ListenerTransferOfUserStrategy, factory, null, players);
        }
        log.info("end doTriggerCheckPoint");
    }

    /**
     * 以代理维度执行玩家-代理关系转移checkpoint补救
     *
     * @param fastContext
     * @param factory
     * @param eventType
     * @param superAgentChainsMapSupply
     */
    private void processTransferOfAgentRemediation(FastContext fastContext, SqlSessionFactory factory, int eventType, TiFunction<FastContext, List<String>, Boolean, Map<String, List<SimpleCustomers>>> superAgentChainsMapSupply) {
        List<IncrementCheckPoint> checkPoints = fastCore.queryCheckPoints(fastContext, IncrementCheckPoint.builder().eventType(eventType).build());
        if (!CollectionUtils.isEmpty(checkPoints)) {
            List<String> agentNames = checkPoints.stream().map(IncrementCheckPoint::getResourceName).collect(Collectors.toList());
            List<SimpleCustomers> simpleCustomers = fastCore.querySimpleCustomers(fastContext, agentNames);
            if (!CollectionUtils.isEmpty(simpleCustomers)) {
                List<TAgentCustomers> targetAgents = simpleCustomers.stream().map(item -> TAgentCustomers.builder().
                        agentLevel(item.getAgentLevel()).loginName(item.getLoginName()).
                        parentName(item.getParentName()).isEnable(item.getIsEnable()).
                        isDeleted(item.getIsDeleted()).build()).collect(Collectors.toList());
                transferOfAgentRemediation.doTransferOfAgentRemediation(fastContext, StrategyEnums.CheckPointTransferOfAgentStrategy, factory, targetAgents, superAgentChainsMapSupply);
            }
        }
    }

}
