package com.mkt.agent.common.player.model;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TAgentRefreshLog;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.TAgentUpdateLog;
import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-02-05
 **/
@Builder
@Data
public class PlayerMapperHolder {

    /**
     * 查询所有代理集合 mapper
     */
    private Function<Integer, List<TAgentCustomers>> agentsMapper;

    /**
     * 查询某个代理团队中所有叶子代理集合（包含自己）
     */
    private BiFunction<String, String, List<TAgentCustomers>> teamAgentsMapper;

    /**
     * 根据level获取对应的代理集合
     */
    private BiFunction<List<TAgentCustomers>, Integer, List<TAgentCustomers>> agentsByLevelMapper;

    /**
     * 执行 t_agent_count_group_day 批量插入的mapper
     */
    private Function<List<TAgentCountGroup>, Integer> groupInsertMapper;

    /**
     * 执行 t_agent_count_group_day 批量删除的mapper
     */
    private Function<TAgentCountGroup, Integer> groupDeleteMapper;

    /**
     * 根据请求返回对应明细count数的mapper
     */
    private Function<TAgentCountGroup, List<TAgentCountGroup>> agentCountMapper;

    /**
     * 返回 t_agent_count_group_day 总数的mapper
     */
    private Supplier<Integer> agentTotalCountMapper;

    /**
     * 根据请求实时从BI返回某一批用户在某个时间段内按天分组后的明细count数据的mapper
     */
    private Function<TAgentCountGroup, List<TAgentCountGroup>> targetAgentsTransCountMapper;

    /**
     * 从t_agent_count_group_day表获取指定日期范围内指定用户集对应的按天维度交易count的mapper
     */
    private Function<TAgentCountGroup, List<TAgentCountGroup>> transCountsMapper;

    /**
     * 获取某些代理所有下级直属用户的mapper
     */
    private Function<TAgentCountGroup, List<String>> lowerDirectsMapper;

    /**
     * 获取某些代理所有下级代理用户的mapper
     */
    private Function<TAgentCountGroup, List<String>> lowerAgentsMapper;

    /**
     * 获取某些代理的下级团队用户的mapper
     */
    private Function<TAgentCountGroup, List<String>> lowerUsersMapper;

    /**
     * 获取目标用户集合的mapper
     * 该mapper有可能是获取一批代理用户的所有团队用户集
     * 也可能是获取一批代理用户的下级直属用户集
     * 也可能是获取一批代理用户的下级代理用户集
     */
    private Function<TAgentCountGroup, List<String>> targetUsersMapper;

    /**
     * 数量汇总表t_agent_count_group_day最大最小日期范围mapper
     */
    private Function<TAgentCountGroup, TAgentCountGroup> countDateRangeMapper;

    /**
     * 查询 t_agent_refresh_log 记录
     */
    private Function<TAgentRefreshLog, String> countLogRangeMapper;

    private Function<TAgentRefreshLog, List<TAgentRefreshLog>> countLogFailedRecordsMapper;

    private Function<TAgentRefreshLog, List<TAgentRefreshLog>> countLogDetailsMapper;

    /**
     * t_agent_refresh_log 插入mapper
     */
    private Function<List<TAgentRefreshLog>, Integer> countLogInsertMapper;

    /**
     * t_agent_refresh_log 删除mapper
     */
    private Function<TAgentRefreshLog, Integer> countLogDeleteMapper;

    private Function<TAgentRefreshLog, Integer> countLogForceDeleteMapper;

    /**
     * bi t_daily_mkt_agent_all最大最小日期范围mapper
     */
    private Supplier<Map<String, Object>> biDateRangeMapper;

    /**
     * 判断某个代理的代理关系是否发生变更
     */
    private Function<String, Result<TAgentUpdateLog>> isAgentChangedMapper;

    /**
     * 当某个代理关系发生变更后的后置逻辑
     */
    private Consumer<String> agentChangedConsumer;

}
