package com.mkt.agent.common.valid;

import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.Assert;

/**
 * @description: 校验器helper
 * @author: ErHu.Zhao
 * @create: 2024-01-17
 **/
@Slf4j
public class ValidateHelper {
    private static int passwordBeginLength = 8;
    private static int passwordEndLength = 16;

    /**
     * 校验密码
     *
     * @param password 密码
     */
    public static void validatePassword(String password) {
        Assert.notNull(password, "password cannot be null");
        if (password.length() < passwordBeginLength || password.length() > passwordEndLength) {
            log.error("Password must be 8-16 characters and number");
            throw new BusinessException(ResultEnum.PASSWORD_LENGTH_INVALIDATED);
        }
        if (!(password.length() == password.replaceAll("[^a-zA-Z0-9]", "").length())) {
            log.error("Password are only allowed to contain numbers and English letters");
            throw new BusinessException(ResultEnum.PASSWORD_CREATE_FAIL);
        }
        if ((password.length() == password.replaceAll("[^a-zA-Z]", "").length()) ||
                (password.length() == password.replaceAll("[^0-9]", "").length())) {
            log.error("Password must contain numbers and English letters");
            throw new BusinessException(ResultEnum.PASSWORD_TOO_SIMPLE);
        }
    }
}
