package com.mkt.agent.exclude.signature.filter;

import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.SecureUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mkt.agent.common.wrapper.RequestWrapper;
import com.mkt.agent.exclude.config.SignatureConfig;
import com.mkt.agent.exclude.signature.exception.SignatureCheckException;
import com.mkt.agent.exclude.signature.exception.SignatureHeaderMissingException;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.entity.ContentType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;


/**
 * 签名校验过滤器
 * @author yiqiang
 * @date 2024/05/14
 */
@Order(5)
@Setter
@Component
@Slf4j
public class SignatureCheckFilter implements Filter {

    /**
     * 签名Header的key
     */
    @Value("${signature.headerSignature:Signature}")
    private String headerSignature;
    /**
     * 签名校验之时间戳 Header key
     */
    @Value("${signature.headerTimestamp:Timestamp}")
    private String headerTimestamp;
    /**
     * 与前端约定的 加签随机值
     */
    @Value("${signature.randomStr:n:98*Vm:GyBW}")
    private String randomStr;

    /**
     * Nacos 动态配置获取
     */
    @Autowired
    private SignatureConfig signatureConfig;

    private String[] whitelist;

    private static final String SIGNATURE_EXCEPTION = "signatureException";

    private static final String ILLEGAL_REQUEST = "Illegal Request";

    private static final String SIGNATURE_EXCEPTION_URL = "/signatureException";

    private static final String SWAGGER_API = "/webjars";

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest servletRequest = (HttpServletRequest) request;
        // 获取请求体的数据
        String requestData;
        String contentType = servletRequest.getContentType();
        log.info("contentType : {}", contentType);

        // 因为request.getReader() 或者request.getInputStream()只能读取一次，所以我们需要自定义包装类
        RequestWrapper requestWrapper = new RequestWrapper(servletRequest);

        String requestAPI = requestWrapper.getRequestURI();
        // 文件上传类的直接放行 或者 是白名单请求则放行
        if ((StringUtils.isNotEmpty(contentType) && contentType.startsWith(ContentType.MULTIPART_FORM_DATA.getMimeType()))
                || Arrays.asList(whitelist).contains(requestAPI)
                || requestAPI.startsWith(SWAGGER_API)) {
            log.info("The request is contained in whitelist or upload type");
            chain.doFilter(requestWrapper, response);
            return;
        }

        String timestamp = requestWrapper.getHeader(headerTimestamp);

        if (StrUtil.isEmpty(timestamp)) {
            log.info("timestamp is empty");
            // 因为Filter层抛出的异常，不能被全局异常处理器捕获到，所以采用”曲线救国“的策略处理
            requestWrapper.setAttribute(SIGNATURE_EXCEPTION, new SignatureHeaderMissingException(ILLEGAL_REQUEST));
            //将异常分发到/expiredJwtException控制器
            requestWrapper.getRequestDispatcher(SIGNATURE_EXCEPTION_URL).forward(requestWrapper, response);
            return;
        }
        long now = System.currentTimeMillis();
        long duration;
        try {
            duration = now - Long.parseLong(timestamp);
        } catch (NumberFormatException e) {
            log.error(e.getMessage(), e);
            requestWrapper.setAttribute(SIGNATURE_EXCEPTION, new SignatureHeaderMissingException(ILLEGAL_REQUEST));
            requestWrapper.getRequestDispatcher(SIGNATURE_EXCEPTION_URL).forward(requestWrapper, response);
            return;
        }
        long validationPeriodOfMinute = signatureConfig.getValidationPeriodOfMinute();
        log.info("validationPeriodOfMinute: {}; duration : {}", validationPeriodOfMinute, duration);
        if (Math.abs(duration) > validationPeriodOfMinute * 60 * 1000){
            requestWrapper.setAttribute(SIGNATURE_EXCEPTION, new SignatureHeaderMissingException(ILLEGAL_REQUEST));
            requestWrapper.getRequestDispatcher(SIGNATURE_EXCEPTION_URL).forward(requestWrapper, response);
            return;
        }

        String method = requestWrapper.getMethod();
        log.info("method : {}", method);
        if (contentType == null && "POST".equals(method) && StringUtils.isEmpty(requestWrapper.getRequestData())){
            log.info("The request Content-Type is null, and params are null");
            chain.doFilter(requestWrapper, response);
            return;
        }

        // 获取Content-Type为 JSON格式的请求体数据
        if ((StringUtils.isNotEmpty(contentType) && contentType.contains("application/json"))) {
            log.info("ContentType : application/json");
            requestData = requestWrapper.getRequestData();
        } else {
            // GET类请求数据
            Map<String, String[]> parameterMap = requestWrapper.getParameterMap();
            if (MapUtil.isEmpty(parameterMap)) {
                chain.doFilter(requestWrapper, response);
                return;
            }

            // 谷歌的Gson工具可以保证Map转成String时顺序的一致性
            GsonBuilder gsonBuilder = new GsonBuilder();
            // 对特殊字符不做转义处理
            gsonBuilder.disableHtmlEscaping();
            Gson gson = gsonBuilder.create();
            requestData = gson.toJson(new LinkedHashMap<>(parameterMap));
        }

        String signature = requestWrapper.getHeader(headerSignature);
        if (StrUtil.isEmpty(signature)) {
            log.info("signature is empty");
            // 因为Filter层抛出的异常，不能被全局异常处理器捕获到，所以采用”曲线救国“的策略处理
            requestWrapper.setAttribute(SIGNATURE_EXCEPTION, new SignatureHeaderMissingException(ILLEGAL_REQUEST));
            //将异常分发到/expiredJwtException控制器
            requestWrapper.getRequestDispatcher(SIGNATURE_EXCEPTION_URL).forward(requestWrapper, response);
            return;
        }

        // 清理请求体内容。保证无特殊字符干扰验签
        requestData = requestData.replaceAll("\\[", StrUtil.EMPTY);
        requestData = requestData.replaceAll("]", StrUtil.EMPTY);
        requestData = requestData.replaceAll("\"", StrUtil.EMPTY);

        if ((StringUtils.isNotEmpty(contentType) && contentType.contains("application/x-www-form-urlencoded"))) {
            /* 表单数据做特殊处理 */
            requestData = requestData.replaceAll("\\{", StrUtil.EMPTY);
            requestData = requestData.replaceAll("}", StrUtil.EMPTY);
            requestData = requestData.replaceAll(":", "=");
        }

        // 验签，通过静态方法获取YAML中配置的随机字符串（与前端约定好）
        String slat = timestamp.concat(randomStr);
        String md5Params = requestData.concat(slat);

        log.info("md5Params: {} ", md5Params);

        String verifySignature = SecureUtil.md5(md5Params);

        log.info("verifySignature : {}", verifySignature);

        if (StrUtil.equals(signature, verifySignature)) {
            chain.doFilter(requestWrapper, response);
            return;
        }

        requestWrapper.setAttribute(SIGNATURE_EXCEPTION, new SignatureCheckException(ILLEGAL_REQUEST));
        requestWrapper.getRequestDispatcher(SIGNATURE_EXCEPTION_URL).forward(requestWrapper, response);
    }
}
