package com.mkt.agent.common.constants;

/**
 * @ClassName PageConstant
 * @Author TJSAlex
 * @Date 2023/5/18 16:07
 * @Version 1.0
 **/
public class PageConstant {

    public static int DEFAULT_PAGE_SIZE = 10;
    public static int DEFAULT_PAGE_NUM = 1;
    public static long DEFAULT_TOTAL_NUM = 0L;
}
