package com.mkt.agent.common.enums;


import com.mkt.agent.common.constants.Constants;

/**
 * 敏感信息类型枚举
 * Created by WADE on 2017/9/12 .
 */
public enum SensitiveType {

    /**
     * 真实姓名
     */
    REAL_NAME("1", "HIDE_REALNAME_TYPE", Constants.HIDE_PLACEHOLDER + Constants.HIDE_CHAR, "01"),

    /**
     * 电话号码
     */
    PHONE_NO("2", "HIDE_PHONENO_TYPE", Constants.HIDE_PLACEHOLDER + Constants.HIDE_PLACEHOLDER + Constants.HIDE_PLACEHOLDER + Constants.HIDE_CHAR + Constants.HIDE_PLACEHOLDER, "03"),
    /**
     * 银行卡号
     */
    BANK_NO("3", "HIDE_BANKNO_TYPE", Constants.HIDE_PLACEHOLDER + Constants.HIDE_CHAR + Constants.HIDE_PLACEHOLDER, "07"),

    /**
     * 银行帐号
     */
    BANK_ACCOUNT_NAME("6", "HIDE_BANKACCOUNTNAME_TYPE", Constants.HIDE_PLACEHOLDER + Constants.HIDE_CHAR + Constants.HIDE_PLACEHOLDER, "06"),

    /**
     * 邮箱
     */
    EMAIL("4", "HIDE_EMAIL_TYPE", Constants.HIDE_PLACEHOLDER + Constants.HIDE_CHAR + Constants.HIDE_PLACEHOLDER, "04"),

    /**
     * 地址
     */
    ADDRESS("5", "HIDE_ADDRESS_TYPE", Constants.HIDE_PLACEHOLDER + Constants.HIDE_PLACEHOLDER + Constants.HIDE_PLACEHOLDER, "02"),
    /**
     * 网路联系方式
     */
    ONLINE_MESSENGER("6", "HIDE_ONLINE_TYPE", Constants.HIDE_PLACEHOLDER + Constants.HIDE_PLACEHOLDER + Constants.HIDE_CHAR, "05"),

    /**
     * 身份证
     */
    CERT_ID("9", "HIDE_CERT_TYPE", Constants.HIDE_PLACEHOLDER + Constants.HIDE_CHAR, "09");

    /**
     * 枚举类型代码
     */
    private String code;
    private String constantsName;
    private String defaultHideType;
    private String encryptCode;

    SensitiveType(String code, String constantsName, String defaultHideType, String encryptCode) {
        this.code = code;
        this.constantsName = constantsName;
        this.defaultHideType = defaultHideType;
        this.encryptCode = encryptCode;
    }

    public String getCode() {
        return this.code;
    }

    public String getConstantsName() {
        return constantsName;
    }

    public String getDefaultHideType() {
        return defaultHideType;
    }

    public String getEncryptCode() {
        return encryptCode;
    }

    public static SensitiveType getConstantsNameByCode(String code) {
        for (SensitiveType sensitive_type : SensitiveType.values()) {
            if (sensitive_type.getCode().equals(code)) {
                return sensitive_type;
            }
        }
        return null;
    }
}
