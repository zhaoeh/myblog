package com.mkt.agent.common.enums;

import com.mkt.agent.common.constants.CacheConstants;

/**
 * @Description: 验证码类型
 * @Author: PTMinnisLi
 * @Date: 2023/6/14
 */
public class VerifyCodeConstants {

    /**
     * 短信常量 TODO 优化验证码类型匹配
     */
    public enum SmsVerifyCacheEnum {

        BIND_PHONE("0", CacheConstants.SMS_CODE_BIND_PHONE),
        UPDATE_PHONE("1", CacheConstants.SMS_CODE_CHANGE_PHONE),
        CHANGE_PASSWORD("2", CacheConstants.SMS_CODE_CHANGE_LOGIN_PASSWORD),
        ;

        private String code;

        private String value;

        SmsVerifyCacheEnum(String code, String value) {
            this.code = code;
            this.value = value;
        }
    }

}
