package com.mkt.agent.common.entity.api.userapi.responses;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@ApiModel("查询子级响应")
@Data
public class QueryChildrenResp {
    @ApiModelProperty("子级列表")
    private List<TCustomerSimple> children;

}
