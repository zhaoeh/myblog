package com.mkt.agent.common.entity.api.jobapi.requests.base;


import com.mkt.agent.common.entity.api.agentapi.responses.AgentCustomerContractQueryByPageResponse;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class TaskBaseRequest<T> {

    // share param

    private T t;


    private T lastAgent;


    private List<AgentCustomerContractQueryByPageResponse> agentAnddirectPlayers;

    // public param

    private String startDate;

    private String endDate;

    // 实际结算开始日期
    private LocalDate settleDateStart;
    // 实际结算结算日期
    private LocalDate settleDateEnd;

    private Integer flag;

    private Integer saveCount = 0;

    private Integer agentNums = 0;


    private boolean isOnce;


}
