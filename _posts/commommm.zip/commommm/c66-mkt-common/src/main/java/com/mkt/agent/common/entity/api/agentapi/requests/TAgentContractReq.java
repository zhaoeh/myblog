package com.mkt.agent.common.entity.api.agentapi.requests;

import com.mkt.agent.common.annotation.GameTypeColumn;
import com.mkt.agent.common.enums.CommissionValuesEnum;
import com.mkt.agent.common.enums.CustomizedValidationContents;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.utils.SerializationUti;
import com.mkt.agent.common.valid.EnumValid;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.commons.beanutils.PropertyUtils;

import javax.persistence.Column;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;

/**
 * @ClassName CommissionPlanReq
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Data
public class TAgentContractReq implements Serializable {



    @ApiModelProperty(value = "id")
    @NotNull(message = "id is not blank",groups = InputValidationGroup.Update.class)
    private Long id;

    @ApiModelProperty(value = "佣金计划名称")
    @NotBlank(message = "commissionPlanName is not blank",groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class})
    private String commissionPlanName;

    /*
       0:TURNOVER, 1:GGR
   */
    @ApiModelProperty(value = "佣金计划类型")
    @NotBlank(message = "commissionPlanType is not blank",groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class})
    @EnumValid(contents = CustomizedValidationContents.sub_commission_plan_type_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class})
    private String commissionPlanType;

    /*
       MONTH,ONE-THIRD_MONTH,WEEK,DAY
    */
    @ApiModelProperty(value = "结算周期")
    @NotBlank(message = "settlementPeriod is not blank",groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class})
    @EnumValid(contents = CustomizedValidationContents.sub_settlement_period_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class})
    private String settlementPeriod;

    /*
      0,1
   */
    @ApiModelProperty(value = "结算条件")
    @NotNull(message = "settlementConditions is not blank",groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class})
    @EnumValid(contents = CustomizedValidationContents.settlement_conditions_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class})
    private Integer settlementConditions;

    /*
     SETTLEMENT_PERIOD 为1时必填,支持小数
    */
    @ApiModelProperty(value = "活跃用户投注额")
    private int activeUserTurnover;

    @ApiModelProperty(value = "活跃用户投注额")
    private BigDecimal activeUserTurnover1;

    /*
     SETTLEMENT_PERIOD 为1时必填,整数
    */
    @ApiModelProperty(value = "活跃用户数量")
    private int activeUserHeadcount;

    /*
     ALL_GAME_TYPES,BY_GAME_TYPE
    */
    @ApiModelProperty(value = "佣金结算类型")
    @NotBlank(message = "commissionValues is not blank",groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class})
    @EnumValid(contents = CustomizedValidationContents.commission_values_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class})
    private String commissionValues;

    /*
     ALL_GAME_TYPES:[{'Range_Turnover_Start':'0','Range_Turnover_END':'1000','Percentage':'1%','order':0}.{'Range_Turnover_Start':'1001','Range_Turnover_END':'5000','Percentage':'3%','order':1}….]
     BY_GAME_TYPE:[{'Range_Turnover_Start':'0','Range_Turnover_END':'1000','GAME1':'0.2%','GAME2':'0.2%'....,'order':0}.{'Range_Turnover_Start':'1001','Range_Turnover_END':'5000','GAME1':'0.5%','GAME2':'0.5%'....,'order':1}….]
    */
    private String percentageDetails;

    private int agentCount=0;

    @ApiModelProperty(value = "结算比例")
    @NotEmpty(message = "settlementPercentage is not blank",groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class})
    private List<SettlementPercentageReq> settlementPercentageList;

    @ApiModelProperty(value = "结算比例")
    private  List<TAgentContractListReq> agentContractListReqList ;

    /*
        创建人
   */
    @ApiModelProperty(value = "创建人")
    @NotBlank(message = "createBy is not blank",groups = InputValidationGroup.Insert.class)
    private String createBy;

    /*
        修改人
    */
    @ApiModelProperty(value = "编辑者")
    @NotBlank(message = "updateBy is not blank",groups = InputValidationGroup.Update.class)
    private String updateBy;


    @ApiModelProperty(value = "isFd")
    @NotBlank(message = "isFd is not blank",groups = InputValidationGroup.Update.class)
    private String   isFd ;

    @ApiModelProperty(value = "fdCount")
    private int fdCount ;

    @ApiModelProperty(value = "fdCommission")
     private BigDecimal fdCommission;


    @ApiModelProperty(value = "结算比例")
    private BigDecimal activeUserCommission;

    /*
    处理佣金方案计算内容
    * */
    public void refresh() {
        try {

            this.setPercentageDetails(SerializationUti.serializeToString(settlementPercentageList));

        }catch (Exception e){
            throw new BusinessException("percentage refresh Exception");
        }

    }


    @Override
    public String toString() {
        return "CommissionPlanDTO{" +
                "id=" + id +
                ", commissionPlanName='" + commissionPlanName + '\'' +
                ", commissionPlanType='" + commissionPlanType + '\'' +
                ", settlementPeriod='" + settlementPeriod + '\'' +
                ", settlementConditions=" + settlementConditions +
                ", activeUserTurnover=" + activeUserTurnover +
                ", activeUserHeadcount=" + activeUserHeadcount +
                ", commissionValues='" + commissionValues + '\'' +
                ", percentageDetails='" + percentageDetails + '\'' +
                ", agentCount=" + agentCount +
                ", settlementPercentageList=" + settlementPercentageList +
                ", agentContractListReqList=" + agentContractListReqList +

                '}';
    }


    public Float polymerization(SettlementPercentageReq settlementPercentageReq,CommissionValuesEnum commissionValuesEnum) throws InvocationTargetException, IllegalAccessException, NoSuchMethodException {
        Float together = 0f;
        Field[] fileds=settlementPercentageReq.getClass().getDeclaredFields();
        for (int i = 0; i < fileds.length; i++) {
            Field field=fileds[i];
            GameTypeColumn column = field.getAnnotation(GameTypeColumn.class);
            if(!Objects.isNull(column)){
                if(commissionValuesEnum.getCode().equals(column.value().getCode())){
                    Float obj = (Float) PropertyUtils.getProperty(settlementPercentageReq, field.getName());
                    together = together + obj;
                }
            }
        }
        return together;
    }


}
