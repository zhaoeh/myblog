package com.mkt.agent.common.dto;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class AgentChainDTO {

    // 本身代理级别
    private Integer levelSelf;


    // 本身代理账号
    private String SelfAgentAccount;

    // 顶级代理账号
    private String level1AgentAccount;

    // 顶级代理账号
    private String parentAgentAccount;

    // 列代理链
    private List<AgentChainDTO> agentChainDTOColumnList = new ArrayList<>();

    // 行代理链
    private List<AgentChainDTO> agentChainDTORowList = new ArrayList<>();

    // 下级行代理链
    private List<AgentChainDTO> agentChainDTONextRowList = new ArrayList<>();

}
