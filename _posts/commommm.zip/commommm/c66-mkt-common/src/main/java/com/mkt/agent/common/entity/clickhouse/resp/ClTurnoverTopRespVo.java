package com.mkt.agent.common.entity.clickhouse.resp;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * @Description TODO
 * @Classname ClTurnoverTopRespVo
 * @Date 2024/1/4 11:00
 * @Created by TJSLucian
 */
@Data
public class ClTurnoverTopRespVo {

    // 用户名
    @ApiModelProperty(value = "agentAccount", example = "mptest388")
    private String agentAccount;
    // 投注额总计
    @ApiModelProperty(value = "turnoverTopRespList", example = "20000")
    private List<ClTurnoverTopResp> turnoverTopRespList = new ArrayList<>();

}
