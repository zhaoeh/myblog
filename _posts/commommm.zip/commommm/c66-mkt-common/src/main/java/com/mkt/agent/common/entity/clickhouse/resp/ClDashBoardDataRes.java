package com.mkt.agent.common.entity.clickhouse.resp;

import lombok.Data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @Description 连接clickhouse，查询物化视图获取dashBoard所需数据的实体类
 * @Classname ClDashBoardDataRes
 * @Date 2023/12/5 17:29
 * @Created by TJSLucian
 */
@Data
public class ClDashBoardDataRes {

    //数据产生日期
    private String agentDate;

    //代理的用户名
    private String loginName;

    //包含以前的gameType，同时增加 88221 deposit 存款  88222 withdraw 取款  88223 first_deposit 首存
    private Integer gameType;

    private BigDecimal ggr = BigDecimal.ZERO.setScale(2);

    private BigDecimal turnover = BigDecimal.ZERO.setScale(2);

    private BigDecimal winOrLoss = BigDecimal.ZERO.setScale(2);

    //当gameType是 88221，88222，88223时的金额
    private BigDecimal amount = BigDecimal.ZERO.setScale(2);//弃用    Stanko

    private Long firstDeposit    = 0L ;   //首充人数
    private BigDecimal firstDepositAmount = BigDecimal.ZERO.setScale(2); //首充金额

    private BigDecimal depositAmount = BigDecimal.ZERO.setScale(2);   // 充值金额
    private BigDecimal withdrawalAmount = BigDecimal.ZERO.setScale(2);  //  提现金额

    private List<Map<String,Object>>  teamReportHistoryType =  new ArrayList<>() ;

    private  Integer betPlayers = 0;     // 有效投注人数

    private  BigDecimal turnover1 = BigDecimal.ZERO.setScale(2);

}
