
package com.mkt.agent.common.hook;

import com.mkt.agent.common.config.ReturnValueStrategyConfiguration;
import org.springframework.core.MethodParameter;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
import org.springframework.web.method.support.ModelAndViewContainer;

/**
 * @description: 自定义的方法Controller方法返回值处理器
 * @author: ErHu.Zhao
 * @create: 2024-01-05
 **/
public class CustomizedMethodReturnValueHandler implements HandlerMethodReturnValueHandler {
    private HandlerMethodReturnValueHandler handlerMethodReturnValueHandler;
    private ReturnValueStrategyConfiguration.ReturnValueStrategy strategy;

    public CustomizedMethodReturnValueHandler(HandlerMethodReturnValueHandler handlerMethodReturnValueHandler, ReturnValueStrategyConfiguration.ReturnValueStrategy strategy) {
        this.handlerMethodReturnValueHandler = handlerMethodReturnValueHandler;
        this.strategy = strategy;
    }

    @Override
    public boolean supportsReturnType(MethodParameter returnType) {
        return this.handlerMethodReturnValueHandler.supportsReturnType(returnType);
    }

    @Override
    public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest) throws Exception {
        this.handlerMethodReturnValueHandler.handleReturnValue(this.strategy.wrapperReturnValue(returnValue), returnType, mavContainer, webRequest);
    }
}
