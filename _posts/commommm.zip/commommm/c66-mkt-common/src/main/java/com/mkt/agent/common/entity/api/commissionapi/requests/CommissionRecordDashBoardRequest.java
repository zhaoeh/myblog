package com.mkt.agent.common.entity.api.commissionapi.requests;

import com.mkt.agent.common.entity.api.commissionapi.requests.base.CommissionRecordBaseRequest;
import com.mkt.agent.common.enums.CustomizedValidationContents;
import com.mkt.agent.common.valid.EnumValid;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

/**
 * @Description TODO
 * @Classname CommissionRecordDashBoardRequest
 * @Date 2023/10/23 14:54
 * @Created by TJSLucian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CommissionRecordDashBoardRequest {

    @ApiModelProperty(value = "当前登录用户名", hidden = true, example = "Lucian")
    private String loginName;

    @ApiModelProperty(value = "选择时间的类型，Month, Week, Day", example = "Month")
    @EnumValid(contents = CustomizedValidationContents.team_summary_type)
    @NotNull
    private String chosenType;

    @ApiModelProperty(value = "选择时间的区间，当前月/周/天：current，上个月/周/天：last，上上个月/周/天：last_two", example = "current")
    @EnumValid(contents = CustomizedValidationContents.team_summary_period)
    @NotNull
    private String chosenPeriod;

    @ApiModelProperty(value = "选择时间起始日",hidden = true, example = "2023-10-26")
    private String recordDateStart;

    @ApiModelProperty(value = "选择时间结束日",hidden = true, example = "2023-10-27")
    private String recordDateEnd;

    @ApiModelProperty(value = "选择时间起始日",hidden = true, example = "2023-10-26 00:00:00")
    private String recordDateTimeStart;

    @ApiModelProperty(value = "选择时间结束日",hidden = true, example = "2023-10-27 23:59:59")
    private String recordDateTimeEnd;


    @ApiModelProperty(value = "上一个区间选择时间起始日",hidden = true, example = "2023-10-26")
    private String recordDateStartLast;

    @ApiModelProperty(value = "上一个区间选择时间结束日",hidden = true, example = "2023-10-27")
    private String recordDateEndLast;

    @ApiModelProperty(value = "上一个区间选择时间起始日",hidden = true, example = "2023-10-26 00:00:00")
    private String recordDateTimeStartLast;

    @ApiModelProperty(value = "上一个区间选择时间结束日",hidden = true, example = "2023-10-27 23:59:59")
    private String recordDateTimeEndLast;



    @ApiModelProperty(value = "上两个区间选择时间起始日",hidden = true, example = "2023-10-26")
    private String recordDateStartLastTwo;

    @ApiModelProperty(value = "上两个区间选择时间结束日",hidden = true, example = "2023-10-27")
    private String recordDateEndLastTwo;

    @ApiModelProperty(value = "上两个区间选择时间起始日",hidden = true, example = "2023-10-26 00:00:00")
    private String recordDateTimeStartLastTwo;

    @ApiModelProperty(value = "上两个区间选择时间结束日",hidden = true, example = "2023-10-27 23:59:59")
    private String recordDateTimeEndLastTwo;


}
