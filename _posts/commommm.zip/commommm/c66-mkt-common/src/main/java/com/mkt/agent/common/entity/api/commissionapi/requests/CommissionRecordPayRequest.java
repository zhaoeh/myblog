package com.mkt.agent.common.entity.api.commissionapi.requests;


import com.mkt.agent.common.entity.api.commissionapi.requests.base.CommissionRecordBaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(value = "CommissionRecordListRequest", description = "Commission Record Query Request")
public class CommissionRecordPayRequest extends CommissionRecordBaseRequest implements Serializable {


    private static final long serialVersionUID = 1l;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount")
    private String agentAccount;

    // 代理上级代理账号：父级代理的账号
    @ApiModelProperty(value = "parentAccount")
    private String parentAccount;


    @ApiModelProperty(value = "agentLevel", example = "1")
    private Integer agentLevel;

    // 佣金记录状态：0:清算中pending,1:同意agreed,2:拒绝rejected
    @ApiModelProperty(value = "CommissionRecordStatusEnum")
    private Integer status;

    // 佣金计算开始日期
    @ApiModelProperty(value = "settleDateStart", example = "2023-05-01")
    private String settleDateStart;

    // 佣金计算结束日期
    @ApiModelProperty(value = "createTimeEnd", example = "2023-05-31")
    private String settleDateEnd;

}


