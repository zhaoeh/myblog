package com.mkt.agent.common.entity.api.agentapi.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.Map;

/**
 * @ClassName GlobalConfigReq---
 * @Description 全局配置入参
 * @Author TJSAlex
 * @Date 2023/5/22 16:28
 * @Version 1.0
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ConfigDto implements Serializable {
    @ApiModelProperty(value = "paramName")
    @NotBlank(message = "paramName is required!")
    private String paramName;
    @ApiModelProperty(value = "paramValue")
    @NotBlank(message = "paramValue is required!")
    private String paramValue;

    private Map<String,String> siteMap;
}
