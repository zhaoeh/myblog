package com.mkt.agent.common.entity.api.commissionapi.responses.base;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Data
public class CommissionRecordPageResponse<T> extends Page<T> {

    @ApiModelProperty(value = "pageSumMap", example = "")
    private Map<String, BigDecimal> pageSumMap = new HashMap<>();

    @ApiModelProperty(value = "searchSumMap", example = "")
    private Map<String, BigDecimal> searchSumMap = new HashMap<>();

    @ApiModelProperty(value = "data changes please reset pageSearch", example = "true")
    private Boolean isNeedReset = false;

}
