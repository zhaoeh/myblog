package com.mkt.agent.common.entity.clickhouse.resp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * @Description TODO11
 * @Classname CommissionRespVo
 * @Date 2024/1/4 16:46
 * @Created by TJSLucian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DashBoardCommissionVo {

    private String agentAccount;

    private BigDecimal commission;

    private String recordDateStart;

    private String recordDateEnd;

}
