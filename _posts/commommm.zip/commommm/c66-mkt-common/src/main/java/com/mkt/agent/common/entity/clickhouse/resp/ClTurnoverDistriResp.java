package com.mkt.agent.common.entity.clickhouse.resp;


import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.mkt.agent.common.enums.GameTypeEnum;
import com.mkt.agent.common.jackson.serializer.BigDecimalSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
@ApiModel(value = "投注额占比饼状图--")
public class ClTurnoverDistriResp {

    // 游戏类型
    @ApiModelProperty(value = "game_type", example = "27")
    private Integer gameType;
    // 游戏名称
    @ApiModelProperty(value = "gameName", example = "bingoPercentage")
    private String gameName;
    // 投注额总计
    @ApiModelProperty(value = "turnoverSum", example = "20000")
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal turnoverSum;

    // 获取各个游戏类型的游戏名称
    public String getGameName() {
        return GameTypeEnum.getNameByCode(gameType);
    }
}


