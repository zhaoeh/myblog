package com.mkt.agent.common.fast.listener;

import com.alibaba.nacos.common.utils.CollectionUtils;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.fast.core.FastConfig;
import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import com.mkt.agent.common.fast.event.UpdateAgentEvent;
import com.mkt.agent.common.fast.remediation.DesensMappingOfAgentRemediation;
import com.mkt.agent.common.fast.remediation.TransferOfAgentRemediation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

/**
 * @description: 新增代理事件监听器
 * @author: ErHu.Zhao
 * @create: 2024-04-02
 **/
@Component
@Slf4j
public class UpdateAgentListener implements ApplicationListener<UpdateAgentEvent> {

    private static ExecutorService executorService = Executors.newSingleThreadExecutor();

    private final TransferOfAgentRemediation transferOfAgentRemediation;
    private final DesensMappingOfAgentRemediation desensMappingOfAgentRemediation;
    private final FastConfig fastConfig;

    public UpdateAgentListener(TransferOfAgentRemediation transferOfAgentRemediation,
                               DesensMappingOfAgentRemediation desensMappingOfAgentRemediation,
                               FastConfig fastConfig) {
        this.transferOfAgentRemediation = transferOfAgentRemediation;
        this.desensMappingOfAgentRemediation = desensMappingOfAgentRemediation;
        this.fastConfig = fastConfig;
    }

    @Override
    public void onApplicationEvent(UpdateAgentEvent event) {
        if (BooleanUtils.isFalse(fastConfig.getFastSwitch())) {
            log.info("fast switch is close,stop do it");
            return;
        }
        List<TAgentCustomers> agents = event.getAgents();
        FastContext fastContext = event.getFastContext();
        SqlSessionFactory factory = event.getFactory();
        if (CollectionUtils.isEmpty(agents)) {
            return;
        }
        if (Objects.nonNull(executorService)) {
            executorService.submit(() -> triggerOnUpdateAgent(fastContext, factory, agents));
        } else {
            triggerOnUpdateAgent(fastContext, factory, agents);
        }
    }

    private void triggerOnUpdateAgent(FastContext fastContext, SqlSessionFactory factory, List<TAgentCustomers> agents) {
        try {
            log.info("begin triggerOnUpdateAgent");
            desensMappingOfAgentRemediation.doDesensMappingOfAgentRemediation(fastContext,
                    StrategyEnums.ListenerDesensMappingStrategy, agents.stream().map(TAgentCustomers::getLoginName).collect(Collectors.toList()));
            transferOfAgentRemediation.doTransferOfAgentRemediation(fastContext, StrategyEnums.ListenerTransferOfAgentStrategy, factory, agents, null);
            log.info("end triggerOnUpdateAgent");
        } catch (Exception e) {
            log.error("triggerOnUpdateAgent error.", e);
        }
    }

}
