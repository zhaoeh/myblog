package com.mkt.agent.common.entity.api.agentapi;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.BaseOperationEntity;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;

/**
 * @ClassName TAgentCustomers
 * @Description 代理客户
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@EqualsAndHashCode(callSuper = true)
@TableName("t_agent_customers")
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@SuperBuilder
public class TAgentCustomers extends BaseOperationEntity {

    /*
        客户id
    */
    @Column(name="CUSTOMERS_ID",nullable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long customersId;

    /*
        登录名
    */
    @Column(name="LOGIN_NAME",nullable = false)
    private String loginName;

    /*
        产品
   */
    @Column(name="PRODUCT_ID",nullable = false)
    private String productId;

    /*
        佣金方案code
    */
    @Column(name="COMMISSION_CONTRACT_BIND_ID",nullable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long commissionContractBindId;

    /*
        父级代理
   */
    @Column(name="PARENT_ID",nullable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long parentId;

    /*
         创建人
    */
    @Column(name="PARENT_NAME",nullable = false)
    private String parentName;

    /*
        代理类型 0:普通 1:专业代理
    */
    @Column(name="AGENT_TYPE")
    private Integer agentType;

    /*
        代理级别
    */
    @Column(name="AGENT_LEVEL",nullable = false)
    private Integer agentLevel = 1;

    /*
        代理可以发展最大下级代理层数
    */
    @Column(name="DEVELOPABLE_LEVEL",nullable = false)
    private Integer developableLevel;

    /*
        是否启用标识 0禁用，1启用
    */
    @Column(name="is_enable",nullable = false)
    private Integer isEnable;

    /*
        备注
    */
    @Column(name="remarks")
    private String remarks;

    /*
        siteId 1:Bingoplus  2:Arenaplus  3:Gameplus
    */
    @Column(name="site_id")
    private Integer siteId;

    /**
     * 门店编号
     */
    @Column(name="branch_code")
    private String branchCode;

    public Long getCustomersId() {
        return customersId;
    }

    public void setCustomersId(Long customersId) {
        this.customersId = customersId;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public Long getCommissionContractBindId() {
        return commissionContractBindId;
    }

    public void setCommissionContractBindId(Long commissionContractBindId) {
        this.commissionContractBindId = commissionContractBindId;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public Integer getAgentType() {
        return agentType;
    }

    public void setAgentType(Integer agentType) {
        this.agentType = agentType;
    }

    public Integer getAgentLevel() {
        return agentLevel;
    }

    public void setAgentLevel(Integer agentLevel) {
        this.agentLevel = agentLevel;
    }

    public Integer getDevelopableLevel() {
        return developableLevel;
    }

    public void setDevelopableLevel(Integer developableLevel) {
        this.developableLevel = developableLevel;
    }

    public Integer getIsEnable() {
        return isEnable;
    }

    public void setIsEnable(Integer isEnable) {
        this.isEnable = isEnable;
    }

    @Override
    public Integer getIsDeleted() {
        return isDeleted;
    }

    @Override
    public void setIsDeleted(Integer isDeleted) {
        this.isDeleted = isDeleted;
    }

    @Override
    public String getRemarks() {
        return remarks;
    }

    @Override
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Integer getSiteId() {
        return siteId;
    }

    public void setSiteId(Integer siteId) {
        this.siteId = siteId;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }

    @Override
    public String toString() {
        return "TAgentCustomers{" +
                "id=" + getId() +
                ", createTime=" + createTime +
                ", updateTime=" + updateTime +
                ", createBy='" + createBy + '\'' +
                ", updateBy='" + updateBy + '\'' +
                ", isDeleted=" + isDeleted +
                ", customersId=" + customersId +
                ", loginName='" + loginName + '\'' +
                ", productId='" + productId + '\'' +
                ", commissionContractBindId=" + commissionContractBindId +
                ", parentId=" + parentId +
                ", parentName='" + parentName + '\'' +
                ", agentType=" + agentType +
                ", agentLevel=" + agentLevel +
                ", developableLevel=" + developableLevel +
                ", isEnable=" + isEnable +
                ", remarks='" + remarks + '\'' +
                ", siteId=" + siteId +
                ", branchCode='" + branchCode + '\'' +
                '}';
    }
}
