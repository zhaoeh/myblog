package com.mkt.agent.common.player.core;

import com.google.common.collect.Lists;
import com.mkt.agent.common.config.PlayerReportConfig;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonth;
import com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonthVo1;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.player.model.PlayerReportByMonthProcessorModel;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * @Description TODO
 * @Classname PlayerReportByMonthPersist
 * @Date 2024/3/14 11:22
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class PlayerReportByMonthPersist {

    @Value("${playerReport.batchSizeByMonth:1000}")
    private Integer batchQuerySize;

    public List<TAgentCountGroupMonth> queryDirectCountFromCH(ClDashBoardCreateQueryReq queryReq, Function<ClDashBoardCreateQueryReq,List<TAgentCountGroupMonth>> queryDirectCountByMonthMapper){

        log.info("Begin to query dashBoard data");

        List<TAgentCountGroupMonth> response = null;

        if (queryReq.getAgentAccountList().size() <= batchQuerySize) {
            response = queryDirectCountByMonthMapper.apply(queryReq);
        } else {

            List<List<String>> batches = Lists.partition(queryReq.getAgentAccountList(), batchQuerySize);

            Set<ClDashBoardCreateQueryReq> batchQuerys = batches.stream().map(b -> ClDashBoardCreateQueryReq.builder()
                    .agentAccountList(b).recordDateStart(queryReq.getRecordDateStart()).recordDateEnd(queryReq.getRecordDateEnd())
                    .agentMonth(queryReq.getAgentMonth()).build()).collect(Collectors.toSet());

            response = batchQuerys.stream().map(q -> queryDirectCountByMonthMapper.apply(q))
                    .reduce((r1,r2) -> Stream.concat(r1.stream(),r2.stream()).collect(Collectors.toList())).orElse(null);
        }

        if(!CollectionUtils.isEmpty(response)){
            response.forEach(r -> r.setTotalCount(r.getDirectCount()));
        }
        return response;
    }

    public List<TAgentCountGroupMonth> querySelfCountFromCH(ClDashBoardCreateQueryReq queryReq, Function<ClDashBoardCreateQueryReq,List<TAgentCountGroupMonth>> querySelfCountByMonthMapper){

        List<TAgentCountGroupMonth> response = null;

        if (queryReq.getAgentAccountList().size() <= batchQuerySize) {
            response = querySelfCountByMonthMapper.apply(queryReq);
        } else {

            List<List<String>> batches = Lists.partition(queryReq.getAgentAccountList(), batchQuerySize);

            Set<ClDashBoardCreateQueryReq> batchQuerys = batches.stream().map(b -> ClDashBoardCreateQueryReq.builder()
                    .agentAccountList(b).recordDateStart(queryReq.getRecordDateStart()).recordDateEnd(queryReq.getRecordDateEnd())
                    .agentMonth(queryReq.getAgentMonth()).build()).collect(Collectors.toSet());

            response = batchQuerys.stream().map(q -> querySelfCountByMonthMapper.apply(q))
                    .reduce((r1,r2) -> Stream.concat(r1.stream(),r2.stream()).collect(Collectors.toList())).orElse(null);
        }

        return response;
    }


    @Transactional(rollbackFor = Exception.class)
    public int refreshAgentGroupCountByMonth(PlayerReportByMonthProcessorModel model,List<String> deletedTarget,List<TAgentCountGroupMonth> insertTarget) {
        if (Objects.isNull(model) || StringUtils.isBlank(model.getOperatorType())){
            return 0;
        }
        log.info("[refreshAgentGroupCountByMonth]Begin to refresh player report month Data for level:{}",model.getLevel());
        deleteAgentGroupCountByMonth(model,deletedTarget);
        return insertBatchAgentGroupCountByMonth(model,insertTarget);
    }

    private int deleteAgentGroupCountByMonth(PlayerReportByMonthProcessorModel model,List<String> deletedTarget) {
        if (Objects.isNull(model)) {
            return 0;
        }

        if(model.getOperatorType().equals(Constants.FROM_JOB)){
            log.info("[deleteAgentGroupCountByMonth]Begin to delete Data for month:{} for level:{}",model.getMonth(),model.getLevel());
            return model.getHolder().getDeleteByLevelNMonth().apply(model.getLevel(), model.getMonth());
        }else if(model.getOperatorType().equals(Constants.FROM_ASYNC)){
            if(CollectionUtils.isEmpty(deletedTarget)){
                return 0;
            }
            log.info("[deleteAgentGroupCountByMonth]Begin to delete Data by async!");
            return model.getHolder().getDeleteByNamesNMonth().apply(deletedTarget, model.getMonth());
        }

        return 0;

    }

    private int insertBatchAgentGroupCountByMonth(PlayerReportByMonthProcessorModel model, List<TAgentCountGroupMonth> insertTarget) {
        if (Objects.isNull(model) || CollectionUtils.isEmpty(insertTarget)) {
            return 0;
        }
        log.info("[insertBatchAgentGroupCountByMonth]Begin to insert data for month:{} for level:{}",model.getMonth(),model.getLevel());
        log.info("[insertBatchAgentGroupCountByMonth]The insert Data is:{}",Arrays.toString(insertTarget.toArray()));
        return model.getHolder().getGroupInsertMapper().apply(insertTarget);
    }

}
