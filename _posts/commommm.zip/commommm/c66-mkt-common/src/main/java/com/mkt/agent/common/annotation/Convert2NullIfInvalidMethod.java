package com.mkt.agent.common.annotation;

import java.lang.annotation.*;

/**
 * @Description 如果是null或空字符串，或自定义字符串，或不满足自定义规则，则设置为null
 * @Classname ConvertToNullIfEmpty
 * @Date 2024/2/14 16:20
 * @Created by TJSLucian
 */
@Documented
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Convert2NullIfInvalidMethod {
}
