package com.mkt.agent.common.constants;

/**
 * @ClassName AgentConstant
 * @Author TJSAlex
 * @Date 2023/5/23 17:12
 * @Version 1.0
 **/
public class DefaultAgentConstant {

    public static final long DEFAULT_AGENT_ID = -1;
    public static final String DEFAULT_LOGIN_NAME = "System";
}
