package com.mkt.agent.common.utils;

import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.Response;
import com.mkt.agent.common.enums.ComprehensiveBranchEnum;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.formula.functions.T;

import java.lang.reflect.Field;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CommonUtil {

    private static final Pattern HUMP_PATTERN = Pattern.compile("[A-Z]");

    /**
     * 将驼峰命名转换为数据库下划线格式
     * @param camelCase 驼峰命名的字符串
     * @return 转换为数据库下划线格式的字符串
     */
    public static String toUnderlineCase(String camelCase) {
        Matcher matcher = HUMP_PATTERN.matcher(camelCase);
        StringBuilder builder = new StringBuilder(camelCase);
        int offset = 0;
        while (matcher.find()) {
            builder.replace(matcher.start() + offset, matcher.end() + offset, "_" + matcher.group().toLowerCase());
            offset++;
        }
        if (builder.charAt(0) == '_') {
            builder.deleteCharAt(0);
        }
        return builder.toString();
    }

    /**
     * 将数据库下划线格式转换为驼峰命名
     * @param underlineCase 数据库下划线格式的字符串
     * @return 转换为驼峰命名的字符串
     */
    public static String toCamelCase(String underlineCase) {
        StringBuilder builder = new StringBuilder();
        String[] words = underlineCase.toLowerCase().split("_");
        for (String word : words) {
            builder.append(word.substring(0, 1).toUpperCase()).append(word.substring(1));
        }
        return builder.toString();
    }

    public static String genRequestUUID() {
        return UUID.randomUUID().toString().replace("-", "").toLowerCase();
    }

    /**
     * description: 获取成功的返回结果 0000:成功
     * @param:  [data]
     * @return: com.mkt.agent.common.entity.Response<org.apache.poi.ss.formula.functions.T>
     * @Date: 2023/6/27 17:42
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public static Response<T> getSucessRes(T data){
        Response<T> res = new Response<>();
        res.getHead().setErrCode(BaseConstants.SUCCESS);
        res.getHead().setErrMsg(BaseConstants.SUCCESS_STR);
        res.setBody(data);
        return res;
    }

    /**
     * description: 获取失败的返回结果 errCode可定义 默认 1111
     * @param:  [errCode, errMessage, data]
     * @return: com.mkt.agent.common.entity.Response<org.apache.poi.ss.formula.functions.T>
     * @Date: 2023/6/27 17:43
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public static Response<T> getFailureRes(String errCode,String errMessage, T data){
        Response<T> res = new Response<>();
        res.getHead().setErrCode(StringUtils.isNotBlank(errCode)?errCode:BaseConstants.FAILURE);
        res.getHead().setErrMsg(errMessage);
        res.setBody(data);
        return res;
    }

    public static <T> boolean fieldInClass(String fieldName,Class<T> clazz){
        Field[] fields=clazz.getDeclaredFields();
        for(Field field:fields){
            if(field.getName().equals(fieldName)){
                return true;
            }
        }
        return false;
    }

    public static boolean isNullOrEmptyList(List<?> list) {
        return list == null || list.isEmpty();
    }

    /**
     * 去除日期的-后转数字
     *
     * @param param 日期字符串
     * @return 纯数字
     */
    public static int convertToInt(String param) {
        return Integer.valueOf(StringUtils.remove(param, "-"));
    }

    /**
     * 随机返回一个综合门店
     *
     * @return
     */
    public static ComprehensiveBranchEnum randomComprehensiveBranchEnum() {
        ComprehensiveBranchEnum[] values = ComprehensiveBranchEnum.values();
        return values[ThreadLocalRandom.current().nextInt(values.length)];
    }

    /**
     * 对json格式字符串中的关键字段值进行脱敏
     *
     * @param source
     * @param sensitive
     * @return
     */
    public static String desensitiveTargetStr(String source, String sensitive) {
        if (StringUtils.isBlank(source) || StringUtils.isBlank(sensitive)) {
            return source;
        }
        if (sensitive.length() > source.length()) {
            return source;
        }
        int start = source.indexOf("\"" + sensitive + "\"");
        if (start <= 0) {
            return source;
        }
        int startIndex = source.indexOf("\"", start + sensitive.length() + 3) + 1;
        if(startIndex <= 0){
            return source;
        }
        int endIndex = source.indexOf(",", startIndex) - 1;
        if (endIndex <= 0) {
            endIndex = source.indexOf("}", startIndex) - 1;
        }
        if (source.length() < startIndex) {
            return source;
        }
        String targetValue;
        if (endIndex <= 0) {
            targetValue = source.substring(startIndex);
        } else {
            targetValue = source.substring(startIndex, endIndex);
        }
        return source.replace(targetValue, "***");
    }

    /**
     * 对json格式字符串中的关键字段值进行脱敏(json格式字符串包含转义字符)
     *
     * @param source
     * @param sensitive
     * @return
     */
    public static String desensitiveTarget(String source, String sensitive) {
        if (StringUtils.isBlank(source) || StringUtils.isBlank(sensitive)) {
            return source;
        }
        if (sensitive.length() > source.length()) {
            return source;
        }
        int start = source.indexOf("\\\"" + sensitive + "\\\"");
        if (start <= 0) {
            return source;
        }
        int startIndex = source.indexOf("\\\"", start + sensitive.length() + 5) + 2;
        if (startIndex <= 0) {
            return source;
        }
        int endIndex = source.indexOf(",", startIndex) - 2;
        if (endIndex <= 0) {
            endIndex = source.indexOf("}", startIndex) - 2;
        }
        if (source.length() < startIndex) {
            return source;
        }
        String targetValue;
        if (endIndex <= 0) {
            targetValue = source.substring(startIndex);
        } else {
            targetValue = source.substring(startIndex, endIndex);
        }
        return source.replace(targetValue, "***");
    }

}
