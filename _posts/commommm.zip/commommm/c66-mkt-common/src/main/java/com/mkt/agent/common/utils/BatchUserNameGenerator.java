package com.mkt.agent.common.utils;

import com.mkt.agent.common.constants.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.Objects;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.Executors;

/**
 * @Description 批量创建用户/代理生成用户名
 * @Classname BatchUserNameGenerator
 * @Date 2023/10/23 10:45
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class BatchUserNameGenerator {

    @Resource
    private RedisUtil redisUtil;

    private static final String ALLOWED_CHARACTERS = "abcdefghjkmnpqrstuvwxyz23456789"; // 允许的字符

    private static final int MAX_LENGTH = 8;

    //生成指定长度的字符串
    private String generateRandomAccount(int length, String prefix) {
        StringBuilder account = new StringBuilder();
        Random random = new SecureRandom(); // 使用安全随机数生成器

        for (int i = 0; i < length; i++) {
            int randomIndex = random.nextInt(ALLOWED_CHARACTERS.length());
            char randomChar = ALLOWED_CHARACTERS.charAt(randomIndex);
            account.append(randomChar);
        }

        return prefix+account.toString();
    }


    //判断用户名是否重复   判断期间产生的用户名不做校验直接插入数据库，插入失败统计到失败数量里
    private String getUsableAccount(String prefix){

        Integer length = Integer.parseInt(redisUtil.get(Constants.CURRENT_LENGTH).toString());

        Integer maxTryTimes = Integer.parseInt(redisUtil.get(Constants.MAX_TRY_TIMES).toString());

        log.info("Length is :{}, maxTryTimes is :{}",length,maxTryTimes);

        String account = "";

        for(int startL = length; startL <= MAX_LENGTH; startL++){

            int attempts = 0;

            boolean flag = false;

            while (true && attempts <= maxTryTimes){

                //生成账号
                account = generateRandomAccount(length,prefix);

                log.info("The account is :{}, The attempts is :{}", account,attempts);

                if(!redisUtil.exists(Constants.UNIQUE_NAME_PREFIX + account)){
                    log.info("The account is usable:{}",account);
                    flag = true;
                    break;
                }

                attempts++;

            }

            if(flag){
                log.info("The usable name is :{}",account);
                redisUtil.set(Constants.CURRENT_LENGTH,startL+"");
                break;
            }

        }
        return account;

    }



    /**
     * description: 根据bp/ap客户端生成账号
     * @param:  [siteId, accountLength]
     * @return: java.lang.String
     * @Date: 2023/10/23 10:54
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public String getAccount(int siteId){

        log.info("begin to make new account");
        String prefix = "bp";
        if(siteId==2){
            prefix = "ap";
        } else if (siteId == 3){
            prefix = "gp";
        }
        String randomAccount = getUsableAccount(prefix);
        log.info("BatchUserNameGenerator account: {}",randomAccount);
        return randomAccount;
    }

    // 获取密码
    public String getPwd(){
        return generateRandomAccount(MAX_LENGTH,"");
    }



}
