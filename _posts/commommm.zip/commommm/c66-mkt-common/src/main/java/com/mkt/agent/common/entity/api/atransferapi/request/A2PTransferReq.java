package com.mkt.agent.common.entity.api.atransferapi.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

@Data
public class A2PTransferReq implements Serializable {
    @ApiModelProperty(required = true,value = "fromId",example = "1022501954")
    @NotNull(message = "fromId is required!")
    private Long fromId;

    @ApiModelProperty(required = true,value = "fromAccount",example = "lucian0626")
    @NotNull(message = "fromAccount is required!")
    private String fromAccount;

    @ApiModelProperty(required = true,value = "toId",example = "1022501927")
    @NotNull(message = "toId is required!")
    private Long toId;

    @ApiModelProperty(required = true,value = "toAccount",example = "bingoplus38rqf1")
    @NotNull(message = "toAccount is required!")
    private String toAccount;

    @ApiModelProperty(required = true,value = "amount",example = "10.00")
    @NotNull(message = "amount is required!")
    @DecimalMin(value = "0.000000",message = "amount is required!")
    private BigDecimal amount;

    @ApiModelProperty(value = "currency",notes = "不传默认为PHP",example = "PHP")
    private String currency;

    @ApiModelProperty(required = true,value = "productId",example = "C66")
    @NotNull(message = "productId is required!")
    private String productId;

    @ApiModelProperty(required = true,value = "siteId 1:Bingoplus 2:Arenaplus 3:Gameplus",example = "1")
    @NotNull(message = "siteId is required!")
    private Integer siteId;

    @ApiModelProperty(required = true,value = "创建人", example = "Lucian")
    private String createBy;

    @ApiModelProperty(value = "备注", example = "123")
    private String remarks;

    @ApiModelProperty(value = "ipAddress",hidden = true)
    private String ipAddress;
}
