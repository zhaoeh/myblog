package com.mkt.agent.common.entity.api.agentapi.responses;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.entity.api.jobapi.requests.base.TaskBaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(description = "代理与佣金方案信息")
public class AgentCustomerQueryResponse extends TaskBaseRequest<AgentCustomerQueryResponse> {


    @ApiModelProperty(value = "customerId")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long customerId;

    @ApiModelProperty(value = "parentId")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long parentId;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount", example = "Amida001")
    private String agentAccount;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "parentAccount", example = "Amida001")
    private String parentAccount;
    // 客户类型1，玩家，3代理
    @ApiModelProperty(value = "customerType")
    private Integer customerType;

    // 代理类型：0：General Line (普通代理)，1：Professional Line(专业代理可发展下级)
    @ApiModelProperty(value = "agentType", example = "0:General line 1:Professional line")
    private Integer agentType;
    // 本身代理等级:数据来自于代理表，共五级：1，2，3，4，5
    @ApiModelProperty(value = "agentLevel", example = "the level of agent like 1,2,3,4,5")
    private Integer agentLevel;

    // 佣金方案名称
    @ApiModelProperty(value = "siteId")
    private Integer siteId;


}
