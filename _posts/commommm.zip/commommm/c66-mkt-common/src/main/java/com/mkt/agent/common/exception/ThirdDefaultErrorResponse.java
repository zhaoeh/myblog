package com.mkt.agent.common.exception;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @description: 三方系统默认的错误响应结构
 * @author: ErHu.Zhao
 * @create: 2023-12-22
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ThirdDefaultErrorResponse {
    private String timestamp;
    private Integer status;
    private String error;
    private String path;
}
