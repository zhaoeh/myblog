package com.mkt.agent.common.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;

/**
 * @ClassName SerializationUti
 * @Description 序列化list < - > String
 * @Author TJSAustin
 * @Date 2023/5/23 10:00
 * @Version 1.0
 **/
public class SerializationUti {
    // 将List<T>转换为JSON字符串
    public static <T> String serializeToString(List<T> objectList) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.writeValueAsString(objectList);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return null;
        }
    }

    // 将JSON字符串转换为List<T>
    public static <T> List<T> deserializeFromString(String jsonString, Class<T> valueType) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.readValue(jsonString, mapper.getTypeFactory().constructCollectionType(List.class, valueType));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return null;
        }
    }
}
