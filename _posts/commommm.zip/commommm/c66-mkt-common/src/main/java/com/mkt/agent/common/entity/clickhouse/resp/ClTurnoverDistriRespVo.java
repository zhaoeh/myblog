package com.mkt.agent.common.entity.clickhouse.resp;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description TODO
 * @Classname ClTurnoverDistriRespVo
 * @Date 2024/1/4 12:02
 * @Created by TJSLucian
 */
@Data
public class ClTurnoverDistriRespVo {

    // 用户名
    @ApiModelProperty(value = "agentAccount", example = "mptest388")
    private String agentAccount;

    private List<ClTurnoverDistriResp> clTurnoverDistriList = new ArrayList<>();

}
