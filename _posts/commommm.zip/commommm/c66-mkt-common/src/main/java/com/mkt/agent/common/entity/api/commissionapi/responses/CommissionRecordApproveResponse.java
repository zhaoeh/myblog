package com.mkt.agent.common.entity.api.commissionapi.responses;


import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.mkt.agent.common.annotation.ExcelColumn;
import com.mkt.agent.common.entity.api.commissionapi.responses.base.CommissionRecordBaseResponse;
import com.mkt.agent.common.jackson.serializer.BigDecimalSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@ApiModel(description = "佣金记录列表信息")
public class CommissionRecordApproveResponse extends CommissionRecordBaseResponse {


    // 佣金记录id：佣金记录唯一标识
    @ApiModelProperty(value = "commission record ID", example = "1,auto increment")
    @ExcelIgnore
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private Long id;
    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount", example = "Amida001")
    @ExcelColumn(value ="Account",order = 0)
    private String agentAccount;
    // 代理上级代理账号：父级代理的账号
    @ApiModelProperty(value = "parentAccount", example = "level1 agent's parent account is acc66")
    @ExcelColumn(value ="Parent",order = 1)
    private String parentAccount;
    // 佣金方案名称
    @ApiModelProperty(value = "commissionPlanName", example = "name of commission plan")
    @ExcelColumn(value ="Commission Plan Name",order = 2)
    private String commissionPlanName;

    // 佣金方案id:佣金方案唯一标识
    @ApiModelProperty(value = "commissionPlanId", example = "id of commission plan is used to figure the only one record")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private String commissionPlanId;
    // 实际结算周期
    @ApiModelProperty(value = "settleDateStart", example = "5.1")
    private String settleDateStart;
    @ApiModelProperty(value = "settleDateEnd", example = "5.10")
    private String settleDateEnd;

    @ExcelColumn(value ="Commission Period",order = 3)
    private String commissionPeriod;

    // 佣金金额：根据佣金方案以及投注金额或平台收益金额计算得出
    @ApiModelProperty(value = "commissionAmount", example = "1000")
    @ExcelColumn(value ="Commission",order = 4)
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal commissionAmount;
    // 实际佣金金额：由管理运营人员结算给订单代理或代理结算给下级代理
    @ApiModelProperty(value = "actualCommission", example = "900")
    @ExcelColumn(value ="Actual Commission",order = 5)
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal actualCommissionAmount;
    // 补发佣金:有上级代理根据实际情况补发给下级代理的佣金金额
    @ApiModelProperty(value = "appendCommissionAmount", example = "100")
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal appendCommissionAmount;
    // 佣金记录状态：0:清算中pending,1:同意agreed,2:拒绝rejected
    @ApiModelProperty(value = "actualSettlementPeriod",
            example = "0:initial status meaning pending," +
                    "1:FIRST_AGREED," +
                    "2:FIRST_REJECTED," +
                    "3:SECOND_AGREED," +
                    "4,SECOND_REJECTED," +
                    "5,RESET," +
                    "6,PAID," +
                    "7,UNPAID")
    private Integer status;

    @ExcelColumn(value ="Status",order = 6)
    private String statusStr;
    // 佣金方案类型：0：turnover,1:GGR
    @ApiModelProperty(value = "commissionType", example = "0:turnover,1:GGR")
    @ExcelColumn(value ="Commission Type",order = 7)
    private String commissionType;
    // 结算周期：ex:10 perday,7 perday,30 perday
    @ApiModelProperty(value = "settlementPeriod", example = "7:week,10:ONE_THIRD_MONTH,30:month")
    @ExcelColumn(value ="Settlement Period",order = 8)
    private String settlementPeriod;
    // 代理类型：0：General Line (普通代理)，1：Professional Line(专业代理可发展下级)
    @ApiModelProperty(value = "agentType", example = "0:General line 1:Professional line")
    private Integer agentType;

    @ExcelColumn(value ="Agent Type",order = 9)
    private String agentTypeStr;

    // 本身代理等级:数据来自于代理表，共五级：1，2，3，4，5
    @ApiModelProperty(value = "agentLevel", example = "the level of agent like 1,2,3,4,5")
    @ExcelColumn(value ="Agent Level",order = 10)
    private Integer agentLevel;
    // 佣金记录创建时间
    @ApiModelProperty(value = "createTime", example = "05/18/2023 08:30:45")
    @ExcelColumn(value ="Generate Time",order = 11)
    private String createTime;

    @ApiModelProperty(value = "firstApproveBy", example = "amida01")
    @ExcelColumn(value ="First Approve By",order = 12)
    private String firstApproveBy;
    // 第二阶段审核者账号

    @ApiModelProperty(value = "secondApproveBy", example = "amida02")
    @ExcelColumn(value ="Second Approve By",order = 13)
    private String secondApproveBy;


}
