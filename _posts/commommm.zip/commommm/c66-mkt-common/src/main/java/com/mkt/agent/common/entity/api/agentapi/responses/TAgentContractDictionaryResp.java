package com.mkt.agent.common.entity.api.agentapi.responses;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @ClassName CommissionPlanResp
 * @Description 佣金方案
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Data
public class TAgentContractDictionaryResp implements Serializable {

    @ApiModelProperty(value = "PLAN_ID")
    private String id;

    /*
        佣金方案类型
    */
    @ApiModelProperty(value = "COMMISSION_PLAN_NAME")
    private String commissionPlanName;

}
