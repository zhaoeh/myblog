package com.mkt.agent.common.aop;

import com.mkt.agent.common.annotation.Validate;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;
import com.mkt.agent.common.utils.ValidationUtils;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @Description: 参数校验aop
 * [javax.validation中的@Valid/@Validated会先于AOP的执行，导致会基于加密后的内容进行校验，进而使校验无效，如果需要解密后再校验则需要使用这个aop]
 * @Author: PTMinnisLi
 * @Date: 2023/6/23
 */
@Order(1)
@Aspect
@Component
@Slf4j
public class ValidationAop {

    @SneakyThrows
    @Before("@annotation(com.mkt.agent.common.annotation.Validate)")
    public void before(JoinPoint joinPoint) {
        // 获取校验分组
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Validate annotation = signature.getMethod().getAnnotation(Validate.class);
        Class<?>[] aClass = annotation.value();
        // 循环每个参数
        Object[] args = joinPoint.getArgs();
        for (int i = 0; i < args.length; i++) {
            Object requestObj = joinPoint.getArgs()[i];
            ValidationUtils.ValidationResult validationResult = ValidationUtils.validateEntity(requestObj, aClass);
            if (validationResult.isHasErrors()) {
                Map<String, String> errorMsg = validationResult.getErrorMsg();
                log.error("参数校验错误！原因是：{}", errorMsg);
                throw new BusinessException(errorMsg.values().toString(), ResultEnum.BAD_REQUEST.getCode());
            }
        }
    }

}
