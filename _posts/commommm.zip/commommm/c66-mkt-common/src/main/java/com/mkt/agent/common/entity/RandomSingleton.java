package com.mkt.agent.common.entity;

import org.springframework.stereotype.Component;

import java.util.Random;

/**
 * @Description TODO
 * @Classname RandomSingleton
 * @Date 2024/2/22 17:27
 * @Created by TJSLucian
 */
@Component
public class RandomSingleton {

    // 私有构造方法，防止外部实例化
    private RandomSingleton() {}

    // 静态内部类持有 Random 实例
    private static class RandomHolder {
        private static final Random INSTANCE = new Random();
    }

    // 公共静态方法，用于获取 Random 实例
    public static Random getInstance() {
        return RandomHolder.INSTANCE;
    }
}
