package com.mkt.agent.common.entity.api.reportapi.requests;


import com.mkt.agent.common.entity.api.reportapi.requests.base.ReportBaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(value = "TeamReportRequest")
public class TeamReportRequest extends ReportBaseRequest implements Serializable {


    private static final long serialVersionUID = 1l;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount", example = "ivan02")
    private String agentAccount;

    // 代理上级代理账号：父级代理的账号
    @ApiModelProperty(value = "parentAccount")
    private String parentAccount;

    // 本身代理等级:数据来自于代理表，共五级：1，2，3，4，5
    @ApiModelProperty(value = "agentLevel")
    private Integer agentLevel;

    @ApiModelProperty(value = "monthFlg", example = "1", required = true)
    private Integer monthFlg;

    private  String  chosenPeriod  ;

    private  String chosenType ;


}


