package com.mkt.agent.common.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @ClassName RabbitMQProperties
 * @Description RabbitMQ配置类
 * @Author TJSAustin
 * @Date 2023/06/07 10:00
 * @Version 1.0
 **/
@Component
@ConfigurationProperties(prefix="spring.rabbitmq")
@Data
public class RabbitMQProperties {

    private  String host;

    private int port;

    private  String userName;

    private  String password;

    private Integer batchSize;

    private String timeOut;

    private long checkOutTimeout;

    private int channelCacheSize;

}