package com.mkt.agent.common.fast.listener;

import com.alibaba.nacos.common.utils.CollectionUtils;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.fast.core.FastConfig;
import com.mkt.agent.common.fast.core.FastCore;
import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import com.mkt.agent.common.fast.event.UpdateParentEvent;
import com.mkt.agent.common.fast.remediation.DesensMappingOfAgentRemediation;
import com.mkt.agent.common.fast.remediation.TransferOfAgentRemediation;
import com.mkt.agent.common.fast.remediation.TransferOfUserRemediation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

/**
 * @description: 更改用户上级代理事件监听器
 * @author: ErHu.Zhao
 * @create: 2024-04-11
 **/
@Component
@Slf4j
public class UpdateParentListener implements ApplicationListener<UpdateParentEvent> {

    private static ExecutorService executorService = Executors.newSingleThreadExecutor();

    private final TransferOfUserRemediation transferOfUserRemediation;
    private final TransferOfAgentRemediation transferOfAgentRemediation;
    private final DesensMappingOfAgentRemediation desensMappingOfAgentRemediation;
    private final FastCore fastCore;
    private final FastConfig fastConfig;

    public UpdateParentListener(TransferOfUserRemediation transferOfUserRemediation,
                                TransferOfAgentRemediation transferOfAgentRemediation,
                                DesensMappingOfAgentRemediation desensMappingOfAgentRemediation,
                                FastCore fastCore,
                                FastConfig fastConfig) {
        this.transferOfUserRemediation = transferOfUserRemediation;
        this.transferOfAgentRemediation = transferOfAgentRemediation;
        this.desensMappingOfAgentRemediation = desensMappingOfAgentRemediation;
        this.fastCore = fastCore;
        this.fastConfig = fastConfig;
    }

    @Override
    public void onApplicationEvent(UpdateParentEvent event) {
        if (BooleanUtils.isFalse(fastConfig.getFastSwitch())) {
            log.info("fast switch is close,stop do it");
            return;
        }
        List<TAgentCustomers> agents = event.getAgents();
        List<TCustomerLayer> players = event.getPlayers();
        FastContext fastContext = event.getFastContext();
        SqlSessionFactory factory = event.getFactory();
        if (Objects.nonNull(executorService)) {
            executorService.submit(() -> triggerOnUpdateParent(fastContext, factory, agents, players));
        } else {
            triggerOnUpdateParent(fastContext, factory, agents, players);
        }
    }

    /**
     * 触发用户上级代理变更流程
     *
     * @param fastContext
     * @param factory
     * @param agents
     * @param players
     */
    private void triggerOnUpdateParent(FastContext fastContext, SqlSessionFactory factory, List<TAgentCustomers> agents, List<TCustomerLayer> players) {
        try {
            log.info("begin triggerOnUpdateParent");
            if (CollectionUtils.isNotEmpty(agents)) {
                desensMappingOfAgentRemediation.doDesensMappingOfAgentRemediation(fastContext, StrategyEnums.ListenerDesensMappingStrategy,
                        agents.stream().map(TAgentCustomers::getLoginName).collect(Collectors.toList()));
                transferOfAgentRemediation.doTransferOfAgentRemediation(fastContext, StrategyEnums.ListenerTransferOfAgentStrategy, factory, agents, fastCore::obtainSuperAgentChainsMap);
            }
            if (CollectionUtils.isEmpty(players)) {
                return;
            }

            players = fastContext.getQueryPlayersByNames().apply(players.stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList()));
            // 过滤不是代理的玩家
            players = players.stream().filter(item -> !item.getCustomerType().equals(BaseConstants.WS_AGENT)).collect(Collectors.toList());
            if (CollectionUtils.isEmpty(players)) {
                return;
            }
            List<TAgentCustomers> relationAgents = fastCore.obtainRelationAgentsFromUsers(players);
            List<String> relationAgentNames = null;
            if (CollectionUtils.isNotEmpty(relationAgents)) {
                relationAgentNames = relationAgents.stream().map(TAgentCustomers::getLoginName).collect(Collectors.toList());
            }
            boolean result = desensMappingOfAgentRemediation.doDesensMappingOfAgentRemediation(fastContext, StrategyEnums.ListenerDesensMappingStrategy, relationAgentNames);
            if (result) {
                transferOfUserRemediation.doTransferOfUserRemediation(fastContext, StrategyEnums.ListenerTransferOfUserStrategy, factory, relationAgents, players);
            }
            log.info("end triggerOnUpdateParent");
        } catch (Exception e) {
            log.error("triggerOnUpdateParent error.", e);
        }
    }
}
