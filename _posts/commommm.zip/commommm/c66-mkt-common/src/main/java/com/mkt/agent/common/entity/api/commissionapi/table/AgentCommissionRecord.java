package com.mkt.agent.common.entity.api.commissionapi.table;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;


//@Repository
@Data
@TableName("t_agent_commission_record")
public class AgentCommissionRecord {

    // 佣金记录id：佣金记录唯一标识
    @TableId
    private Long id;
    // agentId
    @TableField("customer_id")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long customerId;

    @TableField("parent_id")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long parentId;

    // 代理账户号：代理的唯一标识
    @TableField("agent_account")
    private String agentAccount;
    // 代理类型：0：General Line (普通代理)，1：Professional Line(专业代理可发展下级)
    @TableField("agent_type")
    private Integer agentType;
    // 代理上级代理账号：父级代理的账号
    @TableField("parent_account")
    private String parentAccount;
    // 产品名称：默认C66
//    @TableField("product_id")
//    private String productId;
    // 网站名称：1:Bingoplus  2:Arenaplus  3:Gameplus
    @TableField("site_id")
    private Integer siteId;

    @TableField("hash_code")
    private String hashCode;
    // 佣金方案名称
    @TableField("commission_plan_name")
    private String commissionPlanName;
    // 佣金方案id:佣金方案唯一标识
    @TableField("commission_plan_id")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long commissionPlanId;
    // 佣金方案类型：0：turnover,1:GGR
    @TableField("commission_type")
    private String commissionType;
    // 佣金费率：0.02
    @TableField("commission_value")
    private BigDecimal commissionValue;

    @TableField("percentage_details")
    private String percentageDetails;

    @TableField("settlement_conditions")
    private Integer settlementConditions;

    @TableField("active_user_turnover")
    private BigDecimal activeUserTurnover;

    @TableField("active_user_headcount")
    private Integer activeUserHeadcount;

    @TableField("actual_user_count")
    private Integer actualUserCount;

    @TableField("commission_values")
    private String commissionValues;

    // 结算周期：ex:10 perday,7 perday,30 perday
    @TableField("settlement_period")
    private String settlementPeriod;
    // 实际结算开始日期
    @TableField("settle_date_start")
    private LocalDate settleDateStart;
    // 实际结算结算日期
    @TableField("settle_date_end")
    private LocalDate settleDateEnd;
    // 佣金记录状态：0:FIRST_PENDING, 1:FIRST_REJECTED, 2:SECOND_PENDING, 3:SECOND_REJECTED, 4:SECOND_AGREED
    @TableField("status")
    private Integer status;
    // 佣金金额：根据佣金方案以及投注金额或平台收益金额计算得出
    @TableField("commission_amount")
    private BigDecimal commissionAmount;
    // 实际佣金金额：由管理运营人员结算给订单代理或代理结算给下级代理
    @TableField("actual_commission_amount")
    private BigDecimal actualCommissionAmount;
    // 补发佣金:有上级代理根据实际情况补发给下级代理的佣金金额
    @TableField("append_commission_amount")
    private BigDecimal appendCommissionAmount;
    // 货币种类
    @TableField("currency")
    private String currency;
    // 本身代理等级:数据来自于代理表，共五级：1，2，3，4，5
    @TableField("agent_level")
    private Integer agentLevel;
    // 代理所属顶级代理账号：顶级代理账号为系统简称：acc66
    @TableField("level1_agent_account")
    private String level1AgentAccount;
    // 投注金额：玩家投注到平台游戏的金额
    @TableField("turnover")
    private BigDecimal turnover;
    // 平台收入金额：GGR类型佣金计算使用'
    @TableField("GGR")
    private BigDecimal GGR;

    // 玩家输赢金额
    @TableField("win_loss")
    private BigDecimal winOrLoss;
    // 玩家存款金额
    @TableField("deposit")
    private BigDecimal deposit;
    // 玩家取款金额
    @TableField("withdrawal")
    private BigDecimal withdrawal;

    @TableField("percent_info")
    private String percentInfo;
    // 佣金记录备注
    @TableField("remark")
    private String remark;
    // 创建者账号
    @TableField("created_by")
    private String createdBy;
    // 第一阶段审核者账号
    @TableField("first_approve_by")
    private String firstApproveBy;
    // 第二阶段审核者账号
    @TableField("second_approve_by")
    private String secondApproveBy;
    // 佣金记录创建时间
    @TableField("create_time")
    private String createTime;
    // 佣金记录更新时间
    @TableField("update_time")
    private String updateTime;



}
