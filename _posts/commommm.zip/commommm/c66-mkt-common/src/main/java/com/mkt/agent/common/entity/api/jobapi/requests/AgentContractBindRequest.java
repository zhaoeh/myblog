package com.mkt.agent.common.entity.api.jobapi.requests;

import lombok.Data;

/**
 * @author Colson
 * @date 8/14/2023 6:18 PM
 */
@Data
public class AgentContractBindRequest {

    private Long id;
    /**
     * 代理account
     */
    private String loginName;

    /**
     * 佣金方案ID
     */
    private Long commissionContractId;

    private String percentageDetails;

    private String createBy;

    private String updateBy;

}
