package com.mkt.agent.common.utils;

import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.sql.StatementConstant;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2023-12-20
 **/
public class StatementHelper {

    public static String helperQuerySumAgentGgrTData(ClDashBoardCreateQueryReq queryReq) {
        String where = new StringBuilder(StatementConstant.querySumAgentGgrTData1).
                append(AppendUtils.appendSingleQuote(queryReq.getRecordDateStart())).
                append(StatementConstant.querySumAgentGgrTData2).append(AppendUtils.appendSingleQuote(queryReq.getRecordDateEnd())).
                append(StatementConstant.querySumAgentGgrTData3).append(StatementConstant.LEFT_BRACKET).
                append(AppendUtils.appendList(queryReq.getLoginNameList())).append(StatementConstant.RIGHT_BRACKET).toString();
        return where;
    }

    public static String helperQueryGgrActivePlayerCount(ClDashBoardCreateQueryReq queryReq) {
        String where = new StringBuilder(StatementConstant.queryGgrActivePlayerCount1).
                append(AppendUtils.appendSingleQuote(queryReq.getRecordDateStart())).
                append(StatementConstant.queryGgrActivePlayerCount2).append(AppendUtils.appendSingleQuote(queryReq.getRecordDateEnd())).
                append(StatementConstant.queryGgrActivePlayerCount3).append(StatementConstant.LEFT_BRACKET).
                append(AppendUtils.appendList(queryReq.getLoginNameList())).append(StatementConstant.RIGHT_BRACKET).
                append(StatementConstant.queryGgrActivePlayerCount4).append(queryReq.getActiveAmount()).toString();
        return where;
    }

    public static String helperQueryTurnoverActivePlayerCount(ClDashBoardCreateQueryReq queryReq) {
        String where = new StringBuilder(StatementConstant.queryTurnoverActivePlayerCount1).
                append(AppendUtils.appendSingleQuote(queryReq.getRecordDateStart())).
                append(StatementConstant.queryTurnoverActivePlayerCount2).append(AppendUtils.appendSingleQuote(queryReq.getRecordDateEnd())).
                append(StatementConstant.queryTurnoverActivePlayerCount3).append(StatementConstant.LEFT_BRACKET).
                append(AppendUtils.appendList(queryReq.getLoginNameList())).append(StatementConstant.RIGHT_BRACKET).
                append(StatementConstant.queryTurnoverActivePlayerCount4).append(queryReq.getActiveAmount()).toString();
        return where;
    }

    public static String helperTopList(ClDashBoardCreateQueryReq queryReq) {
        String where = new StringBuilder(StatementConstant.topList1).
                append(StatementConstant.LEFT_BRACKET).
                append(AppendUtils.appendList(queryReq.getLoginNameList())).append(StatementConstant.RIGHT_BRACKET).
                append(StatementConstant.topList2).toString();
        return where;
    }

    public static String helperQueryFirstPlayerAndAmountData(ClDashBoardCreateQueryReq queryReq) {
        String where = new StringBuilder(StatementConstant.queryFirstPlayerAndAmountData1).
                append(AppendUtils.appendSingleQuote(queryReq.getRecordDateTimeStart())).
                append(StatementConstant.queryFirstPlayerAndAmountData2).
                append(AppendUtils.appendSingleQuote(queryReq.getRecordDateTimeEnd())).
                append(StatementConstant.queryFirstPlayerAndAmountData3).
                append(StatementConstant.LEFT_BRACKET).
                append(AppendUtils.appendList(queryReq.getLoginNameList())).
                append(StatementConstant.RIGHT_BRACKET).toString();
        return where;
    }

    public static String helperQueryDashBoardData(ClDashBoardCreateQueryReq queryReq){
        String where = new StringBuilder(StatementConstant.queryDashBoardData1).
                append(AppendUtils.appendSingleQuote(queryReq.getRecordDateStart())).
                append(StatementConstant.queryDashBoardData2).
                append(AppendUtils.appendSingleQuote(queryReq.getRecordDateEnd())).
                append(StatementConstant.queryDashBoardData3).
                append(StatementConstant.LEFT_BRACKET).
                append(AppendUtils.appendList(queryReq.getLoginNameList())).
                append(StatementConstant.RIGHT_BRACKET).
                append(StatementConstant.queryDashBoardData4).
                toString();
        return where;
    }
}
