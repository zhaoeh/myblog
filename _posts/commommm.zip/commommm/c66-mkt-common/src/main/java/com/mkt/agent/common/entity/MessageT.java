package com.mkt.agent.common.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;

/**
 * 请求返回消息
 * 
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel
public class MessageT<D1, D2> {

	@ApiModelProperty(value = "是否成功")
	private boolean success;
	@ApiModelProperty(value = "是否失败")
	private boolean fail;
	@ApiModelProperty(value = "提示信息")
	private String msg;
	@ApiModelProperty(value = "数据")
	private D1 data;
	@ApiModelProperty(value = "额外数据")
	private D2 otherData;
	@ApiModelProperty(value = "条目数。查询条目数时")
	private long count;
	@ApiModelProperty(value = "提示信息。仅限 agent office 使用")
	private String msgForOffice;

	@ApiModelProperty(value = "额外数据")
	private List<MessageT> messages = new ArrayList<>();

	// ========================
	public MessageT() {
		super();
	}

	public MessageT(boolean success, String msg, D1 data) {
		super();
		this.success = success;
		this.fail = !success;
		this.msg = msg;
		this.data = data;
	}

	public MessageT(boolean success, String msg) {
		super();
		this.success = success;
		this.fail = !success;
		this.msg = msg;
	}

	public void setFailMsg(String failReason) {
		this.success = false;
		this.fail = true;
		this.msg = failReason;
	}

	// ========================
	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.fail = !success;
		this.success = success;
	}

	public boolean isFail() {
		return fail;
	}

	public void setFail(boolean fail) {
		this.success = !fail;
		this.fail = fail;
	}

	public String getMsg() {
		return msg;
	}

	/*public String getMsgForOffice() {
		if (StringUtils.isBlank(msgForOffice) //
				&& StringUtils.isNotBlank(msg) //
				&& StringUtils.split(msg, "^").length == 3) {
			if(AgentConstants.Msg.MSG_CODE_SUCCESS.equalsIgnoreCase(StringUtils.split(msg, "^")[0])){
				this.msgForOffice = StringUtils.split(msg, "^")[2] ;
			}else{
				this.msgForOffice = StringUtils.split(msg, "^")[2] + "(错误码:"
						+ StringUtils.split(msg, "^")[0] + ")";
			}
		}
		if (StringUtils.isBlank(msgForOffice)) {
			msgForOffice = msg;
		}
		return msgForOffice;
	}*/

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public D1 getData() {
		return data;
	}

	public void setData(D1 data) {
		this.data = data;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	public D2 getOtherData() {
		return otherData;
	}

	public void setOtherData(D2 otherData) {
		this.otherData = otherData;
	}


	public void setMsgForOffice(String msgForOffice) {
		this.msgForOffice = msgForOffice;
	}

	public List<MessageT> getMessages() {
		return messages;
	}
	public void setMessages(List<MessageT> messages) {
		this.messages = messages;
	}
}
