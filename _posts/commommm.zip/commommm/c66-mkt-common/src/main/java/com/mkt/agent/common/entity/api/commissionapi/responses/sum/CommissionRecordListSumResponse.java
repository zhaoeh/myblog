package com.mkt.agent.common.entity.api.commissionapi.responses.sum;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class CommissionRecordListSumResponse {

    // 聚合佣金金额：根据佣金方案以及投注金额或平台收益金额计算得出
    @ApiModelProperty(value = "commissionAmount", example = "1000")
    private BigDecimal sumCommissionAmount;
    // 聚合实际佣金金额：由管理运营人员结算给订单代理或代理结算给下级代理
    @ApiModelProperty(value = "actualCommissionAmount", example = "900")
    private BigDecimal sumActualCommissionAmount;
    // 聚合补发佣金:有上级代理根据实际情况补发给下级代理的佣金金额
    @ApiModelProperty(value = "appendCommissionAmount", example = "100")
    private BigDecimal sumAppendCommissionAmount;

}
