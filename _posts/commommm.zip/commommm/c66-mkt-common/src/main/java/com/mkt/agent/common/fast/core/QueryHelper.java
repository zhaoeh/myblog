package com.mkt.agent.common.fast.core;

import com.mkt.agent.common.fast.pojo.FastQueryModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

/**
 * @description: 查询校验帮助
 * @author: ErHu.Zhao
 * @create: 2024-04-12
 **/
@Component
@Slf4j
public class QueryHelper {

    /**
     * 打印验证结果
     *
     * @param fastContext
     */
    public void printQueryResult(FastContext fastContext) {
        Assert.notNull(fastContext, "fastContext cannot be null");
        // 全量代理总数
        int allAgentCount = fastContext.getQueryAgentsCount().apply(FastQueryModel.builder().build());
        log.info("mysql代理表中全量的代理总数为{}", allAgentCount);
        // 已经脱敏的代理总数
        int mappedAgentCount = fastContext.getQueryAgentsCount().apply(FastQueryModel.builder().isMappingDone(1).build());
        log.info("mysql代理表中已经脱敏的代理总数为{}", mappedAgentCount);
        // 未脱敏的代理总数
        int notMappedAgentCount = fastContext.getQueryAgentsCount().apply(FastQueryModel.builder().isMappingDone(0).build());
        log.info("mysql代理表中未脱敏的代理总数为{}", notMappedAgentCount);
        // 代理脱敏表中的代理总数
        int successMappedAgentCount = fastContext.getQueryAgentsCount().apply(FastQueryModel.builder().build());
        log.info("mysql代理脱敏表中成功被脱敏的代理总数为{}", successMappedAgentCount);
        // 全量玩家总数
        int allPlayersCount = fastContext.getQueryPlayersCount().apply(FastQueryModel.builder().build());
        log.info("mysql玩家表中全量的玩家总数为{}", allPlayersCount);
        // 已经转移的玩家总数
        int transferPlayersCount = fastContext.getQueryPlayersCount().apply(FastQueryModel.builder().isTransferDone(1).build());
        log.info("mysql玩家表中已经转移的玩家总数为{}", transferPlayersCount);
        // 未转移的玩家总数
        int notTransferPlayersCount = fastContext.getQueryPlayersCount().apply(FastQueryModel.builder().isTransferDone(0).build());
        log.info("mysql玩家表中未转移的玩家总数为{}", notTransferPlayersCount);
        // 无效的玩家总数
        int invalidTransferPlayersCount = fastContext.getQueryPlayersCount().apply(FastQueryModel.builder().isTransferDone(-1).build());
        log.info("mysql玩家表中无效的玩家总数为{}", invalidTransferPlayersCount);
        // byteHouse中成功转移的玩家总数
        int transferPlayersCountInByte = fastContext.getQueryUserMappingCount().apply(FastQueryModel.builder().isDelete(0).build());
        log.info("byteHouse转移表中成功转移的玩家总数为{}", transferPlayersCountInByte);
        // byteHouse中无效的玩家总数
        int invalidPlayersCountInByte = fastContext.getQueryUserMappingCount().apply(FastQueryModel.builder().isDelete(1).build());
        log.info("byteHouse转移表中被删除（无效）的玩家总数为{}", invalidPlayersCountInByte);
    }
}
