package com.mkt.agent.common.entity.api.reportapi.responses;


import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.mkt.agent.common.entity.api.integration.bi.responses.UserGameSummerResponse;
import com.mkt.agent.common.jackson.serializer.BigDecimalSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
@ApiModel(description = "TeamReportByGameResponse")
public class TeamReportByGameResponse {

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount")
    private String agentAccount;

    // 佣金记录查询开始产生时间
    @ApiModelProperty(value = "date", example = "2023-01-17")
    private String date;

    // 佣金记录查询结束时间产生时间
    @ApiModelProperty(value = "month", example = "2023-01")
    private String month;

    @ApiModelProperty(value = "userGameSummerResponses")
    private List<UserGameSummerResponse> userGameSummerResponses;

    @ApiModelProperty(value = "turnoverSum", example = "10000.00")
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal turnoverSum;

    @ApiModelProperty(value = "ggrSum", example = "1000.00")
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal ggrSum;

    @ApiModelProperty(value = "outcomeSum", example = "10000.00")
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal outcomeSum;

}
