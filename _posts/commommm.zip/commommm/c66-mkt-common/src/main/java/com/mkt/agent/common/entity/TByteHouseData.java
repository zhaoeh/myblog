package com.mkt.agent.common.entity;


import com.alibaba.excel.annotation.ExcelProperty;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Table(name = "数据同步基础数据")
@TableName("t_bytehouse_data")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@ToString

public class TByteHouseData {
    private String agentDate;

    //代理的用户名
    @ExcelProperty("字符串标题")
    private String loginName;
    @ExcelProperty("字符串标题")
    private BigDecimal ggr = BigDecimal.ZERO.setScale(2);

    private BigDecimal turnover = BigDecimal.ZERO.setScale(2);

    private BigDecimal winOrLoss = BigDecimal.ZERO.setScale(2);

    //当gameType是 88221，88222，88223时的金额
    private Long firstDeposit    = 0L ;   //首充人数
    private BigDecimal firstDepositAmount = BigDecimal.ZERO.setScale(2); //首充金额

    private BigDecimal depositAmount = BigDecimal.ZERO.setScale(2);   // 充值金额
    private BigDecimal withdrawalAmount = BigDecimal.ZERO.setScale(2);  //  提现金额
    private String  parentname1    ; //上级人
    private String  parentname2    ; //上级人






}
