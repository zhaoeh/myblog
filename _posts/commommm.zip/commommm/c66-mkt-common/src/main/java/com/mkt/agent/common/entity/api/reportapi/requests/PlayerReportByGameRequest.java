package com.mkt.agent.common.entity.api.reportapi.requests;


import com.mkt.agent.common.utils.DateUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

@ApiModel(value = "PlayerReportByGameRequest")
@Data
public class PlayerReportByGameRequest implements Serializable {

    private static final long serialVersionUID = 1l;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount", example = "brewtest1", required = true)
    @NotNull(message = "agentAccount can not be null")
    private String agentAccount;

    // 查询时间（日期）
    @ApiModelProperty(value = "date", example = "2024-02-09")
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "date data format error")
    private String date;

    // 查询时间（月份）
    @ApiModelProperty(value = "month", example = "2024-02")
    @Pattern(regexp = "^\\d{4}-\\d{2}$", message = "month data format error")
    private String month;

    // 查询时间（月份--具体开始日期）
    private String monthBeginDate;

    // 查询时间（月份--具体结束日期）
    private String monthEndDate;

    /**
     * 根据月份 ”2024-02“ 设置具体开始和结束日期 ”2024-02-01“ ”2024-02-29“
     */
    public void setFirstAndEndDateOfMonth() {
        this.monthBeginDate = DateUtils.getFirstDayOfMonth(this.getMonth()).toString();
        this.monthEndDate = DateUtils.getLastDayOfMonth(this.getMonth()).toString();
    }


}


