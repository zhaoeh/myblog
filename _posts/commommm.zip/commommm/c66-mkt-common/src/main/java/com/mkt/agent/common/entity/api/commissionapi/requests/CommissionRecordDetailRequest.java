package com.mkt.agent.common.entity.api.commissionapi.requests;

import com.mkt.agent.common.entity.api.commissionapi.requests.base.CommissionRecordBaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value = "CommissionRecordDetailRequest")
public class CommissionRecordDetailRequest extends CommissionRecordBaseRequest {


    private static final long serialVersionUID = 1l;

    @ApiModelProperty(value = "commissionRecordId")
    private Long commissionRecordId;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount", example = "top")
    private String agentAccount;

    // 代理类型：0：General Line (普通代理)，1：Professional Line(专业代理可发展下级)
    @ApiModelProperty(value = "agentType")
    private Integer agentType;

    @ApiModelProperty(value = "agentLevel", example = "1")
    private Integer agentLevel;

    //父类代理账号，用于查询条件
    @ApiModelProperty(hidden = true,value = "parentAccount", example = "top")
    private String parentAccount;


}


