package com.mkt.agent.common.entity.api.commissionapi.responses;



import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.mkt.agent.common.annotation.ExcelColumn;
import com.mkt.agent.common.entity.api.commissionapi.responses.base.CommissionRecordBaseResponse;
import com.mkt.agent.common.jackson.serializer.BigDecimalSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;



@Data
@ApiModel(description = "佣金记录支付信息")
public class CommissionRecordPayResponse extends CommissionRecordBaseResponse {

    // 佣金记录id：佣金记录唯一标识
    @ApiModelProperty(value = "commission record ID", example = "1,auto increment")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private Long id;
    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount", example = "Amida001")
    @ExcelColumn(value = "Account",order = 0)
    private String agentAccount;
    // 实际结算周期
    @ApiModelProperty(value = "settleDateStart", example = "5.1")
    private String settleDateStart;
    @ApiModelProperty(value = "settleDateEnd", example = "5.10")
    private String settleDateEnd;

    @ApiModelProperty(value = "commissionPeriod", example = "2023-7")
    @ExcelColumn(value = "Commission Period",order = 1)
    private String commissionPeriod;

    // 佣金金额：根据佣金方案以及投注金额或平台收益金额计算得出
    @ApiModelProperty(value = "commissionAmount", example = "1000")
    @ExcelColumn(value = "Commission",order = 2)
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal commissionAmount;

    // 实际佣金金额：由管理运营人员结算给订单代理或代理结算给下级代理
    @ApiModelProperty(value = "actualCommissionAmount", example = "900")
    @ExcelColumn(value = "Actual Commission",order = 3)
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal actualCommissionAmount;

    // 佣金记录状态：0:清算中pending,1:同意agreed,2:拒绝rejected
    @ApiModelProperty(value = "actualSettlementPeriod",
            example = "0:initial status meaning pending," +
                    "1:FIRST_AGREED," +
                    "2:FIRST_REJECTED," +
                    "3:SECOND_AGREED," +
                    "4,SECOND_REJECTED," +
                    "5,RESET," +
                    "6,PAID," +
                    "7,UNPAID")
    private Integer status;

    @ExcelColumn(value = "Status",order = 4)
    private String statusValue;

    // 佣金记录创建时间
    @ApiModelProperty(value = "createTime", example = "05/18/2023 08:30:45")
    @ExcelColumn(value = "Generate Time",order = 5)
    private String createTime;

}
