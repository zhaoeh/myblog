package com.mkt.agent.common.fast.event;

import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.fast.core.FastContext;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.ApplicationEvent;

import java.util.List;

/**
 * @description: 取消代理身份事件
 * @author: ErHu.Zhao
 * @create: 2024-04-02
 **/
public class CancleAgentEvent extends ApplicationEvent {

    /**
     * 被取消的代理信息
     */
    private List<TAgentCustomers> agents;

    private List<TCustomerLayer> players;

    private FastContext fastContext;

    private SqlSessionFactory factory;

    public CancleAgentEvent(Object source, List<TAgentCustomers> agents, List<TCustomerLayer> players, FastContext fastContext, SqlSessionFactory factory) {
        super(source);
        this.agents = agents;
        this.players = players;
        this.fastContext = fastContext;
        this.factory = factory;
    }

    public List<TAgentCustomers> getAgents() {
        return agents;
    }

    public List<TCustomerLayer> getPlayers() {
        return players;
    }

    public FastContext getFastContext() {
        return fastContext;
    }

    public SqlSessionFactory getFactory() {
        return factory;
    }
}
