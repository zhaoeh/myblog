package com.mkt.agent.common.entity.api.atransferapi.request;

import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @Description 审核接口入参
 * @Classname P2ATransferVerifyReq
 * @Date 2023/6/23 10:39
 * @Created by TJSLucian
 */
@Data
public class P2ATransferVerifyReq implements Serializable {

    @ApiModelProperty(required = true,value = "提案编号 ", example = "T2023062118227813")
    @NotBlank(message = "transaction_id can not be blank",groups = InputValidationGroup.Insert.class)
    private String transactionId;

    @ApiModelProperty(value = "审核方类型 1：门店一审 2：门店二审 ", example = "1")
    @NotBlank(message = "type can not be blank",groups = InputValidationGroup.Insert.class)
    private String type;

    @ApiModelProperty(value = "审核方人员", example = "System")
    @NotBlank(message = "verifyBy can not be blank",groups = InputValidationGroup.Insert.class)
    private String verifyBy;

    @ApiModelProperty(value = "审核结果 0: 通过 1: 拒绝", example = "0")
    @NotBlank(message = "flag can not be blank",groups = InputValidationGroup.Insert.class)
    private Integer flag;

}
