package com.mkt.agent.common.entity.api.atransferapi;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @Description 玩家转代理提案实体类
 * @Classname P2ATransferEntity
 * @Date 2023/6/21 14:49
 * @Created by TJSLucian
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@TableName("t_player2agent_trans")
public class P2ATransferEntity implements Serializable {


    @ApiModelProperty(required = true,value = "主键id", example = "46554654646")
    @NotNull(message = "id can not be blank",groups = InputValidationGroup.Update.class)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;

    @ApiModelProperty(required = true,value = "所属产品", example = "C66")
    @NotBlank(message = "product id can not be blank",groups = InputValidationGroup.Insert.class)
    private String productId;

    @ApiModelProperty(required = true,value = "产品类型 1:Bingoplus 2:Arenaplus 3:Gameplus", example = "1")
    @NotBlank(message = "product can not be blank",groups = InputValidationGroup.Insert.class)
    private Integer siteId;

    @ApiModelProperty(required = true,value = "创建时间", example = "2023-06-10 12:31:20")
    @NotBlank(message = "createTime can not be blank",groups = InputValidationGroup.Insert.class)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    @ApiModelProperty(required = true,value = "创建人", example = "Lucian")
    @NotBlank(message = "createBy can not be blank",groups = InputValidationGroup.Insert.class)
    private String createBy;

    @ApiModelProperty(required = true,value = "提案状态 -1:Pending 待审核 0:Approved 审核通过 -2:Pending2 待二审 2:Rejected 拒绝", example = "1")
    @NotBlank(message = "status can not be blank",groups = InputValidationGroup.Insert.class)
    private Integer status;

    @ApiModelProperty(required = true,value = "提案编号 ", example = "T2023062118227813")
    @NotBlank(message = "transaction_id can not be blank",groups = InputValidationGroup.Insert.class)
    private String transactionId;

    @ApiModelProperty(required = true,value = "出账玩家ID", example = "2023062118227813")
    @NotBlank(message = "from_id can not be blank",groups = InputValidationGroup.Insert.class)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long fromId;

    @ApiModelProperty(required = true,value = "出账玩家账号", example = "Lucian")
    @NotBlank(message = "from_account can not be blank",groups = InputValidationGroup.Insert.class)
    private String fromAccount;

    @ApiModelProperty(required = true,value = "入账代理ID", example = "20230621184256165")
    @NotBlank(message = "to_id can not be blank",groups = InputValidationGroup.Insert.class)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long toId;

    @ApiModelProperty(required = true,value = "入账代理账号", example = "Alex")
    @NotBlank(message = "to_account can not be blank",groups = InputValidationGroup.Insert.class)
    private String toAccount;

    @ApiModelProperty(required = true, value = "提案金额", example = "100")
    @NotBlank(message = "amount can not be blank",groups = InputValidationGroup.Insert.class)
    private BigDecimal amount;

    @ApiModelProperty(value = "存款币种,默认为PHP", example = "PHP")
    @NotBlank(message = "currency can not be blank",groups = InputValidationGroup.Insert.class)
    private String currency = "PHP";

    @ApiModelProperty(value = "是否删除 0: 未删除 1：已删除, 默认为0", example = "0")
    private Integer isDeleted = 0;

    @ApiModelProperty(value = "是否首次转账 0: 否 1：是, 默认为0", example = "0")
    private Integer isFirst = 0;

    @ApiModelProperty(required = true,value = "一审审批人", example = "Lucian")
    @NotBlank(message = "firstReviewer can not be blank",groups = InputValidationGroup.Insert.class)
    private String firstReviewer;

    @ApiModelProperty(required = true,value = "一审审批时间", example = "2023-06-10 12:31:20")
    @NotBlank(message = "firstReviewTime can not be blank",groups = InputValidationGroup.Insert.class)
    private Date firstReviewTime;

    @ApiModelProperty(required = true,value = "二审审批人", example = "Lucian")
    @NotBlank(message = "secondReviewer can not be blank",groups = InputValidationGroup.Insert.class)
    private String secondReviewer;

    @ApiModelProperty(required = true,value = "二审审批时间", example = "2023-06-10 12:31:20")
    @NotBlank(message = "secondReviewTime can not be blank",groups = InputValidationGroup.Insert.class)
    private Date secondReviewTime;

    @ApiModelProperty(value = "ip地址", example = "127.0.0.1")
    private String ipAddress;

    @ApiModelProperty(value = "备注")
    private String remarks;

    @ApiModelProperty(required = true,value = "更新人", example = "Lucian")
    @NotBlank(message = "update_by can not be blank",groups = InputValidationGroup.Insert.class)
    private String updateBy;

    @ApiModelProperty(required = true,value = "更新时间", example = "2023-06-10 12:31:20")
    @NotBlank(message = "updateTime can not be blank",groups = InputValidationGroup.Insert.class)
    private Date updateTime;


}
