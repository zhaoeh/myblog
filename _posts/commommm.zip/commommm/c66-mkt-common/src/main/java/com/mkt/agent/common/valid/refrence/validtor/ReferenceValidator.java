package com.mkt.agent.common.valid.refrence.validtor;


import com.mkt.agent.common.valid.refrence.annotation.ReferenceField;
import com.mkt.agent.common.valid.refrence.annotation.ReferenceManager;
import com.mkt.agent.common.valid.refrence.annotation.ReferenceHolder;
import com.mkt.agent.common.valid.refrence.annotation.ReferenceValid;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.Range;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.util.ReflectionUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * @ClassName EnumValidtor
 * @Description 校验入参是否为指定enum的值的实现方法
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Slf4j
public class ReferenceValidator implements ConstraintValidator<ReferenceManager, Object> {

    @Override
    public void initialize(ReferenceManager constraintAnnotation) {
    }

    @SneakyThrows
    @Override
    public boolean isValid(Object target, ConstraintValidatorContext context) {
        if (Objects.isNull(target)) {
            return true;
        }
        final List<String> result = new ArrayList<>();
        Class<?> targetClazz = target.getClass();
        ReflectionUtils.doWithFields(targetClazz, field -> ranges(targetClazz, field, target, result));
        return isValid(context, result);
    }

    private boolean isValid(ConstraintValidatorContext context, final List<String> result) {
        if (result.size() > 0) {
            String message = result.get(0);
            if (StringUtils.isNotBlank(message)) {
                // 禁用默认message
                context.disableDefaultConstraintViolation();
                context.buildConstraintViolationWithTemplate(message).addConstraintViolation();
            }
            return false;
        }
        return true;
    }


    private ReferenceHolder[] obtainReferenceRanges(Field field) {
        // 遍历所有字段，获取标注ReferenceValid注解的字段
        ReferenceValid referenceValid = AnnotatedElementUtils.findMergedAnnotation(field, ReferenceValid.class);
        if (Objects.nonNull(referenceValid)) {
            ReferenceHolder[] holders = referenceValid.holders();
            return holders;
        }
        return null;
    }

    private void ranges(Class<?> targetClazz, Field field, Object target, List<String> result) {
        ReferenceHolder[] holders = obtainReferenceRanges(field);
        if (Objects.nonNull(holders)) {
            Arrays.stream(holders).forEach(range -> {
                doReferenceRange(targetClazz, field, target, result, range);
            });
        }
    }

    private void doReferenceRange(Class<?> targetClazz, Field field, Object target, List<String> result, ReferenceHolder holder) {
        ReferenceField referenceField = holder.referenceField();
        if (Objects.nonNull(referenceField)) {
            String fieldName = referenceField.name();
            String when = referenceField.when();
            if (StringUtils.isNotBlank(fieldName) && StringUtils.isNotBlank(when)) {
                try {
                    isReject(targetClazz, field, target, result, holder, fieldName, when);
                } catch (Exception e) {
                    log.error("an error occurred:", e);
                    return;
                }

            }
        }
    }

    /**
     * 是否拒绝请求
     *
     * @param targetClazz
     * @param field
     * @param target
     * @param result
     * @param holder
     * @param fieldName
     * @param when
     */
    private void isReject(Class<?> targetClazz, Field field, Object target, List<String> result, ReferenceHolder holder, String fieldName, String when) {
        Field targetField = ReflectionUtils.findField(targetClazz, fieldName);
        if(Objects.isNull(target)){
            return;
        }
        ReflectionUtils.makeAccessible(targetField);
        String targetFieldName = targetField.getName();
        String targetFieldValue = Objects.toString(ReflectionUtils.getField(targetField, target));
        if (when.equals(targetFieldValue)) {
            Range ran = holder.range();
            RangeValidator.isReject(field, target, result, ran, targetFieldName, targetFieldValue);
        }
    }
}
