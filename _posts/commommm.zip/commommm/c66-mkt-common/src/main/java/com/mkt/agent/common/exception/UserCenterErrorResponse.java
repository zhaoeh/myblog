package com.mkt.agent.common.exception;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @description: userCenter服务错误响应结构
 * @author: ErHu.Zhao
 * @create: 2023-12-26
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserCenterErrorResponse {
    private String message;

    private Integer code;

    private Object data;

    private Boolean success;
}
