package com.mkt.agent.common.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public class TAgentMessageRecord {

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long customerId;
    private String exchange;
    private String queue;
    private String message;
    private String createTime;
    private String messageId;
    private int flag;


}
