package com.mkt.agent.common.entity.api.fund.req;

import com.mkt.agent.common.entity.BasePageRequest;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;

/**
 * @ClassName FundRecordReq
 * @Author TJSAlex
 * @Date 2023/5/19 10:05
 * @Version 1.0
 **/
@Data
public class FundRecordReq extends BasePageRequest {
    @ApiModelProperty(value = "agentId",hidden = true)
    private Long agentId;
    @ApiModelProperty(value = "account")
    private String account;
    @ApiModelProperty(value = "fundType",example = "0:Deposit 1:Withdrawal 2:Transfer 3:Received 4:Paid Commission 5:Received Commission 6:Append Commission")
    private String fundType;
    @ApiModelProperty(value = "minAmount")
    private BigDecimal minAmount;
    @ApiModelProperty(value = "maxAmount")
    private BigDecimal maxAmount;
    @ApiModelProperty(value = "status",example = "0:Pending 1:Success 2:Failure")
    private String status;
    @ApiModelProperty(value = "fromId",hidden = true)
    private Long fromId;
    @ApiModelProperty(value = "fromAccount")
    private String fromAccount;
    @ApiModelProperty(value = "toId",hidden = true)
    private Long toId;
    @ApiModelProperty(value = "toAccount")
    private String toAccount;
    @ApiModelProperty(value = "transactionId")
    private String transactionId;
    @ApiModelProperty(value = "startTime")
    private String startTime;
    @ApiModelProperty(value = "endTime")
    private String endTime;
    @ApiModelProperty(value = "interactionPerson")
    private String interactionPerson;

    @Override
    public String getSortName() {
        if(StringUtils.isBlank(super.getSortName())) {
            return "create_time";
        }
        return super.getSortName();
    }
}
