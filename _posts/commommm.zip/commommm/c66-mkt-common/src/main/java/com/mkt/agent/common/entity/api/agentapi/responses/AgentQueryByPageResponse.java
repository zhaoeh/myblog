package com.mkt.agent.common.entity.api.agentapi.responses;


import com.mkt.agent.common.entity.api.jobapi.requests.base.TaskBaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(description = "AgentQueryByPageResponse")
public class AgentQueryByPageResponse extends TaskBaseRequest<AgentQueryByPageResponse> {


    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount")
    private String agentAccount;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "parentAccount", example = "Amida001")
    private String parentAccount;


    @ApiModelProperty(value = "agentLevel")
    private Integer agentLevel;


    public void publicParamSet(AgentQueryByPageResponse paramReq) {

        super.setAgentNums(paramReq.getAgentNums());
        super.setSaveCount(paramReq.getSaveCount());
        super.setFlag(paramReq.getFlag());

        super.setStartDate(paramReq.getStartDate());
        super.setEndDate(paramReq.getEndDate());
        super.setSettleDateStart(paramReq.getSettleDateStart());
        super.setSettleDateEnd(paramReq.getSettleDateEnd());


    }


}
