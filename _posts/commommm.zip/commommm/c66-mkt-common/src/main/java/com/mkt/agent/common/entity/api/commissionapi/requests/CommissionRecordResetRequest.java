package com.mkt.agent.common.entity.api.commissionapi.requests;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
@ApiModel(value = "CommissionRecordResetRequest")
public class CommissionRecordResetRequest implements Serializable {

    private static final long serialVersionUID = 1l;


    // 佣金记录id：佣金记录唯一标识
    @ApiModelProperty(value = "commissionRecordId")
    @NotNull
    private Long commissionRecordId;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount")
    private String agentAccount;


}
