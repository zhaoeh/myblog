package com.mkt.agent.common.entity.api.userapi.requests;

import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TCustomerLayerReq {

    @ApiModelProperty(value = "登录名")
    @NotBlank(message = "loginName is not blank",groups = InputValidationGroup.UserToAgent.class)
    private String loginName;

    @Column(name="CUSTOMERS_ID")
    @NotNull(message = "customersId is not blank",groups = InputValidationGroup.UserToAgent.class)
    private Long customersId;
}
