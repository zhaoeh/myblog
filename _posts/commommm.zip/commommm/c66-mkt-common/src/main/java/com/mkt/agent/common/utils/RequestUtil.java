package com.mkt.agent.common.utils;

import com.mkt.agent.common.wrapper.RequestWrapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.net.URLDecoder;

/**
 * @Description TODO
 * @Classname RequestUtil
 * @Date 2024/4/22 15:46
 * @Created by TJSLucian
 */
@Slf4j
public class RequestUtil {

    public static void printLog(RequestWrapper requestWrapper,String operator) throws IOException {
        String method = requestWrapper.getMethod();
        if ("GET".equalsIgnoreCase(method)) {
            log.info("[Operation record log]The user:{} accessed the request api: {} at: {}. The params are: {}",operator,requestWrapper.getRequestURL(), DateUtils.getCurrentDateTime(),
                    StringUtils.isEmpty(requestWrapper.getQueryString())? "" : URLDecoder.decode(requestWrapper.getQueryString(),"UTF-8"));
        } else if ("POST".equalsIgnoreCase(method) && "application/json".equalsIgnoreCase(requestWrapper.getContentType())) {
            String body = IOUtils.toString(requestWrapper.getInputStream(), requestWrapper.getCharacterEncoding());
            log.info("[Operation record log]The user:{} accessed the request api: {} at: {}. The params are: {}",operator,requestWrapper.getRequestURL(), DateUtils.getCurrentDateTime(),body);
        }
    }

}
