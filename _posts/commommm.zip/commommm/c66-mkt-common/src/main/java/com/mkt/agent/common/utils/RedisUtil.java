package com.mkt.agent.common.utils;

import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.time.Duration;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

@Component
public class RedisUtil {

    public static final String USER_BIND_PHONE_TIP_PREFIX = "USER_BIND_PHONE_TIP_";

    public static final long THIRTY_DAYS = 60 * 60 * 24 * 30L;

    @Resource
    private RedisTemplate<String, Object> redisTemplate;

//    public RedisUtil(RedisTemplate<String, Object> redisTemplate) {
//        this.redisTemplate = redisTemplate;
//    }

    public boolean setExpire(String key, long time) {

        try {
            if (time > 0) {
                redisTemplate.expire(key, time, TimeUnit.SECONDS);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }

    public long getExpire(String key) {
        return redisTemplate.getExpire(key, TimeUnit.SECONDS);
    }


    public boolean hasKey(String key) {
        return redisTemplate.hasKey(key);
    }


    public Object get(String key) {
        return key == null ? null : redisTemplate.opsForValue().get(key);
    }

    public boolean set(String key, Object value) {

        try {
            redisTemplate.opsForValue().set(key, value);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }

    public boolean delete(String key) {
        try {
            return redisTemplate.delete(key);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean set(String key, Object value, long time) {

        try {
            if (time > 0) {
                redisTemplate.opsForValue().set(key, value, time, TimeUnit.SECONDS);
            } else {
                set(key, value);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }

    public boolean setByTimeUnit(String key, Object value, long time, TimeUnit timeUnit) {

        try {
            if (time > 0) {
                redisTemplate.opsForValue().set(key, value, time, timeUnit);
            } else {
                set(key, value);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }

    public boolean hmset(String key, Map<String, Object> map) {

        try {
            redisTemplate.opsForHash().putAll(key, map);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }


    }

    public boolean hmset(String key, Map<String, Object> map, long time) {

        try {

            redisTemplate.opsForHash().putAll(key, map);
            if (time > 0) {
                setExpire(key, time);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }

    public boolean hmset(String key, String field, Object value, long time) {

        try {

            redisTemplate.opsForHash().put(key, field, value);
            if (time > 0) {
                setExpire(key, time);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }


    public Object hget(String key, String field) {

        return redisTemplate.opsForHash().get(key, field);

    }


    public Map<Object, Object> hmget(String key) {

        return redisTemplate.opsForHash().entries(key);

    }


    public boolean sSet(String key,Set<String> set){
        try {
            redisTemplate.opsForSet().add(key,set);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public Set<Object> sGet(String key){
        return redisTemplate.opsForSet().members(key);
    }

    /**
     * 批量删除对应的value
     */
    public void remove(final String... keys) {
        for (String key : keys) {
            remove(key);
        }
    }

    /**
     * 删除对应的value
     */
    public void remove(final String key) {
        if (exists(key)) {
            redisTemplate.delete(key);
        }
    }

    /**
     * 判断缓存中是否有对应的value
     */
    public boolean exists(final String key) {
        Boolean result = redisTemplate.hasKey(key);
        if (null == result) {
            return false;
        }
        return result;
    }

    public Boolean setIfAbsent (String key ,String value, Duration timeout){
        return redisTemplate.opsForValue().setIfAbsent(key,value,timeout);
    }
    
    public  Long increment(String key,Long num){
        return redisTemplate.opsForValue().increment(key,num);
    }
    public  Long decrement(String key,Long num){
        return redisTemplate.opsForValue().decrement(key,num);
    }

    /**
     * 批量删除某种前缀的所有key
     *
     * @param prefix
     */
    public void removeKeysByPrefix(String prefix) {

        redisTemplate.execute((RedisConnection connection) -> {
            ScanOptions scanOptions = ScanOptions.scanOptions().match(prefix + "*").build();
            connection.scan(scanOptions).forEachRemaining(key -> connection.del(key));
            return null;
        });

//        Set<String> matchKeys = redisTemplate.keys(prefix + "*");
//        if(CollectionUtils.isEmpty(matchKeys)){
//            return;
//        }
//        redisTemplate.delete(matchKeys);
    }
}
