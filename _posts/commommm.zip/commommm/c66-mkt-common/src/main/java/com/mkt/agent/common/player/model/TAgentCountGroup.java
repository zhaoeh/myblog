package com.mkt.agent.common.player.model;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.Table;
import java.util.List;
import java.util.Objects;

/**
 * @description: t_agent_count_group_day 实体
 * @author: ErHu.Zhao
 * @create: 2024-01-31
 **/
@Table(name = "代理用户按天分组交易总数统计表")
@TableName("t_agent_count_group_day")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public class TAgentCountGroup {

    /**
     * 汇总count类型：1，汇总自己本身count 2，汇总下级直属count 3，汇总下级代理的团队count
     */
    private Integer totalType;

    /**
     * 操作类型：1，刷新动作（先删后插）2，同步动作（纯粹插入）3，清除动作（纯粹删除）
     */
    private Integer actionType;

    /**
     * 数据来源类型 0：定时任务 1：异步更新
     */
    private String dataSourceType;

    /**
     * 是否需要异步更新
     */
    private Boolean isNeedAsyncUpdate;

    /**
     * 指定清除几天前的数据
     */
    private Integer clearDays;

    /**
     * 当前请求登录的代理名称
     */
    private String agentName;

    /**
     * 当前代理的父代理名称
     */
    private String parentAgentName;

    /**
     * 当前汇总日期
     */
    private String dashDate;

    /**
     * 最大日期
     */
    private String maxDate;

    /**
     * 最小日期
     */
    private String minDate;

    /**
     * 当前检索条件中的开始日期
     */
    private String beginDate;

    /**
     * 当前检索条件中的结束日期
     */
    private String endDate;

    /**
     * 当前代理用户自己当天交易总数
     */
    private Integer selfCount;

    /**
     * 当前代理直属用户当天交易总数
     */
    private Integer directCount;

    /**
     * 当前代理下级代理用户当天交易总数
     */
    private Integer downCount;

    /**
     * 当前代理用户当天交易总数（直属用户交易总数+下级代理用户交易总数）
     */
    private Integer totalCount;

    /**
     * 查询用户集：目标玩家名称/当前代理下级代理集/当前代理下级团队用户集/当前代理下级直属用户集
     */
    private List<String> queryUsers;

    /**
     * 当前请求对应的目标代理集：当前登录的代理/当前level对应的代理集/当前parent指定的代理
     */
    private List<String> targetAgents;

    /**
     * 有可能参与重试的同步对象集合
     */
    private List<TAgentCountGroup> willRetrySyncs;

    /**
     * 是否被删除：0未删除，1已删除
     */
    private Integer isDeleted;

    /**
     * 是否被启用：0未被启用，1已被启用
     */
    private Integer isEnable;

    /**
     * 当前更新条数
     */
    private Integer update;

    /**
     * 是否全量删除
     */
    private Boolean forceClearAll;

    /**
     * 定时器跑数的最大结束日期
     */
    private String maxDateWithTiming;

    /**
     * 清空重试容器
     */
    public void clearRetries(){
        if(Objects.nonNull(willRetrySyncs)){
            willRetrySyncs = null;
        }
    }

    /**
     * 清空参数容器
     */
    public void clearParams() {
        if (Objects.nonNull(queryUsers)) {
            queryUsers = null;
        }
        if (Objects.nonNull(targetAgents)) {
            targetAgents = null;
        }
    }

    /**
     * 清空集合容器
     */
    public void clear(){
        clearParams();
        clearRetries();
    }

    @Override
    public String toString() {
        return "TAgentCountGroup{" +
                "totalType=" + totalType +
                ", actionType=" + actionType +
                ", dataSourceType='" + dataSourceType + '\'' +
                ", isNeedAsyncUpdate=" + isNeedAsyncUpdate +
                ", clearDays=" + clearDays +
                ", agentName='" + agentName + '\'' +
                ", parentAgentName='" + parentAgentName + '\'' +
                ", dashDate='" + dashDate + '\'' +
                ", maxDate='" + maxDate + '\'' +
                ", minDate='" + minDate + '\'' +
                ", beginDate='" + beginDate + '\'' +
                ", endDate='" + endDate + '\'' +
                ", selfCount=" + selfCount +
                ", directCount=" + directCount +
                ", downCount=" + downCount +
                ", totalCount=" + totalCount +
                ", isDeleted=" + isDeleted +
                ", isEnable=" + isEnable +
                '}';
    }
}
