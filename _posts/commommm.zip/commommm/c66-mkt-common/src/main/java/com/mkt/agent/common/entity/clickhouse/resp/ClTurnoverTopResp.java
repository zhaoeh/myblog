package com.mkt.agent.common.entity.clickhouse.resp;


import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.mkt.agent.common.jackson.serializer.BigDecimalSerializer;
import com.mkt.agent.common.jackson.serializer.BigDecimalZeroSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
@ApiModel(description = "排名前十的玩家账号柱状图")
public class ClTurnoverTopResp {

    // 用户名
    @ApiModelProperty(value = "login_name", example = "mptest388")
    private String loginName;
    // 投注额总计
    @ApiModelProperty(value = "turnoverSum", example = "20000")
    @JsonSerialize(using = BigDecimalZeroSerializer.class)
    private BigDecimal turnoverSum;
}
