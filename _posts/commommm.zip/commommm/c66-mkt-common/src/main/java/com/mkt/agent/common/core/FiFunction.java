package com.mkt.agent.common.core;

@FunctionalInterface
public interface FiFunction<T, U, W, S, R> {

    R apply(T t, U u, W w, S s);

}
