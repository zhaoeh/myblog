package com.mkt.agent.common.valid.refrence.validtor;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.Range;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Objects;

/**
 * @description: 校验range
 * @author: ErHu.Zhao
 * @create: 2024-01-26
 **/
public class RangeValidator {

    private static final String defaultMessage = "{org.hibernate.validator.constraints.Range.message}";

    public static void isReject(Field field, Object target, List<String> result, Range ran, String targetFieldName, String targetFieldValue) {
        if (Objects.isNull(ran)) {
            return;
        }
        long min = ran.min();
        long max = ran.max();
        ReflectionUtils.makeAccessible(field);
        // 当前字段的值
        Object currentFieldValue = ReflectionUtils.getField(field, target);
        if (Objects.nonNull(currentFieldValue)) {
            long currentValue = Long.valueOf(currentFieldValue.toString());
            if (currentValue < min || currentValue > max) {
                result.add(handleRangeMessage(ran, field, min, max, targetFieldName, targetFieldValue));
                return;
            }
        }
    }

    /**
     * 处理@Range注解的message
     *
     * @param ran
     * @param field
     * @param min
     * @param max
     * @return
     */
    private static String handleRangeMessage(Range ran, Field field, long min, long max, String targetFieldName, String targetFieldValue) {
        String message = ran.message();
        if (StringUtils.isNotBlank(message) && !defaultMessage.equals(message)) {
            return message;
        }
        String fieldName = field.getName();
        message = "%s must between %s and %s when %s is %s";
        return String.format(message, fieldName, min, max, targetFieldName, targetFieldValue);
    }
}
