package com.mkt.agent.common.entity.api.reportapi.responses;


import com.alibaba.excel.annotation.ExcelIgnore;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.mkt.agent.common.annotation.ExcelColumn;
import com.mkt.agent.common.entity.api.reportapi.responses.base.ReportBaseResponse;
import com.mkt.agent.common.jackson.serializer.BigDecimalSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
@ApiModel(description = "记录信息")
public class TeamReportResponse extends ReportBaseResponse {

    //  记录id： 记录唯一标识
    @ApiModelProperty(value = "commission record ID", example = "1,auto increment")
    @ExcelIgnore
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    @JsonIgnore // 不需要
    private Long id;

    //  记录创建时间
    @ApiModelProperty(value = "createTime", example = "05/18/2023 08:30:45")
    @ExcelColumn(value ="Date",order = 0)
    private String playInfoDate;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount", example = "Amida001")
    @ExcelColumn(value ="Account",order = 1)
    private String agentAccount;

    // 代理上级代理账号：父级代理的账号
    @ApiModelProperty(value = "parentAccount", example = "Top")
    @ExcelColumn(value ="Parent",order = 2)
    private String parentAccount;

    // 本身代理等级:数据来自于代理表，共五级：1，2，3，4，5
    @ApiModelProperty(value = "agentLevel", example = "2")
    @ExcelColumn(value ="Agent Level",order = 3)
    private Integer agentLevel;

    // 投注金额：玩家投注到平台游戏的金额
    @ApiModelProperty(value = "turnover", example = "10000")
    @ExcelColumn(value ="Turnover",order = 4)
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal turnover;
    // 平台收入金额：GGR类型 计算使用'
    @ApiModelProperty(value = "income", example = "10000")
    @ExcelColumn(value ="GGR",order = 5)
    @JsonSerialize(using = BigDecimalSerializer.class)
    @JsonProperty("GGR")
    private BigDecimal GGR;
    // 玩家输赢金额
    @ApiModelProperty(value = "winOrLoss", example = "20000")
    @ExcelColumn(value ="Win/Loss",order = 6)
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal winOrLoss;
    // 玩家存款金额
    @ApiModelProperty(value = "deposit", example = "20000")
    @ExcelColumn(value ="Deposit",order = 7)
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal deposit;
    // 玩家取款金额
    @ApiModelProperty(value = "withdrawal", example = "1000")
    @ExcelColumn(value ="Withdrawal",order = 8)
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal withdrawal;


}
