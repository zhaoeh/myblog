package com.mkt.agent.common.fast.strategy;

import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import com.mkt.agent.common.fast.pojo.IncrementCheckPoint;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @description: 代理脱敏checkpoint策略
 * @author: ErHu.Zhao
 * @create: 2024-04-08
 **/
@Component
@Slf4j
public class CheckPointDesensMappingStrategy implements RemediationStrategy {

    @Override
    public String strategy() {
        return StrategyEnums.CheckPointDesensMappingStrategy.getStrategyName();
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void afterSuccess(FastContext fastContext, String callable, List<String> params) {
        log.info("afterSuccess with CheckPointDesensMappingStrategy，check point-更新代理脱敏成功");
        fastContext.getDeleteIncrementCheckPoint().apply(null, fastContext.getEvent().getEventType(), null);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void afterFailed(FastContext fastContext, String callable, List<String> params) {
        log.info("afterFailed with CheckPointDesensMappingStrategy，check point-更新代理脱敏失败");
        // 如果checkpoint补救失败，则直接清空老数据，再重新插入最新失败的数据
        fastContext.getDeleteIncrementCheckPoint().apply(null, fastContext.getEvent().getEventType(), null);
        log.info("{} 重试失败，添加到checkPoint", callable);
        List<IncrementCheckPoint> inserts = params.stream().map(agentName -> IncrementCheckPoint.builder().resourceName(agentName).
                eventType(fastContext.getEvent().getEventType()).build()).collect(Collectors.toList());
        fastContext.getInsertBatchSomeColumnWithIncrementCheckPoint().apply(inserts);
    }
}
