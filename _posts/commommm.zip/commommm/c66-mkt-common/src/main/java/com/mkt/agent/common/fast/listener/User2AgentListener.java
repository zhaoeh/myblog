package com.mkt.agent.common.fast.listener;

import com.alibaba.nacos.common.utils.CollectionUtils;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.fast.core.FastConfig;
import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.common.fast.core.FastCore;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import com.mkt.agent.common.fast.event.User2AgentEvent;
import com.mkt.agent.common.fast.remediation.DesensMappingOfAgentRemediation;
import com.mkt.agent.common.fast.remediation.TransferOfAgentRemediation;
import com.mkt.agent.common.fast.remediation.TransferOfUserRemediation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

/**
 * @description: 新增代理事件监听器
 * @author: ErHu.Zhao
 * @create: 2024-04-02
 **/
@Component
@Slf4j
public class User2AgentListener implements ApplicationListener<User2AgentEvent> {

    private static ExecutorService executorService = Executors.newSingleThreadExecutor();

    private final DesensMappingOfAgentRemediation desensMappingOfAgentRemediation;

    private final FastCore fastCore;

    private final TransferOfAgentRemediation transferOfAgentRemediation;

    private final TransferOfUserRemediation transferOfUserRemediation;

    private final FastConfig fastConfig;

    public User2AgentListener(DesensMappingOfAgentRemediation desensMappingOfAgentRemediation,
                              FastCore fastCore,
                              TransferOfAgentRemediation transferOfAgentRemediation,
                              TransferOfUserRemediation transferOfUserRemediation,
                              FastConfig fastConfig) {
        this.desensMappingOfAgentRemediation = desensMappingOfAgentRemediation;
        this.transferOfAgentRemediation = transferOfAgentRemediation;
        this.fastCore = fastCore;
        this.transferOfUserRemediation = transferOfUserRemediation;
        this.fastConfig = fastConfig;
    }

    @Override
    public void onApplicationEvent(User2AgentEvent event) {
        if (BooleanUtils.isFalse(fastConfig.getFastSwitch())) {
            log.info("fast switch is close,stop do it");
            return;
        }
        // 玩家转代理
        List<TAgentCustomers> agents = event.getAgents();
        FastContext fastContext = event.getFastContext();
        SqlSessionFactory factory = event.getFactory();
        List<TCustomerLayer> players = event.getPlayers();
        if (CollectionUtils.isEmpty(agents)) {
            return;
        }
        if (Objects.nonNull(executorService)) {
            executorService.submit(() -> triggerOnUser2Agent(fastContext, factory, agents, players));
        } else {
            triggerOnUser2Agent(fastContext, factory, agents, players);
        }
    }

    private void triggerOnUser2Agent(FastContext fastContext, SqlSessionFactory factory, List<TAgentCustomers> agents, List<TCustomerLayer> players) {
        try {
            log.info("begin triggerOnUser2Agent");
            if (CollectionUtils.isEmpty(agents)) {
                return;
            }
            desensMappingOfAgentRemediation.doDesensMappingOfAgentRemediation(fastContext, StrategyEnums.ListenerDesensMappingStrategy,
                    agents.stream().map(TAgentCustomers::getLoginName).collect(Collectors.toList()));
            if (CollectionUtils.isEmpty(players)) {
                return;
            }
            players = fastContext.getQueryPlayersByNames().apply(players.stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList()));
            List<TAgentCustomers> relationAgents = fastCore.obtainRelationAgentsFromUsers(players);
            List<String> relationAgentNames = null;
            if (CollectionUtils.isNotEmpty(relationAgents)) {
                relationAgentNames = relationAgents.stream().map(TAgentCustomers::getLoginName).collect(Collectors.toList());
            }
            boolean result = desensMappingOfAgentRemediation.doDesensMappingOfAgentRemediation(fastContext, StrategyEnums.ListenerDesensMappingStrategy, relationAgentNames);
            if (result) {
                transferOfAgentRemediation.doTransferOfAgentRemediation(fastContext, StrategyEnums.ListenerTransferOfAgentStrategy, factory, agents, null);
            }
            transferOfUserRemediation.doTransferOfUserRemediation(fastContext, StrategyEnums.ListenerTransferOfUserStrategy, factory, relationAgents, players);
            log.info("end triggerOnUser2Agent");
        } catch (Exception e) {
            log.error("triggerOnUser2Agent error.", e);
        }
    }


}
