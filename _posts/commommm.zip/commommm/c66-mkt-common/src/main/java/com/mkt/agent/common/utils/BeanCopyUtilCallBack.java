package com.mkt.agent.common.utils;

/**
 * @ClassName BeanCopyUtilCallBack
 * @Description 默认回调方法
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
public interface BeanCopyUtilCallBack<S, T> {
    void callBack(S s, T t);
}