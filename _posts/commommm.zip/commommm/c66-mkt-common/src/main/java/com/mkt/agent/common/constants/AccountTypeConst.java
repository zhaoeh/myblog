package com.mkt.agent.common.constants;

import java.util.Arrays;
import java.util.List;

/**
 * @author PTHenry_
 */
public class AccountTypeConst {

    public static final String PAY_MAYA = "PAYMAYA";
    public static final String PAY_MAYA_A = "GCASH_A";
    public static final String G_CASH = "GCASH";
    public static final String G_CASH_A = "PAYMAYA_A";
    public static final List<String> ACCOUNT_TYPE_LIST =
            Arrays.asList(
                    PAY_MAYA,
                    PAY_MAYA_A,
                    G_CASH,
                    G_CASH_A
            );
}
