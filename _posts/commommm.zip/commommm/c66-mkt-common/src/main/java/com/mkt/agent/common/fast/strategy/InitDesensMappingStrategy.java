package com.mkt.agent.common.fast.strategy;

import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.common.fast.core.FastPersist;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @description: 代理脱敏初始化策略
 * @author: ErHu.Zhao
 * @create: 2024-04-08
 **/
@Component
@Slf4j
public class InitDesensMappingStrategy implements RemediationStrategy {

    private final FastPersist fastPersist;

    public InitDesensMappingStrategy(FastPersist fastPersist) {
        this.fastPersist = fastPersist;
    }


    @Override
    public String strategy() {
        return StrategyEnums.InitDesensMappingStrategy.getStrategyName();
    }

    @Override
    public void afterSuccess(FastContext fastContext, String callable, List<String> params) {
        log.info("afterSuccess with InitDesensMappingStrategy，初始化-更新代理脱敏成功");
        // 执行成功，更新当前代理已脱敏状态
        fastPersist.batchUpdateAgentsStatus(fastContext, params, 1);
    }

    @Override
    public void afterFailed(FastContext fastContext, String callable, List<String> params) {
        log.info("afterFailed with InitDesensMappingStrategy，初始化-更新代理脱敏失败");
    }
}
