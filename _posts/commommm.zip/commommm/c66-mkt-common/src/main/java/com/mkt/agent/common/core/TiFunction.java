package com.mkt.agent.common.core;

@FunctionalInterface
public interface TiFunction<T, U, W, R> {

    R apply(T t, U u, W w);

}
