package com.mkt.agent.common.entity.api.agentapi.responses;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.entity.api.jobapi.requests.base.TaskBaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(description = "代理与佣金方案信息")
public class AgentCustomerContractQueryByPageResponse extends TaskBaseRequest<AgentCustomerContractQueryByPageResponse> {


    @ApiModelProperty(value = "customerId")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long customerId;

    @ApiModelProperty(value = "parentId")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long parentId;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount", example = "Amida001")
    private String agentAccount;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "parentAccount", example = "Amida001")
    private String parentAccount;
    // 客户类型1，玩家，3代理
    @ApiModelProperty(value = "customerType")
    private Integer customerType;

    // 代理类型：0：General Line (普通代理)，1：Professional Line(专业代理可发展下级)
    @ApiModelProperty(value = "agentType", example = "0:General line 1:Professional line")
    private Integer agentType;
    // 本身代理等级:数据来自于代理表，共五级：1，2，3，4，5
    @ApiModelProperty(value = "agentLevel", example = "the level of agent like 1,2,3,4,5")
    private Integer agentLevel;

    // 佣金方案名称
    @ApiModelProperty(value = "siteId")
    private Integer siteId;

    // 佣金方案id:佣金方案唯一标识
    @ApiModelProperty(value = "commissionPlanId", example = "id of commission plan is used to figure the only one record")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long commissionPlanId;
    // 佣金方案名称
    @ApiModelProperty(value = "commissionPlanName", example = "name of commission plan")
    private String commissionPlanName;
    // 佣金方案类型：0：turnover,1:GGR
    @ApiModelProperty(value = "commissionType", example = "0:turnover,1:GGR")
    private String commissionPlanType;
    // 结算周期：ex:10 perday,7 perday,30 perday
    @ApiModelProperty(value = "settlementPeriod", example = "7:week,10:ONE_THIRD_MONTH,30:month")
    private String settlementPeriod;
    // 佣金方案名称
    @ApiModelProperty(value = "percentageDetail", example = "[{\"rangeOfTurnoverStart\":0,\"rangeOfTurnoverEnd\":1000,\"allGamesPercentage\":null,\"bingoPercentage\":0.08,\"slotPercentage\":0.08,\"sportsPercentage\":0.08,\"pokerPercentage\":0.08,\"order\":0},{\"rangeOfTurnoverStart\":1001,\"rangeOfTurnoverEnd\":2000,\"allGamesPercentage\":null,\"bingoPercentage\":0.14,\"slotPercentage\":0.14,\"sportsPercentage\":0.14,\"pokerPercentage\":0.14,\"order\":1}]")
    private String percentageDetails;

    @ApiModelProperty(value = "settlementConditions")
    private Integer settlementConditions;

    @ApiModelProperty(value = "activeUserTurnover")
    private int activeUserTurnover;

    @ApiModelProperty(value = "activeUserHeadcount")
    private int activeUserHeadcount;

    @ApiModelProperty(value = "commissionValues")
    private String commissionValues;

    public void publicParamSet(AgentCustomerContractQueryByPageResponse paramReq) {

        super.setAgentNums(paramReq.getAgentNums());
        super.setSaveCount(paramReq.getSaveCount());
        super.setFlag(paramReq.getFlag());

        super.setStartDate(paramReq.getStartDate());
        super.setEndDate(paramReq.getEndDate());
        super.setSettleDateStart(paramReq.getSettleDateStart());
        super.setSettleDateEnd(paramReq.getSettleDateEnd());


    }

}
