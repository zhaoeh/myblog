package com.mkt.agent.common.entity.api.jobapi.requests;

import lombok.Data;

/**
 * @author Colson
 * @date 8/28/2023
 */
public class CustomerLayerTestRequest {

    private String loginName;

    private String updateBy;

    private int pageSize;

    private int pageNum;

    private int rowNum;

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getRowNum() {
        return this.rowNum = (this.pageNum-1)*this.pageSize;
    }

    public void setRowNum(int rowNum) {
        this.rowNum = rowNum;
    }
}
