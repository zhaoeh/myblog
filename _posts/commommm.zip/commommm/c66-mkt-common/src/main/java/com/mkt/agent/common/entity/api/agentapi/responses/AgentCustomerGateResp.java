package com.mkt.agent.common.entity.api.agentapi.responses;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.enums.CustomizedValidationContents;
import com.mkt.agent.common.valid.EnumValid;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class AgentCustomerGateResp  {

    @ApiModelProperty(value = "CUSTOMERS_ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long customersId; //修改

    @ApiModelProperty(value = "AGENT_LEVEL")
    private Integer agentLevel;

    @ApiModelProperty(value = "siteId 1:Bingoplus  2:Arenaplus  3:Gameplus")
    @EnumValid(contents = CustomizedValidationContents.site_id_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class,InputValidationGroup.UserToAgent.class} )
    private Integer siteId;

    @ApiModelProperty(value = "COMMISSION_PLAN_NAME")
    private String commissionPlanName;

    @ApiModelProperty(value = "COMMISSION_PLAN_TYPE")
    private String commissionPlanType;

    @ApiModelProperty(value = "COMMISSION_VALUES")
    private String commissionValues;

    @ApiModelProperty(name="SETTLEMENT_PERIOD")
    private String settlementPeriod;

    @ApiModelProperty(value = "SETTLEMENT_CONDITIONS [0,1]")
    private int settlementConditions;

    @ApiModelProperty(value = "ACTIVE_USER_TURNOVER")
    private int activeUserTurnover;

    @ApiModelProperty(value = "ACTIVE_USER_HEADCOUNT")
    private int activeUserHeadcount;

    @ApiModelProperty(value = "PERCENTAGE_DETAILS")
    private String percentageDetails;


}
