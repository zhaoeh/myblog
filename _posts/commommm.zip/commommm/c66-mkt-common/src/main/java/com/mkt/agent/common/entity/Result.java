package com.mkt.agent.common.entity;

import com.mkt.agent.common.enums.ResultEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.NamedParameterUtils;

/**
 * 请求返回消息
 */
@ApiModel
@NoArgsConstructor
@AllArgsConstructor
@Data
@Slf4j
public class Result<T> {

    @ApiModelProperty(value = "是否成功")
    private Boolean success;
    @ApiModelProperty(value = "编码")
    private Integer code;
    @ApiModelProperty(value = "提示信息")
    private String message;
    @ApiModelProperty(value = "数据")
    private T data;

    public boolean isSuccess(){
        return success != null && success;
    }

    public static <T> Result success(Integer code, String message, T data) {
//        log.info("Restful Request success, code:{}, message:{}, data:{}", code, message, data);
        return new Result(ResultEnum.SUCCESS.getSuccess(), code, message, data);
    }
    public static <T> Result success(Integer code, String message) {
        return success(code,message,null);
    }


    public static <T> Result success(T data) {
        return success(ResultEnum.SUCCESS.getCode(), ResultEnum.SUCCESS.getMessage(), data);
    }

    public static Result success() {
        return success(null);
    }

    private static <T> Result fail(Integer code, String message, T data) {
        log.error("Restful Request fail, code:{}, message:{}, data:{}", code, message, data);
        return new Result(ResultEnum.FAIL.getSuccess(), code, message, data);
    }

    public static <T> Result fail(String message) {
        return fail(ResultEnum.FAIL.getCode(),message,null);
    }

    public static <T> Result fail(T data) {
        return fail(ResultEnum.FAIL.getCode(), ResultEnum.FAIL.getMessage(), data);
    }

    public static <T> Result fail(Integer code,String message) {
        return fail(code,message,null);
    }

    public static Result fail() {
        return fail(null);
    }


}
