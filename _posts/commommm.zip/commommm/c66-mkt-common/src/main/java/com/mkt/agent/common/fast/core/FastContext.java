package com.mkt.agent.common.fast.core;

import com.mkt.agent.common.core.TiFunction;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.fast.enums.CheckPointTypeEnums;
import com.mkt.agent.common.fast.pojo.*;
import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-04-04
 **/
@Data
@Builder
public class FastContext {

    private Supplier<Integer> queryNotTransferPlayersCountWithJoin;

    private Function<List<String>, List<AgentCustomersMapping>> queryAgentsMapping;

    private Function<List<String>, List<AgentCustomersMapping>> queryAgentsMappingOfLarge;

    private Function<List<String>, List<SimpleCustomers>> selectSuperAgentsByNames;

    private BiFunction<Integer, Integer, List<TCustomerLayer>> queryNotTransferPlayersWithLimit;

    private Function<List<String>, List<TCustomerLayer>> queryNotTransferPlayersWithJoin;

    private Function<List<AgentCustomersMapping>, Integer> insertBatchSomeColumnWithAgentCustomersMapping;

    private Function<List<IncrementCheckPoint>, Integer> insertBatchSomeColumnWithIncrementCheckPoint;

    private BiFunction<List<String>, Integer, Integer> updateAgentsStatus;

    private TiFunction<List<String>, Integer, Integer, Integer> deleteIncrementCheckPoint;

    private Function<List<String>, List<SimpleCustomers>> selectSuperAgentsByNamesOfLarge;

    private BiFunction<List<String>, Integer, List<SimpleCustomers>> selectSimpleCustomers;

    private Function<IncrementCheckPoint, List<SimpleCustomers>> selectAgentWithCheckPoint;

    private Function<IncrementCheckPoint, List<IncrementCheckPoint>> selectTargetCheckPoints;

    private Function<IncrementCheckPoint, Integer> selectTargetCheckPointsOfCount;

    private BiFunction<Integer, List<String>, List<DailyMktUserMapping>> queryUserMappingByNames;

    private Function<Integer, List<Map<String, String>>> queryUsersCountForAgent;

    private Function<List<String>, List<TCustomerLayer>> queryPlayersByNames;

    private BiFunction<List<String>, Integer, Integer> updateUsersStatus;

    private Function<FastQueryModel, Integer> queryAgentsCount;

    private Function<FastQueryModel, Integer> queryAgentsCountDone;

    private Function<FastQueryModel, Integer> queryPlayersCount;

    private Function<FastQueryModel, Integer> queryUserMappingCount;

    private Runnable clearAgentsMapping;

    private Runnable clearUsersMapping;

    private String fastAgentMapperStatement;

    private String fastAgentMappingMapperStatement;

    private CheckPointTypeEnums event;

    private boolean printResult;

    private boolean reRun;
}
