package com.mkt.agent.common.entity.api.jobapi.table;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.entity.BaseEntity;
import lombok.Data;

import java.time.LocalDate;

//@Repository
@Data
@TableName("t_task_info")
public class TaskInfo extends BaseEntity {

    @TableId
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long id;

    @TableField("task_group")
    private String taskGroup;

    @TableField("task_type")
    private Integer taskType;

    @TableField("task_name")
    private String taskName;

    @TableField("task_date")
    private LocalDate taskDate;

    @TableField("cron_express")
    private String cronExpress;

    @TableField("status")
    private Integer status;

    @TableField("exception")
    private String exception;

    @TableField("remark")
    private String remark;


    @TableField(exist = false)
    private boolean successFlag;

}
