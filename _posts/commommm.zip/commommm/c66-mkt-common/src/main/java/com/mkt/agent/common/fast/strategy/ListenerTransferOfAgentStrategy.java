package com.mkt.agent.common.fast.strategy;

import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.common.fast.core.FastPersist;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import com.mkt.agent.common.fast.pojo.IncrementCheckPoint;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-04-08
 **/
@Component
@Slf4j
public class ListenerTransferOfAgentStrategy implements RemediationStrategy {
    private final FastPersist fastPersist;

    public ListenerTransferOfAgentStrategy(FastPersist fastPersist) {
        this.fastPersist = fastPersist;
    }

    @Override
    public String strategy() {
        return StrategyEnums.ListenerTransferOfAgentStrategy.getStrategyName();
    }

    @Override
    public void afterSuccess(FastContext fastContext, String callable, List<String> params) {
        log.info("afterSuccess with ListenerTransferOfAgentStrategy，监听器-代理维度更新玩家转移成功");
    }

    @Override
    public void afterFailed(FastContext fastContext, String callable, List<String> params) {
        log.info("afterFailed with ListenerTransferOfAgentStrategy，监听器-代理维度更新玩家转移失败");
//        log.info("{} 重试失败，添加到checkPoint", callable);
        List<IncrementCheckPoint> inserts = params.stream().map(agentName -> IncrementCheckPoint.builder().resourceName(agentName).
                eventType(fastContext.getEvent().getEventType()).build()).collect(Collectors.toList());
        fastContext.getInsertBatchSomeColumnWithIncrementCheckPoint().apply(inserts);
    }


}
