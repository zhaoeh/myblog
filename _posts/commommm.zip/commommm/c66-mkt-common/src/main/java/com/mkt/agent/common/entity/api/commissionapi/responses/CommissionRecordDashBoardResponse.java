package com.mkt.agent.common.entity.api.commissionapi.responses;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverDistriResp;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverTopResp;
import com.mkt.agent.common.jackson.serializer.BigDecimalSerializer;
import com.mkt.agent.common.utils.SerializationUti;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.ibatis.type.JdbcType;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @Description TODO
 * @Classname CommissionRecordDashBoardResponse
 * @Date 2023/10/24 14:49
 * @Created by TJSLucian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "仪表盘历史数据展示表-1")
@TableName("t_agent_dashboard")
@Builder
public class CommissionRecordDashBoardResponse {

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty(value = "用户名",hidden = true, example = "Lucian")
    private String loginName;

    @ApiModelProperty(value = "父类用户名",hidden = true, example = "Lucian")
    private String parentLoginName;

    @ApiModelProperty(value = "选中时间内的计算佣金", example = "1000.00")
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "0.00")
    @JsonSerialize(using = BigDecimalSerializer.class)
    @TableField(jdbcType = JdbcType.DECIMAL)
    private BigDecimal commissionAmount = BigDecimal.ZERO.setScale(2);

    @ApiModelProperty(value = "注册人数", example = "20")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long registrationNumber = 0L;

    @ApiModelProperty(value = "首存人数", example = "20")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long firstDepositPlayers = 0L;

    @ApiModelProperty(value = "投注人数", example = "20")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long betPlayers = 0L;

    @ApiModelProperty(value = "选中时间内的投注额", example = "1000.00")
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "0.00")
    @JsonSerialize(using = BigDecimalSerializer.class)
    @TableField(jdbcType = JdbcType.DECIMAL)
    private BigDecimal turnover = BigDecimal.ZERO.setScale(2);

    @ApiModelProperty(value = "选中时间内的GGR金额", example = "1000.00")
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "0.00")
    @JsonSerialize(using = BigDecimalSerializer.class)
    @TableField(jdbcType = JdbcType.DECIMAL)
    private BigDecimal ggr = BigDecimal.ZERO.setScale(2);

    @ApiModelProperty(value = "选中时间内的winorloss金额,暂时不统计该字段",hidden = true, example = "1000.00")
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "0.00")
    @JsonSerialize(using = BigDecimalSerializer.class)
    @TableField(jdbcType = JdbcType.DECIMAL)
    private BigDecimal winorloss = BigDecimal.ZERO.setScale(2);

    @ApiModelProperty(value = "选中时间内的首存金额", example = "1000.00")
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "0.00")
    @JsonSerialize(using = BigDecimalSerializer.class)
    @TableField(jdbcType = JdbcType.DECIMAL)
    private BigDecimal firstDepositAmount = BigDecimal.ZERO.setScale(2);

    @ApiModelProperty(value = "选中时间内的存款", example = "1000.00")
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "0.00")
    @JsonSerialize(using = BigDecimalSerializer.class)
    @TableField(jdbcType = JdbcType.DECIMAL)
    private BigDecimal deposit = BigDecimal.ZERO.setScale(2);

    @ApiModelProperty(value = "选中时间内的取款", example = "1000.00")
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "0.00")
    @JsonSerialize(using = BigDecimalSerializer.class)
    @TableField(jdbcType = JdbcType.DECIMAL)
    private BigDecimal withdraw = BigDecimal.ZERO.setScale(2);

    @ApiModelProperty(value = "选中的时间开始日期,冗余字段,前端暂时不需要", hidden = true, example = "2023-10-30")
    private String recordDateStart;
    @ApiModelProperty(value = "选中的时间结束日期", hidden = true, example = "2023-10-30")
    private String recordDateEnd;

}

