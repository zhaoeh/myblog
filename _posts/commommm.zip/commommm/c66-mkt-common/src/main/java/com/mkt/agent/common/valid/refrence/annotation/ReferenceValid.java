package com.mkt.agent.common.valid.refrence.annotation;

import java.lang.annotation.*;

/**
 * @description: 多字段依赖校验
 * @author: ErHu.Zhao
 * @create: 2024-01-25
 **/
@Target({ElementType.TYPE, ElementType.FIELD, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
public @interface ReferenceValid {

    /**
     * 校验值范围
     *
     * @return
     */
    ReferenceHolder[] holders() default {};

}
