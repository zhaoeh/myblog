package com.mkt.agent.common.sql;

import com.mkt.agent.common.enums.SensitiveFields;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.logging.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

/**
 * @description: sql日志脱敏打印器
 * @author: ErHu.Zhao
 * @create: 2024-04-26
 **/
public class LogOfSqlImpl implements Log {

    private static Logger log = LoggerFactory.getLogger(LogOfSqlImpl.class);

    public LogOfSqlImpl(String clazz) {
    }

    public static void setLogger(Logger log) {
        if (Objects.nonNull(log)) {
            LogOfSqlImpl.log = log;
        }
    }

    public static void setLogger(String name) {
        if (StringUtils.isNotBlank(name)) {
            LogOfSqlImpl.log = LoggerFactory.getLogger(name);
        }
    }

    public static void setLogger(Class<?> clazz) {
        if (Objects.nonNull(clazz)) {
            LogOfSqlImpl.log = LoggerFactory.getLogger(clazz);
        }
    }

    @Override
    public boolean isDebugEnabled() {
        return log.isDebugEnabled();
    }

    @Override
    public boolean isTraceEnabled() {
        return log.isTraceEnabled();
    }

    @Override
    public void error(String s, Throwable e) {
        log.error(s);
        e.printStackTrace(System.err);
    }

    @Override
    public void error(String s) {
        log.error(s);
    }

    @Override
    public void debug(String s) {
        if (isContainSensitiveFields(s)) {
            return;
        }
        log.debug(s);
    }

    @Override
    public void trace(String s) {
        log.trace(s);
    }

    @Override
    public void warn(String s) {
        log.warn(s);
    }

    /**
     * 判断源字符串是否包含指定的敏感字段
     *
     * @param s
     * @return
     */
    private boolean isContainSensitiveFields(String s) {
        if (StringUtils.isNotBlank(s) && containSensitiveFields(s)) {
            return true;
        }
        return false;
    }

    private boolean containSensitiveFields(String s) {
        for (SensitiveFields enumValue : SensitiveFields.values()) {
            if (s.indexOf(enumValue.getName()) > 0) {
                return true;
            }
        }
        return false;
    }
}
