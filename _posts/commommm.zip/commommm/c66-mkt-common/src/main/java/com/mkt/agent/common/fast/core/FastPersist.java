package com.mkt.agent.common.fast.core;

import com.alibaba.nacos.common.utils.CollectionUtils;
import com.mkt.agent.common.fast.pojo.AgentCustomersMapping;
import com.mkt.agent.common.fast.pojo.IncrementCheckPoint;
import com.mkt.agent.common.fast.pojo.SimpleCustomers;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-04-01
 **/
@Component
@Slf4j
public class FastPersist {

    @Autowired
    private MappingHelper mappingHelper;


    /**
     * 批量插入代理脱敏映射
     *
     * @param mapping
     */
    @Transactional(rollbackFor = Exception.class)
    public int batchInsertAgentMapping(FastContext fastContext, List<AgentCustomersMapping> mapping) {
        if (CollectionUtils.isEmpty(mapping)) {
            return 0;
        }
        return fastContext.getInsertBatchSomeColumnWithAgentCustomersMapping().apply(mapping);
    }

    /**
     * 更新代理脱敏状态
     *
     * @param fastContext
     * @param agents
     * @param status
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public int batchUpdateAgentsStatus(FastContext fastContext, List<String> agents, Integer status) {
        if (CollectionUtils.isEmpty(agents)) {
            return 0;
        }
        return fastContext.getUpdateAgentsStatus().apply(agents, status);
    }

    /**
     * 更新玩家映射状态
     *
     * @param currentUsers
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public int batchUpdateUsersStatus(FastContext fastContext, List<String> currentUsers, Integer status) {
        if (CollectionUtils.isEmpty(currentUsers)) {
            return 0;
        }
        return fastContext.getUpdateUsersStatus().apply(currentUsers, status);
    }

    /**
     * 批量插入checkpoint表
     *
     * @param checkPoints
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public int batchInsertCheckPoints(FastContext fastContext, List<IncrementCheckPoint> checkPoints) {
        if (CollectionUtils.isEmpty(checkPoints)) {
            return 0;
        }
        return fastContext.getInsertBatchSomeColumnWithIncrementCheckPoint().apply(checkPoints);
    }


    /**
     * 根据条件删除checkpoint数据
     *
     * @param resourceNames
     * @param eventType
     * @param checkPointStep
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public int batchDeleteCheckPoints(FastContext fastContext, List<String> resourceNames, Integer eventType, Integer checkPointStep) {
        if (CollectionUtils.isEmpty(resourceNames)) {
            return 0;
        }
        return fastContext.getDeleteIncrementCheckPoint().apply(resourceNames, eventType, checkPointStep);
    }

    /**
     * 查询当前批次代理集已经脱敏映射的集合
     *
     * @param mapping
     * @return
     */
    public Map<String, List<AgentCustomersMapping>> queryAgentsMappingGroup(FastContext fastContext, List<AgentCustomersMapping> mapping) {
        if (CollectionUtils.isEmpty(mapping)) {
            return Collections.emptyMap();
        }
        List<String> params = mapping.stream().map(AgentCustomersMapping::getAgentName).collect(Collectors.toList());
        List<AgentCustomersMapping> agentCustomersMappings = mappingHelper.queryAgentsMapping(fastContext, params);
        if (CollectionUtils.isEmpty(agentCustomersMappings)) {
            return Collections.emptyMap();
        }
        return agentCustomersMappings.stream().collect(Collectors.groupingBy(AgentCustomersMapping::getAgentName));
    }

    /**
     * 根据条件查询代理映射集合
     *
     * @param params
     * @return
     */
    public List<AgentCustomersMapping> queryAgentsMappingList(FastContext fastContext, List<String> params) {
        return mappingHelper.queryAgentsMapping(fastContext, params);
    }

    /**
     * 根据条件查询代理上级代理链
     *
     * @param params
     * @return
     */
    public List<SimpleCustomers> querySuperAgentsByNames(FastContext fastContext, List<String> params) {
        return mappingHelper.querySuperAgentsByNames(fastContext, params);
    }


}
