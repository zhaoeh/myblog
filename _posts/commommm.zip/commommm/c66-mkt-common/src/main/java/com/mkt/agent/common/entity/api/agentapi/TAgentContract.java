package com.mkt.agent.common.entity.api.agentapi;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.mkt.agent.common.entity.BaseOperationEntity;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.List;

/**
 * @ClassName TAgentContract
 * @Description 佣金方案
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Table(name="佣金方案表 ")
@TableName("t_agent_contract")
@NoArgsConstructor
@Data
public class TAgentContract extends BaseOperationEntity {

    /*
        佣金方案类型
    */
    @Column(name="COMMISSION_PLAN_NAME",nullable = false)
    private String commissionPlanName;

    /*
        佣金方案类型
        0:turnover, 1:GGR
   */
    @Column(name="COMMISSION_PLAN_TYPE",nullable = false)
    private String commissionPlanType;

    /*
        结算周期
        MONTH,ONE-THIRD_MONTH,WEEK,DAY
    */

    @Column(name="SETTLEMENT_PERIOD",nullable = false)
    private String settlementPeriod;

    /*
        结算条件
        0,1
   */
    @Column(name="SETTLEMENT_CONDITIONS",nullable = false)
    private int settlementConditions;

    /*
        活跃用户投注额
        SETTLEMENT_PERIOD 为1时必填,支持小数
    */
    @Column(name="ACTIVE_USER_TURNOVER")
    private int activeUserTurnover;


    @Column(name="ACTIVE_USER_TURNOVER1")
    private BigDecimal activeUserTurnover1;

    /*
        活跃用户数量
        SETTLEMENT_PERIOD 为1时必填,整数
    */
    @Column(name="ACTIVE_USER_HEADCOUNT")
    private int activeUserHeadcount;

    /*
        结算类型
        ALL_GAME_TYPES,BY_GAME_TYPE
    */
    @Column(name="COMMISSION_VALUES",nullable = false)
    private String commissionValues;

    /*
     ALL_GAME_TYPES:[{'Range_Turnover_Start':'0','Range_Turnover_END':'1000','Percentage':'1%','order':0}.{'Range_Turnover_Start':'1001','Range_Turnover_END':'5000','Percentage':'3%','order':1}….]
     BY_GAME_TYPE:[{'Range_Turnover_Start':'0','Range_Turnover_END':'1000','GAME1':'0.2%','GAME2':'0.2%'....,'order':0}.{'Range_Turnover_Start':'1001','Range_Turnover_END':'5000','GAME1':'0.5%','GAME2':'0.5%'....,'order':1}….]
    */

    /*
        计划内容
    */
    @Column(name="PERCENTAGE_DETAILS",nullable = false)
    private String percentageDetails;

    //结算比例
    @TableField(exist = false)
    private List<SettlementPercentageReq> settlementPercentageList;

    /*
        被代理聚合
    */
    @Column(name="AGENT_COUNT",nullable = false)
    private int agentCount = 0;

    @Column(name="is_fd",nullable = false)
    private String   isFd ;

    @Column(name="fd_count",nullable = false)
    private int fdCount ;

    @Column(name="fd_commission",nullable = false)
    private BigDecimal fdCommission;



    @Column(name="active_user_commission",nullable = false)
    private BigDecimal activeUserCommission;



    @Override
    public String toString() {
        return "CommissionPlanPO{" +
                "id=" + id +
                ", commissionPlanName='" + commissionPlanName + '\'' +
                ", commissionPlanType='" + commissionPlanType + '\'' +
                ", settlementPeriod='" + settlementPeriod + '\'' +
                ", settlementConditions=" + settlementConditions +
                ", activeUserTurnover=" + activeUserTurnover +
                ", activeUserHeadcount=" + activeUserHeadcount +
                ", commissionValues='" + commissionValues + '\'' +
                ", percentagedetails='" + percentageDetails + '\'' +
                ", agentCount=" + agentCount +
                ", createdBy='" + super.createBy + '\'' +
                ", isDeleted=" + isDeleted +
                ", createTime=" + createTime +
                ", updatedBy='" + super.updateBy + '\'' +
                ", updateTime=" + updateTime +
                '}';
    }
}
