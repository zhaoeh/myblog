package com.mkt.agent.common.player.processor;

import com.google.common.collect.Lists;
import com.mkt.agent.common.config.DashBoardConfig;
import com.mkt.agent.common.config.PlayerReportConfig;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.BatchRecord;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonth;
import com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonthVo1;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.player.core.PlayerReportByMonthPersist;
import com.mkt.agent.common.player.model.PlayerReportByMonthMapperHolder;
import com.mkt.agent.common.player.model.PlayerReportByMonthProcessorModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * @Description TODO
 * @Classname AgentTransByMonthProcessor
 * @Date 2024/3/13 15:32
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class AgentTransByMonthProcessor {

//    @Value("${playerReport.asyncLimit:50000}")
    private Integer asyncLimit = 2000;

    @Value("${playerReport.threadPoolSize:5}")
    private Integer threadPoolSize;

    private static ExecutorService executorService;

    private final PlayerReportConfig config;

    private final PlayerReportByMonthPersist playerReportByMonthPersist;

    public AgentTransByMonthProcessor(PlayerReportConfig config,PlayerReportByMonthPersist playerReportByMonthPersist) {
        this.config = config;
        this.playerReportByMonthPersist = playerReportByMonthPersist;
    }

    @PostConstruct
    public void initTheadPool() {
        log.info("begin to init thread pool of AgentTransByMonthProcessor");
        executorService = Executors.newFixedThreadPool(this.threadPoolSize);
        log.info("end to init thread pool of AgentTransByMonthProcessor, threadPoolSize is {}", this.threadPoolSize);
    }

    /**
     * description: 封装参数 提交任务
     * @param:  [agentList, model]
     * @return: int
     * @Date: 2024/4/1 14:11
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public void preSubmitTaskByMonth(List<TAgentCustomers> agentList, PlayerReportByMonthProcessorModel model){

        if(Objects.isNull(model) || CollectionUtils.isEmpty(agentList)){
            return;
        }

        List<List<TAgentCustomers>> partAgentList;

        if(agentList.size() > asyncLimit){
            partAgentList = Lists.partition(agentList,asyncLimit);
        }else {
            partAgentList = List.of(agentList);
        }

        //封装条件 提交任务
        List<Future<ClDashBoardCreateQueryReq>> futureList = partAgentList.stream().map(p -> submitTaskForPlayerByMonth(buildQueryReq(p,model),model)).filter(Objects::nonNull).collect(Collectors.toList());

        //统计失败的任务 进行重试
        doAsyncQueryWithRetry(getResultFromFuture(futureList),model);

        log.info("Finished to submit tasks for level:{} and month:{}",model.getLevel(),model.getMonth());
    }


    /**
     * description: 提交player report任务到线程池
     * @param:  [countGroupMonthVo1, queryCKCountByMonthMapper]
     * @return: java.util.concurrent.Future<com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonthVo1>
     * @Date: 2024/3/19 11:26
     * @Version: 1.0.0
     * @Author: Lucian
     */
    private Future<ClDashBoardCreateQueryReq> submitTaskForPlayerByMonth(ClDashBoardCreateQueryReq queryReq, PlayerReportByMonthProcessorModel model){
        if(Objects.isNull(queryReq) || CollectionUtils.isEmpty(queryReq.getAgentAccountList())){
            return null;
        }

        Function<ClDashBoardCreateQueryReq,List<TAgentCountGroupMonth>> queryDirectCountByMonthMapper = model.getHolder().getQueryDirectCountByMonthMapper();
        Function<ClDashBoardCreateQueryReq,List<TAgentCountGroupMonth>> querySelfCountByMonthMapper = model.getHolder().getQuerySelfCountByMonthMapper();
        Function<ClDashBoardCreateQueryReq,List<TAgentCountGroupMonth>> downlineAgentCountMapper = model.getHolder().getDownlineAgentCountMapper();

        log.info("Begin to add task for level:{} and month:{}",model.getLevel(),model.getMonth());
        Future<ClDashBoardCreateQueryReq> futureRecord = executorService.submit(() -> {
            try {

                List<TAgentCountGroupMonth> agentCountGroupMonthList = new ArrayList<>();
                //直属用户数据 directCount totalCount
                List<TAgentCountGroupMonth> directRes = playerReportByMonthPersist.queryDirectCountFromCH(queryReq,queryDirectCountByMonthMapper);

                if(!CollectionUtils.isEmpty(directRes)){
                    agentCountGroupMonthList.addAll(directRes);
                }
                //自身数据 selfCount
                List<TAgentCountGroupMonth> selfRes = playerReportByMonthPersist.querySelfCountFromCH(queryReq,querySelfCountByMonthMapper);
                if(!CollectionUtils.isEmpty(selfRes)){
                    agentCountGroupMonthList.addAll(selfRes);
                }

                List<TAgentCountGroupMonth> downlineRes = null;

                //下级代理数据 totalCount
                if(model.getLevel() != Constants.DASH_BOARD_DATA_START_LEVEL){
                    downlineRes = downlineAgentCountMapper.apply(queryReq);
                }

                if(!CollectionUtils.isEmpty(downlineRes)){
                    agentCountGroupMonthList.addAll(downlineRes);
                }

                if(!CollectionUtils.isEmpty(agentCountGroupMonthList)){
                    Map<String,TAgentCustomers> agentMap = queryReq.getAgentCustomersList().stream().collect(Collectors.toMap(TAgentCustomers::getLoginName,t -> t));
                    log.info("[submitTaskForPlayerByMonth]The month is:{}, the level is:{}",model.getMonth(),model.getLevel());
                    List<TAgentCountGroupMonth> response = agentCountGroupMonthList.stream().collect(Collectors.groupingBy(TAgentCountGroupMonth::getAgentName)).values().stream()
                            .map(pList -> pList.stream().reduce((r1,r2) -> {
                                r1.setTotalCount(r1.getTotalCount() + r2.getTotalCount());
                                r1.setDirectCount(r1.getDirectCount() + r2.getDirectCount());
                                r1.setSelfCount(r1.getSelfCount() + r2.getSelfCount());
                                log.info("[submitTaskForPlayerByMonth]The agent is:{},the month is:{}, the level is:{}",r1.getAgentName(),r1.getAgentMonth(),r1.getAgentLevel());
                                return r1;
                            }).orElse(null)).map(b -> handleInfoForData(b,model,agentMap.get(b.getAgentName()))).filter(Objects::nonNull).collect(Collectors.toList());

                    playerReportByMonthPersist.refreshAgentGroupCountByMonth(model,queryReq.getAgentAccountList(),response);
                }
                return null;

            } catch (Exception failedE) {
                log.error("Failed to submit task:{}",queryReq,failedE);
            }
            return queryReq;
        });

        return futureRecord;
    }


    private void doAsyncQueryWithRetry(List<ClDashBoardCreateQueryReq> failedQueryReqList, PlayerReportByMonthProcessorModel model){
        if(!CollectionUtils.isEmpty(failedQueryReqList)){
            return;
        }

        for(int i=0; i < config.getRetryTimeWithFailedTask(); i++){

            //提交任务
            List<Future<ClDashBoardCreateQueryReq>> futureList = failedQueryReqList.stream().map(f -> submitTaskForPlayerByMonth(f,model)).collect(Collectors.toList());

            //获取任务结果
            List<ClDashBoardCreateQueryReq> failedAfterRetryList = getResultFromFuture(futureList);

            if(CollectionUtils.isEmpty(failedAfterRetryList)){
                return;
            }

            failedQueryReqList = failedAfterRetryList;

            if(i > 1){
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    log.error("InterruptedException!",e);
                    Thread.currentThread().interrupt();
                }catch (Exception ignoredSleep){
                    log.error("Failed to make thread sleep while retrying async query. Now pass it and keep on querying!",ignoredSleep);
                }

            }

        }
    }

    /**
     * description: 从线程池返回对象中获取任务结果
     * @param:  [futureList]
     * @return: java.util.List<com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq>
     * @Date: 2024/4/1 16:11
     * @Version: 1.0.0
     * @Author: Lucian
     */
    private List<ClDashBoardCreateQueryReq> getResultFromFuture(List<Future<ClDashBoardCreateQueryReq>> futureList){
        if(CollectionUtils.isEmpty(futureList)){
            return null;
        }
        List<ClDashBoardCreateQueryReq> resultList = futureList.stream().map(f -> {
            try {
                return f.get();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
            return null;
        }).filter(Objects::nonNull).collect(Collectors.toList());

        return resultList;
    }

    public ClDashBoardCreateQueryReq buildQueryReq(List<TAgentCustomers> partList,PlayerReportByMonthProcessorModel model){
        List<String> pName = partList.stream().map(m -> m.getLoginName()).collect(Collectors.toList());
        return ClDashBoardCreateQueryReq.builder().agentCustomersList(partList).agentAccountList(pName).recordDateStart(model.getStartDate()).recordDateEnd(model.getEndDate())
                .agentMonth(model.getMonth()).build();
    }


    private TAgentCountGroupMonth handleInfoForData(TAgentCountGroupMonth data, PlayerReportByMonthProcessorModel model, TAgentCustomers agent){

        if(Objects.isNull(data)){
            return null;
        }

        data.setAgentMonth(model.getMonth());
        data.setAgentLevel(model.getLevel());
        data.setParentAgentName(agent.getParentName());
        data.setIsEnable(agent.getIsEnable());
        data.setIsDeleted(agent.getIsDeleted());

        return data;
    }

}
