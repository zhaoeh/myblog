package com.mkt.agent.common.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * 公共配置类
 *
 * @program: riskcontrol-common
 * @description: riskcontrol-common模块-公共配置类--
 * @author: Erhu.Zhao
 * @create: 2023-10-18 15:28
 **/
@Configuration
@ComponentScan(basePackages = {"com.mkt.agent.common"})
public class CommonConfig {
}
