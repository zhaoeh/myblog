package com.mkt.agent.common.entity.api.reportapi;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections.CollectionUtils;

import javax.persistence.Transient;
import java.util.List;

/**
 * @Description TODO
 * @Classname TAgentCountGroupMonth
 * @Date 2024/2/5 15:01
 * @Created by TJSLucian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TAgentCountGroupMonth implements Comparable<TAgentCountGroupMonth>{

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    private String agentName;

    private String agentMonth;

    private Integer agentLevel;

    private Integer directCount = 0;

    private Integer totalCount = 0;

    private Integer selfCount = 0;

    private String parentAgentName;

    private Integer isDeleted;

    private Integer isEnable;

    @Transient
    @TableField(exist = false)
    private List<String> neededDeleteAgents;

    private void clear(){
        if(!CollectionUtils.isEmpty(neededDeleteAgents)){
            neededDeleteAgents = null;
        }
    }


    @Override
    public int compareTo(TAgentCountGroupMonth o) {
        return o.getAgentMonth().compareTo(this.agentMonth);
    }
}
