package com.mkt.agent.common.annotation;


import com.mkt.agent.common.enums.CommissionValuesEnum;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @Author TJSAustin
 */
@Target({ ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
public @interface GameTypeColumn {
    /** 列名称 */
    CommissionValuesEnum value() default CommissionValuesEnum.ALL_GAME_TYPES;

}
