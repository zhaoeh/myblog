package com.mkt.agent.common.fast.enums;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-04-02
 **/
public enum CheckPointTypeEnums {
    // 代理脱敏补救check point
    DesensMappingOfAgent(1, "DesensMappingOfAgent"),
    // 代理状态维度补救代理关系check point
    TransferStatusOfAgent(2, "TransferStatusOfAgent"),
    // 代理上级链路维度补救代理关系check point
    TransferChainsOfAgent(3, "TransferStatusOfAgent"),
    // 玩家维度补救代理关系check point
    TransferOfUser(4, "TransferOfUser"),
    CreateAgentEvent(1, "CreateAgentEvent"),
    DeleteAgentEvent(2, "DeleteAgentEvent"),
    UpdateAgentEvent(3, "UpdateAgentEvent"),
    UpdateUserByAgentEvent(4, "UpdateUserByAgentEvent"),
    UpdateUserByPlayerEvent(5, "UpdateUserByPlayerEvent");

    int eventType;
    String desc;

    CheckPointTypeEnums(int eventType, String desc) {
        this.eventType = eventType;
        this.desc = desc;
    }

    public int getEventType() {
        return eventType;
    }

    public String getDesc() {
        return desc;
    }
}
