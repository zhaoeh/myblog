package com.mkt.agent.common.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Objects;

@Data
public class PageRequest {


    @ApiModelProperty(value = "size", example = "5")
    private Long size = 10l;

    @ApiModelProperty(value = "current", example = "1")
    private Long current = 1l;

    @ApiModelProperty(hidden = true)
    private Long offset = (current - 1) * size;


    public void setPageParams(Long current, Long size) {
        // 默认分页设置
        if (Objects.isNull(this.getCurrent())) {
            this.setCurrent(1l);
        }
        if (Objects.isNull(this.getSize())) {
            this.setSize(10l);
        }
        this.setOffset((this.getCurrent() - 1) * this.getSize());
    }

}
