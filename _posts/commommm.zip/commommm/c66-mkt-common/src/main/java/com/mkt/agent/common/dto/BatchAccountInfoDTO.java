package com.mkt.agent.common.dto;

import lombok.Data;

/**
 * @ClassName BatchAccountInfoDTO
 * @Description 批量申请的账号信息详情，包括对应的部分客户信息
 * @Author Dingping.Qin
 * @Date 2024/4/4 16:56
 * @Version 1.0
 **/
@Data
public class BatchAccountInfoDTO {

    /* 批量申请记录id */
    private Long batchId;

    /* 平台id */
    private Integer siteId;

    /* 客户编号 */
    private Long customersId;

    /* 登录名 */
    private String loginName;

    /* 产品 */
    private String productId;

}
