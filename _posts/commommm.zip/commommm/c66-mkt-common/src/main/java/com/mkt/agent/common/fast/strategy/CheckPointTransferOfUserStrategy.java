package com.mkt.agent.common.fast.strategy;

import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import com.mkt.agent.common.fast.pojo.IncrementCheckPoint;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @description: 玩家-代理-关系 玩家维度 checkpoint策略
 * @author: ErHu.Zhao
 * @create: 2024-04-08
 **/
@Component
@Slf4j
public class CheckPointTransferOfUserStrategy implements RemediationStrategy {
    @Override
    public String strategy() {
        return StrategyEnums.CheckPointTransferOfUserStrategy.getStrategyName();
    }

    @Override
    public void afterSuccess(FastContext fastContext, String callable, List<String> params) {
        log.info("afterSuccess with CheckPointTransferOfUserStrategy，check point-玩家维度更新玩家转移成功");
        fastContext.getDeleteIncrementCheckPoint().apply(null, fastContext.getEvent().getEventType(), null);
    }

    @Override
    public void afterFailed(FastContext fastContext, String callable, List<String> params) {
        log.info("afterFailed with CheckPointTransferOfUserStrategy，check point-玩家维度更新玩家转移失败");
        // 如果checkpoint补救失败，则直接清空老数据，再重新插入最新失败的数据
        fastContext.getDeleteIncrementCheckPoint().apply(null, fastContext.getEvent().getEventType(), null);
        log.info("{} 重试失败，添加到checkPoint", callable);
        List<IncrementCheckPoint> inserts = params.stream().map(agentName -> IncrementCheckPoint.builder().resourceName(agentName).
                eventType(fastContext.getEvent().getEventType()).build()).collect(Collectors.toList());
        fastContext.getInsertBatchSomeColumnWithIncrementCheckPoint().apply(inserts);
    }
}
