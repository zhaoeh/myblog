package com.mkt.agent.common.entity.api.userapi.requests;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @ClassName TAgentCustomersReq
 * @Author TJSAustin
 * @Date 2023/6/6 10:00
 * @Version 1.0
 **/
@Data
@NoArgsConstructor
public class PlayerCustomersBatchReq {

    /**
     * 批量创建个数
     */
    @ApiModelProperty(value = "批量创建个数")
    @NotNull(message = "account number can not be empty")
    private Integer accountNumber;

    @ApiModelProperty(value = "批量创建代理的前缀", example = "gto")
//    @NotNull(message = "prefix can not be empty")
    private String prefix;

    /**
     * 产品
     */
    @ApiModelProperty(value = "所属产品")
    @NotBlank(message = "productId id can not be empty")
    private String productId;

    /**
     * 父级代理
     */
    @ApiModelProperty(value = "父级代理")
    @NotNull(message = "parent Id can not be empty")
    private Long parentId;

    /**
     * 创建人
     */
    @ApiModelProperty(value = "创建人")
    @NotNull(message = "createdBy can not be empty")
    private String createdBy;

    /**
     * ip
     */
    @ApiModelProperty(value = "创建人")
    @NotNull(message = "ip can not be empty")
    private String ip;

    @Override
    public String toString() {
        return "PlayerCustomersBatchReq{" +
                "accountNumber=" + accountNumber +
                ", productId='" + productId + '\'' +
                ", parentId=" + parentId +
                ", createdBy='" + createdBy + '\'' +
                ", ip='" + ip + '\'' +
                '}';
    }

    @Data
    @NoArgsConstructor
    public static class GatewayReq{
        /**
         * 批量创建个数
         */
        @ApiModelProperty(value = "批量创建个数")
        @NotNull(message = "account number can not be empty")
        private Integer accountNumber;

        @ApiModelProperty(value = "批量创建代理的前缀", example = "gto")
        private String prefix;
    }
}
