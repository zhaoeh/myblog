package com.mkt.agent.common.utils;


import com.mkt.agent.common.entity.RandomSingleton;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Random;


public class NumberUtils {


    /**
     * 比较大小，参数1 &gt; 参数2 返回true
     *
     * @param bigNum1 数字1
     * @param bigNum2 数字2
     * @return 是否大于
     * @since 3.0.9
     */
    public static boolean isGreater(BigDecimal bigNum1, BigDecimal bigNum2) {
        return bigNum1.compareTo(bigNum2) > 0;
    }

    /**
     * 比较大小，参数1 &gt;= 参数2 返回true
     *
     * @param bigNum1 数字1
     * @param bigNum2 数字2
     * @return 是否大于等于
     * @since 3, 0.9
     */
    public static boolean isGreaterOrEqual(BigDecimal bigNum1, BigDecimal bigNum2) {
        return bigNum1.compareTo(bigNum2) >= 0;
    }

    /**
     * 比较大小，参数1 &lt; 参数2 返回true
     *
     * @param bigNum1 数字1
     * @param bigNum2 数字2
     * @return 是否小于
     * @since 3, 0.9
     */
    public static boolean isLess(BigDecimal bigNum1, BigDecimal bigNum2) {
        return bigNum1.compareTo(bigNum2) < 0;
    }

    /**
     * 比较大小，参数1&lt;=参数2 返回true
     *
     * @param bigNum1 数字1
     * @param bigNum2 数字2
     * @return 是否小于等于
     * @since 3, 0.9
     */
    public static boolean isLessOrEqual(BigDecimal bigNum1, BigDecimal bigNum2) {
        return bigNum1.compareTo(bigNum2) <= 0;
    }


    /**
     * 对BigDecimal截取两位小数，后面位数舍弃
     * @param bigDecimal
     * @return
     */
    public static BigDecimal twoScaleFormat(BigDecimal bigDecimal){
        DecimalFormat decimalFormat = new DecimalFormat("0.00");
        decimalFormat.setRoundingMode(RoundingMode.DOWN);
        BigDecimal result = new BigDecimal(decimalFormat.format(bigDecimal));
        return result;
    }


    /**
     * description: 获取10位随机数
     * @param:  []
     * @return: java.lang.String
     * @Date: 2023/8/8 20:20
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public static String getRNum(int n){
        Random random = RandomSingleton.getInstance();
        StringBuilder stringBuilder = new StringBuilder();
        for (int i=0; i<n;i++){
            stringBuilder.append(random.nextInt(10));
        }
        return stringBuilder.toString();
    }

}
