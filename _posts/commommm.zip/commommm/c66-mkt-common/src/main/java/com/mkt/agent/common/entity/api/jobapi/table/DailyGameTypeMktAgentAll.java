package com.mkt.agent.common.entity.api.jobapi.table;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigDecimal;

@Data
@TableName("t_daily_game_type_mkt_agent_all")
public class DailyGameTypeMktAgentAll {

    @TableField("agent_date")
    private String agentDate;

    @TableField("login_name")
    private String loginName;

    @TableField("game_type")
    private String gameType;

    @TableField("ggr")
    private BigDecimal ggr = BigDecimal.ZERO;

    @TableField("turnover")
    private BigDecimal turnover = BigDecimal.ZERO;

    @TableField("winorloss")
    private BigDecimal winOrLoss = BigDecimal.ZERO;

}
