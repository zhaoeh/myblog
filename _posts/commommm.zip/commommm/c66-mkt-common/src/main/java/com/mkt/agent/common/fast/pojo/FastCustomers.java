package com.mkt.agent.common.fast.pojo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-04-08
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FastCustomers {

    private String curentLogin;

    private String loginName;

    private String parentName;

    private Integer agentLevel;

    private Integer isEnable;

    private Integer isDeleted;

    // 目标状态
    private Integer targetStatus;
}
