package com.mkt.agent.common.entity.mq;

import com.mkt.agent.common.enums.SensitiveFields;
import com.mkt.agent.common.utils.CommonUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Description TODO
 * @Classname Message
 * @Date 2023/9/9 17:35
 * @Created by TJSLucian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Message {
    private String messageId; // 消息唯一标识符
    private String content;   // 消息内容
    private String sender;    // 发送者
    private String receiver;  // 接收者
    private Long timestamp; // 消息时间戳
    private String dateTime;

    @Override
    public String toString() {
        return "Message{" +
                "messageId='" + messageId + '\'' +
                ", content='" + CommonUtil.desensitiveTargetStr(content, SensitiveFields.withdrawalPassword.getName()) + '\'' +
                ", sender='" + sender + '\'' +
                ", receiver='" + receiver + '\'' +
                ", timestamp=" + timestamp +
                ", dateTime='" + dateTime + '\'' +
                '}';
    }
}
