package com.mkt.agent.common.fast.pojo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;


/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-03-28
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("t_daily_mkt_user_mapping")
public class DailyMktUserMapping {

    /**
     * 玩家名称
     */
    @TableField(value = "login_name")
    private String loginName;

    /**
     * 当前用户自身状态：0：是代理且无效 1：是玩家，或者是代理且有效 -1：无效玩家
     */
    @TableField(value = "self_status")
    private Integer selfStatus;

    /**
     * 上级直属代理
     */
    @TableField(value = "parent_direct")
    private String parentDirect;

    /**
     * 上级直属代理状态
     */
    @TableField(value = "parent_direct_status")
    private Integer parentDirectStatus;

    /**
     * 上级直属代理level 0-5
     * 0：acc66
     * 1：一级代理
     * 2：二级代理
     * 3：三级代理
     * 4：四级代理
     * 5：五级代理
     */
    @TableField(value = "parent_direct_level")
    private Integer parentDirectLevel;

    /**
     * 该玩家的五级代理名称
     */
    @TableField(value = "parent_five")
    private String parentFive;

    /**
     * 该玩家的五级代理状态
     */
    @TableField(value = "parent_five_status")
    private Integer parentFiveStatus;

    /**
     * 该玩家的四级代理名称
     */
    @TableField(value = "parent_four")
    private String parentFour;

    /**
     * 该玩家的四级代理状态
     */
    @TableField(value = "parent_four_status")
    private Integer parentFourStatus;

    /**
     * 该玩家的三级代理名称
     */
    @TableField(value = "parent_three")
    private String parentThree;

    /**
     * 该玩家的三级代理状态
     */
    @TableField(value = "parent_three_status")
    private Integer parentThreeStatus;

    /**
     * 该玩家的二级代理名称
     */
    @TableField(value = "parent_two")
    private String parentTwo;

    /**
     * 该玩家的二级代理状态
     */
    @TableField(value = "parent_two_status")
    private Integer parentTwoStatus;


    /**
     * 该玩家的一级代理名称
     */
    @TableField(value = "parent_one")
    private String parentOne;

    /**
     * 该玩家的一级代理状态
     */
    @TableField(value = "parent_one_status")
    private Integer parentOneStatus;

    /**
     * 该玩家的顶级代理名称
     */
    @TableField(value = "parent_root")
    private String parentRoot;

    /**
     * 该玩家的删除状态 0：未删除 1：已删除
     */
    @TableField(value = "is_deleted")
    private Integer isDeleted;

    @TableField(value = "parent_root")
    private Date createDate;
}
