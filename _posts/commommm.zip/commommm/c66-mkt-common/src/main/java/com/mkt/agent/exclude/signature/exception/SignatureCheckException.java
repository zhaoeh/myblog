package com.mkt.agent.exclude.signature.exception;

/**
 * 签名校验错误bug
 * @author yiqiang
 * @date 2024/05/14
 */
public class SignatureCheckException extends AbstractSignatureException {
    private static final long serialVersionUID = -44670696324195L;

    public SignatureCheckException(String message) {
        super(message);
    }
}
