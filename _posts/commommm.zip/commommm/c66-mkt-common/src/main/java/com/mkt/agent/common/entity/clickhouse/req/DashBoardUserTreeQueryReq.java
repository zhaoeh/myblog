package com.mkt.agent.common.entity.clickhouse.req;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Description TODO
 * @Classname DashBoardUserTreeQueryEntity
 * @Date 2023/10/31 15:59
 * @Created by TJSLucian
 */
@Data
@NoArgsConstructor
@Builder
public class DashBoardUserTreeQueryReq {

    private String parent;
    private List<String> parentList;
    private String createTimeStart;
    private String createTimeEnd;

    public DashBoardUserTreeQueryReq(String createTimeStart, String createTimeEnd) {
        this.createTimeStart = createTimeStart;
        this.createTimeEnd = createTimeEnd;
    }

    public DashBoardUserTreeQueryReq(String parent, String createTimeStart, String createTimeEnd) {
        this.parent = parent;
        this.createTimeStart = createTimeStart;
        this.createTimeEnd = createTimeEnd;
    }

    public DashBoardUserTreeQueryReq(String parent, List<String> parentList, String createTimeStart, String createTimeEnd) {
        this.parent = parent;
        this.parentList = parentList;
        this.createTimeStart = createTimeStart;
        this.createTimeEnd = createTimeEnd;
    }
}
