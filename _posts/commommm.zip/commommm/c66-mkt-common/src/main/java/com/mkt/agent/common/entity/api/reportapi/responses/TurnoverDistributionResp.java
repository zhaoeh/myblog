package com.mkt.agent.common.entity.api.reportapi.responses;


import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.mkt.agent.common.entity.api.reportapi.requests.base.ReportBaseRequest;
import com.mkt.agent.common.entity.api.reportapi.responses.base.ReportBaseResponse;
import com.mkt.agent.common.enums.GameTypeEnum;
import com.mkt.agent.common.jackson.serializer.BigDecimalSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
@ApiModel(value = "投注额占比饼状图")
public class TurnoverDistributionResp {

    /**
     * Sport("Sports", "sportsPercentage", 1),
     * Sport_22("Sports", "sportsPercentage", 22),
     * Poker("Poker", "pokerPercentage", 3),
     * Slot("Slot", "slotPercentage", 5),
     * Bingo("Bingo", "bingoPercentage", 27),
     * Ebingo("EBingo", "ebingoPercentage", 21),
     * Casino("Casino", "casinoPercentage", 17),
     * Fishing("Fishing", "fishingPercentage", 8),
     * Specialty("Specialty Game", "specialty game", 30),
     * All("All", "allGamesPercentage", 0);
     **/
    // 游戏类型
    @ApiModelProperty(value = "game_type", example = "27")
    private Integer gameType;
    // 游戏名称
    @ApiModelProperty(value = "gameName", example = "bingoPercentage")
    private String gameName;
    // 投注额总计
    @ApiModelProperty(value = "turnoverSum", example = "20000")
    private String turnoverSum;
    // 投注额占比
    @ApiModelProperty(value = "turnoverDistribution", example = "0.4")
    private String turnoverDistribution;

    // 获取各个游戏类型的游戏名称
    public String getGameName() {
        return GameTypeEnum.getNameByCode(gameType);
    }
}


