package com.mkt.agent.common.fast.pojo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Builder;
import lombok.Data;

/**
 * @description: t_increment_check_point
 * @author: ErHu.Zhao
 * @create: 2024-03-28
 **/
@Data
@Builder
@TableName("t_increment_check_point")
public class IncrementCheckPoint {

    @TableId
    private Long id;

    /**
     * 资源名称
     */
    @TableField("resource_name")
    private String resourceName;

    /**
     * 事件类型 1.新增代理事件 2.删除代理事件 3.编辑代理事件 4.新增玩家事件 5.删除玩家事件 6.编辑玩家事件
     */
    @TableField("event_type")
    private Integer eventType;

}
