package com.mkt.agent.common.entity.api.agentapi.responses;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;

/**
 * @ClassName UserResp
 * @Description 用户信息
 * @Author TJSAlex
 * @Date 2023/7/17 14:37
 * @Version 1.0
 **/
@Data
public class UserResp implements Serializable {

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long customerId;

    private String loginName;
}
