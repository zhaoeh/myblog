package com.mkt.agent.common.player.core;

import org.springframework.util.CollectionUtils;

import java.util.Map;

/**
 * @description: 执行堆栈
 * @author: ErHu.Zhao
 * @create: 2024-03-14
 **/
public class CustomizeStackTrace {
    public static String getCurrentMethodStackTrace(Map<String,Object> element) {
        if (CollectionUtils.isEmpty(element)) {
            return "";
        }
        return element.get("fileName") + "|" + element.get("className") + "." + element.get("methodName") + "():" + element.get("lineNumber");
    }

}
