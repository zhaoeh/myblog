package com.mkt.agent.common.utils;

import java.util.HashMap;
import java.util.Map;

/**
 * 本地线程工具类
 */
public class ThreadLocalUtil {

    private static final ThreadLocal threadLocal = ThreadLocal.withInitial(() -> new HashMap(4));

    public static <T> T get(String key) {
        Map map = (Map) threadLocal.get();
        return (T) map.get(key);
    }

    public static <T> T get(String key, T defaultValue) {
        Map map = (Map) threadLocal.get();
        return (T) map.get(key) == null ? defaultValue : (T) map.get(key);
    }

    public static <T>  void set(String key, T value) {
        Map map = (Map) threadLocal.get();
        map.put(key, value);
    }

    public static void clear() {
        threadLocal.remove();
    }

    public static void remove(String key){
        Map map = (Map) threadLocal.get();
        map.remove(key);
    }

}
