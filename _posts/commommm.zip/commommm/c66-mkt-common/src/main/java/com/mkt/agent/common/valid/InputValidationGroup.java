package com.mkt.agent.common.valid;

public class InputValidationGroup {

    // 分组验证接口
    public interface Insert {}

    public interface Update {}

    public interface Query {}

    // 分组验证接口
    public interface SubInsert {}


    public interface UserToAgent {}

    public interface createUserByBatch {}


}
