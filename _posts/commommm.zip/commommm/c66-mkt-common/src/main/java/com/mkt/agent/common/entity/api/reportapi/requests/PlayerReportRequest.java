package com.mkt.agent.common.entity.api.reportapi.requests;


import com.mkt.agent.common.annotation.Convert2NullIfInvalidField;
import com.mkt.agent.common.entity.BasePageRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

@Data
@ApiModel(value = "PlayerReportRequest")
public class PlayerReportRequest extends BasePageRequest implements Serializable {


    private static final long serialVersionUID = 1l;

    @ApiModelProperty(hidden = true,notes = "当前登录代理用户名")
    private String loginName;

    // 玩家账户号：玩家的唯一标识
    @ApiModelProperty(value = "agentAccount", example = "ivan02")
    private String playerAccount;

    // 玩家上级代理账号：父级代理的账号
    @ApiModelProperty(value = "parentAccount", example = "ivan02")
    private String parentAccount;

    // 本身代理等级:数据来自于代理表，共五级：1，2，3，4，5
    @ApiModelProperty(value = "parentLevel")
    @Pattern(regexp = "-1|[1-5]", message = "parentLevel data format error")
    @Convert2NullIfInvalidField
    private String parentLevel;

    @ApiModelProperty(value = "playReportDataDate", example = "Month")
    @Pattern(regexp = "Day|Month", message = "dataDate data format error")
    @NotNull(message = "dataDate can not be null")
    private String dataDate;

    // 开始日期
    @ApiModelProperty(value = "startTime", example = "2023-05-01")
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "startTime data format error")
    @NotNull(message = "startTime can not be null")
    private String startDate;

    // 结束日期
    @ApiModelProperty(value = "endTime", example = "2023-05-31")
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "endTime data format error")
    @NotNull(message = "endTime can not be null")
    private String endDate;
}


