package com.mkt.agent.common.player.processor;

import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.mkt.agent.common.annotation.DistributedLock;
import com.mkt.agent.common.config.PlayerReportConfig;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.TAgentRefreshLog;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.TAgentUpdateLog;
import com.mkt.agent.common.player.core.LogHolder;
import com.mkt.agent.common.player.core.PlayerCache;
import com.mkt.agent.common.player.core.PlayerPersist;
import com.mkt.agent.common.player.model.*;
import com.mkt.agent.common.utils.CommonUtil;
import com.mkt.agent.common.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * @description: 代理用户明细处理器
 * @author: ErHu.Zhao
 * @create: 2024-02-06
 **/
@Component
@Slf4j
public class AgentTransProcessor {

    private final TransProcessor transProcessor;
    private final PlayerPersist playerPersist;
    private final PlayerReportConfig playerReportConfig;
    private final PlayerCache playerCache;
    private final Gson gson;

    public AgentTransProcessor(TransProcessor transProcessor, PlayerPersist playerPersist, PlayerReportConfig playerReportConfig, PlayerCache playerCache, Gson gson) {
        this.transProcessor = transProcessor;
        this.playerPersist = playerPersist;
        this.playerReportConfig = playerReportConfig;
        this.playerCache = playerCache;
        this.gson = gson;
    }

    /**
     * 按天处理BI数据和count表
     *
     * @param holder
     * @param dataSourceType
     * @param level
     * @param syncTransByDayParams
     */
    @DistributedLock(value = "handleUsersGroupByDay",expire = 360)
    public void handleUsersGroupByDay(PlayerMapperHolder holder, String dataSourceType, int level, SyncTransByDayParams syncTransByDayParams) {
        clearCache(syncTransByDayParams);
        TAgentCountGroup param = TAgentCountGroup.builder().clearDays(syncTransByDayParams.getClearDays()).dataSourceType(dataSourceType).build();
        List<TAgentCountGroup> contexts = transProcessor.buildGroupCountContexts(holder, param);
        log.info("当前action对应请求集是：{}", gson.toJson(contexts));
        LogHolder.addLogContainer(LogHolder.LogContainer.builder().logStatement("当前action对应请求集是：{}").log(List.of(gson.toJson(contexts))).build());
        if (CollectionUtils.isEmpty(contexts)) {
            log.info("按天查询count表，进行数据同步,params 为空,终止执行");
            LogHolder.addLogContainer(LogHolder.LogContainer.builder().logStatement("按天查询count表，进行数据同步,params 为空,终止执行").build());
            return;
        }
        contexts.stream().forEach(context -> this.doHandleData(holder, context, level));
    }

    /**
     * 处理数据同步
     *
     * @param holder
     * @param context
     * @param level
     */
    public void doHandleData(PlayerMapperHolder holder, TAgentCountGroup context, int level) {
        Integer actionType = context.getActionType();
        Assert.notNull(actionType, "actionType cannot be null");
        String dataSourceType = context.getDataSourceType();
        Assert.isTrue(Constants.FROM_ASYNC.equals(dataSourceType) || Constants.FROM_JOB.equals(dataSourceType) || Constants.FROM_SCHEDULED.equals(dataSourceType), "dataSourceType error");

        // 根据条件删除数据
        if (Constants.CLEAR.equals(actionType)) {
            log.info("按天查询count表，开始根据条件删除数据，param is {}", context);
            LogHolder.addLogContainer(LogHolder.LogContainer.builder().logStatement("按天查询count表，开始根据条件删除数据，param is {}").log(List.of(gson.toJson(context))).build());
            int delete = playerPersist.deleteAgentGroupCount(holder, context);
            context.clear();
            log.info("按天查询count表，根据条件删除数据结束，本次删除总数为{}条", delete);
            LogHolder.addLogContainer(LogHolder.LogContainer.builder().logStatement("按天查询count表，根据条件删除数据结束，本次删除总数为{}条").log(List.of(delete)).build());
            return;
        }

        Map<String, List<TAgentCustomers>> someAgents = obtainSomeAgents(holder, context);
        // 根据条件刷新数据(先删除符合条件的所有数据，再插入符合条件的所有数据)
        if (Constants.REFRESH.equals(actionType) && Constants.FROM_ASYNC.equals(dataSourceType)) {
            List<TAgentCustomers> teamAgents = someAgents.get(dataSourceType);
            if (CollectionUtils.isEmpty(teamAgents)) {
                log.info("按天查询count表，当前代理团队叶子代理为空，终止刷新动作");
                return;
            }
            log.info("按天查询count表，开始根据条件刷新数据，param is {},获取到的目标代理集合总数为:{}", context, teamAgents.size());
            int update = syncAgentTransCountGroupByDay(teamAgents, holder, context, level, 0);
            context.clear();
            log.info("按天查询count表，根据条件刷新数据结束，param is {},获取到的目标代理集合总数为:{},本次刷新总数为{}条", context, teamAgents.size(), update);
            return;
        }

        // 根据条件增量同步数据
        boolean isTimingTask = Constants.SYNC.equals(actionType) && (Constants.FROM_JOB.equals(dataSourceType) || Constants.FROM_SCHEDULED.equals(dataSourceType));
        if (isTimingTask) {
            List<TAgentCustomers> allAgents = someAgents.get(dataSourceType);
            if (CollectionUtils.isEmpty(allAgents)) {
                LogHolder.addLogContainer(LogHolder.LogContainer.builder().logStatement("按天查询count表，当前全量代理（忽略代理状态）为空").build());
                log.info("按天查询count表，当前全量代理（忽略代理状态）为空");
                return;
            }
            log.info("按天查询count表，开始根据条件同步数据，param is {},获取到的目标代理集合总数为:{}", context, allAgents.size());
            LogHolder.addLogContainer(LogHolder.LogContainer.builder().logStatement("按天查询count表，开始根据条件同步数据，param is {},获取到的目标代理集合总数为:{}").log(List.of(context, allAgents.size())).build());
            int update = batchAsyncAgentTransCountGroupByDay(allAgents, holder, context, level, 0);
            context.clear();
            log.info("按天查询count表，根据条件同步数据结束，param is {},获取到的目标代理集合总数为:{},本次插入总数为{}条", context, allAgents.size(), update);
            LogHolder.addLogContainer(LogHolder.LogContainer.builder().logStatement("按天查询count表，根据条件同步数据结束，param is {},获取到的目标代理集合总数为:{},本次插入总数为{}条").log(List.of(context, allAgents.size(), update)).build());
            return;
        }
    }

    /**
     * 针对原始请求开始日期到结束日期范围，按批次进行分批执行
     *
     * @param someAgents
     * @param holder
     * @param context
     * @param level
     * @param update
     * @return
     */
    private int batchAsyncAgentTransCountGroupByDay(List<TAgentCustomers> someAgents, PlayerMapperHolder holder, TAgentCountGroup context, int level, int update) {
        boolean isValidSegments = playerReportConfig.isValidSegments(Optional.ofNullable(context.getWillRetrySyncs()).map(List::size).orElse(0));
        if (!isValidSegments) {
            return doSingleWithRetry(someAgents, holder, context, level, update);
        }
        List<TAgentCountGroup> segments = transProcessor.splitDates(context, playerReportConfig.getSegments());
        if (CollectionUtils.isEmpty(segments)) {
            log.info("segments is empty,return 0");
            LogHolder.addLogContainer(LogHolder.LogContainer.builder().logStatement("segments is empty,return 0").build());
            return 0;
        }
        if (segments.size() == 1) {
            return doSingleWithRetry(someAgents, holder, context, level, update);
        }
        log.info("按天查询count表，准备分批同步数据，当前请求按照时间计划拆分为{}批，实际拆分为{}批", playerReportConfig.getSegments(), segments.size());
        LogHolder.addLogContainer(LogHolder.LogContainer.builder().logStatement("按天查询count表，准备分批同步数据，当前请求按照时间计划拆分为{}批，实际拆分为{}批").log(List.of(playerReportConfig.getSegments(), segments.size())).build());
        ExecutorService executorService = initExecutorService(segments);
        return doBatchWithRetry(executorService, segments, someAgents, holder, context, level, update);
    }

    /**
     * 带重试机制的单个时间范围处理
     *
     * @param someAgents
     * @param holder
     * @param context
     * @param level
     * @param update
     * @return
     */
    private int doSingleWithRetry(List<TAgentCustomers> someAgents, PlayerMapperHolder holder, TAgentCountGroup context, int level, int update) {
        int up = doSingle(someAgents, holder, context, level, update);
        List<TAgentCountGroup> willRetrySyncs = context.getWillRetrySyncs();
        if (CollectionUtils.isEmpty(willRetrySyncs)) {
            return up;
        }

        // 重试
        for (int i = 0, retryTimes = getRetryTimes(); i < retryTimes; i++) {
            log.info("开始重试，index is {}", i);
            up = doSingle(someAgents, holder, context, level, update);
            if (CollectionUtils.isEmpty(willRetrySyncs)) {
                return up;
            }
        }
        return up;
    }

    /**
     * 处理单个时间范围的数据
     *
     * @param someAgents
     * @param holder
     * @param context
     * @param level
     * @param update
     * @return
     */
    private int doSingle(List<TAgentCustomers> someAgents, PlayerMapperHolder holder, TAgentCountGroup context, int level, int update) {
        playerPersist.logsRefactor(holder, context);
        context.clearRetries();
        TAgentCountGroup completeContext = null;
        try {
            completeContext = doSyncWithLogs(someAgents, holder, context, level, update);
        } catch (Exception e) {
            context.setWillRetrySyncs(List.of(context));
            // 同步一批执行失败，则当前执行对象全部收集为重试对象再次重试
            log.error("按天查询count表，同步一批处理数据出错，error is ", e);
            LogHolder.addLogContainer(LogHolder.LogContainer.builder().logStatement("按天查询count表，同步一批处理数据出错，error is ").throwable(LogHolder.toStr(e)).build());
            return 0;
        }
        return completeContext.getUpdate();
    }

    /**
     * 带有重试机制的批量时间范围
     *
     * @param executorService
     * @param segments
     * @param someAgents
     * @param holder
     * @param context
     * @param level
     * @param update
     * @return
     */
    private int doBatchWithRetry(ExecutorService executorService, List<TAgentCountGroup> segments, List<TAgentCustomers> someAgents, PlayerMapperHolder holder, TAgentCountGroup context, int level, int update) {
        int up = doBatch(executorService, segments, someAgents, holder, context, level, update);
        List<TAgentCountGroup> willRetrySyncs = context.getWillRetrySyncs();
        if (CollectionUtils.isEmpty(willRetrySyncs)) {
            return up;
        }

        // 重试
        for (int i = 0, retryTimes = getRetryTimes(); i < retryTimes; i++) {
            log.info("开始重试，index is {}", i);
            up = doBatch(executorService, context.getWillRetrySyncs(), someAgents, holder, context, level, update);
            if (CollectionUtils.isEmpty(willRetrySyncs)) {
                return up;
            }
        }
        return up;
    }

    /**
     * 处理批量时间范围的数据
     *
     * @param executorService
     * @param segments
     * @param someAgents
     * @param holder
     * @param context
     * @param level
     * @param update
     * @return
     */
    private int doBatch(ExecutorService executorService, List<TAgentCountGroup> segments, List<TAgentCustomers> someAgents, PlayerMapperHolder holder, TAgentCountGroup context, int level, int update) {
        playerPersist.logsRefactor(holder, context);
        AtomicInteger updateCount = new AtomicInteger(0);
        if (Objects.isNull(executorService)) {
            log.info("同步分批执行");
            context.clearRetries();
            try {
                segments.stream().forEach(seg -> {
                    TAgentCountGroup completedContext = doSyncWithLogs(someAgents, holder, seg, level, update);
                    updateCount.set(updateCount.get() + completedContext.getUpdate());
                });
            } catch (Exception e) {
                // 同步多批执行失败，则当前执行对象全部收集为重试对象再次重试
                context.setWillRetrySyncs(segments);
                log.error("按天查询count表，同步分批处理数据出错，error is ", e);
                LogHolder.addLogContainer(LogHolder.LogContainer.builder().logStatement("按天查询count表，同步分批处理数据出错，error is ").throwable(LogHolder.toStr(e)).build());
            }

        } else {
            log.info("异步分批执行");
            // 将当前执行对象集设置为默认重试对象
            context.setWillRetrySyncs(segments);
            List<Future<TAgentCountGroup>> futures = new ArrayList<>();
            ExecutorService finalExecutorService = executorService;
            segments.stream().forEach(seg -> futures.add(finalExecutorService.submit(() -> {
                log.info("按天查询count表，开始异步分批处理数据，startDate is {},endDate is {}", seg.getBeginDate(), seg.getEndDate());
                TAgentCountGroup completedContext = doSyncWithLogs(someAgents, holder, seg, level, update);
                return completedContext;
            })));

            futures.stream().forEach(future -> {
                try {
                    TAgentCountGroup completedContext = future.get();
                    updateCount.set(updateCount.get() + completedContext.getUpdate());
                    // 成功一条，则删除一条
                    collectNeedRetriesAgain(context, completedContext);
                } catch (Exception e) {
                    log.error("按天查询count表，异步分批处理数据出错，error is ", e);
                    LogHolder.addLogContainer(LogHolder.LogContainer.builder().logStatement("按天查询count表，异步分批处理数据出错，error is ").throwable(LogHolder.toStr(e)).build());
                }
            });
        }
        return updateCount.get();
    }

    /**
     * 从上次重试对象中，聚合依旧需要继续重试的对象集
     *
     * @param context         原始上下文
     * @param completeContext 执行完成的上下文
     */
    private void collectNeedRetriesAgain(TAgentCountGroup context, TAgentCountGroup completeContext) {
        List<TAgentCountGroup> retries = context.getWillRetrySyncs();
        List<TAgentCountGroup> needRetriesAgain;
        if (!CollectionUtils.isEmpty(retries)) {
            needRetriesAgain = retries.stream().filter(e ->
                    !(CommonUtil.convertToInt(e.getBeginDate()) == CommonUtil.convertToInt(completeContext.getBeginDate()) &&
                            CommonUtil.convertToInt(e.getEndDate()) == CommonUtil.convertToInt(completeContext.getEndDate()))).collect(Collectors.toList());
            if (CollectionUtils.isEmpty(needRetriesAgain)) {
                context.clearRetries();
                return;
            }
            context.setWillRetrySyncs(needRetriesAgain);
        }
    }

    /**
     * 这个方法只做增量同步（全量代理-from job 和某个代理-from async）
     *
     * @param someAgents
     * @param holder
     * @param context
     * @param level
     */
    private int syncAgentTransCountGroupByDay(List<TAgentCustomers> someAgents, PlayerMapperHolder holder, TAgentCountGroup context, int level, int update) {
        //获取目标level的所有代理
        List<TAgentCustomers> agentList = holder.getAgentsByLevelMapper().apply(someAgents, level);

        if (!CollectionUtils.isEmpty(agentList)) {
            //获取当前level的所有代理在指定begin-end日期内按天分组后的交易count数(包含每一个代理自己本身的明细count)
            List<TAgentCountGroup> allAgentCountGroupDay = this.obtainAllAgentOfCurrentLevelCountGroupDay(holder, agentList, context);
            List<String> agentNames = agentList.stream().map(TAgentCustomers::getLoginName).collect(Collectors.toList());

            context.setTargetAgents(agentNames);
            update = playerPersist.batchRefreshWithPartition(holder, allAgentCountGroupDay, context);

            log.info("当前更新条数为: {}", update);
            allAgentCountGroupDay = null;
        }

        level--;

        if (level > 0) {
            return update + syncAgentTransCountGroupByDay(someAgents, holder, context, level, update);
        }
        return update;
    }

    /**
     * 分批插入
     *
     * @param holder
     * @param allAgentCountGroupDay
     */
    private int batchInsert(PlayerMapperHolder holder, List<TAgentCountGroup> allAgentCountGroupDay) {
        if (CollectionUtils.isEmpty(allAgentCountGroupDay)) {
            return 0;
        }
        List<List<TAgentCountGroup>> batches = Lists.partition(allAgentCountGroupDay, playerReportConfig.getPlayerInsertBatchSize());
        int update = batches.stream().map(b -> playerPersist.insertBatchAgentGroupCount(holder, b)).reduce((r1, r2) -> r1 + r2).orElse(0);
        batches = null;
        return update;
    }

    /**
     * 获取指定level的代理集合
     *
     * @param someAgents
     * @param level
     * @return
     */
    public List<TAgentCustomers> obtainAgentsByLevel(List<TAgentCustomers> someAgents, Integer level) {
        Map<Integer, List<TAgentCustomers>> someAgentsMap = obtainSomeAgentsMap(someAgents);
        if (MapUtils.isEmpty(someAgentsMap)) {
            return Collections.emptyList();
        }
        return Optional.ofNullable(someAgentsMap.get(level)).orElse(Collections.emptyList());
    }

    private Map<Integer, List<TAgentCustomers>> obtainSomeAgentsMap(List<TAgentCustomers> someAgents) {
        if (CollectionUtils.isEmpty(someAgents)) {
            return Collections.emptyMap();
        }
        return transProcessor.groupByAgentLevel(someAgents);
    }

    /**
     * 获取某些代理
     *
     * @param holder
     * @param context
     * @return
     */
    private Map<String, List<TAgentCustomers>> obtainSomeAgents(PlayerMapperHolder holder, TAgentCountGroup context) {
        String dataSourceType = context.getDataSourceType();
        Assert.isTrue(Constants.FROM_ASYNC.equals(dataSourceType) || Constants.FROM_JOB.equals(dataSourceType) || Constants.FROM_SCHEDULED.equals(dataSourceType), "dataSourceType error");
        Map<String, List<TAgentCustomers>> someAgents = new HashMap<>();
        List<TAgentCustomers> agents = null;
        if (Constants.FROM_ASYNC.equals(dataSourceType)) {
            // 异步更新类型，查询当前用户的团队中的所有叶子代理集（包括自己）
            String agentName = context.getAgentName();
            Assert.isTrue(StringUtils.isNotBlank(agentName), "agentName cannot be blank");
            log.info("dataSourceType 是 FROM_ASYNC， 获取当前代理团队中的所有叶子代理，当前代理是 {}", agentName);
            agents = holder.getTeamAgentsMapper().apply("0", agentName);
        }
        if (Constants.FROM_JOB.equals(dataSourceType) || Constants.FROM_SCHEDULED.equals(dataSourceType)) {
            log.info("dataSourceType 是 FROM_JOB， 开始获取全量代理（忽略代理状态）");
            agents = holder.getAgentsMapper().apply(0);
        }
        if (CollectionUtils.isEmpty(agents)) {
            return Collections.emptyMap();
        }
        someAgents.put(dataSourceType, agents);
        return someAgents;
    }

    /**
     * 获取当前level的所有代理用户按天分组后的汇总count
     *
     * @param holder
     * @param agentList
     * @param context
     * @return
     */
    public List<TAgentCountGroup> obtainAllAgentOfCurrentLevelCountGroupDay(PlayerMapperHolder holder, List<TAgentCustomers> agentList, TAgentCountGroup context) {

        if (CollectionUtils.isEmpty(agentList)) {
            return null;
        }

        List<TAgentCountGroup> allAgentCountGroupDay = new ArrayList<>();

        /**
         * 遍历代理
         */
        agentList.forEach(agent -> {
            List<TAgentCountGroup> currentAgentCountGroupDay = this.handleAgent(holder, agent, context);

            if (!CollectionUtils.isEmpty(currentAgentCountGroupDay)) {
                allAgentCountGroupDay.addAll(currentAgentCountGroupDay);
            }
        });

        return allAgentCountGroupDay;
    }

    /**
     * 从5级遍历，自下而上处理某个代理
     *
     * @param holder
     * @param agent
     * @param context
     * @return
     */
    public List<TAgentCountGroup> handleAgent(PlayerMapperHolder holder, TAgentCustomers agent, TAgentCountGroup context) {
        String agentAccount = agent.getLoginName();

        Integer isDeleted = agent.getIsDeleted();
        Integer isEnable = agent.getIsEnable();

        log.info("[handleAgent]开始同步当前代理数据，当前代理是:{}", agentAccount);
        TAgentCountGroup request = TAgentCountGroup.builder().beginDate(context.getBeginDate()).endDate(context.getEndDate()).
                queryUsers(List.of(agentAccount)).agentName(agentAccount).parentAgentName(agent.getParentName()).
                totalType(Constants.SELF).dataSourceType(context.getDataSourceType()).isDeleted(isDeleted).isEnable(isEnable).build();
        try {
            // 查询当前代理自己的交易count
            List<TAgentCountGroup> selfCount = transProcessor.queryTargetUsersCount(holder.getTargetAgentsTransCountMapper(), request);

            // 查询当前代理直属用户的交易count
            request.clearParams();
            request.setTargetAgents(List.of(agentAccount));
            request.setTotalType(Constants.DIRECT);
            List<TAgentCountGroup> currentAgentDirectCount = transProcessor.queryTargetUsersCount(holder.getTargetAgentsTransCountMapper(), request);
//            List<TAgentCountGroup> currentAgentDirectCount = transProcessor.collectUsersCounts(holder.getLowerDirectsMapper(), holder.getTargetAgentsTransCountMapper(), request);

            List<TAgentCountGroup> downCountOfCurrentAgentGroupByDashDate = null;
            if (agent.getAgentLevel() != Constants.DASH_BOARD_DATA_START_LEVEL) {
//                int begin = CommonUtil.convertToInt(context.getBeginDate());
//                int end = CommonUtil.convertToInt(context.getEndDate());
//                if (begin < 20231224 && end > 20231224) {
//                    throw new RuntimeException("模拟线程失败,name is " + Thread.currentThread().getName() + ";begin is " + begin);
//                }
//
//                if (begin < 20240115 && end > 20240115) {
//                    throw new RuntimeException("模拟线程失败,name is " + Thread.currentThread().getName() + ";begin is " + begin);
//                }

                // 查询当前代理下级代理用户的交易count
                request.clearParams();
                request.setTotalType(Constants.AGENT);
                request.setQueryUsers(List.of(agentAccount));
                downCountOfCurrentAgentGroupByDashDate = transProcessor.queryTargetUsersCount(holder.getTransCountsMapper(), request);
            }

            // 合并count
            List<TAgentCountGroup> merged = transProcessor.mergeTotalCount(agentAccount, selfCount, currentAgentDirectCount, downCountOfCurrentAgentGroupByDashDate);

            if (!CollectionUtils.isEmpty(merged)) {
                return merged;
            }
            request = null;
        } catch (Exception e) {
            // 出现异常，则清空当前时间段插入的数据
            if (BooleanUtils.isTrue(context.getIsNeedAsyncUpdate())) {
                log.info("异步更新类型，回滚当前代理的数据");
                playerPersist.deleteAgentGroupCountWithLogs(holder, TAgentCountGroup.builder().targetAgents(List.of(agentAccount)).isNeedAsyncUpdate(context.getIsNeedAsyncUpdate()).beginDate(context.getBeginDate()).endDate(context.getEndDate()).build());
            } else {
                log.info("job类型，回滚当前时间段的数据");
                playerPersist.deleteAgentGroupCountWithLogs(holder, TAgentCountGroup.builder().isNeedAsyncUpdate(context.getIsNeedAsyncUpdate()).beginDate(context.getBeginDate()).endDate(context.getEndDate()).build());
            }

            throw e;
        }
        return null;
    }

    /**
     * 当代理关系发生变更时，刷新当前代理的交易总数
     *
     * @param holder
     * @param currentAgent
     * @param recordDateStart
     * @param recordDateEnd
     */
    public void refreshAgentWithRelationChanged(PlayerMapperHolder holder,
                                                String currentAgent, String recordDateStart, String recordDateEnd) {
        if (this.isAgentRelationChange(holder, currentAgent)) {
            refreshCounts(holder, currentAgent, recordDateStart, recordDateEnd);
        }
    }

    /**
     * 处理数据
     *
     * @param holder
     * @param currentAgent
     */
    public void dealWithData(PlayerMapperHolder holder, String currentAgent) {
        if (StringUtils.isBlank(currentAgent)) {
            log.error("currentAgent为空,终止按天查询异步更新");
        }
        TAgentCountGroup param = TAgentCountGroup.builder().agentName(currentAgent).dataSourceType(Constants.FROM_ASYNC).
                actionType(Constants.REFRESH).clearDays(playerReportConfig.getClearDays()).build();
        List<TAgentCountGroup> groups = transProcessor.buildGroupCountContexts(holder, param);
        if (CollectionUtils.isEmpty(groups)) {
            log.info("groups 为空,终止按天查询异步更新");
            return;
        }
        dealWithToday(holder, groups.get(0));

    }

    /**
     * 处理今天之外的数据
     *
     * @param holder
     * @param currentAgent
     */
    public void dealWithOutsideToday(PlayerMapperHolder holder, String currentAgent, TAgentCountGroup group) {
        if (Objects.isNull(group)) {
            return;
        }
        if (Constants.SYNC.equals(group.getActionType())) {
            syncCounts(holder, currentAgent, group.getBeginDate(), group.getEndDate());
        }
        if (Constants.CLEAR.equals(group.getActionType())) {
            clearCounts(holder, currentAgent, group.getBeginDate(), group.getEndDate());
        }
    }

    /**
     * 处理今天的数据
     */
    public void dealWithToday(PlayerMapperHolder holder, TAgentCountGroup group) {
        if (Objects.isNull(group)) {
            log.info("group 为空,终止按天查询异步更新");
            return;
        }
        log.info("准备按天查询异步更新，group is {}", group);
        if (BooleanUtils.isTrue(group.getIsNeedAsyncUpdate())) {
            log.info("开始按天异步更新,group is {}", group);
            doHandleData(holder, group, Constants.DASH_BOARD_DATA_START_LEVEL);
        }
    }

    /**
     * 重构 group 参数
     *
     * @param group
     * @param currentAgent
     */
    private void refactorGroup(TAgentCountGroup group, String currentAgent) {
        String today = DateUtils.localDateToString(DateUtils.getNDaysAgo(0));
        group.setBeginDate(today);
        group.setEndDate(today);
        group.setAgentName(currentAgent);
        group.setDataSourceType(Constants.FROM_ASYNC);
    }

    /**
     * 实时刷新目标代理指定日期范围内的count交易总数（先删除再插入）
     *
     * @param holder
     * @param currentAgent
     * @param recordDateStart
     * @param recordDateEnd
     */
    public void refreshCounts(PlayerMapperHolder holder,
                              String currentAgent, String recordDateStart, String recordDateEnd) {
        List<TAgentCountGroup> merged = obtainTransCountsForCurrent(holder, currentAgent, recordDateStart, recordDateEnd);
        // 刷新当前代理指定日期范围的交易count总数
        playerPersist.refreshAgentGroupCount(holder, merged,
                TAgentCountGroup.builder().agentName(currentAgent).targetAgents(List.of(currentAgent)).beginDate(recordDateStart).endDate(recordDateEnd).build());
    }

    /**
     * 同步目标代理指定日期范围内的count交易总数（直接插入）
     *
     * @param holder
     * @param currentAgent
     * @param recordDateStart
     * @param recordDateEnd
     */
    public void syncCounts(PlayerMapperHolder holder,
                           String currentAgent, String recordDateStart, String recordDateEnd) {
        List<TAgentCountGroup> merged = obtainTransCountsForCurrent(holder, currentAgent, recordDateStart, recordDateEnd);
        playerPersist.insertBatchAgentGroupCount(holder, merged);
    }

    /**
     * 清除目标代理指定日期范围内的count交易总数（直接删除）
     *
     * @param holder
     * @param currentAgent
     * @param recordDateStart
     * @param recordDateEnd
     */
    public void clearCounts(PlayerMapperHolder holder,
                            String currentAgent, String recordDateStart, String recordDateEnd) {
        TAgentCountGroup delete = TAgentCountGroup.builder().agentName(currentAgent).targetAgents(List.of(currentAgent)).beginDate(recordDateStart).endDate(recordDateEnd).build();
        playerPersist.deleteAgentGroupCount(holder, delete);
    }

    /**
     * 获取当前登录者的counts交易集合
     *
     * @param holder
     * @param currentAgent
     * @param recordDateStart
     * @param recordDateEnd
     * @return
     */
    public List<TAgentCountGroup> obtainTransCountsForCurrent(PlayerMapperHolder holder, String currentAgent,
                                                              String recordDateStart, String recordDateEnd) {
        List<String> allAgents = new ArrayList<>(List.of(currentAgent));
        TAgentCountGroup request = TAgentCountGroup.builder().beginDate(recordDateStart).endDate(recordDateEnd).
                agentName(currentAgent).queryUsers(List.of(currentAgent)).build();
        // 当前代理的所有下级代理
        List<String> lowerAgents = holder.getLowerAgentsMapper().apply(request);
        if (!org.apache.commons.collections4.CollectionUtils.isEmpty(lowerAgents)) {
            allAgents.addAll(lowerAgents);
        }
        log.info("按天查询异步更新，需要更新的代理 size is {}", allAgents.size());
        List<TAgentCountGroup> allCounts = new ArrayList<>();
        allAgents.stream().forEach(agent -> {
            List<TAgentCountGroup> counts = obtainTransCountsForAgents(holder, agent, recordDateStart, recordDateEnd);
            if (!org.apache.commons.collections4.CollectionUtils.isEmpty(counts)) {
                allCounts.addAll(counts);
            }
        });
        return allCounts;
    }

    /**
     * 实时获取某一批代理指定时间区间内的按天分组交易总数
     *
     * @param holder
     * @return
     */
    public List<TAgentCountGroup> obtainTransCountsForAgents(PlayerMapperHolder holder, String currentAgent,
                                                             String recordDateStart, String recordDateEnd) {

        // 查询当前代理自己的交易count
        TAgentCountGroup request = TAgentCountGroup.builder().beginDate(recordDateStart).endDate(recordDateEnd).
                agentName(currentAgent).queryUsers(List.of(currentAgent)).totalType(Constants.SELF).build();
        List<TAgentCountGroup> selfCount = transProcessor.queryTargetUsersCount(holder.getTargetAgentsTransCountMapper(), request);

        // 查询当前代理直属用户集的交易count
        request.clearParams();
        request.setTargetAgents(List.of(currentAgent));
        request.setTotalType(Constants.DIRECT);
        List<TAgentCountGroup> currentAgentDirectCount = transProcessor.collectUsersCounts(holder.getLowerDirectsMapper(), holder.getTargetAgentsTransCountMapper(), request);

        // 查询当前代理下级代理用户集的团队交易count
        request.clearParams();
        request.setTargetAgents(List.of(currentAgent));
        request.setTotalType(Constants.AGENT);
        request.setTargetAgents(holder.getLowerAgentsMapper().apply(request));
        List<TAgentCountGroup> currentAgentDownCount = transProcessor.collectUsersCounts(holder.getLowerUsersMapper(), holder.getTargetAgentsTransCountMapper(), request);

        // 合并count
        List<TAgentCountGroup> merged = transProcessor.mergeTotalCount(currentAgent, selfCount, currentAgentDirectCount, currentAgentDownCount);

        if (!org.apache.commons.collections4.CollectionUtils.isEmpty(merged)) {
            return merged;
        }
        request = null;
        return merged;
    }

    /**
     * 实时获取某一批代理在某一天的下级用户交易明细总数
     *
     * @param holder
     * @param request
     * @return
     */
    public TAgentCountGroup obtainGroupCountsOfAgentsByDayWithRuntime(PlayerMapperHolder holder, TAgentCountGroup request) {
        List<TAgentCountGroup> currentAgentDirectCount = transProcessor.collectUsersCounts(holder.getTargetUsersMapper(),
                holder.getTargetAgentsTransCountMapper(), request);
        return Optional.ofNullable(currentAgentDirectCount).map(list -> list.stream().
                reduce((r1, r2) -> transProcessor.reduceAllDirectCount(r1, r2)).orElse(new TAgentCountGroup())).orElse(new TAgentCountGroup());
    }

    /**
     * 判断当前代理用户代理关系是否发生变更
     *
     * @param holder
     * @param currentAgent
     * @return
     */
    public boolean isAgentRelationChange(PlayerMapperHolder holder, String currentAgent) {
        boolean isAgentRelationChange = false;
        Result<TAgentUpdateLog> logResult = holder.getIsAgentChangedMapper().apply(currentAgent);
        if (logResult.isSuccess() && !Objects.isNull(logResult.getData())) {
            log.info("The agent:{} has been changed!", currentAgent);
            isAgentRelationChange = true;
            holder.getAgentChangedConsumer().accept(currentAgent);
        }
        log.info("[isAgentRelationChange method] begin to run isAgentRelationChange, current user is {}, isAgentRelationChange is {}", currentAgent, isAgentRelationChange);
        return isAgentRelationChange;
    }

    /**
     * 是否处理全量代理 true：是 false：否
     *
     * @param agentName
     * @return
     */
    private boolean isHandleFullAgents(String agentName) {
        return StringUtils.isBlank(agentName);
    }

    /**
     * 根据条件清空缓存
     *
     * @param syncTransByDayParams
     */
    private void clearCache(SyncTransByDayParams syncTransByDayParams) {
        // 定时任务清除缓存
        if (BooleanUtils.isTrue(syncTransByDayParams.getClearCache())) {
            log.info("定时任务清除缓存开始");
            playerCache.clearPlayersByDay(Constants.PLAYER_REPORT_BY_DAY);
            log.info("定时任务清除缓存结束");
        }
    }

    /**
     * 执行同步操作并记录log records
     *
     * @param someAgents
     * @param holder
     * @param context
     * @param level
     * @param update
     * @return
     */
    private TAgentCountGroup doSyncWithLogs(List<TAgentCustomers> someAgents, PlayerMapperHolder holder, TAgentCountGroup context, int level, int update) {
        Integer up = syncAgentTransCountGroupByDay(someAgents, holder, context, level, update);
        holder.getCountLogInsertMapper().apply(List.of(TAgentRefreshLog.builder().
                handlerName(Constants.SYNC_TRANS_BY_DAY_HANDLER).
                refreshDate(DateUtils.getNDaysAgo(0).toString()).
                beginDate(context.getBeginDate()).
                endDate(context.getEndDate()).
                runner(Thread.currentThread().getName()).
                isSuccess(1).recordSize(up).build()));
        context.setUpdate(up);
        return context;
    }



    /**
     * 获取重试次数
     *
     * @return
     */
    private Integer getRetryTimes() {
        Integer retryTimes = playerReportConfig.getRetryTimeWithFailedTask();
        if (Objects.isNull(retryTimes)) {
            retryTimes = 3;
        }
        return retryTimes;
    }

    /**
     * 初始化线程池对象
     *
     * @param segments
     * @return
     */
    private ExecutorService initExecutorService(List<TAgentCountGroup> segments) {
        if (BooleanUtils.isTrue(playerReportConfig.getEnableSegments())) {
            log.info("begin to init thread pool of AgentTransProcessor");
            ExecutorService executorService = Executors.newFixedThreadPool(segments.size());
            log.info("end to init thread pool of AgentTransProcessor, threadPoolSize is {}", segments);
            return executorService;
        }
        return null;
    }
}
