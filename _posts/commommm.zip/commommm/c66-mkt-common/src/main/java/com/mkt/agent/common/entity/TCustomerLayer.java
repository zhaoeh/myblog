package com.mkt.agent.common.entity;


import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@TableName("t_customer_layer")
public class TCustomerLayer extends BaseOperationEntity{
  @TableField(exist = false)
  private String messageId;
  @ApiModelProperty("上级id")
  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private Long parentId;
  @ApiModelProperty("上级LoginName")
  private String parentLoginName;
  @ApiModelProperty("登录名")
  private String loginName;
  @ApiModelProperty("用户id")
  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private Long customerId;
  private Long flag;
  private Integer customerType;
  @ApiModelProperty("siteId 1:Bingoplus  2:Arenaplus  3:Gameplus")
  private Integer siteId;

}
