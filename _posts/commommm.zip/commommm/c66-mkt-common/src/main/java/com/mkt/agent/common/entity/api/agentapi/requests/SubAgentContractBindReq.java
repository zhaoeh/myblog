package com.mkt.agent.common.entity.api.agentapi.requests;

import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * @ClassName AgentReq
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Data
@NoArgsConstructor
public class SubAgentContractBindReq {

    /*
        subAgentId
    */
    @ApiModelProperty(value = "subCustomersId")
    @NotNull(message = "sub customers id is not blank", groups = InputValidationGroup.Update.class)
    private String subCustomersId;


    /*
        parentAgentId
    */
    @ApiModelProperty(value = "parentCustomersId")
    @NotNull(message = "parent customers id is not blank", groups = InputValidationGroup.Update.class)
    private Long parentCustomersId;


    /*
        parentLoginName
    */
    @ApiModelProperty(value = "parentLoginName")
    @NotBlank(message = "parent login name is not blank", groups = InputValidationGroup.Update.class)
    private String parentLoginName;

    /*
        subLoginName
    */
    @ApiModelProperty(value = "subLoginName")
    @NotBlank(message = "sub login name is not blank", groups = InputValidationGroup.Update.class)
    private String subLoginName;

    /*
        settlementPercentageReq
    */
    @ApiModelProperty(value = "佣金比例集合")
    @NotEmpty(message = "settlementPercentageReq array is not blank", groups = InputValidationGroup.Update.class)
    private List<SettlementPercentageReq> settlementPercentageReq;



}
