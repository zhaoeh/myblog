package com.mkt.agent.common.entity.clickhouse.resp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * @Description TODO11
 * @Classname DashBoardBetPlayersVo
 * @Date 2024/1/4 16:46
 * @Created by TJSLucian
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DashBoardBetPlayersVo {

    private String agentAccount;

    private Long betPlayers;

    private String recordDateStart;

    private String recordDateEnd;

}
