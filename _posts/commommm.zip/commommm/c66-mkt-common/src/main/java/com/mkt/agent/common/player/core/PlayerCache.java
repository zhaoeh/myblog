package com.mkt.agent.common.player.core;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.reportapi.requests.PlayerReportRequest;
import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse;
import com.mkt.agent.common.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * @description: player report缓存器
 * @author: ErHu.Zhao
 * @create: 2024-02-26
 **/
@Component
@Slf4j
public class PlayerCache {

    private final RedisUtil redisUtil;
    private final Gson gson;

    public PlayerCache(RedisUtil redisUtil, Gson gson) {
        this.redisUtil = redisUtil;
        this.gson = gson;
    }

    /**
     * 缓存5分钟
     *
     * @param key
     * @param details
     */
    public void cachePlayersByDay(String key, List<PlayerReportResponse> details) {
        if(StringUtils.isBlank(key)){
            log.info("缓存key为空，终止缓存更新");
            return;
        }
        if (CollectionUtils.isEmpty(details)) {
            log.info("details 为empty,终止缓存更新");
            return;
        }
        redisUtil.setByTimeUnit(key, gson.toJson(details), 5, TimeUnit.MINUTES);
    }

    /**
     * 删除key
     *
     * @param key
     */
    public void clearPlayersByDay(String key) {
        if (StringUtils.isBlank(key)) {
            log.info("key is blank,skip to clear cache");
            return;
        }
        if (Constants.PLAYER_REPORT_BY_DAY.equals(key)) {
            log.info("key is {},clear all keys starting with this", key);
            redisUtil.removeKeysByPrefix(Constants.PLAYER_REPORT_BY_DAY);
            return;
        }
        log.info("key is {},clear this key", key);
        redisUtil.remove(key);
    }

    /**
     * 从缓存中获取player report按天数据
     *
     * @param key
     * @return
     */
    public List<PlayerReportResponse> obtainPlayersByDay(String key) {
        if (StringUtils.isBlank(key)) {
            log.info("缓存key为空，查询缓存返回null");
            return null;
        }
        List<PlayerReportResponse> playerList = Optional.ofNullable(redisUtil.get(key)).map(value -> {
            List<PlayerReportResponse> players = gson.fromJson(Objects.toString(value), new TypeToken<List<PlayerReportResponse>>() {
            }.getType());
            return players;
        }).orElse(null);
        log.info("[obtainPlayersByDay method] 从缓存加载当前数据, cacheKey is {}, cacheValue size is {}", key, Optional.ofNullable(playerList).map(List::size).orElse(0));
        return playerList;
    }

    /**
     * 缓存key
     *
     * @param request
     * @return
     */
    public String prepareCacheKey(PlayerReportRequest request) {
        StringBuilder builder = new StringBuilder(Constants.PLAYER_REPORT_BY_DAY);
        builder.append(returnEmptyStrIfNeed(request.getLoginName()));
        builder.append(returnEmptyStrIfNeed(request.getPlayerAccount()));
        builder.append(returnEmptyStrIfNeed(request.getParentAccount()));
        builder.append(returnEmptyStrIfNeed(request.getParentLevel()));
        return builder.toString();
    }

    public String obtainCacheKey(String prepareKey, String beginDate, String endDate) {
        if (StringUtils.isBlank(prepareKey)) {
            return null;
        }
        return prepareKey + beginDate + endDate;
    }

    private String returnEmptyStrIfNeed(String source) {
        return StringUtils.isBlank(source) ? Strings.EMPTY : source;
    }
}
