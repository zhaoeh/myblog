package com.mkt.agent.common.Interceptor;

import com.alibaba.nacos.shaded.org.checkerframework.checker.nullness.qual.Nullable;
import com.mkt.agent.common.constants.AuthConstants;
import com.mkt.agent.common.entity.system.LoginUserInfo;
import com.mkt.agent.common.utils.UserContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

/**
 * @Description: 拦截器，用户上下文配置
 * @Author: PTMinnisLi
 * @Date: 2023/6/16
 */
@Slf4j
public class UserInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        // 获取请求头中的信息
        String userId = request.getHeader(AuthConstants.USER_ID);
        String userName = request.getHeader(AuthConstants.USER_NAME);
        String userType = request.getHeader(AuthConstants.USER_TYPE);
        String from = request.getHeader(AuthConstants.USER_FROM);
        if (ObjectUtils.isNotEmpty(userId) && ObjectUtils.isNotEmpty(userName)) {
            userId = URLDecoder.decode(userId, StandardCharsets.UTF_8);
            userName = URLDecoder.decode(userName, StandardCharsets.UTF_8);
            if (ObjectUtils.isNotEmpty(userType)) {
                userType = URLDecoder.decode(userType, StandardCharsets.UTF_8);
            }
            if (ObjectUtils.isNotEmpty(from)) {
                from = URLDecoder.decode(from, StandardCharsets.UTF_8);
            }
            LoginUserInfo userInfo = LoginUserInfo.builder().userId(userId).username(userName).userType(userType).from(from).build();
            UserContext.setContext(userInfo);
        }
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, @Nullable Exception ex) {
        UserContext.clear();
    }
}