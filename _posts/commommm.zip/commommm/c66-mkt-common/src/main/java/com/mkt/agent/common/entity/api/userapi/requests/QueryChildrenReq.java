package com.mkt.agent.common.entity.api.userapi.requests;

import lombok.Data;

@Data
public class QueryChildrenReq {

    private String loginName;

    private Long customerId;

    private int pageSize;

    private int pageNum;
}
