package com.mkt.agent.common.entity.api.jobapi.responses;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

/**
 * @author Colson
 * @date 8/21/2023 6:54 PM
 */
@Data
public class CustomerLayerResponse {

    private String loginName;

    private String parentLoginName;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long parentId;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long customerId;

    private Integer siteId;

    private String remarks;



}
