package com.mkt.agent.common.entity.api.agentapi;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;

/**
 * @description: 用户门店日志表
 * @author: ErHu.Zhao
 * @create: 2024-04-17
 **/
@TableName("t_agent_customers_branch_log")
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@SuperBuilder
public class TAgentCustomersBranch {

    //指定主键生成策略使用雪花算法(默认策略)
    @TableId(value = "id", type = IdType.ASSIGN_ID)
    @ApiModelProperty(value = "id")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    protected Long id;

    /**
     * 用户名称
     */
    @Column(name = "user_name", nullable = false)
    private String userName;

    /**
     * 门店编号
     */
    @Column(name = "branch_code", nullable = false)
    private String branchCode;

    /**
     * 门店名称
     */
    @Column(name = "branch_name", nullable = false)
    private String branchName;

    /**
     * 备注
     */
    @Column(name = "remarks", nullable = false)
    private String remarks;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "创建人(Creator)")
    protected String createBy;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty(value = "更新人(Modifier)")
    protected String updateBy;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "创建日期(Create Time)")
    protected String createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty(value = "更新日期(Modify Time)")
    protected String updateTime;
}
