package com.mkt.agent.common.helper;

import com.alibaba.fastjson.JSONObject;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;

import java.util.Objects;
import java.util.Optional;

/**
 * @description: 跨服务三方调用，针对毫无规则的三方响应数据处理，一对一定制处理
 * @author: ErHu.Zhao
 * @create: 2024-01-04
 **/
@Slf4j
public class ThirdResponseOfNoRulesHelper {

    public static <T> T pullDataOfFindAgentAllPayTypes(String response, String url, String loginName, Class<T> tClass) {
        final String messageKey = "message";
        final String statusKey = "status";
        log.info("{}调用支付系统接口AllPayChannels返回:{},url:{}", loginName, response, url);
        try {
            JSONObject res = JSONObject.parseObject(response);
            return (T) Optional.ofNullable(res).filter(e -> e.containsKey(statusKey)).map(e -> e.get(statusKey).toString()).filter(e -> e.equals(String.valueOf(0))).map(e -> Objects.isNull(tClass) ? res : JSONObject.toJavaObject(res, tClass)).orElseThrow(() -> {
                String message = "AllPayChannels error";
                if (Objects.nonNull(res) && res.containsKey(messageKey)) {
                    message = Objects.toString(res.get(messageKey));
                }
                log.error("{}调用allPayChannels支付系统返回error data:{}", loginName, response);
                throw new BusinessException(message, 1111);
            });
        } catch (Exception e) {
            if (BusinessException.class.isInstance(e)) {
                throw e;
            }
            log.error("调用allPayChannels支付系统返回错误格式，response is {}", response);
            throw new BusinessException(ResultEnum.THIRD_SYSTEM_RETURN_ERROR);
        }
    }
}
