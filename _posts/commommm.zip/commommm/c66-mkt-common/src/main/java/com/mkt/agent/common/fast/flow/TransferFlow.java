package com.mkt.agent.common.fast.flow;

import com.alibaba.nacos.common.utils.CollectionUtils;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.fast.core.*;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import com.mkt.agent.common.fast.pojo.AgentCustomersMapping;
import com.mkt.agent.common.fast.pojo.DailyMktUserMapping;
import com.mkt.agent.common.fast.pojo.SimpleCustomers;
import com.mkt.agent.common.utils.PageUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.util.Asserts;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @description: 用户（玩家）流程
 * @author: ErHu.Zhao
 * @create: 2024-04-01
 **/
@Component
@Slf4j
public class TransferFlow {

    @Autowired
    private FastConfig fastConfig;

    @Autowired
    private FastCore fastCore;

    @Autowired
    private FastPersist persist;

    /**
     * 循环处理玩家-代理关系转移，直到处理完毕
     *
     * @param fastContext 逻辑持有器
     * @param strategy    策略标志
     * @param mapping     代理映射集
     * @param factory     byteHouse sqlSession工厂
     * @param nullAgent   空代理脱敏值
     * @param adminAgent  acc66代理脱敏值
     */
    public void handleUserMappingFlowWithLoop(FastContext fastContext, StrategyEnums strategy, List<AgentCustomersMapping> mapping, SqlSessionFactory factory, String nullAgent, String adminAgent) {
        int result = 0;
        while (true) {
            int current = handleUserMappingFlow(fastContext, strategy, mapping, factory, nullAgent, adminAgent);
            result = result + current;
            if (current == 0) {
                log.info("全量补救执行完毕,本地补救玩家个数为：{}", result);
                return;
            }
        }
    }

    /**
     * 处理玩家-代理映射
     *
     * @param fastContext
     * @param strategy
     * @param mapping
     * @param factory
     * @param nullAgent
     * @param adminAgent
     * @return
     */
    private int handleUserMappingFlow(FastContext fastContext, StrategyEnums strategy, List<AgentCustomersMapping> mapping, SqlSessionFactory factory, String nullAgent, String adminAgent) {
        Asserts.notBlank(nullAgent, "nullAgent cannot be blank");
        Asserts.notBlank(adminAgent, "adminAgent cannot be blank");
        int result = 0;
        // 查询当前脱敏映射表关联的所有未转移的玩家总数
        int notTransferPlayersCountByCondition = fastContext.getQueryNotTransferPlayersCountWithJoin().get();
        log.info("-----当前关联脱敏映射表中未转移的玩家总数为：{}", notTransferPlayersCountByCondition);
        if (notTransferPlayersCountByCondition == 0) {
            // 当前脱敏映射中不存在可用于转移的玩家，终止
            return result;
        }
        boolean supportCache = false;
        List<TCustomerLayer> targetUsers = null;
        if (CollectionUtils.isEmpty(mapping)) {
            if (notTransferPlayersCountByCondition <= fastConfig.getSmallPlayersCount()) {
                // 对于少量玩家，则定点查询
                targetUsers = fastContext.getQueryNotTransferPlayersWithJoin().apply(null);
                // 关联代理为空，有可能是acc66
                List<TAgentCustomers> relationAgents = fastCore.obtainRelationAgentsFromUsers(targetUsers);
                if (CollectionUtils.isEmpty(relationAgents)) {
                    doHandleUserFlowOne(fastContext, strategy, targetUsers, null, null, factory, nullAgent, adminAgent);
                }
                mapping = persist.queryAgentsMappingList(fastContext, relationAgents.stream().map(TAgentCustomers::getLoginName).collect(Collectors.toList()));
            } else {
                // 如果原始mapping为空，则默认查询全量代理脱敏映射表
                mapping = persist.queryAgentsMappingList(fastContext, null);
                supportCache = true;
            }
        } else {
            // 否则查询当前代理集的脱敏映射表
            mapping = persist.queryAgentsMappingList(fastContext, mapping.stream().map(AgentCustomersMapping::getAgentName).collect(Collectors.toList()));
        }
        if (CollectionUtils.isEmpty(mapping)) {
            return result;
        }
        Map<String, String> currentAgentsMapping = fastCore.agentCustomersMapping2Map(mapping);
        if (MapUtils.isEmpty(currentAgentsMapping)) {
            return result;
        }

        result = handleUserFlowThree(fastContext, strategy, currentAgentsMapping, factory, nullAgent, adminAgent, supportCache);
        notTransferPlayersCountByCondition = notTransferPlayersCountByCondition - result;
        result = result + loopHandle(fastContext, strategy, factory, targetUsers, currentAgentsMapping, nullAgent, adminAgent, notTransferPlayersCountByCondition, supportCache);
        return result;
    }

    private int loopHandle(FastContext fastContext,
                           StrategyEnums strategy,
                           SqlSessionFactory factory,
                           List<TCustomerLayer> targetUsers,
                           Map<String, String> currentAgentsMapping,
                           String nullAgent, String adminAgent,
                           int notTransferPlayersCountByCondition,
                           boolean supportCache) {
        if (notTransferPlayersCountByCondition <= fastConfig.getFastPlayersCount()) {
            // 对于未转移的有效玩家数小于50万的，采用flow2的方式进行同步
            return handleUserFlowTwo(fastContext, strategy, targetUsers, currentAgentsMapping, factory, nullAgent, adminAgent, supportCache);
        } else {
            return handleUserFlowOne(fastContext, strategy, currentAgentsMapping, factory, nullAgent, adminAgent, notTransferPlayersCountByCondition, supportCache);
        }
    }

    /**
     * 执行玩家流程1
     *
     * @param currentAgentsMapping
     * @param factory
     * @param nullAgent
     * @param adminAgent
     */
    private int handleUserFlowOne(FastContext fastContext,
                                  StrategyEnums strategy,
                                  Map<String, String> currentAgentsMapping,
                                  SqlSessionFactory factory,
                                  String nullAgent,
                                  String adminAgent,
                                  int notTransferCount,
                                  boolean supportCache) {
        Asserts.notBlank(nullAgent, "nullAgent cannot be blank");
        Asserts.notBlank(adminAgent, "adminAgent cannot be blank");
        int result = 0;
        if (MapUtils.isEmpty(currentAgentsMapping)) {
            return result;
        }
        if (notTransferCount == 0) {
            return result;
        }
        // 查询指定代理集的所有上级代理链路
        Map<String, List<SimpleCustomers>> superAgentChainsMap = fastCore.obtainSuperAgentChainsMap(fastContext, FastUtils.mapKey2List(currentAgentsMapping), supportCache);
        // 根据未转移的玩家总数按照批次分批处理
        int batches = fastCore.obtainsBatches(notTransferCount, fastConfig.getFastPlayersCount());
        for (int i = 1; i <= batches; i++) {
            // 查询当前批次所有未同步的玩家
            List<TCustomerLayer> notTransferPlayersWithLimit = fastContext.getQueryNotTransferPlayersWithLimit().
                    apply(PageUtils.calculateStartIndex(i, fastConfig.getFastPlayersCount()), PageUtils.calculateEndIndex(i, fastConfig.getFastPlayersCount()));
            if (CollectionUtils.isEmpty(notTransferPlayersWithLimit)) {
                continue;
            }
            result = result + doHandleUserFlowOne(fastContext, strategy, notTransferPlayersWithLimit, currentAgentsMapping, superAgentChainsMap, factory, nullAgent, adminAgent);
        }
        FastCore.CACHE.clear();
        return result;
    }


    /**
     * 执行玩家流程1
     *
     * @param notTransferPlayers
     * @param currentAgentsMapping
     * @param factory
     * @param nullAgent
     * @param adminAgent
     */
    private int doHandleUserFlowOne(FastContext fastContext,
                                    StrategyEnums strategy,
                                    List<TCustomerLayer> notTransferPlayers,
                                    Map<String, String> currentAgentsMapping,
                                    Map<String, List<SimpleCustomers>> superAgentChainsMap,
                                    SqlSessionFactory factory, String nullAgent, String adminAgent) {
        if (CollectionUtils.isEmpty(notTransferPlayers)) {
            return 0;
        }
        List<DailyMktUserMapping> targetUsers = fastCore.packageUsersMappings(fastContext, notTransferPlayers, superAgentChainsMap, currentAgentsMapping, nullAgent, adminAgent);
        if (CollectionUtils.isNotEmpty(targetUsers)) {
            return fastCore.batchHandleUsersMappingWithRetry(fastContext, strategy, targetUsers, factory);
        }
        return 0;
    }


    /**
     * 执行玩家流程2（玩家驱动）
     *
     * @param currentAgentsMapping
     * @param factory
     * @param nullAgent
     * @param adminAgent
     */
    private int handleUserFlowTwo(FastContext fastContext,
                                  StrategyEnums strategy,
                                  List<TCustomerLayer> targetUsers,
                                  Map<String, String> currentAgentsMapping,
                                  SqlSessionFactory factory,
                                  String nullAgent,
                                  String adminAgent,
                                  boolean supportCache) {
        if (MapUtils.isEmpty(currentAgentsMapping)) {
            return 0;
        }
        if (CollectionUtils.isEmpty(targetUsers)) {
            // 查询未转移的玩家
            targetUsers = fastContext.getQueryNotTransferPlayersWithJoin().apply(null);
        }
        targetUsers = targetUsers.stream().filter(pl -> StringUtils.isNotBlank(pl.getParentLoginName())).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(targetUsers)) {
            return 0;
        }
        Map<String, List<SimpleCustomers>> superAgentChainsMap = fastCore.obtainSuperAgentChainsMap(fastContext, FastUtils.mapKey2List(currentAgentsMapping), supportCache);
        return doHandleUserFlowOne(fastContext, strategy, targetUsers, currentAgentsMapping, superAgentChainsMap, factory, nullAgent, adminAgent);
    }

    private int handleUserFlowThree(FastContext fastContext,
                                    StrategyEnums strategy,
                                    Map<String, String> currentAgentsMapping,
                                    SqlSessionFactory factory,
                                    String nullAgent,
                                    String adminAgent,
                                    boolean supportCache) {
        if (MapUtils.isEmpty(currentAgentsMapping)) {
            return 0;
        }

        // 获取玩家数量大于200000且未转移的玩家
        List<Map<String, String>> agentWithPlayers = fastContext.getQueryUsersCountForAgent().apply(fastConfig.getUsersSizeOfBigAgent());
        if (CollectionUtils.isEmpty(agentWithPlayers)) {
            return 0;
        }

        List<String> largeAgents = agentWithPlayers.stream().map(item -> item.get("parentName")).collect(Collectors.toList());

        if (CollectionUtils.isEmpty(largeAgents)) {
            return 0;
        }


        // 查询目标代理集合的上级代理链
        Map<String, List<SimpleCustomers>> superAgentChainsMap = fastCore.obtainSuperAgentChainsMap(fastContext, FastUtils.mapKey2List(currentAgentsMapping), supportCache);
        if (MapUtils.isEmpty(superAgentChainsMap)) {
            return 0;
        }


        return largeAgents.stream().map(largeAgent -> {
            // 处理当前大代理未转移的玩家
            List<TCustomerLayer> notTransferPlayersByCondition = fastContext.getQueryNotTransferPlayersWithJoin().apply(List.of(largeAgent));
            notTransferPlayersByCondition = notTransferPlayersByCondition.stream().filter(pl -> StringUtils.isNotBlank(pl.getParentLoginName())).collect(Collectors.toList());
            if (CollectionUtils.isEmpty(notTransferPlayersByCondition)) {
                return 0;
            }
            return doHandleUserFlowThree(fastContext, strategy, notTransferPlayersByCondition, currentAgentsMapping, superAgentChainsMap, factory, nullAgent, adminAgent);
        }).reduce((r1, r2) -> r1 + r2).orElse(0);
    }

    /**
     * 执行Flow3
     *
     * @param notTransferPlayers
     * @param currentAgentsMapping
     * @param superAgentChainsMap
     * @param factory
     * @param nullAgent
     * @param adminAgent
     */
    private int doHandleUserFlowThree(FastContext fastContext,
                                      StrategyEnums strategy,
                                      List<TCustomerLayer> notTransferPlayers,
                                      Map<String, String> currentAgentsMapping,
                                      Map<String, List<SimpleCustomers>> superAgentChainsMap,
                                      SqlSessionFactory factory, String nullAgent, String adminAgent) {
        if (MapUtils.isEmpty(superAgentChainsMap)) {
            return 0;
        }
        if (MapUtils.isEmpty(currentAgentsMapping)) {
            return 0;
        }
        if (CollectionUtils.isEmpty(notTransferPlayers)) {
            return 0;
        }
        List<DailyMktUserMapping> currentUsers = fastCore.packageUsersMappings(fastContext, notTransferPlayers, superAgentChainsMap, currentAgentsMapping, nullAgent, adminAgent);
        return fastCore.batchHandleUsersMappingWithRetry(fastContext, strategy, currentUsers, factory);
    }

}
