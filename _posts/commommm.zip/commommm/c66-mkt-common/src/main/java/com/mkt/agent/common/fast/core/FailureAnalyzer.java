package com.mkt.agent.common.fast.core;

import com.alibaba.nacos.common.utils.CollectionUtils;
import com.mkt.agent.common.fast.pojo.AgentCustomersMapping;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @description: 失败分析器
 * @author: ErHu.Zhao
 * @create: 2024-04-04
 **/
@Component
@Slf4j
public class FailureAnalyzer {

    @Autowired
    private FastPersist fastPersist;


    /**
     * handleAgentMappingWithRetry失败处理
     *
     * @param initStart
     * @param mapping
     */
    @Transactional(rollbackFor = Exception.class)
    public List<AgentCustomersMapping> failureAnalysisOfHandleAgentMappingWithRetry(FastContext fastContext, int initStart, List<AgentCustomersMapping> mapping) {
        if (initStart == 2) {
            // 重试第二次则进行失败原因分析并处理
            Map<String, List<AgentCustomersMapping>> hasMappedAgents = fastPersist.queryAgentsMappingGroup(fastContext, mapping);
            if (MapUtils.isNotEmpty(hasMappedAgents)) {
                // 更新已经脱敏的数据status状态
                fastPersist.batchUpdateAgentsStatus(fastContext,
                        hasMappedAgents.values().stream().flatMap(List::stream).map(AgentCustomersMapping::getAgentName).collect(Collectors.toList()), 1);
                // 找出入参中依旧未脱敏的代理集
                mapping = mapping.stream().filter(map -> {
                    List<AgentCustomersMapping> hasMapped = hasMappedAgents.get(map.getAgentName());
                    return CollectionUtils.isEmpty(hasMapped);
                }).collect(Collectors.toList());
            }
        }
        return mapping;
    }
}
