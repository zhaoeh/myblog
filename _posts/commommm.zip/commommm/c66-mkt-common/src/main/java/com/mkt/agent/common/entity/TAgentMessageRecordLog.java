package com.mkt.agent.common.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class TAgentMessageRecordLog {

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private long customerId;
    private String exchange;
    private String queue;
    private String message;
    private String create_time;
    private String message_create_time;

}
