package com.mkt.agent.common.entity.api.commissionapi.responses;


import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.mkt.agent.common.annotation.ExcelColumn;
import com.mkt.agent.common.entity.api.commissionapi.responses.base.CommissionRecordBaseResponse;
import com.mkt.agent.common.jackson.serializer.BigDecimalSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
@ApiModel(description = "佣金记录信息")
public class CommissionRecordDetailResponse extends CommissionRecordBaseResponse {

    // 佣金记录id：佣金记录唯一标识
    @ApiModelProperty(value = "commission record ID", example = "1,auto increment")
    @ExcelIgnore
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private Long id;
    // 本身代理等级:数据来自于代理表，共五级：1，2，3，4，5
    @ApiModelProperty(value = "agentLevel", example = "the level of agent like 1,2,3,4,5")
    private Integer agentLevel;
    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount", example = "Amida001")
    @ExcelColumn(value ="Account",order = 1)
    private String agentAccount;

    // 代理类型：0：General Line (普通代理)，1：Professional Line(专业代理可发展下级)
    @ApiModelProperty(value = "agentType")
    @ExcelIgnore
    private Integer agentType;

    @ExcelColumn(value ="Type",order = 0)
    private String agentTypeStr;

    // 佣金金额：根据佣金方案以及投注金额或平台收益金额计算得出
    @ApiModelProperty(value = "commissionAmount", example = "1000")
    @ExcelColumn(value ="Generate Commission",order = 2)
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal commissionAmount;
    // 投注金额：玩家投注到平台游戏的金额
    @ApiModelProperty(value = "turnover", example = "10000")
    @ExcelColumn(value ="Turnover",order = 3)
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal turnover;
    // 平台收入金额：GGR类型佣金计算使用'
    @ApiModelProperty(value = "income", example = "compute commission by GGR meaning that income generate by player like 10000")
    @ExcelColumn(value ="GGR",order = 4)
    @JsonSerialize(using = BigDecimalSerializer.class)
    @JsonProperty("GGR")
    private BigDecimal GGR;
    // 玩家输赢金额
    @ApiModelProperty(value = "winOrLoss", example = "20000")
    @ExcelColumn(value ="Win/Loss",order = 5)
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal winOrLoss;
    // 玩家存款金额
    @ApiModelProperty(value = "deposit", example = "20000")
    @ExcelColumn(value ="Deposit",order = 6)
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal deposit;
    // 玩家取款金额
    @ApiModelProperty(value = "withdrawal", example = "1000")
    @ExcelColumn(value ="Withdrawal",order = 7)
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal withdrawal;

    // 佣金记录创建时间
    @ApiModelProperty(value = "createTime", example = "05/18/2023 08:30:45")
    @ExcelIgnore
    private String createTime;

}
