package com.mkt.agent.common.player.model;

import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonth;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @Description TODO
 * @Classname PlayerReportByMonthProcessorModel
 * @Date 2024/3/13 15:49
 * @Created by TJSLucian
 */
@Data
@Component
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PlayerReportByMonthProcessorModel {

    private Integer level;

    private String startDate;

    private String endDate;

    private String month;

    private boolean isCurrentMonth;

    private PlayerReportByMonthMapperHolder holder;

    //定时任务   异步更新
    private String operatorType;

    //如果是异步更新，需要指定团队的所有者parent
    private String parent;

    //如果是异步更新，parent的level
    private int parentLevel;

}
