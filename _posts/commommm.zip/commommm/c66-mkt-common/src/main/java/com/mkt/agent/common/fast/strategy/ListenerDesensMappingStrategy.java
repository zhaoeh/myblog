package com.mkt.agent.common.fast.strategy;

import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.common.fast.core.FastPersist;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import com.mkt.agent.common.fast.pojo.IncrementCheckPoint;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @description: 代理脱敏监听器策略
 * @author: ErHu.Zhao
 * @create: 2024-04-08
 **/
@Component
@Slf4j
public class ListenerDesensMappingStrategy implements RemediationStrategy {

    private final FastPersist fastPersist;

    public ListenerDesensMappingStrategy(FastPersist fastPersist) {
        this.fastPersist = fastPersist;
    }

    @Override
    public String strategy() {
        return StrategyEnums.ListenerDesensMappingStrategy.getStrategyName();
    }

    @Override
    public void afterSuccess(FastContext fastContext, String callable, List<String> params) {
//        log.info("{} 执行成功，更新当前代理已脱敏状态", callable);
        log.info("afterSuccess with ListenerDesensMappingStrategy，监听器-更新代理脱敏成功");
        fastPersist.batchUpdateAgentsStatus(fastContext, params, 1);
    }

    @Override
    public void afterFailed(FastContext fastContext, String callable, List<String> params) {
//        log.info("{} 重试失败，添加到checkPoint", callable);
        log.info("afterFailed with ListenerDesensMappingStrategy，监听器-更新代理脱敏失败");
        List<IncrementCheckPoint> inserts = params.stream().map(agentName -> IncrementCheckPoint.builder().resourceName(agentName).
                eventType(fastContext.getEvent().getEventType()).build()).collect(Collectors.toList());
        fastContext.getInsertBatchSomeColumnWithIncrementCheckPoint().apply(inserts);
    }
}
