package com.mkt.agent.common.entity.api.reportapi.responses.base;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Data
public class ReportPageResponse<T> extends Page<T> {

    @ApiModelProperty(value = "pageSumMap", example = "{\n" +
            "      \"GGR\": -283661.526464,\n" +
            "      \"deposit\": 242884046.000000,\n" +
            "      \"winAndLoss\": -15937.834248,\n" +
            "      \"withdrawal\": 0,\n" +
            "      \"turnover\": 30335.793536\n" +
            "    }")
    private Map<String, BigDecimal> pageSumMap = new HashMap<>();

    @ApiModelProperty(value = "searchSumMap", example = "{\n" +
            "      \"GGR\": -283661.526464,\n" +
            "      \"deposit\": 242884046.000000,\n" +
            "      \"winAndLoss\": -15937.834248,\n" +
            "      \"withdrawal\": 0,\n" +
            "      \"turnover\": 30335.793536\n" +
            "    }")
    private Map<String, BigDecimal> searchSumMap = new HashMap<>();


}
