package com.mkt.agent.common.fast.flow;

import com.alibaba.nacos.common.utils.CollectionUtils;
import com.alibaba.nacos.common.utils.StringUtils;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.fast.core.*;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import com.mkt.agent.common.fast.pojo.AgentCustomersMapping;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.http.util.Asserts;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.StopWatch;

import java.util.List;
import java.util.Map;

/**
 * @description: 全量补救器
 * @author: ErHu.Zhao
 * @create: 2024-04-01
 **/
@Component
@Slf4j
public class FlowCenter {

    private final FastCore fastCore;
    private final DesensMappingFlow desensMappingFlow;
    private final TransferFlow transferFlow;
    private final QueryHelper queryHelper;
    private final FastConfig fastConfig;

    public FlowCenter(FastCore fastCore, DesensMappingFlow desensMappingFlow, TransferFlow transferFlow, QueryHelper queryHelper, FastConfig fastConfig) {
        this.fastCore = fastCore;
        this.desensMappingFlow = desensMappingFlow;
        this.transferFlow = transferFlow;
        this.queryHelper = queryHelper;
        this.fastConfig = fastConfig;
    }

    /**
     * 执行流程
     *
     * @param factory
     */
    public void doFlows(FastContext fastContext, SqlSessionFactory factory) {
        if (BooleanUtils.isFalse(fastConfig.getFastSwitch())) {
            log.info("fast switch is close,stop do it");
            return;
        }
        StopWatch stopWatch = new StopWatch();
        stopWatch.start("doFlows");
        Assert.notNull(factory, "SqlSessionFactory cannot be null");
        cleanUp(fastContext);
        Map<String, String> nullOrAcc66AgentsMapping = fastCore.queryNullOrAcc66AgentMapping(fastContext);
        String nullAgent = nullOrAcc66AgentsMapping.get(BaseConstants.NULL_AGENT);
        String adminAgent = nullOrAcc66AgentsMapping.get(BaseConstants.C66_ADMIN);
        List<String> allLoginNames = fastCore.obtainWaitForMappingAgents(fastContext, nullOrAcc66AgentsMapping);
        List<String> uuids = FastUtils.generateUuid(allLoginNames.size());
        if (CollectionUtils.isEmpty(uuids)) {
            log.info("uuids is empty,stop to sync agent mapping flow and begin to sync user transfer flow");
            transferFlow.handleUserMappingFlowWithLoop(fastContext, StrategyEnums.InitTransferOfUserStrategy, null, factory, nullAgent, adminAgent);
        }
        List<AgentCustomersMapping> mapping = fastCore.packageAgentMappings(allLoginNames, uuids);
        if (CollectionUtils.isEmpty(mapping)) {
            log.info("mapping is empty,stop to sync agent mapping flow");
            printResult(fastContext);
            return;
        }
        Map<String, String> currentAgentsMapping = fastCore.agentCustomersMapping2Map(mapping);
        nullAgent = StringUtils.isBlank(nullAgent) ? currentAgentsMapping.get(BaseConstants.NULL_AGENT) : nullAgent;
        Asserts.notBlank(nullAgent, "nullAgent cannot be blank");
        adminAgent = StringUtils.isBlank(adminAgent) ? currentAgentsMapping.get(BaseConstants.C66_ADMIN) : adminAgent;
        Asserts.notBlank(adminAgent, "adminAgent cannot be blank");
        int updateResult = desensMappingFlow.batchHandleAgentMappingWithRetry(fastContext, StrategyEnums.InitDesensMappingStrategy, mapping, factory, nullAgent, adminAgent);
        // 所有代理脱敏成功，则进入玩家映射流程
        if (updateResult > 0) {
            transferFlow.handleUserMappingFlowWithLoop(fastContext, StrategyEnums.InitTransferOfUserStrategy, null, factory, nullAgent, adminAgent);
        }
        log.info("全量补救执行完毕,本地补救代理个数为：{}", updateResult);
        stopWatch.stop();
        log.info("suspend time is {} ms", stopWatch.getTotalTimeMillis());
        printResult(fastContext);
    }

    private void cleanUp(FastContext fastContext) {
        if (fastContext.isReRun()) {
            log.info("begin to clean up");
            fastContext.getClearAgentsMapping().run();
            fastContext.getClearUsersMapping().run();
            fastContext.getUpdateAgentsStatus().apply(null, 0);
            fastContext.getUpdateUsersStatus().apply(null, 0);
            log.info("end to clean up");
        }
    }

    private void printResult(FastContext fastContext) {
        if (fastContext.isPrintResult()) {
            queryHelper.printQueryResult(fastContext);
        }
    }

}
