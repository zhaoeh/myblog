package com.mkt.agent.common.wrapper;

import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.StreamUtils;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.io.*;
import java.nio.charset.Charset;
import java.util.Enumeration;

/**
 * @Description request包装类 request的inputStream只能读取一次， 封装一下用于多次读取request
 * @Classname RequestWrapper
 * @Date 2024/4/22 15:40
 * @Created by TJSLucian
 */
public class RequestWrapper extends HttpServletRequestWrapper {
    private final byte[] body;

    @Getter
    private final String requestData;

    public RequestWrapper(HttpServletRequest request) {
        super(request);
        String sessionStream = getBodyString(request);
        body = sessionStream.getBytes(Charset.forName("UTF-8"));
        requestData = sessionStream;
    }


    /**
     * 获取请求Body
     *
     * @param request
     * @return
     */
    public String getBodyString(final ServletRequest request) {
        String contentType = request.getContentType();
        String bodyString ="";

        if (StringUtils.isNotBlank(contentType) &&
                (contentType.contains("multipart/form-data") ||
                        contentType.contains("x-www-form-urlencoded"))){

            Enumeration<String> pars=request.getParameterNames();

            while(pars.hasMoreElements()){

                String n=pars.nextElement();

                bodyString+=n+"="+request.getParameter(n)+"&";

            }

            bodyString=bodyString.endsWith("&")?bodyString.substring(0, bodyString.length()-1):bodyString;

            return bodyString;

        }

        try {
            byte[] byteArray = StreamUtils.copyToByteArray(request.getInputStream());
            bodyString = new String(byteArray, "UTF-8");
        } catch (IOException e) {
        }

        return bodyString;
    }


    @Override
    public ServletInputStream getInputStream() throws IOException {
        final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(body);
        ServletInputStream servletInputStream = new ServletInputStream() {
            @Override
            public boolean isFinished() {
                return false;
            }
            @Override
            public boolean isReady() {
                return false;
            }
            @Override
            public void setReadListener(ReadListener readListener) {
            }
            @Override
            public int read() throws IOException {
                return byteArrayInputStream.read();
            }
        };
        return servletInputStream;

    }

    @Override
    public BufferedReader getReader() throws IOException {
        return new BufferedReader(new InputStreamReader(this.getInputStream()));
    }

}