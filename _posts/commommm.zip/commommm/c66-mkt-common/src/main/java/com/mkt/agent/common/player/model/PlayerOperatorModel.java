package com.mkt.agent.common.player.model;

import com.mkt.agent.common.constants.Constants;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.Assert;

import java.util.List;
import java.util.Objects;

/**
 * @description: player运算器参数模型
 * @author: ErHu.Zhao
 * @create: 2024-02-01
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
@Slf4j
public class PlayerOperatorModel {

    /**
     * 当前检索条件中的开始索引
     */
    private Integer startIndex;

    /**
     * 当前检索条件中的结束索引
     */
    private Integer endIndex;

    /**
     * 基于当前查询条件所查询出来的总count
     */
    private Integer totalSize;

    /**
     * 基于当前查询条件，当首次命中startIndex后，所查询出来的总条数(-1为初始状态)
     */
    private Integer totalSizeWhenFirstHitStartIndex;

    /**
     * 基于当前查询条件，当成功命中endIndex后，所查询出来的总条数
     */
    private Integer totalSizeWhenHitEndIndex;

    /**
     * 基于当前查询条件startIndex和endIndex命中的目标日期集合
     */
    private List<String> targetDates;

    /**
     * 依赖对象
     */
    private TAgentCountGroup agentCountGroup;

    /**
     * 是否终止请求
     */
    private boolean killed;

    /**
     * 是否直接查询：直接查询将忽略分阶段查询，直接查询目标库
     */
    private boolean directQuery;

    /**
     * 查询类型：1.查询自己的count 2.查询直属用户的count 3.查询整个团队的count
     */
    private int queryType;

    /**
     * 忽略分页
     */
    private boolean ignorePagination;

    /**
     * 当前迭代日期
     */
    private String iterationDate;

    /**
     * 最大查询条数限制
     */
    private Integer maxCountLimit;

    /**
     * 缓存key
     */
    private String prepareKey;

    /**
     * 向容器中添加目标日期
     *
     * @param targetDate
     */
    public void addTargetDate(String targetDate) {
        Assert.notNull(targetDates, "targetDates must be init when call addTargetDate method");
        this.targetDates.add(targetDate);
    }

    public String getAgentName() {
        Assert.notNull(agentCountGroup, "agentCountGroup must be init when call getAgentName method");
        return this.agentCountGroup.getAgentName();
    }

    public PlayerOperatorModel setTargetAgents(List<String> agents) {
        Assert.notNull(agentCountGroup, "agentCountGroup must be init when call setTargetAgents agent");
        this.agentCountGroup.setTargetAgents(agents);
        return this;
    }

    public List<String> getTargetAgents() {
        Assert.notNull(agentCountGroup, "agentCountGroup must be init when call getTargetAgents method");
        return this.agentCountGroup.getTargetAgents();
    }

    public PlayerOperatorModel setTargetQueryUsers(List<String> queryUsers) {
        Assert.notNull(agentCountGroup, "agentCountGroup must be init when call setTargetQueryUsers method");
        this.agentCountGroup.setQueryUsers(queryUsers);
        return this;
    }

    public List<String> getTargetQueryUsers() {
        Assert.notNull(agentCountGroup, "agentCountGroup must be init when call getTargetQueryUsers method");
        return this.agentCountGroup.getQueryUsers();
    }

    public String getBeginDate() {
        Assert.notNull(agentCountGroup, "agentCountGroup must be init when call getBeginDate method");
        return this.agentCountGroup.getBeginDate();
    }

    public String getEndDate() {
        Assert.notNull(agentCountGroup, "agentCountGroup must be init when call getEndDate method");
        return this.agentCountGroup.getEndDate();
    }

    /**
     * 是否忽略查询最大数量限制
     *
     * @return
     */
    public boolean ignoreMaxCountLimit() {
        return Objects.isNull(maxCountLimit) || maxCountLimit <= -1;
    }

    public void setTotalSizeWhenFirstHitStartIndex(Integer totalSizeWhenFirstHitStartIndex) {
        Assert.notNull(totalSizeWhenFirstHitStartIndex, "totalSizeWhenFirstHitStartIndex cannot be null");
        if (this.totalSizeWhenFirstHitStartIndex > Constants.DEFAULT_FIRST_HIT_START_INDEX) {
            return;
        }
        this.totalSizeWhenFirstHitStartIndex = totalSizeWhenFirstHitStartIndex;
        log.info("设置首次命中当前页面startIndex之前的count：{}", totalSizeWhenFirstHitStartIndex);
    }

    public Integer getTotalSizeWhenFirstHitStartIndex() {
        int subtractedCount = totalSizeWhenFirstHitStartIndex.equals(Constants.DEFAULT_FIRST_HIT_START_INDEX) ? 0 : totalSizeWhenFirstHitStartIndex;
        log.info("获取首次命中当前页面startIndex之前的count：{}", subtractedCount);
        return subtractedCount;
    }
}
