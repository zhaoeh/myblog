package com.mkt.agent.common.entity.api.reportapi.requests.base;

import com.mkt.agent.common.entity.BasePageRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Pattern;
import java.io.Serializable;

@Data
@ApiModel(value = "ReportBaseRequest")
public class ReportBaseRequest extends BasePageRequest implements Serializable {


    private static final long serialVersionUID = 1l;
    // 导出文件名称
    @ApiModelProperty(value = "loginName", example = "top")
    private String loginName;

    // 导出文件名称
    @ApiModelProperty(value = "fileName", example = "commissionRecord")
    private String fileName;

    // 佣金记录查询开始产生时间
    //@ApiModelProperty(value = "createDateStart", example = "2023-01-01 00:00:00")
    private String createDateStart;

    // 佣金记录查询结束时间产生时间
    //@ApiModelProperty(value = "createDateEnd", example = "2023-07-28 00:00:00")
    private String createDateEnd;

    // 佣金计算开始日期
    @ApiModelProperty(value = "playInfoDateStart", example = "2023-05-01")
    @Pattern(regexp = ".*-.*", message = "data format error")
    private String playInfoDateStart;

    // 佣金计算结束日期
    @ApiModelProperty(value = "playInfoDateEnd", example = "2023-05-31")
    @Pattern(regexp = ".*-.*", message = "data format error")
    private String playInfoDateEnd;


}


