package com.mkt.agent.common.player.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-03-05
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SyncTransByDayParams {

    private Integer clearDays;

    private Boolean clearCache;

    private Boolean onlyWatchNico;

    private Map<String, Object> params;
}
