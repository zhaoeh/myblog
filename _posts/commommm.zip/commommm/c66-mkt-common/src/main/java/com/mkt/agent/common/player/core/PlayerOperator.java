package com.mkt.agent.common.player.core;

import com.mkt.agent.common.config.DashBoardConfig;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.player.model.PlayerMapperHolder;
import com.mkt.agent.common.player.model.PlayerOperatorModel;
import com.mkt.agent.common.player.model.TAgentCountGroup;
import com.mkt.agent.common.player.processor.AgentTransProcessor;
import com.mkt.agent.common.player.processor.TransProcessor;
import com.mkt.agent.common.utils.DateUtils;
import com.mkt.agent.common.utils.ThreadLocalUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @description: player运算器
 * @author: ErHu.Zhao
 * @create: 2024-02-01
 **/
@Component
@Slf4j
public class PlayerOperator {

    private final AgentTransProcessor agentTransProcessor;
    private final DashBoardConfig dashBoardConfig;
    private final TransProcessor transProcessor;

    public PlayerOperator(AgentTransProcessor agentTransProcessor, DashBoardConfig dashBoardConfig, TransProcessor transProcessor) {
        this.agentTransProcessor = agentTransProcessor;
        this.dashBoardConfig = dashBoardConfig;
        this.transProcessor = transProcessor;
    }

    /**
     * 分阶段查询逻辑处理：1.执行分阶段查询场景的total size 2.根据需要重置startIndex 和 endIndex 3.执行分阶段查询请求某一页命中的查询日期集
     *
     * @param holder
     * @param model
     * @return
     */
    public void phasedHandle(PlayerMapperHolder holder, PlayerOperatorModel model) {
        Assert.notNull(holder, "holder cannot be null");
        Assert.notNull(model, "playerOperatorModel cannot be null");
        if (model.isKilled() || model.isDirectQuery()) {
            return;
        }

        // 1.设置当前查询总数
        Map<String, TAgentCountGroup> totalInfo = queryTotalInfo(holder, model);
        if (!afterRefreshTotal(model, totalInfo)) {
            return;
        }
        // 2.当忽略分页时，重置start index 和 end index
        refactorIndexWhenIgnorePagination(model);

        // 3.分阶段查询时命中目标日期集
        int iterationCount = 120;
        doHitTargetDates(model, totalInfo, 0, iterationCount);

        if (!CollectionUtils.isEmpty(model.getTargetDates())) {
            // 自然去重排序
            model.setTargetDates(model.getTargetDates().stream().distinct().sorted().collect(Collectors.toList()));
        }

    }

    /**
     * 内存分页
     *
     * @param sources    原始资源列表
     * @param comparator 自定义比较器
     * @param startIndex 开始索引
     * @param endIndex   结束索引
     * @param <T>        元素类型
     * @return 按照指定索引分页后的数据列表
     */
    public <T> List<T> pagingSources(List<T> sources, Comparator<? super T> comparator, int subtractedCount, int startIndex, int endIndex) {
        if (CollectionUtils.isEmpty(sources)) {
            return sources;
        }
        Assert.isTrue(startIndex < endIndex, "endIndex cannot be less than startIndex");
        // 对原始数据按照指定排序规则排序
        Collections.sort(sources, comparator);
        // 重新计算分页索引后，在内存中分页
        Assert.isTrue(startIndex >= subtractedCount, "startIndex error");
        Assert.isTrue(endIndex >= subtractedCount, "endIndex error");

        int startAfter = startIndex - subtractedCount;
        int endAfter = endIndex - subtractedCount;

        return sources.subList(startAfter, endAfter > sources.size() ? sources.size() : endAfter);
    }

    /**
     * 基于当前查询条件查询count总数（今天的数据会被异步更新进去，因此直接查询t_agent_count_group_day即可）
     *
     * @param model
     * @return
     */
    private Map<String, TAgentCountGroup> queryTotalInfo(PlayerMapperHolder holder, PlayerOperatorModel model) {
        // 总结果集
        TAgentCountGroup newQuery = model.getAgentCountGroup();
        // 基于当前条件，查询总count数
        log.info("基于当前条件查询总数开始，queryParam is {}", newQuery);
        List<TAgentCountGroup> totalCounts = batchQueryTAgentCountGroups(holder, newQuery);
        if (CollectionUtils.isEmpty(totalCounts)) {
            return Collections.emptyMap();
        }
        Map<String, TAgentCountGroup> totalMapping = list2MapForCountGroup(totalCounts);
        if (MapUtils.isEmpty(totalMapping)) {
            return Collections.emptyMap();
        }
        // 汇总查询结果集为总count
        TAgentCountGroup totalCount = totalCounts.stream().reduce(transProcessor::reduceAllDirectCount).orElse(null);
        Integer totalResult = Objects.isNull(totalCount) ? 0 : this.strategyTargetCount(model.getQueryType(), totalCount);
        totalMapping.put(Constants.TOTAL_SIZE, TAgentCountGroup.builder().totalCount(totalResult).build());
        log.info("基于当前条件查询总数结束，totalMapping is {}", totalMapping);
        return totalMapping;
    }

    /**
     * 针对TAgentCountGroup list转map
     *
     * @param totalCounts
     * @return
     */
    private Map<String, TAgentCountGroup> list2MapForCountGroup(List<TAgentCountGroup> totalCounts) {
        Map<String, TAgentCountGroup> resultMapping = transProcessor.groupByDashDate(totalCounts).stream().
                map(list -> list.stream().reduce(transProcessor::reduceAllDirectCount).orElse(null)).
                filter(Objects::nonNull).collect(Collectors.toMap(TAgentCountGroup::getDashDate, Function.identity(), (k1, k2) -> k2));
        return resultMapping;

    }

    /**
     * 调用BI查询当天的count总数
     *
     * @param holder
     * @param model
     * @param currentDate
     * @return
     */
    private TAgentCountGroup queryCountsForCurrentDay(PlayerMapperHolder holder, PlayerOperatorModel model, String currentDate) {
        TAgentCountGroup currentDayCount = obtainCurrentDayCount();
        if (Objects.isNull(currentDayCount)) {
            // 如果最新检索日期是今天，则实时查询BI获取目标代理集合（可能是当前代理，也可能是某批目标代理）在今天的交易流水count总数
            TAgentCountGroup request = TAgentCountGroup.builder().beginDate(currentDate).endDate(currentDate).
                    queryUsers(model.getTargetAgents()).agentName(model.getAgentName()).build();
            currentDayCount = agentTransProcessor.obtainGroupCountsOfAgentsByDayWithRuntime(holder, request);
            cacheCurrentDayCount(currentDayCount);
        }
        return currentDayCount;
    }

    /**
     * 执行命中逻辑
     *
     * @param model
     * @param lastIterationCount 上一次迭代完毕的count总数
     * @param iterationCount     外部设置的迭代次数
     */
    private void doHitTargetDates(PlayerOperatorModel model,
                                  Map<String, TAgentCountGroup> totalInfo,
                                  Integer lastIterationCount, int iterationCount) {
        Integer totalSize = Optional.ofNullable(model.getTotalSize()).orElse(0);
        if (MapUtils.isEmpty(totalInfo) || iterationCount == 0 || totalSize.equals(0)) {
            return;
        }

        if (!model.ignoreMaxCountLimit()) {
            if (lastIterationCount > model.getMaxCountLimit()) {
                return;
            }
        }

        String iterationDate = model.getIterationDate();
        TAgentCountGroup iterationGroup = totalInfo.get(iterationDate);

        // 当前增量数据
        Integer currentIncrement = Objects.isNull(iterationGroup) ? 0 : this.strategyTargetCount(model.getQueryType(), iterationGroup);
        Integer targetCount = currentIncrement + lastIterationCount;
        // 当前增量数据大于0，则继续迭代
        if (currentIncrement > 0) {
            Integer startIndex = model.getStartIndex();
            Integer endIndex = totalSize < model.getEndIndex() ? totalSize : model.getEndIndex();
            Assert.isTrue(startIndex < endIndex, "endIndex cannot be less than startIndex");

            if (targetCount > 0 && targetCount >= startIndex) {
                model.setTotalSizeWhenFirstHitStartIndex(lastIterationCount);
                model.addTargetDate(iterationDate);
            }
            if (targetCount >= endIndex) {
                model.addTargetDate(iterationDate);
                model.setTotalSizeWhenHitEndIndex(targetCount);
                return;
            }

            // 当前迭代日期命中检索条件中的开始日期时，做最后一次迭代后直接终止
            if (model.getIterationDate().equals(model.getBeginDate())) {
                model.setTotalSizeWhenHitEndIndex(targetCount);
                return;
            }
        }
        model.setIterationDate(DateUtils.localDateToString(DateUtils.stringToLocalDate(iterationDate).minusDays(1)));
        iterationCount--;
        doHitTargetDates(model, totalInfo, targetCount, iterationCount);
    }


    /**
     * 缓存首次命中的日期之前的count总数到当前线程中
     *
     * @param currentDayCount
     */
    private void cacheCurrentDayCount(TAgentCountGroup currentDayCount) {
        if (Objects.nonNull(ThreadLocalUtil.get(Constants.CURRENT_DAY_COUNT))) {
            return;
        }
        ThreadLocalUtil.set(Constants.CURRENT_DAY_COUNT, currentDayCount);
    }

    /**
     * 从当前线程中获取命中之前的总count数
     *
     * @return
     */
    private TAgentCountGroup obtainCurrentDayCount() {
        if (Objects.nonNull(ThreadLocalUtil.get(Constants.CURRENT_DAY_COUNT))) {
            return ThreadLocalUtil.get(Constants.CURRENT_DAY_COUNT);
        }
        return null;
    }

    /**
     * 缓存首次命中的日期之前的count总数到当前线程中
     *
     * @param lastIterationCount
     */
    private void cacheTargetCountBeforeHit(Integer lastIterationCount) {
        if (Objects.nonNull(ThreadLocalUtil.get(Constants.AGENT_TOTAL_COUNT_BEFORE_HIT))) {
            return;
        }
        ThreadLocalUtil.set(Constants.AGENT_TOTAL_COUNT_BEFORE_HIT, lastIterationCount);
    }

    /**
     * 从当前线程中获取命中之前的总count数
     *
     * @return
     */
    private Integer obtainTargetCountBeforeHit() {
        if (Objects.nonNull(ThreadLocalUtil.get(Constants.AGENT_TOTAL_COUNT_BEFORE_HIT))) {
            return ThreadLocalUtil.get(Constants.AGENT_TOTAL_COUNT_BEFORE_HIT);
        }
        return 0;
    }

    /**
     * 根据策略返回需要统计的count
     *
     * @return
     */
    private Integer strategyTargetCount(int queryType, TAgentCountGroup agentCountGroup) {
        Assert.notNull(agentCountGroup, "agentCountGroup cannot be null");
        if (Constants.SELF_COUNT.equals(queryType)) {
            return agentCountGroup.getSelfCount();
        }
        if (Constants.DIRECT_COUNT.equals(queryType)) {
            return agentCountGroup.getDirectCount();
        }
        if (Constants.TEAM_COUNT.equals(queryType)) {
            return agentCountGroup.getTotalCount();
        }
        return 0;
    }

    /**
     * 分批聚合
     *
     * @param holder
     * @param queryReq
     * @return
     */
    public List<TAgentCountGroup> batchQueryTAgentCountGroups(PlayerMapperHolder holder, TAgentCountGroup queryReq) {
        Function<TAgentCountGroup, List<TAgentCountGroup>> mapper = holder.getAgentCountMapper();
        if (queryReq.getTargetAgents().size() <= dashBoardConfig.getBatchQuerySize()) {
            return mapper.apply(queryReq);
        } else {
            return transProcessor.buildBatchQueryForAgents(queryReq.getTargetAgents(), queryReq).stream().map(q -> mapper.apply(q))
                    .reduce((r1, r2) -> Stream.concat(r1.stream(), r2.stream()).collect(Collectors.toList())).orElse(Collections.emptyList());
        }
    }

    /**
     * 获取totalSize
     *
     * @param totalInfo
     * @return
     */
    private boolean afterRefreshTotal(PlayerOperatorModel model, Map<String, TAgentCountGroup> totalInfo) {
        if (MapUtils.isEmpty(totalInfo)) {
            return Boolean.FALSE;
        }
        TAgentCountGroup totalSizeInfo = totalInfo.get(Constants.TOTAL_SIZE);
        if (Objects.isNull(totalSizeInfo)) {
            return Boolean.FALSE;
        }
        Integer totalSize = totalSizeInfo.getTotalCount();
        if (Objects.isNull(totalSize) || totalSize.equals(0)) {
            return Boolean.FALSE;
        }
        refreshTotal(model, totalSize);
        return Boolean.TRUE;
    }

    public void refreshTotal(PlayerOperatorModel model, Integer totalSize) {
        if (!model.ignoreMaxCountLimit()) {
            if (totalSize > model.getMaxCountLimit()) {
                totalSize = model.getMaxCountLimit();
            }
        }
        model.setTotalSize(totalSize);
        log.info("刷新total结束，model info is {}", model);
    }

    public void refactorIndexWhenIgnorePagination(PlayerOperatorModel model) {
        log.info("开始重构索引,model info is {}", model);
        if (model.isIgnorePagination()) {
            model.setStartIndex(0);
            model.setEndIndex(model.ignoreMaxCountLimit() ? model.getTotalSize() : model.getMaxCountLimit());
        }
        log.info("结束重构索引,model info is {}", model);
    }

}
