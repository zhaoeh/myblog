package com.mkt.agent.common.utils;

import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import lombok.extern.slf4j.Slf4j;
import net.glxn.qrgen.javase.QRCode;
import org.springframework.util.CollectionUtils;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * zip压缩包导出工具类
 *  Dingping.Qin
 **/
@Slf4j
public class ZipUtil {

    public static final String CHARSET = "UTF-8";

    public static final int QR_CODE_WIDTH_AND_HEIGHT = 260;

    public static final String TEMPLATE_QR_CODE_LINK = "%s?palcode=%s";

    private ZipUtil(){}

    /**
     * 通用导出方法
     * Dingping.Qin 11:28 2024/4/4
     * @param dataMap 数据map集合，key=账号名，value=二维码内容
     * @param zipFileName 下载的压缩包文件名
     */
    public static void downloadQrCodesZip(Map<String,String> dataMap, String zipFileName, HttpServletResponse response) {
        if(CollectionUtils.isEmpty(dataMap)){
            log.info("Data map is empty");
            return;
        }
        List<QRCode> qrCodes = new ArrayList<>(dataMap.size());
        List<String> qrCodeNames = new ArrayList<>();
        dataMap.forEach((key,value)->{
            QRCode qrCode = QRCode.from(value);
            // 设置字符集，支持中文
            qrCode.withCharset("utf-8");
            // 设置生成的二维码图片大小
            qrCode.withSize(QR_CODE_WIDTH_AND_HEIGHT, QR_CODE_WIDTH_AND_HEIGHT);
            qrCode.withErrorCorrection(ErrorCorrectionLevel.H);
            qrCodes.add(qrCode);
            qrCodeNames.add(key);
        });

        //设置下载格式和压缩包文件名，即在下载框默认显示的文件名
        String downloadFileName;
        try {
            downloadFileName = URLEncoder.encode(zipFileName,CHARSET);
        } catch (UnsupportedEncodingException e) {
            downloadFileName = String.valueOf(System.currentTimeMillis());
            log.error("Encode zip file name error, so system time ["+downloadFileName+"] will be used as the file name.",e);
        }
        log.info("zipFileName="+zipFileName+", downloadFileName="+downloadFileName);
        response.addHeader("Content-Disposition","attachment; filename="+downloadFileName+".zip");
        //重置response防止乱码
        //response.reset();
        //指明response的返回对象是文件流
        response.setContentType("application/octet-stream");

        try(ZipOutputStream zos = new ZipOutputStream(response.getOutputStream())){
            for (int i = 0; i < qrCodeNames.size(); i++) {
                zos.putNextEntry(new ZipEntry(qrCodeNames.get(i)+".jpg"));
                qrCodes.get(i).writeTo(zos);
                zos.closeEntry();
            }
            zos.flush();
        }catch (IOException e){
            e.printStackTrace();
            log.error("Download QR-Code-zip-file [zipFileName="+downloadFileName+"] error!",e);
        }
    }

}
