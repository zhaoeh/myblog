package com.mkt.agent.common.annotation;

import com.mkt.agent.common.constants.SQLConstants;

import java.lang.annotation.*;

@Target({ElementType.TYPE, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface Query {

    /**
     * 查询方法(默认为eq查询)
     */
    String mt() default SQLConstants.Query.EQ;

    /**
     * 是否校验参数为空(true的情况下会进行非空判断，即参数不为空的情况下才会拼接sql)
     */
    boolean check() default true;

    /**
     * 查询字段(与数据库对应实体类字段名一致，未设置时会将requestDto字段直接与数据库对应实体类字段名进行比较)
     * *不推荐使用，推荐requestDto字段直接与实体类字段保持一致
     */
    String field() default "";

    /**
     * 使用in表达式，分隔符，目前使用List去做in条件查询
     */
    String symbol() default ",";
}