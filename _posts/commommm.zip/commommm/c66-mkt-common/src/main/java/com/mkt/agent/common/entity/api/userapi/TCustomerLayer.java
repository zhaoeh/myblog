package com.mkt.agent.common.entity.api.userapi;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
@TableName("t_customer_layer")
public class TCustomerLayer {
  @TableId(type = IdType.AUTO)
  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private Long id;
  @ApiModelProperty("上级id")
  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private Long parentId;
  @ApiModelProperty("上级LoginName")
  private String parentLoginName;
  @ApiModelProperty("登录名")
  private String loginName;
  @ApiModelProperty("用户id")
  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private Long customerId;
  private String createdBy;
  private String updatedBy;
  private Long flag;
  private Date createTime;
  private Date updateTime;
}
