package com.mkt.agent.common.entity.api.agentapi.requests;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;

/**
 * @Description: 推广码查询实体类
 * @Author: PTMinnisLi
 * @Date: 2023/6/12
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AgentReferralCodeRequest {

    /**
     * REFERRAL_ID
     */
    @Column(name="REFERRAL_ID",nullable = false)
    private String referralId;

}
