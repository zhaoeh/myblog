package com.mkt.agent.common.entity.api.jobapi.requests;

import lombok.Data;

import java.time.LocalDate;

//@Repository
@Data
public class CustomerPlayInfoMonthSumRequest {


    private Long id;

    private String agentAccount;

    private String parentAccount;

    private Integer agentLevel;

    private Integer customerType;

    private Long customerId;

    private Long parentId;

    private LocalDate playInfoDate;


}
