package com.mkt.agent.common.aop;

import com.mkt.agent.common.annotation.DecryptField;
import com.mkt.agent.common.annotation.EncryptField;
import com.mkt.agent.common.utils.AesEncode;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.util.Objects;

/**
 * @Description: 安全字段加密解密切面
 * @Author: PTMinnisLi
 * @Date: 2023/6/23
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
@Aspect
@Component
@Slf4j
public class EncryptFieldAop {

    @SneakyThrows
    @Around("@annotation(com.mkt.agent.common.annotation.EncryptMethod)")
    public Object around(ProceedingJoinPoint joinPoint) throws Exception {
        Object responseObj = null;
        // 循环每个参数
        Object[] args = joinPoint.getArgs();
        for (int i = 0; i < args.length; i++) {
            Object requestObj = joinPoint.getArgs()[i];
            handleRequest(requestObj);
        }
        responseObj = joinPoint.proceed();
        handleResponse(responseObj);
        return responseObj;
    }

    /**
     * 处理request 加/解密
     *
     * @param requestObj request
     */
    private void handleRequest(Object requestObj) throws IllegalAccessException {
        if (Objects.isNull(requestObj)) {
            return;
        }
        Field[] fields = requestObj.getClass().getDeclaredFields();
        for (Field field : fields) {
            boolean hasEncryptField = field.isAnnotationPresent(EncryptField.class);
            boolean hasDecryptField = field.isAnnotationPresent(DecryptField.class);
            // 加密字段
            if (hasEncryptField) {
                field.setAccessible(true);
                String plaintextValue = (String) field.get(requestObj);
                String encryptValue = AesEncode.encrypt(plaintextValue);
                field.set(requestObj, encryptValue);
            }

            // 解密字段
            if (hasDecryptField) {
                field.setAccessible(true);
                String plaintextValue = (String) field.get(requestObj);
                String encryptValue = AesEncode.desEncrypt(plaintextValue);
                field.set(requestObj, encryptValue);
            }
        }
    }


    /**
     * 处理response 加/解密
     *
     * @param responseObj response
     */
    private Object handleResponse(Object responseObj) throws IllegalAccessException {
        if (Objects.isNull(responseObj)) {
            return null;
        }

        Field[] fields = responseObj.getClass().getDeclaredFields();
        for (Field field : fields) {
            boolean hasEncryptField = field.isAnnotationPresent(EncryptField.class);
            boolean hasDecryptField = field.isAnnotationPresent(DecryptField.class);
            // 加密字段
            if (hasEncryptField) {
                field.setAccessible(true);
                String plaintextValue = (String) field.get(responseObj);
                String encryptValue = AesEncode.encrypt(plaintextValue);
                field.set(responseObj, encryptValue);
            }

            // 解密字段
            if (hasDecryptField) {
                field.setAccessible(true);
                String plaintextValue = (String) field.get(responseObj);
                String encryptValue = AesEncode.desEncrypt(plaintextValue);
                field.set(responseObj, encryptValue);
            }
        }
        return responseObj;
    }

}
