package com.mkt.agent.common.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * @ClassName SignatureUtil
 * @Description SignatureUtil 加签
 * @Author Amida
 **/
public class SignatureUtil {


    private static final String ALGORITHM = "SHA-256";

    /**
     * @ClassName SignatureUtil
     * @Description SignatureUtil 加签
     * @Author Amida
     **/

    public static String generateSignature(String signInfo, String format) throws RuntimeException {


        try {
            MessageDigest md = MessageDigest.getInstance(ALGORITHM);
            byte[] hashBytes = md.digest(signInfo.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format(format, b));
            }

            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Failed to generate signature", e);
        }

    }

}
