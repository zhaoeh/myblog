package com.mkt.agent.common.aop;

import com.mkt.agent.common.annotation.HtmlEscape;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import java.lang.reflect.Field;
import java.util.Objects;

/**
 * 对入参对象中标注HtmlEscape的字段且为String类型的，进行html转移，防止xss攻击
 */
@Aspect
@Component
@Slf4j
public class HtmlEscapeAop {

    @SneakyThrows
    @Before("@annotation(com.mkt.agent.common.annotation.EnableHtmlEscape)")
    public void htmlEscape(JoinPoint joinPoint) {
        Object[] args = joinPoint.getArgs();
        if (Objects.isNull(args)) {
            return;
        }
        for (Object arg : args) {
            checkFields(arg);
        }

    }

    private void checkFields(Object arg) throws IllegalAccessException {
        if (Objects.isNull(arg)) {
            return;
        }
        Field[] fields = arg.getClass().getDeclaredFields();
        for (Field field : fields) {
            if (String.class.equals(field.getType()) && field.isAnnotationPresent(HtmlEscape.class)) {
                field.setAccessible(true);
                Object value = field.get(arg);
                if (Objects.isNull(value)) {
                    return;
                }
                String valueInUse = Objects.toString(value);
                if (StringUtils.isBlank(valueInUse)) {
                    return;
                }
                field.set(arg, HtmlUtils.htmlEscape(valueInUse));
            }
        }
    }
}
