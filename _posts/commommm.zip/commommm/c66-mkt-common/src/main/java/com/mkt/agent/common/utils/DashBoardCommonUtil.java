package com.mkt.agent.common.utils;

import com.google.gson.Gson;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.commissionapi.requests.CommissionRecordDashBoardRequest;
import com.mkt.agent.common.entity.api.commissionapi.responses.CommissionRecordDashBoardResponse;
import com.mkt.agent.common.entity.api.commissionapi.table.DashBoardHistoryEntity;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import com.mkt.agent.common.entity.clickhouse.resp.ClDashBoardDataRes;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverDistriResp;
import com.mkt.agent.common.enums.CommissionPlanTypeEnum;
import com.mkt.agent.common.enums.DashboardChosenTimeEnum;
import com.mkt.agent.common.enums.GameTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

/**
 * @Description TODO
 * @Classname DashBoardCommonUtil
 * @Date 2023/12/6 14:35
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class DashBoardCommonUtil {

    @Autowired
    private RedisUtil redisUtil;

    private Gson gson = new Gson();

    /**
     * description: 把当月仪表盘数据放入缓存
     * @param:  [dashBoardResponsesList]
     * @return: void
     * @Date: 2023/12/7 14:47
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public void saveRedisForDashBoard(List<DashBoardHistoryEntity> dashBoardResponsesList){

        //存入redis
        dashBoardResponsesList.forEach(entity -> {
            String key = Constants.CURRENT_USER_DASH_BOARD_CACHE_PREFIX + entity.getLoginName() + entity.getDashDate();
            String value = gson.toJson(entity);
            redisUtil.setByTimeUnit(key,value, 27, TimeUnit.HOURS);
        });

    }

    /**
     * description: 从缓存中取当月历史数据
     * @param:  [dashBoardResponsesList]
     * @return: void
     * @Date: 2023/12/7 14:47
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public List<DashBoardHistoryEntity> getRedisForDashBoardByDay(List<String> names,String date){

        List<DashBoardHistoryEntity> list = new ArrayList<>();

        log.info("Begin to get redis data!");

        //存入redis 多存一天
        names.forEach(name -> {

            String key = Constants.CURRENT_USER_DASH_BOARD_CACHE_PREFIX + name + date;
            Object commissionValue = redisUtil.get(key);
            if(!Objects.isNull(commissionValue)){
                DashBoardHistoryEntity cacheValue = Optional.ofNullable(commissionValue).map(v -> gson.fromJson(v.toString(), DashBoardHistoryEntity.class)).
                        orElseGet(DashBoardHistoryEntity::new);
                list.add(cacheValue);
            }

        });

        return list;

    }


    /**
     * description: 计算日期
     * @param:  [req]
     * @return: void
     * @Date: 2023/11/22 14:05
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public ClDashBoardCreateQueryReq getNeededRecordDate(CommissionRecordDashBoardRequest req){
        ClDashBoardCreateQueryReq dashBoardCreateQueryReq = null;
        String chosenType = req.getChosenType();
        String chosenPeriod = req.getChosenPeriod();

        //月类型
        if(chosenType.equals(DashboardChosenTimeEnum.ChosenType_Month.getName())){

            if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Current.getName())){
                //当前月
                req.setRecordDateStart(DateUtils.getLastNMonthFirstDay(0).toString());
                req.setRecordDateEnd(DateUtils.getLastNMonthLastDay(0).toString());
                req.setRecordDateTimeStart(DateUtils.getLastNMonthFirstDay(0)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEnd(DateUtils.getLastNMonthLastDay(0)+ BaseConstants.END_TIME);
                dashBoardCreateQueryReq = buildClDashBoardCreateQueryReq(req.getLoginName(), req.getRecordDateStart(), req.getRecordDateEnd(), req.getRecordDateTimeStart(), req.getRecordDateTimeEnd());
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last.getName())){
                //上一个月
                req.setRecordDateStartLast(DateUtils.getLastNMonthFirstDay(1).toString());
                req.setRecordDateEndLast(DateUtils.getLastNMonthLastDay(1).toString());
                req.setRecordDateTimeStartLast(DateUtils.getLastNMonthFirstDay(1)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLast(DateUtils.getLastNMonthLastDay(1)+ BaseConstants.END_TIME);
                dashBoardCreateQueryReq = buildClDashBoardCreateQueryReq(req.getLoginName(), req.getRecordDateStartLast(), req.getRecordDateEndLast(), req.getRecordDateTimeStartLast(), req.getRecordDateTimeEndLast());
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last_Two.getName())){
                //上两个月
                req.setRecordDateStartLastTwo(DateUtils.getLastNMonthFirstDay(2).toString());
                req.setRecordDateEndLastTwo(DateUtils.getLastNMonthLastDay(2).toString());
                req.setRecordDateTimeStartLastTwo(DateUtils.getLastNMonthFirstDay(2)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLastTwo(DateUtils.getLastNMonthLastDay(2)+ BaseConstants.END_TIME);
                dashBoardCreateQueryReq = buildClDashBoardCreateQueryReq(req.getLoginName(), req.getRecordDateStartLastTwo(), req.getRecordDateEndLastTwo(), req.getRecordDateTimeEndLastTwo(), req.getRecordDateTimeStartLastTwo());
            }
        }else if(chosenType.equals(DashboardChosenTimeEnum.ChosenType_Week.getName())){
            if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Current.getName())){
                //当前周
                req.setRecordDateStart(DateUtils.getNWeeksAgoMonday(0).toString());
                req.setRecordDateEnd(DateUtils.getNWeeksAgoSunday(0).toString());
                req.setRecordDateTimeStart(DateUtils.getNWeeksAgoMonday(0)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEnd(DateUtils.getNWeeksAgoSunday(0)+ BaseConstants.END_TIME);
                dashBoardCreateQueryReq = buildClDashBoardCreateQueryReq(req.getLoginName(), req.getRecordDateStart(), req.getRecordDateEnd(), req.getRecordDateTimeStart(), req.getRecordDateTimeEnd());
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last.getName())){
                //上一个周
                req.setRecordDateStartLast(DateUtils.getNWeeksAgoMonday(1).toString());
                req.setRecordDateEndLast(DateUtils.getNWeeksAgoSunday(1).toString());
                req.setRecordDateTimeStartLast(DateUtils.getNWeeksAgoMonday(1)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLast(DateUtils.getNWeeksAgoSunday(1)+ BaseConstants.END_TIME);
                dashBoardCreateQueryReq = buildClDashBoardCreateQueryReq(req.getLoginName(), req.getRecordDateStartLast(), req.getRecordDateEndLast(), req.getRecordDateTimeStartLast(), req.getRecordDateTimeEndLast());
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last_Two.getName())){
                //上两个周
                req.setRecordDateStartLastTwo(DateUtils.getNWeeksAgoMonday(2).toString());
                req.setRecordDateEndLastTwo(DateUtils.getNWeeksAgoSunday(2).toString());
                req.setRecordDateTimeStartLastTwo(DateUtils.getNWeeksAgoMonday(2)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLastTwo(DateUtils.getNWeeksAgoSunday(2)+ BaseConstants.END_TIME);
                dashBoardCreateQueryReq = buildClDashBoardCreateQueryReq(req.getLoginName(), req.getRecordDateStartLastTwo(), req.getRecordDateEndLastTwo(), req.getRecordDateTimeEndLastTwo(), req.getRecordDateTimeStartLastTwo());
            }
        }else if(chosenType.equals(DashboardChosenTimeEnum.ChosenType_Day.getName())){
            if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Current.getName())){
                //当天
                req.setRecordDateStart(DateUtils.getNDaysAgo(0).toString());
                req.setRecordDateEnd(DateUtils.getNDaysAgo(0).toString());
                req.setRecordDateTimeStart(DateUtils.getNDaysAgo(0)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEnd(DateUtils.getNDaysAgo(0)+ BaseConstants.END_TIME);
                dashBoardCreateQueryReq = buildClDashBoardCreateQueryReq(req.getLoginName(), req.getRecordDateStart(), req.getRecordDateEnd(), req.getRecordDateTimeStart(), req.getRecordDateTimeEnd());
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last.getName())){
                //昨天
                req.setRecordDateStartLast(DateUtils.getNDaysAgo(1).toString());
                req.setRecordDateEndLast(DateUtils.getNDaysAgo(1).toString());
                req.setRecordDateTimeStartLast(DateUtils.getNDaysAgo(1)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLast(DateUtils.getNDaysAgo(1)+ BaseConstants.END_TIME);
                dashBoardCreateQueryReq = buildClDashBoardCreateQueryReq(req.getLoginName(), req.getRecordDateStartLast(), req.getRecordDateEndLast(), req.getRecordDateTimeStartLast(), req.getRecordDateTimeEndLast());
            }else if(chosenPeriod.equals(DashboardChosenTimeEnum.ChosenPeriod_Last_Two.getName())){
                //前天
                req.setRecordDateStartLastTwo(DateUtils.getNDaysAgo(2).toString());
                req.setRecordDateEndLastTwo(DateUtils.getNDaysAgo(2).toString());
                req.setRecordDateTimeStartLastTwo(DateUtils.getNDaysAgo(2)+ BaseConstants.START_TIME);
                req.setRecordDateTimeEndLastTwo(DateUtils.getNDaysAgo(2)+ BaseConstants.END_TIME);
                dashBoardCreateQueryReq = buildClDashBoardCreateQueryReq(req.getLoginName(), req.getRecordDateStartLastTwo(), req.getRecordDateEndLastTwo(), req.getRecordDateTimeEndLastTwo(), req.getRecordDateTimeStartLastTwo());
            }
        }
        log.info("handle date finished. The date is:{}",req);
        if(Objects.isNull(dashBoardCreateQueryReq)){
            throw new IllegalArgumentException("chosenType 或者 chosenPeriod 传入错误");
        }
        return dashBoardCreateQueryReq;
    }


    private ClDashBoardCreateQueryReq buildClDashBoardCreateQueryReq(String agentAccount, String recordDateStart, String recordDateEnd, String recordDateTimeStart, String recordDateTimeEnd) {
        ClDashBoardCreateQueryReq queryReq = ClDashBoardCreateQueryReq.builder().agentAccount(agentAccount).recordDateStart(recordDateStart).recordDateEnd(recordDateEnd)
                .recordDateTimeStart(recordDateTimeStart).recordDateTimeEnd(recordDateTimeEnd).build();
        return queryReq;
    }

    public CommissionRecordDashBoardResponse sumDataResultV1(CommissionRecordDashBoardResponse source,CommissionRecordDashBoardResponse increment){
        if(!Objects.isNull(increment)&&!Objects.isNull(source)){
            log.info("begin to sub data from increment:{} to source:{} ",increment,source);
            source.setFirstDepositPlayers(source.getFirstDepositPlayers()+increment.getFirstDepositPlayers());
            source.setBetPlayers(source.getBetPlayers()+increment.getBetPlayers());
            source.setTurnover(source.getTurnover().add(increment.getTurnover()));
            source.setGgr(source.getGgr().add(increment.getGgr()));
            source.setFirstDepositAmount(source.getFirstDepositAmount().add(increment.getFirstDepositAmount()));
            source.setDeposit(source.getDeposit().add(increment.getDeposit()));
            source.setWithdraw(source.getWithdraw().add(increment.getWithdraw()));
        }
        log.info("finished sub data, result is:{}",source);
        return source;
    }

    public DashBoardHistoryEntity sumDataResultV2(DashBoardHistoryEntity source,DashBoardHistoryEntity increment){
        if(!Objects.isNull(increment)&&!Objects.isNull(source)){
            log.info("begin to sub data from increment:{} to source:{} ",increment,source);
            source.setFirstDepositPlayers(source.getFirstDepositPlayers()+increment.getFirstDepositPlayers());
            source.setBetPlayers(source.getBetPlayers()+increment.getBetPlayers());
            source.setTurnover(source.getTurnover().add(increment.getTurnover()));
            source.setGgr(source.getGgr().add(increment.getGgr()));
            source.setFirstDepositAmount(source.getFirstDepositAmount().add(increment.getFirstDepositAmount()));
            source.setDeposit(source.getDeposit().add(increment.getDeposit()));
            source.setWithdraw(source.getWithdraw().add(increment.getWithdraw()));
        }
        log.info("finished sub data, result is:{}",source);
        return source;
    }


    /**
     * description: 判断结果是否需要入表1
     * @param:  [response]
     * @return: boolean
     * @Date: 2023/12/15 16:17
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public boolean isNeededSave(CommissionRecordDashBoardResponse response){

        boolean flag = false;

        if(!Objects.isNull(response)){
            if(response.getGgr().compareTo(BigDecimal.ZERO) > 0 || response.getTurnover().compareTo(BigDecimal.ZERO) > 0
                    || response.getBetPlayers() > 0 || response.getWithdraw().compareTo(BigDecimal.ZERO) > 0 || response.getDeposit().compareTo(BigDecimal.ZERO) > 0
                    || response.getWinorloss().compareTo(BigDecimal.ZERO) > 0 || response.getFirstDepositAmount().compareTo(BigDecimal.ZERO) > 0 || response.getFirstDepositPlayers() >0
                    || response.getRegistrationNumber() > 0){
                flag = true;
            }
        }

        return flag;

    }


    public boolean isNeededSave2(DashBoardHistoryEntity response){

        boolean flag = false;

        if(!Objects.isNull(response)){
            if(response.getGgr().compareTo(BigDecimal.ZERO) > 0 || response.getTurnover().compareTo(BigDecimal.ZERO) > 0
                    || response.getBetPlayers() > 0 || response.getWithdraw().compareTo(BigDecimal.ZERO) > 0 || response.getDeposit().compareTo(BigDecimal.ZERO) > 0
                    || response.getWinorloss().compareTo(BigDecimal.ZERO) > 0 || response.getFirstDepositAmount().compareTo(BigDecimal.ZERO) > 0 || response.getFirstDepositPlayers() >0
                    || response.getRegistrationNumber() > 0){
                flag = true;
            }
        }

        return flag;

    }

}
