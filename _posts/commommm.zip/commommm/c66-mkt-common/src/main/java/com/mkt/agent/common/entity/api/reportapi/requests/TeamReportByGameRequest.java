package com.mkt.agent.common.entity.api.reportapi.requests;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(value = "TeamReportByGameRequest")
public class TeamReportByGameRequest implements Serializable {


    private static final long serialVersionUID = 1l;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount", example = "brewtest1")
    private String agentAccount;

    // 佣金记录查询开始产生时间
    @ApiModelProperty(value = "date", example = "2023-01-17")
    private String date;

    // 佣金记录查询结束时间产生时间
    @ApiModelProperty(value = "month", example = "2023-01")
    private String month;

    //当前登录用户
    @ApiModelProperty(value = "loginName", example = "brewtest1")
    private String loginName;

}


