package com.mkt.agent.common.utils;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.groups.Default;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 校验工具类
 * <p>
 * ValidationResult result = ValidationUtils.validateEntity(obj); // 校验实体
 * ValidationResult result = ValidationUtils.validateProperty(obj,"name")//校验属性;
 * result.isHasErrors();//是否有错误
 * result.getErrorMessage();//取得错误信息
 */
public class ValidationUtils {
    /**
     * 默认校验工厂 生产的 validator
     * 也可以通过博客中 配置类注入
     */
    private static Validator validator = Validation.buildDefaultValidatorFactory().getValidator();

    /**
     * 对 整个 对象进行校验
     *
     * @param <T>object    对象
     * @return ValidationResult 校验结果
     */
    public static <T> ValidationResult validateEntity(T object) {
        return validateEntity(object, new Class[]{Default.class});
    }

    /**
     * 对 整个 对象进行校验
     *
     * @param <T>object 对象
     * @param aClass    group分组
     * @return ValidationResult 校验结果
     */
    public static <T> ValidationResult validateEntity(T object, Class<?>[] aClass) {
        ValidationResult result = new ValidationResult();
        // 使用默认分组 Default.class
        Set<ConstraintViolation<T>> set = validator.validate(object, aClass);
        if (set != null && !set.isEmpty()) {
            result.setHasErrors(true);
            Map<String, String> errorMsg = new HashMap<>(5);
            for (ConstraintViolation<T> constraintViolation : set) {
                // propertyPath: 从北验证跟对象到被验证的属性的路径 message: 错误信息
                errorMsg.put(constraintViolation.getPropertyPath().toString(), constraintViolation.getMessage());
            }
            result.setErrorMsg(errorMsg);
        }
        return result;
    }

    /**
     * 对 对象中的 某个属性进行校验
     *
     * @param <T>object    对象
     * @param propertyName 属性名称
     * @return ValidationResult 校验结果
     */
    public static <T> ValidationResult validateProperty(T object, String propertyName) {
        ValidationResult result = new ValidationResult();
        Set<ConstraintViolation<T>> set = validator.validateProperty(object, propertyName, Default.class);
        if (set != null && !set.isEmpty()) {
            result.setHasErrors(true);
            Map<String, String> errorMsg = new HashMap<>(5);
            for (ConstraintViolation<T> constraintViolation : set) {
                errorMsg.put(propertyName, constraintViolation.getMessage());
            }
            result.setErrorMsg(errorMsg);
        }
        return result;
    }

    public static ValidationResult checkPhoneNumFormat(String temp) {
        ValidationResult result = new ValidationResult();
        Map<String, String> errorMsg = new HashMap<>(1);
        if (StringUtils.isEmpty(temp)) {
            result.setHasErrors(true);
            errorMsg.put("phone","cannot be empty");
            result.setErrorMsg(errorMsg);
            return result;
        }
        String regex = "^\\d[1-9]\\d{8}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(temp);
        boolean matcherResult = matcher.matches();
        if (!matcherResult) {
            result.setHasErrors(true);
            errorMsg.put("phone","cannot be empty");
            result.setErrorMsg(errorMsg);
        }
        return result;
    }


    @Data
    public static class ValidationResult {

        /**
         * 校验结果是否有错
         */
        private boolean hasErrors;

        /**
         * 校验错误信息
         */
        private Map<String, String> errorMsg;

    }
}
