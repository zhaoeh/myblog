package com.mkt.agent.common.entity.api.agentapi.requests;

import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @ClassName TAgentCustomersReq
 * @Author TJSAustin
 * @Date 2023/5/25 10:00
 * @Version 1.0
 **/
@Data
@NoArgsConstructor
public class TAgentCustomersRemarkReq {


    /*
        登录名
    */
    @ApiModelProperty(value = "登录名")
    @NotBlank(message = "loginName is not blank",groups = InputValidationGroup.Update.class)
    private String loginName;

    /*
        customersId
    */
    @ApiModelProperty(name="CUSTOMERS_ID")
    @NotNull(message = "customersId is not blank",groups = InputValidationGroup.Update.class)
    private Long customersId;


    /*
        备注
    */
    @ApiModelProperty(name="remark  [字段长度小于200]")
    @NotBlank(message = "remarks is not blank",groups = InputValidationGroup.Update.class)
    @Length(message = "remarks length must <= 200")
    private String remarks;


    @Override
    public String toString() {
        return "TAgentCustomersRemarkReq{" +
                "loginName='" + loginName + '\'' +
                ", customersId=" + customersId +
                ", remarks='" + remarks + '\'' +
                '}';
    }
}
