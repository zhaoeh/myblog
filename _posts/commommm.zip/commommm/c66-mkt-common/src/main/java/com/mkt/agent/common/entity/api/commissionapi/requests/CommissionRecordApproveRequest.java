package com.mkt.agent.common.entity.api.commissionapi.requests;

import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(value = "CommissionRecordListRequest", description = "Commission Record Query Request")
public class CommissionRecordApproveRequest extends CommissionRecordListRequest implements Serializable {


}


