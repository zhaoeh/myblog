package com.mkt.agent.common.entity.clickhouse;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Description TODO
 * @Classname DailyOrderAll
 * @Date 2023/11/22 14:44
 * @Created by TJSLucian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DailyOrderAll {

    private String billDate;

    private String loginName;
    /**
     * 渠道类型 1: Market,
     * 2:Website,
     */
    private String channel;

    /**
     * 用户注册终端 1:web,2:android,3:ios,4:h5,6:glife,7:maya,8:lazada
     */
    private String registerSource;

    /**
     * 用户注册方式 1:username+pwd,2:phone,3:completely register,4:email,5:google,6:facebook,7:vistor,8:glife,9:maya,10:lazada
     */
    private String registerWay;

    /**
     * 游戏id
     */
    private String gameId;

    /**
     *版本时间
     */
    private String versionTime;

    /**
     *用户注册站点（1、bingoplus；2、ArenaPlus）
     */
    private String siteId;


    /**
     * 网站类别,
     * 投注时网站id（1、bingoplus；2、ArenaPlus）
     */
    private String betSiteId;

    /**
     *是否首存:1是,0否 (存款报表根据此字段统计 首存即可)
     */
    private String firstDeposit;

    /**
     *首充时间
     */
    private String firstDepositTime;

    /**
     *游戏大类
     */
    private String gameType;

    /**
     * 注册时间
     */
    private String registeredTime;

    /**
     * 投注额汇总
     */
    private String bet_amount;

    /**
     * 当日盈利ggr
     */
    private String ggr;

    /**
     * 当日有效投注金额（有效投注额）
     */
    private String turnover;

    /**
     * 当日盈利率
     */
    private String profitability;

    /**
     * 游戏厅id
     */
    private String platformId;
    /**
     * 游戏名称
     */
    private String game_platform;

}
