package com.mkt.agent.common.entity.api.agentapi.requests;

import com.mkt.agent.common.entity.PageRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(value = "AgentQueryByPageRequest")
public class AgentQueryByPageRequest extends PageRequest implements Serializable {


    private static final long serialVersionUID = 1l;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "parentAccount")
    private String parentAccount;

    @ApiModelProperty(value = "agentLevel")
    private Integer agentLevel;

}


