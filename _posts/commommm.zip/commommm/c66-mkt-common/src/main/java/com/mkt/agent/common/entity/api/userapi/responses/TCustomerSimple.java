package com.mkt.agent.common.entity.api.userapi.responses;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class TCustomerSimple {
    @ApiModelProperty("登陆名")
    private String loginName;
    @ApiModelProperty("父级代理名")
    private String parentloginName;
    @ApiModelProperty("用户id")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long customerId;
    @ApiModelProperty("用户父级id")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long parentId;
    @ApiModelProperty("代理级别")
    private Integer agentLevel;
    @ApiModelProperty("客户类型")
    private Integer customerType;

}
