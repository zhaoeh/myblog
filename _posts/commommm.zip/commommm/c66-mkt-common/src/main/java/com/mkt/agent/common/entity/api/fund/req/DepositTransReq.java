package com.mkt.agent.common.entity.api.fund.req;

import com.mkt.agent.common.entity.PageReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @ClassName DepositTransReq
 * @Description 存款提案审批
 * @Author TJSAlex
 * @Date 2023/6/30 12:17
 * @Version 1.0
 **/
@Data
public class DepositTransReq extends PageReq {
    @ApiModelProperty(value = "customerId")
    @NotNull(message = "customerId is required!")
    private Long customerId;
    @ApiModelProperty(value = "loginName")
    @NotBlank(message = "loginName is required!")
    private String loginName;
    @ApiModelProperty(value = "orderId")
    @NotBlank(message = "orderId is required!")
    private String orderId;
    @ApiModelProperty(value = "status")
    private Integer status;
}
