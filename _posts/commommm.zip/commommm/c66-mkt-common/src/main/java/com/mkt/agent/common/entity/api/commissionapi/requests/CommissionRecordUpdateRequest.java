package com.mkt.agent.common.entity.api.commissionapi.requests;


import com.mkt.agent.common.annotation.DecryptField;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

@Data
@ApiModel(value = "CommissionRecordUpdateRequest", description = "Commission Record Approve Request")
@ToString(exclude = {"password"})
public class CommissionRecordUpdateRequest implements Serializable {

    private static final long serialVersionUID = 1l;


    // 佣金记录id：佣金记录唯一标识
    @ApiModelProperty(value = "commissionRecordId")
    @NotNull
    private Long commissionRecordId;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount")
    private String agentAccount;

    // 实际佣金金额：由管理运营人员结算给订单代理或代理结算给下级代理
    @ApiModelProperty(value = "actualCommissionAmount")
    private BigDecimal actualCommissionAmount;

    // 佣金记录状态：0:清算中pending,1:同意agreed,2:拒绝rejected
    private Integer status;

    @DecryptField
    private String password;


}
