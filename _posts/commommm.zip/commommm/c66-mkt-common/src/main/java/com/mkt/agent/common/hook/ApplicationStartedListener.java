package com.mkt.agent.common.hook;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

/**
 * @description: 应用完成启动监听器
 * @author: ErHu.Zhao
 * @create: 2023-12-30
 **/
@Component
@Slf4j
public class ApplicationStartedListener implements ApplicationListener<ApplicationStartedEvent> {
    @Override
    public void onApplicationEvent(ApplicationStartedEvent event) {
        Environment environment = Optional.ofNullable(event).map(ApplicationStartedEvent::getApplicationContext).map(ConfigurableApplicationContext::getEnvironment).orElse(null);
        if (Objects.nonNull(environment)) {
            String port = environment.getProperty("server.port");
            String applicationName = environment.getProperty("spring.application.name");
            log.info("应用[{}]启动完毕，端口为[{}]", applicationName, port);
        }
    }
}
