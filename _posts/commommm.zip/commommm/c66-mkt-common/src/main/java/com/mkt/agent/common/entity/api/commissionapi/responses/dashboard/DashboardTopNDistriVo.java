package com.mkt.agent.common.entity.api.commissionapi.responses.dashboard;

import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverDistriResp;
import com.mkt.agent.common.entity.clickhouse.resp.ClTurnoverTopResp;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description TODO
 * @Classname DashboardTopNDistriVo
 * @Date 2024/1/5 16:09
 * @Created by TJSLucian
 */
@Data
public class DashboardTopNDistriVo {

    private List<ClTurnoverDistriResp> distriRespList = new ArrayList<>();

    private List<ClTurnoverTopResp> topRespList = new ArrayList<>();

}
