package com.mkt.agent.common.entity.api.agentapi.requests;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value = "AgentCustomerQueryRequest")
public class AgentCustomerQueryRequest {


    private static final long serialVersionUID = 1l;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount")
    private String agentAccount;

}


