package com.mkt.agent.common.fast.listener;

import com.alibaba.nacos.common.utils.CollectionUtils;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.fast.core.FastConfig;
import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.common.fast.core.FastCore;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import com.mkt.agent.common.fast.event.RegisterUsersEvent;
import com.mkt.agent.common.fast.remediation.DesensMappingOfAgentRemediation;
import com.mkt.agent.common.fast.remediation.TransferOfUserRemediation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

/**
 * @description: 注册用户事件监听器
 * @author: ErHu.Zhao
 * @create: 2024-04-04
 **/
@Component
@Slf4j
public class RegisterUsersListener implements ApplicationListener<RegisterUsersEvent> {
    private static ExecutorService executorService = Executors.newSingleThreadExecutor();

    private final DesensMappingOfAgentRemediation desensMappingOfAgentRemediation;

    private final FastCore fastCore;

    private final TransferOfUserRemediation transferOfUserRemediation;

    private final FastConfig fastConfig;

    public RegisterUsersListener(DesensMappingOfAgentRemediation desensMappingOfAgentRemediation,
                                 FastCore fastCore,
                                 TransferOfUserRemediation transferOfUserRemediation,
                                 FastConfig fastConfig) {
        this.desensMappingOfAgentRemediation = desensMappingOfAgentRemediation;
        this.fastCore = fastCore;
        this.transferOfUserRemediation = transferOfUserRemediation;
        this.fastConfig = fastConfig;
    }

    @Override
    public void onApplicationEvent(RegisterUsersEvent event) {
        if (BooleanUtils.isFalse(fastConfig.getFastSwitch())) {
            log.info("fast switch is close,stop do it");
            return;
        }
        List<TCustomerLayer> users = event.getUsers();
        SqlSessionFactory factory = event.getFactory();
        FastContext fastContext = event.getFastContext();
        if (CollectionUtils.isEmpty(users)) {
            return;
        }
        if (Objects.nonNull(executorService)) {
            executorService.submit(() -> triggerOnRegisterUsers(fastContext, factory, users));
        } else {
            triggerOnRegisterUsers(fastContext, factory, users);
        }
    }

    private void triggerOnRegisterUsers(FastContext fastContext, SqlSessionFactory factory, List<TCustomerLayer> players) {
        try {
            log.info("begin triggerOnRegisterUsers");
            if (CollectionUtils.isEmpty(players)) {
                return;
            }

            players = fastContext.getQueryPlayersByNames().apply(players.stream().map(TCustomerLayer::getLoginName).collect(Collectors.toList()));
            List<TAgentCustomers> relationAgents = fastCore.obtainRelationAgentsFromUsers(players);
            if (CollectionUtils.isEmpty(relationAgents)) {
                return;
            }

            boolean result = desensMappingOfAgentRemediation.doDesensMappingOfAgentRemediation(fastContext, StrategyEnums.ListenerDesensMappingStrategy, relationAgents.stream().map(TAgentCustomers::getLoginName).collect(Collectors.toList()));
            if (result) {
                transferOfUserRemediation.doTransferOfUserRemediation(fastContext, StrategyEnums.ListenerTransferOfUserStrategy, factory, relationAgents, players);
            }
            log.info("end triggerOnRegisterUsers");
        } catch (Exception e) {
            log.error("triggerOnRegisterUsers error.");
        }
    }
}
