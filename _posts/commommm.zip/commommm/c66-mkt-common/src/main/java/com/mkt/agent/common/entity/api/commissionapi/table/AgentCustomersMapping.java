package com.mkt.agent.common.entity.api.commissionapi.table;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Builder;
import lombok.Data;

/**
 * @description: t_agent_customers_mapping
 * @author: ErHu.Zhao
 * @create: 2024-03-28
 **/
@Data
@Builder
@TableName("t_agent_customers_mapping")
public class AgentCustomersMapping {

    @TableId
    private Long id;

    /**
     * 代理账号
     */
    @TableField("agent_name")
    private String agentName;

    /**
     * 对应的映射字段
     */
    @TableField("agent_mapping")
    private String agentMapping;
}
