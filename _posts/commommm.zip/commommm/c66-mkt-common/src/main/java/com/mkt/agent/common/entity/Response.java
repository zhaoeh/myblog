package com.mkt.agent.common.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

public class Response<T> implements Serializable {
	@ApiModelProperty("响应头，返回提示信息")
	private Head head;

	@ApiModelProperty("响应体，返回数据")
	@JsonProperty("body") 
	private T t;

	public Response() {
		head = new Head();
	}

	public Response(String errCode, String errMsg) {
		head = new Head(errCode, errMsg);
	}

	public void setHead(String errCode, String errMsg) {
		head.setErrCode(errCode);
		head.setErrMsg(errMsg);
	}
	
	public void setHead(Head head) {
		this.head = head;
	}

	public Head getHead() {
		return head;
	}
	
	public void setCost(Long x) {
		head.setCost(x);
	}
	
	public boolean isSuccess() {
		if ("0000".equals(head.getErrCode())) {
			return true;
		} else {
			return false;
		}
	}

	public T getBody() {
		return t;
	}

	public void setBody(T t) {
		this.t = t;
	}

    public static class Head implements Serializable {
		@ApiModelProperty("错误代码[默认：0000，表示无错误]")
		private String errCode = "0000";
		@ApiModelProperty("错误消息[默认：操作成功]")
		private String errMsg = "操作成功";
		@ApiModelProperty("耗时[毫秒]")
		private Long cost = 0L;
		@ApiModelProperty("错误码提示根据{}标识依次格式化动态传入数据")
		private Object[] formatData;

		public Head() {

		}

		public Head(String errCode, String errMsg) {
			this.errCode = errCode;
			this.errMsg = errMsg;
		}

		public Head(String errCode, String errMsg, Object[] formatData) {
			this.errCode = errCode;
			this.errMsg = errMsg;
			this.formatData = formatData;
		}

		public String getErrCode() {
			return errCode;
		}

		public void setErrCode(String errCode) {
			this.errCode = errCode;
		}

		public String getErrMsg() {
			return errMsg;
		}

		public void setErrMsg(String errMsg) {
			this.errMsg = errMsg;
		}

		public Long getCost() {
			return cost;
		}

		public void setCost(Long cost) {
			this.cost = cost;
		}

		public Object[] getFormatData() {
			return formatData;
		}

		public void setFormatData(Object[] formatData) {
			this.formatData = formatData;
		}
	}
}

