package com.mkt.agent.common.entity.api.agentapi.requests;

import com.mkt.agent.common.entity.PageRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(value = "AgentCustomerQueryByPageRequest")
public class AgentCustomerQueryByPageRequest extends PageRequest implements Serializable {


    private static final long serialVersionUID = 1l;

    // 产品名称：ex:bingoplus,areana 默认值all_type
    @ApiModelProperty(value = "customerId")
    private Long customerId;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount")
    private String agentAccount;


    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "parentAccount")
    private String parentAccount;

    // 1玩家，3代理
    @ApiModelProperty(value = "customerType")
    private Integer customerType;

    // 代理类型：0：General Line (普通代理)，1：Professional Line(专业代理可发展下级)
    @ApiModelProperty(value = "agentType")
    private Integer agentType;

    @ApiModelProperty(value = "agentLevel")
    private Integer agentLevel;
    // 产品名称：ex:bingoplus,areana 默认值all_type
    @ApiModelProperty(value = "siteId")
    private Integer siteId;


}


