package com.mkt.agent.common.entity.api.commissionapi.responses;


import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
@ApiModel(description = "佣金计算参数信息")
public class CommissionRecordPlanResponse {

    // 佣金记录创建时间
    @ApiModelProperty(value = "createTime", example = "05/18/2023 08:30:45")
    private String createTime;

    @ApiModelProperty(value = "commissionType")
    private String commissionType;

    @ApiModelProperty(value = "settlementPeriod")
    private String settlementPeriod;

    @ApiModelProperty(value = "settlementConditions")
    private Integer settlementConditions;

    @ApiModelProperty(value = "activeUserTurnover")
    private Integer activeUserTurnover;

    @ApiModelProperty(value = "activeUserHeadcount")
    private Integer activeUserHeadcount;

    @ApiModelProperty(value = "actualUserCount")
    private Integer actualUserCount;

    @ApiModelProperty(value = "commissionValues")
    private String commissionValues;

    @ApiModelProperty(value = "commissionValue")
    private BigDecimal commissionValue;

    @ApiModelProperty(value = "detailJSONObject")
    private JSONObject detailJSONObject;

    @ApiModelProperty(value = "activeUserTurnover1")
    private BigDecimal  activeUserTurnover1;


}
