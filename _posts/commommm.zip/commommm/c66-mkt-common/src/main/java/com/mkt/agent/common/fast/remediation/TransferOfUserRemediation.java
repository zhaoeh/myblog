package com.mkt.agent.common.fast.remediation;

import com.alibaba.nacos.common.utils.CollectionUtils;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.fast.core.FastCore;
import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.common.fast.enums.CheckPointTypeEnums;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import com.mkt.agent.common.fast.pojo.DailyMktUserMapping;
import com.mkt.agent.common.fast.pojo.SimpleCustomers;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;
import org.apache.http.util.Asserts;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @description: 玩家-代理-关系转移补救器（以玩家为维度）
 * @author: ErHu.Zhao
 * @create: 2024-04-08
 **/
@Component
@Slf4j
public class TransferOfUserRemediation {

    private final FastCore fastCore;

    public TransferOfUserRemediation(FastCore fastCore) {
        this.fastCore = fastCore;
    }

    /**
     * 玩家为维度，进行玩家-代理 关系转移补救
     *
     * @param fastContext
     * @param users
     */
    public void doTransferOfUserRemediation(FastContext fastContext, StrategyEnums strategy, SqlSessionFactory factory, List<TAgentCustomers> relationAgents, List<TCustomerLayer> users) {
        log.info("begin doTransferOfUserRemediation");
        fastContext.setEvent(CheckPointTypeEnums.TransferOfUser);
        if (CollectionUtils.isEmpty(users)) {
            return;
        }
        List<DailyMktUserMapping> targetUsers = new ArrayList<>();
        Map<String, String> currentAgentsMapping;
        List<TCustomerLayer> players = fastCore.obtainWithSelfIsPlayerAndParentIsAcc66(users);
        if (users.size() - players.size() > 0) {
            // 当前玩家集合所有关联代理
            if (Objects.isNull(relationAgents)) {
                relationAgents = fastCore.obtainRelationAgentsFromUsers(users);
            }

            // 当前玩家集合所有关联代理的脱敏映射表
            currentAgentsMapping = fastCore.obtainDesensMapping(fastContext, relationAgents);
            if (MapUtils.isEmpty(currentAgentsMapping)) {
                return;
            }
            String nullAgent = currentAgentsMapping.get(BaseConstants.NULL_AGENT);
            String adminAgent = currentAgentsMapping.get(BaseConstants.C66_ADMIN);
            Asserts.notBlank(nullAgent, "nullAgent cannot be blank");
            Asserts.notBlank(adminAgent, "adminAgent cannot be blank");
            Map<String, List<SimpleCustomers>> superAgentChainsMap = null;
            if (CollectionUtils.isNotEmpty(relationAgents)) {
                // 获取当前玩家集合所有关联代理的上级代理链路
                superAgentChainsMap = fastCore.obtainSuperAgentChainsMap(fastContext, relationAgents.stream().map(TAgentCustomers::getLoginName).collect(Collectors.toList()), false);
            }

            if (CollectionUtils.isNotEmpty(users)) {
                List<DailyMktUserMapping> normals = fastCore.packageUsersMappings(fastContext, users, superAgentChainsMap, currentAgentsMapping, nullAgent, adminAgent);
                targetUsers.addAll(normals);
            }
        } else {
            // 当前玩家集合所有关联代理的脱敏映射表
            currentAgentsMapping = fastCore.obtainDesensMapping(fastContext, null);
            if (MapUtils.isEmpty(currentAgentsMapping)) {
                return;
            }
            String nullAgent = currentAgentsMapping.get(BaseConstants.NULL_AGENT);
            String adminAgent = currentAgentsMapping.get(BaseConstants.C66_ADMIN);
            Asserts.notBlank(nullAgent, "nullAgent cannot be blank");
            Asserts.notBlank(adminAgent, "adminAgent cannot be blank");

            if (CollectionUtils.isNotEmpty(players)) {
                // 直属上级为acc66的做特殊处理，不用查询当前玩家直属代理的上级代理链
                List<DailyMktUserMapping> acc66s = fastCore.packageUsersMappingsWithAcc66(players, nullAgent, adminAgent);
                targetUsers.addAll(acc66s);
            }
        }

        if (CollectionUtils.isNotEmpty(targetUsers)) {
            fastCore.batchHandleUsersMappingWithRetry(fastContext, strategy, targetUsers, factory);
        }
        log.info("end doTransferOfUserRemediation");
    }


}
