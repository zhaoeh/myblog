package com.mkt.agent.common.entity.api.integration.bi.responses;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Description: TODO
 * @Author: PTMinnisLi
 * @Date: 2023/7/20
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class CustUserSummerResponse extends UserSummerResponse{

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long customerId;

    private Integer agentType;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long parentId;

    private String parentAccount;

    private Integer siteId;

    private String productId;
}
