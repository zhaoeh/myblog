package com.mkt.agent.common.constants;

/**
 * @Description 代理转账-常量类--
 * @Classname ATransferConstants
 * @Date 2023/6/22 15:19
 * @Created by TJSLucian
 */
public class ATransferConstants {


    //加额度标识
    public static final String ADD = "add";
    //减额度标识
    public static final String SUBTRACT = "subtract";

    //调用ws给玩家加减额度加密类型
    public static final String ENCRYPT_TYPE = "08";

    /*
     *  审核类型常量值
     */
    //门店二审审核
    public static final String VERIFY_TYPE_SECOND = "2";

    //门店一审审核
    public static final String VERIFY_TYPE_FIRST = "1";

    /*
     * 审核结果常量值
     */
    //通过
    public static final Integer VERIFY_SUCESS = 0;

    //拒绝
    public static final Integer VERIFY_FAILURE = 1;

    //风控审核最大金额值
    public static final String APPROVE_AMOUNT = "WITHDRAWAL_RISK_AMOUNT";

    /**
     * 转账方向
     */
    public static final String A2A = "A2A";

    public static final String A2P = "A2P";

    public static final String P2A = "P2A";

}
