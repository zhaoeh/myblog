package com.mkt.agent.common.entity.api.integration.bi.responses;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserSummerResponse {
    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "name", example = "in agent system is agentAccount")
    private String name;

    @ApiModelProperty(value = "depositAmount", example = "in agent system is deposit")
    private BigDecimal depositAmount;

    @ApiModelProperty(value = "withdrawAmount", example = "in agent system is withdrawal")
    private BigDecimal withdrawAmount;

    @ApiModelProperty(value = "turnoverSum", example = "turnoverSum")
    private BigDecimal turnoverSum;

    @ApiModelProperty(value = "ggrSum", example = "ggrSum")
    private BigDecimal ggrSum;


    @ApiModelProperty(value = "outcomeSum", example = "outcomeSum")
    private BigDecimal outcomeSum;

    @ApiModelProperty(value = "recordDate")
    private String recordDate;

    @ApiModelProperty(value = "recordStr")
    private String recordStr;

}
