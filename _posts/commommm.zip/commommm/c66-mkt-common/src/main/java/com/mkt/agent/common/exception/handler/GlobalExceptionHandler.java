package com.mkt.agent.common.exception.handler;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @ClassName GlobalExceptionHandler
 * @Description 全局捕获异常
 * @Author TJSAlex
 * @Date 2023/5/19 12:12
 * @Version 1.0
 **/
@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {
    /**
     * 处理自定义业务异常
     * @param e
     * @return
     */
    @ExceptionHandler(value = BusinessException.class)
    @ResponseBody
    public Result businessExceptionHandler(BusinessException e){
        log.info("发生业务异常！原因是：{}",e.getMessage());
        Integer code = ObjectUtils.isEmpty(e.getCode())? ResultEnum.FAIL.getCode() : e.getCode();
        return Result.fail(code, e.getMessage());
    }

    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    @ResponseBody
    public Result MethodArgumentNotValidExceptionHandler(MethodArgumentNotValidException exception){
        BindingResult result = exception.getBindingResult();
        StringBuilder errorMsg = new StringBuilder() ;
        if (result.hasErrors()) {
            List<ObjectError> fieldErrors = result.getAllErrors();
            fieldErrors.forEach(error -> {
                errorMsg.append(error.getDefaultMessage()).append("!");
            });
        }
        log.error("参数校验错误！原因是：{}", errorMsg);
        return Result.fail(ResultEnum.BAD_REQUEST.getCode(), errorMsg.toString());
    }

    /**
     * 处理参数校验异常
     *
     * @param e BindException
     * @return Result
     */
    @ExceptionHandler(BindException.class)
    @ResponseBody
    public Result handleValidationException(BindException e) {
        BindingResult bindingResult = e.getBindingResult();
        if (bindingResult.hasErrors()) {
            String errorMessage = bindingResult.getAllErrors().stream()
                    .map(ObjectError::getDefaultMessage).collect(Collectors.joining("/"));
            log.error("参数校验错误！原因是：{}", errorMessage);
            return Result.fail(ResultEnum.BAD_REQUEST.getCode(), errorMessage);
        }
        log.error("参数校验错误！原因是：{}", ResultEnum.BAD_REQUEST.getMessage());
        return Result.fail(ResultEnum.BAD_REQUEST.getCode(), ResultEnum.BAD_REQUEST.getMessage());
    }

    @ResponseBody
    @ExceptionHandler(ConstraintViolationException.class)
    public Result handleValidationErrors(ConstraintViolationException ex) {
        List<String> errors = ex.getConstraintViolations()
                .stream().map(e->e.getMessage()).collect(Collectors.toList());
        log.error("参数校验错误！原因是：{}", String.join(",",errors));
        return Result.fail(String.join(",",errors));
    }

    /**
     * 全局异常 TODO 开发阶段暂时关闭
     *
     * @param req HttpServletRequest
     * @param e   ConstraintViolationException
     * @return Result
     */
    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public Result allExceptionHandler(HttpServletRequest req, Exception e) {
        log.error("未捕捉异常！The method is: {} ,The URI is:{},原因是", Objects.nonNull(req) ? req.getMethod() : "", Objects.nonNull(req) ? req.getRequestURI() : "", e);
        String message = StringUtils.isNotBlank(e.getMessage()) ? e.getMessage() : ResultEnum.UNEXPECTED_FAIL.getMessage();
        return Result.fail(ResultEnum.UNEXPECTED_FAIL.getCode(), message);
    }
}