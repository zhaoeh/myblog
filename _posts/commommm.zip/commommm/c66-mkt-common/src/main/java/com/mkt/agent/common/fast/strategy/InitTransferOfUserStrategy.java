package com.mkt.agent.common.fast.strategy;

import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.common.fast.core.FastPersist;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @description: 玩家-代理-关系 玩家维度 初始化策略
 * @author: ErHu.Zhao
 * @create: 2024-04-08
 **/
@Component
@Slf4j
public class InitTransferOfUserStrategy implements RemediationStrategy {

    private final FastPersist fastPersist;

    public InitTransferOfUserStrategy(FastPersist fastPersist) {
        this.fastPersist = fastPersist;
    }

    @Override
    public String strategy() {
        return StrategyEnums.InitTransferOfUserStrategy.getStrategyName();
    }

    @Override
    public void afterSuccess(FastContext fastContext, String callable, List<String> params) {
        log.info("afterSuccess with InitTransferOfUserStrategy，初始化-玩家维度更新玩家转移成功");
        fastPersist.batchUpdateUsersStatus(fastContext, params, 1);
    }

    @Override
    public void afterFailed(FastContext fastContext, String callable, List<String> params) {
        log.info("afterFailed with InitTransferOfUserStrategy，初始化-玩家维度更新玩家转移失败");
    }
}
