package com.mkt.agent.common.fast.remediation;

import com.alibaba.nacos.common.utils.CollectionUtils;
import com.mkt.agent.common.constants.BaseConstants;
import com.mkt.agent.common.fast.core.FastCore;
import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.common.fast.core.FastUtils;
import com.mkt.agent.common.fast.enums.CheckPointTypeEnums;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import com.mkt.agent.common.fast.pojo.AgentCustomersMapping;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.util.Asserts;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * @description: 代理脱敏补救器
 * @author: ErHu.Zhao
 * @create: 2024-04-08
 **/
@Component
@Slf4j
public class DesensMappingOfAgentRemediation {

    private final FastCore fastCore;

    public DesensMappingOfAgentRemediation(FastCore fastCore) {
        this.fastCore = fastCore;
    }

    /**
     * 代理脱敏补救
     *
     * @param fastContext
     * @param strategy
     * @param agentNames
     * @return
     */
    public boolean doDesensMappingOfAgentRemediation(FastContext fastContext,
                                                     StrategyEnums strategy,
                                                     List<String> agentNames) {
        log.info("begin doDesensMappingOfAgentRemediation");
        fastContext.setEvent(CheckPointTypeEnums.DesensMappingOfAgent);
        if (CollectionUtils.isEmpty(agentNames)) {
            return true;
        }

        List<String> targetAgents = fastCore.queryDiffs(fastContext, agentNames);
        if (CollectionUtils.isEmpty(targetAgents)) {
            return true;
        }

        Map<String, String> nullOrAcc66AgentsMapping = fastCore.queryNullOrAcc66AgentMapping(fastContext);
        List<String> basedAgentsMapping = fastCore.packageNullOrAcc66AgentContainerIfNeed(nullOrAcc66AgentsMapping);
        basedAgentsMapping.addAll(agentNames);
        List<String> uuids = FastUtils.generateUuid(basedAgentsMapping.size());
        if (CollectionUtils.isEmpty(uuids)) {
            return false;
        }
        List<AgentCustomersMapping> mapping = fastCore.packageAgentMappings(basedAgentsMapping, uuids);
        if (CollectionUtils.isEmpty(mapping)) {
            log.info("mapping is empty,stop to sync agent mapping flow");
            return false;
        }
        Map<String, String> newAgentsMapping = fastCore.agentCustomersMapping2Map(mapping);
        String nullAgent = newAgentsMapping.get(BaseConstants.NULL_AGENT);
        nullAgent = StringUtils.isBlank(nullAgent) ? nullOrAcc66AgentsMapping.get(BaseConstants.NULL_AGENT) : nullAgent;
        Asserts.notBlank(nullAgent, "nullAgent cannot be blank");
        String adminAgent = newAgentsMapping.get(BaseConstants.C66_ADMIN);
        adminAgent = StringUtils.isBlank(adminAgent) ? nullOrAcc66AgentsMapping.get(BaseConstants.C66_ADMIN) : adminAgent;
        Asserts.notBlank(adminAgent, "adminAgent cannot be blank");
        boolean result = fastCore.wrapHandleAgentMappingWithRetry(fastContext, strategy, mapping);
        log.info("end doDesensMappingOfAgentRemediation");
        return result;
    }

}
