package com.mkt.agent.common.entity.api.reportapi.responses;


import com.alibaba.excel.annotation.ExcelIgnore;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.mkt.agent.common.annotation.ExcelColumn;
import com.mkt.agent.common.entity.api.reportapi.responses.base.ReportBaseResponse;
import com.mkt.agent.common.jackson.serializer.BigDecimalSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Column;
import java.math.BigDecimal;

@Data
@ApiModel(description = "排名前十的玩家账号柱状图")
public class TurnoverTopResp {

    // 用户名
    @ApiModelProperty(value = "login_name", example = "mptest388")
    private String loginName;
    // 投注额总计
    @ApiModelProperty(value = "turnoverSum", example = "20000")
    private String turnoverSum;
}
