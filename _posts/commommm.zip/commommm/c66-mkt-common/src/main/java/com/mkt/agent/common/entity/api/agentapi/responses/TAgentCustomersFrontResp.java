package com.mkt.agent.common.entity.api.agentapi.responses;

import com.mkt.agent.common.annotation.ExcelColumn;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @ClassName CommissionPlanResp
 * @Description 佣金方案
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Data
public class TAgentCustomersFrontResp implements Serializable {

    /*
        佣金方案类型
    */
    @ApiModelProperty(value = "LOGIN_NAME")
    @ExcelColumn(value ="Account",order = 0)
    private String loginName;

    /*
        agentType
    */
    @ApiModelProperty(value = "代理类型")
    private String agentType;

    /*
        Referral Id
    */
    @ApiModelProperty(value = "Referral Id")
    private String referralId;

    /*
        flag
    */
    @ApiModelProperty(value = "parent")
    @ExcelColumn(value ="Parent",order = 1)
    private String parent;

    /*
       agentLevel
    */
    @ApiModelProperty(value = "AGENT_LEVEL")
    @ExcelColumn(value ="Agent Level",order = 2)
    private Integer agentLevel;

    /*
        创建时间
    */
    @ApiModelProperty(value = "CREATE_TIME")
    @ExcelColumn(value ="Create Time",order = 4)
    private String createTime;


}
