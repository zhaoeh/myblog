package com.mkt.agent.common.entity.api.agentapi.requests;

import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.persistence.Column;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

@Data
public class TAgentContractListReq implements Serializable {
    @ApiModelProperty(value = "contract_list_id")
    @NotNull(message = "contract_list_id is not blank",groups = InputValidationGroup.Update.class)
     private String contractListId ;

    @ApiModelProperty(value = "金额")
    @NotBlank(message = "turnoverOr GGr is not blank",groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class})
    private BigDecimal turnoverGgr;

    @ApiModelProperty(value = "commission")
    @NotBlank(message = "commission is not blank",groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class})
    private BigDecimal commission ;

    @ApiModelProperty(value = "contractId")
    private String contractId;

    @ApiModelProperty(value = "isChecked")
    @NotBlank(message = "isChecked is not blank",groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class})
    private String isChecked;
}
