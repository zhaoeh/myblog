package com.mkt.agent.common.annotation;

import java.lang.annotation.*;

/**
 * @Description 满足自定义规则，则设置为null。默认参数值为空字符串或-1则设置为null
 * @Classname ConvertToNullIfEmpty
 * @Date 2024/2/14 16:20
 * @Created by TJSLucian
 */
@Documented
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface Convert2NullIfInvalidField {

    String[] inValidValues() default {};

    boolean isDefault() default true;

}
