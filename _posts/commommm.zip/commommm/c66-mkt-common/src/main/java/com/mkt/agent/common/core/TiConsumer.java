package com.mkt.agent.common.core;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-02-28
 **/
@FunctionalInterface
public interface TiConsumer<T, U, W> {

    void accept(T t, U u, W w);
}
