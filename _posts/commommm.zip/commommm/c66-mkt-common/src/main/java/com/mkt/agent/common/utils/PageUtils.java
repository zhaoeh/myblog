package com.mkt.agent.common.utils;

import com.mkt.agent.common.constants.PageConstant;

import java.util.Objects;

/**
 * @description: 分页工具类
 * @author: ErHu.Zhao
 * @create: 2024-02-01
 **/
public class PageUtils {

    /**
     * 根据pageNum和pageSize计算startIndex
     *
     * @param pageNum
     * @param pageSize
     * @return
     */
    public static Integer calculateStartIndex(Integer pageNum, Integer pageSize) {
        return (handlePageNum(pageNum) - 1) * handlePageSize(pageSize);
    }

    /**
     * 根据pageNum和pageSize计算endIndex
     *
     * @param pageNum
     * @param pageSize
     * @return
     */
    public static Integer calculateEndIndex(Integer pageNum, Integer pageSize) {
        return handlePageNum(pageNum) * handlePageSize(pageSize);
    }

    /**
     * 处理pageNum
     *
     * @param pageNum
     * @return
     */
    public static Integer handlePageNum(Integer pageNum) {
        if (Objects.isNull(pageNum) || pageNum < 0) {
            pageNum = PageConstant.DEFAULT_PAGE_NUM;
        }
        return pageNum;
    }

    /**
     * 处理pageSize
     *
     * @param pageSize
     * @return
     */
    public static Integer handlePageSize(Integer pageSize) {
        if (Objects.isNull(pageSize) || pageSize < 0) {
            pageSize = PageConstant.DEFAULT_PAGE_SIZE;
        }
        return pageSize;
    }
}
