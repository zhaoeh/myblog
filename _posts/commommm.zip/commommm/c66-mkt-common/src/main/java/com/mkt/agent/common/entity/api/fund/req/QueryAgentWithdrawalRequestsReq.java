package com.mkt.agent.common.entity.api.fund.req;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;


@Data
@ToString(exclude = {"bankAccountNo"})
public class QueryAgentWithdrawalRequestsReq {
    @ApiModelProperty(value = "本次请求UUID标识")
    
    protected String requestUUID;
    
    protected String parentAccount;
    
    protected String bankAccountName;

    protected String bankAccountNo;
    
    protected String bankAccountType;
    
    protected String bankCity;
    
    protected String bankName;
    
    protected String branchName;
    
    protected String createdBy;
    
    protected String currency;
    
    protected String loginName;
    
    protected String customerId;
    
    protected String customerType;
    
    protected String emailStatus;
    
    protected String flag;
    
    protected String lastUpdatedBy;
    
    protected String priorityType;
    
    protected String processedBy;
    
    protected String requestId;
    
    protected String productId;
    
    protected String createdDateBegin;
    
    protected String createdDateEnd;
    
    protected String processedDateBegin;
    
    protected String processedDateEnd;
    
    protected String lastUpdateBegin;
    
    protected String lastUpdateEnd;
    

    protected String deleteFlag;
    
    protected String endPointUrl;
    
    protected String endPointType;
    
    protected int pageNum;

    protected int pageSize;
    
    protected String order;
    
    protected String amountStart;
    
    protected String amountEnd;
    
    protected String catalog;
    
    protected String targetCurrency;

    @ApiModelProperty(value = "存款门店编码")
    
    private String branchCode;
    @ApiModelProperty(value = "用户上级")
    
    protected String parent;

    @ApiModelProperty(value = "ip")
    
    private String ipAddress;

    @ApiModelProperty(value = "第一次取款")
    
    private String firstWithdrawal;

    public Integer getRowNum() {
        return (pageNum -1) * pageSize;
    }
}
