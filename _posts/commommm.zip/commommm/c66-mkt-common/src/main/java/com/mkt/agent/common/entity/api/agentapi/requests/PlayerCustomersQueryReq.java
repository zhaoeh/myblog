package com.mkt.agent.common.entity.api.agentapi.requests;

import com.mkt.agent.common.entity.BasePageRequest;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;

/**
 * @ClassName TAgentCustomersReq
 * @Author TJSAustin
 * @Date 2023/6/6 10:00
 * @Version 1.0
 **/
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
public class PlayerCustomersQueryReq extends BasePageRequest {

    /**
     * 登录名
     */
    @ApiModelProperty(value = "登录名(account)")
    private String account;

    /**
     * 父级代理
     */
    @ApiModelProperty(value = "父级代理(Parent)")
    private String parent;

    /**
     * 父级代理
     */
    @ApiModelProperty(value = "父级代理id(Parent)" ,hidden = true)
    private Long parentId;

    /**
     * Register Link
     */
    @ApiModelProperty(value = "Register Link")
    private String registerLink;

    /**
     * Parent Level
     */
    @ApiModelProperty(value = "Parent Level")
    private Integer parentLevel;

    /**
     * Parent Level
     */
    @ApiModelProperty(value = "Parent Level End", hidden = true)
    private Integer parentLevelEnd;

    /**
     * Player Type
     */
    @ApiModelProperty(value = "Player Type[ (All, 0),(Direct Users, 1),(Downline Users, 2)]", example = "0")
    private Integer playerType;

    /**
     * Register Referral ID
     */
    @ApiModelProperty(value = "Register Referral ID")
    private String registerReferralID;

    /**
     * Register Domain
     */
    @ApiModelProperty(value = "Register Domain")
    private String registerDomain;

    /**
     * 创建时间-开始
     */
    @ApiModelProperty(value = "创建时间-开始(Create Time - Start Time)")
    private String createTimeStart;

    /**
     * 创建时间-结束
     */
    @ApiModelProperty(value = "创建时间-结束(Create Time - End Time)")
    private String createTimeEnd;

    /**
     * 产品
     */
    @ApiModelProperty(value = "所属产品", hidden = true)
    private String productId;
}
