package com.mkt.agent.common.player.processor;


import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.player.model.PlayerReportByMonthMapperHolder;
import com.mkt.agent.common.player.model.PlayerReportByMonthProcessorModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Objects;

/**
 * @Description TODO
 * @Classname PlayerReportByMonthProcessor
 * @Date 2024/3/13 14:40
 * @Created by TJSLucian
 */
@Component
@Slf4j
public class PlayerReportByMonthProcessor {

    private final AgentTransByMonthProcessor agentTransByMonthProcessor;

    public PlayerReportByMonthProcessor(AgentTransByMonthProcessor agentTransByMonthProcessor) {
        this.agentTransByMonthProcessor = agentTransByMonthProcessor;
    }


    public void preHandlePlayerReportByMonth(PlayerReportByMonthProcessorModel model){
        if(Objects.isNull(model) || Objects.isNull(model.getHolder())){
            return;
        }

        if(model.getOperatorType().equals(Constants.FROM_ASYNC)){
            TAgentCustomers parent = model.getHolder().getQueryAgentByNameMapper().apply(model.getParent());
            if(Objects.isNull(parent)){
                return;
            }

            model.setParentLevel(parent.getAgentLevel());
        }

        handlePlayerReportData(model);
    }

    /**
     * description: 递归处理某月的player report数据
     * @param:  [model]
     * @return: void
     * @Date: 2024/3/13 15:20
     * @Version: 1.0.0
     * @Author: Lucian
     */
    public void handlePlayerReportData(PlayerReportByMonthProcessorModel model){

        Integer level = model.getLevel();

        List<TAgentCustomers> agentList = getAgentList(model);

        if(!CollectionUtils.isEmpty(agentList)){
            log.info("[handlePlayerReportData]The agentCount for level:{} is:{}",level,agentList.size());
            //不为空，则提交给线程池处理任务
            agentTransByMonthProcessor.preSubmitTaskByMonth(agentList,model);
        }

        log.info("[handleByLevelByDay]finished to save data for level:{} for month:{}",level,model.getMonth());
        agentList = null;
        level--;
        model.setLevel(level);

        if(level>0 || (model.getOperatorType().equals(Constants.FROM_ASYNC) && level >= model.getParentLevel())){
            handlePlayerReportData(model);
        }else {
            model = null;
        }

    }


    private List<TAgentCustomers> getAgentList(PlayerReportByMonthProcessorModel model){

        Integer level = model.getLevel();

        PlayerReportByMonthMapperHolder holder = model.getHolder();

        if(model.getOperatorType().equals(Constants.FROM_JOB)){
            if(model.isCurrentMonth()){
                //当前月查询当前层级所有代理
                return holder.getAllAgentByLevelWithoutStatusMapper().apply(level);
            }else {
                //历史月查询未同步的代理
                return holder.getUncheckedAgentsByLevelNMonth().apply(model.getMonth(),level);
            }

        }else if(model.getOperatorType().equals(Constants.FROM_ASYNC)){
            //查询当前代理团队下当前层级的代理
            return holder.getTeamAgentsByLevelMapper().apply(level.toString(),model.getParent());
        }

        return null;
    }

}
