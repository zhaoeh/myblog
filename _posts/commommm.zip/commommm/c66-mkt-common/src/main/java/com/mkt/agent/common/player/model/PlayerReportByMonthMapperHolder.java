package com.mkt.agent.common.player.model;

import com.mkt.agent.common.core.TiFunction;
import com.mkt.agent.common.entity.Result;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.entity.api.agentapi.TAgentUpdateLog;
import com.mkt.agent.common.entity.api.reportapi.TAgentCountGroupMonth;
import com.mkt.agent.common.entity.api.reportapi.requests.TAgentCountGroupMonthRequest;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * @Description TODO
 * @Classname PlayerMapperByMonthHolder
 * @Date 2024/2/19 11:47
 * @Created by TJSLucian
 */
@Data
@Builder
public class PlayerReportByMonthMapperHolder {


    private Function<String,TAgentCustomers> queryAgentByNameMapper;

    /**
     * 获取某些代理所有下级直属用户的mapper
     */
    private Function<List<String>, List<String>> directUsersMapper;


    /**
     * 获取某个代理的团队里某级别的代理
     */
    private BiFunction<String,String,List<TAgentCustomers>> teamAgentsByLevelMapper;


    // 获取所有当前层级的代理  不区分是否禁用/删除
    private Function<Integer,List<TAgentCustomers>> allAgentByLevelWithoutStatusMapper;

    //获取所有当前层级未同步的代理
    private BiFunction<String,Integer,List<TAgentCustomers>> uncheckedAgentsByLevelNMonth;

    /**
     * 执行 t_agent_count_group 批量插入的mapper
     */
    private Function<List<TAgentCountGroupMonth>, Integer> groupInsertMapper;

    // 根据level和月份删除数据
    private BiFunction<Integer,String,Integer> deleteByLevelNMonth;

    // 根据代理用户名和月份删除数据
    private BiFunction<List<String>,String,Integer> deleteByNamesNMonth;

    /**
     * 获取下级代理产生的count
     */
    private Function<ClDashBoardCreateQueryReq,List<TAgentCountGroupMonth>> downlineAgentCountMapper;

    //查询直属用户的count
    private Function<ClDashBoardCreateQueryReq,List<TAgentCountGroupMonth>> queryDirectCountByMonthMapper;

    //查询自己的count
    private Function<ClDashBoardCreateQueryReq,List<TAgentCountGroupMonth>> querySelfCountByMonthMapper;
}
