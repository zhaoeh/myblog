package com.mkt.agent.common.entity.api.userapi.requests;

import com.mkt.agent.common.entity.BasePageRequest;
import com.mkt.agent.common.entity.PageReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Description: 玩家搜索请求类
 * @Author: PTMinnisLi
 * @Date: 2023/6/22
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerLayerSearchRequest extends PageReq {

    @ApiModelProperty("用户登录名")
    private String loginName;

    @ApiModelProperty("父级代理id")
    private Long parentId;

    @ApiModelProperty("父级代理名称列表")
    private List<String> parentNames;

    @ApiModelProperty("创建时间起期")
    private String createTimeStart;

    @ApiModelProperty("创建时间止期")
    private String createTimeEnd;
}
