package com.mkt.agent.common.hook;

import com.mkt.agent.common.enums.CustomizedValidationContents;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 * @description: CustomizedValidationContents 枚举打印钩子
 * @author: ErHu.Zhao
 * @create: 2024-01-03
 **/
@Component
@Slf4j
public class CustomizedValidationContentsPrinter implements SmartInitializingSingleton {
    @Override
    public void afterSingletonsInstantiated() {
        log.info("begin to print CustomizedValidationContents");
        for (CustomizedValidationContents content : CustomizedValidationContents.values()) {
            log.info("content is {},acceptValues is {},message is {}", content, Arrays.toString(content.getAcceptValues()), content.getMessage());
        }
        log.info("end to print CustomizedValidationContents");
    }
}
