package com.mkt.agent.common.entity.api.reportapi;



import com.mkt.agent.common.entity.api.reportapi.responses.PlayerReportResponse;
import com.mkt.agent.common.entity.clickhouse.req.ClDashBoardCreateQueryReq;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "PlayerReportResponseVo1")
public class PlayerReportResponseVo1 {

    //player report 查询结果
    private List<PlayerReportResponse> resList;

    //查询条件
    private ClDashBoardCreateQueryReq queryReq;

    //是否查询成功
    private boolean asyncSucess;

}
