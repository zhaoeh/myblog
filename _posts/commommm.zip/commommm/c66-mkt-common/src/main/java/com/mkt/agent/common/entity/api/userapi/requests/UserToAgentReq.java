package com.mkt.agent.common.entity.api.userapi.requests;

import com.mkt.agent.common.annotation.DecryptField;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class UserToAgentReq {

    @ApiModelProperty(value = "登录名")
    @NotBlank(message = "loginName is not blank",groups = InputValidationGroup.UserToAgent.class)
    @DecryptField
    private String loginName;

    @NotBlank(message = "parentLoginName is not blank",groups = InputValidationGroup.UserToAgent.class)
    @DecryptField
    private String parentLoginName;
}
