package com.mkt.agent.common.entity.api.jobapi.responses;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

/**
 * @author Colson
 * @date 8/28/2023
 */
@Data
public class AgentContractBindResponse {

    /**
     * 代理account
     */
    private String loginName;

    /**
     * 佣金方案ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long commissionContractId;


}
