package com.mkt.agent.common.entity.api.integration.bi.requests;

import com.mkt.agent.common.entity.api.integration.base.BaseRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class UserSummerRequest extends BaseRequest {
    private String startDate;

    private String endDate;

    private List<String> names;

    private Integer monthFlg;
}
