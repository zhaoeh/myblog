package com.mkt.agent.common.utils;

import com.mkt.agent.common.entity.RandomSingleton;
import com.mkt.agent.common.enums.ResultEnum;
import com.mkt.agent.common.exception.BusinessException;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

//@Component
public class PHPDESEncrypt {
    String key;
    private Random random = RandomSingleton.getInstance();

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public PHPDESEncrypt() {

    }


    /**
     * 根据类型实例化加密类
     *
     * @param productId
     * @param type      01:真实姓名 02:地址 03:电话 04:邮件 05:网络联系方式 06:帐户名 07:帐号 08:存款人
     *                  (预留校验码以真实姓名加密,身份证以电话加密,问题答案以地址加密)
     * @author sky.x
     */
    public PHPDESEncrypt(String productId, String type, String productKey) {
        StringBuilder tempKey = new StringBuilder();
        if (null == type || "".equals(type)) {
            tempKey.append(productId).append(productId).append(productId);
        }
        // 01:真实姓名
        if ("01".equals(type)) {
            tempKey.append(productId).append("R_01").append(productKey, 1, productKey.length() - 1);
        }
        // 02:地址
        if ("02".equals(type)) {
            tempKey.append(productId).append("A_02").append(productKey, 2, productKey.length() - 2);
        }
        // 03:电话
        if ("03".equals(type)) {
            tempKey.append(productId).append("P_03").append(productKey, 1, productKey.length() - 1);
        }
        // 04:邮件
        if ("04".equals(type)) {
            tempKey.append(productId).append("E_04").append(productKey, 1, productKey.length() - 2);
        }
        // 05:网络联系方式
        if ("05".equals(type)) {
            tempKey.append(productId).append("O_05").append(productKey, 3, productKey.length() - 3);
        }
        // 06:帐户名
        if ("06".equals(type)) {
            tempKey.append(productId).append("AN_06").append(productKey, 1, productKey.length() - 2);
        }
        // 07:帐号
        if ("07".equals(type)) {
            tempKey.append(productId).append("AN_07").append(productKey, 2, productKey.length() - 1);
        }
        // 08:存款人
        if ("08".equals(type)) {
            tempKey.append(productId).append("D_08").append(productKey, 2, productKey.length() - 2);
        }
        // 09:身份证
        if ("09".equals(type)) {
            tempKey.append(productId).append("C_09").append(productKey, 1, productKey.length() - 1);
        }
        this.key = tempKey.toString();
    }

    public byte[] desEncrypt(byte[] plainText) throws Exception {
        SecureRandom sr = new SecureRandom();
        DESKeySpec dks = new DESKeySpec(key.getBytes());
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
        SecretKey key = keyFactory.generateSecret(dks);
        Cipher cipher = Cipher.getInstance("DES");
        cipher.init(Cipher.ENCRYPT_MODE, key, sr);
        byte[] data = plainText;
        return cipher.doFinal(data);
    }

    public byte[] desDecrypt(byte[] encryptText) throws Exception {
        SecureRandom sr = new SecureRandom();
        DESKeySpec dks = new DESKeySpec(key.getBytes());
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
        SecretKey key = keyFactory.generateSecret(dks);
        Cipher cipher = Cipher.getInstance("DES");
        cipher.init(Cipher.DECRYPT_MODE, key, sr);
        byte[] encryptedData = encryptText;
        return cipher.doFinal(encryptedData);
    }

    /**
     * 加密
     *
     * @param input
     * @return String
     * @author sky.x
     */
    public String encrypt(String input) throws Exception {
        if (null == input || "".equals(input.trim())) {
            return input;
        }
        String str1 = getRandomNum(1);
        String str2 = getRandomStr(str1, 2);
        String str3 = getRandomStr(str1, 3);
        StringBuilder sb = new StringBuilder(str2);
        String base = base64Encode(desEncrypt(input.getBytes())).replaceAll("\r|\n", "");
        sb.append(base);
        sb.append(str3);
        return sb.toString();
    }

    public String encryptV2(String input) {
        if (null == input || "".equals(input.trim())) {
            return input;
        }
        String str1 = getRandomNum(1);
        String str2 = getRandomStr(str1, 2);
        String str3 = getRandomStr(str1, 3);
        StringBuilder sb = new StringBuilder(str2);
        String base = "()";
        try {
            base = base64Encode(desEncrypt(input.getBytes())).replaceAll("\r|\n", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        sb.append(base);
        sb.append(str3);
        return sb.toString();
    }

    /**
     * 解密
     *
     * @param input
     * @return String
     * @author sky.x
     */
    public String decrypt(String input) {
        try {
            if (null == input || "".equals(input.trim()) || input.length() <= 8) {
                return input;
            }
            input = input.substring(3, input.length() - 4);
            byte[] result = base64Decode(input);
            return new String(desDecrypt(result));
        } catch (Exception e) {
            throw new BusinessException(ResultEnum.ENCRYPT_DECRYPT_ERROR);
        }
    }

    public String base64Encode(byte[] s) {
        if (s == null) {
            return null;
        }
        Base64.Encoder b = Base64.getEncoder();
        return b.encodeToString(s);
    }

    public byte[] base64Decode(String s) throws IOException {
        if (s == null) {
            return null;
        }
        Base64.Decoder decoder = Base64.getDecoder();
        byte[] b = decoder.decode(s);
        return b;
    }


    /**
     * 生成随机字符串
     *
     * @param prefix     前缀
     * @param bodyLength 前缀后 字符串长度
     * @return 帐号
     */
    public String getRandomStr(String prefix, int bodyLength) {
        char[] c = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', 'a', 's', 'd', 'f', 'g',
                'h', 'j', 'k', 'l', 'z', 'x', 'c', 'b', 'n', 'm', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', 'A', 'S', 'D', 'F', 'G', 'H',
                'J', 'K', 'L', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '='};

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < bodyLength; i++) {
            sb.append(c[ThreadLocalRandom.current().nextInt(c.length)]);
        }
        return prefix + sb;
    }

    /**
     * 生成随机由数字组成的字符串
     *
     * @param bodyLength 字符串长度
     * @return
     */
    public String getRandomNum(int bodyLength) {
        StringBuilder sRand = new StringBuilder();
        for (int i = 0; i < bodyLength; i++) {
            String rand = String.valueOf(random.nextInt(10));
            sRand.append(rand);
        }
        return sRand.toString();
    }

}
