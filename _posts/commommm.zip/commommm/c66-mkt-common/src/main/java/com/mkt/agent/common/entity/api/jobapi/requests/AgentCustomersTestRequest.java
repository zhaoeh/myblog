package com.mkt.agent.common.entity.api.jobapi.requests;

import com.mkt.agent.common.entity.BaseOperationEntity;
import lombok.Data;

import javax.persistence.Column;

@Data
public class AgentCustomersTestRequest extends BaseOperationEntity {

    /*
        客户id
    */
    private Long customersId;

    /*
        登录名
    */
    @Column(name="LOGIN_NAME",nullable = false)
    private String loginName;

    /*
        产品
   */
    private String productId;

    /*
        佣金方案code
    */
    private Long commissionContractBindId;

    /*
        父级代理
   */
    private Long parentId;

    /*
         创建人
    */
    private String parentName;

    /*
        代理类型 0:普通 1:专业代理
    */
    private Integer agentType;

    /*
        代理级别
    */
    private Integer agentLevel = 1;

    /*
        代理可以发展最大下级代理层数
    */
    private Integer developableLevel;

    /*
        是否启用标识 0禁用，1启用
    */
    private Integer isEnable=1;

    /*
        备注
    */
    private String remarks;

    /*
        siteId 1:Bingoplus  2:Arenaplus  3:Gameplus
    */
    private Integer siteId;

    private String createBy;

    private String updateBy;

    private Integer isDeleted;

    private Long id;

}
