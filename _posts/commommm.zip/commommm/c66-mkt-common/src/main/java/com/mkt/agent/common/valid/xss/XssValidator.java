package com.mkt.agent.common.valid.xss;

import org.apache.commons.lang3.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.Objects;
import java.util.regex.Pattern;

/**
 * @description: xss脚本攻击校验
 * @author: ErHu.Zhao
 * @create: 2024-03-06
 **/
public class XssValidator implements ConstraintValidator<XssValid, Object> {

    public static final Pattern XSS_REGEX = Pattern.compile("[<>&\"'`/\\\\{}\\[\\]=;\\+\\-\\*\\?!\\|%@:^$#~,]");

    @Override
    public void initialize(XssValid constraintAnnotation) {
    }

    @Override
    public boolean isValid(Object target, ConstraintValidatorContext constraintValidatorContext) {
        if (Objects.isNull(target) || !String.class.isInstance(target)) {
            return true;
        }
        String value = Objects.toString(target);
        return !isContainsXssPayload(value);
    }

    /**
     * 校验输入是否包含xss攻击字符
     *
     * @param input
     * @return
     */
    private boolean isContainsXssPayload(String input) {
        if (StringUtils.isBlank(input)) {
            return false;
        }
        return XSS_REGEX.matcher(input).find();
    }
}
