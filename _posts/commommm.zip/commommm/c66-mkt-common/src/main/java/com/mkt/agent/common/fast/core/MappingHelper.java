package com.mkt.agent.common.fast.core;

import com.alibaba.nacos.common.utils.CollectionUtils;
import com.mkt.agent.common.fast.pojo.AgentCustomersMapping;
import com.mkt.agent.common.fast.pojo.SimpleCustomers;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 * @description: 映射关系持久层查询器
 * @author: ErHu.Zhao
 * @create: 2024-04-04
 **/
@Component
@Slf4j
public class MappingHelper {

    /**
     * 使用IN查询的范围
     */
    private static Integer IN_SIZE = 10;

    @Autowired
    @Qualifier("mysqlSqlSessionFactory")
    private SqlSessionFactory sqlSessionFactory;

    /**
     * 查询目标代理集的脱敏映射
     *
     * @param params
     * @return
     */
    public List<AgentCustomersMapping> queryAgentsMapping(FastContext fastContext, List<String> params) {
        List<AgentCustomersMapping> mappings;
        if (CollectionUtils.isEmpty(params)) {
            log.info("开始查询全量代理的脱敏映射集合");
            mappings = fastContext.getQueryAgentsMapping().apply(params);
            log.info("全量代理脱敏映射集合查询结束，result size is {}", Optional.ofNullable(mappings).map(List::size).orElse(0));
            return mappings;
        }
        log.info("开始查询目标代理的脱敏映射集合，目标代理集合 size is {}", Optional.ofNullable(params).map(List::size).orElse(0));
        mappings = fastContext.getQueryAgentsMapping().apply(params);
        log.info("目标代理脱敏映射集合查询结束，result size is {}", Optional.ofNullable(mappings).map(List::size).orElse(0));
        return mappings;
//        if (params.size() <= IN_SIZE) {
//            return holder.getQueryAgentsMapping().apply(params);
//        }
//
//        SqlSession sqlSession = sqlSessionFactory.openSession();
//        try {
//            sqlSession.getConnection().setAutoCommit(false);
//            sqlSession.getConnection().createStatement().execute("create temporary table FastQueryTemp (stringSource varchar(255)) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci");
//            sqlSession.getConnection().createStatement().execute("create index idx_name on FastQueryTemp (stringSource)");
//            sqlSession.getConnection().createStatement().executeUpdate(buildSqlWithTemp(params));
//            sqlSession.commit();
//            List<AgentCustomersMapping> results = sqlSession.selectList(holder.getFastAgentMappingMapperStatement(), params);
//            sqlSession.commit();
//            return results;
//        } catch (Exception e) {
//            sqlSession.rollback();
//            log.error("创建临时表失败");
//        } finally {
//            sqlSession.close();
//        }
//        return null;
    }

    /**
     * 查询目标代理集的上级代理链路
     *
     * @param params
     * @return
     */
    public List<SimpleCustomers> querySuperAgentsByNames(FastContext fastContext, List<String> params) {
        if (CollectionUtils.isEmpty(params)) {
            return fastContext.getSelectSuperAgentsByNames().apply(params);
        }
        return fastContext.getSelectSuperAgentsByNames().apply(params);
//        if (params.size() <= IN_SIZE) {
//            return holder.getSelectSuperAgentsByNames().apply(params);
//        }
//        SqlSession sqlSession = sqlSessionFactory.openSession();
//        try {
//            sqlSession.getConnection().setAutoCommit(false);
//            sqlSession.getConnection().createStatement().execute("create temporary table FastQueryTemp (stringSource varchar(255))");
//            sqlSession.getConnection().createStatement().execute("create index idx_name on FastQueryTemp (stringSource)");
//            sqlSession.getConnection().createStatement().executeUpdate(buildSqlWithTemp(params));
//            sqlSession.commit();
//            List<SimpleCustomers> results = sqlSession.selectList(holder.getFastAgentMapperStatement(), params);
//            return results;
//        } catch (Exception e) {
//            sqlSession.rollback();
//            log.error("创建临时表失败," + e);
//        } finally {
//            sqlSession.close();
//        }
//        return null;
    }

    private String buildSqlWithTemp(List<String> dataSources) {
        if (CollectionUtils.isEmpty(dataSources)) {
            return null;
        }
        StringBuilder builder = new StringBuilder();
        builder.append("insert into FastQueryTemp (stringSource) VALUES ");
        dataSources.stream().forEach(item -> {
            builder.append("(").append("\'" + item + "\'").append("),");
        });

        String sql = builder.toString();
        sql = sql.substring(0, sql.length() - 1);
        return sql;
    }


}
