package com.mkt.agent.common.fast.event;

import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.fast.core.FastContext;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.ApplicationEvent;

import java.util.List;

/**
 * @description: 注册用户事件
 * @author: ErHu.Zhao
 * @create: 2024-04-03
 **/
public class RegisterUsersEvent extends ApplicationEvent {
    /**
     * 新注册的玩家
     */
    private List<TCustomerLayer> users;

    private SqlSessionFactory factory;

    private FastContext fastContext;

    public RegisterUsersEvent(Object source, List<TCustomerLayer> users, SqlSessionFactory factory, FastContext fastContext) {
        super(source);
        this.users = users;
        this.factory = factory;
        this.fastContext = fastContext;
    }

    public List<TCustomerLayer> getUsers() {
        return users;
    }

    public FastContext getFastContext() {
        return fastContext;
    }

    public SqlSessionFactory getFactory() {
        return factory;
    }
}
