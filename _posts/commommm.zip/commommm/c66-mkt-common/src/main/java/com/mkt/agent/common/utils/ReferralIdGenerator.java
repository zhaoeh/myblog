package com.mkt.agent.common.utils;

import com.mkt.agent.common.entity.RandomSingleton;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * @ClassName ReferralIdGenerator
 * @Description 生成ReferralId
 * @Author TJSAlex
 * @Date 2023/5/26 17:29
 * @Version 1.0
 **/
public class ReferralIdGenerator {

    private static final int digit;
    private static final List<Character> characters;

    static {
        digit = 4;
        characters = new ArrayList<>(31);
        for (int i = 'a'; i <= 'z'; i++) {
            if (i != 'i' && i != 'l' && i != 'o') {
                characters.add((char) i);
            }
        }
        for (int i = '2'; i <= '9'; i++) {
            characters.add((char) i);
        }
    }

    public static String generateReferralId() {
        Random random = RandomSingleton.getInstance();
        char[] res = new char[digit];
        for (int i = 0; i < digit; i++) {
            int index = random.nextInt(characters.size());
            res[i] = characters.get(index);
        }
        return String.valueOf(res);
    }
}
