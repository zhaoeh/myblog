package com.mkt.agent.common.fast.pojo;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.sql.Date;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-03-29
 **/
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public class FastQueryModel {

    private String beginDate;

    private String endDate;

    /**
     * 查询条件中的代理层级
     */
    private Integer agentLevel;

    /**
     * 玩家名称
     */
    private String loginName;

    /**
     * 直属代理
     */
    private String parentDirect;

    /**
     * 该玩家的五级代理名称
     */
    private String parentFive;

    /**
     * 该玩家的五级代理状态
     */
    private Integer parentFiveStatus;

    /**
     * 该玩家的四级代理名称
     */
    private String parentFour;

    /**
     * 该玩家的四级代理状态
     */
    private Integer parentFourStatus;

    /**
     * 该玩家的三级代理名称
     */
    private String parentThree;

    /**
     * 该玩家的三级代理状态
     */
    private Integer parentThreeStatus;

    /**
     * 该玩家的二级代理名称
     */
    private String parentTwo;

    /**
     * 该玩家的二级代理状态
     */
    private Integer parentTwoStatus;


    /**
     * 该玩家的一级代理名称
     */
    private String parentOne;

    /**
     * 该玩家的一级代理状态
     */
    private Integer parentOneStatus;

    /**
     * 该玩家的顶级代理名称
     */
    private String parentRoot;

    /**
     * 空代理
     */
    private String parentNull;

    private Date createDate;

    private Integer startIndex;

    private Integer endIndex;

    /**
     * 是否已经映射脱敏 0：未脱敏 1：已脱敏
     */
    private Integer isMappingDone;

    /**
     * 是否已经关系转移 0：未转移  1：已转移
     */
    private Integer isTransferDone;

    /**
     * 是否删除 0：未删除 1：已删除
     */
    private Integer isDelete;
}
