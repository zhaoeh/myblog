package com.mkt.agent.common.entity.api.reportapi.responses;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.mkt.agent.common.annotation.ExcelColumn;
import com.mkt.agent.common.jackson.serializer.BigDecimalSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "PlayerReportInfo")
public class PlayerReportResponse {

    //  数据日期
    @ApiModelProperty(value = "agentDate", example = "2023-05-18")
    @ExcelColumn(value ="Date",order = 0)
    private String agentDate;

    // 玩家账户号：玩家的唯一标识
    @ApiModelProperty(value = "Account", example = "Amida001")
    @ExcelColumn(value ="Account",order = 1)
    private String account;

    // 玩家上级代理账号：父级代理的账号
    @ApiModelProperty(value = "Parent", example = "Top")
    @ExcelColumn(value ="Parent",order = 2)
    private String parent;

    // 玩家上级代理的代理等级:数据来自于代理表，共五级：1，2，3，4，5
    @ApiModelProperty(value = "Parent Level", example = "2")
    @ExcelColumn(value ="Parent Level",order = 3)
    private String parentLevel;

    // 投注金额：玩家投注到平台游戏的金额
    @ApiModelProperty(value = "turnover", example = "10000")
    @ExcelColumn(value ="Turnover",order = 4)
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal turnover = BigDecimal.ZERO.setScale(2);

    // 平台收入金额：GGR类型 计算使用'
    @ApiModelProperty(value = "GGR", example = "10000")
    @ExcelColumn(value ="GGR",order = 5)
    @JsonSerialize(using = BigDecimalSerializer.class)
    @JsonProperty("ggr")
    private BigDecimal ggr = BigDecimal.ZERO.setScale(2);;

    // 玩家输赢金额
    @ApiModelProperty(value = "winOrLoss", example = "20000")
    @ExcelColumn(value ="Win/Loss",order = 6)
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal winOrLoss = BigDecimal.ZERO.setScale(2);

    // 玩家存款金额
    @ApiModelProperty(value = "deposit", example = "20000")
    @ExcelColumn(value ="Deposit",order = 7)
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal deposit = BigDecimal.ZERO.setScale(2);

    // 玩家取款金额
    @ApiModelProperty(value = "withdrawal", example = "1000")
    @ExcelColumn(value ="Withdrawal",order = 8)
    @JsonSerialize(using = BigDecimalSerializer.class)
    private BigDecimal withdrawal = BigDecimal.ZERO.setScale(2);


}
