package com.mkt.agent.common.entity;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * @ClassName SumPageResponse
 * @Description 页汇总数据
 * @Author Jojo
 * @Date 2023/10/23 14:03
 * @Version 1.0
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SumPageResponse<T> extends Page<T> {

    // 当前页汇总数据
    @ApiModelProperty(value = "pageSumMap", example = "")
    private Map<String, BigDecimal> pageSumMap = new HashMap<>();

    // 所有汇总数据
    @ApiModelProperty(value = "searchSumMap", example = "")
    private Map<String, BigDecimal> searchSumMap = new HashMap<>();

}
