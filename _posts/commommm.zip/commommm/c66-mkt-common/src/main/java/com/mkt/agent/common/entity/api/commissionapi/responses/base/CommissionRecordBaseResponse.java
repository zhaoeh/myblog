package com.mkt.agent.common.entity.api.commissionapi.responses.base;


import com.alibaba.excel.annotation.ExcelIgnore;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


import java.io.Serializable;


@Data
@ApiModel(description = "佣金记录列表信息")
public class CommissionRecordBaseResponse implements Serializable {


    // 佣金记录更新时间
    @ApiModelProperty(value = "updateTime")
    @ExcelIgnore
    private String updateTime;

}
