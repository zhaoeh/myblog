package com.mkt.agent.common.entity.api.jobapi.requests;

import com.mkt.agent.common.entity.api.jobapi.requests.CustomerPlayInfoMonthSumRequest;
import lombok.Data;

import java.math.BigDecimal;

//@Repository
@Data
public class CustomerPlayInfoMonthCountRequest extends CustomerPlayInfoMonthSumRequest {


    private BigDecimal turnover;


}
