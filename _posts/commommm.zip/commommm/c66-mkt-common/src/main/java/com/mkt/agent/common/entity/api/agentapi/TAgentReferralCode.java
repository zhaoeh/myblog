package com.mkt.agent.common.entity.api.agentapi;

import com.baomidou.mybatisplus.annotation.TableName;
import com.mkt.agent.common.entity.BaseOperationEntity;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import javax.persistence.Table;

@Table(name="佣金方案表")
@TableName("t_agent_referral_code")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
public class TAgentReferralCode extends BaseOperationEntity {

    /*
       LOGIN_NAME
    */
    @Column(name="LOGIN_NAME",nullable = false)
    private String loginName;

    /*
        REFERRAL_ID
   */
    @Column(name="REFERRAL_ID",nullable = false)
    private String referralId;

    /*
         备注
    */
    @Column(name="REMARK",nullable = false)
    private String remark;


}
