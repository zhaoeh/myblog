package com.mkt.agent.common.entity.api.agentapi.requests;

import com.mkt.agent.common.entity.BasePageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class BatchQueryRequest extends BasePageRequest {
    private String creator;
    private String startTime;
    private String endTime;

    private byte queryType;

}
