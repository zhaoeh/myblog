package com.mkt.agent.common.config;

import com.alibaba.nacos.api.config.annotation.NacosConfigurationProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @Description TODO
 * @Classname dashBoardConfig
 * @Date 2023/12/6 14:38
 * @Created by TJSLucian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Component
@RefreshScope
public class DashBoardConfig {

    @Value("${dashboard.batchQuerySize:2000}")
    private Integer batchQuerySize;

    @Value("${dashboard.initThreadCount:1}")
    private Integer initThreadCount;

    @Value("${dashboard.threadPoolSize:10}")
    private Integer threadPoolSize;

    @Value("${dashboard.limitPeriod:}")
    private Long limitPeriod;

    @Value("${dashboard.limitCount:}")
    private Long limitCount;

    @Value("${dashboard.limitKey:}")
    private String limitKey;

}
