package com.mkt.agent.common.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * 操作类基类
 */
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class BaseOperationEntity extends BaseEntity {

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "创建人(Creator)")
    protected String createBy;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty(value = "更新人(Modifier)")
    protected String updateBy;

    @TableLogic
    protected Integer isDeleted;

    @ApiModelProperty(value = "备注")
    protected String remarks;

}
