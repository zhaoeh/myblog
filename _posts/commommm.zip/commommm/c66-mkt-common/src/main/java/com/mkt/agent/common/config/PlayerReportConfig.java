package com.mkt.agent.common.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * @description: player report config
 * @author: ErHu.Zhao
 * @create: 2024-02-21
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Component
@RefreshScope
public class PlayerReportConfig {

    /**
     * 是否强制禁止访问
     */
    @Value("${playerReport.forceLimit:false}")
    private Boolean forceLimit;

    /**
     * 向Mysql中批量插入时的批次大小
     */
    @Value("${playerReport.insertBatchSize:200000}")
    private Integer playerInsertBatchSize;

    /**
     * 查询最大条数限制，默认未-1，表示关闭最大条数限制
     */
    @Value("${playerReport.maxCountLimit:-1}")
    private Integer maxCountLimit;

    /**
     * 定时任务按天同步数据的天数：默认同步过去95天的数据
     */
    @Value("${playerReport.syncDays:95}")
    private Integer syncDays;

    /**
     * SCHEDULED定时任务指定清除几天前的数据（如果大于syncDays的值，则默认全量清空当前时间段符合条件的数据后重新同步），-1表示此配置无效
     */
    @Value("${playerReport.clearDays:-1}")
    private Integer clearDays;

    /**
     * 限流period配置
     */
    @Value("${playerReport.limitPeriod:}")
    private Long limitPeriod;

    /**
     * 限流访问次数配置
     */
    @Value("${playerReport.limitCount:}")
    private Long limitCount;

    /**
     * job数据同步时间范围分批，分为几批处理，<=1表示不进行分批
     */
    @Value("${playerReport.segments:1}")
    private Integer segments;

    /**
     * 是否开启异步执行时间分批策略：如果开启，则默认启动 segments 个线程异步执行job的数据同步；否则依然采用同步方式进行批处理
     */
    @Value("${playerReport.enableAsyncWithSegments:false}")
    private Boolean enableSegments;

    /**
     * 按天统计count，对于失败范围配置的重试次数
     */
    @Value("${playerReport.retryTimeWithFailedTask:3}")
    private Integer retryTimeWithFailedTask;

    /**
     * 天维度分批次
     */
    @Value("${playerReport.batchSizeByDay:2000}")
    private Integer batchSizeByDay;

    public Integer getSegments() {
        int max = 10;
        if (Objects.isNull(segments) || segments <= 1) {
            return 1;
        }
        if (segments > max) {
            return 3;
        }
        return segments;
    }

    public boolean isValidSegments(int appendSegments) {
        return getSegments() + appendSegments > 1;
    }

    public boolean ignoreMaxCountLimit(){
        return Objects.isNull(maxCountLimit) || maxCountLimit <= -1;
    }

}
