package com.mkt.agent.exclude.signature.exception;


/**
 * 缺失签名Header异常
 * @author yiqiang
 * @date 2024/05/14
 */
public class SignatureHeaderMissingException extends AbstractSignatureException {
    private static final long serialVersionUID = 26732288906799170L;

    public SignatureHeaderMissingException(String message) {
        super(message);
    }
}
