package com.mkt.agent.common.constants;

/**
 * redis red lock key const
 * @author PTHenry
 */
public class LockKeyConst
{
    public static final String PRE = "mkt:lock:";
    // 存款成功操作 锁
    public static final String DEPOSIT_SUCCESS = PRE + "deposit_success_";
}
