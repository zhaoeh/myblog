package com.mkt.agent.common.entity.api.reportapi.requests;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Description TODO
 * @Classname TAgentCountGroupMonthRequest
 * @Date 2024/2/5 18:09
 * @Created by TJSLucian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TAgentCountGroupMonthRequest {

    private List<String> agentAccountList;

    private List<String> agentMonthList;

    private String parent;

    private String agentAccount;

    private String agentMonth;
}
