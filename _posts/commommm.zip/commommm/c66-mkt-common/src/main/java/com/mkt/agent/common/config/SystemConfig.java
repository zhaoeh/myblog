package com.mkt.agent.common.config;

import com.alibaba.nacos.api.config.annotation.NacosConfigurationProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Component
@NacosConfigurationProperties(dataId = "mkt-share-config.yml", prefix = "executor", autoRefreshed = true)
@RefreshScope
public class SystemConfig {

    @Value("${executor.mkt.productId:C66}")
    private String productId;
}
