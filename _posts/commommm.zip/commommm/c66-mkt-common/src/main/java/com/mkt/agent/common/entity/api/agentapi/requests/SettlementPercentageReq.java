package com.mkt.agent.common.entity.api.agentapi.requests;

import com.mkt.agent.common.annotation.GameTypeColumn;
import com.mkt.agent.common.enums.CommissionValuesEnum;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Objects;

/**
 * @ClassName SettlementPercentageReq
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SettlementPercentageReq implements Serializable {


    @ApiModelProperty(value = "起始阶梯营业额")
    private Integer rangeOfTurnoverStart=0;

    @ApiModelProperty(value = "结束阶梯营业额")
    private Integer rangeOfTurnoverEnd=Integer.MAX_VALUE;

    @ApiModelProperty(value = "全量游戏百分比")
    @GameTypeColumn(CommissionValuesEnum.ALL_GAME_TYPES)
    private Float allGamesPercentage=0f;

    @ApiModelProperty(value = "bingo游戏百分比")
    @GameTypeColumn(CommissionValuesEnum.BY_GAME_TYPE)
    private Float bingoPercentage=0f;

    @ApiModelProperty(value = "slot游戏百分比")
    @GameTypeColumn(CommissionValuesEnum.BY_GAME_TYPE)
    private Float slotPercentage=0f;

    @ApiModelProperty(value = "sports游戏百分比")
    @GameTypeColumn(CommissionValuesEnum.BY_GAME_TYPE)
    private Float sportsPercentage=0f;

    @ApiModelProperty(value = "poker游戏百分比")
    @GameTypeColumn(CommissionValuesEnum.BY_GAME_TYPE)
    private Float pokerPercentage=0f;

    @ApiModelProperty(value = "eBingo游戏百分比")
    @GameTypeColumn(CommissionValuesEnum.BY_GAME_TYPE)
    private Float ebingoPercentage=0f;

    @ApiModelProperty(value = "casino游戏百分比")
    @GameTypeColumn(CommissionValuesEnum.BY_GAME_TYPE)
    private Float casinoPercentage=0f;

    @ApiModelProperty(value = "fishing游戏百分比")
    @GameTypeColumn(CommissionValuesEnum.BY_GAME_TYPE)
    private Float fishingPercentage=0f;

    @ApiModelProperty(value = "阶梯序号")
    private int order=0;

    public Integer getRangeOfTurnoverStart() {
        if(null==rangeOfTurnoverStart){
            return 0;
        }
        return rangeOfTurnoverStart;
    }

    public Integer getRangeOfTurnoverEnd() {
        if(null==rangeOfTurnoverStart){
            return Integer.MAX_VALUE;
        }
        return rangeOfTurnoverEnd;
    }


    //BY GAME PERCENTAGE TYPE
    public Boolean comparePercentage(SettlementPercentageReq currentPercentageReq) {
        if(!this.rangeOfTurnoverStart.equals(currentPercentageReq.rangeOfTurnoverStart)){
            return false;
        }
        if(!this.rangeOfTurnoverEnd.equals(currentPercentageReq.rangeOfTurnoverEnd)){
            return false;
        }
        if(!compare(this.allGamesPercentage,currentPercentageReq.allGamesPercentage)){
            return false;
        }
        if(!compare(this.bingoPercentage,currentPercentageReq.bingoPercentage)){
            return false;
        }
        if(!compare(this.slotPercentage,currentPercentageReq.slotPercentage)){
            return false;
        }
        if(!compare(this.sportsPercentage,currentPercentageReq.sportsPercentage)){
            return false;
        }
        if(!compare(this.pokerPercentage,currentPercentageReq.pokerPercentage)){
            return false;
        }
        if(!compare(this.ebingoPercentage,currentPercentageReq.ebingoPercentage)){
            return false;
        }
        if(!compare(this.casinoPercentage,currentPercentageReq.casinoPercentage)){
            return false;
        }
        if(!compare(this.fishingPercentage,currentPercentageReq.fishingPercentage)){
            return false;
        }
        return true;
    }


    public Boolean compare(Float index,Float index1) {
        if(!Objects.isNull(index)){
            if(Objects.isNull(index1)){
                return false;
            }
            if(index<index1){
                return false;
            }
        }else{
            return false;
        }
        return true;
    }

}
