package com.mkt.agent.common.utils;

import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.entity.system.LoginUserInfo;
import com.mkt.agent.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;

import java.util.Optional;

/**
 * @Description: 用户信息
 * @Author: PTMinnisLi
 * @Date: 2023/6/16
 */
@Slf4j
public class UserContext {

    private static final ThreadLocal<LoginUserInfo> USER_INFO_THREAD_LOCAL = new ThreadLocal<>();


    public static void setResponse(LoginUserInfo response) {
        USER_INFO_THREAD_LOCAL.set(response);
    }

    /**
     * 用户上下文中放入信息
     */
    public static void setContext(LoginUserInfo tokenInfo) {
        USER_INFO_THREAD_LOCAL.set(tokenInfo);
    }

    /**
     * 门店方调用接口时创建一个门店的上下文信息
     */
    public static void createBranchContext(String userName) {
        LoginUserInfo userInfo = new LoginUserInfo();
        userInfo.setUserId(Constants.BranchConstants.BRANCH_DEFAULT_CREATE_UPDATE_ID.toString());
        userInfo.setUsername(userName == null ? Constants.BranchConstants.BRANCH_DEFAULT_CREATE_UPDATE_BY : userName);
        USER_INFO_THREAD_LOCAL.set(userInfo);
    }

    /**
     * 门店方调用接口时创建一个门店的上下文信息
     */
    public static void createBranchContext(Long id, String userName) {
        LoginUserInfo userInfo = new LoginUserInfo();
        userInfo.setUserId(String.valueOf(id));
        userInfo.setUsername(userName == null ? Constants.BranchConstants.BRANCH_DEFAULT_CREATE_UPDATE_BY : userName);
        USER_INFO_THREAD_LOCAL.set(userInfo);
    }

    /**
     * 获取上下文中的信息
     */
    public static LoginUserInfo getContext() {
        return USER_INFO_THREAD_LOCAL.get();
    }

    /**
     * 获取上下文中的用户名--代理后台:userName（当前登录的管理员用户名）,代理前台:loginName当前登录的代理用户名）
     */
    public static String getUsername() {
        return getValidatedContext().getUsername();
    }

    /**
     * 获取上下文中的用户id--代理后台:userId（当前登录的管理员用户id）,代理前台:customerId当前登录的代理用户id）
     */
    public static String getUserId() {
        return getValidatedContext().getUserId();
    }

    /**
     * 获取上下文中的用户类型--代理后台:用户类型
     */
    public static String getUserType() {
        return getValidatedContext().getUserType();
    }

    /**
     * 清空上下文
     */
    public static void clear() {
        USER_INFO_THREAD_LOCAL.remove();
    }

    /**
     * 从线程上下文中获取用户信息，增加判空操作
     *
     * @return 如果线程上下文存在用户信息则返回用户信息
     */
    private static LoginUserInfo getValidatedContext() {
        return Optional.ofNullable(getContext()).orElseThrow(() -> {
            log.error("当前线程上下文中不存在用户信息，请确保当前用户在有效登录会话中");
            throw new BusinessException("当前登录用户不存在");
        });
    }
}
