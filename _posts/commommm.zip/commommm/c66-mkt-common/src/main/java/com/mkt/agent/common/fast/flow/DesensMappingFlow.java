package com.mkt.agent.common.fast.flow;

import com.alibaba.nacos.common.utils.CollectionUtils;
import com.google.common.collect.Lists;
import com.mkt.agent.common.fast.core.FastConfig;
import com.mkt.agent.common.fast.core.FastContext;
import com.mkt.agent.common.fast.core.FastCore;
import com.mkt.agent.common.fast.enums.StrategyEnums;
import com.mkt.agent.common.fast.pojo.AgentCustomersMapping;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @description: 代理脱敏流程
 * @author: ErHu.Zhao
 * @create: 2024-04-01
 **/
@Component
@Slf4j
public class DesensMappingFlow {

    private final FastCore fastCore;

    private Integer fastAgentsBatchSize;

    private final FastConfig fastConfig;

    public DesensMappingFlow(FastCore fastCore, FastConfig fastConfig) {
        this.fastCore = fastCore;
        this.fastConfig = fastConfig;
        this.fastAgentsBatchSize = fastConfig.getFastAgentsBatchSize();
    }

    /**
     * 根据条件决定是否分批处理
     *
     * @param mapping
     * @return
     */
    public int batchHandleAgentMappingWithRetry(FastContext fastContext, StrategyEnums strategy, List<AgentCustomersMapping> mapping, SqlSessionFactory factory, String nullAgent, String adminAgent) {
        if (CollectionUtils.isEmpty(mapping)) {
            return 0;
        }

        if (mapping.size() <= fastAgentsBatchSize) {
            return fastCore.handleAgentMappingWithRetry(fastContext, strategy, mapping, 0);
        }

        List<List<AgentCustomersMapping>> batches = Lists.partition(mapping, fastAgentsBatchSize);
        if (CollectionUtils.isEmpty(batches)) {
            return 0;
        }

        return batches.stream().map(m -> fastCore.handleAgentMappingWithRetry(fastContext, strategy, mapping, 0)).reduce((r1, r2) -> r1 + r2).orElse(0);
    }


}
