package com.mkt.agent.common.fast.event;

import com.mkt.agent.common.entity.TCustomerLayer;
import com.mkt.agent.common.entity.api.agentapi.TAgentCustomers;
import com.mkt.agent.common.fast.core.FastContext;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.ApplicationEvent;

import java.util.List;

/**
 * @description: 更改用户上级代理事件
 * @author: ErHu.Zhao
 * @create: 2024-04-11
 **/
public class UpdateParentEvent extends ApplicationEvent {

    private List<TAgentCustomers> agents;

    private List<TCustomerLayer> players;

    private FastContext fastContext;

    private SqlSessionFactory factory;

    public UpdateParentEvent(Object source, FastContext fastContext, List<TAgentCustomers> agents, List<TCustomerLayer> players, SqlSessionFactory factory) {
        super(source);
        this.agents = agents;
        this.players = players;
        this.fastContext = fastContext;
        this.factory = factory;
    }

    public List<TAgentCustomers> getAgents() {
        return agents;
    }

    public List<TCustomerLayer> getPlayers() {
        return players;
    }

    public FastContext getFastContext() {
        return fastContext;
    }

    public SqlSessionFactory getFactory() {
        return factory;
    }
}
