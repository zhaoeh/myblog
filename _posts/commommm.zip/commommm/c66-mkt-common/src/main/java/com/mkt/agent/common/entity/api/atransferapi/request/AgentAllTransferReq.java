package com.mkt.agent.common.entity.api.atransferapi.request;

import com.mkt.agent.common.annotation.DecryptField;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

/**
 * @Description 代理转账实体类
 * @Classname AgentAllTransferReq
 * @Date 2023/7/11 18:21
 * @Created by TJSLucian
 */
@Data
@ToString(exclude = {"withdrawalPassword"})
public class AgentAllTransferReq {

    @ApiModelProperty(required = true,value = "fromId")
    @NotNull(message = "fromId is required!")
    private Long fromId;

    @ApiModelProperty(required = true,value = "fromAccount")
    @NotNull(message = "fromAccount is required!")
    private String fromAccount;

    @ApiModelProperty(required = true,value = "toId")
    @NotNull(message = "toId is required!")
    private Long toId;

    @ApiModelProperty(required = true,value = "toAccount")
    @NotNull(message = "toAccount is required!")
    private String toAccount;

    @ApiModelProperty(required = true,value = "amount",example = "10.00")
    @NotNull(message = "amount is required!")
    @DecimalMin(value = "0.000000",message = "amount format is incorrect!")
    private BigDecimal amount;

    @NotBlank(message = "withdrawalPassword can not be blank")
    @ApiModelProperty(required = true, value = "取款密码，RSA加密<br/>Withdrawal password, RSA encrypt")
    @DecryptField
    private String withdrawalPassword;

    @ApiModelProperty(value = "currency",notes = "不传默认为PHP",example = "PHP")
    private String currency;

    @ApiModelProperty(required = true,value = "productId",example = "C66")
    @NotNull(message = "productId is required!")
    private String productId;

    @ApiModelProperty(required = true,value = "siteId 1:Bingoplus 2:Arenaplus 3:Gameplus",example = "1")
    @NotNull(message = "siteId is required!")
    private Integer siteId;

    @ApiModelProperty(required = true,value = "转账类型 0: Transfer 1: Paid Commission 2: Append Commission",example = "0")
    @NotNull(message = "transferType is required!")
    private Integer transferType;

    @ApiModelProperty(value = "备注", example = "123")
    private String remarks;

    @ApiModelProperty(value = "ipAddress",hidden = true)
    private String ipAddress;

    @ApiModelProperty(value = "productId",hidden = true)
    private String createBy;

    @ApiModelProperty(value = "A2A 代理转代理,A2P 代理转玩家/用户,P2A 用户转代理",hidden = true)
    private String fromToType;

    //消息处理属性
    private String messageId; // 消息唯一标识符
    private String sender;    // 发送者
    private String receiver;  // 接收者
    private Long timestamp; // 消息时间戳
    private String dateTime;
    private int status; //0: 未处理 1:已处理 2:处理失败

    public String getCreateBy() {
        return fromAccount;
    }

}
