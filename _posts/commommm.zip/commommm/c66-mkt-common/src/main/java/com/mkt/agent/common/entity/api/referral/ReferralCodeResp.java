package com.mkt.agent.common.entity.api.referral;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mkt.agent.common.enums.CustomizedValidationContents;
import com.mkt.agent.common.valid.EnumValid;
import com.mkt.agent.common.valid.InputValidationGroup;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @ClassName AgentReq
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
@Data
@NoArgsConstructor
public class ReferralCodeResp {

    /*
        主键
    */
    @Id
    @ApiModelProperty(value = "id")
    @NotNull(message = "id is not blank",groups = InputValidationGroup.Update.class)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Integer id;

    /*
        登录名
    */
    @ApiModelProperty(value = "登录名")
    @NotBlank(message = "loginName is not blank",groups = InputValidationGroup.Insert.class)
    private String loginName;

    /*
        产品
   */
    @ApiModelProperty(value = "所属产品")
    @NotBlank(message = "product id is not blank",groups = InputValidationGroup.Insert.class)
    private String productId;


    /*
        佣金方案code
    */
    @ApiModelProperty(value = "佣金方案code")
    //@NotNull(message = "commission contract code is not blank",groups = Insert.class)
    private Integer commissionContractCode;

    /*
        父级代理
   */
    @ApiModelProperty(value = "父级代理")
    @NotNull(message = "parent Id is not blank",groups = InputValidationGroup.Insert.class)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Long parentId;


    /*
        代理类型 0:普通 1:总代 2:专业代理
    */
    @ApiModelProperty(value = "代理类型")
    //@NotNull(message = "agent type is not blank",groups = Insert.class)
    @EnumValid(contents = CustomizedValidationContents.sub_agent_type_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class})
    private Integer agentType;


    /*
        代理可以发展最大下级代理层数
    */
    @ApiModelProperty(value = "可发展最大下级代理层数")
    @EnumValid(contents = CustomizedValidationContents.developable_level_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class})
    private Integer developableLevel;

    /*
        启用标识 0:启用 1:禁用
    */
    @ApiModelProperty(value = "启用标识")
    @EnumValid(contents = CustomizedValidationContents.sub_is_enable_values,groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class})
    private Integer flag=0;

    /*
        启用标识 0:启用 1:禁用
    */
    @ApiModelProperty(value = "Referral ID")
    @NotBlank(message = "Referral ID id is not blank",groups = {InputValidationGroup.Insert.class,InputValidationGroup.Update.class})
    private String referralId;

    @ApiModelProperty(value = "Referral Link")
    @NotBlank(message = "Referral Link id is not blank")
    private String referralLink;

    /*
         创建人
    */
    @ApiModelProperty(value = "创建人")
    //@NotBlank(message = "createdBy is not blank",groups = Insert.class)
    private String createdBy;

    /*
        逻辑删除
    */
    @ApiModelProperty(value = "删除标识")
    private int deleteFlag = 0;

    /*
        创建时间
    */
    @Column(name = "CREATE_TIME", nullable = false)
    private String createTime;

    /*
        修改人
    */
    @ApiModelProperty(value = "编辑者")
    @NotBlank(message = "updatedBy is not blank",groups = InputValidationGroup.Update.class)
    private String updatedBy;

    /*
        修改时间
    */
    @Column(name="UPDATE_TIME")
    private String updateTime;


    /*
        备注
    */
    @Column(name="remark")
    private String remark;

    @Override
    public String toString() {
        return "AgentReq{" +
                "id=" + id +
                ", loginName='" + loginName + '\'' +
                ", productId='" + productId + '\'' +
                ", commissionContractCode='" + commissionContractCode + '\'' +
                ", parentId=" + parentId +
                ", agentType=" + agentType +
                ", developableLevel=" + developableLevel +
                ", flag=" + flag +
                ", createdBy='" + createdBy + '\'' +
                ", deleteFlag=" + deleteFlag +
                ", createTime=" + createTime +
                ", updatedBy='" + updatedBy + '\'' +
                ", updateTime=" + updateTime +
                ", remark='" + remark + '\'' +
                '}';
    }
}
