package com.mkt.agent.common.player.core;

import com.google.common.collect.Lists;
import com.mkt.agent.common.config.PlayerReportConfig;
import com.mkt.agent.common.constants.Constants;
import com.mkt.agent.common.player.model.PlayerMapperHolder;
import com.mkt.agent.common.player.model.TAgentCountGroup;
import com.mkt.agent.common.entity.TAgentRefreshLog;
import com.mkt.agent.common.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * @description: 持久层操作器
 * @author: ErHu.Zhao
 * @create: 2024-02-02
 **/
@Component
@Slf4j
public class PlayerPersist {

    private final PlayerReportConfig playerReportConfig;

    public PlayerPersist(PlayerReportConfig playerReportConfig) {
        this.playerReportConfig = playerReportConfig;
    }

    /**
     * @param holder
     * @param groupInsertParam
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public int insertBatchAgentGroupCount(PlayerMapperHolder holder, List<TAgentCountGroup> groupInsertParam) {
        if (CollectionUtils.isEmpty(groupInsertParam)) {
            return 0;
        }
        int result = holder.getGroupInsertMapper().apply(groupInsertParam);
        return result;
    }


    /**
     * 大量数据分批次刷新
     *
     * @param holder
     * @param allAgentCountGroupDay
     * @param context
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public int batchRefreshWithPartition(PlayerMapperHolder holder, List<TAgentCountGroup> allAgentCountGroupDay, TAgentCountGroup context) {
        if (CollectionUtils.isEmpty(allAgentCountGroupDay)) {
            return 0;
        }
        deleteAgentGroupCount(holder, context);
        List<List<TAgentCountGroup>> batches = partition(allAgentCountGroupDay);
        int update = batches.stream().map(b -> insertBatchAgentGroupCount(holder, b)).reduce((r1, r2) -> r1 + r2).orElse(0);
        batches = null;
        return update;
    }

    /**
     * 批量刷新
     *
     * @param holder
     * @param groupInsertParam
     * @param groupDeleteParam
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public int refreshAgentGroupCount(PlayerMapperHolder holder,
                                      List<TAgentCountGroup> groupInsertParam, TAgentCountGroup groupDeleteParam) {
        if (CollectionUtils.isEmpty(groupInsertParam)) {
            return 0;
        }
        deleteAgentGroupCount(holder, groupDeleteParam);
        return insertBatchAgentGroupCount(holder, groupInsertParam);
    }

    /**
     * 批量删除
     *
     * @param holder
     * @param context
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public int deleteAgentGroupCount(PlayerMapperHolder holder, TAgentCountGroup context) {
        if (Objects.isNull(context)) {
            return 0;
        }
        if(BooleanUtils.isTrue(context.getForceClearAll()) && !BooleanUtils.isTrue(context.getIsNeedAsyncUpdate())){
            holder.getCountLogForceDeleteMapper().apply(TAgentRefreshLog.builder().handlerName(Constants.SYNC_TRANS_BY_DAY_HANDLER).build());
        }
        return holder.getGroupDeleteMapper().apply(context);
    }

    @Transactional(rollbackFor = Exception.class)
    public int deleteAgentGroupCountWithLogs(PlayerMapperHolder holder, TAgentCountGroup groupDeleteParam) {
        if (Objects.isNull(groupDeleteParam)) {
            return 0;
        }
        // job任务插入记录
        if (!BooleanUtils.isTrue(groupDeleteParam.getIsNeedAsyncUpdate())) {
            holder.getCountLogInsertMapper().apply(List.of(TAgentRefreshLog.builder().
                    refreshDate(DateUtils.getNDaysAgo(0).toString()).
                    beginDate(groupDeleteParam.getBeginDate()).
                    endDate(groupDeleteParam.getEndDate()).
                    runner(Thread.currentThread().getName()).
                    isSuccess(0).recordSize(0).handlerName(Constants.SYNC_TRANS_BY_DAY_HANDLER).build()));
        }
        return holder.getGroupDeleteMapper().apply(groupDeleteParam);
    }

    private List<List<TAgentCountGroup>> partition(List<TAgentCountGroup> sources){
        if(CollectionUtils.isEmpty(sources)){
            return Collections.emptyList();
        }
        return Lists.partition(sources, playerReportConfig.getPlayerInsertBatchSize());
    }

    /**
     * logsRefactor 处理
     *
     * @param holder
     */
    @Transactional(rollbackFor = Exception.class)
    public void logsRefactor(PlayerMapperHolder holder, TAgentCountGroup context) {
        // 删除10天之前的软删除数据
        holder.getCountLogForceDeleteMapper().apply(TAgentRefreshLog.builder().handlerName(Constants.SYNC_TRANS_BY_DAY_HANDLER).isDeleted(1).endDate(DateUtils.getNDaysAgo(10).toString()).build());
        // 失败或者record size为0的记录全部软删除
        holder.getCountLogDeleteMapper().apply(TAgentRefreshLog.builder().handlerName(Constants.SYNC_TRANS_BY_DAY_HANDLER).maxDateWithTiming(context.getMaxDateWithTiming()).isSuccess(0).build());
    }
}
