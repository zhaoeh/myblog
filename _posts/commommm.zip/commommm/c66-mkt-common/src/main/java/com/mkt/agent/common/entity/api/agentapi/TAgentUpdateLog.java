package com.mkt.agent.common.entity.api.agentapi;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.JDBCType;

/**
 * @Description TODO
 * @Classname TAgentUpdateLog
 * @Date 2023/12/8 18:08
 * @Created by TJSLucian
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TableName("t_agent_update_log")
public class TAgentUpdateLog {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String loginName;

    private String updateDate;

    private String updateDateTime;

    private int dashboardStatus;

    private int playerReportStatus;

}
