package com.mkt.agent.common.fast.core;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @description: fast配置
 * @author: ErHu.Zhao
 * @create: 2024-04-18
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Component
@RefreshScope
public class FastConfig {

    /**
     * fast功能开关
     */
    @Value("${fast.fastSwitch:false}")
    private Boolean fastSwitch;

    /**
     * 代理脱敏以及玩家关系转移失败重试次数
     */
    @Value("${fast.retryTimes:5}")
    private Integer fastRetryTimes;

    /**
     * 代理脱敏插入时分批阈值
     */
    @Value("${fast.agentsBatchSize:200000}")
    private Integer fastAgentsBatchSize;

    /**
     * 玩家关系转移插入时分批阈值
     */
    @Value("${fast.usersBatchSize:200000}")
    private Integer fastUsersBatchSize;

    /**
     * 玩家处理方式阈值分割点(总数超过该值采取另外一种方式)
     */
    @Value("${fast.fastPlayersCount:500000}")
    private Integer fastPlayersCount;

    /**
     * 少量玩家阈值
     */
    @Value("${fast.smallPlayersCount:5000}")
    private Integer smallPlayersCount;

    /**
     * 大代理玩家数量阈值，默认玩家总数大于该值的算大代理
     */
    @Value("${fast.usersSizeOfBigAgent:200000}")
    private Integer usersSizeOfBigAgent;

}
