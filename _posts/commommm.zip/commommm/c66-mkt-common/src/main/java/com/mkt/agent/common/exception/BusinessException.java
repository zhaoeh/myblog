package com.mkt.agent.common.exception;

import com.mkt.agent.common.enums.ResultEnum;
import lombok.Getter;

/**
 * @ClassName BusinessException
 * @Description 自定义业务异常
 * @Author TJSAlex
 * @Date 2023/5/19 12:11
 * @Version 1.0
 **/
@Getter
public class BusinessException extends RuntimeException{
    /**
     * 异常码
     */
    protected Integer code;

    public BusinessException() {
        super();
    }

    public BusinessException(String message) {
        super(message);
    }

    public BusinessException(String message, Integer code) {
        super(message);
        this.code = code;
    }

    public BusinessException(ResultEnum resultEnum) {
        super(resultEnum.getMessage());
        this.code = resultEnum.getCode();
    }

    public BusinessException(String message, Throwable cause) {
        super(message, cause);
    }
}
