package com.mkt.agent.common.dto;

import lombok.Data;

/**
 * @Description player_report按月查询时 便于查询封装的实体类 记录一个值--
 * @Classname TAgentCountGroupMonthDTO
 * @Date 2024/2/21 15:35
 * @Created by TJSLucian
 */
@Data
public class TAgentCountGroupMonthDTO {

    private Integer minusCount = 0;

}
