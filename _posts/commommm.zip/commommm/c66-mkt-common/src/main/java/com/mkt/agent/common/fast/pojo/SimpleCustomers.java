package com.mkt.agent.common.fast.pojo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-03-29
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SimpleCustomers {

    @Column(name = "curent_login", nullable = false)
    private String curentLogin;

    @Column(name = "login_name", nullable = false)
    private String loginName;

    @Column(name = "parent_name", nullable = false)
    private String parentName;

    @Column(name = "agent_level", nullable = false)
    private Integer agentLevel;

    @Column(name = "is_enable", nullable = false)
    private Integer isEnable;

    @Column(name = "is_deleted", nullable = false)
    private Integer isDeleted;

    @Column(name = "is_mapping_done", nullable = false)
    private Integer isMappingDone;


}
