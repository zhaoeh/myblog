package com.mkt.agent.common.entity.api.agentapi.responses;

import com.baomidou.mybatisplus.annotation.TableField;
import com.mkt.agent.common.entity.BatchInfo;
import com.mkt.agent.common.entity.api.agentapi.requests.SettlementPercentageReq;
import lombok.Data;
import org.springframework.beans.BeanUtils;

import java.util.List;

@Data
public class BatchQueryResp extends BatchInfo {

    //结算比例
    private List<SettlementPercentageReq> settlementPercentageList;

    public static BatchQueryResp fromBatchInfo(BatchInfo info) {
        BatchQueryResp resp = new BatchQueryResp();
        BeanUtils.copyProperties(info, resp);

        return resp;
    }
}
