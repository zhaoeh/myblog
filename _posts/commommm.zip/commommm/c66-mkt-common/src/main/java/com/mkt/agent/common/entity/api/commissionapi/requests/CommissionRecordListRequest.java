package com.mkt.agent.common.entity.api.commissionapi.requests;

import com.mkt.agent.common.entity.api.commissionapi.requests.base.CommissionRecordBaseRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel(value = "CommissionRecordListRequest", description = "Commission Record Query Request")
public class CommissionRecordListRequest extends CommissionRecordBaseRequest implements Serializable {


    private static final long serialVersionUID = 1l;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "commissionRecordId", example = "1111")
    private Long commissionRecordId;

    // 代理账户号：代理的唯一标识
    @ApiModelProperty(value = "agentAccount", example = "top")
    private String agentAccount;

    // 1 bp 2 ap 3 gp
    @ApiModelProperty(value = "siteId", example = "1")
    private String siteId;

    @ApiModelProperty(value = "productId", example = "C66")
    private String productId;

    @ApiModelProperty(value = "agentType", example = "1")
    private Integer agentType;

    @ApiModelProperty(value = "agentLevel", example = "1")
    private Integer agentLevel;

    // 代理上级代理账号：父级代理的账号
    @ApiModelProperty(value = "parentAccount", example = "acc66")
    private String parentAccount;

    @ApiModelProperty(value = "status", example = "0")
    private Integer status;

    // 佣金方案名称
    @ApiModelProperty(value = "commissionPlanName", example = "testName")
    private String commissionPlanName;

    @ApiModelProperty(value = "commissionType", example = "TURNOVER")
    private String commissionType;

    // 结算周期：ex:10 perday,7 perday,30 perday
    @ApiModelProperty(value = "settlementPeriod", example = "MONTH")
    private String settlementPeriod;


}


