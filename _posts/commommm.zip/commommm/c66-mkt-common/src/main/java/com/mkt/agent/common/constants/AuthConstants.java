package com.mkt.agent.common.constants;

/**
 * 权限认证相关常量
 */
public class AuthConstants {

    /**
     * 请求头userId的key(代理后台)
     */
    public static final String USER_ID = "userId";

    /**
     * 请求头username的key(代理后台)
     */
    public static final String USER_NAME = "username";

    /**
     * 请求头userType的key(代理后台)
     */
    public static final String USER_TYPE = "userType";

    /**
     * 请求头from的key(代理前台&后台)
     */
    public static final String USER_FROM = "from";

    /**
     * redis与响应体的access_token的key
     */
    public static final String ACCESS_TOKEN = "access_token";

    /**
     * redis与响应体的refresh_token的key
     */
    public static final String REFRESH_TOKEN = "refresh_token";

    /**
     * 请求头customers_id的key(代理前台)
     */
    public static final String CUSTOMERS_ID = "customers_id";

    /**
     * 请求头agent_type的key(代理前台)
     */
    public static final String LOGIN_NAME = "login_name";


    /**
     * 请求头UserInfo的key(
     */
    public static final String USER_INFO = "UserInfo";

    /**
     * 请求头token的key(
     */
    public static final String AUTH_HEADER = "Authorization";


}
