package com.mkt.agent.exclude.signature.endpoint;

import com.mkt.agent.common.entity.Result;
import com.mkt.agent.exclude.signature.exception.SignatureCheckException;
import com.mkt.agent.exclude.signature.exception.SignatureHeaderMissingException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * 兜底处理签名校验异常
 * @author yiqiang
 * @date 2024/05/14
 */
@Slf4j
@RestController
public class SignatureExceptionController {

    /**
     * 对抛出的签名异常做统一处理
     *
     * @param request {@link HttpServletRequest}
     * @return {@link Result<String>}
     */
    @RequestMapping("/signatureException")
    public Result<String> handleSignatureException(HttpServletRequest request) {
        Object exception = request.getAttribute("signatureException");

		// 这里也可以直接抛出，交由全局异常处理层处理
        RuntimeException signatureException;
        if (exception instanceof SignatureCheckException) {
            log.error("签名校验异常，说明请求被抓包，请求体被修改过了。修改之后的请求体内容：{}，异常：{}", request, exception);
            signatureException = (SignatureCheckException) exception;
        } else if (exception instanceof SignatureHeaderMissingException) {
            log.error("签名校验异常，说明请求被抓包，验签的Headers被删除了、缺失。请求体内容：{}，异常：{}", request, exception);
            signatureException = (SignatureHeaderMissingException) exception;
        } else {
            // 自定义的响应实体类，代码中应该都定义了。名字不一样罢了
            return Result.fail("验签异常");
        }

        return Result.fail(signatureException.getMessage());
    }
}

