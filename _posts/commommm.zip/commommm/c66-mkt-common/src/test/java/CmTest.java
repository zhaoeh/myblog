import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;

@Slf4j
public class CmTest {

    /**
     * 对于某些日期，比如 7月31日
     * 减少一个月后会出现问题
     * 因为 6 月没有 31 号
     * 在这种情况下
     * Java 的 Calendar实例会自动调整日期到下一个月的第一天
     * 所以如果当前是7月31日，减少一个月后，实际上会得到7月1日，而不是6月30日
     * @param args null
     */
    public static void main(String[] args) {
        // 设置为 7 月 31 号
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR,2023);
        // 月份从零开始
        calendar.set(Calendar.MONTH,Calendar.JULY);
        calendar.set(Calendar.DAY_OF_MONTH,31);

        int month = calendar.get(Calendar.MONTH);
        calendar.set(Calendar.MONTH, month - 1);
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        LocalDate localDate = LocalDate.ofInstant(calendar.toInstant(), ZoneId.systemDefault());
        log.info("old {}",localDate);

        log.info("new {}",getLastMonthLastDayV1());
    }

    public static LocalDate getLastMonthLastDayV1() {

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR,2023);
        calendar.set(Calendar.MONTH,Calendar.JULY);
        calendar.set(Calendar.DAY_OF_MONTH,31);

        // Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        calendar.add(Calendar.MONTH, -1);
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        return LocalDate.ofInstant(calendar.toInstant(), ZoneId.systemDefault());
    }
}
