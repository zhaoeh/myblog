package com.riskcontrol.common.entity.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.riskcontrol.common.annotation.Null2Empty;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import java.math.BigInteger;

/**
 * 登录风控表
 */
@TableName(value = "t_risk_action_login")
@Getter
@Setter
@Accessors(chain = true)
public class TRiskActionLogin {

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private BigInteger id;

    /**
     * 设备指纹token
     */
    @TableField(value = "device_fingerprint_token")
    private String deviceFingerprintToken;

    /**
     * 设备指纹
     */
    @TableField(value = "device_fingerprint")
    private String deviceFingerprint;

    /**
     * 登陆IP地址
     */
    @TableField(value = "login_ip")
    private String loginIp;

    /**
     * 登陆电话
     */
    @TableField(value = "phone_number")
    @Null2Empty
    private String phoneNumber;

    /**
     * 业务名(C66)
     */
    @TableField(value = "product_id")
    private String productId;

    /**
     * 用户名
     */
    @TableField(value = "login_name")
    private String loginName;

    /**
     * 产品标识(BP, AP, GP, PG, SP)
     */
    @TableField(value = "tenant")
    private String tenant;

    /**
     * 渠道(3:GLIFE, 4:GPO, 5:LAZADA,6:MAYA, 7:PERYAGAME, 91:PC, 92:H5, 93:IOS, 94:Android)
     */
    @TableField(value = "channel")
    private String channel;

    /**
     * 创建时间
     */
    @TableField(value = "create_date")
    private String createDate;

    /**
     * 创建人
     */
    @TableField(value = "create_by")
    private String createBy;

    /**
     * 更新时间
     */
    @TableField(value = "update_date")
    private String updateDate;

    /**
     * 更新人
     */
    @TableField(value = "update_by")
    private String updateBy;

    /**
     * 域名
     */
    @TableField(value = "domain_name")
    private String domainName;

    /**
     * 拦截类型(0:通过, 1:ip, 2:设备指纹, 3:ip+设备指纹, 4:调用顶象异常)
     */
    @TableField(value = "intercept_type")
    private Integer interceptType;

}
