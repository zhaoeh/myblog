package com.riskcontrol.common.entity.request.kyc;

import com.alibaba.fastjson.annotation.JSONField;
import com.cn.schema.customers.WSKycRequest;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.riskcontrol.common.entity.pojo.KycRequest;
import io.swagger.annotations.ApiModelProperty;

public class RiskCreateKycRequestRequest {
    @ApiModelProperty(
            required = true,
            value = "产品ID"
    )
    protected String infProductId;
    @ApiModelProperty(
            required = true,
            value = "产品密码"
    )
    protected String infPwd;
    @ApiModelProperty(
            required = true,
            value = "requestUUID"
    )
    protected String requestUUID;
    @ApiModelProperty(
            required = true,
            value = "需要创建的信息"
    )
    @JSONField(
            name = "wsKycRequest"
    )
    @JsonProperty("wsKycRequest")
    protected KycRequest wsKycRequest;

    public RiskCreateKycRequestRequest() {
    }

    public String getInfProductId() {
        return this.infProductId;
    }

    public void setInfProductId(String value) {
        this.infProductId = value;
    }

    public String getInfPwd() {
        return this.infPwd;
    }

    public void setInfPwd(String value) {
        this.infPwd = value;
    }

    public KycRequest getWsKycRequest() {
        return wsKycRequest;
    }

    public void setWsKycRequest(KycRequest wsKycRequest) {
        this.wsKycRequest = wsKycRequest;
    }

    public String getRequestUUID() {
        return this.requestUUID;
    }

    public void setRequestUUID(String requestUUID) {
        this.requestUUID = requestUUID;
    }

}
