package com.riskcontrol.common.entity.response.kyc;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 * @program: riskcontrol-api
 * @description: 风控kyc处理日志
 * @author: Colson
 * @create: 2023-12-15 15:52
 */
@ApiModel(value = "风险 Kyc 请求流程日志响应", description = "风险 Kyc 请求流程日志响应")
@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
public class RiskKycRequestProcessLogResponse implements Serializable {

    @ApiModelProperty("Id, primary Key")
    private String id;
    @ApiModelProperty("lastStauts")
    private Integer lastStauts;
    @ApiModelProperty("kycRequestId")
    private String kycRequestId;
    @ApiModelProperty("remark")
    private String remark;
    @ApiModelProperty("dispatchBy")
    private String dispatchBy;
    @ApiModelProperty("created Date")
    private String createTime;
    @ApiModelProperty("type")
    private String type;


}
