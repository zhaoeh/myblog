package com.riskcontrol.common.annotation;

import com.riskcontrol.common.validation.NotDuplicateValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

/**
 * @description: list重复元素校验注解
 * @author: ErHu.Zhao
 * @create: 2024-09-24
 **/
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {NotDuplicateValidator.class})
@Documented
public @interface NotDuplicate {
    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String message() default "不允许重复";
}
