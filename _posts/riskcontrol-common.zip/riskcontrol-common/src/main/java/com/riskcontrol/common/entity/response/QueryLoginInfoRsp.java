package com.riskcontrol.common.entity.response;

import lombok.Data;

@Data
public class QueryLoginInfoRsp {


    private String loginIp;

    private String customerId;

    private String loginName;

    private String loginTime;
}
