package com.riskcontrol.common.entity.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import java.math.BigInteger;

/**
 * @author Zhilin.Du
 */
@TableName(value = "t_risk_action_rules")
@Getter
@Setter
@Accessors(chain = true)
public class TRiskActionRules {

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private BigInteger id;

    /**
     * 规则校验类型（0：ip ; 1：设备指纹；2：ip+设备指纹）
     */
    @TableField(value = "rules_type")
    private Integer rulesType;

    /**
     * 规则限制行为（0：登录：1：注册）
     */
    @TableField(value = "rules_action")
    private Integer rulesAction;

    /**
     * 规则限制账号最大数量
     */
    @TableField(value = "rules_account_max")
    private Integer rulesAccountMax;

    /**
     * 规则数据查询天数
     */
    @TableField(value = "rules_check_day")
    private Integer rulesCheckDay;

    /**
     * 产品标识(BP, AP, GP, PG, SP)
     */
    @TableField(value = "tenant")
    private String tenant;

    /**
     * '
     * 是否启用（0：启用；1：禁用）
     */
    @TableField(value = "is_enable")
    private Integer isEnable;

    /**
     * 备注
     */
    @TableField(value = "remark")
    private String remark;

    /**
     * 创建时间
     */
    @TableField(value = "create_date")
    private String createDate;

    /**
     * 创建人
     */
    @TableField(value = "create_by")
    private String createBy;

    /**
     * 更新时间
     */
    @TableField(value = "update_date")
    private String updateDate;

    /**
     * 更新人
     */
    @TableField(value = "update_by")
    private String updateBy;

}