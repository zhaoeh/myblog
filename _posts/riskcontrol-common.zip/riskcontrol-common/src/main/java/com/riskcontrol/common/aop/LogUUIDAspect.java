package com.riskcontrol.common.aop;

import com.riskcontrol.common.utils.LogUtils;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

/**
 * @Description: mq接收消息设置uuid
 * @Auther: yannis
 * @create: 2023-10-27
 */
@Slf4j
@Aspect
@Component
public class LogUUIDAspect {


    @Pointcut("@annotation(com.riskcontrol.common.annotation.LogUUID)")
    public void logPointcut(){}

    @Before(value = "logPointcut()")
    public void doBefore(JoinPoint joinPoint) {
        LogUtils.generatedThreadLogUUID();
    }
    @After(value = "logPointcut()")
    public void doAfter(JoinPoint joinPoint)
    {
        LogUtils.cleanLogUUID();
    }

}
