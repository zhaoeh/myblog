package com.riskcontrol.common.client;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.customers.*;
import com.cn.schema.request.*;
import com.riskcontrol.common.entity.request.UserCompleteCustomerRequest;
import com.riskcontrol.common.entity.request.UserQueryCheckCustomerInfoRequest;
import com.riskcontrol.common.entity.request.UserQueryCustomersBasicByLoginNameRequest;
import com.riskcontrol.common.entity.request.UserQueryCustomersByCustomerIdRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * @program: riskcontrol-common
 * @description: c66-integral-api
 * @author: sanji
 * @create: 2024-05-27 13:52
 */
@FeignClient(name = "c66-integral-api")
public interface IntegralFeign {

    /**
     * 查询优惠申请报表
     * @param request
     * @return
     */
    @PostMapping(value = "/request/promotion/query_report_count")
    QueryCountReportPromotionResponse getCountReportPromotion(QueryCountReportPromotionRequest request);
}
