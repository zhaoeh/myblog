package com.riskcontrol.common.constants;

/**
 * sql常量
 */
public class SQLConstants {

    /**
     * 查询sql常量
     */
    public static class Query {
        /**
         * equal
         */
        public static final String EQ = "eq";
        /**
         * not equal
         */
        public static final String NE = "ne";
        /**
         * in
         */
        public static final String IN = "in";
        /**
         * like
         */
        public static final String LIKE = "like";
        /**
         * likeRight
         */
        public static final String LIKE_RIGHT = "likeRight";
        /**
         * greater than >
         */
        public static final String GT = "gt";
        /**
         * greater&equals than >=
         */
        public static final String GE = "ge";
        /**
         * less than <
         */
        public static final String LT = "lt";
        /**
         * less&equals than <=
         */
        public static final String LE = "le";
    }
}
