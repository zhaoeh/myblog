package com.riskcontrol.common.entity.request.message;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

/**
 * 推送消息请求
 * @author dante
 */
@Data
public class PushContentReq {
        /**
         * 模板动态参数  {"{0}": "Martin","{1}": "CG01"}
         */
        JSONObject data;
        /**
         * 推送模板ID temId
         */
        String paramId;
        /**
         * 请求唯一值
         */
        String billNo;
        /**
         * 批量推送的人员 只针对 当前消息体默认类型
         */
        String loginName;

}
