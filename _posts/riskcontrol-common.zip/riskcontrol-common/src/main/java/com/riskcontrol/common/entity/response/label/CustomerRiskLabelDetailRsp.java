package com.riskcontrol.common.entity.response.label;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigInteger;

/**
 * <p>
 * 风控标签信息
 * </p>
 *
 * @author Colson
 * @since 2024-01-11
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@ApiModel(value = "RiskLabelDetailRsp对象", description = "风控标签详细信息")
public class CustomerRiskLabelDetailRsp implements Serializable {

    @ApiModelProperty("所属产品")
    private String productId;

    @ApiModelProperty("风控标签名称")
    private String riskLabelName;

    @ApiModelProperty("风控标签ID")
    private BigInteger riskLabelId;

    @ApiModelProperty("风控标签key")
    private String riskLabelKey;

}
