
package com.riskcontrol.common.client;

import com.riskcontrol.common.entity.response.Response;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestPart;

/**
 * @program: c66-message-api
 * @description: push api
 * @author: dante
 * @create: 2024-08-15
 */
@FeignClient(name = "c66-message-api")
public interface MessageApiFeign {

    /**
     * 推送模板消息
     * @param exchange
     * @param routingKey
     * @param message
     * @return
     */
    @PostMapping(value = "/send-template/push",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    Response<String> pushMessage(@RequestPart("exchange") String exchange ,@RequestPart("routingKey")String routingKey,@RequestPart("message") String message);
}