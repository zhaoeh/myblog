package com.riskcontrol.common.entity.request;

import com.cn.schema.customers.WSQueryCustomers;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * @program: riskcontrol-common
 * @description: 客户信息查询请求
 * @author: Erhu.Zhao
 * @create: 2023-11-21 18:46
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Accessors(chain = true)
public class ApiQueryCustomersRequest {

    private String requestUUID;

    private String infProductId;

    private String infPwd;

    private String customerId;

    private WSQueryCustomers wsQueryCustomers;
}