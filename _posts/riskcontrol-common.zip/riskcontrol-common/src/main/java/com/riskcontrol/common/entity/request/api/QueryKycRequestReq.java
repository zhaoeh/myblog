package com.riskcontrol.common.entity.request.api;

import com.riskcontrol.common.entity.request.BaseQueryReq;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(title = "查询玩家详细列表请求参数")
@Data
public class QueryKycRequestReq extends BaseQueryReq {


    @Schema(description = "玩家账号")
    private String customerName;

    @Schema(description = "分配人")
    private String assigneeBy;

    @Schema(description = "assignee Begin", example = "")
    private String assigneeDateBegin;

    @Schema(description = "assignee End", example = "")
    private String assigneeDateEnd;

    @Schema(description = "createdDate Begin", example = "")
    private String createdDateBegin;

    @Schema(description = "createdDate End", example = "")
    private String createdDateEnd;

    @Schema(description = "审核状态", example = "")
    private Integer processType;
    @Schema(description = "pbc提案单号", example = "")
    private String billNo;
    @Schema(description = "产品", example = "")
    private String product;
    @Schema(description = "渠道", example = "")
    private String channel;

}
