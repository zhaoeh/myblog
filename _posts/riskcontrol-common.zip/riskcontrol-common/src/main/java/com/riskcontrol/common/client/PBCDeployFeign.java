package com.riskcontrol.common.client;


import com.riskcontrol.common.entity.request.api.PBCDeployDisableRequest;
import com.riskcontrol.common.entity.request.api.PBCDeployUpdateRequest;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.api.PBCDeployRsp;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import javax.validation.Valid;
import java.util.List;

/**
 * @program: riskcontrol-common
 * @description: 风控PBC配置相关接口
 * @author: hongwei
 * @create: 2023-11-14 12:16
 */
@FeignClient(name = "riskcontrol-cron",contextId = "risk-cron-api-second")
public interface PBCDeployFeign {

    @PostMapping(value = "/pbc/deploy")
    public Response<List<PBCDeployRsp>> getDeployList();

    @PostMapping(value = "/pbc/updateDeploy")
    public Response updateDeploy(@RequestBody PBCDeployUpdateRequest deployUpdateRequest);

    @PostMapping(value = "/pbc/deleteDeploy")
    public Response deleteDeploy(@RequestBody PBCDeployDisableRequest deployDisableRequest);




}
