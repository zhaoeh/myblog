package com.riskcontrol.common.entity.zoloz;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/10/2 17:01
 */
@AllArgsConstructor
@NoArgsConstructor
@ApiModel("初始化id+人脸验证结果")
@Data
public class RealIDResult {
    @ApiModelProperty(value = "{\"resultStatus\": \"S\", \"resultCode\": \"SUCCESS\",  \"resultMessage\": \"Success\" }" )
    private Result result;
    @ApiModelProperty(value = "标识整个身份验证进程的运行状态,Success：身份验证运行成功。\n" +
            "Pending：身份验证结果待人工确认。\n" +
            "Failure：身份验证失败，可能是证件验证、人脸验证或风控处理失败导致。\n" +
            "InProcess：正在身份验证中。\n" +
            "VoidCancelled：用户取消了身份验证。\n" +
            "VoidTimeout：身份验证超时。" +
            "当result.resultStatus的值为S时，才返回该字段" )
    private String ekycResult;
    @ApiModelProperty(value = "eKYC申请中人脸验证的详细信息" )
    private ExtFaceInfo extFaceInfo;
    @ApiModelProperty(value = "eKYC申请中证件验证的详细信息" )
    private ExtIdInfo extIdInfo;
    @ApiModelProperty(value = "eKYC申请中证件验证的风险信息" )
    private ExtRiskInfo extRiskInfo;

    @Data
    public static class ExtFaceInfo {
        @ApiModelProperty(value = "人脸模块的验证结果。 Success：人脸验证成功。Pending：人脸验证结果待人工确认。Failure：人脸验证失败。" )
        private String ekycResultFace;
        @ApiModelProperty(value = "人脸比对分数，取值范围0-100" )
        private Integer faceScore;
        @ApiModelProperty(value = "返回的人脸图片，当isReturnImage的值为Y，且人脸采集成功时才返回该字段。" )
        @JsonIgnore
        private String faceImg;
    }
    @Data
    public static class ExtIdInfo {
        @ApiModelProperty(value = "证件模块的验证结果 Success：人脸验证成功。Pending：人脸验证结果待人工确认。Failure：人脸验证失败。" )
        private String ekycResultDoc;
        @ApiModelProperty(value = "证件的正面照，采用Base64编码格式" )
        @JsonIgnore
        private String frontPageImg;
        @ApiModelProperty(value = "证件的背面照（如果有），采用Base64编码格式" )
        @JsonIgnore
        private String backPageImg;
        @ApiModelProperty(value = "证件识别的字段" )
        private OcrResult ocrResult;
        @ApiModelProperty(value = "证件识别不通过明细。\n" +
                "\n" +
                "NO_REQUIRED_ID：证件图片不符合指定的证件类型。\n" +
                "BLUR：证件图片模糊。\n" +
                "NO_FACE_DETECTED：未检测到证件上的人脸。\n" +
                "NOT_REAL_DOC：证件防伪检测不通过。\n" +
                "EXPOSURE：证件图片过度曝光。\n" +
                "UNKNOWN：其他错误。" )
        private String docErrorDetails;
        @Data
        public static class OcrResult {
            @JSONField(name = "FIRST_NAME")
            private String firstName;
            @JSONField(name = "MIDDLE_NAME")
            private String middleName;
            @JSONField(name = "LAST_NAME")
            private String lastName;
            @JSONField(name = "ID_NUMBER")
            private String idNumber;
            @JSONField(name = "DATE_OF_BIRTH")
            private String birthDay;
            @JSONField(name = "SEX")
            private String sex;
        }
    }
    @Data
    public static class ExtRiskInfo {
        @ApiModelProperty(value = "风控模块的验证结果 Success：人脸验证成功。Pending：人脸验证结果待人工确认。Failure：人脸验证失败。" )
        private String ekycResultRisk;
        @ApiModelProperty(value = "风险检测结果 " +
                "PASS：身份验证通过了风险检测。\n" +
                "VELOCITY_HIGH_RISK：风控引擎检测到高风险。\n" +
                "ID_NETWORK_HIGH_RISK：通过IdNetwork检测到虚假验证风险。例如，检测到识别出的人脸与多个身份证件相关或检测到一个身份证件与多张人脸相关。\n" +
                "说明：同一用户或同一证件号检测出相同的人脸不会触发该风险。\n" +
                "BLACKLIST_HIGH_RISK：黑名单扫描检测到高风险。\n" +
                "AGE_MISMATCH_HIGH_RISK：在年龄验证过程中检测到高风险。" )
        private String strategyPassResult;
    }
}
