package com.riskcontrol.common.entity.zoloz;

/**
 * @author: sanji
 * @desc: zoloz结果常量
 * @date: 2024/10/7 15:49
 */
public class ResultStatusStr {
    public static final String SUCCESS ="Success";//通过
    public static final String PENDING ="Pending";//需人工确认
    public static final String FAILURE ="Failure";//失败、拒绝

    /**
     * ekyc风险控制需转人工，证件和人脸通过
     */
    public static final String RISK_PENDING ="risk_Pending";//风控拒绝，人工
    public static final String RISK_SAME_FACE_OR_ID ="same face or id";//相同人脸或证件，自动通过
    public static final String RISK_SYSTEM_CANCELLED ="system Cancelled";//切换证件做ekyc，取消上一笔
}
