package com.riskcontrol.common.entity.request.api;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.riskcontrol.common.annotation.Query;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigInteger;

/**
 * @Description: 查询风控字典请求对象
 * @Auther: yannis
 * @create: 2024-01-11
 */
@Data
@ApiModel(value = "查询风控字典请求对象", description = "查询风控字典参数")
public class QueryRiskConstants implements Serializable {
    @ApiModelProperty("产品id")
    @Query
    private String productId;

    @ApiModelProperty("ID")
    @Query
    private BigInteger id;

    @ApiModelProperty("常量key")
    @Query
    @JsonAlias("pKey")
    private String pKey;

    @ApiModelProperty("类型")
    @Query
    @JsonAlias("pType")
    private String pType;

    @ApiModelProperty("标志:0-未启用；1-已启用")
    @Query
    private Integer isEnable;

    @ApiModelProperty("是否删除：0-否 ；1-是")
    @Query
    private Integer isDeleted;
}
