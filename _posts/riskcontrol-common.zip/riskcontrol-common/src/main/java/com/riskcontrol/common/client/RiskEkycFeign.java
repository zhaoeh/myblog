package com.riskcontrol.common.client;


import com.riskcontrol.common.entity.pojo.Ekyc;
import com.riskcontrol.common.entity.pojo.EkycRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycCreateRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycUpdateRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycExtendRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycZolozErrorRequest;
import com.riskcontrol.common.entity.response.Response;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import javax.validation.constraints.NotEmpty;


/**
 * @program: riskcontrol-common
 * @description: ekyc服务接口
 * @author: yueds
 * @create: 2024-10-08 12:23
 */
@FeignClient(name = "riskcontrol-cron", contextId = "risk-cron-api-fourth")
public interface RiskEkycFeign {

    /**
     * 查询用户ekyc状态*
     *
     * @param loginName 账号
     * @return ekyc状态
     */
    @GetMapping(value = "/ekyc/queryStatus/{loginName}")
    Response<Ekyc> queryStatus(@PathVariable String loginName);

    /**
     * 查询目标用户最近一笔kyc提案*
     *
     * @param loginName
     * @return
     */
    @GetMapping(value = "/ekyc/queryCurrentKyc/{loginName}")
    Response<EkycRequest> queryCurrentKycRequest(@PathVariable String loginName);

    /**
     * 完善ekyc状态*
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/ekyc/modifyEkycRequest")
    Response<Boolean> modifyEkycRequest(@RequestBody EkycExtendRequest request);

    /**
     * 创建ekyc提案
     * @return 是否处理成功
     */
    @PostMapping(value = "/ekyc/createEkycRequest")
    Response<Boolean> createEkycRequest(@RequestBody EkycCreateRequest request);

    /**
     * 第三方认证成功之后信息回写
     * @return 是否处理成功
     */
    @PostMapping(value = "/ekyc/saveVerificationInfo")
    Response<Boolean> saveVerificationInfo(@RequestBody EkycUpdateRequest request);
    /**
     * 第三方认证失败之后更新ekyc
     * @return 是否处理成功
     */
    @PostMapping(value = "/ekyc/updateEkycStatus")
    Response<Boolean> updateEkycStatus(@RequestBody EkycZolozErrorRequest request);
    @GetMapping(value = "/riskBlack/getBlackStatus/{loginName}")
    Response<Boolean> getBlackStatus(@PathVariable @Validated @NotEmpty String loginName);
}
