package com.riskcontrol.common.client;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.customers.*;
import com.cn.schema.products.WSProductConstants;
import com.cn.schema.products.WSQueryProductConstants;
import com.cn.schema.request.*;
import com.riskcontrol.common.config.CustomizedFeignConfiguration;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.pojo.TPbcCrawlerResultNew;
import com.riskcontrol.common.entity.request.PbcCrawlerUpdateStatusReq;
import com.riskcontrol.common.entity.request.api.QueryRiskConstants;
import com.riskcontrol.common.entity.request.kyc.RiskCreateKycRequestRequest;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequest;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequestRequest;
import com.riskcontrol.common.entity.request.kyc.RiskUpdateKycRequestRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelBindingRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelByCustomerIdRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelListRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelRemoveBindingRequest;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.api.RiskConstantsRsp;
import com.riskcontrol.common.entity.response.kyc.RiskQueryKycRequestResponse;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelRsp;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.List;

/**
 * feign interface of risk common
 *
 * @program: riskcontrol-common
 * @description: riskContolCron使用feign调用
 * @author: Erhu.Zhao
 * @create: 2023-10-04 15:31
 **/
@FeignClient(name = "riskcontrol-cron", contextId = "risk-cron-api-first", configuration = CustomizedFeignConfiguration.class)
public interface CronFeign {

    /**
     * 查询kyc
     *
     * @param request kyc request of query
     * @return query result
     */
    @PostMapping(value = "customers/kyc_request/query")
    Response<RiskQueryKycRequestResponse> queryKycRequest(RiskQueryKycRequestRequest request);

    /**
     * 新增kyc
     *
     * @param request kyc request of create
     * @return add result
     */
    @PostMapping(value = "customers/kyc_request/create")
    Response<CreateKycRequestResponse> addKycRequest(RiskCreateKycRequestRequest request);

    /**
     * 更新kyc
     *
     * @param request kyc request of update
     * @return update result
     */
    @PostMapping(value = "customers/kyc_request/update")
    Response<ModifyKycRequestResponse> updateKycRequest(RiskUpdateKycRequestRequest request);

    /**
     * 查询kyc count
     *
     * @param request kyc request of query count
     * @return query count result
     */
    @PostMapping({"customers/kyc_request/count"})
    Response<QueryKycRequestResponse> countKycRequest(RiskQueryKycRequestRequest request);

    @PostMapping(value = "customers/kyc_request/pbcDispatch")
    Response<ModifyKycRequestResponse> pbcDispatch(RiskUpdateKycRequestRequest request);

    @PostMapping(value = "customers/kyc_request/pbcModifyStatus")
    Response<ModifyKycRequestResponse> pbcModifyStatus(RiskUpdateKycRequestRequest request);

    @PostMapping(value = "customers/kyc_request/queryWaitPendingCount")
    Response<QueryCountResponse> queryWaitPendingCount(KycRequest request);

    @PostMapping(value = "customers/kyc_request/dispatch")
    Response<RiskQueryKycRequestResponse> dispatch(KycRequest request);

    @PostMapping(value = "customers/kyc_request/dispatchCancel")
    Response<KycDispatchConfirmResponse> dispatchCancel(KycRequest request);


    @PostMapping(value = "customers/kyc_request/queryKycPbcRequest")
    Response<RiskQueryKycRequestResponse> queryKycPbcRequest(RiskQueryKycRequestRequest request);


    /**
     * 新增 导出接口查询
     *
     * @param request
     * @return
     */
    @PostMapping(value = "customers/kyc_request/queryKycSheetRequest")
    Response<QueryKycSheetListRequestResponse> queryKycSheetRequest(RiskQueryKycRequestRequest request);


    @PostMapping({"customers/kyc_request/countKycPbcRequest"})
    Response<QueryKycRequestResponse> countKycPbcRequest(RiskQueryKycRequestRequest request);


    @PostMapping({"customers/kyc_request/bactchModifyPbcStatus"})
    Response<BatchModifyPbcRequestResponse> bactchModifyPbcStatus(BatchUpdateKycRequestRequest request);


    @PostMapping({"customers/kyc_request/queryPageByKycRequestId"})
    Response<QueryKycRequestProcessLogResponse> queryPageByKycRequestId(UpdateKycRequestRequest request);


    @PostMapping({"customers/kyc_request/checkDispatchConfirm"})
    Response<KycDispatchConfirmResponse> checkDispatchConfirm(KycDispatchConfirmRequest request);

    @PostMapping({"customers/kyc_request/dispatchConfirm"})
    Response<KycDispatchConfirmResponse> dispatchKycRequestConfirm(KycDispatchConfirmRequest request);

    @PostMapping({"local/cache/loadLocalCacheInfoByKeyFromCron"})
    Response<Object> loadLocalCacheInfoByKeyFromCron(String cacheKey);

    @PostMapping({"productConstants/queryList"})
    Response<List<WSProductConstants>> queryProductConstants(WSQueryProductConstants request);

    @PostMapping({"customers/kyc_request/modifyCustomConfiguration"})
    Response<JSONObject> modifyCustomConfiguration(JSONObject request);

    @PostMapping({"redis/operation/doOperationForRedis"})
    Response<JSONObject> doOperationForRedis(JSONObject request);

    /**
     * 自动通过KYC和PBC *
     *
     * @param request -
     * @return -
     */
    @PostMapping({"customers/kyc_request/autoApproveKycAndPbc"})
    Response<ModifyKycRequestResponse> autoApproveKycAndPbc(RiskUpdateKycRequestRequest request);

    @PostMapping({"customers/kyc_request/pending_count"})
    Response<DispatchPendingCountResponse> pendingCount(WSDispatchRecord request);

    /**
     * 风控常量列表
     *
     * @param request
     * @return
     */
    @PostMapping({"productConstants/queryRiskConstantsList"})
    Response<List<RiskConstantsRsp>> queryRiskConstantsList(QueryRiskConstants request);

    /**
     * 批量查询风控标签
     *
     * @param request -*
     * @return
     */
    @PostMapping({"risk/label/customer/list"})
    Response<List<CustomerRiskLabelRsp>> listCustomerRiskLabel(RiskLabelListRequest request);

    /**
     * 用户风控标签详情
     *
     * @param request -
     * @return
     */
    @PostMapping({"risk/label/customer/detail"})
    Response<CustomerRiskLabelRsp> getRiskLabelDetail(RiskLabelByCustomerIdRequest request);

    /**
     * 绑定风控标签
     *
     * @param request -
     * @return
     */
    @PostMapping({"risk/label/customer/binding"})
    Response<Boolean> bindingCustomerRiskLabel(RiskLabelBindingRequest request);

    /**
     * 解除用户风控标签
     *
     * @param request -
     * @return
     */
    @PostMapping({"risk/label/customer/removeLabel"})
    Response<Boolean> removeLabel(RiskLabelRemoveBindingRequest request);

    /**
     * 查询用户kyc状态（所有状态）
     *
     * @param params -
     * @return
     */
    @PostMapping({"/customers/kyc_request/queryKycStatusByCustomerId"})
    Response<List<Integer>> queryKycStatusByCustomerId(RiskQueryKycRequest params);

    /**
     * 检验kyc idNo和idType是否存在
     * @param idType 证件类型
     * @param idNo 证件id
     * @return
     */
    @PostMapping({"/customers/kyc_request/validKycIdAndType"})
    Response<Boolean> validKycIdAndType(@RequestParam("idType") Integer idType,@RequestParam("idNo") String idNo);

    /**
     * 查询指定用户kyc信息，最有效的一条 （已审批>待审批>）
     * @param query
     * @return
     */
    @PostMapping({"/customers/kyc_request/queryKycByLoginNameOrderOne"})
    Response<KycRequest> queryKycByLoginNameOrderOne(RiskQueryKycRequest query);


//    @PostMapping({"/customers/kyc_request/queryKycByLoginNameOrderOne"})
//    String queryKycByLoginNameOrderOne(RiskQueryKycRequest query);



    @PostMapping({"/customers/withdrawal/queryWithdrawInfoByRequestId"})
    Response<String> queryWithdrawInfoByRequestId(@RequestParam("requestId") String requestId, @RequestParam("productId")String productId);

    /**
     * 根据全名查询pagcor数据，并写入pbc爬虫数据表.
     * 执行逆向 匹配新老kyc 命中黑名单逻辑.
     *
     * @param fullName        全名
     * @param currentUsername 当前登陆的用户名
     * @return 返回匹配的爬虫数据列表
     */
    @PostMapping({"/pbcCrawler/pullPagcorDataToDb/byFullName"})
    Response<List<TPbcCrawlerResultNew>> pullPagcorDataToDbByFullName(@RequestParam("fullName") String fullName, @RequestParam("currentUsername") String currentUsername);

    /**
     * 解除/禁用PBC接口
     */
    @PostMapping({"/pbcCrawler/updateStatus"})
    Response<Boolean> updateStatusOfTPbcCrawlerResultNew(@RequestBody PbcCrawlerUpdateStatusReq pbcCrawlerUpdateStatusReq);

}
