package com.riskcontrol.common.service;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.gw.datacenter.common.constants.UtilConstants;
import com.gw.datacenter.vo.order.OrderReq;
import com.gw.datacenter.vo.order.OrderSummaryNew;
import com.gw.datacenter.vo.pagainate.QueryResult;
import com.gw.datacenter.vo.pagainate.QueryResultWrapper;
import com.riskcontrol.common.client.GdApiCenterFeign;
import com.riskcontrol.common.utils.MD5Util;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/9/23 16:41
 */
@Slf4j
@Component
public class GdApiFeignTemplate {
    @Resource
    private GdApiCenterFeign gdApiCenterFeign;

    public QueryResult<OrderSummaryNew> getSummaryNewByLoginName(String productId,String loginName, String beginTime, String endTime) {
        try {
            String sb = productId + loginName + beginTime + endTime+UtilConstants.SUFFIX;
            String key = DigestUtils.md5Hex(sb);
            JSONObject object = new JSONObject();
            object.put("productId",productId);
            object.put("loginName",loginName);
            object.put("beginTime",beginTime);
            object.put("endTime",endTime);
            object.put("key",key);
            log.info("调用gd-api getOrderSummaryNewByLoginName param={}",object.toJSONString());
            JSONObject apiResult = gdApiCenterFeign.getOrderSummaryNewByLoginName(object);
            log.info("调用gd-api getOrderSummaryNewByLoginName resp={}", JSONObject.toJSONString(apiResult));
            if(apiResult!=null && apiResult.getInteger("errorCode").equals(1) ){
                return apiResult.getObject ("objs", new TypeReference<QueryResult<OrderSummaryNew>>(){});
            }
            log.info("调用gd-api getOrderSummaryNewByLoginName 返回错误  resp={}", JSONObject.toJSONString(apiResult));
        } catch (Exception e) {
            log.error("调用gd-api getSummaryNewByLoginName 异常", e);
        }
        return null;
    }

    public QueryResultWrapper getCountTotalStrRecordAndSummaryV2(OrderReq order) {
        try {
            String sb = order.getProductId() +
                    (order.getLoginName() == null ? "" : StringUtils.join(order.getLoginName(), ",")) +
                    (StringUtils.isBlank(order.getBeginTime()) ? order.getBeginReckonTime() : order.getBeginTime()) +
                    (StringUtils.isBlank(order.getEndTime()) ? order.getEndReckonTime() : order.getEndTime()) +
                    UtilConstants.SUFFIX;
            String key = DigestUtils.md5Hex(sb);
            order.setKey(key);
            String reqest = JSONObject.toJSONString(order);
            log.info("调用gd-api getCountTotalStrRecordAndSummaryV2 param={}",reqest);
            JSONObject apiResult = gdApiCenterFeign.getCountTotalStrRecordAndSummaryV2(JSONObject.parseObject(reqest));
            log.info("调用gd-api getCountTotalStrRecordAndSummaryV2 resp={}", JSONObject.toJSONString(apiResult));
            if(apiResult!=null && apiResult.getInteger("errorCode").equals(1) ){
                return apiResult.getObject ("objs",QueryResultWrapper.class);
            }
            log.info("调用gd-api getCountTotalStrRecordAndSummaryV2 返回错误  resp={}", JSONObject.toJSONString(apiResult));
        } catch (Exception e) {
            log.error("调用gd-api getCountTotalStrRecordAndSummaryV2 异常", e);
        }
        return null;
    }
}
