package com.riskcontrol.common.entity.request.kyc;

import io.swagger.annotations.ApiModelProperty;

/**
 * @Description:
 * @Auther: yannis
 * @create: 2023-12-05
 */
public class RiskQueryKycRequest {
    @ApiModelProperty(value = "customerId")
    protected String customerId;

    @ApiModelProperty(value = "loginName")
    protected String loginName;

    @ApiModelProperty(value = "productId")
    protected String productId;

    @ApiModelProperty(value = "statusList")
    protected String statusList;
    @ApiModelProperty(value = "sex")
    protected String sex;
    @ApiModelProperty(value = "idType")
    protected String idType;
    @ApiModelProperty(value = "country")
    protected String country;
    @ApiModelProperty(value = "address")
    protected String address;

    protected String createdDateBegin;
    protected String createdDateEnd;


    protected String openDateBegin;
    protected String openDateEnd;


    protected String approvedDateBegin;
    protected String approvedDateEnd;


    protected int pageNum;
    protected int pageSize;
    protected String order;

    @ApiModelProperty(value = "employerName")
    private String employerName;

    @ApiModelProperty(value = "birthPlace")
    private String birthPlace;
    @ApiModelProperty("分配人")
    protected String assigneeBy;

    @ApiModelProperty("状态")
    protected String dispatchStatus;

    @ApiModelProperty(value = "assignee Begin", example = "")
    private String assigneeDateBegin;

    @ApiModelProperty(value = "assignee End", example = "")
    private String assigneeDateEnd;
    @ApiModelProperty(value = "pbc Status List", example = "")
    private String pbcStatus;
    private String billNo;

    private String birthday;

    private String firstName;

    private String middleName;

    private String lastName;

    @ApiModelProperty(value = "id", example = "")
    private String id;

    @ApiModelProperty(value = "product 产品名称", example = "BP,AP")
    private String product;
    @ApiModelProperty(value = "channel 渠道", example = "与网关对应：3-GLIFE, 4-GPO(占位), 5-LAZADA, 6-MAYA, 99-WEBSITE")
    private String channel;
    @ApiModelProperty(value = "是否导出数据")
    private boolean isExport;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmployerName() {
        return employerName;
    }

    public void setEmployerName(String employerName) {
        this.employerName = employerName;
    }

    public String getBirthPlace() {
        return birthPlace;
    }

    public void setBirthPlace(String birthPlace) {
        this.birthPlace = birthPlace;
    }

    public String getPbcStatus() {
        return pbcStatus;
    }

    public void setPbcStatus(String pbcStatus) {
        this.pbcStatus = pbcStatus;
    }

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getCreatedDateBegin() {
        return createdDateBegin;
    }

    public void setCreatedDateBegin(String createdDateBegin) {
        this.createdDateBegin = createdDateBegin;
    }

    public String getCreatedDateEnd() {
        return createdDateEnd;
    }

    public void setCreatedDateEnd(String createdDateEnd) {
        this.createdDateEnd = createdDateEnd;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public String getStatusList() {
        return statusList;
    }

    public void setStatusList(String statusList) {
        this.statusList = statusList;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }


    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAssigneeBy() {
        return assigneeBy;
    }

    public void setAssigneeBy(String assigneeBy) {
        this.assigneeBy = assigneeBy;
    }

    public String getDispatchStatus() {
        return dispatchStatus;
    }

    public void setDispatchStatus(String dispatchStatus) {
        this.dispatchStatus = dispatchStatus;
    }

    public String getAssigneeDateBegin() {
        return assigneeDateBegin;
    }

    public void setAssigneeDateBegin(String assigneeDateBegin) {
        this.assigneeDateBegin = assigneeDateBegin;
    }

    public String getAssigneeDateEnd() {
        return assigneeDateEnd;
    }

    public void setAssigneeDateEnd(String assigneeDateEnd) {
        this.assigneeDateEnd = assigneeDateEnd;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getOpenDateBegin() {
        return openDateBegin;
    }

    public void setOpenDateBegin(String openDateBegin) {
        this.openDateBegin = openDateBegin;
    }

    public String getOpenDateEnd() {
        return openDateEnd;
    }

    public void setOpenDateEnd(String openDateEnd) {
        this.openDateEnd = openDateEnd;
    }

    public String getApprovedDateBegin() {
        return approvedDateBegin;
    }

    public void setApprovedDateBegin(String approvedDateBegin) {
        this.approvedDateBegin = approvedDateBegin;
    }

    public String getApprovedDateEnd() {
        return approvedDateEnd;
    }

    public void setApprovedDateEnd(String approvedDateEnd) {
        this.approvedDateEnd = approvedDateEnd;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public boolean getIsExport() {
        return isExport;
    }

    public void setIsExport(boolean isExport) {
        this.isExport = isExport;
    }
}
