package com.riskcontrol.common.entity.response.kyc;


import com.cn.schema.customers.WSKycRequest;
import com.riskcontrol.common.entity.pojo.KycRequest;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

public class RiskQueryKycRequestResponse {
    @ApiModelProperty(
            required = true,
            value = "结果总数量"
    )
    protected int count;
    @ApiModelProperty(
            required = true,
            value = "当前页数据集合"
    )
    protected List<KycRequest> data;

    public RiskQueryKycRequestResponse() {
    }

    public RiskQueryKycRequestResponse(int count, List<KycRequest> data) {
        this.count = count;
        this.data = data;
    }

    public int getCount() {
        return this.count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public List<KycRequest> getData() {
        return this.data;
    }

    public void setData(List<KycRequest> data) {
        this.data = data;
    }


}
