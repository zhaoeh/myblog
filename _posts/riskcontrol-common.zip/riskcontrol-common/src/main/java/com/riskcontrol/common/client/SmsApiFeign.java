
package com.riskcontrol.common.client;

import com.ws.SmsContentRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @program: riskcontrol-common
 * @description: risk api feign
 * @author: Erhu.Zhao
 * @create: 2023-11-21 16:33
 */
@FeignClient(name = "c66-sms-api")
public interface SmsApiFeign {
    /**
     * 发送短信
     * @return
     */
    @PostMapping(value = "/rest/sendSMS")
    String sendSms(@RequestBody SmsContentRequest contentRequest);

}