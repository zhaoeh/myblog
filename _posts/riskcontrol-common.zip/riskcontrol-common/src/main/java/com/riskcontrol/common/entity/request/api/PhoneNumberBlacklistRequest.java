package com.riskcontrol.common.entity.request.api;

import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.constants.SQLConstants;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigInteger;

/**
 * @author Colson
 * @program riskcontrol-common
 * @description 手机号码黑名单，部分字段名由DP指定，故不使用基类
 * @date 2023/9/26 10:30
 **/
@Data
@ApiModel(value = "手机号黑名单请求对象", description = "手机号黑名单查询参数")
public class PhoneNumberBlacklistRequest {

    @ApiModelProperty("ID")
    @Query
    private BigInteger id;

    @ApiModelProperty("所有历史绑定的用户ID，逗号分隔，按照时间顺序增加")
    @Query(mt = SQLConstants.Query.LIKE)
    private String history;

    @ApiModelProperty("手机号码")
    @Query
    private String phone;

    @ApiModelProperty("手机号码md5")
    @Query
    private String phoneMd5;

    @ApiModelProperty("状态：0-失效，1-生效中")
    @Query
    private Integer status;

    @ApiModelProperty("创建时间-起始时间")
    @Query(field = "createTime", mt = SQLConstants.Query.GE)
    private String createTimeStart;

    @ApiModelProperty("创建时间-截止时间")
    @Query(field = "createTime", mt = SQLConstants.Query.LE)
    private String createTimeEnd;

    @ApiModelProperty("最后一次最后修改的account")
    @Query
    private String dataModifier;

    @ApiModelProperty("最后修改时间-起始时间")
    @Query(field = "lastUpdateTime", mt = SQLConstants.Query.GE)
    private String lastUpdateTimeStart;

    @ApiModelProperty("最后修改时间-截止时间")
    @Query(field = "lastUpdateTime", mt = SQLConstants.Query.LE)
    private String lastUpdateTimeEnd;

    @ApiModelProperty("所属产品")
    @Query
    private String productId;

}