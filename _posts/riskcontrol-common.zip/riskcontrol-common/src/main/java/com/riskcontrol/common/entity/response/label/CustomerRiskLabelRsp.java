package com.riskcontrol.common.entity.response.label;

import com.riskcontrol.common.entity.response.BaseRsp;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.List;

/**
 * <p>
 * 用户风控标签信息
 * </p>
 *
 * @author Colson
 * @since 2024-01-12
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@ApiModel(value = "CustomerRiskLabelRsp对象", description = "用户风控标签信息")
public class CustomerRiskLabelRsp extends BaseRsp implements Serializable {

    @ApiModelProperty("用户ID")
    private String customerId;

    @ApiModelProperty("用户登录名")
    private String loginName;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty("所属产品")
    private String productId;

    @ApiModelProperty("绑定的风控标签")
    private List<CustomerRiskLabelDetailRsp> riskLabels;

}
