package com.riskcontrol.common.entity.request.api;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author Colson
 * @program riskcontrol-common
 * @description 手机号码查询剩余冷却天数-请求参数
 * @date 2023/10/27 12:20
 **/
@Data
@ApiModel(value = "手机号码查询剩余冷却天数-请求对象", description = "手机号码查询剩余冷却天数-请求对象")
public class PhoneCoolingDownPeriodRequest {

    @ApiModelProperty("手机号码MD5")
    private String oldPhoneMd5;

    @ApiModelProperty("用户ID")
    private String customerId;

}
