package com.riskcontrol.common.entity.request.label;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.math.BigInteger;
import java.util.List;

/**
 * @program: riskcontrol-api
 * @description: 绑定风控标签
 * @author: Colson
 * @create: 2024-01-11 18:14
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Accessors(chain = true)

public class RiskLabelBindingRequest {

    @ApiModelProperty(value = "用户ID", required = true)
    @NotNull(message = "customer id cannot be empty")
    private Long customerId;

    @ApiModelProperty(value = "用户名", required = true)
    @NotBlank(message = "login name cannot be empty")
    private String loginName;

    @ApiModelProperty(value = "产品ID", required = true)
    @NotBlank(message = "product id cannot be empty")
    private String productId;

    @ApiModelProperty(value = "操作人", required = true)
    @NotBlank(message = "operator cannot be empty")
    private String operator;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty(value = "绑定的风控标签ID", required = true)
    @Size(min = 1, message = "riskLabelIds cannot be empty")
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private List<BigInteger> riskLabelIds;

}
