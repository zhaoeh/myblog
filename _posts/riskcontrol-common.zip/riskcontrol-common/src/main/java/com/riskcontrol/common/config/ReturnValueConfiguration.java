package com.riskcontrol.common.config;

import com.riskcontrol.common.handler.CustomizedMethodReturnValueHandler;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.CollectionUtils;
import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;

import java.util.*;

/**
 * @program: riskcontrol-common
 * @description: response body自定义配置
 * @author: Erhu.Zhao
 * @create: 2023-12-01 15:09
 */
@Configuration
public class ReturnValueConfiguration implements InitializingBean {

    @Autowired
    private RequestMappingHandlerAdapter requestMappingHandlerAdapter;

    @Autowired
    private ObjectProvider<ReturnValueStrategyConfiguration> replacedHandlerAndStrategy;

    @Override
    public void afterPropertiesSet() throws Exception {
        Optional.ofNullable(replacedHandlerAndStrategy.getIfAvailable()).filter(ReturnValueStrategyConfiguration::supportsDoThis).ifPresent(strategy -> {
            Map<String, ReturnValueStrategyConfiguration.ReturnValueStrategy> replacedHandlerAndStrategy = strategy.replacedHandlerAndStrategy();
            this.resetReturnValueHandlersIfNeed(replacedHandlerAndStrategy);
        });
    }

    private void resetReturnValueHandlersIfNeed(Map<String, ReturnValueStrategyConfiguration.ReturnValueStrategy> replacedHandlerAndStrategy) {
        if (CollectionUtils.isEmpty(replacedHandlerAndStrategy)) {
            return;
        }
        List<HandlerMethodReturnValueHandler> handlers = obtainReturnValueHandlers();
        if (CollectionUtils.isEmpty(handlers)) {
            return;
        }
        doResetReturnValueHandlers(handlers, replacedHandlerAndStrategy);
    }

    private void doResetReturnValueHandlers(List<HandlerMethodReturnValueHandler> handlers, Map<String, ReturnValueStrategyConfiguration.ReturnValueStrategy> replacedHandlerAndStrategy) {
        List<HandlerMethodReturnValueHandler> newHandlers = new ArrayList<>(handlers.size());
        handlers.stream().forEach(h -> Optional.ofNullable(h).ifPresent(handler -> fillNewHandler(newHandlers, replacedHandlerAndStrategy, handler)));
        Optional.ofNullable(newHandlers).filter(e -> !CollectionUtils.isEmpty(newHandlers)).ifPresent(t -> this.requestMappingHandlerAdapter.setReturnValueHandlers(t));
    }

    private List<HandlerMethodReturnValueHandler> obtainReturnValueHandlers() {
        return Optional.ofNullable(requestMappingHandlerAdapter).map(RequestMappingHandlerAdapter::getReturnValueHandlers).orElse(Collections.emptyList());
    }

    private void fillNewHandler(List<HandlerMethodReturnValueHandler> newHandlers, Map<String, ReturnValueStrategyConfiguration.ReturnValueStrategy> replacedHandlerAndStrategy, HandlerMethodReturnValueHandler currentHandler) {

        if (replacedHandlerAndStrategy.containsKey(currentHandler.getClass().getName())) {
            ReturnValueStrategyConfiguration.ReturnValueStrategy strategy = replacedHandlerAndStrategy.get(currentHandler.getClass().getName());
            newHandlers.add(new CustomizedMethodReturnValueHandler(currentHandler, strategy));
        } else {
            newHandlers.add(currentHandler);
        }
    }

}