package com.riskcontrol.common.entity.request.api;

import com.riskcontrol.common.annotation.Query;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.math.BigInteger;

/**
 * @author Colson
 * @program riskcontrol-common
 * @description 手机号黑名单-单条查询参数
 * @date 2023/9/26 10:30
 **/
@Data
@ApiModel(value = "手机号黑名单-根据手机号码md5或ID查询请求对象", description = "手机号黑名单-根据手机号码md5或ID查询")
public class PhoneNumberBlacklistGetOneRequest {

    @ApiModelProperty("ID")
    @Query
    private BigInteger id;

    @ApiModelProperty("手机号码md5")
    @Query
    private String phoneMd5;


}
