package com.riskcontrol.common.container;

import org.springframework.core.NamedThreadLocal;

import java.util.Objects;

/**
 * @program: riskcontrol-common
 * @description: headers holder
 * @author: Erhu.Zhao
 * @create: 2023-10-27 18:52
 */
public class HeaderContextHolder {

    private static final ThreadLocal<HeaderContext> headerContextHolder = new NamedThreadLocal("HeaderContext");

    public static void resetHeaderContext() {
        headerContextHolder.remove();
    }

    public static void setHeaderContext(HeaderContext headerContext) {
        if (Objects.isNull(headerContext)) {
            resetHeaderContext();
        } else {
            headerContextHolder.set(headerContext);
        }
    }

    public static HeaderContext getHeaderContext() {
        HeaderContext headerContext = headerContextHolder.get();
        return headerContext;
    }

    public static void clearHeaderContext() {
        headerContextHolder.remove();
    }

}