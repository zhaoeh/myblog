package com.riskcontrol.common.entity.request.api;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.*;
import java.math.BigInteger;

/**
 * @author Colson
 * @program riskcontrol-common
 * @description 手机号码黑名单，部分字段名由DP指定，故不使用基类
 * @date 2023/9/26 10:30
 **/
@Data
@ApiModel(value = "手机号黑名单更新状态请求对象", description = "手机号黑名单更新状态参数")
public class PhoneNumberBlacklistUpdateStatusRequest {

    @ApiModelProperty("ID")
    private BigInteger id;

    @ApiModelProperty("手机号码")
    private String phoneMd5;

    @ApiModelProperty("状态：0-失效，1-生效中")
    @Max(value =1, message = "The status can only be filled in 0 or 1 (0-invalid, 1-in effect)")
    @Min(value = 0, message = "The status can only be filled in 0 or 1 (0-invalid, 1-in effect)")
    @NotNull(message = "status cannot be empty")
    private Integer status;

    @ApiModelProperty("最后一次最后修改的account")
    @NotBlank(message = "dataModifier cannot be empty")
    private String dataModifier;

    @ApiModelProperty("备注")
    private String remarks;
}
