
package com.riskcontrol.common.client;

import com.alibaba.fastjson.JSONObject;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

/**
 * @program: riskcontrol-common
 * @description: 大数据 api服务
 * @author: sanji
 * @create: 2024-08-07 13:33
 */
@FeignClient(name = "bd-report-api")
public interface DBReportApiFeign {
    /**
     * 根据日期、存款区间 查询所有用户投注、存取款、优惠数据
     *
     * @param  req
     * @return query result
     */
    @PostMapping(value = "/operation/getPlayerReportPage")
    JSONObject getPlayerReportPage(@RequestBody JSONObject req);


}