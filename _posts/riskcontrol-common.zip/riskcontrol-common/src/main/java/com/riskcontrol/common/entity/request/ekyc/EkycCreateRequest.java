package com.riskcontrol.common.entity.request.ekyc;

import com.riskcontrol.common.annotation.EnumValid;
import com.riskcontrol.common.enums.EkycChannelEnum;
import com.riskcontrol.common.enums.CardTypeEnum;
import com.riskcontrol.common.enums.TenantEnum;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @description: ekyc：创建 提案/ekyc记录
 **/
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class EkycCreateRequest {

    @ApiModelProperty(required = true, value = "zoloz业务id" )
    @NotBlank(message = "transactionId cannot be empty")
    private String transactionId;

    @ApiModelProperty(required = true, value = "登录名" )
    @NotBlank(message = "loginName cannot be empty")
    private String loginName;

    @ApiModelProperty(required = true, value = "用户id" )
    @NotNull(message = "customerId cannot be null")
    private Long customerId;

    @ApiModelProperty(required = true, value = "渠道" )
    @NotBlank(message = "channel cannot be empty")
    @EnumValid(enumClass = EkycChannelEnum.class, enumField = "channelId",message = "tenant必须为{target}")
    private String channel;

    @ApiModelProperty(required = true, value = "血缘标记" )
    @NotBlank(message = "tenant cannot be empty")
    @EnumValid(enumClass = TenantEnum.class, enumField = "name",message = "tenant必须为{target}")
    private String tenant;

    @ApiModelProperty(required = true, value = "业务Id" )
    @NotBlank(message = "billNo cannot be empty")
    private String billNo;

    @ApiModelProperty(required = true, value = "证件类型" )
    @NotNull(message = "idType不能为空")
    @EnumValid(enumClass = CardTypeEnum.class, enumField = "code", message = "idType必须为{target}")
    private Integer idType;

}
