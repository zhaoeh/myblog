package com.riskcontrol.common.entity.request.device;

import com.riskcontrol.common.annotation.Null2Empty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotBlank;

/**
 * @Auther: Zhilin
 * @Date: 2024/11/13 18:23
 * @Description:
 */
@Getter
@Setter
@Accessors(chain = true)
public class RegisterCheckRequest {

    /**
     * 设备指纹token
     */
    @ApiModelProperty(value = "deviceFingerprintToken")
    @NotBlank(message = "deviceFingerprintToken cannot be blank")
    private String deviceFingerprintToken;

    /**
     * 设备指纹
     */
    @ApiModelProperty(value = "deviceFingerprint")
    @Null2Empty
    private String deviceFingerprint;

    /**
     * 注册IP地址
     */
    @ApiModelProperty(value = "registerIp")
    @NotBlank(message = "registerIp cannot be blank")
    private String registerIp;

    /**
     * 注册电话
     */
    @ApiModelProperty(value = "phoneNumber")
    @Null2Empty
    private String phoneNumber;

    /**
     * 产品标识(BP, AP, GP, PG, SP)
     */
    @ApiModelProperty(value = "tenant")
    @NotBlank(message = "tenant cannot be blank")
    private String tenant;

    /**
     * 渠道(3:GLIFE, 4:GPO, 5:LAZADA,6:MAYA, 7:PERYAGAME, 91:PC, 92:H5, 93:IOS, 94:Android)
     */
    @ApiModelProperty(value = "channel")
    @NotBlank(message = "channel cannot be blank")
    private String channel;

    /**
     * 域名
     */
    @ApiModelProperty(value = "domainName")
    @NotBlank(message = "domainName cannot be blank")
    private String domainName;

    /**
     * 业务名(C66)
     */
    @ApiModelProperty(value = "productId")
    private String productId;

    /**
     * 设备信息的JsonString
     */
    @ApiModelProperty(value = "deviceInfo")
    private String deviceInfo;

}
