
package com.riskcontrol.common.client;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.riskcontrol.common.entity.request.QueryLoginInfoReq;
import com.riskcontrol.common.entity.response.QueryLoginInfoRsp;
import com.riskcontrol.common.entity.response.Result;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @program: c66-log-api
 * @description: log api
 * @author: dante
 * @create: 2024-08-15
 */
@FeignClient(name = "c66-log-api")
public interface LogApiFeign {

    @PostMapping(value = "/login_item/query_by_ip")
    Result<Page<QueryLoginInfoRsp>> queryLoginInfoByIp(@RequestBody QueryLoginInfoReq queryReq);
}