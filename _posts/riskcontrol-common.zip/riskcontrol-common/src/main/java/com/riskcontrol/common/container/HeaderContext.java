package com.riskcontrol.common.container;

import java.util.Enumeration;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @program: riskcontrol-common
 * @description: 自定义header容器
 * @author: Erhu.Zhao
 * @create: 2023-10-30 10:09
 */
public class HeaderContext extends ConcurrentHashMap<String, String> {

    public HeaderContext() {
        super();
    }

    /**
     * 获取header names
     *
     * @return header names
     */
    public Enumeration<String> getHeaderNames() {
        return this.keys();
    }

    /**
     * 根据headerName获取header value
     *
     * @param headerName header name
     * @return header value
     */
    public String getHeader(String headerName) {
        return this.get(headerName);
    }
}