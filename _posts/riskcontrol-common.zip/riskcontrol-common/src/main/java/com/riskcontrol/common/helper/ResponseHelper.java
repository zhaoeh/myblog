package com.riskcontrol.common.helper;

import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.enums.ResultCode;
import com.riskcontrol.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;

import java.util.Objects;

/**
 * @program: riskcontrol-common
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-11-29 18:15
 */
@Slf4j
public class ResponseHelper {

    public static <T> T pullData(Response<T> response) {
        if(response.success()){
            return response.getBody();
        }
        if (Objects.isNull(response) || Objects.isNull(response.getHead()) || Objects.isNull(response.getHead().getErrCode())) {
            throw  new BusinessException("下游系统响应数据为空", "508");
        }
        throw  new BusinessException(response.getHead().getErrMsg(), response.getHead().getErrCode());
    }

    public static BusinessException businessException(Exception ex, String message, ResultCode code) {
        if (BusinessException.class.isInstance(ex)) {
            return (BusinessException) ex;
        }
        log.error(message, ex);
        return new BusinessException(code);
    }
}