package com.riskcontrol.common.annotation;
import com.riskcontrol.common.validation.ExcelHeaderValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

/**
 * @author Heng.zhang
 */
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = ExcelHeaderValidator.class)  // 指定验证逻辑的类
public @interface ExcelHeaderCheck {

    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};

    // 用来指定要校验的模板类型
    int type();

    String message() default "Excel 模板列头不符合要求";

}