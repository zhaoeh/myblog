package com.riskcontrol.common.entity.request;

import com.google.common.base.MoreObjects;
import io.swagger.annotations.ApiModelProperty;

public class BalanceReq extends BaseReq {

    @ApiModelProperty(required = false, value = "刷新余额级别[不传默认缓存2分钟,1:缓存15秒, 9:不缓存]" )
    private int flag;

    @ApiModelProperty(required = false, value = "新钱包用户是否返回各游戏厅内余额,1：返回，0：不返回，默认为0" )
    private int walletCreditForPlatformFlag;

    @ApiModelProperty(value = "是否后台:true后台,false 前端")
    private boolean background = true;


    @ApiModelProperty(required = false, value = "币种" )
    private String platformCurrency;


    @ApiModelProperty(required = false, value = "gameId" )
    private String gameId;
    private String customerId;


    public boolean isBackground() {
        return background;
    }

    public void setBackground(boolean background) {
        this.background = background;
    }

    public int getFlag() {
        return flag;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }


    public void setFlag(int flag) {
        this.flag = flag;
    }

    public int getWalletCreditForPlatformFlag() {
        return walletCreditForPlatformFlag;
    }

    public void setWalletCreditForPlatformFlag(int walletCreditForPlatformFlag) {
        this.walletCreditForPlatformFlag = walletCreditForPlatformFlag;
    }

    public String getPlatformCurrency() {
        return platformCurrency;
    }

    public void setPlatformCurrency(String platformCurrency) {
        this.platformCurrency = platformCurrency;
    }

    public String getGameId() {
        return gameId;
    }

    public void setGameId(String gameId) {
        this.gameId = gameId;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper("")
                .add("flag", flag)
                .add("walletCreditForPlatformFlag", walletCreditForPlatformFlag)
                .add("platformCurrency", platformCurrency)
                .addValue(super.toString())
                .omitNullValues()
                .toString();
    }
}
