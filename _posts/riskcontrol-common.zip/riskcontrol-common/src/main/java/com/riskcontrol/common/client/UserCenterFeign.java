package com.riskcontrol.common.client;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.customers.*;
import com.cn.schema.request.*;
import com.riskcontrol.common.entity.request.UserCompleteCustomerRequest;
import com.riskcontrol.common.entity.request.UserQueryCheckCustomerInfoRequest;
import com.riskcontrol.common.entity.request.UserQueryCustomersBasicByLoginNameRequest;
import com.riskcontrol.common.entity.request.UserQueryCustomersByCustomerIdRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * @program: riskcontrol-common
 * @description: user center
 * @author: Colson
 * @create: 2023-09-14 13:52
 */
@FeignClient(name = "public-user-api",url = "${public-user-api.url}")
public interface UserCenterFeign {

    @PostMapping(value = "/customer/account/getCustomerByLoginName")
    QueryCustomersBasicByLoginNameResponseV3 getSimpleCustomerByLoginName(UserQueryCustomersBasicByLoginNameRequest request);

    @PostMapping(value = "/customer/account/modify")
    ModifyAccountResponse modifyAccount(ModifyAccountRequest request);

    @PostMapping(value = "/customer/account/queryByCustomerId")
    JSONObject getCustomerByCustomerId(UserQueryCustomersByCustomerIdRequest request);

    @PostMapping(value = "/customer/account/checkCustomerInfo")
    JSONObject checkCustomerInfo(UserQueryCheckCustomerInfoRequest request);

    @PostMapping(value = "/customer/bind/queryPhoneOREmail")
    QueryBondResponse queryBondRequest(QueryBondRequest request);

    @PostMapping(value = "/customer/account/complete")
    ModifyAccountResponse completeCustomer(UserCompleteCustomerRequest request);

    @PostMapping(value = "/customer/bind/createPhoneOREmail")
    JSONObject bindMobileNoOrEmail(CreateBondRequest request);

    @PostMapping(value = "/constant/query")
    JSONObject constantQuery(JSONObject request);

    @PostMapping(value = "/customers/query_customer_by_login_name_v2")
    QueryCustomerByLoginNameResponse queryByLoginName(QueryCustomerByLoginNameRequest request);

    /**
     * 根据用户ID查询用户信息*
     *
     * @param request
     * @return
     */
    @PostMapping(value = "customers/query_basic_by_customer_Id")
    QueryCustomersBasicByLoginNameResponseV2 getCustomerById(QueryCustomersBasicByIdRequest request);
    @PostMapping(value = "/customers/customerBank/query")
    QueryCustomersBankResponse queryCustomerBanks(QueryCustomersBankRequest request);
    /**
     * 根据用户名查询用户信息*
     *
     * @param request
     * @return
     */
    @PostMapping(value = "customers/query_basic_by_login_nameV2")
    QueryCustomersBasicByLoginNameResponseV2 getCustomerByLoginNameV2(QueryCustomersBasicByLoginNameRequestV2 request);

    @PostMapping(value = "customers/check_customer_infoV2")
    CheckCustomerInfoResponseV2 checkCustomerV2(CheckCustomerInfoRequestV2 request);

    @PostMapping(value = "customers/kyc_request/query")
    QueryKycRequestResponse queryKycRequest(QueryKycRequestRequest request);

    @PostMapping(value = "customers/ocr_identify/checkOcrIdentify")
    CheckOcrIdentifyResponse checkOcrIdentify(CheckOcrIdentifyRequest request);

    @PostMapping(value = "customers/kyc_request/create")
    CreateKycRequestResponse addKycRequest(CreateKycRequestRequest request);

    @PostMapping(value = "customers/account/complete")
    CompleteAccountResponse completeCustomer(CompleteAccountRequest request);

    @PostMapping(value = "customers/customer_face/create")
    CreateCustomerFaceResponse createCustomerFace(CreateCustomerFaceRequest request);

    @PostMapping(value = "customers/ocr_identify/create")
    CreateOcrIdentifyResponse saveOcrIdentify(CreateOcrIdentifyRequest request);

    @PostMapping(value = "customers/query_basic_by_login_name")
    QueryCustomersBasicByLoginNameResponse getSimpleCustomerByLoginName(QueryCustomersBasicByLoginNameRequest request);

    @PostMapping(value = "customers/query_basic_by_login_nameV3")
    QueryCustomersBasicByLoginNameResponseV3 getSimpleCustomerByLoginNameV3(QueryCustomersBasicByLoginNameRequestV3 request);

    @PostMapping(value = "customers/account/modify")
    ModifyAccountResponse modifyAccounts(ModifyAccountRequest request);

    @PostMapping(value = "customers/kyc_request/update")
    ModifyKycRequestResponse updateKycRequest(UpdateKycRequestRequest request);

    @PostMapping(value = "customers/kyc_request/pbcDispatch")
    ModifyKycRequestResponse pbcDispatch(UpdateKycRequestRequest request);

    @PostMapping(value = "customers/customer_face/modify")
    ModifyCustomerFaceResponse updateCustomerFace(ModifyCustomerFaceRequest request);

    @PostMapping(value = "customers/kyc_request/count")
    QueryKycRequestResponse countKycRequest(QueryKycRequestRequest request);

    @PostMapping(value = "customers/kyc_request/pbcModifyStatus")
    ModifyKycRequestResponse pbcModifyStatus(UpdateKycRequestRequest request);

    /**
     * 新增 导出接口查询
     *
     * @param request
     * @return
     */
    @PostMapping(value = "customers/kyc_request/queryKycSheetList")
    QueryKycSheetListRequestResponse queryKycSheetRequest(QueryKycRequestRequest request);

    @PostMapping(value = "customers/kyc_request/countKycPbc")
    QueryKycRequestResponse countKycPbcRequest(QueryKycRequestRequest request);

    @PostMapping(value = "customers/kyc_request/bactchModifyPbcStatus")
    BatchModifyPbcRequestResponse bactchModifyPbcStatus(BatchUpdateKycRequestRequest request);

    @PostMapping(value = "customers/kyc_request/queryPageByKycRequestId")
    QueryKycRequestProcessLogResponse queryPageByKycRequestId(UpdateKycRequestRequest request);

    @PostMapping(value = "customers/kyc_request/queryWaitPendingCount")
    QueryCountResponse queryWaitPendingCount(WSKycRequest request);

    @PostMapping(value = "customers/kyc_request/dispatch")
    QueryKycRequestResponse dispatch(WSKycRequest request);

    @PostMapping(value = "customers/kyc_request/dispatchCancel")
    KycDispatchConfirmResponse dispatchCancel(WSKycRequest request);

    @PostMapping(value = "customers/kyc_request/checkDispatchConfirm")
    KycDispatchConfirmResponse checkDispatchConfirm(KycDispatchConfirmRequest request);

    @PostMapping(value = "customers/kyc_request/dispatchConfirm")
    KycDispatchConfirmResponse dispatchKycRequestConfirm(KycDispatchConfirmRequest request);
}
