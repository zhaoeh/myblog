
package com.riskcontrol.common.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @program: riskcontrol-common
 * @description: risk api feign
 * @author: Erhu.Zhao
 * @create: 2023-11-21 16:33
 */
@FeignClient(name = "c66-px-gw-api")
public interface PxGwApiFeign {
    /**
     * 查询Gw缓存常量
     *
     * @param productId
     * @param key
     * @return
     */
    @PostMapping(value = "/office/constants/gwCache/cacheConstant")
    String queryCacheConstant(@RequestParam("productId") String productId, @RequestParam("key") String key);

}