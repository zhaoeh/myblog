package com.riskcontrol.common.entity.pojo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @Description: kyc申请表实体，从ws项目中迁移
 * @Auther: yannis
 * @create: 2023-12-04
 */
@Data
public class KycRequest implements Serializable {
    @ApiModelProperty("Id, primary Key")
    private String id;
    @ApiModelProperty("customerId")
    private String customerId;
    @ApiModelProperty("customer Login Name")
    private String loginName;
    @ApiModelProperty("productId")
    private String productId;
    @ApiModelProperty("created Date")
    private String createdDate;
    @ApiModelProperty("open Date")
    private String openDate;
    @ApiModelProperty("approved Date")
    private String approvedDate;
    @ApiModelProperty("pbc approved Date")
    private String pbcApprovedDate;
    @ApiModelProperty("repetation")
    private String repetation;
    @ApiModelProperty("doubtful")
    private String doubtful;
    @ApiModelProperty("employerName")
    private String employerName;
    @ApiModelProperty("birthPlace")
    private String birthPlace;
    @ApiModelProperty("created By")
    private String createdBy;
    @ApiModelProperty("update By")
    private String updateDate;
    @ApiModelProperty("type")
    private String type;
    @ApiModelProperty("update By")
    private String updateBy;
    @ApiModelProperty("approved By")
    private String approvedBy;
    @ApiModelProperty("pbc approved By")
    private String pbcApprovedBy;
    @ApiModelProperty("id Type")
    private String idType;
    @ApiModelProperty("id Number")
    private String idNo;
    @ApiModelProperty("firstName")
    private String firstName;
    @ApiModelProperty("middleName")
    private String middleName;
    @ApiModelProperty("lastName")
    private String lastName;
    @ApiModelProperty("id snapshot storage address")
    private String idScan;
    @ApiModelProperty("id snapshot storage address v2")
    private String idScanV2;
    @ApiModelProperty("id scan image key")
    private String idScanImagekey;
    @ApiModelProperty("id status")
    private String status;
    @ApiModelProperty("remark")
    private String remark;
    @ApiModelProperty("sex")
    private String sex;
    @ApiModelProperty("address")
    private String address;
    @ApiModelProperty("country")
    private String country;
    @ApiModelProperty("assigneeTime")
    private String assigneeTime;
    @ApiModelProperty("assigneeBy")
    private String assigneeBy;
    @ApiModelProperty("dispatchStatus")
    private Integer dispatchStatus;
    @ApiModelProperty("pbcStatus")
    private Integer pbcStatus;
    @ApiModelProperty("processLog")
    private String processLog;
    @ApiModelProperty("billNo")
    private String billNo;
    @ApiModelProperty("birthday")
    private String birthday;
    @ApiModelProperty(
            value = "product 产品名称",
            example = "BP,AP"
    )
    private String product;
    @ApiModelProperty(
            value = "channel 渠道",
            example = "与网关对应：3-GLIFE, 4-GPO(占位), 5-LAZADA, 6-MAYA, 99-WEBSITE"
    )
    private String channel;

    @ApiModelProperty("站点ID")
    private String siteId;

    @ApiModelProperty("血缘")
    private String tenant;

    @ApiModelProperty("现住地址")
    private String presentAddress;
    @ApiModelProperty("国籍")
    private String nationality;
    @ApiModelProperty("收入来源")
    private String sourceOfIncome;
    @ApiModelProperty("工作性质")
    private String natureOfWork;
    @ApiModelProperty("自拍照地址")
    private String imgUrl;
    @ApiModelProperty("是否系统处理pbc（0:否；1是）")
    private Integer autoPbc;
}
