package com.riskcontrol.common.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * 公共配置类
 *
 * @program: riskcontrol-common
 * @description: riskcontrol-common模块公共配置类
 * @author: Erhu.Zhao
 * @create: 2023-10-18 15:28
 **/
@Configuration
@ComponentScan(basePackages = {"com.riskcontrol.common.exception.handler",
        "com.riskcontrol.common.cache", "com.riskcontrol.common.aop",
        "com.riskcontrol.common.config","com.riskcontrol.common.service"})
public class CommonConfig {
}
