package com.riskcontrol.common.entity.request.label;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;

/**
 * @program: riskcontrol-api
 * @description: 根据单个customerId查询风控标签
 * @author: Colson
 * @create: 2024-01-11 18:14
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Accessors(chain = true)
public class RiskLabelByCustomerIdRequest {

    @ApiModelProperty(value = "用户ID",required = true)
    private Long customerId;

}
