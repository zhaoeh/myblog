package com.riskcontrol.common.entity.response.api;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Colson
 * @program riskcontrol-common
 * @description 手机号码查询剩余冷却天数-响应参数
 * @date 2023/10/27 12:20
 **/
@Data
@ApiModel(value = "手机号码查询剩余冷却天数-响应对象", description = "手机号码查询剩余冷却天数-请求对象")
public class PhoneCoolingDownPeriodRsp {

    @ApiModelProperty("是否在冷却期:true-在冷却期，false-不在冷却期")
    private Boolean isCoolDownPeriod;

    @ApiModelProperty("剩余冷却天数")
    private String days;

}
