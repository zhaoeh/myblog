package com.riskcontrol.common.enums;

import com.riskcontrol.common.entity.zoloz.EkycContext;
import org.springframework.util.Assert;

import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;

/**
 * @description: ekyc request审核策略枚举
 * @author: ErHu.Zhao
 * @create: 2024-10-08
 **/
public enum EkycApprovalStrategy {
    STRATEGY_APPROVAL("STRATEGY_APPROVAL", "approval ekyc request"),
    STRATEGY_REJECT("STRATEGY_REJECT", "reject ekyc request"),
    STRATEGY_MANUAL("STRATEGY_MANUAL", "ekyc request to manual"),
    ;

    private String flag;

    private String desc;

    EkycApprovalStrategy(String flag, String desc) {
        this.flag = flag;
        this.desc = desc;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    /**
     * 根据上下文选择策略枚举对象*
     *
     * @param context 上下文
     * @param mapper  策略选择器
     * @return 策略枚举对象
     */
    public static EkycApprovalStrategy switchStrategy(EkycContext context, Function<EkycContext, EkycApprovalStrategy> mapper) {
        Assert.notNull(mapper, "mapper cannot be null");
        return mapper.apply(context);
    }

    /**
     * 执行后置动作*
     *
     * @param actions 动作链
     * @return 策略枚举对象
     */
    public EkycApprovalStrategy then(Runnable... actions) {
        Optional.ofNullable(actions).map(Arrays::stream).filter(Objects::nonNull).ifPresent(s -> s.forEach(Runnable::run));
        return this;
    }

    @Override
    public String toString() {
        return "EkycApprovalStrategy{" +
                "flag='" + flag + '\'' +
                ", desc='" + desc + '\'' +
                '}';
    }
}
