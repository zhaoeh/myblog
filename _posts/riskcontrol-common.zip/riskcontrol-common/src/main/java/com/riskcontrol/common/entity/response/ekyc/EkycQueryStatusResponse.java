package com.riskcontrol.common.entity.response.ekyc;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @description: ekyc查询用户状态响应
 * @author: ErHu.Zhao
 * @create: 2024-10-07
 **/
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class EkycQueryStatusResponse {

    /**
     * KYC状态-1待提交0待审核,1通过,2自动拒绝,3手动拒绝
     */
    private Integer ekycStatus;

    /**
     * 老kyc状态,新kyc没通过才会查询-1未通过,待未审批,1:通过
     */
    private Integer oldKycStatus;

    /**
     * 今日可尝试次数
     */
    private Integer cankycTime;


    /**
     * 是否在ekyc白名单,暂留字段
     */
    private Boolean isEkycWhite;

    /**
     * 手动拒绝禁止kyc,转人工开关,ekycStatus=3时,refuselnitFlag=true弹框联系客服
     */
    private Boolean refuselnitFlag;
}
