package com.riskcontrol.common.entity.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * @description: customer/account/queryByCustomerId
 * @author: Colson
 * @create: 2023-09-20 12:10
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class UserQueryCustomersByCustomerIdRequest {

    private String requestUUID;

    private String infProductId;

    private String infPwd;

    private String customerId;

}
