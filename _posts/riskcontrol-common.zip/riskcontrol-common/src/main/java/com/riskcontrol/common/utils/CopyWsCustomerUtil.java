package com.riskcontrol.common.utils;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.customers.WSCustomers;
import com.riskcontrol.common.entity.pojo.Ekyc;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;

import java.util.Objects;

import static com.riskcontrol.common.utils.DateUtils.dateToDateTime;

/**
 * 将Ekyc拷贝到WSCustomers
 */
@Slf4j
public class CopyWsCustomerUtil {

    /**
     * 拷贝
     * @return
     */
    public static void copy(Ekyc source,WSCustomers target) {
        if(Objects.nonNull(source) && Objects.nonNull(target)){
            WSCustomers copyWs = new WSCustomers();
            if (StringUtils.isNotBlank(source.getFirstName())) {
                copyWs.setFirstName(source.getFirstName());
            }
            if (StringUtils.isNotBlank(source.getMiddleName())) {
                copyWs.setMiddleName(source.getMiddleName());
            }
            if (StringUtils.isNotBlank(source.getLastName())) {
                copyWs.setLastName(source.getLastName());
            }
            if (StringUtils.isNotBlank(source.getSex())) {
                copyWs.setSex(source.getSex());
            }
            if (StringUtils.isNotBlank(source.getIdFrontImg())) {
                copyWs.setFirstIdScan(source.getIdFrontImg());
            }
            if (Objects.nonNull(source.getIdType())) {
                copyWs.setFirstIdType(String.valueOf(source.getIdType()));
            }
            if (StringUtils.isNotBlank(source.getIdNo())) {
                copyWs.setFirstNoType(source.getIdNo());
            }
            if (StringUtils.isNotBlank(source.getAddress())) {
                copyWs.setAddress(source.getAddress());
            }
            if (StringUtils.isNotBlank(source.getNationality())) {
                copyWs.setNationality(source.getNationality());
            }
            if (StringUtils.isNotBlank(source.getUpdateBy())) {
                copyWs.setLastUpdatedBy(source.getUpdateBy());
            }
            if (Objects.nonNull(source.getCustomerId())) {
                copyWs.setCustomerId(String.valueOf(source.getCustomerId()));
            }
            if (StringUtils.isNotBlank(source.getSourceOfIncome())) {
                copyWs.setSourceOfIncome(source.getSourceOfIncome());
            }
            if (StringUtils.isNotBlank(source.getLoginName())) {
                copyWs.setLoginName(source.getLoginName());
            }
            copyWs.setProductId(target.getProductId());
            BeanUtils.copyProperties(copyWs,target);
        }
    }

}
 