package com.riskcontrol.common.entity.response.api;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigInteger;


/**
 * @program riskcontrol-common
 * @description 手机号码黑名单，部分字段名由DP指定，故不使用基类
 * @author Colson
 * @date 2023/9/26 10:30
 **/
@ApiModel(value = "手机号黑名单响应对象", description = "手机号黑名单")
@Data
public class PhoneNumberBlacklistRsp implements Serializable {

    @ApiModelProperty("ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    @ApiModelProperty("所有历史绑定的用户ID，逗号分隔，按照时间顺序增加")
    private String history;

    @ApiModelProperty("手机号码")
    private String phone;

    @ApiModelProperty("手机号码MD5")
    private String phoneMd5;

    @ApiModelProperty("状态：0-失效，1-生效中")
    private Integer status;

    @ApiModelProperty("创建时间")
    private String createTime;

    @ApiModelProperty("最后一次最后修改的account")
    private String dataModifier;

    @ApiModelProperty("最后修改时间")
    private String lastUpdateTime;

    @ApiModelProperty("所属产品")
    private String productId;

    @ApiModelProperty("备注")
    private String remarks;

}