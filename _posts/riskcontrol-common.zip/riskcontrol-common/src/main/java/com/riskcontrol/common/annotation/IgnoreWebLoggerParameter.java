package com.riskcontrol.common.annotation;

import java.lang.annotation.*;

/**
 * 忽略记录weblog
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface IgnoreWebLoggerParameter {
}
