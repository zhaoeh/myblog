package com.riskcontrol.common.entity.request.kyc;

import com.riskcontrol.common.entity.request.BaseQueryReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Objects;

/**
 * @Auther: yannis
 * @Date: 2023/4/4 18:23
 * @Description:
 */
@Data
public class CustomerOcrCardReq extends BaseQueryReq {
    @ApiModelProperty(value = "firstName")
    private String firstName;
    /**
     * 中间名
     */
    @ApiModelProperty(value = "中间名")
    private String middleName;
    /**
     * 姓
     */
    @ApiModelProperty(value = "姓")
    private String lastName;
    /**
     * 出生日期
     */
    @ApiModelProperty(value = "出生日期")
    private Date birthday;
    @ApiModelProperty(value = "idScan")
    private  String idScan;

    @ApiModelProperty(value = "customerId")
    private String customerId;

    @ApiModelProperty(value = "idType")
    private String idType;

    @ApiModelProperty("识别表id")
    private String identifyId;

    @Component
    public static class Product {
        /**
         * 產品編號
         */
        public enum Ids {
            C66
        }

        /**
         * 貨幣
         */public enum Currency {
            /** 人民币 */
            CNY,
            /** 泰銖 */
            THB,
            /** 越南盾 */
            VND,
            /** 虚拟币 */
            USDT,
            /** 美元 */
            USD,
        }

        /**
         * 語系對照
         */
        public enum Language {
            /** 中文 */
            CN,
            /** 英文 */
            EN,
            /** 越文 */
            VI,
            /** 泰文 */
            TH,
            /** 日语 */
            JA
        }

        /**
         *
         */
        public enum PayChannelCode{
            /** zakzak 支付渠道code*/
            zakzakpay
        }
        /**
         * 檢查產品編號是否相同
         * @param productId
         * @param id
         * @return
         */
        public static boolean isSameId(String productId, Ids id) {
            if (StringUtils.isBlank(productId) || null == id) return false;
            return id.name().equalsIgnoreCase(productId);
        }

        /**
         * 檢查產品編號是否相同
         * @param productId
         * @param productId2
         * @return
         */
        public static boolean isSameId(String productId, String productId2) {
            return StringUtils.equalsIgnoreCase(productId, productId2);
        }

        /**
         * 檢查產品編號是否有相同的
         * @param productId
         * @param ids
         * @return
         */
        public static boolean containsId(String productId, Ids... ids) {
            if (StringUtils.isBlank(productId) || Objects.isNull(ids)) return false;
            for (Ids id : ids) {
                if (id.name().equalsIgnoreCase(productId)) return true;
            }

            return false;
        }

        /**
         * 檢查產品編號是否有相同的
         * @param productId
         * @param productIds
         * @return
         */
        public static boolean containsId(String productId, String... productIds) {
            return StringUtils.equalsAnyIgnoreCase(productId, productIds);
        }

        /**
         * 是否為國際化項目
         *
         * @param productId
         * @return
         */
        public static boolean isPublicProject(String productId) {
            return false;
        }

        // -------------------------------------------------------------------------------
        // 產品編號系統內常用比對使用
        // -------------------------------------------------------------------------------
        /**
         * 取得C66產品編號
         * @return
         */
        public static String getPidC66() {
            return Ids.C66.name();
        }

        /**
         * 取得C68產品編號
         * @return
         */
        // todo laurent 保留该方法，但是返回C66的Id，方便后续找调用该方法做特殊处理的代码
        public static String getPidC68() {
            return Ids.C66.name();
        }
    }
}
