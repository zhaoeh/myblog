package com.riskcontrol.common.enums;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

/**
 * 黑名单/白名单类型枚举类
 *
 * @author Heng.zhang
 */
@AllArgsConstructor
@Getter
public enum RiskActionAllowRuleEnum {
    WHITELIST(0, "白名单"),
    BLACKLIST(1, "黑名单"),
    ;
    private final int id;
    private final String name;

    /**
     * 获取所有的来源
     */
    public static List<AllowRule> getAllowRule() {
        return Arrays.stream(RiskActionAllowRuleEnum.values()).map(x -> new RiskActionAllowRuleEnum.AllowRule(x.id, x.name)).toList();
    }

    /**
     * 渠道返回对象
     */
    @AllArgsConstructor
    @Data
    public static class AllowRule implements Serializable {
        private static final long serialVersionUID = 1L;
        private final int id;
        private final String name;
    }
}
