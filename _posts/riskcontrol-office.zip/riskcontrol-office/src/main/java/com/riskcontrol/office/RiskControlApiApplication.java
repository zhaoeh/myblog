package com.riskcontrol.office;

import com.digiplus.common.annotation.EnableDefaultKafkaProducerConfig;
import com.riskcontrol.common.annotation.EnableRiskCommon;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.core.env.Environment;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Slf4j
@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients(basePackages = {"com.riskcontrol.*.client","com.digiplus.oms.*"})
@EnableAspectJAutoProxy
@EnableRiskCommon
@EnableSwagger2
@ComponentScan(basePackages={"com.digiplus.oms","com.riskcontrol"})
@EnableDefaultKafkaProducerConfig
public class RiskControlApiApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        ConfigurableApplicationContext context = SpringApplication.run(RiskControlApiApplication.class, args);
        Environment environment = context.getBean(Environment.class);
        String port = environment.getProperty("local.server.port");
        log.info("[riskcontrol-office服务启动！ port:{} ]",port);
    }
}
