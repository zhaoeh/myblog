package com.riskcontrol.office.domain.customers.rsp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

@ApiModel("玩家银行卡信息<br/>Player's bank account")
public class BankAccountInfo implements Serializable {
    @ApiModelProperty("银行名称<br/>Bank name")
    private String bankName;

    @ApiModelProperty("银行账号信息<br/>Bank account No")
    private String bankAccountNo;

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankAccountNo() {
        return bankAccountNo;
    }

    public void setBankAccountNo(String bankAccountNo) {
        this.bankAccountNo = bankAccountNo;
    }
}