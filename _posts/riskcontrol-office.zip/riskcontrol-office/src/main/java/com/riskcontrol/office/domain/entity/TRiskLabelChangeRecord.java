package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigInteger;
import java.util.Date;

/**
 * 用户标签变更记录(TRiskLabelChangeRecord)表实体类
 *
 * @author makejava
 * @since 2024-06-06 15:26:02
 */
@Schema(description="用户标签变更记录表")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@TableName(value = "t_risk_label_change_record")
public class TRiskLabelChangeRecord extends BaseEntity {
    private static final long serialVersionUID = 1L;
    @TableId(value = "id", type = IdType.ASSIGN_ID)
    @Schema(description = "id")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    protected BigInteger id;
    //所属产品
    private String productId;
    //用户ID
    private Long customerId;
    //用户登录名
    private String loginName;
    //新风控标签ID，多个逗号隔开
    private String newRiskLabelId;
    //新风控标签名称，多个逗号隔开
    private String newRiskLabelName;
    //旧风控标签ID，多个逗号隔开
    private String oldRiskLabelId;
    //旧风控标签名称，多个逗号隔开
    private String oldRiskLabelName;
    //备注
    private String remark;
    //创建人
    private String createBy;
    //创建时间
    private Date createTime;
    //账户匹配状态 1：合法 0：非法
    private Integer operationStatus;
    //日志主表id
    private BigInteger logId;

}

