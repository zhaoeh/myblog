package com.riskcontrol.office.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.cn.schema.common.RabbitMQMessage;
import com.cn.schema.customers.WSCustomers;
import com.riskcontrol.common.entity.pojo.EkycDeduplicate;
import com.riskcontrol.common.enums.EkycStatusEnum;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.office.common.constants.ConstantVars;
import com.riskcontrol.office.domain.entity.TEkyc;
import com.riskcontrol.office.domain.entity.TEkycDeduplicate;
import com.riskcontrol.office.domain.entity.TEkycRequest;
import com.riskcontrol.office.kafka.KafkaTopic;
import com.riskcontrol.office.mapper.EkycDeduplicateMapper;
import com.riskcontrol.office.service.EkycDoSaveService;
import com.riskcontrol.office.service.EkycRequestService;
import com.riskcontrol.office.service.EkycService;
import com.riskcontrol.office.util.KafkaProductUtils;
import com.riskcontrol.office.util.RabbitMQUtils;
import com.riskcontrol.office.util.RedisUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;


/**
 * @author Heng.zhang
 */
@Service
@Slf4j
public class EkycDoSaveServiceImpl implements EkycDoSaveService {


    @Autowired
    @Lazy
    private EkycService ekycService;

    @Autowired
    @Lazy
    private EkycRequestService ekycRequestService;

    @Autowired
    private EkycDeduplicateMapper ekycDeduplicateMapper;

    @Resource
    private KafkaProductUtils kafkaProductUtils;
    @Resource
    protected RedisUtils redisUtils;
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean doSave(TEkycRequest ekycRequest) {
        if (Objects.isNull(ekycRequest)) {
            return false;
        }
        // 保存到ekyc申请表
        boolean save = ekycRequestService.save(ekycRequest);
        TEkyc ekycInfo = ekycService.getEkycInfo(ekycRequest.getLoginName());
        if (save && Objects.isNull(ekycInfo)) {
            //主表无记录，插入一条主表记录
            TEkyc tEkyc = new TEkyc();
            BeanUtil.copyProperties(ekycRequest, tEkyc);
            tEkyc.setStatus(EkycStatusEnum.PENDING.getEkycStatus());
            ekycService.save(tEkyc);
        }
        return save;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean doUpdate(TEkycRequest ekycRequest, TEkyc tEkyc, WSCustomers wsCustomers) {
        // 保存到ekyc申请表
        if(Objects.nonNull(ekycRequest)){
            boolean updateReq = ekycRequestService.updateById(ekycRequest);
            log.info("审批操作，审批成功后更新ekyc_request表，返回结果：{}",updateReq);
        }
        // 如果是审批拒绝，主表状态是通过，不修改任何主表信息
        if(Objects.nonNull(tEkyc)){
            boolean updateEkyc = ekycService.updateById(tEkyc);
            log.info("审批操作，审批成功后更新ekyc表，返回结果：{}",updateEkyc);
        }
        // 通过的时候更新WS用户信息
        if (Objects.equals(EkycStatusEnum.APPROVAL.getEKycReqStatus(), ekycRequest.getStatus())) {
            //审核通过后 更新Deduplicate表
            updateDeduplicate(ekycRequest);
            log.info("审批操作，人工审批通过更新WS开始");
           boolean result = ekycRequestService.updateWsUserInfo(tEkyc, wsCustomers);
           log.info("审批操作，人工审批通过更新WS，返回结果：{}",result);
        }
        return true;
    }

    /**
     * 更新Deduplicate表
     * @param ekycRequest
     */
    private void updateDeduplicate(TEkycRequest ekycRequest) {
        // 更新证件使用中间表
        String idNo = ekycRequest.getIdNo();
        Integer idType = ekycRequest.getIdType();
        if (StringUtils.isNotBlank(idNo) && Objects.nonNull(idType)) {
            TEkycDeduplicate ekycDeduplicate = ekycDeduplicateMapper.selectOne(new LambdaQueryWrapper<TEkycDeduplicate>()
                    .eq(TEkycDeduplicate::getIdNo, idNo)
                    .eq(TEkycDeduplicate::getIdType, idType));
            log.info("审批操作，审批成功后更新ekyc_Deduplicate表，入参：{}",ekycDeduplicate);
            if (Objects.isNull(ekycDeduplicate)) {
                TEkycDeduplicate entity = new TEkycDeduplicate();
                entity.setIdNo(idNo);
                entity.setIdType(idType);
                entity.setLoginName(ekycRequest.getLoginName());
                ekycDeduplicateMapper.insert(entity);
            } else {
                Optional.ofNullable(ekycDeduplicate.getLoginName()).filter(StringUtils::isNotBlank).
                        ifPresentOrElse(bindNames -> {
                            if (Arrays.stream(bindNames.split(ConstantVars.SEMICOLON)).noneMatch(str -> str.equals(ekycRequest.getLoginName()))) {
                                ekycDeduplicate.setLoginName(bindNames + ConstantVars.SEMICOLON +  ekycRequest.getLoginName());
                                ekycDeduplicateMapper.updateById(ekycDeduplicate);
                            }
                        }, () -> {
                            ekycDeduplicate.setLoginName( ekycRequest.getLoginName());
                            ekycDeduplicateMapper.updateById(ekycDeduplicate);
                        });
            }
        }
    }

}
