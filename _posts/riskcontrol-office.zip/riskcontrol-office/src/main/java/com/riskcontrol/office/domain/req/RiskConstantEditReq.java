package com.riskcontrol.office.domain.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.constants.SQLConstants;
import com.riskcontrol.office.domain.validation.RiskConstantCreateReqValidator;
import com.riskcontrol.office.domain.validation.RiskConstantUpdateReqValidator;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;

@Data
@Schema(description="风控标签请求对象")
public class RiskConstantEditReq {
    @Schema(description="主键id")
    @NotNull(groups = RiskConstantUpdateReqValidator.class,message = "id can not  be null")
    @Query
    private BigInteger id;

    @Schema(description = "常量key")
    @JsonProperty("pKey")
    @NotBlank(groups = {RiskConstantCreateReqValidator.class},message = "pKey can not  be null")
    @Query(mt = SQLConstants.Query.LIKE)
    private String pKey;

    @Schema(description="常量值")
    @JsonProperty("pValue")
    @NotBlank(groups = {RiskConstantCreateReqValidator.class},message = "pValue can not  be null")
    @Query(mt = SQLConstants.Query.LIKE)
    private String pValue;

    @Schema(description = "常量key")
    @JsonProperty("pType")
    @NotBlank(groups = {RiskConstantCreateReqValidator.class},message = "pType can not  be null")
    @Query(mt = SQLConstants.Query.LIKE)
    private String pType;

    @Schema(description="备注")
    @Query(mt = SQLConstants.Query.LIKE)
    private String remarks;

    @Schema(description = "标志:0-未启用；1-已启用")
    @Query
    private Integer isEnable;

    @Schema(description = "优先级")
    @Query
    @NotNull(groups = {RiskConstantCreateReqValidator.class,RiskConstantUpdateReqValidator.class},message = "priority can not  be null")
    @Min(0)
    @Max(255)
    private Integer priority;

    private static final long serialVersionUID = 1L;
}