package com.riskcontrol.office.domain.withdrawal.rsp;

import com.cn.schema.request.WSModifyAccountRequests;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
@Schema(title = "打开取款提案审核响应参数<br/>Response parameters for review withdrawal")
public class ReviewWithdrawalRequestRsp implements Serializable {
    @Schema(description = "Account")
    private String account;
    @Schema(description = "Register Branch")
    private String registerBranch;
    @Schema(description = "First Name")
    private String firstName;
    @Schema(description = "Middle Name")
    private String middleName;
    @Schema(description = "Last Name")
    private String lastName;
    @Schema(description = "Withdraw Amount")
    private String withdrawAmount;
    @Schema(description = "Total Balance after last withdrawal")
    private String lastTotalBalance;
    @Schema(description = "Local Balance after last withdrawal")
    private String lastLocalBalance;
    @Schema(description = "withdrawal type")
    private String bank;
    @Schema(description = "bank account number/mobile phone number")
    private String accountNo;
    @Schema(description = "Withdrawal request status, 0: Pending withdraw, 9: Pending withdraw2, 1: Processing withdraw")
    private String flag;

    @Schema(description = "birthday")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date birthday;
    @Schema(description = "KYC ID")
    private String idNo;
    @ApiModelProperty("KYC 照片")
    private String idScan;

    @Schema(description = "PBC status")
    private Integer pbcStatus;

    @Schema(description = "Total Balance after this withdrawal")
    private String totalBalance;
    @Schema(description = "Local Balance after last withdrawal")
    private String localBalance;

    @Schema(description = "deposit amount")
    private String dpAmount;
    @Schema(description = "discount amount")
    private String dsAmount;
    @Schema(description = "amount of credit correction")
    private String fixAmount;
    @Schema(description = "total betting amount")
    private String totalBetAmount;

    @Schema(description = "disable logging")
    List<WSModifyAccountRequests> accountModifyList;



}