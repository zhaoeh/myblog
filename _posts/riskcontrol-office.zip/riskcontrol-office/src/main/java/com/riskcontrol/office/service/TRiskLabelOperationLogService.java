package com.riskcontrol.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.domain.entity.TRiskLabelOperationLog;
import com.riskcontrol.office.domain.req.RiskLabelOperationPageRequest;

public interface TRiskLabelOperationLogService extends IService<TRiskLabelOperationLog> {

    /**
     * 查看历史操作记录列表
     * @param request 请求参数
     * @return 响应参数
     */
    PageModel<TRiskLabelOperationLog> getOperationList(RiskLabelOperationPageRequest request);
}
