package com.riskcontrol.office.domain.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.entity.request.BasePageRequest;
import com.riskcontrol.office.domain.validation.SysConstantCreateReqValidator;
import com.riskcontrol.office.domain.validation.SysConstantUpdateReqValidator;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;

@Data
@Schema(description="常量列表请求对象")
public class SysConstantReq extends BasePageRequest {
    @Schema(description="主键id")
    @NotNull(groups = SysConstantUpdateReqValidator.class,message = "ID不能为空")
    private BigInteger id;

    @Schema(description = "所属产品")
    @JsonProperty("productId")
    @NotBlank(groups = {SysConstantCreateReqValidator.class},message = "所属产品不能为空")
    @Query
    private String productId;

    @Schema(description = "常量类型")
    @JsonProperty("sType")
    @NotBlank(groups = {SysConstantCreateReqValidator.class},message = "常量类型不能为空")
    @Query
    private String sType;

    @Schema(description = "常量key")
    @JsonProperty("sKey")
    @NotBlank(groups = {SysConstantCreateReqValidator.class,SysConstantUpdateReqValidator.class},message = "常量key不能为空")
    @Query(
            mt = "like"
    )
    private String sKey;

    @Schema(description="常量值")
    @JsonProperty("sValue")
    @NotBlank(groups = {SysConstantCreateReqValidator.class,SysConstantUpdateReqValidator.class},message = "常量值不能为空")
    @Query(
            mt = "like"
    )
    private String sValue;

    @Schema(description="备注")
    @Query(
            mt = "like"
    )
    private String remarks;

    @Schema(description = "标志:0-未启用；1-已启用")
    @Query
    private Integer isEnable;

    private static final long serialVersionUID = 1L;
}