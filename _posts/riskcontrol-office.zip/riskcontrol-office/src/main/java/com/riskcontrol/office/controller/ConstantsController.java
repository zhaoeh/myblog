package com.riskcontrol.office.controller;

import com.digiplus.oms.aspect.annotation.PreAuthorize;
import com.riskcontrol.common.controller.BaseController;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.constans.req.QueryConstantsListReq;
import com.riskcontrol.office.service.IConstantsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

@Tag(name = "产品常量相关接口", description = "产品常量相关接口")
@RestController
@RequestMapping(value = "/office/constants")
public class ConstantsController extends BaseController {
    @Resource
    private IConstantsService constantsService;

    @PreAuthorize("riskManage_constant_query")
    @Operation(tags ="产品常量相关接口" ,summary = "查询产品常量列表")
    @PostMapping(value = "list")
    @ResponseBody
    public R queryList(HttpServletRequest request, @RequestBody QueryConstantsListReq req) throws Exception {
        return R.ok(constantsService.queryList(request, req));
    }
}
