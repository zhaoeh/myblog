package com.riskcontrol.office.common;


import com.cm.util.common.Constants;
import com.riskcontrol.common.config.C66Config;
import com.riskcontrol.common.config.UserCenterConstant;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.request.BaseReq;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.office.util.DESUtil;
import com.riskcontrol.office.util.RSATool;
import com.riskcontrol.office.util.RedisUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class BaseService {
    private static final Logger logger = LoggerFactory.getLogger(BaseService.class);
    protected static final String PRODUCT_ID_C66 = "C66";
    private static final String[] weekDays = {"星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"};
    @Resource(name = "taskExecutor")
    protected ThreadPoolTaskExecutor executor;
    @Resource
    protected RedisUtils redisUtils;
    @Resource
    protected C66Config c66Config;

    @Resource
    private UserCenterConstant userCenterConstant;
    protected Boolean tryLock(BaseReq baseReq, String key) {
        try {
            return redisUtils.tryLock(key, 30, 0, TimeUnit.SECONDS);
        } catch (Exception ex) {
            logger.error(baseReq.getLoginName() + "获取会员锁失败", ex);
            return null;
        }
    }
    /**
     * 释放锁
     */
    protected void releaseLock(BaseReq baseReq, String lockKey) {
        try {
            if (StringUtils.isEmpty(lockKey)) {
                return;
            }
            redisUtils.unLock(lockKey);
        } catch (Exception ex) {
            logger.error(baseReq.getLoginName() + "释放会员锁失败", ex);
        }
    }
    protected String flagToFlagDesc(String flag, String lang) {
        if ("0".equals(flag)) {
            return getNameFromLangIndexInData("Pending,等待,รอ,chờ đợi,待つ", ",", lang);
        } else if ("1".equals(flag)) {
            return getNameFromLangIndexInData("process,处理,vัดการกับ,đôi pho vơi,扱う", ",", lang);
        } else if ("2".equals(flag)) {
            return getNameFromLangIndexInData("Approve,批准,อนุมัติ,Phê duyệt,承認する", ",", lang);
        } else if ("9".equals(flag)) {
            return getNameFromLangIndexInData("Pending2,待核,จะได้รับการตรวจสอบ,Để được xác nhận,確認する", ",", lang);
        } else if ("-1".equals(flag)) {
            return getNameFromLangIndexInData("Front desk cancellation,前台取消,การยกเลิกแผนกต้อนรับ,Quầy lễ tân hủy bỏ,フロントデスクのキャンセル", ",", lang);
        } else if ("-2".equals(flag)) {
            return getNameFromLangIndexInData("Cancel in background,后台取消,ยกเลิกในพื้นหลัง,Hủy trong nền,バックグラウンドでキャンセル", ",", lang);
        } else if ("-3".equals(flag)) {
            return getNameFromLangIndexInData("Denied,拒绝,ปฏิเสธ,Từ chối,ごみ", ",", lang);
        } else {
            return getNameFromLangIndexInData("other,其他,อื่น ๆ,khác,その他", ",", lang);
        }
    }

    /**
     * ^英文^中文^泰语^越南语^日语
     *
     * @param data
     * @param splitRegx
     * @param lang
     * @return
     */
    protected final static String getNameFromLangIndexInData(String data, String splitRegx, String lang) {

        String datas[] = data.split(splitRegx);
        //code ^英文^中文^泰语^越南语^日语
        if (StringUtils.isBlank(lang))
            return datas[0];//默认返回英文

        switch (lang.toLowerCase()) {
            case "en":
                return datas[0];
            case "cn":
                if (datas.length > 1) {
                    return datas[1];

                }
                return datas[0];
            case "th":
                if (datas.length > 2) {
                    return datas[2];

                }
                return datas[0];
            case "vi":
                if (datas.length > 3) {
                    return datas[3];

                }
                return datas[0];
            case "ja":
                if (datas.length > 4) {
                    return datas[4];

                }
                return datas[0];
        }
        return datas[0];
    }

    protected boolean isNotStore(BaseReq baseReq) {
        // todo PC02 电游站门店PC, PC04 体育站门店PC,PC01 电游站门店PC
        String[] physical = new String[]{"C66PC01", "C66PC04"};
        if (Arrays.asList(physical).contains(baseReq.getAppId()))
            return true;
        else
            return false;
    }
    public boolean isSkipEnvironment(String productId) {
        String isSkip = userCenterConstant.getConstantValue(Constants.CURRENT_ENVIRONMENT);
        return "TEST".equalsIgnoreCase(isSkip);
    }
    public String generateRedisKeyByDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        return "C66:uploadPbcBatch:" + sdf.format(new Date());
    }
    /**
     *
     * @param baseReq
     * @param x
     * @return
     */
    protected String decrypt(BaseReq baseReq, String x) {

        String privateKey = DESUtil.decrypt(userCenterConstant.getConstantValue(Constant.X3_KEY), userCenterConstant.getConstantValue(Constant.X2_KEY));
        String x1;
        if (NumberUtils.INTEGER_TWO.equals(c66Config.getAppType())) {
            x1 = RSATool.decrypt(x, privateKey, 1);
        } else {
            try {
                x1 = RSATool.decrypt(x, privateKey);
            } catch (Exception ex) {
                logger.warn("尝试RSA解密失败，使用type=1的解密方式", ex);
                x1 = RSATool.decrypt(x, privateKey, 1);
            }
        }
        if (StringUtils.isBlank(x1)) {
            throw new BusinessException(ResultEnum.PWD_DECRYPT_ERROR);
        }
        return x1;
    }
    protected String buildTimeEx(Date dt) {
        Date now = new Date();
        // 小于1小时,显示分钟
        if (now.compareTo(DateUtils.addMinutes(dt, 59)) < 0) {
            long x = (now.getTime() - dt.getTime()) / (60 * 1000);
            if (x <= 1) {
                x = 1;
            }
            return x + "分钟前";
        }
        // 同日则显示今天
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        if (sdf.format(now).equals(sdf.format(dt))) {
            sdf.applyPattern("HH:mm");
            return "今天 " + sdf.format(dt);
        }
        // 同周则显示星期
        if (getWeekOfYear(dt) == getWeekOfYear(now)) {
            sdf.applyPattern("HH:mm");
            return this.getWeekOfDate(dt) + " " + sdf.format(dt);
        }
        // 显示年月日
        sdf.applyPattern("yyyy-MM-dd HH:mm");
        return sdf.format(dt);
    }

    private int getWeekOfYear(Date dt) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(dt);
        return cal.get(Calendar.WEEK_OF_YEAR);
    }

    private String getWeekOfDate(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (w < 0) {
            w = 0;
        }
        return weekDays[w];
    }
}