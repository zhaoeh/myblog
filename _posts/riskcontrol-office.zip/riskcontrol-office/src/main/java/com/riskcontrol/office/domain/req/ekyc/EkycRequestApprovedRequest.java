package com.riskcontrol.office.domain.req.ekyc;

import com.riskcontrol.common.annotation.StringValuesValid;
import com.riskcontrol.common.entity.request.BasePageRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Size;
import java.math.BigInteger;

/**
 * @author Heng.zhang
 */
@Data
@ApiModel(value = "Ekyc申请表审批", description = "Ekyc申请表审批")
public class EkycRequestApprovedRequest extends BasePageRequest {
    @ApiModelProperty("ID")
    private BigInteger id;

    /**
     * 0 初始化.
     * 1 待完善信息.
     * 2 等待人工进行审核.
     * 3 审核通过, 不区分是人工审核通过还是自动审核通过.
     * 5 自动审核拒绝.
     * 6 人工审核拒绝.
     * 7 失效.
     */
    @ApiModelProperty("状态")
    @StringValuesValid(values = {"3", "6"}, message = "status must be {target}")
    private String status;

    @ApiModelProperty("人工拒绝原因")
    @Size(max = 60, message = "rejectReason max length is 60")
    private String rejectReason;

    @ApiModelProperty("备注")
    private String remark;

}
