package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.Date;

/**
 * 风控标签常量表
 */
@Schema(description = "风控标签常量表")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@TableName(value = "t_risk_constants")
public class TRiskConstants extends BaseEntity {

    /**
     * 所属产品
     */
    @TableField(value = "product_id")
    @Schema(description = "所属产品")
    private String productId;

    /**
     * 常量key
     */
    @TableField(value = "p_key",fill = FieldFill.INSERT)
    @Schema(description = "常量key")
    @JsonProperty("pKey")
    private String pKey;

    /**
     * 常量值
     */
    @TableField(value = "p_value",fill = FieldFill.INSERT)
    @Schema(description = "常量值")
    @JsonProperty("pValue")
    private String pValue;

    @TableField(value = "p_type",fill = FieldFill.INSERT)
    @Schema(description = "常量类型")
    @JsonProperty("pType")
    private String pType;

    /**
     * 描述
     */
    @TableField(value = "remarks")
    @Schema(description = "描述")
    private String remarks;

    /**
     * ip地址
     */
    @TableField(value = "ip_address")
    @Schema(description = "ip地址")
    private String ipAddress;

    /**
     * 标志:0-未启用；1-已启用
     */
    @TableField(value = "is_enable")
    @Schema(description = "标志:0-未启用；1-已启用")
    private Integer isEnable;

    /**
     * 是否删除：0-否 ；1-是
     */
    @TableField(value = "is_deleted")
    @Schema(description = "是否删除：0-否 ；1-是")
    private Integer isDeleted;

    /**
     * 创建人
     */
    @TableField(value = "create_by",fill = FieldFill.INSERT)
    @Schema(description = "创建人")
    private String createBy;

    @TableField(value = "create_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description  = "创建日期(Create Time)")
    protected Date createTime;

    /**
     * 最后修改人
     */
    @TableField(value = "update_by")
    @Schema(description = "最后修改人")
    private String updateBy;

    /**
     * 最后修改时间
     */
    @TableField(value = "update_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description = "最后修改时间")
    private Date updateTime;

    /**
     * 优先级
     */
    @TableField(value = "priority")
    @Schema(description = "优先级")
    private Integer priority;

    private static final long serialVersionUID = 1L;
}