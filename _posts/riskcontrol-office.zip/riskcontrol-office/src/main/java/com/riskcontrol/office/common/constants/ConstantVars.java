package com.riskcontrol.office.common.constants;

import cn.hutool.core.util.StrUtil;

public class ConstantVars {

    public static final String ZERO = "0";
    public static final String ONE = "1";
    public static final String TWO = "2";
    public static final String THREE = "3";
    public static final String FOUR = "4";
    public static final String FIVE = "5";
    public static final String CODE_PREFIX_GW = "GW_";
    public static final String CODE_PREFIX_WS = "WS_";
    public static final String CODE_PREFIX_AGENT = "AG_";
    // 分号
    public static final String SEMICOLON = ";";
    public static final String COLON_SPLIT = ":";
    // 逗号分隔符
    public static final String SEPARATOR_COMMA = ",";
    /**KYC审核失败短信类型**/
    public static final String CUSTOMER_KYC_FAIL_SMS_TYPE = "600192";
    /**KYC审核成功短信类型**/
    public static final String CUSTOMER_KYC_SUCCESS_SMS_TYPE = "600191";

    /**
     * 根据产线获取站点(针对于短信发送)
     * @param tenant
     * @return
     */
    public static String getSiteIdByTenant(String tenant){
        //发送类型[0:bingoplus;1:sports(AP);3:Gameplus; 4:Peryagame;5:Slotsplus]
        return switch (tenant) {
            case "BP" -> ZERO;
            case "AP" -> ONE;
            case "GP" -> THREE;
            case "PG" -> FOUR;
            case "SP" -> FIVE;
            default -> StrUtil.EMPTY;
        };
    }


    public static void main(String[] args) {
        System.out.println(getSiteIdByTenant("AP"));
    }
}
