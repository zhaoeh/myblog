package com.riskcontrol.office.util.aws;

import com.riskcontrol.office.util.RedisUtils;
import com.riskcontrol.office.util.oss.OssService;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;
import org.springframework.util.MimeTypeUtils;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Component
public class AWSS3Util {

    @Value("${aws.s3.bucketName:}")
    private String bucketName;

    private static final Logger logger = LoggerFactory.getLogger(AWSS3Util.class);

    public static final String FILE_HASH ="FILE";

    @Autowired
    private OssService ossService;


    public String s3GetUrl(String key) throws Exception {
        return ossService.getFileUrl(bucketName, key);
    }


    public String s3GetTxtUrl(String key)throws Exception{
        return ossService.getFileTxtUrl(bucketName,key);
    }

    public String s3GetUrl(String key, String suffix) throws Exception {
        return ossService.getFileUrl(bucketName, key, suffix);
    }


    public String s3GetObject(String key) {
        return ossService.getFileBase64(bucketName, key);
    }


    public byte[] s3GetObjectByte(String key) {
        return ossService.getFileByte(bucketName, key);
    }

    @Async
    public void s3PutObject(String base64Img, String key) throws Exception {
        ossService.putObject(bucketName, base64Img, key);
    }

    @Async
    public Future<String> s3PutObject(File base64Img, String key) throws Exception {
        return new AsyncResult<>(ossService.putObject(bucketName, base64Img, key, false));
    }

    @Async
    public Future<String> s3PutObjectPublic(File base64Img, String key) throws Exception {
        return new AsyncResult<>(ossService.putObject(bucketName, base64Img, key, true));
    }

    @Async
    public void s3PutObject(byte[] base64Img, String key) throws Exception {
        ossService.putObject(bucketName, base64Img, key);
    }

    public String s3PutObject(File base64Img, String key, String suffix) throws Exception {
        return ossService.putObject(bucketName, base64Img, key, suffix, false);
    }

    // 注意！！ 敏感数据请问使用此方法
    public String s3PutObjectPublic(File base64Img, String key, String suffix) throws Exception {
        return ossService.putObject(bucketName, base64Img, key, suffix, true);
    }

    public String s3UploadText(String text) throws Exception{
        String contentType = MimeTypeUtils.TEXT_PLAIN_VALUE;
        InputStream inputStream = new ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8));
        String fileName = DigestUtils.md5Hex(text);
        if (Objects.nonNull(s3GetText(fileName))) return fileName;
        String result = ossService.uploadFile(bucketName, inputStream, contentType, fileName);
        logger.info("upload text result:{}, text:{}, bucketName:{}, inputSteam:{}", result, text, bucketName, inputStream);
        return result;
    }

    public String s3UploadTextbyKey(String text,String key) throws Exception{
        String contentType = MimeTypeUtils.TEXT_PLAIN_VALUE;
        InputStream inputStream = new ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8));
        if (Objects.nonNull(s3GetText(key))) return key;
        String result = ossService.uploadFile(bucketName, inputStream, contentType, key);
        logger.info("upload text result:{}, text:{}, bucketName:{}, inputSteam:{}", result, text, bucketName, inputStream);
        return result;
    }

    public String s3GetText(String key){
        String result =  RedisUtils.getHash(FILE_HASH,key,String.class);
        if(StringUtils.isEmpty(result)){
            InputStream file = ossService.getFile(bucketName, key);
            if (Objects.isNull(file)){
                return null;
            }
            result = new BufferedReader(new InputStreamReader(file)).lines().collect(Collectors.joining(System.lineSeparator()));
            RedisUtils.setExpire(key,result,23L, TimeUnit.HOURS);
            logger.info("get text result:{}", result);
        }
        return result;
    }

    private String base64Process(String base64Str) {
        if (!StringUtils.isEmpty(base64Str)) {
            String photoBase64 = base64Str.substring(0, 30).toLowerCase();
            int indexOf = photoBase64.indexOf("base64,");
            if (indexOf > 0) {
                base64Str = base64Str.substring(indexOf + 7);
            }

            return base64Str;
        } else {
            return "";
        }
    }

    public String getPublicUrl(String key){
        return ossService.getPublicUrl(key);
    }

}
