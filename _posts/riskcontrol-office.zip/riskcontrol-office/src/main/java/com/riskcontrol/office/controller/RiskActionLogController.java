package com.riskcontrol.office.controller;

import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.req.RiskActionLoginQueryRequest;
import com.riskcontrol.office.domain.req.RiskActionRegistrationQueryRequest;
import com.riskcontrol.office.domain.rsp.RiskActionLogInResponse;
import com.riskcontrol.office.domain.rsp.RiskActionRegistrationResponse;
import com.riskcontrol.office.service.RiskActionLoginService;
import com.riskcontrol.office.service.RiskActionRegistrationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * zhangheng
 */
@RestController
@Tag(name = "用户登录注册日志")
@SecurityRequirement(name = HttpHeaders.AUTHORIZATION)
@RequestMapping("/office/riskActionLog")
@Validated
public class RiskActionLogController {
    @Autowired
    private RiskActionRegistrationService riskActionRegistrationService;
    @Autowired
    private RiskActionLoginService riskActionLoginService;


//    @PreAuthorize("riskManage_eKycUsers_query,riskManage_eKycUsers_export")
    @PostMapping("/getRegistrationPageList")
    @Operation(tags ="用户登录注册日志" ,summary = "注册日志列表查询")
    public R<PageModel<RiskActionRegistrationResponse>> pageRegistrationList(@Validated @RequestBody RiskActionRegistrationQueryRequest req) {
        return R.ok(riskActionRegistrationService.pageRegistrationList(req));
    }

//    @PreAuthorize("riskManage_ekyc_query,riskManage_ekyc_export")
    @PostMapping("/getLoginPageList")
    @Operation(tags ="用户登录注册日志" ,summary = "登录日志列表查询")
    public R<PageModel<RiskActionLogInResponse>> pageLoginList(@Validated @RequestBody RiskActionLoginQueryRequest req) {
        return R.ok(riskActionLoginService.pageLoginList(req));
    }

}

