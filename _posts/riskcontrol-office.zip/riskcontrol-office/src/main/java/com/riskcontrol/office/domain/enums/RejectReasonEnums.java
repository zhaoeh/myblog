package com.riskcontrol.office.domain.enums;

import cn.hutool.core.util.StrUtil;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum RejectReasonEnums {

    NO_GAME_RECORD("No game record"," withdrawal was unsuccessful due to no game activity. Please contact %s support."," withdrawal was unsuccessful due to no game activity. Please engage in more gameplay or contact %s support."),
    PROMO_NOT_PLAYED("Promo not played"," withdrawal was unsuccessful because the promo hasn't been played. Please contact %s support."," withdrawal was unsuccessful because the promo hasn't been played. Please complete the requirements or contact %s support."),
    INVALID_ID("Invalid id"," withdrawal was unsuccessful due to an invalid ID. Please contact %s support for assistance."," withdrawal was unsuccessful due to an invalid ID. Please contact %s support for assistance."),
    OTHER("Other","withdrawal was unsuccessful due to a system review issue. Please contact %s support for assistance.","withdrawal was unsuccessful due to a system review issue. Please contact %s support for assistance.")
    ;
    /**
     * 类型
     */
    private final String reasonType;

    /**
     * push内容
     */
    private final String pushMsg;
    /**
     * sms内容
     */
    private final String smsMsg;


    public static RejectReasonEnums getReasonByType(String reasonType){
        for (RejectReasonEnums reasonEnums:RejectReasonEnums.values()){
            if (reasonEnums.getReasonType().equalsIgnoreCase(reasonType)){
                return reasonEnums;
            }
        }
        return null;
    }
    public static String getSmsReasonByType(String reasonType,String product){
        for (RejectReasonEnums reasonEnums:RejectReasonEnums.values()){
            if (reasonEnums.getReasonType().equalsIgnoreCase(reasonType)){
                return String.format(reasonEnums.getSmsMsg(),product);
            }
        }
        return StrUtil.EMPTY;
    }

    public static String getPushReasonByType(String reasonType,String product){
        for (RejectReasonEnums reasonEnums:RejectReasonEnums.values()){
            if (reasonEnums.getReasonType().equalsIgnoreCase(reasonType)){
                return String.format(reasonEnums.getPushMsg(),product);
            }
        }
        return StrUtil.EMPTY;
    }

}
