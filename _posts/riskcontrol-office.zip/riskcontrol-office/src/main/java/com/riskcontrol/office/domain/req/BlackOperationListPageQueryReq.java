package com.riskcontrol.office.domain.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.riskcontrol.common.entity.request.BasePageRequest;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;


@Data
@Schema(description = "黑名单操作历史分页查询请求对象")
public class BlackOperationListPageQueryReq extends BasePageRequest {

    @Schema(description = "查询日期")
    @JsonProperty("date")
    @NotBlank(message = "date can not be null")
    private String date;

    @ApiModelProperty("操作人")
    @JsonProperty("operator")
    private String operator;
}
