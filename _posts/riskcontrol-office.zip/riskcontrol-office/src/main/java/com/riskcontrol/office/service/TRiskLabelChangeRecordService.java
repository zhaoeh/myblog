package com.riskcontrol.office.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.domain.entity.TRiskLabelChangeRecord;
import com.riskcontrol.office.domain.req.RiskLabelOperationDetailPageRequest;
import com.riskcontrol.office.domain.rsp.RiskLabelOperationDetailPageRsp;

/**
 * 用户标签变更记录(TRiskLabelChangeRecord)表服务接口
 *
 * @author makejava
 * @since 2024-06-06 15:27:21
 */
public interface TRiskLabelChangeRecordService extends IService<TRiskLabelChangeRecord> {

    /**
     * 查看历史操作记录列表明细
     * @param request 请求参数
     * @return 响应参数
     */
    PageModel<RiskLabelOperationDetailPageRsp> getOperationDetailList(RiskLabelOperationDetailPageRequest request);

}

