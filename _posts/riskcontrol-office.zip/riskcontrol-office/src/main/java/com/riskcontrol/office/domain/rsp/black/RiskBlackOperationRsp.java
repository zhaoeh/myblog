package com.riskcontrol.office.domain.rsp.black;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigInteger;


/**
 * @author Heng.zhang
 */
@ApiModel(value = "风控黑名单操作记录响应对象", description = "风控黑名单")
@Data
public class RiskBlackOperationRsp{

    @ApiModelProperty("ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    @ApiModelProperty(value = "操作人")
    private String operator;

    @ApiModelProperty(value = "状态 0:执行中 1:执行完成")
    private String status;

    @ApiModelProperty(value = "操作类型 0:导入模式 1:关联模式 2:手动更新 3:系统自动关联")
    private String opMode;

    @ApiModelProperty(value = "操作的账号量")
    private String totalNo;

    @ApiModelProperty(value = "成功数量")
    private String successNo;

    @ApiModelProperty(value = "失败数量")
    private String failureNo;

    @ApiModelProperty(value = "完成时间")
    private String finishDate;

    @ApiModelProperty(value = "创建时间")
    private String createDate;

    @ApiModelProperty(value = "备注")
    private String remark;

}