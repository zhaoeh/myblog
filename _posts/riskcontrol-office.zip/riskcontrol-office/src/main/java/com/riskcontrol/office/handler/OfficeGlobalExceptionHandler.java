package com.riskcontrol.office.handler;

import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.office.common.R;
import org.apache.commons.lang3.ObjectUtils;
import org.mybatis.spring.MyBatisSystemException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.validation.ConstraintViolationException;
import java.util.List;
import java.util.stream.Collectors;

/**
 * global exception handler
 *
 * @program: riskcontrol-common
 * @description: 全局异常处理器
 * @author: Erhu.Zhao
 * @create: 2023-10-18 15:21
 **/
@Order(1000)
@ControllerAdvice(basePackages = "com.riskcontrol.office")
public class OfficeGlobalExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(OfficeGlobalExceptionHandler.class);

    /**
     * 处理自定义业务异常
     *
     * @param e
     * @return
     */
    @ExceptionHandler(value = BusinessException.class)
    @ResponseBody
    public R businessExceptionHandler(BusinessException e) {
        log.error("业务异常："+e.buildMessage(), e);
        String code = ObjectUtils.isEmpty(e.getCode()) ? ResultEnum.FAIL.getCode() : e.getCode();
        return R.failed(code,e.getMessage());
    }

    /**
     * 处理方法参数无效异常
     *
     * @param exception
     * @return
     */
    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    @ResponseBody
    public R MethodArgumentNotValidExceptionHandler(MethodArgumentNotValidException exception) {
        BindingResult result = exception.getBindingResult();
        StringBuilder errorMsg = new StringBuilder();
        if (result.hasErrors()) {
            List<FieldError> fieldErrors = result.getFieldErrors();
            fieldErrors.forEach(error -> {
                errorMsg.append(error.getDefaultMessage()).append("!");
            });
        }
        log.error("参数校验错误！原因是：{}", errorMsg);
        return R.failed(ResultEnum.BAD_REQUEST.getCode(),errorMsg.toString());
    }

    /**
     * 处理参数校验异常
     *
     * @param e BindException
     * @return Result
     */
    @ExceptionHandler(BindException.class)
    @ResponseBody
    public R handleValidationException(BindException e) {
        BindingResult bindingResult = e.getBindingResult();
        if (bindingResult.hasErrors()) {
            String errorMessage = bindingResult.getFieldErrors().stream()
                    .map(FieldError::getDefaultMessage).collect(Collectors.joining("/"));
            log.error("参数校验错误！原因是：{}", errorMessage);
            return R.failed(ResultEnum.BAD_REQUEST.getCode(),errorMessage);

        }
        log.error("参数校验错误！原因是：{}", ResultEnum.BAD_REQUEST.getMessage());
        return R.failed(ResultEnum.BAD_REQUEST.getCode(),ResultEnum.BAD_REQUEST.getMessage());

    }

    @ResponseBody
    @ExceptionHandler(ConstraintViolationException.class)
    public R handleValidationErrors(ConstraintViolationException ex) {
        List<String> errors = ex.getConstraintViolations()
                .stream().map(e -> e.getMessage()).collect(Collectors.toList());
        log.error("参数校验错误！原因是：{}", String.join(",", errors));
        return R.failed(ResultEnum.FAIL.getCode(),String.join(",", errors));

    }


    /**
     * 主键异常
     *
     * @param e   Exception
     * @return Result
     */
    @ExceptionHandler(value = DuplicateKeyException.class)
    @ResponseBody
    public R duplicateKeyExceptionHandler(DuplicateKeyException e) {
        log.error("主键异常：", e);
        return R.failed(ResultEnum.BAD_REQUEST.getCode(),"Please check, there is duplicate data");
    }
    /**
     * mybatis异常
     *
     * @param e   Exception
     * @return Result
     */
    @ExceptionHandler(value = MyBatisSystemException.class)
    @ResponseBody
    public R mybatisPlusExceptionHandler(MyBatisSystemException e) {
        log.error("mysql 查询异常：", e);
        return R.failed(ResultEnum.BAD_REQUEST.getCode(),"Operation database exception");
    }


    /**
     * 全局异常
     *
     * @param e   Exception
     * @return Result
     */
    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public R allExceptionHandler(Exception e) {
        log.error("office 全局异常", e);
        return R.failed(ResultEnum.UNEXPECTED_FAIL.getCode(),ResultEnum.UNEXPECTED_FAIL.getMessage());
    }

    /**
     * oms鉴权异常
     *
     * @param e   Exception
     * @return Result
     */
    @ExceptionHandler(value = com.digiplus.oms.exception.BusinessException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    @ResponseBody
    public R duplicateKeyExceptionHandler(com.digiplus.oms.exception.BusinessException e) {
        log.error("oms鉴权异常", e);
        return R.failed(ResultEnum.FORBIDDEN.getCode(),ResultEnum.FORBIDDEN.getMessage());
    }


}