package com.riskcontrol.office.domain.constans.req;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema
@Data
public class QueryConstantsListReq extends BaseReq {
    @Schema(description = "ID", example = "1")
    protected String id;
    @Schema(description = "常量键", example = "KEY_TEST_01 , DEPOSIT_AUTO_APPROVE_SWITCH")
    protected String key;
    @Schema(description = "常量值", example = "1")
    protected String value;
    @Schema(description = "常量类型", example = "0001,0002,0003,0004")
    protected String type;
    protected String createdBy;
    @Schema(description = "创建时间范围开始", example = "2018-01-01 00:00:00")
    protected String createdDateBegin;
    @Schema(description = "创建时间范围结束", example = "2018-01-01 23:59:59")
    protected String createdDateEnd;
    @Schema(description = "最后更新人", example = "system")
    protected String lastUpdatedBy;
    @Schema(description = "最后更新时间范围开始", example = "2018-01-01 00:00:00")
    protected String lastUpdateBegin;
    @Schema(description = "最后更新时间范围结束", example = "2018-01-01 23:59:59")
    protected String lastUpdateEnd;
    @Schema(description = "是否查询所有数据（已作废参数）", example = "false")
    protected boolean allData;
    @Schema(description = "当期页数（从1开始）", example = "1")
    protected int pageNum;
    @Schema(description = "每页条数（最大5000）", example = "50")
    protected int pageSize;
    @Schema(description = "排序字段", example = "created_by desc")
    protected String order;

    @Schema(description = "当期页数（从1开始）", example = "1")
    protected int pageNo;
}
