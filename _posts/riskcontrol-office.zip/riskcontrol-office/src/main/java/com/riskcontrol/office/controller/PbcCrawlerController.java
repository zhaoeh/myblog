package com.riskcontrol.office.controller;

import com.riskcontrol.common.entity.request.PbcCrawlerUpdateStatusReq;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.enums.PbcBannedEnum;
import com.riskcontrol.common.enums.PbcSourceEnum;
import com.riskcontrol.office.annotation.EnableOperationLog;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.entity.TPbcCrawlerResultNew;
import com.riskcontrol.office.domain.enums.OpTypeEnum;
import com.riskcontrol.office.domain.req.PbcCrawlerImportByFullNameReq;
import com.riskcontrol.office.domain.req.PbcCrawlerPageRequest;
import com.riskcontrol.office.service.TPbcCrawlerResultNewService;
import com.riskcontrol.office.template.RiskControlApiTemplate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/***
 *  @program: riskcontrol-office
 ** @description: PBC爬虫Controller
 ** @author: Zhilin.Du
 ** @create: 2024-10-30 11:03
 **/
@RestController
@RequestMapping("/office/pbcCrawler")
@Tag(name = "PBC数据")
@SecurityRequirement(name = HttpHeaders.AUTHORIZATION)
public class PbcCrawlerController {

    @Autowired
    private TPbcCrawlerResultNewService pbcCrawlerResultNewService;

    @Autowired
    private RiskControlApiTemplate riskControlApiTemplate;

    @PostMapping("queryList")
    @Operation(tags ="PBC数据", summary = "分页查询PBC列表接口")
    //    @PreAuthorize("riskConfig_pbcRule_query")
    public R<PageModel<TPbcCrawlerResultNew>> queryList(@Validated @RequestBody PbcCrawlerPageRequest req) {
        return R.ok(pbcCrawlerResultNewService.queryList(req));
    }

    @PostMapping("create/byFullName")
    @Operation(tags ="PBC数据", summary = "根据全名手动创建PBC接口")
    @EnableOperationLog(menuName = "PBC数据", subMenuName = "根据全名手动创建PBC接口", opLog = "创建", opLogType = OpTypeEnum.CREATE)
    //    @PreAuthorize("riskConfig_pbcRule_create")
    public R<List<com.riskcontrol.common.entity.pojo.TPbcCrawlerResultNew>> createByFullName(@Validated @RequestBody PbcCrawlerImportByFullNameReq req) {
        return R.ok(riskControlApiTemplate.pullPagcorDataToDbByFullName(req.getFullName()));
    }

    @PostMapping("updateStatus")
    @Operation(tags ="PBC数据", summary = "解除/禁用PBC接口")
    @EnableOperationLog(menuName = "PBC数据", subMenuName = "解除/禁用PBC接口", opLog = "更新", opLogType = OpTypeEnum.UPDATE)
    //    @PreAuthorize("riskConfig_pbcRule_modify")
    public R<Boolean> updateStatus(@Validated @RequestBody PbcCrawlerUpdateStatusReq req) {
        return R.ok(pbcCrawlerResultNewService.updateStatus(req));
    }

    @GetMapping("/getPbcBannedList")
    @Operation(tags ="PBC数据" ,summary = "pbc的禁用状态接口")
    public R<List<PbcBannedEnum.PbcBanned>> getPbcBannedList() {
        return R.ok(PbcBannedEnum.getAllPbcSource());
    }

    @GetMapping("/getPbcSourceList")
    @Operation(tags ="PBC数据" ,summary = "pbc的来源接口")
    public R<List<PbcSourceEnum.PbcSource>> getPbcSourceList() {
        return R.ok(PbcSourceEnum.getAllPbcSource());
    }

}
