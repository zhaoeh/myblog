package com.riskcontrol.office.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cm.util.common.Constants;
import com.cn.schema.customers.WSCustomers;
import com.digiplus.oms.domain.entity.SysUser;
import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.google.common.collect.Lists;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.constants.CronConstant;
import com.riskcontrol.common.entity.request.label.RiskLabelListRequest;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelDetailRsp;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelRsp;
import com.riskcontrol.common.enums.YesNoEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.common.utils.LogUtils;
import com.riskcontrol.office.common.constants.ConstantVars;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.datasource.DBSourceCheck;
import com.riskcontrol.office.datasource.DataSourceType;
import com.riskcontrol.office.domain.entity.TRiskConstants;
import com.riskcontrol.office.domain.entity.TRiskLabelChangeRecord;
import com.riskcontrol.office.domain.entity.TRiskLabelOperation;
import com.riskcontrol.office.domain.entity.TRiskLabelRelationship;
import com.riskcontrol.office.domain.po.RiskLabelImportPO;
import com.riskcontrol.office.domain.req.RiskLabelChangeReq;
import com.riskcontrol.office.domain.req.RiskLabelImportRequest;
import com.riskcontrol.office.domain.req.RiskLabelPageReq;
import com.riskcontrol.office.domain.rsp.RiskLabelPageRsp;
import com.riskcontrol.office.domain.rsp.RiskLabelRelationRsp;
import com.riskcontrol.office.mapper.RiskLabelOperationMapper;
import com.riskcontrol.office.mapper.TRiskConstantsMapper;
import com.riskcontrol.office.mapper.TRiskLabelChangeRecordMapper;
import com.riskcontrol.office.mapper.TRiskLabelRelationshipMapper;
import com.riskcontrol.office.service.TRiskConstantsService;
import com.riskcontrol.office.service.TRiskLabelRelationshipService;
import com.riskcontrol.office.template.WsApiFeignTemplate;
import com.riskcontrol.office.util.ExcelUtils;
import com.riskcontrol.office.util.RedisUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jinq.orm.stream.JinqStream;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import javax.annotation.Resource;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.math.BigInteger;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.riskcontrol.office.common.constants.ConstantVars.*;

@Service
@Slf4j
public class TRiskLabelRelationshipServiceImpl extends BaseServiceImpl<TRiskLabelRelationshipMapper, TRiskLabelRelationship> implements TRiskLabelRelationshipService {
    public static final String CUSTOMER_All_LABEL = "risk:customer:allLabelnew::%s";
    @Resource
    private TRiskConstantsMapper riskConstantsMapper;

    @Resource
    private TRiskLabelRelationshipMapper riskLabelRelationshipMapper;

    @Resource(name = "taskExecutor")
    protected ThreadPoolTaskExecutor executor;

    @Resource
    private RiskLabelOperationMapper riskLabelOperationMapper;


    @Autowired
    private WsApiFeignTemplate wsApiFeignTemplate;

    @Resource
    private TRiskConstantsService tRiskConstantsService;

    @Autowired
    private RiskLabelRelationshipSupport riskLabelRelationshipSupport;

    /**
     * 批量查询用户标签信息*
     *
     * @param request -
     * @return -
     */
    @Override
    public List<CustomerRiskLabelRsp> listCustomerRiskLabel(RiskLabelListRequest request) {
        if (CollectionUtil.isEmpty(request.getCustomerIds())) {
            return ListUtil.empty();
        }

        // 无绑定标签时返回普通标签
        List<CustomerRiskLabelDetailRsp> customerRiskLabelDetailRspList = new ArrayList<>();
        TRiskConstants riskConstants = riskConstantsMapper.selectOne(Wrappers.lambdaQuery(TRiskConstants.class)
                .eq(TRiskConstants::getPKey, CronConstant.LabelKey.RISK_REGULAR));
        CustomerRiskLabelDetailRsp riskLabelDetailRsp = new CustomerRiskLabelDetailRsp();
        riskLabelDetailRsp.setRiskLabelId(riskConstants.getId())
                .setRiskLabelName(riskConstants.getPValue())
                .setProductId(riskConstants.getProductId());
        customerRiskLabelDetailRspList.add(riskLabelDetailRsp);
        // 查询用户风控标签绑定关系
        List<TRiskLabelRelationship> riskLabelRelationshipList = list(Wrappers.lambdaQuery(TRiskLabelRelationship.class)
                .in(TRiskLabelRelationship::getCustomerId, request.getCustomerIds()));
        //根据customerId 分组
        Map<Long, List<TRiskLabelRelationship>> riskLabelRelationshipGroupMap = riskLabelRelationshipList.stream()
                .collect(Collectors.groupingBy(TRiskLabelRelationship::getCustomerId));

        List<CustomerRiskLabelRsp> rspList = new ArrayList<>();
        request.getCustomerIds().forEach(customerId -> {
            List<TRiskLabelRelationship> riskLabelRelationshipListTemp = riskLabelRelationshipGroupMap.get(customerId);
            CustomerRiskLabelRsp rsp = new CustomerRiskLabelRsp();
            if (CollectionUtil.isNotEmpty(riskLabelRelationshipListTemp)) {
                TRiskLabelRelationship tempRelationship = riskLabelRelationshipListTemp.get(0);
                rsp.setCustomerId(String.valueOf(customerId))
                        .setLoginName(tempRelationship.getLoginName())
                        .setRemark(tempRelationship.getRemark() == null ? StrUtil.EMPTY : tempRelationship.getRemark())
                        .setProductId(tempRelationship.getProductId())
                        .setCreateBy(tempRelationship.getCreateBy())
                        .setCreateTime(DateUtils.dateToDateTime(tempRelationship.getCreateTime()))
                        .setUpdateBy(tempRelationship.getUpdateBy())
                        .setUpdateTime(DateUtils.dateToDateTime(tempRelationship.getUpdateTime()));
                // 用户绑定标签信息
                List<CustomerRiskLabelDetailRsp> customerRiskLabelDetailRsp = new ArrayList<>();
                riskLabelRelationshipListTemp.forEach(label -> {
                    CustomerRiskLabelDetailRsp riskLabelDetailRspTemp = new CustomerRiskLabelDetailRsp();
                    riskLabelDetailRspTemp.setRiskLabelId(label.getRiskLabelId())
                            .setRiskLabelName(label.getRiskLabelName())
                            .setProductId(label.getProductId());
                    customerRiskLabelDetailRsp.add(riskLabelDetailRspTemp);
                });
                rsp.setRiskLabels(customerRiskLabelDetailRsp);
            } else {
                rsp.setCustomerId(String.valueOf(customerId))
                        .setRemark(StrUtil.EMPTY)
                        .setCreateBy("-")
                        .setCreateTime("-")
                        .setUpdateTime("-")
                        .setUpdateBy("-");
                // 无绑定关系数据时默认普通标签
                rsp.setRiskLabels(customerRiskLabelDetailRspList);
            }
            rspList.add(rsp);
        });
        return rspList;
    }

    /**
     * 获取用户风控标签详情
     *
     * @param customerId
     * @return
     */
    @Override
    public CustomerRiskLabelRsp getRiskLabelDetail(Long customerId) {
        if (Objects.isNull(customerId)) {
            return new CustomerRiskLabelRsp();
        }
        List<TRiskLabelRelationship> riskLabelRelationshipList = list(Wrappers.lambdaQuery(TRiskLabelRelationship.class)
                .eq(TRiskLabelRelationship::getCustomerId, customerId));

        List<CustomerRiskLabelDetailRsp> customerRiskLabelDetailRspList = new ArrayList<>();
        CustomerRiskLabelRsp customerRiskLabelRsp = new CustomerRiskLabelRsp();

        riskLabelRelationshipList.forEach(r -> {
            customerRiskLabelRsp.setCustomerId(String.valueOf(r.getCustomerId()))
                    .setLoginName(r.getLoginName())
                    .setRemark(r.getRemark() == null ? StrUtil.EMPTY : r.getRemark())
                    .setProductId(r.getProductId())
                    .setCreateBy(r.getCreateBy())
                    .setCreateTime(DateUtils.dateToDateTime(r.getCreateTime()))
                    .setUpdateBy(r.getUpdateBy())
                    .setUpdateTime(DateUtils.dateToDateTime(r.getUpdateTime()));

            CustomerRiskLabelDetailRsp riskLabelDetailRsp = new CustomerRiskLabelDetailRsp();
            riskLabelDetailRsp.setRiskLabelId(r.getRiskLabelId())
                    .setRiskLabelName(r.getRiskLabelName())
                    .setProductId(r.getProductId())
                    .setRiskLabelKey(r.getRiskLabelKey());
            customerRiskLabelDetailRspList.add(riskLabelDetailRsp);
        });
        if (CollectionUtil.isEmpty(riskLabelRelationshipList)) {
            customerRiskLabelRsp.setCustomerId(String.valueOf(customerId))
                    .setRemark(StrUtil.EMPTY)
                    .setCreateBy("-")
                    .setCreateTime("-")
                    .setUpdateTime("-")
                    .setUpdateBy("-");
            // 无绑定标签时返回普通标签
            TRiskConstants riskConstants = riskConstantsMapper.selectOne(Wrappers.lambdaQuery(TRiskConstants.class).eq(TRiskConstants::getPKey, CronConstant.LabelKey.RISK_REGULAR));
            CustomerRiskLabelDetailRsp riskLabelDetailRsp = new CustomerRiskLabelDetailRsp();
            riskLabelDetailRsp.setRiskLabelId(riskConstants.getId())
                    .setRiskLabelName(riskConstants.getPValue())
                    .setProductId(riskConstants.getProductId())
                    .setRiskLabelKey(riskConstants.getPKey());
            customerRiskLabelDetailRspList.add(riskLabelDetailRsp);
        }
        customerRiskLabelRsp.setRiskLabels(customerRiskLabelDetailRspList);
        return customerRiskLabelRsp;
    }

//    @Override
//    public PageModel<RiskLabelPageRsp> queryRiskLabelRelationships(RiskLabelPageReq req) {
//        // 只查询用户绑定的有效标签
//        req.setQueryValidatedLabel(true);
//        Page<TRiskLabelRelationship> page = new Page<>(req.getPageNum(), req.getPageSize());
//        Optional.ofNullable(req.getSortName()).filter(StringUtils::isNotBlank).ifPresent(t -> {
//            Boolean asc = req.getIsAsc();
//            page.setOrders(BooleanUtils.isTrue(asc) ? List.of(OrderItem.asc(t)) : List.of(OrderItem.desc(t)));
//        });
//        IPage<TRiskLabelRelationship> result = riskLabelRelationshipMapper.selectRelationPage(page, req);
//        List<RiskLabelPageRsp> data = result.getRecords().stream().map(ship -> {
//            RiskLabelPageRsp rsp = new RiskLabelPageRsp();
//            BeanUtils.copyProperties(ship, rsp);
//            rsp.setCustomerId(String.valueOf(ship.getCustomerId()));
//            return rsp;
//        }).collect(Collectors.toList());
//        PageModel<RiskLabelPageRsp> pageModel = new PageModel<>((int) page.getTotal(), req.getPageNum(), req.getPageSize());
//        pageModel.setTotalPage((int) result.getPages());
//        pageModel.setData(data);
//        return pageModel;
//    }

//    @Override
//    public PageModel<RiskLabelPageRsp> queryRiskLabelRelationships(RiskLabelPageReq req) {
//        // 只查询用户绑定的有效标签
//        req.setQueryValidatedLabel(true);
//        Page<TRiskLabelRelationship> page = new Page<>(req.getPageNum(), req.getPageSize());
//        Optional.ofNullable(req.getSortName()).filter(StringUtils::isNotBlank).ifPresent(t -> {
//            Boolean asc = req.getIsAsc();
//            page.setOrders(BooleanUtils.isTrue(asc) ? List.of(OrderItem.asc(t)) : List.of(OrderItem.desc(t)));
//        });
//        IPage<TRiskLabelRelationship> result = riskLabelRelationshipMapper.selectRelationPage(page, req);
//        List<RiskLabelPageRsp> data = result.getRecords().stream().map(ship -> {
//            RiskLabelPageRsp rsp = new RiskLabelPageRsp();
//            BeanUtils.copyProperties(ship, rsp);
//            rsp.setCustomerId(String.valueOf(ship.getCustomerId()));
//            return rsp;
//        }).collect(Collectors.toList());
//        PageModel<RiskLabelPageRsp> pageModel = new PageModel<>((int) page.getTotal(), req.getPageNum(), req.getPageSize());
//        pageModel.setTotalPage((int) result.getPages());
//        pageModel.setData(data);
//        return pageModel;
//    }

    @Override
    @DBSourceCheck(DataSourceType.SLAVE)
    public PageModel<RiskLabelPageRsp> queryRiskLabelRelationships(RiskLabelPageReq req) {
        Page<RiskLabelPageRsp> page = new Page<>(req.getPageNum(), req.getPageSize());
        //必须指定一个查询条件
        if(StringUtils.isBlank(req.getLoginName()) && CollectionUtil.isEmpty(req.getRiskLabelIds())){
            throw new BusinessException("Please select a query condition!", 100003);
        }
        IPage<RiskLabelPageRsp> result = riskLabelRelationshipMapper.selectRelationPage(page, req);
        PageModel<RiskLabelPageRsp> pageModel = new PageModel<>((int) result.getTotal(), req.getPageNum(), req.getPageSize());
        pageModel.setTotalPage((int) result.getPages());

        var lambdaQueryWrapper = new LambdaQueryWrapper<TRiskLabelRelationship>()
                .in(TRiskLabelRelationship::getLoginName, result.getRecords().stream().map(s -> s.getLoginName()).toList());
        var riskLabelRelationshipList = result.getRecords().isEmpty() ? new ArrayList<TRiskLabelRelationship>() : this.riskLabelRelationshipMapper.selectList(lambdaQueryWrapper);
        pageModel.setData(result.getRecords()
                .stream()
                .peek(riskLabelRelationship -> {
                    var riskLableIdList = JinqStream.from(riskLabelRelationshipList)
                            .where(m -> m.getLoginName().equals(riskLabelRelationship.getLoginName()))
                            .select(m -> m.getRiskLabelId())
                            .sortedBy(m -> m)
                            .toList();
                    riskLabelRelationship.setRiskLabelIds(StringUtils.join(riskLableIdList, ","));
                    riskLabelRelationship.setUpdateBy(JinqStream.from(riskLabelRelationshipList)
                            .where(m -> m.getLoginName().equals(riskLabelRelationship.getLoginName()))
                            .sortedDescendingBy(m -> m.getUpdateTime())
                            .select(m -> StringUtils.isNotBlank(m.getUpdateBy()) ? m.getUpdateBy() : "")
                            .findFirst()
                            .orElse(""));
                }).toList());


        return pageModel;
    }

    @Override
    public Boolean modifyRiskLabelRelationship(RiskLabelChangeReq req) {
        String loginName = req.getLoginName();
        // DB中存量的“用户-标签”关系记录
        List<TRiskLabelRelationship> oldRecords = this.list(new LambdaQueryWrapper<TRiskLabelRelationship>().eq(TRiskLabelRelationship::getLoginName, loginName));
        // 用户关系不存在，直接报错
        Assert.isTrue(CollectionUtil.isNotEmpty(oldRecords), () -> {
            throw new BusinessException("400", "loginName [" + loginName + "] is not exists in DB,please check");
        });

        // 请求中的标签id集合
        List<BigInteger> labelIds = req.getRiskLabelIds();
        // DB中的标签集合
        List<TRiskConstants> labelsInDb = riskConstantsMapper.selectList(new LambdaQueryWrapper<TRiskConstants>().in(TRiskConstants::getId, labelIds).
                eq(TRiskConstants::getIsDeleted, YesNoEnum.NO.getIntCode()).eq(TRiskConstants::getIsEnable, YesNoEnum.YES.getIntCode()));
        List<BigInteger> labelIdsInDb = labelsInDb.stream().map(TRiskConstants::getId).collect(Collectors.toList());
        List<BigInteger> diffLabelIds = labelIds.stream().filter(item -> !labelIdsInDb.contains(item)).collect(Collectors.toList());
        Assert.isTrue(CollectionUtil.isEmpty(diffLabelIds), () -> {
            throw new BusinessException("400", "riskLabelId " + diffLabelIds + " is not exists in DB,please check");
        });

        Map<BigInteger, TRiskConstants> labelsInDbMap = labelsInDb.stream().collect(Collectors.toMap(TRiskConstants::getId, Function.identity(), (k1, k2) -> k2));

        UserInfoVO userInfoVO = CurrentUserUtil.get();
        log.info("修改用户风控标签，获取登录用户，userInfoVO：{}", JSON.toJSONString(userInfoVO));
        String operator = Optional.ofNullable(userInfoVO).map(UserInfoVO::getUserInfo).map(SysUser::getUsername).orElse("");
        TRiskLabelRelationship existsRecord = oldRecords.stream().findFirst().get();
        List<TRiskLabelRelationship> newRecords = labelIds.stream().map(requestLabelId -> {
            TRiskLabelRelationship ship = new TRiskLabelRelationship();
            BeanUtils.copyProperties(existsRecord, ship);
            ship.setId(null);
            ship.setRiskLabelId(requestLabelId);
            ship.setRiskLabelKey(labelsInDbMap.get(requestLabelId).getPKey());
            ship.setRiskLabelName(labelsInDbMap.get(requestLabelId).getPValue());
            ship.setUpdateTime(new Date());
            ship.setCreateTime(new Date());
            ship.setCreateBy(operator);
            ship.setUpdateBy(operator);
            return ship;
        }).collect(Collectors.toList());
        return riskLabelRelationshipSupport.doModifyRelationships(1, oldRecords, newRecords,operator);
    }

    @Override
    public RiskLabelRelationRsp queryRiskLabelRelationshipByLoginName(String loginName) {
        LambdaQueryWrapper<TRiskLabelRelationship> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(TRiskLabelRelationship::getLoginName, loginName);
        List<TRiskLabelRelationship> tRiskLabelRelationshipList = this.list(wrapper);
        var result = tRiskLabelRelationshipList.stream().collect(Collectors.groupingBy(r->r.getLoginName(),Collectors.toList()));
        var labelIds = result.get(loginName).stream().map(r -> String.valueOf(r.getRiskLabelId())).collect(Collectors.joining(","));
        return Optional.ofNullable(tRiskLabelRelationshipList).map(ship -> {
            RiskLabelRelationRsp rsp = new RiskLabelRelationRsp();
            rsp.setLoginName(ship.get(0).getLoginName());
            rsp.setRiskLabelIds(labelIds);
            rsp.setProductId(Constants.C66);
            rsp.setCustomerId(ship.get(0).getCustomerId());
            return rsp;
        }).orElseThrow(() -> {
            throw new BusinessException("400", loginName + "不存在，请检查");
        });
    }

//    @Transactional(rollbackFor = Exception.class)
//    @Override
//    public Boolean bindingCustomerRiskLabel(RiskLabelBindingRequest request) {
//        if (CollectionUtil.isEmpty(request.getRiskLabelIds())) {
//            throw new BusinessException(ResultEnum.RISK_LABEL_ID_IS_EMPTY);
//        }
//        // 根据customerId检查当前绑定的标签信息
//        LambdaQueryWrapper<TRiskLabelRelationship> currentLabelList = Wrappers.lambdaQuery(TRiskLabelRelationship.class)
//                .eq(TRiskLabelRelationship::getCustomerId, request.getCustomerId());
//
//        List<TRiskLabelRelationship> currentRelationshipList = list(currentLabelList);
//        List<Long> currentLabelIdListSort = currentRelationshipList.stream().map(TRiskLabelRelationship::getRiskLabelId).sorted().collect(Collectors.toList());
//        List<Long> requestLabelIdListSort = request.getRiskLabelIds().stream().distinct().sorted().collect(Collectors.toList());
//
//        String oldLabelNameArrStr = currentRelationshipList.stream().map(TRiskLabelRelationship::getRiskLabelName).collect(Collectors.joining(","));
//        String oldLabelIdArrStr = currentRelationshipList.stream().map(r -> String.valueOf(r.getRiskLabelId())).collect(Collectors.joining(","));
//        // 查询标签信息
//        List<TRiskConstants> riskLabelList = riskConstantsMapper.selectList(Wrappers.lambdaQuery(TRiskConstants.class)
//                .in(TRiskConstants::getId, request.getRiskLabelIds())
//                .eq(TRiskConstants::getIsEnable, YesNoEnum.YES.getCode())
//                .eq(TRiskConstants::getIsDeleted,YesNoEnum.NO.getCode()));
//        Map<Long, String> riskLabelMap = riskLabelList.stream().collect(Collectors.toMap(TRiskConstants::getId, TRiskConstants::getPValue));
//        boolean labelChangeFlag = false;
//        boolean remarkChangeFlag = false;
//        boolean equalsFlag = currentLabelIdListSort.equals(requestLabelIdListSort);
//        if (!equalsFlag) {
//            labelChangeFlag = true;
//            // 标签信息变更，删除原绑定关系
//            remove(currentLabelList);
//            // 添加用户风控标签绑定关系
//            riskLabelList.forEach(r -> {
//                TRiskLabelRelationship riskLabelRelationship = TRiskLabelRelationship.builder()
//                        .riskLabelId(r.getId())
//                        .customerId(request.getCustomerId())
//                        .riskLabelKey(r.getPKey())
//                        .riskLabelName(riskLabelMap.get(r.getId()))
//                        .remark(request.getRemarks())
//                        .productId(request.getProductId())
//                        .loginName(request.getLoginName())
//                        .updateBy(request.getOperator())
//                        .updateTime(DateUtil.date())
//                        .createBy(request.getOperator())
//                        .createTime(DateUtil.date())
//                        .build();
//                save(riskLabelRelationship);
//            });
//        } else {
//            // 标签信息未变更，检查备注是否变更
//            if (CollectionUtil.isNotEmpty(currentRelationshipList)) {
//                String currentRemark = currentRelationshipList.get(0).getRemark();
//                boolean allBlankFlag = StrUtil.isBlank(currentRemark) && StrUtil.isBlank(request.getRemarks());
//                remarkChangeFlag = !allBlankFlag && !(StrUtil.equals(currentRemark, request.getRemarks()));
//                if (remarkChangeFlag) {
//                    // 更新绑定关系备注
//                    TRiskLabelRelationship update = TRiskLabelRelationship.builder()
//                            .remark(request.getRemarks())
//                            .updateTime(DateUtil.date())
//                            .updateBy(request.getOperator()).build();
//                    update(update, Wrappers.lambdaQuery(TRiskLabelRelationship.class).eq(TRiskLabelRelationship::getCustomerId, request.getCustomerId()));
//                }
//            }
//        }
//        if (labelChangeFlag || remarkChangeFlag) {
//            // 添加变更记录
//            TRiskLabelChangeRecord riskLabelChangeRecord = TRiskLabelChangeRecord.builder()
//                    .productId(request.getProductId())
//                    .customerId(request.getCustomerId())
//                    .loginName(request.getLoginName().trim())
//                    .newRiskLabelId(riskLabelList.stream().map(r -> String.valueOf(r.getId())).collect(Collectors.joining(",")))
//                    .newRiskLabelName(riskLabelList.stream().map(TRiskConstants::getPValue).collect(Collectors.joining(",")))
//                    .oldRiskLabelName(oldLabelNameArrStr)
//                    .oldRiskLabelId(oldLabelIdArrStr)
//                    .remark(request.getRemarks())
//                    .createBy(request.getOperator())
//                    .createTime(DateUtil.date())
//                    .build();
//            riskLabelChangeRecordMapper.insert(riskLabelChangeRecord);
//        }
//        return true;
//    }

    @Override
    public Boolean importExcel(RiskLabelImportRequest.RiskLabelImport importRequest) {
        TRiskLabelOperation mainLog = TRiskLabelOperation.builder().
                opMode(Integer.valueOf(ZERO)).
                status(Integer.valueOf(ZERO)).
                finishDate("1900-01-01 00:00:00").
                operator(importRequest.getDataModifier()).
                build();
        boolean isSuccess = riskLabelOperationMapper.insert(mainLog) > 0;
        if (isSuccess) {
            importRequest.setRiskLabelIds(importRequest.getRiskLabelIds().stream().distinct().collect(Collectors.toList()));
            Map<String,String> mdcContextMap = LogUtils.getMDCContextMap();
            executor.submit(buildImportTask(importRequest, mainLog,mdcContextMap));
        }
        return true;
    }


    private List<RiskLabelImportPO.ImportMode> getTotalCount(byte[] bytes) {
        List<RiskLabelImportPO.ImportMode> imports = null;
        try (InputStream inputStream = new ByteArrayInputStream(bytes)) {
            imports = ExcelUtils.read(inputStream, RiskLabelImportPO.ImportMode.class);
        } catch (Exception e) {
            log.error("解析文件失败", e);
        }
        return imports;
    }

    private Runnable buildImportTask(RiskLabelImportRequest.RiskLabelImport labelImport, TRiskLabelOperation mainLog,Map<String,String> mdcContextMap) {
        return () -> {
            LogUtils.setMDCContextMap(mdcContextMap);
            List<RiskLabelImportPO.ImportMode> imports = getTotalCount(labelImport.getContent());
            if(CollectionUtil.isEmpty(imports)){
                log.info("导入用户为空，终止导入");
                return;
            }
            int sero = Integer.valueOf(ConstantVars.ZERO);
            // 获取目标用户集（非空、去重）
            List<String> importUsers = imports.stream().filter(Objects::nonNull).map(RiskLabelImportPO.ImportMode::getLoginName).distinct().collect(Collectors.toList());
            int totalCount = imports.size();
            try {
                RiskLabelImportPO.LabelImportContext context = this.collectDates(labelImport.setImportUsers(importUsers).setMainLogId(mainLog.getId()));

                context.setTotalCount(BigInteger.valueOf(totalCount));
                if (CollectionUtil.isEmpty(context.getListMap()) && CollectionUtil.isEmpty(context.getLabelLogDetails())) {
                    mainLog.setStatus(Integer.valueOf(TWO));
                } else {
                    mainLog.setStatus(Integer.valueOf(ONE));
                    mainLog.setTotalNo(totalCount);
                    int successNo = Optional.ofNullable(context.getLabelLogDetails()).map(logDetail -> logDetail.stream().filter(op ->op.getOperationStatus().equals(Integer.valueOf(ONE))).count()).orElse(0L).intValue();
                    mainLog.setSuccessNo(totalCount == sero ? sero : successNo);
                    mainLog.setFailureNo(totalCount >= successNo ? totalCount - successNo : sero);
                }
                log.info("导入用户标签前收集数据,导入标签（用户*标签）的总数：{},日志明细总数：{}", totalCount,CollectionUtil.size(context.getLabelLogDetails()));
//                log.info("导入用户标签前收集数据,导入标签：{},日志明细：{}", context.getListMap(),context.getLabelLogDetails());
                log.info("导入用户标签前日志主表：{}", JSON.toJSONString(mainLog));
                // 执行导入操作
                riskLabelRelationshipSupport.doImports(context);
            } catch (Exception e) {
                log.error("用户标签异步导入操作发生错误，e:", e);
                mainLog.setStatus(Integer.valueOf(ConstantVars.TWO));
                mainLog.setTotalNo(totalCount);
                mainLog.setSuccessNo(sero);
                mainLog.setFailureNo(totalCount);
            } finally {
                // 日志明细入库成功，记录导入日志
                try {
                    mainLog.setFinishDate(DateUtils.getCurrentDateTime());
                    log.info("用户标签插入主表后更新日志主表的入参：{}", JSON.toJSONString(mainLog));
                    riskLabelOperationMapper.updateById(mainLog);
                } catch (Exception e) {
                    log.error("用户标签异步导入操作更新日志主表发生错误，e:", e);
                }
            }
        };
    }

    private RiskLabelImportPO.LabelImportContext collectDates(RiskLabelImportRequest.RiskLabelImport labelImport) {
        RiskLabelImportPO.LabelImportContext context = new RiskLabelImportPO.LabelImportContext();
        List<String> importUsers = labelImport.getImportUsers();
        if(CollectionUtil.isEmpty(importUsers)){
            log.info("请求中导入用户为空，终止导入，导入用户为：{}", importUsers);
            context.setTotalCount(BigInteger.ZERO);
            return context;
        }
        List<BigInteger> requestLabelIds = labelImport.getRiskLabelIds();
        if(CollectionUtil.isEmpty(requestLabelIds)){
            log.info("请求中导入标签ids {} 为空，终止导入", requestLabelIds);
            return context;
        }
        // 查询入参中的标签集
        Map<BigInteger, TRiskConstants> labelMaps = riskConstantsMapper.selectList(new LambdaQueryWrapper<TRiskConstants>().in(TRiskConstants::getId, requestLabelIds).
                eq(TRiskConstants::getIsDeleted, YesNoEnum.NO.getIntCode()).
                eq(TRiskConstants::getIsEnable, YesNoEnum.YES.getIntCode())).
                stream().collect(Collectors.toMap(TRiskConstants::getId, Function.identity()));
        if (CollectionUtil.isEmpty(labelMaps)) {
            log.info("请求中导入标签ids {} 在db中不存在，终止导入", requestLabelIds);
            return context;
        }

        // 请求存在，但DB中不存在，则终止导入，存在垃圾标签
        List<BigInteger> labelIdsInDb = labelMaps.keySet().stream().collect(Collectors.toList());
        List<BigInteger> diffLabelIds = requestLabelIds.stream().filter(item -> !labelIdsInDb.contains(item)).collect(Collectors.toList());
        if(CollectionUtil.isNotEmpty(diffLabelIds)){
            log.error("请求中部分标签 ids {} 不存在，终止导入", diffLabelIds);
        }

        List<TRiskLabelRelationship> labelRelationships = new ArrayList<>();
        List<TRiskLabelChangeRecord> labelChangeRecords = new ArrayList<>();
        // loginName->旧标签集映射
        List<List<String>> batches = Lists.partition(importUsers, 2000);
        Map<String, List<TRiskLabelRelationship>> oldRelationsMap = batches.stream().map(p -> getOldLabelInfo(p).stream()).reduce((r1, r2) -> Stream.concat(r1, r2)).map(stream -> stream.collect(Collectors.groupingBy(TRiskLabelRelationship::getLoginName))).orElse(Collections.emptyMap());

        BigInteger mainLogId = labelImport.getMainLogId();
        importUsers.stream().forEach(account -> {
            WSCustomers wsCustomers;
            wsCustomers = wsApiFeignTemplate.getSimpleCustomerByLoginName(Constants.C66, account);
            log.info("导入用户标签，查询ws用户，返回结果:{}",JSON.toJSONString(wsCustomers));
            if (Objects.isNull(wsCustomers) || Objects.isNull(wsCustomers.getLoginName())) {
                // 非法用户
                var newRiskLabelId = requestLabelIds.stream().distinct().map(Objects::toString).collect(Collectors.joining(","));
                labelChangeRecords.add(TRiskLabelChangeRecord.builder()
                        .productId(Constants.C66)
                        .loginName(account)
                        .newRiskLabelId(newRiskLabelId)
                        .operationStatus(Integer.valueOf(ConstantVars.ZERO))
                        .createTime(new Date())
                        .createBy(labelImport.getDataModifier())
                        .customerId(0L)
                        .logId(mainLogId).build());
            } else {
                List<TRiskLabelRelationship> oldRelationships = oldRelationsMap.get(account);
                // 获取当前用户原有的标签ids 和 原有的标签名称集
                List<BigInteger> oldLabelIds = Optional.ofNullable(oldRelationships).map(list -> list.stream().map(TRiskLabelRelationship::getRiskLabelId).distinct()).map(s -> s.collect(Collectors.toList())).orElse(Collections.emptyList());
//              //  List<String> oldLabelNames = Optional.ofNullable(oldRelationsMap.get(account)).map(list -> list.stream().map(TRiskLabelRelationship::getRiskLabelName).distinct()).map(s -> s.collect(Collectors.toList())).orElse(Collections.emptyList());
                // 当前用户新标签和老标签取差集，得到当前用户需要绑定的标签集
                Map<Boolean,List<BigInteger>> needLabelIds = requestLabelIds.stream().distinct().collect(Collectors.partitioningBy(item -> !oldLabelIds.contains(item)));
                if(CollectionUtil.isNotEmpty(needLabelIds)){
                    List<BigInteger> needToInsert = needLabelIds.get(true);
                    List<BigInteger> existsToUpdate = needLabelIds.get(false);
                    if(CollectionUtil.isNotEmpty(needToInsert)){
                        // 当前用户存在增量标签，绑定当前用户和目标标签集
                        List<TRiskLabelRelationship> needLabelRelationships = needToInsert.stream().map(needLabelId -> {
                            TRiskLabelRelationship labelRelationship = new TRiskLabelRelationship();
                            labelRelationship.setLoginName(account);
                            labelRelationship.setCustomerId(Long.parseLong(wsCustomers.getCustomerId()));
                            labelRelationship.setProductId(Constants.C66);
                            labelRelationship.setRiskLabelId(needLabelId);
                            labelRelationship.setRiskLabelKey(labelMaps.get(needLabelId).getPKey());
                            labelRelationship.setRiskLabelName(labelMaps.get(needLabelId).getPValue());
                            labelRelationship.setCreateTime(new Date());
                            labelRelationship.setCreateBy(labelImport.getDataModifier());
                            labelRelationship.setUpdateTime(new Date());
                            labelRelationship.setUpdateBy(labelImport.getDataModifier());
                            return labelRelationship;
                        }).collect(Collectors.toList());
                        labelRelationships.addAll(needLabelRelationships);
                    }
                    if(CollectionUtil.isNotEmpty(existsToUpdate) && CollectionUtil.isNotEmpty(oldRelationships)){
                        Map<BigInteger, List<TRiskLabelRelationship>> existsMapping = oldRelationships.stream().collect(Collectors.groupingBy(TRiskLabelRelationship::getRiskLabelId));
                        // 数据库中存量记录需要进行更新
                        List<TRiskLabelRelationship> needToUpdate = existsToUpdate.stream().flatMap(labelId -> {
                            List<TRiskLabelRelationship> currentLabelIdRecords = existsMapping.get(labelId);
                            return CollectionUtil.isEmpty(currentLabelIdRecords) ? Stream.empty() : currentLabelIdRecords.stream();
                        }).map(record->{
                            record.setUpdateTime(new Date());
                            record.setUpdateBy(labelImport.getDataModifier());
                            return record;
                        }).collect(Collectors.toList());
                        labelRelationships.addAll(needToUpdate);
                    }
                    TRiskLabelChangeRecord record = TRiskLabelChangeRecord.builder()
                            .productId(Constants.C66)
                            .loginName(account)
                            .customerId(Long.valueOf(wsCustomers.getCustomerId()))
                            .operationStatus(Integer.valueOf(ONE))
                            .createTime(new Date())
                            .createBy(labelImport.getDataModifier())
                            .newRiskLabelId(Stream.concat(oldLabelIds.stream(), requestLabelIds.stream()).distinct().map(Objects::toString).collect(Collectors.joining(",")))
                            .oldRiskLabelId(oldLabelIds.stream().map(Objects::toString).collect(Collectors.joining(",")))
                            .logId(mainLogId).build();
                    // 合法用户
                    labelChangeRecords.add(record);
                }
            }
        });

        context.setListMap(labelRelationships.stream().filter(Objects::nonNull).collect(Collectors.partitioningBy(item -> Objects.isNull(item.getId()))));
        context.setLabelLogDetails(labelChangeRecords);
        return context;
    }


    private List<TRiskLabelRelationship> getOldLabelInfo(List<String> loginNames) {
        if(CollectionUtil.isEmpty(loginNames)){
            return Collections.emptyList();
        }
        LambdaQueryWrapper<TRiskLabelRelationship> wrapper = new LambdaQueryWrapper<>();
        wrapper.in(TRiskLabelRelationship::getLoginName, loginNames.stream().distinct().collect(Collectors.toList()));
        return list(wrapper);
    }


    @Component
    @Slf4j
    static class RiskLabelRelationshipSupport extends BaseServiceImpl<TRiskLabelRelationshipMapper, TRiskLabelRelationship> {

        @Resource
        private TRiskLabelChangeRecordMapper riskLabelChangeRecordMapper;

        @Resource
        private RiskLabelOperationMapper riskLabelOperationMapper;

        /**
         * 更新*
         *
         * @param oldRecords
         * @param newRecords
         */
        @Transactional(rollbackFor = Exception.class)
        public Boolean doModifyRelationships(int size, List<TRiskLabelRelationship> oldRecords, List<TRiskLabelRelationship> newRecords,String operator) {
            if (CollectionUtil.isEmpty(oldRecords) || CollectionUtil.isEmpty(newRecords)) {
                return true;
            }
            if (this.removeBatchByIds(oldRecords) && this.saveBatch(newRecords)) {
                String loginName = newRecords.stream().findFirst().map(TRiskLabelRelationship::getLoginName).get();
                TRiskLabelOperation mainLog = TRiskLabelOperation.builder().
                        operator(operator)
                        .status(1).opMode(1).totalNo(size).successNo(size).failureNo(0).build();
                riskLabelOperationMapper.insert(mainLog);
                TRiskLabelChangeRecord detailLog = TRiskLabelChangeRecord.builder().
                        productId(newRecords.stream().findFirst().map(TRiskLabelRelationship::getProductId).orElse(Constant.C66_PRODUCT_ID)).
                        newRiskLabelId(newRecords.stream().map(TRiskLabelRelationship::getRiskLabelId).map(Objects::toString).collect(Collectors.joining(","))).
//                        newRiskLabelName(newRecords.stream().map(TRiskLabelRelationship::getRiskLabelName).collect(Collectors.joining(","))).
                        loginName(loginName).
                        createBy(operator).
                        customerId(newRecords.stream().findFirst().map(TRiskLabelRelationship::getCustomerId).get()).
                        oldRiskLabelId(oldRecords.stream().map(TRiskLabelRelationship::getRiskLabelId).map(Objects::toString).collect(Collectors.joining(","))).
//                        oldRiskLabelName(oldRecords.stream().map(TRiskLabelRelationship::getRiskLabelName).collect(Collectors.joining(","))).
                        operationStatus(com.riskcontrol.office.common.constants.Constants.VALID_LABEL_STATUS).logId(mainLog.getId()).build();
                riskLabelChangeRecordMapper.insert(detailLog);
                //删除redis缓存
                String key = String.format(CUSTOMER_All_LABEL, detailLog.getCustomerId());
                RedisUtils.remove(key);
                log.info("更新用户标签完成，删除用户标签key：{}",key);
            }
            return true;
        }


        @Transactional(rollbackFor = Exception.class)
        public Boolean doImports(RiskLabelImportPO.LabelImportContext context) {
            if (CollectionUtil.isNotEmpty(context.getLabelLogDetails())) {
                log.info("新增标签日志明细表开始，入参：{}", JSON.toJSONString(context.getLabelLogDetails()));
                // 插入日志明细
                riskLabelChangeRecordMapper.insertBatch((context.getLabelLogDetails()));
                log.info("新增标签日志明细表结束");
            }
            Map<Boolean, List<TRiskLabelRelationship>> listMap = context.getListMap();
            if (CollectionUtil.isNotEmpty(listMap)) {
                log.info("新增标签表开始");
                List<TRiskLabelRelationship> existInserts = listMap.get(Boolean.FALSE);
                if(CollectionUtil.isNotEmpty(existInserts)){
                    // 分批删除存量数据
                    List<List<BigInteger>> needDeleteIds = Lists.partition(existInserts.stream().map(TRiskLabelRelationship::getId).distinct().collect(Collectors.toList()),5000);
                    log.info("新增标签表开始，先批量删除已存在的Id：{}", JSON.toJSONString(needDeleteIds));
                    needDeleteIds.stream().forEach(ids-> this.getBaseMapper().deleteBatchIds(ids));
                    log.info("批量删除结束");
                }
                List<TRiskLabelRelationship> totalInserts = listMap.values().stream().flatMap(List::stream).map(ship->{
                    ship.setId(null);
                    return ship;
                }).collect(Collectors.toList());
                if(CollectionUtil.isNotEmpty(totalInserts)){
                    log.info("新增标签表开始，导入总数：{}", CollectionUtil.size(totalInserts));
                    // 插入标签表
                    this.saveBatch(totalInserts);
                    //删除redis缓存
                    List<Long> customerIds = totalInserts.stream().map(TRiskLabelRelationship::getCustomerId).distinct().collect(Collectors.toList());
                    customerIds.forEach(customerId->{
                        String key = String.format(CUSTOMER_All_LABEL, customerId);
                        RedisUtils.remove(key);
                        log.info("新增标签表，导入完成，删除用户标签key：{}",key);
                    });

                    log.info("新增标签表结束");
                }
            }
            return true;
        }

    }
}
