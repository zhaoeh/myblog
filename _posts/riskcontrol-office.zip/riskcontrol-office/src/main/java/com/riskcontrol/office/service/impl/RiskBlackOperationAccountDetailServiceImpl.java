package com.riskcontrol.office.service.impl;

import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.riskcontrol.office.domain.rsp.black.RiskBlackOperationAccountInfoRsp;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.domain.entity.TRiskBlackOperationAccountDetail;
import com.riskcontrol.office.mapper.RiskBlackOperationAccountDetailMapper;
import com.riskcontrol.office.service.RiskBlackOperationAccountDetailService;
import com.riskcontrol.office.service.RiskBlackOperationDetailService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Heng.zhang
 */
@Service
@Slf4j
public class RiskBlackOperationAccountDetailServiceImpl extends BaseServiceImpl<RiskBlackOperationAccountDetailMapper, TRiskBlackOperationAccountDetail> implements RiskBlackOperationAccountDetailService {

//    @Autowired
//    private RiskBlackOperationAccountDetailMapper accountDetailMapper;
      @Autowired
      private RiskBlackOperationDetailService detailService;

//    @Override
//    public PageModel<RiskBlackOperationAccountDetailReRsp> getOperationDetailRePageList(RiskBlackOperationDetailRequest req) {
//        List<RiskBlackOperationAccountDetailReRsp> pageList=new ArrayList<>();
//        int count = accountDetailMapper.countQueryPageByLogAccountDetailList(req);
//        if (count > 0) {
//            req.setPageNum(CommonLogic.buildFirstPageParamOfMySql(req.getPageNum(), req.getPageSize()));
//            pageList = accountDetailMapper.queryPageByLogAccountDetailList(req);
//        } else {
//            return new PageModel<>();
//        }
//        PageModel<RiskBlackOperationAccountDetailReRsp> pageResult = new PageModel<>();
//        pageResult.setData(pageList);
//        pageResult.setPageNo(req.getPageNum()+1);
//        pageResult.setPageSize(req.getPageSize());
//        pageResult.setTotalRow(count);
//        Integer totalPage = count / req.getPageSize() + (count % req.getPageSize() == 0 ? 0 : 1);
//        pageResult.setTotalPage(totalPage);
//        return pageResult;
//    }

    @Override
    public List<TRiskBlackOperationAccountDetail> getAccountList(List<BigInteger> ids){
        LambdaQueryWrapper<TRiskBlackOperationAccountDetail> wrapper = new LambdaQueryWrapper<>();
        wrapper.select(TRiskBlackOperationAccountDetail::getId,
                TRiskBlackOperationAccountDetail::getLogDetailId,
                TRiskBlackOperationAccountDetail::getLoginName);
        wrapper.in(TRiskBlackOperationAccountDetail::getLogDetailId, ids);
        return list(wrapper);
    }

    @Override
    public  RiskBlackOperationAccountInfoRsp getOperationAccountReInfo(BigInteger detailId){
        LambdaQueryWrapper<TRiskBlackOperationAccountDetail> wrapper = new LambdaQueryWrapper<>();
        wrapper.select(TRiskBlackOperationAccountDetail::getLoginName);
        wrapper.eq(TRiskBlackOperationAccountDetail::getLogDetailId,detailId);
        List<TRiskBlackOperationAccountDetail> list = list(wrapper);
        if (CollUtil.isEmpty(list)) {
            return null;
        }
        var detail = detailService.getOperationDetailReInfo(detailId);
        RiskBlackOperationAccountInfoRsp accountInfoRsp = new RiskBlackOperationAccountInfoRsp();
//        accountInfoRsp.setAllName(detail.getFirstName()+","+detail.getMiddleName()+","+detail.getLastName());

        accountInfoRsp.setFirstName(detail.getFirstName());
        accountInfoRsp.setMiddleName(detail.getMiddleName());
        accountInfoRsp.setLastName(detail.getLastName());
        accountInfoRsp.setBirthday(detail.getBirthday());
        accountInfoRsp.setAssociationAccount(list.stream().map(a-> new RiskBlackOperationAccountInfoRsp.AssociationAccount(a.getLoginName())).collect(Collectors.toList()));
        return accountInfoRsp;
    }
}
