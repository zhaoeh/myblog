package com.riskcontrol.office.config;

import lombok.extern.slf4j.Slf4j;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.redisson.connection.DnsAddressResolverGroupFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Configuration
@ConditionalOnClass(RedisOperations.class)
@Slf4j
public class RedisConfig {
    @Value("${spring.redis.cluster.nodes}")
    private String redisNodes;

    @Value("${redisson.cluster.timeout}")
    private int timeout;

    @Value("${redisson.cluster.keepAlive}")
    private boolean keepAlive;

    @Value("${redisson.cluster.retryInterval}")
    private int retryInterval;

    @Value("${redisson.cluster.connectTimeout}")
    private int connectTimeout;

    @Value("${redisson.cluster.idleConnectionTimeout}")
    private int idleConnectionTimeout;

    @Value("${redisson.cluster.pingConnectionInterval}")
    private int pingConnectionInterval;

    @Value("${redisson.cluster.masterConnectionPoolSize}")
    private int masterConnectionPoolSize;

    @Value("${redisson.cluster.slaveConnectionPoolSize}")
    private int slaveConnectionPoolSize;

    @Value("${redisson.cluster.checkLockSyncedSlaves}")
    private boolean checkLockSyncedSlaves;

    @Value("${redisson.cluster.nettyThreads}")
    private int nettyThreads;

    @Value("${spring.redis.password}")
    private String password;

    @Value("${spring.redis.ssl:false}")
    private boolean sslEnable;
    @Bean(name = "riskcontrolRedisTemplate")
    @ConditionalOnMissingBean(name = "riskcontrolRedisTemplate")
    public RedisTemplate<Serializable, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<Serializable, Object> template = new RedisTemplate<Serializable, Object>();
        template.setConnectionFactory(redisConnectionFactory);
        template.setDefaultSerializer(new StringRedisSerializer());
        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(new GenericJackson2JsonRedisSerializer());
        template.setHashKeySerializer(new StringRedisSerializer());
        template.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());
        template.afterPropertiesSet();
        return template;
    }


    @Bean(name = "riskcontrolStringRedisTemplate")
    @ConditionalOnMissingBean(name = "riskcontrolStringRedisTemplate")
    public StringRedisTemplate stringRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
        StringRedisTemplate template = new StringRedisTemplate();
        template.setConnectionFactory(redisConnectionFactory);
        return template;

    }

    @Bean
    public RedissonClient redissonClient() {
        String[] nodesUrl = redisNodes.split(",");
        List<String> clusterNodes = new ArrayList<>();
        for (int i = 0; i < nodesUrl.length; i++) {
            if(sslEnable){
                clusterNodes.add("rediss://" + nodesUrl[i]); //ssl 配置
            }else{
                clusterNodes.add("redis://" + nodesUrl[i]);
            }
            log.info("redissonClient clusterNodes load nodes:{}",clusterNodes.get(i));
        }
        Config config = new Config();
        // 集群配置信息
        //  参数详解见 SLS confluence pageId=17018896
        config.useClusterServers()
                .setTimeout(timeout)
                .setKeepAlive(keepAlive) // redisTCP保活 检测死节点
                .setRetryInterval(retryInterval)
                .setConnectTimeout(connectTimeout)
                .setIdleConnectionTimeout(idleConnectionTimeout)
                .setPingConnectionInterval(pingConnectionInterval)
                .setMasterConnectionPoolSize(masterConnectionPoolSize)
                .setSlaveConnectionPoolSize(slaveConnectionPoolSize)
                .setPassword(password)
                .addNodeAddress(clusterNodes.toArray(new String[clusterNodes.size()]))
                .setSslEnableEndpointIdentification(!sslEnable);

        // 线上异常提示： Try to increase nettyThreads and/ or timeout settings
        config.setAddressResolverGroupFactory(new DnsAddressResolverGroupFactory())
                .setNettyThreads(nettyThreads)
                .setCheckLockSyncedSlaves(checkLockSyncedSlaves);

        RedissonClient redissonClient = Redisson.create(config);
        return redissonClient;
    }


}
