package com.riskcontrol.office.common.constants;

import org.wildfly.common.Branch;

/**
 * @author Herman.T
 */

public enum AccountTypeCatalog {

    BANK_CARD("Bank", "0"),
    ALIPAY_A("ALIPAY_A", "6"),
    ALIPAY_Q("ALIPAY_Q", "7"),
    BITOLL("BITOLL", "8"),
    DCBOX("DCBOX", "9"),
    ZAKZAK("ZAKZAK", "10"),
    GCASH_A("Gcash", "11"),
    PAYMAYA_A("Mayapay", "12"),

    PAYMAYA_M("Mayapay", "15"),

    GLIFE_A("Glife", "13"),

    LAZADA_A("Lazada", "14"),

    BRANCH_SHORE("Branch","99");
    private String accountType;

    private String catalog;

    public String getAccountType() {
        return accountType;
    }

    public String getCatalog() {
        return catalog;
    }

    AccountTypeCatalog(String accountType, String catalog) {
        this.accountType = accountType;
        this.catalog = catalog;
    }

    /**
     * 默认返回银行卡
     *
     * @param catalog
     * @return
     */
    public static String getByAccountType(String catalog) {
        for (AccountTypeCatalog accountCatalog : AccountTypeCatalog.values()) {
            if (accountCatalog.catalog.equalsIgnoreCase(catalog)) {
                return accountCatalog.accountType;
            }
        }
        return BANK_CARD.accountType;
    }
}
