package com.riskcontrol.office.domain.customers.req;

import com.riskcontrol.common.entity.request.BaseQueryReq;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(title = "查询玩家详细列表请求参数")
@Data
public class QueryCustomersReq extends BaseQueryReq {

    @Schema(description = "省")
    private String province;

    @Schema(description = "城市")
    private String city;

    @Schema(description = "玩家类型：Normal、PreVIP、VIP,默认Normal")
    protected String custType;

    @Schema(description = "是否开通线上投注:1开通,0未开通")
    protected String onlineBet;

    @Schema(description = "存款标识：1是0否， 13个自然周单笔存款是否达1万")
    protected String depositFlag;

    @Schema(description = "有效投注标识：1是0否， 13个自然周单周达成7万流水")
    protected String turnoverFlag;

    @Schema(description = "VIP的有效时间")
    protected String vipValidTimeStart;

    @Schema(description = "VIP的有效时间")
    protected String vipValidTimeEnd;

    @Schema(description = "玩家账号")
    private String customerName;

    @Schema(description = "注册开始时间(yyyy-MM-dd HH:mm:ss)", example = "2019-11-10 12:00:00")
    private String createdDateBegin;

    @Schema(description = "注册截止时间(yyyy-MM-dd HH:mm:ss)", example = "2019-11-11 12:00:00")
    private String createdDateEnd;

    @Schema(description = "生日", example = "")
    private String birthday;

    @Schema(description = "生日起始 yyyy-MM-dd", example = "2016-11-13")
    private String birthDateBegin;

    @Schema(description = "生日结束 yyyy-MM-dd", example = "2020-11-13")
    private String birthDateEnd;

    @Schema(description = "最後登入時間 begin", example = "")
    private String lastLoginDateBegin;

    @Schema(description = "最後登入時間 end", example = "")
    private String lastLoginDateEnd;

    @Schema(description = "電子郵箱", example = "")
    private String email;

    @Schema(description = "phone", example = "")
    private String phone;

    @Schema(description = "性別, M-男,F-女", example = "")
    private String sex;

    @Schema(description = "建立者", example = "")
    private String createdBy;

    @Schema(description = "余额 begin", example = "")
    private String balanceStart;

    @Schema(description = "余额 end", example = "")
    private String balanceEnd;

    @Schema(description = "登入次數 begin", example = "1")
    private String loginTimesStart;

    @Schema(description = "登入次數 end", example = "2")
    private String loginTimesEnd;

    @Schema(description = "玩家賬號狀態, 1=启用 0=禁用", example = "")
    private String flag;

    @Schema(description = "filterType", example = "")
    private String filterType;

    @Schema(description = "門店代碼, 多門店請用 ; 隔開")
    private String branchCode;

    @Schema(description = "currency",example="PHP")
    private String currency;

    @Schema(description = "玩家真实姓名，结合玩家注册时输入的“名字、中间名、姓氏”，全部显示在一个栏位，显示格式：名字、中间名、姓氏（John Gomez Gonzales），每个字之间以空格分开即可，有可能名就有两个字以上，字段就会较长", example = "ptest01")
    private String playerName;

    @Schema(description = "玩家唯一编号", example = "1022144331")
    private String customerId;

    @Schema(description = "是否激活：1是 0否", example = "0")
    protected String activation;

    @Schema(description ="上级",example = "acc66")
    private String parent;

    @Schema(description = "优先级",example = "1")
    private String priorityLevel;

    @Schema(description = "优先级比较符号", example = "=")
    private String priorityLevelFlag;

    @Schema(description = "kyc审核状态", example = "")
    private String firstIdStatusList;

    @Schema(description = "kyc类型", example = "")
    private String firstIdType;

    @Schema(description = "Market :01  Website :02 Store :03 ")
    private String chanelType;

    @Schema(description = "exact match :0  previous match:1 fuzzy match:2  not match:3")
    private String accountSearch;

    @Schema(description = "昵称")
    private String nickName;

    @Schema(description = "注册方式：1.username+pwd ,3.完整注册, 2.phone, 4. email, 5. google, 6.facebook")
    private Integer registerMethod;

    @Schema(description = "注册方式：1.username+pwd ,3.完整注册, 2.phone, 4. email, 5. google, 6.facebook")
    private Integer[] registerMethodArray;

    @Schema(description = "应用类型[1:web; 2:android; 3:ios; 4:h5]")
    private Integer appType;

    @Schema(description = "kyc审核状态", example = "'': All, '1': Yes except Glife users, '2': No, '3': Glife users")
    private String kycType;

    @Schema(description = "newFirstDepositStatDateEnd", example = "")
    private String newFirstDepositStatDateEnd;

    @Schema(description = "newFirstDepositStatDateBegin", example = "")
    private String newFirstDepositStatDateBegin;

    @Schema(description = "bingoplus :1  sport :2 ")
    private Integer siteId;

    @Schema(description = "域名", example = "bingoplus.com")
    public String domainNameQuery;

    @Schema(description = "FromFriend: 0 否，1 是")
    private String fromFriend;
}
