package com.riskcontrol.office.controller;

import com.cm.util.common.Constants;
import com.digiplus.oms.aspect.annotation.PreAuthorize;
import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.riskcontrol.common.client.PhoneNumberBlacklistFeign;
import com.riskcontrol.common.entity.request.api.*;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.api.PhoneCoolingDownPeriodRsp;
import com.riskcontrol.common.entity.response.api.PhoneNumberBlacklistRsp;
import com.riskcontrol.common.utils.PHPDESEncrypt;
import com.riskcontrol.office.annotation.EnableOperationLog;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.enums.OpTypeEnum;
import com.riskcontrol.office.domain.req.PhoneNumberBlacklistCreateReq;
import com.riskcontrol.office.mapper.TPhoneNumberBlacklistMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;
import java.util.Objects;

/**
 * @program: riskcontrol-api
 * @description: 手机号黑名单 前端控制器
 * @author: Colson
 * @create: 2023-09-26 14:19
 */
@RestController
@Tag(name = "手机号码黑名单")
@SecurityRequirement(name = HttpHeaders.AUTHORIZATION)
@RequestMapping("/office/phoneNumberBlacklist")
public class PhoneNumberBlacklistController {

    private final String SUCCESS_CODE = "0000";
    @Resource
    private PhoneNumberBlacklistFeign phoneNumberBlacklistFeign;

    @PreAuthorize("riskConfig_phoneBlacklist_query")
    @PostMapping("page")
    @Operation(tags ="手机号码黑名单" ,summary = "手机号码黑名单分页列表")
    public R<PageModel<PhoneNumberBlacklistRsp>> getPage(@RequestBody PhoneNumberBlacklistPageRequest request) throws Exception {
        if(request.getPhone() !=null && !"".equals(request.getPhone())){
            //md5加密
            String md5Phone =  DigestUtils.md5Hex(request.getPhone());
            request.setPhoneMd5(md5Phone);
            request.setPhone(null);
        }
        Response<PageModel<PhoneNumberBlacklistRsp>> page = phoneNumberBlacklistFeign.getPage(request);
        boolean isSuccess = SUCCESS_CODE.equals(page.getHead().getErrCode());
        if(isSuccess){
            PageModel<PhoneNumberBlacklistRsp> body = page.getBody();
            if (CollectionUtils.isNotEmpty(body.getData())){
                List<PhoneNumberBlacklistRsp> PhoneList = body.getData();
                body.setData(PhoneList);
            }
        }
        return isSuccess? R.ok(page.getBody()) : R.failed(page.getHead().getErrMsg());
    }
    @PreAuthorize("riskConfig_phoneBlacklist_query")
    @PostMapping("list")
    @Operation(tags ="手机号码黑名单" ,summary = "手机号码黑名单列表")
    public R<List<PhoneNumberBlacklistRsp>> getList(@RequestBody PhoneNumberBlacklistRequest request) throws Exception {
        if(request.getPhone() !=null && !"".equals(request.getPhone())){
            //md5加密
            String md5Phone =  DigestUtils.md5Hex(request.getPhone());
            request.setPhoneMd5(md5Phone);
            request.setPhone(null);
        }
        Response<List<PhoneNumberBlacklistRsp>> response = phoneNumberBlacklistFeign.getList(request);
        boolean isSuccess = SUCCESS_CODE.equals(response.getHead().getErrCode());
        if(isSuccess){
            List<PhoneNumberBlacklistRsp> PhoneList = response.getBody();
            PHPDESEncrypt encrypt = PHPDESEncrypt.getNewInstance(Constants.C66, "03");//03手机号加密
            for (int i=0;i<PhoneList.size();i++){
                String newPhone = encrypt.decrypt(PhoneList.get(i).getPhone());
                PhoneList.get(i).setPhone(newPhone);
            }
            response.setBody(PhoneList);
        }
        return isSuccess? R.ok(response.getBody()) : R.failed(response.getHead().getErrMsg());
    }
    @PreAuthorize("riskConfig_phoneBlacklist_create")
    @PostMapping("create")
    @Operation(tags ="手机号码黑名单" ,summary = "创建手机号码黑名单")
    @EnableOperationLog(menuName="风控配置",subMenuName="手机号码黑名单",opLog = "创建",opLogType= OpTypeEnum.CREATE,mapperClass = TPhoneNumberBlacklistMapper.class)
    public R<Boolean> create(@Valid @RequestBody PhoneNumberBlacklistCreateReq req) throws Exception {
        //md5加密
        String md5Phone =  DigestUtils.md5Hex(req.getPhone());
        req.setPhoneMd5(md5Phone);

        PHPDESEncrypt encrypt = PHPDESEncrypt.getNewInstance(Constants.C66, "03");//03手机号加密
        String enphone = encrypt.encrypt(req.getPhone());
        req.setPhone(enphone);

        PhoneNumberBlacklistCreateRequest request = new  PhoneNumberBlacklistCreateRequest();
        BeanUtils.copyProperties(req,request);
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if(!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())){
            request.setDataModifier(userInfoVO.getUserInfo().getUsername());
        }
        Response<Boolean> response = phoneNumberBlacklistFeign.create(request);
        boolean isSuccess = SUCCESS_CODE.equals(response.getHead().getErrCode());
        return isSuccess? R.ok(response.getBody()) : R.failed(response.getHead().getErrMsg());
    }

    @PreAuthorize("riskConfig_phoneBlacklist_create")
    @PostMapping("updateHistory")
    @Operation(tags ="手机号码黑名单" ,summary = "更新手机号码黑名单绑定用户ID")
    @EnableOperationLog(menuName="风控配置",subMenuName="手机号码黑名单",opLog = "修改",opLogType= OpTypeEnum.UPDATE,mapperClass = TPhoneNumberBlacklistMapper.class)
    public R<Boolean> updateHistory(@Valid @RequestBody PhoneNumberBlacklistUpdateHistoryRequest request) {
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if(!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())){
            request.setDataModifier(userInfoVO.getUserInfo().getUsername());
        }
        Response<Boolean> response = phoneNumberBlacklistFeign.updateHistory(request);
        boolean isSuccess = SUCCESS_CODE.equals(response.getHead().getErrCode());
        return isSuccess? R.ok(response.getBody()) : R.failed(response.getHead().getErrMsg());
    }

    @PreAuthorize("riskConfig_phoneBlacklist_status")
    @PostMapping("updateStatus")
    @Operation(tags ="手机号码黑名单" ,summary = "更新手机号码黑名单状态")
    @EnableOperationLog(menuName="风控配置",subMenuName="手机号码黑名单",opLog = "修改状态",opLogType= OpTypeEnum.UPDATE,mapperClass = TPhoneNumberBlacklistMapper.class)
    public R<Boolean> updateStatus(@Valid @RequestBody PhoneNumberBlacklistUpdateStatusRequest request) {
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if(!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())){
            request.setDataModifier(userInfoVO.getUserInfo().getUsername());
        }
        Response<Boolean> response = phoneNumberBlacklistFeign.updateStatus(request);
        boolean isSuccess = SUCCESS_CODE.equals(response.getHead().getErrCode());
        return isSuccess? R.ok(response.getBody()) : R.failed(response.getHead().getErrMsg());
    }
    @PreAuthorize("riskConfig_phoneBlacklist_query")
    @PostMapping("coolingDownPeriod")
    @Operation(tags ="手机号码黑名单" ,summary = "查询手机号码冷却期")
    public R<PhoneCoolingDownPeriodRsp> coolingDownPeriod(@RequestBody PhoneCoolingDownPeriodRequest request) {
        Response<PhoneCoolingDownPeriodRsp> response = phoneNumberBlacklistFeign.coolingDownPeriod(request);
        boolean isSuccess = SUCCESS_CODE.equals(response.getHead().getErrCode());
        return isSuccess? R.ok(response.getBody()) : R.failed(response.getHead().getErrMsg());
    }


}
