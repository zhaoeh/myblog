package com.riskcontrol.office.common.enums;

/**
 * 加密类型枚举
 */

public enum ENCRYPT_TYPE {

    /**
     * 加密类型 手机号
     **/
    PHONE("03", "P_", 1, 1),

    /**
     * 加密类型 地址
     **/
    ADDRESS("02", "A_", 2, 2),

    /**
     * 加密类型 邮箱
     **/
    EMAIL("04", "E_", 1, 2);

    /**
     * 枚举类型代码
     **/
    private String type;

    /**
     * 混码前置词
     */
    private String prefix;

    /**
     * 混码起始乱数
     */
    private int mixNo1;

    /**
     * 混码结数乱数
     */
    private int mixNo2;

    ENCRYPT_TYPE(String type, String prefix, int mixNo1, int mixNo2) {
        this.type = type;
        this.prefix = prefix;
        this.mixNo1 = mixNo1;
        this.mixNo2 = mixNo2;
    }

    public String getType() {
        return this.type;
    }

    public String getPrefix() {
        return this.prefix;
    }

    public int getMixNo1() {
        return this.mixNo1;
    }

    public int getMixNo2() {
        return this.mixNo2;
    }

    public static ENCRYPT_TYPE getByType(String type) {
        ENCRYPT_TYPE[] encryptTypes = ENCRYPT_TYPE.values();
        for (ENCRYPT_TYPE encryptType : encryptTypes) {
            if (encryptType.getType().equals(type)) {
                return encryptType;
            }
        }
        return null;
    }
}
