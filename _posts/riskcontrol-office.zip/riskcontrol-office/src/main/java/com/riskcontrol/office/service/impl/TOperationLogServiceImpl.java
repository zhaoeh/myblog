package com.riskcontrol.office.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.domain.entity.TOperationLog;
import com.riskcontrol.office.domain.req.OperactionLogReq;
import com.riskcontrol.office.mapper.TOperationLogMapper;
import com.riskcontrol.office.service.TOperationLogService;
import org.springframework.stereotype.Service;

@Service
public class TOperationLogServiceImpl extends BaseServiceImpl<TOperationLogMapper, TOperationLog> implements TOperationLogService {

    @Override
    public PageModel<TOperationLog> queryList(OperactionLogReq req) {
        Page<TOperationLog> page = pageByWrapper(req,buildWrapper(req));
        PageModel<TOperationLog> pageResult = new PageModel<>();
        pageResult.setData(page.getRecords());
        pageResult.setPageNo((int) page.getCurrent());
        pageResult.setPageSize((int) page.getSize());
        pageResult.setTotalRow((int) page.getTotal());
        pageResult.setTotalPage((int) page.getPages());
        return pageResult;
    }
}
