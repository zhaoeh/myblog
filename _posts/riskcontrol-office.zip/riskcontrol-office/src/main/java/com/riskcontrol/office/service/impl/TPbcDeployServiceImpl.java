package com.riskcontrol.office.service.impl;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.datasource.DBSourceCheck;
import com.riskcontrol.office.datasource.DataSourceType;
import com.riskcontrol.office.domain.entity.TPbcDeploy;
import com.riskcontrol.office.domain.req.PbcDeployReq;
import com.riskcontrol.office.mapper.TPbcDeployMapper;
import com.riskcontrol.office.service.TPbcDeployService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Objects;

@Service
public class TPbcDeployServiceImpl extends BaseServiceImpl<TPbcDeployMapper, TPbcDeploy> implements TPbcDeployService {

    @Resource
    private TPbcDeployMapper tpbcDeployMapper;
    @DBSourceCheck(DataSourceType.SLAVE)
    @Override
    public PageModel<TPbcDeploy> getPBCDeployList(PbcDeployReq req) {
        Page<TPbcDeploy> page = pageByWrapper(req, buildWrapper(req));
        page.getRecords().forEach(tPbcDeploy -> {
            if (StringUtils.isNotEmpty(tPbcDeploy.getPassword())) {
                tPbcDeploy.setPassword("********");
            }
        });
        PageModel<TPbcDeploy> pageResult = new PageModel<>();
        pageResult.setData(page.getRecords());
        pageResult.setPageNo((int) page.getCurrent());
        pageResult.setPageSize((int) page.getSize());
        pageResult.setTotalRow((int) page.getTotal());
        pageResult.setTotalPage((int) page.getPages());
        return pageResult;
    }

    @Override
    public Boolean updateDeploy(PbcDeployReq req) throws Exception {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        LocalTime startTime = LocalTime.parse(req.getStartTime(), dateTimeFormatter);
        LocalTime endTime = LocalTime.parse(req.getEndTime(), dateTimeFormatter);
        if (!startTime.isBefore(endTime)) {
            throw new Exception("Start time before end time");
        }
//        TPbcDeploy updateDeploy = new TPbcDeploy();
//        updateDeploy.setUserName(req.getUserName());
//        updateDeploy.setPassword(req.getPassword());
//        updateDeploy.setStartTime(req.getStartTime());
//        updateDeploy.setEndTime(req.getEndTime());
//        updateDeploy.setStatus(1);
//        updateDeploy.setFrequency(req.getFrequency());
//        updateDeploy.setDeleteDate(null);
//        updateDeploy.setDeleteBy(null);
//        updateDeploy.setUpdateDate(new Date());
        LambdaUpdateWrapper<TPbcDeploy> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(TPbcDeploy::getId, req.getId())
                .eq(TPbcDeploy::getSystemId, req.getSystemId())
                .set(TPbcDeploy::getUserName, req.getUserName())
                .set(TPbcDeploy::getPassword, req.getPassword())
                .set(TPbcDeploy::getStartTime, req.getStartTime())
                .set(TPbcDeploy::getEndTime, req.getEndTime())
                .set(TPbcDeploy::getStatus, 1)
                .set(TPbcDeploy::getFrequency, req.getFrequency())
                .set(TPbcDeploy::getDeleteDate, null)
                .set(TPbcDeploy::getDeleteBy, null)
                .set(TPbcDeploy::getUpdateDate, new Date())
        ;

        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            updateWrapper.set(TPbcDeploy::getUpdateBy, userInfoVO.getUserInfo().getUsername());
        }
        return tpbcDeployMapper.update(null, updateWrapper) > 0;
    }

    @Override
    public Boolean disableDeploy(PbcDeployReq tpbcDeploy) {
        LambdaUpdateWrapper<TPbcDeploy> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.eq(TPbcDeploy::getId, tpbcDeploy.getId())
                .eq(TPbcDeploy::getSystemId, tpbcDeploy.getSystemId())
                .set(TPbcDeploy::getUserName, "")
                .set(TPbcDeploy::getPassword, "")
                .set(TPbcDeploy::getStartTime, null)
                .set(TPbcDeploy::getEndTime, null)
                .set(TPbcDeploy::getStatus, 0)
                .set(TPbcDeploy::getFrequency, 15)
                .set(TPbcDeploy::getDeleteDate, new Date())
        ;
//        TPbcDeploy updateDeploy = new TPbcDeploy();
//        updateDeploy.setUserName("");
//        updateDeploy.setPassword("");
//        updateDeploy.setStartTime(null);
//        updateDeploy.setEndTime(null);
//        updateDeploy.setStatus(0);
//        updateDeploy.setFrequency(15);
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            updateWrapper.set(TPbcDeploy::getUpdateBy, userInfoVO.getUserInfo().getUsername());
        }
        return tpbcDeployMapper.update(null, updateWrapper) > 0;
    }
}
