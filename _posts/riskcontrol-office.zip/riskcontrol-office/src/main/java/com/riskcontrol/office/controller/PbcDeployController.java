package com.riskcontrol.office.controller;

import com.digiplus.oms.aspect.annotation.PreAuthorize;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.annotation.EnableOperationLog;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.entity.TPbcDeploy;
import com.riskcontrol.office.domain.enums.OpTypeEnum;
import com.riskcontrol.office.domain.req.PbcDeployReq;
import com.riskcontrol.office.domain.validation.PbcDisableReqValidator;
import com.riskcontrol.office.domain.validation.PbcUpdateReqValidator;
import com.riskcontrol.office.service.TPbcDeployService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpHeaders;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/*** @program: riskcontrol-cron
 ** @description: PBC配置文件Controller
 ** @author: hongwei
 ** @create: 2023-11-14 12:23
 **/
@RestController
@RequestMapping("/office/pbc")
@Tag(name = "PBC配置")
@SecurityRequirement(name = HttpHeaders.AUTHORIZATION)
public class PbcDeployController {

    @Resource
    private TPbcDeployService pbcDeployService;
    @PreAuthorize("riskConfig_pbcRule_query")
    @PostMapping("deploy")
    @Operation(tags ="PBC配置" ,summary = "查询pbc配置接口")
    public R<PageModel<TPbcDeploy>> getDeployList(PbcDeployReq req) {
        return R.ok(pbcDeployService.getPBCDeployList(req));
    }
    @PreAuthorize("riskConfig_pbcRule_modify")
    @PostMapping("updateDeploy")
    @Operation(tags ="PBC配置" ,summary = "修改pbc配置接口")
    //    @PreAuthorize("@pms.hasPermission('pbc_update')")
    @EnableOperationLog(menuName="风控配置",subMenuName="PBC配置",opLog = "修改",opLogType= OpTypeEnum.UPDATE)
    public R<Boolean> updateDeploy(@RequestBody @Validated(PbcUpdateReqValidator.class) PbcDeployReq req) throws Exception {
        return R.ok(pbcDeployService.updateDeploy(req));
    }
    @PreAuthorize("riskConfig_pbcRule_delete")
    @PostMapping("deleteDeploy")
    @Operation(tags ="PBC配置" ,summary = "停止pbc抓包配置接口")
    //    @PreAuthorize("@pms.hasPermission('pbc_stop')")
    @EnableOperationLog(menuName="风控配置",subMenuName="PBC配置",opLog = "禁用",opLogType= OpTypeEnum.DISABLE)
    public R<Boolean> disableDeploy(@RequestBody @Validated(PbcDisableReqValidator.class) PbcDeployReq req) {
        return R.ok(pbcDeployService.disableDeploy(req));
    }
}
