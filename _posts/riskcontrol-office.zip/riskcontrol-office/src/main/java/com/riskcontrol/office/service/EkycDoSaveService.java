package com.riskcontrol.office.service;

import com.cn.schema.customers.WSCustomers;
import com.riskcontrol.office.domain.entity.TEkyc;
import com.riskcontrol.office.domain.entity.TEkycRequest;


/**
 * @author Heng.zhang
 */
public interface EkycDoSaveService {

    boolean doSave(TEkycRequest ekycRequest);


    boolean doUpdate(TEkycRequest ekycRequest, TEkyc tEkyc, WSCustomers wsCustomers);
}
