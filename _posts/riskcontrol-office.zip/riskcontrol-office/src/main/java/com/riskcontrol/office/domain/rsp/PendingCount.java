package com.riskcontrol.office.domain.rsp;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/8/2 10:56
 */
@Data
@Schema(description="首页仪表盘-待审批数量bean")
public class PendingCount {
    @Schema(description="kyc待审批数量")
    private int kycCount;

    @Schema(description="取款待审批数量")
    private int withdrawCount;

}
