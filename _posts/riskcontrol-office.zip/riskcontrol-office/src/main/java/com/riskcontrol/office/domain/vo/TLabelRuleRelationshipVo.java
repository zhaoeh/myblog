package com.riskcontrol.office.domain.vo;

import com.riskcontrol.office.domain.entity.TLabelRuleRelationship;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
    * 标签-规则绑定表
    */
@Schema(description="标签-规则绑定表")
@Data
public class TLabelRuleRelationshipVo extends TLabelRuleRelationship {

    /**
     * 优先级
     */
    @Schema(description="优先级")
    private int priority;

}