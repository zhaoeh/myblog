package com.riskcontrol.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.domain.entity.TRiskConstants;
import com.riskcontrol.office.domain.req.RiskConstantEditReq;
import com.riskcontrol.office.domain.req.RiskConstantReq;
import com.riskcontrol.office.domain.rsp.RiskLabelDetailsRsp;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.math.BigInteger;

public interface TRiskConstantsService extends IService<TRiskConstants>{

    PageModel<TRiskConstants> queryConstantList(@RequestBody RiskConstantReq req);
    boolean create(RiskConstantEditReq req);
    boolean updateById(RiskConstantEditReq req);
    boolean deleteById(BigInteger id);

    List<RiskLabelDetailsRsp> queryConstantByType(String type);
    List<RiskLabelDetailsRsp> queryConstantById(List<Integer> id);
}
