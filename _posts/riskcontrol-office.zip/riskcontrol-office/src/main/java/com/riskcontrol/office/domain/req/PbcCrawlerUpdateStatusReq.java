package com.riskcontrol.office.domain.req;

import com.riskcontrol.common.annotation.EnumValid;
import com.riskcontrol.common.entity.request.BasePageRequest;
import com.riskcontrol.common.enums.PbcBannedEnum;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.hibernate.validator.constraints.Range;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;

@Data
@Schema(description = "PBC数据请求对象")
public class PbcCrawlerUpdateStatusReq extends BasePageRequest {

    @Schema(description = "主键id", example = "1")
    @NotNull(message = "id cannot be null")
    protected BigInteger id;

    @Schema(description = "禁用状态. 0:解除, 1:禁用）")
    @NotNull(message = "isBanned cannot be null")
    @EnumValid(enumClass = PbcBannedEnum.class, deduplicateEnumField = true, enumField = "id", message = "banned must belong to {target}")
    protected Integer isBanned;

}
