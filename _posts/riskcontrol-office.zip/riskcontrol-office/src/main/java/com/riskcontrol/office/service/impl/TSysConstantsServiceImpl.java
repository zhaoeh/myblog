package com.riskcontrol.office.service.impl;

import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.domain.entity.TSysConstants;
import com.riskcontrol.office.domain.req.SysConstantReq;
import com.riskcontrol.office.mapper.TSysConstantsMapper;
import com.riskcontrol.office.service.TSysConstantsService;
import com.riskcontrol.office.util.RedisUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class TSysConstantsServiceImpl extends BaseServiceImpl<TSysConstantsMapper, TSysConstants> implements TSysConstantsService {

    @Resource
    protected RedisUtils redisUtils;

    @Override
    public PageModel<TSysConstants> queryConstantList(SysConstantReq req) {
        LambdaQueryWrapper<TSysConstants> wrapper = buildWrapper(req);
        wrapper.eq(TSysConstants::getIsDeleted, 0);
        Page<TSysConstants> page = pageByWrapper(req, wrapper);
        PageModel<TSysConstants> pageResult = new PageModel<>();
        pageResult.setData(page.getRecords());
        pageResult.setPageNo((int) page.getCurrent());
        pageResult.setPageSize((int) page.getSize());
        pageResult.setTotalRow((int) page.getTotal());
        pageResult.setTotalPage((int) page.getPages());
        return pageResult;
    }

    @Override
    public boolean create(SysConstantReq req) {
        TSysConstants entity = JSONObject.parseObject(JSONObject.toJSONString(req), TSysConstants.class);
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            entity.setCreateBy(userInfoVO.getUserInfo().getUsername());
            entity.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        boolean bool = this.save(entity);
        SysConstantReq newReq = new SysConstantReq();
        newReq.setSType(req.getSType());
        refreshSysConstant(newReq);
        return bool;
    }

    @Override
    public boolean updateById(SysConstantReq req) {
        TSysConstants entity = JSONObject.parseObject(JSONObject.toJSONString(req), TSysConstants.class);
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            entity.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        boolean bool = this.updateById(entity);
        TSysConstants sysConstants = this.getById(req.getId());
        if (ObjectUtil.isNotEmpty(sysConstants)) {
            RedisUtils.remove(sysConstants.getSType());
            SysConstantReq newReq = new SysConstantReq();
            newReq.setSType(sysConstants.getSType());
            refreshSysConstant(newReq);
        }
        return bool;
    }

    @Override
    public boolean deleteById(BigInteger id) {
        TSysConstants entity = new TSysConstants();
        entity.setId(id);
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            entity.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        entity.setIsDeleted(1);
        boolean bool = this.updateById(entity);
        TSysConstants sysConstants = this.getById(id);
        if (ObjectUtil.isNotEmpty(sysConstants)) {
            RedisUtils.remove(sysConstants.getSType());
            SysConstantReq newReq = new SysConstantReq();
            newReq.setSType(sysConstants.getSType());
            refreshSysConstant(newReq);
        }
        return bool;
    }


    @Override
    public void refreshSysConstant(SysConstantReq req) {
        LambdaQueryWrapper<TSysConstants> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(TSysConstants::getIsDeleted, Constant.ZERO);
        wrapper.eq(TSysConstants::getIsEnable, Constant.ONE);
        wrapper.eq(StringUtils.isNotBlank(req.getSKey()), TSysConstants::getSKey, req.getSKey());
        wrapper.eq(StringUtils.isNotBlank(req.getSType()), TSysConstants::getSType, req.getSType());
        List<TSysConstants> list = list(wrapper);
        Map<String, Map<String, String>> groupMap = list.stream()
                .collect(Collectors.groupingBy(TSysConstants::getSType,
                        Collectors.toMap(TSysConstants::getSKey, TSysConstants::getSValue)));
        groupMap.forEach(RedisUtils::setHashMap);
    }

    @Override
    public List<Map<String, String>> queryConstantListByType(String type) {
        Map entries = redisUtils.entries(type);
        List<Map<String, String>> result = new ArrayList<>();
        entries.forEach((key,value)->{
            Map<String, String> entity = new HashMap<>();
            entity.put("key", (String) key);
            entity.put("value", (String) value);
            result.add(entity);
        });
        return result;
    }

}
