package com.riskcontrol.office.domain.req;

import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.entity.request.BasePageRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigInteger;

@Data
@ApiModel(value = "风控标签操作日志明细分页查询请求对象", description = "风控标签操作日志明细分页查询参数")
public class RiskLabelOperationDetailPageRequest extends BasePageRequest {

    @ApiModelProperty(value = "logId", required = true)
    @Query(field = "logId")
    @NotNull(message = "id cannot be null")
    private BigInteger id;

    @ApiModelProperty(value = "operationStatus", example = "1")
    @Query(field = "operationStatus")
    private Integer status;

}