package com.riskcontrol.office.domain.rsp.black;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigInteger;


/**
 * @author Heng.zhang
 */
@ApiModel(value = "风控黑名单操作记录明细响应对象", description = "风控黑名单")
@Data
public class RiskBlackOperationDetailReRsp {

    @ApiModelProperty("ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    @ApiModelProperty(value = "操作日志主表id")
    private String blackId;

    @ApiModelProperty(value = "名")
    private String firstName;

    @ApiModelProperty(value = "中间名")
    private String middleName;

    @ApiModelProperty(value = "姓")
    private String lastName;

//    @ApiModelProperty(value = "全名")
//    private String allName;

    @ApiModelProperty(value = "生日")
    private String birthday;

    @ApiModelProperty(value = "操作的成功失败状态 1：成功 0：失败")
    private String operationStatus;

    @ApiModelProperty(value = "关联账户的个数")
    private String totalNo;

}