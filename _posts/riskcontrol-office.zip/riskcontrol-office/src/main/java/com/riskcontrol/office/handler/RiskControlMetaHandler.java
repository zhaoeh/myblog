package com.riskcontrol.office.handler;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import com.riskcontrol.common.utils.DateUtils;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * @program: riskcontrol-cron
 * @description: mybatis-plus 自动填充
 * @author: Colson
 * @create: 2023-09-27 15:14
 */
@Component
public class RiskControlMetaHandler implements MetaObjectHandler {

    @Override
    public void insertFill(MetaObject metaObject) {
        null2Empty(metaObject);
        // 插入操作时，自动填充字段的值
        this.setFieldValByName("createDate",  DateUtils.getCurrentDateTime(), metaObject);
        this.setFieldValByName("updateDate",  DateUtils.getCurrentDateTime(), metaObject);
    }

    @Override
    public void updateFill(MetaObject metaObject) {
        this.setFieldValByName("finishDate", DateUtils.getCurrentDateTime(), metaObject);
        this.setFieldValByName("updateDate", DateUtils.getCurrentDateTime(), metaObject);
        this.setFieldValByName("lastUpdateTime", DateUtils.getCurrentDateTime(), metaObject);
    }

    /**
     * null值转空串*
     *
     * @param metaObject
     */
    private void null2Empty(MetaObject metaObject) {
        for (String fieldName : metaObject.getGetterNames()) {
            Object value = this.getFieldValByName(fieldName, metaObject);
            if (Objects.isNull(value) && metaObject.hasSetter(fieldName) && metaObject.getGetterType(fieldName) == String.class) {
                this.setFieldValByName(fieldName, "", metaObject);
            }
        }
    }
}
