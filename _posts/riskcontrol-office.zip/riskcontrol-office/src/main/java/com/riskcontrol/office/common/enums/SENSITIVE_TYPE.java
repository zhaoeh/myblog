package com.riskcontrol.office.common.enums;


import com.riskcontrol.office.util.EncryptUtil;

/**
 * 敏感信息类型枚举
 * Created by WADE on 2017/9/12 .
 */
public enum SENSITIVE_TYPE {

    /** 电话号码 */
    PHONE_NO("2", "HIDE_PHONENO_TYPE", EncryptUtil.HIDE_PLACEHOLDER+EncryptUtil.HIDE_PLACEHOLDER+EncryptUtil.HIDE_PLACEHOLDER+EncryptUtil.HIDE_CHAR+EncryptUtil.HIDE_PLACEHOLDER),

    /** 邮箱 */
    EMAIL("4", "HIDE_EMAIL_TYPE", EncryptUtil.HIDE_PLACEHOLDER+EncryptUtil.HIDE_CHAR+EncryptUtil.HIDE_PLACEHOLDER),

    /** Messenger/Viber */
    MSG_VIBER("8", "HIDE_MSG_VIBER_TYPE", EncryptUtil.HIDE_PLACEHOLDER+EncryptUtil.HIDE_CHAR+EncryptUtil.HIDE_PLACEHOLDER)
    ;


    private String code;
    private String constantsName;
    private String defaultHideType;

    SENSITIVE_TYPE(String code, String constantsName, String defaultHideType) {
        this.code = code;
        this.constantsName = constantsName;
        this.defaultHideType = defaultHideType;
    }

    public static SENSITIVE_TYPE getConstantsNameByCode(String code) {
        for (SENSITIVE_TYPE sensitiveType : SENSITIVE_TYPE.values()) {
            if (sensitiveType.getCode().equals(code)) {
                return sensitiveType;
            }
        }
        return null;
    }

    public String getCode(){
        return this.code;
    }

    public String getConstantsName() {
        return constantsName;
    }

    public String getDefaultHideType() {
        return defaultHideType;
    }
}
