package com.riskcontrol.office.domain.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.math.BigInteger;

@Data
@Schema(description = "白名单编辑请求对象")
public class WhiteListEditReq {
    @Schema(description = "白名单主键")
    @JsonProperty("id")
    private BigInteger id;

    @Schema(description = "规则校验类型（0：ip ; 1：设备指纹；）")
    @JsonProperty("allowType")
    private Integer allowType;

    @Schema(description = "名单规则（0：白名单；1：黑名单）")
    @JsonProperty("allowRule")
    private Integer allowRule;


    @Schema(description = "ip")
    @JsonProperty("allowRecord")
    @NotBlank(message = "IP地址不能为空")
    @Pattern(regexp = "^(?:[0-9]{1,3}\\.){3}[0-9]{1,3}$", message = "IP地址格式不正确或包含多条IP地址")
    private String allowRecord;

    @Schema(description = "备注")
    private String remark;

}