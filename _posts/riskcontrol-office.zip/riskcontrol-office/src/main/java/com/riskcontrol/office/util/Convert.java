package com.riskcontrol.office.util;


import org.apache.commons.lang3.StringUtils;

import java.security.MessageDigest;

public class Convert {

	private final static char[] hexDigits = {'0', '1', '2', '3', '4', '5','6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

	/**
	 * 转换字节数组为16进制字串
	 * @param byteArray 字节数组
	 * @return 16进制字串
	 */
	private static String byteArrayToHexString(byte[] byteArray) {
		char[] resultCharArray =new char[byteArray.length * 2];
		int index = 0;
		for (byte b : byteArray) {
			resultCharArray[index++] = hexDigits[b>>>4 & 0xf];
			resultCharArray[index++] = hexDigits[b & 0xf];
		}
		return new String(resultCharArray);
	}

	/**
	 * 标准Md5 加密方法
	 * @param origin 需要加密的字符串
	 * @return
	 */
	public static String md5Hex(String origin) {
		if(StringUtils.isBlank(origin)){
			return null;
		}
		String resultString = null;
		try {
			resultString = origin;
			MessageDigest md = MessageDigest.getInstance("MD5");
			resultString = byteArrayToHexString(md.digest(resultString.getBytes()));
		} catch (Exception ex) {
			//logger.error(ErrCodeEnum.MSG_100007.getErrMsg(),ex);
		}
		return resultString;
	}

	public static String md5Cols(String content) {
		if (StringUtils.isBlank(content)) {
			//字符串为空的时候MD5也会有值，所以当为null 或者为 ""的时候直接返回null
			return null;
		} else {
			//有些是前端传入的数据，需要trim
			return md5Hex(content.trim());
		}
    }

}
