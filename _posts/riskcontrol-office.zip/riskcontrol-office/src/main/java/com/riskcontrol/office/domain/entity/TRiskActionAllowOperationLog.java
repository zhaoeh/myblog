package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigInteger;

/**
 * @author Heng.zhang
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_risk_action_allow_operation_log")
@ApiModel(description = "风控行为 黑/白 名单配置历史操作记录表")
public class TRiskActionAllowOperationLog  extends BaseEntity {

    /** 主键 */
    @ApiModelProperty("ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    /** 类容（IP或者设备指纹 字符串） */
    @ApiModelProperty(value = "类容（IP或者设备指纹 字符串）")
    private String allowRecord;

    /** 名单类型（0:ip ; 1:设备指纹） */
    @ApiModelProperty(value = "名单类型（0:ip ; 1:设备指纹）")
    private Integer allowType;

    /** 名单规则（0：白名单；1：黑名单） */
    @ApiModelProperty(value = "名单规则（0：白名单；1：黑名单）")
    private Integer allowRule;

    /** 是否启用（0：启用；1：禁用） */
    @ApiModelProperty(value = "是否启用（0：启用；1：禁用）")
    private Integer isEnable;

    /** 状态 1:执行完成 2:执行失败 */
    @ApiModelProperty(value = "状态 1:执行完成 2:执行失败")
    private Integer status;

    /** 操作人*/
    @ApiModelProperty(value = "操作人")
    private Integer operator;

    /** 创建时间 */
    @ApiModelProperty(value = "创建时间")
    private String createDate;

    /** 备注 */
    @ApiModelProperty(value = "备注")
    private String remark;
}
