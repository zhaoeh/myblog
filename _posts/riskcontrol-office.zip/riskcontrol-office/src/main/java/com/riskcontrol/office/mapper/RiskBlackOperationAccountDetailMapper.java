package com.riskcontrol.office.mapper;


import com.riskcontrol.office.domain.entity.TRiskBlackOperationAccountDetail;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author Heng.zhang
 */
@Mapper
public interface RiskBlackOperationAccountDetailMapper extends BaseMapperX<TRiskBlackOperationAccountDetail> {

}
