package com.riskcontrol.office.mapper;

import com.riskcontrol.office.domain.entity.TRiskActionRegistration;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author Heng.zhang
 */
@Mapper
public interface RiskActionRegistrationMapper extends BaseMapperX<TRiskActionRegistration> {
}