package com.riskcontrol.office.domain.rsp.ekyc;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

/**
 * @description: ekyc查询用户状态响应
 * @author: ErHu.Zhao
 * @create: 2024-10-07
 **/
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class EkycQueryResponse {

    @ApiModelProperty("ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    @ApiModelProperty(value = "账号")
    private String loginName;

    @ApiModelProperty(value = "渠道")
    private String channel;

    @ApiModelProperty(value = "注册时间")
    private String createDate;

    @ApiModelProperty(value = "产品")
    private String tenant;

    @ApiModelProperty(value = "首名")
    private String firstName;

    @ApiModelProperty(value = "中间名")
    private String middleName;

    @ApiModelProperty(value = "尾名")
    private String lastName;

    @ApiModelProperty(value = "性别")
    private String sex;

    @ApiModelProperty(value = "现居地址")
    private String presentAddress;

    @ApiModelProperty(value = "出生地")
    private String birthPlace;

    @ApiModelProperty(value = "常住地（永久居住地）")
    private String address;

    @ApiModelProperty(value = "生日")
    private String birthday;

    @ApiModelProperty(value = "证件类型")
    private Integer idType;

    @ApiModelProperty(value = "证件ID")
    private String idNo;

    @ApiModelProperty(value = "eKYC状态 -1待提交 0 待审核，1 通过，2 拒绝，3手动拒绝")
    private Integer status;

    @ApiModelProperty(value = "更新时间")
    private String updateDate;

    @ApiModelProperty(value = "更新人")
    private String updateBy;

}
