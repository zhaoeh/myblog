package com.riskcontrol.office.template;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.cn.schema.customers.*;
import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.riskcontrol.common.client.CronFeign;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.pojo.TPbcCrawlerResultNew;
import com.riskcontrol.common.entity.request.PbcCrawlerUpdateStatusReq;
import com.riskcontrol.common.entity.request.QueryPageByKycRequestId;
import com.riskcontrol.common.entity.request.api.QueryRiskConstants;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequest;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequestRequest;
import com.riskcontrol.common.entity.request.kyc.RiskUpdateKycRequestRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelBindingRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelByCustomerIdRequest;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.api.RiskConstantsRsp;
import com.riskcontrol.common.entity.response.kyc.RiskQueryKycRequestResponse;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelRsp;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.helper.ResponseHelper;
import com.riskcontrol.office.common.constants.ConstantVars;
import com.riskcontrol.office.common.enums.ErrorCodeEnum;
import com.riskcontrol.office.common.exceptions.BizException;
import com.riskcontrol.office.config.WsProductConfig;
import com.riskcontrol.office.domain.constans.req.UpdateCustomerRiskLabelReq;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.oxm.UncategorizedMappingException;
import org.springframework.stereotype.Component;
import org.springframework.ws.client.WebServiceIOException;

import javax.annotation.Resource;
import java.util.*;

/**
 * @program: gateway-api20230622
 * @description: 封装调用risk api service的模板类
 * @author: Erhu.Zhao
 * @create: 2023-10-31 11:03
 */
@Slf4j
@Component
public class RiskControlApiTemplate {
    @Resource
    private WsProductConfig wsWsProductConfig;
    @Resource
    private CronFeign cronFeign;
    public static final String WS_RESPONSE_DELIMITER = "^";


    public String queryWithdrawalInfoByRequestId(String requestId, String productId) {
        try {
            Response<String> response = cronFeign.queryWithdrawInfoByRequestId(requestId, productId);
            log.info("[queryWithdrawalInfoByRequestId method] response is {}", response);
            return ResponseHelper.pullData(response);
        } catch (Exception ex) {
            log.error("调用riskControl接口异常，queryRiskLabelByCustomerId 错误", ex);
        }
        return null;
    }

    public List<RiskConstantsRsp> queryRiskLabelConstants() {
        try {
            Response<List<RiskConstantsRsp>> response = cronFeign.queryRiskConstantsList(new QueryRiskConstants());
            log.info("[queryRiskConstantsList method] response is {}", JSONObject.toJSONString(response));
            return ResponseHelper.pullData(response);
        } catch (Exception ex) {
            log.error("调用riskControl接口异常，queryRiskLabelConstants 错误", ex);
        }
        return new ArrayList<>(0);
    }

    public CustomerRiskLabelRsp queryRiskLabelByCustomerId(String customerId) {
        try {
            RiskLabelByCustomerIdRequest request = new RiskLabelByCustomerIdRequest();
            request.setCustomerId(Long.parseLong(customerId));
            Response<CustomerRiskLabelRsp> response = cronFeign.getRiskLabelDetail(request);
            log.info("[getRiskLabelDetail method] response is {}", JSONObject.toJSONString(response));
            return ResponseHelper.pullData(response);
        } catch (Exception ex) {
            log.error("调用riskControl接口异常，queryRiskLabelByCustomerId 错误", ex);
        }
        return new CustomerRiskLabelRsp();
    }

    public Boolean updateCustomerRiskLabel(UpdateCustomerRiskLabelReq req) {
        try {
            RiskLabelBindingRequest request = new RiskLabelBindingRequest();
            request.setCustomerId(Long.parseLong(req.getCustomerId()));
            request.setLoginName(req.getCustomerName());
            UserInfoVO userInfoVO = CurrentUserUtil.get();
            if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
                request.setOperator(userInfoVO.getUserInfo().getUsername());
            }
//            request.setOperator(req.getOperator());
            request.setProductId(req.getProductId());
            request.setRemarks(req.getRemarks());
            request.setRiskLabelIds(req.getRiskLabelIds());
            Response<Boolean> response = cronFeign.bindingCustomerRiskLabel(request);
            log.info("[bindingCustomerRiskLabel method] response is {}", JSONObject.toJSONString(response));
            return ResponseHelper.pullData(response);
        } catch (Exception ex) {
            log.error("调用riskControl接口异常，updateCustomerRiskLabel 错误", ex);
        }
        return false;
    }

    public RiskQueryKycRequestResponse queryKycRequestRisk(RiskQueryKycRequest query, String productId) {
        try {
            RiskQueryKycRequestRequest request = buildRiskKycQueryParams(query, productId);
            log.info("请求风控系统queryKycRequest request={}", JSON.toJSONString(request));
            return ResponseHelper.pullData(cronFeign.queryKycRequest(request));
        } catch (Exception ex) {
            log.error("调用Risk API接口异常，QueryKycRequest 错误", ex);
            throw buildBizException(ex);
        }
    }

    @NotNull
    private RiskQueryKycRequestRequest buildRiskKycQueryParams(RiskQueryKycRequest query, String productId) {
        RiskQueryKycRequestRequest request = new RiskQueryKycRequestRequest();
        request.setInfProductId(productId);
        request.setInfPwd(wsWsProductConfig.getWsProductPwd());
        request.setParams(query);
        request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
        return request;
    }

    public QueryKycRequestProcessLogResponse queryPageByKycRequestId(QueryPageByKycRequestId queryPageByKycRequestId) {
        try {
            UpdateKycRequestRequest request = new UpdateKycRequestRequest();
            request.setInfProductId(queryPageByKycRequestId.getProductId());
            request.setInfPwd(wsWsProductConfig.getWsProductPwd());
            WSKycRequest wsKycRequest = new WSKycRequest();
            wsKycRequest.setId(queryPageByKycRequestId.getId());
            request.setWsKycRequest(wsKycRequest);
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
            return ResponseHelper.pullData(cronFeign.queryPageByKycRequestId(request));
        } catch (Exception ex) {
            log.error("调用CRON接口异常，queryPageByKycRequestId 错误", ex);
            throw buildBizException(ex);
        }
    }

    /**
     * 查询符合条件的kyc数量
     *
     * @param query     WSQueryKycRequest
     * @param productId productId
     * @return 符合条件的kyc数量
     */
    public int countKycRequest(RiskQueryKycRequest query, String productId) {
        try {
            RiskQueryKycRequestRequest request = buildRiskKycQueryParams(query, productId);
            log.info("countKycRequest request={}", JSON.toJSONString(request));
            int count = ResponseHelper.pullData(cronFeign.countKycRequest(request)).getCount();
            log.info("countKycRequest response={}", count);
            return count;
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，QueryKycRequest 错误", ResultEnum.CRON_EXCEPTION);
        }
    }

    public ModifyKycRequestResponse pbcDispatch(KycRequest cid, String productId) {
        try {
            RiskUpdateKycRequestRequest request = new RiskUpdateKycRequestRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsWsProductConfig.getWsProductPwd());
            request.setWsKycRequest(cid);
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
            log.info("pbcDispatch request={}", JSON.toJSONString(request));
            ModifyKycRequestResponse response = ResponseHelper.pullData(cronFeign.pbcDispatch(request));
            log.info("pbcDispatch response={}", JSON.toJSONString(response));
            return response;
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，pbcDispatch 错误", ResultEnum.CRON_EXCEPTION);
        }
    }

    public int countKycPbcRequest(RiskQueryKycRequest query, String productId) {
        try {

            RiskQueryKycRequestRequest request = buildRiskKycQueryParams(query, productId);
            return ResponseHelper.pullData(cronFeign.countKycPbcRequest(request)).getCount();

        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，/customers/kyc_request/countKycPbcRequest 错误", ResultEnum.CRON_EXCEPTION);
        }
    }

    public RiskQueryKycRequestResponse queryKycPbcRequest(RiskQueryKycRequest query, String productId) {
        try {
            RiskQueryKycRequestRequest request = buildRiskKycQueryParams(query, productId);

            RiskQueryKycRequestResponse response = ResponseHelper.pullData(cronFeign.queryKycPbcRequest(request));
            return response;
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，queryKycPbcRequest 错误", ResultEnum.CRON_EXCEPTION);
        }

    }

    public ModifyKycRequestResponse pbcModifyStatus(KycRequest cid, String productId) {
        try {
            RiskUpdateKycRequestRequest request = new RiskUpdateKycRequestRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsWsProductConfig.getWsProductPwd());
            request.setWsKycRequest(cid);
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
            return ResponseHelper.pullData(cronFeign.pbcModifyStatus(request));
        } catch (Exception ex) {
            log.error("调用cron接口异常，updateKycRequest 错误", ex);
            throw buildBizException(ex);
        }
    }

    public ModifyKycRequestResponse updateKycRequest(KycRequest wsKycRequest, String productId) {
        try {
            RiskUpdateKycRequestRequest request = new RiskUpdateKycRequestRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsWsProductConfig.getWsProductPwd());
            request.setWsKycRequest(wsKycRequest);
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
            return ResponseHelper.pullData(cronFeign.updateKycRequest(request));
        } catch (Exception ex) {
            log.error("调用cron接口异常，updateKycRequest 错误", ex);
            throw buildBizException(ex);
        }
    }


    public BatchModifyPbcRequestResponse bactchModifyPbcStatus(List<WSKycSheetRequest> kycSheetList, String productId, String operator) {
        try {
            BatchUpdateKycRequestRequest request = new BatchUpdateKycRequestRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsWsProductConfig.getWsProductPwd());
            request.setWsKycSheetRequestList(kycSheetList);
            request.setOperator(operator);
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
            return ResponseHelper.pullData(cronFeign.bactchModifyPbcStatus(request));
        } catch (Exception ex) {
            throw buildBizException(ex);
        }
    }

    /**
     * 根据全名查询pagcor数据，并写入pbc爬虫数据表.
     *
     * @param fullName
     * @return
     */
    public List<TPbcCrawlerResultNew> pullPagcorDataToDbByFullName(String fullName) {
        var username = Optional.ofNullable(CurrentUserUtil.get())
                .map(s -> s.getUserInfo())
                .filter(s -> !Objects.isNull(s))
                .map(s -> s.getUsername())
                .orElse("");
        var pbcCrawlerList = cronFeign.pullPagcorDataToDbByFullName(fullName, username);
        if (pbcCrawlerList.success()) {
            return pbcCrawlerList.getBody();
        }
        throw new BusinessException(pbcCrawlerList.getHead().getErrMsg(), pbcCrawlerList.getHead().getErrCode());
    }

    public void updateStatusOfTPbcCrawlerResultNew(PbcCrawlerUpdateStatusReq pbcCrawlerUpdateStatusReq) {
        var result = cronFeign.updateStatusOfTPbcCrawlerResultNew(pbcCrawlerUpdateStatusReq);
        if (result.success()) {
            return;
        }
        throw new BusinessException(result.getHead().getErrMsg(), result.getHead().getErrCode());
    }

    private BizException buildBizException(String x) {
        if (x.contains(WS_RESPONSE_DELIMITER)) {
            return new BizException(x);
        } else {
            return new BizException(ErrorCodeEnum.ERROR_WS.getErrCode() + "^Business System Error[W]^" + x);
        }
    }

    /**
     * 将WS调用返回的异常封装为业务异常
     *
     * @param e WS异常，其message格式为 <b>CODE^英文描述信息^中文描述信息</b>
     * @return
     */
    private BizException buildBizException(Exception e) {
        if (e instanceof WebServiceIOException) {
            return buildConectionException();
        }
        if (e instanceof UncategorizedMappingException) {
            return buildParamsMapException();
        }
        String originErrMessage = e.getMessage();
        String errCode, message;
        if (StringUtils.contains(originErrMessage, WS_RESPONSE_DELIMITER)) {
            String[] splits = originErrMessage.split("\\" + WS_RESPONSE_DELIMITER);
            if (splits.length < 3) { //WS返回的错误信息不符合格式
                errCode = ErrorCodeEnum.ERROR_WS.getErrCode();
                message = originErrMessage;
            } else {
                errCode = ConstantVars.CODE_PREFIX_WS + splits[0];
                message = splits[1] + WS_RESPONSE_DELIMITER + splits[2]; //只返回中文描述信息
            }

        } else if (e instanceof BizException) {

            return (BizException) e;

        } else if (StringUtils.isNotBlank(originErrMessage)) {
            //为了兼容目前ws返回的错误消息没有^分隔符导致前端捕捉不到错误码的情况
            errCode = "99985";
            message = originErrMessage;
        } else {
            errCode = ErrorCodeEnum.ERROR_WS.getErrCode();
            message = ErrorCodeEnum.ERROR_WS.getErrMsg();
        }
        return new BizException(errCode, message, e);
    }

    private BizException buildConectionException() {
        return new BizException(ErrorCodeEnum.ERROR_WS.getErrCode(), "^Server Connect Error[W]^");
    }

    private BizException buildParamsMapException() {
        return new BizException(ErrorCodeEnum.ERROR_WS.getErrCode(), "^Params Map System Error[W]^");
    }
}