package com.riskcontrol.office.aspect;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.nacos.common.utils.ArrayUtils;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.container.HeaderContext;
import com.riskcontrol.common.container.HeaderContextHolder;
import com.riskcontrol.common.utils.LogUtils;
import javassist.*;
import javassist.bytecode.CodeAttribute;
import javassist.bytecode.LocalVariableAttribute;
import javassist.bytecode.MethodInfo;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;


/**
 * @Description: 用来在日志中输出接口入参和出参
 * @Auther: yannis
 * @create: 2023-09-27
 */
@Slf4j
@Aspect
@Component
public class LoggerAspect {
    /**
     * 拦截所有controller包下的方法
     */
    @Pointcut("execution(* com.riskcontrol.office.controller.*.*(..))")
    private void controllerMethod() {
    }


    /**
     * 日志打印
     *
     * @param point
     * @return
     * @throws Throwable
     */
    @Around("controllerMethod()")
    public Object doAround(ProceedingJoinPoint point) throws Throwable {
        preHandleUUID();
//        String msgInfo = "@aop["+point.getSignature().getDeclaringTypeName()+"."+point.getSignature().getName()+"]"; // 所在的类.方法
        String requestStr = getRequestParam(point);
        requestStr = parameterHandle(requestStr, 10000);

        ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = requestAttributes.getRequest();
        String requestIP = getRequestIP(request);
        String path = request.getServletPath();

        log.info("[web_server_start][ip]:{} [method]:{} [path]:{} [params]:{}", requestIP, request.getMethod(), path, requestStr);

        long startTime = System.currentTimeMillis();// 开始时间
        Object result = null;
        try {
            // 执行完方法的返回值
            result = point.proceed();
        } catch (Exception e) {
            throw e;
        } finally {
            long handleTime = System.currentTimeMillis() - startTime;// 耗时
            String responseStr = result == null ? "无" : JSON.toJSONString(result);
            responseStr = parameterHandle(responseStr, 10000);

            log.info("[web_server_end][ip]:{} [method]:{} [path]:{} [time]:{} [response]:{}", requestIP, request.getMethod(), path, handleTime + "ms", responseStr);
        }
        return result;
    }

    /**
     * 参数处理，超过指定长度字符的，只显示1000...
     *
     * @param paramStr
     * @param strlength
     * @return
     */
    private String parameterHandle(String paramStr, int strlength) {
        if (paramStr.length() > strlength) {
            paramStr = paramStr.substring(0, 1000) + "...";
        }
        if (paramStr.length() > 10) {
            paramStr = "[" + paramStr + "]";
        }
        return paramStr;
    }

    /**
     * 获取请求参数
     *
     * @param point
     * @return
     */
    private String getRequestParam(ProceedingJoinPoint point) {
        String class_name = point.getTarget().getClass().getName();
        String method_name = point.getSignature().getName();
        /**
         * 获取方法的参数值数组。
         */
        Object[] methodArgs = point.getArgs();

        String[] paramNames = null;
        // 结果
        String requestStr = "";
        /**
         * 获取方法参数名称
         */
        try {
            paramNames = getFieldsName(class_name, method_name);
            requestStr = logParam(paramNames, methodArgs);
        } catch (Exception e) {
            requestStr = "获取参数失败";
        }
        return requestStr;
    }

    /**
     * 使用javassist来获取方法参数名称
     *
     * @param class_name  类名
     * @param method_name 方法名
     * @return
     * @throws Exception
     */
    private String[] getFieldsName(String class_name, String method_name) throws Exception {
        Class<?> clazz = Class.forName(class_name);
        String clazz_name = clazz.getName();
        ClassPool pool = ClassPool.getDefault();
        CtClass ctClass = pool.getOrNull(class_name);
        if(null == ctClass){//内存泄露优化，减少每次执行都new对象 insert
            ClassClassPath classPath = new ClassClassPath(clazz);
            pool.insertClassPath(classPath);
            ctClass = pool.get(clazz_name);
        }
        CtMethod ctMethod = ctClass.getDeclaredMethod(method_name);
        MethodInfo methodInfo = ctMethod.getMethodInfo();
        CodeAttribute codeAttribute = methodInfo.getCodeAttribute();
        LocalVariableAttribute attr = (LocalVariableAttribute) codeAttribute.getAttribute(LocalVariableAttribute.tag);
        if (attr == null) {
            return null;
        }
        String[] paramsArgsName = new String[ctMethod.getParameterTypes().length];
        int pos = Modifier.isStatic(ctMethod.getModifiers()) ? 0 : 1;
        for (int i = 0; i < paramsArgsName.length; i++) {
            paramsArgsName[i] = attr.variableName(i + pos);
        }
        return paramsArgsName;
    }

    /**
     * 判断是否为基本类型：包括String
     *
     * @param clazz clazz
     * @return true：是;     false：不是
     */
    private boolean isPrimite(Class<?> clazz) {
        return clazz.isPrimitive() || clazz == String.class;
    }


    /**
     * 打印方法参数值  基本类型直接打印，非基本类型需要重写toString方法
     *
     * @param paramsArgsName  方法参数名数组
     * @param paramsArgsValue 方法参数值数组
     */
    private String logParam(String[] paramsArgsName, Object[] paramsArgsValue) {
        if (ArrayUtils.isEmpty(paramsArgsName) || ArrayUtils.isEmpty(paramsArgsValue)) {
            return "";
        }
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < paramsArgsValue.length; i++) {
            //参数名
            String name = paramsArgsName[i];
            //参数值
            Object value = paramsArgsValue[i];
            buffer.append(name + " = ");
            if (isPrimite(value.getClass())) {
                buffer.append(value + "  ,");
            } else {
                buffer.append(JSONObject.toJSONString(value) + "  ,");
            }
        }
        return buffer.toString();
    }

    public static String getRequestIP(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }

    /**
     * 处理uuid相关
     */
    private void preHandleUUID(){
        setUUID2MDC();
        initHeaderContext();
    }

    /**
     * 将uuid存入MDC
     */
    private void setUUID2MDC() {
        String uuid = LogUtils.generatedThreadUUID();
        MDC.put(Constant.MDC_UUID_KEY, uuid);
    }

    /**
     * 初始化自定义headers
     */
    private void initHeaderContext() {
        HeaderContext headerContext = new HeaderContext();
        headerContext.put("requestUUID", MDC.get(Constant.MDC_UUID_KEY));
        HeaderContextHolder.setHeaderContext(headerContext);
    }
}


