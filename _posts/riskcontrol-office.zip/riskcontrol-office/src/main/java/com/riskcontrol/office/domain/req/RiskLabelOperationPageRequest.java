package com.riskcontrol.office.domain.req;

import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.constants.SQLConstants;
import com.riskcontrol.common.entity.request.BasePageRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel(value = "风控标签操作日志分页查询请求对象", description = "风控标签操作日志分页查询参数")
public class RiskLabelOperationPageRequest extends BasePageRequest {

    @ApiModelProperty("createdDate Begin")
    @Query(field = "createDate", mt = SQLConstants.Query.GE)
    private String createdDateBegin;

    @ApiModelProperty("createdDate End")
    @Query(field = "createDate", mt = SQLConstants.Query.LE)
    private String createdDateEnd;

}