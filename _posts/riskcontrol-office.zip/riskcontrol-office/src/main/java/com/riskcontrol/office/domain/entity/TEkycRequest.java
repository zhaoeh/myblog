package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * eKYC提案审核表
 */
@TableName(value = "t_ekyc_request")
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class TEkycRequest extends  BaseEntity {

    /**
     * 用户ID
     */
    @TableField(value = "customer_id",fill = FieldFill.INSERT)
    private String customerId;

    /**
     * 用户名
     */
    @TableField(value = "login_name",fill = FieldFill.INSERT)
    private String loginName;

    /**
     * 首名
     */
    @TableField(value = "first_name",fill = FieldFill.INSERT)
    private String firstName;

    /**
     * 中间名
     */
    @TableField(value = "middle_name",fill = FieldFill.INSERT)
    private String middleName;

    /**
     * 尾名
     */
    @TableField(value = "last_name",fill = FieldFill.INSERT)
    private String lastName;

    /**
     * 生日
     */
    @TableField(value = "birthday",fill = FieldFill.INSERT)
    private String birthday;

    /**
     * M=Male, F=Female
     */
    @TableField(value = "sex",fill = FieldFill.INSERT)
    private String sex;

    /**
     * 证件证明照
     */
    @TableField(value = "id_front_img",fill = FieldFill.INSERT)
    private String idFrontImg;


    /**
     * 证件背面照
     */
    @TableField(value = "id_back_img",fill = FieldFill.INSERT)
    private String idBackImg;


    /**
     * 证件类型
     */
    @TableField(value = "id_type",fill = FieldFill.INSERT)
    private Integer idType;

    /**
     * 证件号
     */
    @TableField(value = "id_no",fill = FieldFill.INSERT)
    private String idNo;

    /**
     * 自拍照
     */
    @TableField(value = "face_img",fill = FieldFill.INSERT)
    private String faceImg;


    /**
     * KYC审批状态 0初始化，1待完善信息，2 人工审批，3通过，5 自动拒绝，6手动拒绝, 7失效
     */
    @TableField(value = "`status`")
    private Integer status;

    /**
     * 创建时间
     */
    @TableField(value = "create_date",fill = FieldFill.INSERT)
    private String createDate;

    /**
     * 创建人
     */
    @TableField(value = "create_by",fill = FieldFill.INSERT)
    private String createBy;

    /**
     * 更新时间
     */
    @TableField(value = "update_date",fill = FieldFill.INSERT)
    private String updateDate;

    /**
     * 更新人
     */
    @TableField(value = "update_by",fill = FieldFill.INSERT)
    private String updateBy;

//    /**
//     * 完善扩展信息时间
//     */
//    @TableField(value = "update_ex_date")
//    private String updateExDate;

    /**
     * 审批时间
     */
    @TableField(value = "approved_date")
    private String approvedDate;

    /**
     * 审核人
     */
    @TableField(value = "approved_by",fill = FieldFill.INSERT)
    private String approvedBy;

    /**
     * 血缘标记（BP、AP、 GP、PG、SP）
     */
    @TableField(value = "tenant",fill = FieldFill.INSERT)
    private String tenant;

    /**
     * 渠道(3:GLIFE,4:GPO,5:LAZADA,6:MAYA,7:PERYAGAME,99WEBSITE,98:人工)
     */
    @TableField(value = "channel",fill = FieldFill.INSERT)
    private String channel;

    /**
     * 业务编号（随机生成唯一号）
     */
    @TableField(value = "bill_no",fill = FieldFill.INSERT)
    private String billNo;

    /**
     * 第三方业务id
     */
    @TableField(value = "ekyc_transaction_id",fill = FieldFill.INSERT)
    private String ekycTransactionId;

    /**
     * 第三方获取结果时间
     */
    @TableField(value = "ekyc_result_date")
    private String ekycResultDate;

    /**
     * 第三方返回结果
     */
    @TableField(value = "ekyc_result",fill = FieldFill.INSERT)
    private String ekycResult;

    /**
     * 企业名称
     */
    @TableField(value = "employer_name",fill = FieldFill.INSERT)
    private String employerName;

    /**
     * 永久居住地
     */
    @TableField(value = "address",fill = FieldFill.INSERT)
    private String address;

    /**
     * 出生地
     */
    @TableField(value = "birth_place",fill = FieldFill.INSERT)
    private String birthPlace;

    /**
     * 现居地址
     */
    @TableField(value = "present_address",fill = FieldFill.INSERT)
    private String presentAddress;

    /**
     * 国籍
     */
    @TableField(value = "nationality",fill = FieldFill.INSERT)
    private String nationality;

    /**
     * 资金来源
     */
    @TableField(value = "source_of_income",fill = FieldFill.INSERT)
    private String sourceOfIncome;

    /**
     * 工作性质
     */
    @TableField(value = "nature_of_work",fill = FieldFill.INSERT)
    private String natureOfWork;

    /**
     * 备注
     */
    @TableField(value = "remark",fill = FieldFill.INSERT)
    private String remark;

    /**
     * 转人工审核原因
     */
    @TableField(value = "manual_reason")
    private Integer manualReason;

    /**
     * 人工提交截图
     */
    @TableField(value = "manual_img",fill = FieldFill.INSERT)
    private String manualImg;


    /**
     * 拒绝原因
     */
    @TableField(value = "reject_reason",fill = FieldFill.INSERT)
    private String rejectReason;


}