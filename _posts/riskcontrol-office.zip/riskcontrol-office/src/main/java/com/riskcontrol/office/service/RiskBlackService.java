package com.riskcontrol.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.office.domain.req.black.RiskBlackImportRequest;
import com.riskcontrol.office.domain.req.black.RiskBlackPageRequest;
import com.riskcontrol.office.domain.req.black.RiskBlackUpdateRequest;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.domain.rsp.black.RiskBlackRsp;
import com.riskcontrol.office.domain.entity.TRiskBlack;


/**
 * @author Heng.zhang
 */
public interface RiskBlackService extends IService<TRiskBlack> {

    /**
     * 分页查询风控黑名单 *
     *
     * @param req -
     * @return
     */
    PageModel<RiskBlackRsp> pageRiskBlackList(RiskBlackPageRequest req);

    /**
     * 导入excel黑名单
     *
     * @param importRequest
     * @return
     */
    Boolean importExcel(RiskBlackImportRequest.RiskBlackImport importRequest);

    /**
     * 更新风控黑名单状态 *
     *
     * @param req -
     * @return
     */
    Boolean updateBlackStatus(RiskBlackUpdateRequest req);

}
