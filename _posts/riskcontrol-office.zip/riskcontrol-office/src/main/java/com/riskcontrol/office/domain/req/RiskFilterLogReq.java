package com.riskcontrol.office.domain.req;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.entity.request.BasePageRequest;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * @author dante
 * @date 2024/04/22
 */
@Data
@Schema(description="拦截日志请求对象")
public class RiskFilterLogReq extends BasePageRequest {

    @Schema(description = "时间开始")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @NotNull
    @Query(
            field = "createTime",
            mt = "ge"
    )
    private Date beginDate;

    @Schema(description = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @NotNull
    @Query(
            field = "createTime",
            mt = "le"
    )
    private Date endDate;


    @Schema(description = "审批时间开始")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Query(
            field = "auditTime",
            mt = "ge"
    )
    private Date auditBeginDate;

    @Schema(description = "审批结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Query(
            field = "auditTime",
            mt = "le"
    )
    private Date auditEndDate;

    @Schema(description = "拦截类型（deposit;withdraw;betting）")
    @Query
    private String filterType;

    @Schema(description = "风控决策(RESTRICT_WITHDRAW;RESTRICT_BETTING;AUDIT_FREE_WITHDRAW;TRANSFERRED_TO_MANUAL_REVIEW）")
    @Query
    private String riskRuleAction;
    @Schema(description = "拦截状态( 0初始 1已放行 2待审核 3已拦截)")
    @Query
    private Integer status;
    @Schema(description = "通知状态 (0未通知 1已通知)")
    @Query
    private Integer notifyStatus;
    @Schema(description = "请求id ")
    @Query
    private String requestId;

}
