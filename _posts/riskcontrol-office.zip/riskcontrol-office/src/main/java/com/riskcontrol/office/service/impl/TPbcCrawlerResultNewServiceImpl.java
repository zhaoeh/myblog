package com.riskcontrol.office.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.riskcontrol.common.entity.request.PbcCrawlerUpdateStatusReq;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.domain.entity.TPbcCrawlerResultNew;
import com.riskcontrol.office.domain.req.PbcCrawlerPageRequest;
import com.riskcontrol.office.mapper.TPbcCrawlerResultNewMapper;
import com.riskcontrol.office.service.TPbcCrawlerResultNewService;
import com.riskcontrol.office.template.RiskControlApiTemplate;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.Objects;

@Service
public class TPbcCrawlerResultNewServiceImpl extends BaseServiceImpl<TPbcCrawlerResultNewMapper, TPbcCrawlerResultNew> implements TPbcCrawlerResultNewService {

    @Resource
    private TPbcCrawlerResultNewMapper pbcCrawlerResultNewMapper;

    @Resource
    private RiskControlApiTemplate riskControlApiTemplate;

    @Override
    @SneakyThrows
    public PageModel<TPbcCrawlerResultNew> queryList(PbcCrawlerPageRequest req) {
        LambdaQueryWrapper<TPbcCrawlerResultNew> wrapper = buildWrapper(req);
        modifyWrapper(wrapper, req);
        if(StringUtils.isBlank(req.getSortName())){
            req.setSortName("createDate");
            req.setIsAsc(false);
        }
        var page = pageByWrapper(req, wrapper);
        var pageResult = new PageModel<TPbcCrawlerResultNew>();
        pageResult.setData(page.getRecords());
        pageResult.setPageNo((int) page.getCurrent());
        pageResult.setPageSize((int) page.getSize());
        pageResult.setTotalRow((int) page.getTotal());
        pageResult.setTotalPage((int) page.getPages());
        return pageResult;
    }

    @Override
    public boolean updateStatus(PbcCrawlerUpdateStatusReq req) {
        riskControlApiTemplate.updateStatusOfTPbcCrawlerResultNew(req);
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            var updateWrapper = new LambdaUpdateWrapper<TPbcCrawlerResultNew>()
                    .eq(TPbcCrawlerResultNew::getId, req.getId())
                    .set(TPbcCrawlerResultNew::getUpdateBy, userInfoVO.getUserInfo().getUsername());
            return pbcCrawlerResultNewMapper.update(null, updateWrapper) > 0;
        }
        return true;
    }

    /**
     * 更新warpper*
     *
     * @param wrapper
     * @param req
     */
    private void modifyWrapper(LambdaQueryWrapper<TPbcCrawlerResultNew> wrapper, PbcCrawlerPageRequest req) {
        String firstName = req.getFirstName();
        String middleName = req.getMiddleName();
        String lastName = req.getLastName();
        if (StringUtils.isNotBlank(firstName) && StringUtils.isBlank(middleName) && StringUtils.isNotBlank(lastName)) {
            wrapper.eq(TPbcCrawlerResultNew::getMiddleName, "");
        }
    }

}
