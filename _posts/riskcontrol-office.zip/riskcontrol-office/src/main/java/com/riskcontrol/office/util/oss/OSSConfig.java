package com.riskcontrol.office.util.oss;

import com.riskcontrol.office.util.aws.AwsServiceImpl;
import com.riskcontrol.office.util.minio.MinioServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.Resource;

@Configuration
public class OSSConfig {

    @Resource
    private OssProperties ossProperties;

    @Bean
    public OssService ossService() {
        if (StringUtils.isBlank(ossProperties.getType()) || !"minio".equals(ossProperties.getType())) {
            return new AwsServiceImpl(ossProperties);
        } else {
            return new MinioServiceImpl(ossProperties);
        }
    }

}
