package com.riskcontrol.office.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.riskcontrol.office.domain.entity.RiskFilterLog;
import org.apache.ibatis.annotations.Mapper;

/**
 * 风控拦截日志表(t_risk_filter_log)数据Mapper
 *
 * @author dante
 * @since 2024-04-18 16:45:29
 * @description 由 Mybatisplus Code Generator 创建
*/
@Mapper
public interface RiskFilterLogMapper extends BaseMapper<RiskFilterLog> {

}
