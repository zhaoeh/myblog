package com.riskcontrol.office.domain.req;

import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.entity.request.BasePageRequest;
import com.riskcontrol.office.domain.validation.PbcDisableReqValidator;
import com.riskcontrol.office.domain.validation.PbcUpdateReqValidator;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;

@Data
@Schema(description="PBC请求对象")
public class PbcDeployReq extends BasePageRequest {

    @Schema(description = "id")
    @NotNull(groups = {PbcUpdateReqValidator.class, PbcDisableReqValidator.class},message = "ID cannot be null")
    @Query
    protected BigInteger id;

    @Schema(description = "抓取系统id")
    @NotBlank(groups = {PbcUpdateReqValidator.class,PbcDisableReqValidator.class},message = "systemId cannot be null")
    @Query
    protected String systemId;

    @Schema(description ="用户名")
    @NotBlank(groups = PbcUpdateReqValidator.class,message = "userName cannot be null")
    protected String userName;

    @Schema(description ="密码")
    @NotBlank(groups = PbcUpdateReqValidator.class,message = "password cannot be null")
    protected String password;

    @Schema(description ="开始时间 HH:mm:ss")
    @NotBlank(groups = PbcUpdateReqValidator.class,message = "start time cannot be null")
    protected String startTime;

    @Schema(description ="停止时间 HH:mm:ss")
    @NotBlank(groups = PbcUpdateReqValidator.class,message = "end time cannot be null")
    protected String endTime;

    @Schema(description ="抓取频率")
    @NotNull(groups = PbcUpdateReqValidator.class,message = "frequency cannot be null")
    @Min(15)
    @Max(60)
    protected Integer frequency;

}