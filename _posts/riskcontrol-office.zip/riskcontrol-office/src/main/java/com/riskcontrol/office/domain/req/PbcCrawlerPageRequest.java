package com.riskcontrol.office.domain.req;

import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.constants.SQLConstants;
import com.riskcontrol.common.entity.request.BasePageRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


/**
 * @author Heng.zhang
 */
@Data
@ApiModel(value = "PBC黑名单分页查询请求对象", description = "PBC黑名单分页查询参数")
public class PbcCrawlerPageRequest extends BasePageRequest {

    @ApiModelProperty("名字")
    @Query
    private String firstName;

    @ApiModelProperty("中间名")
    @Query
    private String middleName;

    @ApiModelProperty("姓")
    @Query
    private String lastName;

    @ApiModelProperty("生日")
    @Query
    private String birthDate;

    @ApiModelProperty("禁用来源")
    @Query
    private String source;
}