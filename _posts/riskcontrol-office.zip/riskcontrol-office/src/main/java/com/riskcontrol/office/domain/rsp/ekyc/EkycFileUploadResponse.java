package com.riskcontrol.office.domain.rsp.ekyc;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class EkycFileUploadResponse {

    private String url;

    private String filePath;

}
