package com.riskcontrol.office.domain.req;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.riskcontrol.common.entity.request.BasePageRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.math.BigInteger;
import java.util.List;

/**
 * @description: 风控分页标签请求体
 * @author: ErHu.Zhao
 * @create: 2024-10-16
 **/
@Data
@ApiModel(description = "风控标签请求对象")
public class RiskLabelPageReq extends BasePageRequest {

    @ApiModelProperty(value = "用户名称")
    private String loginName;

    @ApiModelProperty("标签id")
    @JsonProperty("riskLabelIds")
    private List<BigInteger> riskLabelIds;

    @JsonIgnore
    private boolean queryValidatedLabel;

}
