package com.riskcontrol.office.domain.req;

import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.entity.request.BasePageRequest;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.util.Date;

@Data
@Schema(description="操作日志请求对象")
public class OperactionLogReq extends BasePageRequest {

    private String productId = "C66";

    @TableField(value = "menu_name")
    @Schema(description = "父菜单名称")
    @Query
    private String menuName;

    @TableField(value = "sub_menu_name")
    @Schema(description = "子菜单名称")
    @Query
    private String subMenuName;

    @Schema(description = "操作类型(0:未知操作,1:创建,2:修改,3:删除,4:发布,5:撤销,6:配置,7:复制,8:维护,9:启用,10:禁用）")
    @Query
    private Integer opType;

    @Schema(description = "操作人")
    @Query
    private String opBy;

    @Schema(description = "操作日志")
    @Query
    private String opLog;

    @Schema(description = "时间开始")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @NotNull
    @Query(
            field = "createTime",
            mt = "ge"
    )
    private Date beginDate;

    @Schema(description = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @NotNull
    @Query(
            field = "createTime",
            mt = "le"
    )
    private Date endDate;

    @Schema(description = "返回结果")
    @Query(
            mt = "like"
    )
    private String returnStr;

    @Schema(description = "请求参数")
    @Query(
            mt = "like"
    )
    private String requestStr;

    private static final long serialVersionUID = 1L;
}