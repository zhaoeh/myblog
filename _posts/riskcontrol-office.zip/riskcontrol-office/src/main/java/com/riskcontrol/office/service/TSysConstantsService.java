package com.riskcontrol.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.domain.entity.TSysConstants;
import com.riskcontrol.office.domain.req.SysConstantReq;
import org.springframework.web.bind.annotation.RequestBody;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

public interface TSysConstantsService extends IService<TSysConstants>{

    PageModel<TSysConstants> queryConstantList(@RequestBody SysConstantReq req);
    boolean create(SysConstantReq req);
    boolean updateById(SysConstantReq req);
    boolean deleteById(BigInteger id);

    void refreshSysConstant(SysConstantReq req);

    /**
     * 获取某类型所有的常量
     * @param type 类型标识
     */
    List<Map<String, String>> queryConstantListByType(String type);
}
