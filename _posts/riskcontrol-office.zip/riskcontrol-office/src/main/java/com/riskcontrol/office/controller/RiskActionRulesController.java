package com.riskcontrol.office.controller;

import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.annotation.EnableOperationLog;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.enums.OpTypeEnum;
import com.riskcontrol.office.domain.req.DeviceRiskRuleEditReq;
import com.riskcontrol.office.domain.req.DeviceRiskRuleNewReq;
import com.riskcontrol.office.domain.req.DeviceRiskRuleQueryReq;
import com.riskcontrol.office.domain.req.DeviceRiskRuleUpdateReq;
import com.riskcontrol.office.domain.rsp.DeviceRiskRuleResp;
import com.riskcontrol.office.service.IDeviceRiskRuleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author: Yu.Guo
 * @date: 2024/11/12
 * @description: 设备指纹风控规则前端控制器
 */
@Tag(name = "设备指纹风控规则", description = "设备指纹风控规则管理")
@RestController
@RequestMapping(value = "office/riskActionRules")
public class RiskActionRulesController {

    @Autowired
    private IDeviceRiskRuleService deviceRiskRuleService;
//    @PreAuthorize("DeviceRiskRule_create")
    @PostMapping("create")
    @Operation(tags ="DeviceRiskRule" ,summary = "创建设备风控规则")
    @EnableOperationLog(menuName = "设备风控规则配置", subMenuName = "创建设备风控规则", opLog = "创建", opLogType = OpTypeEnum.CREATE)
    public R<Boolean> create(@Validated @RequestBody DeviceRiskRuleNewReq deviceRiskRuleNewReq) {
        return R.ok(deviceRiskRuleService.deviceRiskRuleCreate(deviceRiskRuleNewReq));
    }

//    @PreAuthorize("DeviceRiskRule_update")
    @PostMapping("update")
    @Operation(tags ="DeviceRiskRule" ,summary = "修改设备风控规则")
    @EnableOperationLog(menuName = "设备风控规则配置", subMenuName = "修改设备风控规则", opLog = "修改", opLogType = OpTypeEnum.UPDATE)
    public R<Boolean> Edit(@Validated @RequestBody DeviceRiskRuleEditReq deviceRiskRuleEditReq) {
        return R.ok(deviceRiskRuleService.deviceRiskRuleEdit(deviceRiskRuleEditReq));
    }

//    @PreAuthorize("DeviceRiskRule_updateStatus")
    @PostMapping("updateStatus")
    @Operation(tags ="DeviceRiskRule" ,summary = "修改设备风控规则状态")
    @EnableOperationLog(menuName = "设备风控规则配置", subMenuName = "修改设备风控规则状态", opLog = "修改", opLogType = OpTypeEnum.UPDATE)
    public R<Boolean> updateStatus(@Validated @RequestBody DeviceRiskRuleUpdateReq deviceRiskRuleEditReq) {
        return R.ok(deviceRiskRuleService.deviceRiskRuleUpdateStatus(deviceRiskRuleEditReq));
    }

//    @PreAuthorize("DeviceRiskRule_getPageList")
    @PostMapping("getPageList")
    @Operation(tags ="DeviceRiskRule" ,summary = "分页查询设备风控规则")
    public R<PageModel<DeviceRiskRuleResp>> getPageList(@Validated @RequestBody DeviceRiskRuleQueryReq deviceRiskRuleQueryReq) {
        return R.ok(deviceRiskRuleService.deviceRiskRulePageList(deviceRiskRuleQueryReq));
    }
}
