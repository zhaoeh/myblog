package com.riskcontrol.office.template;

import com.cn.schema.customers.WSCustomers;
import com.cn.schema.customers.WSCustomersBank;
import com.cn.schema.customers.WSQueryCustomersBank;
import com.riskcontrol.common.config.UserCenterSwitch;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.service.UserCenterTemplate;
import com.riskcontrol.common.service.WsFeignTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Optional;


@Slf4j
@Component
public class WsApiFeignTemplate {

    @Resource
    private UserCenterTemplate userCenterTemplate;
    @Resource
    private WsFeignTemplate wsFeignTemplate;

    public WSCustomers getSimpleCustomerByLoginName(String productId, String loginName) {
        return Optional.ofNullable(UserCenterSwitch.getSwitch()).filter(Boolean::booleanValue).
                map(e -> userCenterTemplate.getSimpleCustomerByLoginName(productId, loginName)).
                orElseGet(() -> wsFeignTemplate.getCustomerByLoginName(productId, loginName));
    }

    public List<WSCustomersBank> getSimpleCustomerByBank(String loginName) {
        WSQueryCustomersBank wsQueryCustomersBank = new WSQueryCustomersBank();
        wsQueryCustomersBank.setFlag("0;1;9");
        wsQueryCustomersBank.setLoginName(loginName);
        wsQueryCustomersBank.setProductId(Constant.C66_PRODUCT_ID);
        wsQueryCustomersBank.setDeleteFlag("0");
        return wsFeignTemplate.queryCustomerBanks(wsQueryCustomersBank);
    }
}
