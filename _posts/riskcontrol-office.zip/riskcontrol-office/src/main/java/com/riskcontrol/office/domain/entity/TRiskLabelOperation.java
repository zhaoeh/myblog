package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigInteger;

/**
 * @author Heng.zhang
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_risk_label_operation_log")
@ApiModel(value = "t_risk_label_operation_log对象", description = "用户标签历史操作记录")
public class TRiskLabelOperation extends BaseEntity {

    @ApiModelProperty("ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    @ApiModelProperty(value = "操作人")
    private String operator;

    @ApiModelProperty(value = "状态 0:执行中 1:执行完成,2:执行失败")
    private Integer status;

    @ApiModelProperty(value = "操作类型 0:导入模式 1:手动更新")
    private Integer opMode;

    @ApiModelProperty(value = "操作的账号量")
    private Integer totalNo;

    @ApiModelProperty(value = "成功数量")
    private Integer successNo;

    @ApiModelProperty(value = "失败数量")
    private Integer failureNo;

    @ApiModelProperty(value = "创建日期")
    protected String createDate;

    @ApiModelProperty(value = "完成时间")
    private String finishDate;

    @ApiModelProperty(value = "备注")
    private String remark;

}