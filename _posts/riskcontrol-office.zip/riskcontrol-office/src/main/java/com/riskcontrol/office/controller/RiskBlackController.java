package com.riskcontrol.office.controller;

import cn.hutool.core.io.IoUtil;
import com.digiplus.oms.aspect.annotation.PreAuthorize;
import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.annotation.EnableOperationLog;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.common.validation.EasyExcelTemplateValidator;
import com.riskcontrol.office.domain.enums.OpTypeEnum;
import com.riskcontrol.office.domain.req.black.RiskBlackImportRequest;
import com.riskcontrol.office.domain.req.black.RiskBlackOperationDetailRequest;
import com.riskcontrol.office.domain.req.black.RiskBlackOperationPageRequest;
import com.riskcontrol.office.domain.req.black.RiskBlackPageRequest;
import com.riskcontrol.office.domain.req.black.RiskBlackUpdateRequest;
import com.riskcontrol.office.domain.rsp.black.RiskBlackOperationAccountDetailReRsp;
import com.riskcontrol.office.domain.rsp.black.RiskBlackOperationAccountInfoRsp;
import com.riskcontrol.office.domain.rsp.black.RiskBlackOperationDetailImRsp;
import com.riskcontrol.office.domain.rsp.black.RiskBlackOperationRsp;
import com.riskcontrol.office.domain.rsp.black.RiskBlackRsp;
import com.riskcontrol.office.service.RiskBlackOperationAccountDetailService;
import com.riskcontrol.office.service.RiskBlackOperationDetailService;
import com.riskcontrol.office.service.RiskBlackOperationService;
import com.riskcontrol.office.service.impl.RiskBlackServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.math.BigInteger;
import java.util.Objects;


@RestController
@Tag(name = "风控黑名单")
@SecurityRequirement(name = HttpHeaders.AUTHORIZATION)
@RequestMapping("/office/riskBlack")
public class RiskBlackController {

    @Resource
    private RiskBlackServiceImpl riskBlackService;

    @Resource
    private RiskBlackOperationService riskBlackOperationService;

    @Resource
    private RiskBlackOperationDetailService riskBlackOperationDetailService;
    @Resource
    private RiskBlackOperationAccountDetailService riskBlackOperationAccountDetailService;

    @PreAuthorize("riskBlacklist_account_export,riskBlacklist_account_query")
    @PostMapping("queryList")
    @Operation(tags = "风控黑名单", summary = "风控黑名单分页列表")
    public R<PageModel<RiskBlackRsp>> getPage(@RequestBody RiskBlackPageRequest request) throws Exception {
        if (request.getPhoneNumber() != null && !"".equals(request.getPhoneNumber())) {
            String md5Phone =  DigestUtils.md5Hex(request.getPhoneNumber());
            request.setPhoneMd5(md5Phone);
            request.setPhoneNumber(null);
        }
        return R.ok(riskBlackService.pageRiskBlackList(request));
    }

    @PreAuthorize("riskBlacklist account_import,riskBlacklist_account_association")
    @PostMapping("import")
    @Operation(tags = "风控黑名单导入", summary = "风控黑名单导入")
    @EnableOperationLog(menuName = "风控配置", subMenuName = "风控黑名单", opLog = "创建", opLogType = OpTypeEnum.CREATE)
    public R<Boolean> importExcel(@Validated RiskBlackImportRequest importRequest) throws Exception {
        boolean isValid = EasyExcelTemplateValidator.validateTemplate(importRequest.getFile(), importRequest.getType());
        if (!isValid) {
            return R.failed("The Excel template is incorrect. Please check if the column headers meet the requirements.");
        }
        byte[] content = IoUtil.readBytes(importRequest.getFile().getInputStream());
        RiskBlackImportRequest.RiskBlackImport riskBlackImport = new RiskBlackImportRequest.RiskBlackImport();
        riskBlackImport.setContent(content);
        riskBlackImport.setType(importRequest.getType());
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            riskBlackImport.setDataModifier(userInfoVO.getUserInfo().getUsername());
        }
        riskBlackService.importExcel(riskBlackImport);
        return R.ok();
    }

    @PreAuthorize("riskBlacklist_account_status")
    @PostMapping("updateStatus")
    @Operation(tags = "风控黑名单更新状态", summary = "风控黑名单更新状态")
    @EnableOperationLog(menuName = "风控配置", subMenuName = "风控黑名单", opLog = "修改", opLogType = OpTypeEnum.UPDATE)
    public R<Boolean> updateHistory(@Validated @RequestBody RiskBlackUpdateRequest request) {
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            request.setDataModifier(userInfoVO.getUserInfo().getUsername());
        }
        riskBlackService.updateBlackStatus(request);
        return R.ok();
    }

    @PreAuthorize("riskBlacklist_account_history")
    @PostMapping("operation/queryList")
    @Operation(tags = "风控黑名单历史操作记录", summary = "风控黑名单历史操作记录分页列表")
    public R<PageModel<RiskBlackOperationRsp>> getOperationPage(@RequestBody RiskBlackOperationPageRequest request) {
        return R.ok(riskBlackOperationService.getOperationPageList(request));
    }

    @PostMapping("importList")
    @Operation(tags = "导入模式历史操作记录列表", summary = "导入模式历史操作记录列表")
    public R<PageModel<RiskBlackOperationDetailImRsp>> getOperationDetailImPageList(@RequestBody RiskBlackOperationDetailRequest request) {
        return R.ok(riskBlackOperationDetailService.getOperationDetailImPageList(request));
    }

    @PostMapping("relationList")
    @Operation(tags = "关联模式历史操作记录列表", summary = "关联模式历史操作记录列表")
    public R<PageModel<RiskBlackOperationAccountDetailReRsp>> getOperationDetailRePageList(@RequestBody RiskBlackOperationDetailRequest request) {
        return R.ok(riskBlackOperationDetailService.getOperationDetailRePageList(request));
    }

    @GetMapping("relationList/{detailId}")
    @Operation(tags = "关联模式历史操作记录明细", summary = "关联模式历史操作记录明细")
    public R<RiskBlackOperationAccountInfoRsp> getOperationDetailReInfo(@PathVariable("detailId") BigInteger detailId) {
        return R.ok(riskBlackOperationAccountDetailService.getOperationAccountReInfo(detailId));
    }
}
