package com.riskcontrol.office.config;

import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.support.ConsumerTagStrategy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

/**
 * @author Dominik.X
 * @description
 * @date 2018/12/12 15:46
 */
@Configuration
public class RabbitConfig {

    private static final String VIRTUAL_HOST = "/";

    @Value("${spring.rabbitmq.username}")
    private String userName;

    @Value("${spring.rabbitmq.password}")
    private String password;

    @Value("${spring.rabbitmq.host}")
    private String url;

    @Value("${spring.rabbitmq.port}")
    private int port;
    @Value("${spring.rabbitmq.checkTimeout:10000}")
    private int checkTimeout;
    @Value("${spring.rabbitmq.chaheSize:50}")
    private int chaheSize;



    @Bean
    public ConnectionFactory rabbitConnectionFactory() {
        CachingConnectionFactory connectionFactory = new CachingConnectionFactory();
        connectionFactory.setPort(port);
        connectionFactory.setHost(url);
        connectionFactory.setUsername(userName);
        connectionFactory.setPassword(password);
        connectionFactory.setVirtualHost(VIRTUAL_HOST);
        connectionFactory.setChannelCacheSize(chaheSize);
        connectionFactory.setChannelCheckoutTimeout(checkTimeout);
        connectionFactory.setPublisherConfirms(true);
        return connectionFactory;
    }

    @Bean("rabbitMq")
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public RabbitTemplate rabbitTemplate(ConnectionFactory rabbitConnectionFactory) {
        return new RabbitTemplate(rabbitConnectionFactory);
    }

    @Bean
    public RabbitAdmin rabbitAdmin(ConnectionFactory rabbitConnectionFactory) {
        RabbitAdmin rabbitAdmin = new RabbitAdmin(rabbitConnectionFactory);
        rabbitAdmin.setIgnoreDeclarationExceptions(true);
        return rabbitAdmin;
    }



    /**
     * 不配置这个容器，启动项目时候，rabbitmq的管控台看不到动作
     * @param factory
     * @return
     */
    @Bean
    public SimpleMessageListenerContainer container(ConnectionFactory factory) {
        SimpleMessageListenerContainer container = new SimpleMessageListenerContainer(factory);
        container.setConsumerTagStrategy(new ConsumerTagStrategy() {

            @Override
            public String createConsumerTag(String queue) {
                return null;
            }
        });
        return container;
    }


}
