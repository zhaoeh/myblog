package com.riskcontrol.office.service;


import com.riskcontrol.office.domain.entity.TRiskBlackOperation;
import com.riskcontrol.office.domain.po.RiskBlackImportPO;

/**
 * @author Heng.zhang
 */
public interface RiskBlackDoImportService {

    boolean doImports(RiskBlackImportPO.BlackImportContext context);
}
