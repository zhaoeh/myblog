package com.riskcontrol.office.controller;

import com.digiplus.oms.aspect.annotation.PreAuthorize;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.annotation.EnableOperationLog;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.entity.TSysConstants;
import com.riskcontrol.office.domain.enums.OpTypeEnum;
import com.riskcontrol.office.domain.req.SysConstantReq;
import com.riskcontrol.office.domain.validation.SysConstantCreateReqValidator;
import com.riskcontrol.office.domain.validation.SysConstantUpdateReqValidator;
import com.riskcontrol.office.mapper.TSysConstantsMapper;
import com.riskcontrol.office.service.TSysConstantsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;

/**
 * @author: sanji
 * @date: 2024/03/11 16:01
 */
@RestController
@RequestMapping("/sys_constants")
@Tag(name = "风控常量设置")
@Slf4j
public class SysConstantsController {

    @Resource
    TSysConstantsService sysConstantsService;

    @PostMapping("/list")
    @Operation(tags ="风控常量设置" ,summary = "查询常量列表")
    @ResponseBody
    @PreAuthorize("systemAdmin_systemConstants_query")
    public R<PageModel<TSysConstants>> queryConstantList(@RequestBody SysConstantReq req) {
        return R.ok(sysConstantsService.queryConstantList(req));
    }
    @PostMapping("/create")
    @Operation(tags ="风控常量设置" ,summary = "创建常量")
    @ResponseBody
    @PreAuthorize("systemAdmin_systemConstants_create")
    @EnableOperationLog(menuName="系统管理",subMenuName="风控常量设置",opLog = "创建",opLogType= OpTypeEnum.CREATE,mapperClass = TSysConstantsMapper.class)
    public Object create(@RequestBody @Validated(SysConstantCreateReqValidator.class) SysConstantReq req) {
        return R.ok(sysConstantsService.create(req));
    }
    @PostMapping("/update")
    @Operation(tags ="风控常量设置" ,summary = "根据id修改常量配置")
    @ResponseBody
    @PreAuthorize("systemAdmin_systemConstants_modify")
    @EnableOperationLog(menuName="系统管理",subMenuName="风控常量设置",opLog = "更新",opLogType= OpTypeEnum.UPDATE,mapperClass = TSysConstantsMapper.class)
    public R<Boolean> update(@RequestBody @Validated(SysConstantUpdateReqValidator.class) SysConstantReq req) {
        return R.ok(sysConstantsService.updateById(req));
    }

    @PostMapping("/delete/{id}")
    @Operation(tags ="风控常量设置" ,summary = "删除常量")
    @ResponseBody
    @PreAuthorize("systemAdmin_systemConstants_delete")
    @EnableOperationLog(menuName="系统管理",subMenuName="风控常量设置",opLog = "删除",opLogType= OpTypeEnum.DELETE,mapperClass = TSysConstantsMapper.class)
    public R<Boolean> delete(@PathVariable @NotNull @Validated BigInteger id) {
        return R.ok(sysConstantsService.deleteById(id));
    }

    @PostMapping("/enable/{id}")
    @Operation(tags ="风控常量设置" ,summary = "启用常量")
    @ResponseBody
    @PreAuthorize("systemAdmin_systemConstants_status")
    @EnableOperationLog(menuName="系统管理",subMenuName="风控常量设置",opLog = "启用",opLogType= OpTypeEnum.ENABLE,mapperClass = TSysConstantsMapper.class)
    public R<Boolean> enable(@PathVariable @NotNull @Validated BigInteger id) {
        SysConstantReq req = new SysConstantReq();
        req.setId(id);
        req.setIsEnable(1);
        return R.ok(sysConstantsService.updateById(req));
    }

    @PostMapping("/disable/{id}")
    @Operation(tags ="风控常量设置" ,summary = "禁用常量")
    @ResponseBody
    @PreAuthorize("systemAdmin_systemConstants_status")
    @EnableOperationLog(menuName="系统管理",subMenuName="风控常量设置",opLog = "禁用",opLogType= OpTypeEnum.DISABLE,mapperClass = TSysConstantsMapper.class)
    public R<Boolean> disable(@PathVariable @NotNull @Validated BigInteger id) {
        SysConstantReq req = new SysConstantReq();
        req.setId(id);
        req.setIsEnable(0);
        return R.ok(sysConstantsService.updateById(req));
    }
    @PostMapping("/refreshConstants")
    @Operation(tags ="风控常量设置" ,summary = "刷新缓存")
    @ResponseBody
    @PreAuthorize("systemAdmin_systemConstants_refresh")
    @EnableOperationLog(menuName="系统管理",subMenuName="风控常量设置",opLog = "刷新缓存",opLogType= OpTypeEnum.RELEASE,mapperClass = TSysConstantsMapper.class)
    public R<Boolean> refreshConstants(@RequestBody SysConstantReq req){
        sysConstantsService.refreshSysConstant(req);
        return R.ok();
    }
}
