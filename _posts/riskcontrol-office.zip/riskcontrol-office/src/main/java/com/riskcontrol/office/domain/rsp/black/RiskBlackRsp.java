package com.riskcontrol.office.domain.rsp.black;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigInteger;


@ApiModel(value = "风控黑名单响应对象", description = "风控黑名单")
@Data
public class RiskBlackRsp{

    @ApiModelProperty("ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    @ApiModelProperty(value = "账号")
    private String loginName;

    @ApiModelProperty(value = "生日")
    private String birthday;

    @ApiModelProperty("名字")
    private String firstName;

    @ApiModelProperty("中间名")
    private String middleName;

    @ApiModelProperty("姓")
    private String lastName;

    @ApiModelProperty(value = "注册IP")
    private String registerIp;

    @ApiModelProperty(value = "登陆IP")
    private String loginIp;

    @ApiModelProperty(value = "证件类型")
    private Integer idType;

    @ApiModelProperty(value = "证件ID")
    private String idNo;

    @ApiModelProperty(value = "电话号码")
    private String phoneNumber;

    @ApiModelProperty(value = "邮箱")
    private String email;

    @ApiModelProperty(value = "银行卡号")
    private String bankAccountNo;

    @ApiModelProperty(value = "状态 1：有效状态 0：无效状态")
    private String status;

    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "创建日期(Create Time)")
    protected String createDate;

    @ApiModelProperty(value = "更新日期(Modify Time)")
    protected String updateDate;

    @ApiModelProperty(value = "创建人")
    private String createBy;

    @ApiModelProperty(value = "更新人")
    private String updateBy;

    @ApiModelProperty(value = "黑名单来源：0：人工、1：关联匹配、2：pagcor黑名单")
    private String source;

}