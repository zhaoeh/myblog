package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.riskcontrol.common.annotation.Null2Empty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigInteger;

/**
 * @author Heng.zhang
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_risk_black")
@ApiModel(value = "t_risk_black对象", description = "黑名单")
public class TRiskBlack extends BaseEntity{

    @ApiModelProperty("ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    @ApiModelProperty(value = "账号")
    @TableField(fill = FieldFill.INSERT)
    private String loginName;

    @ApiModelProperty(value = "名")
    @TableField(fill = FieldFill.INSERT)
    private String firstName;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "中间名")
    private String middleName;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "姓")
    private String lastName;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "生日")
    private String birthday;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "注册IP")
    private String registerIp;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "登陆IP")
    private String loginIp;

    @ApiModelProperty(value = "证件类型")
    private Integer idType;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "证件ID")
    private String idNo;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "电话号码")
    private String phoneNumber;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "电话号码")
    private String phoneMd5;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "邮箱")
    private String email;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "银行卡号")
    private String bankAccountNo;

    @ApiModelProperty(value = "黑名单来源：0：人工、1：关联匹配、2：pagcor黑名单")
    private Integer source;

    @ApiModelProperty(value = "状态 1：有效状态 0：无效状态")
    private Integer status;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "创建日期")
    protected String createDate;

    @ApiModelProperty(value = "更新日期")
    protected String updateDate;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "创建人")
    private String createBy;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty(value = "更新人")
    private String updateBy;
}