package com.riskcontrol.office.domain.rsp;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

/**
 * @description: ekyc查询用户状态响应
 * @author: ErHu.Zhao
 * @create: 2024-10-07
 **/
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class RiskActionLogInResponse {

    @ApiModelProperty("ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    /** 设备指纹token */
    @ApiModelProperty(value = "设备指纹token")
    private String deviceFingerprintToken;

    /** 设备指纹 */
    @ApiModelProperty(value = "设备指纹")
    private String deviceFingerprint;

    /** 登陆IP地址 */
    @ApiModelProperty(value = "登陆IP地址")
    private String loginIp;

    /** 登陆电话 */
    @ApiModelProperty(value = "登陆电话")
    private String phoneNumber;

    /** 业务名(C66) */
    @ApiModelProperty(value = "业务名(C66)")
    private String productId;

    /** 用户名 */
    @ApiModelProperty(value = "用户名")
    private String loginName;

    /** 产品标识(BP, AP, GP, PG, SP) */
    @ApiModelProperty(value = "产品标识(BP, AP, GP, PG, SP)")
    private String tenant;

    /** 渠道(3:GLIFE, 4:GPO, 5:LAZADA, 6:MAYA, 7:PERYAGAME, 91:PC, 92:H5, 93:IOS, 94:Android) */
    @ApiModelProperty(value = "渠道(3:GLIFE, 4:GPO, 5:LAZADA, 6:MAYA, 7:PERYAGAME, 91:PC, 92:H5, 93:IOS, 94:Android)")
    private String channel;

    /** 创建时间 */
    @ApiModelProperty(value = "创建时间")
    private String createDate;

    /** 创建人 */
    @ApiModelProperty(value = "创建人")
    private String createBy;

    /** 更新时间 */
    @ApiModelProperty(value = "更新时间")
    private String updateDate;

    /** 更新人 */
    @ApiModelProperty(value = "更新人")
    private String updateBy;

    /** 域名 */
    @ApiModelProperty(value = "域名")
    private String domainName;

    /** 拦截类型（0：通过；1：ip；2：设备指纹；3：ip+设备指纹） */
    @ApiModelProperty(value = "拦截类型（0：通过；1：ip；2：设备指纹；3：ip+设备指纹）")
    private Integer interceptType;

}
