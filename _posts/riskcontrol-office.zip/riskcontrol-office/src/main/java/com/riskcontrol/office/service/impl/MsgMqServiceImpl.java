package com.riskcontrol.office.service.impl;

import com.cn.schema.other.WSMsgMqSendRecord;
import com.cn.schema.other.WSQueryMsgMqSendRecord;
import com.google.common.collect.Maps;
import com.riskcontrol.common.constants.CronConstant;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.office.mapper.MsgMqDao;
import com.riskcontrol.office.service.MsgMqService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * MQ消息发送记录表服务层实现类
 *
 * @author wade
 * @date 2018-08-29 09:52:47.
 */
@Service
public class MsgMqServiceImpl implements MsgMqService {

    @Autowired
    private MsgMqDao msgMqDao;

    /**
     * 查询符合条件的信息分页
     *
     * @param query 查询条件
     * @return List<WSMsgMqSendRecord> MQ消息发送记录表列表
     * @throws BusinessException
     */
    @Override
    public List<WSMsgMqSendRecord> queryPageMsgMqByCondition(WSQueryMsgMqSendRecord query) throws BusinessException {
        if(Objects.isNull(query)){
            throw new BusinessException("Request parameter cannot be null.", ResultEnum.BAD_REQUEST.getCode());
        }
        if (query.getPageSize() == 0) {
            query.setPageSize(CronConstant.PAGE_SIZE);
        } else if (query.getPageSize() > CronConstant.PAGE_MAX_SIZE) {
            throw new BusinessException("The maxium number of per page is 5000!", 100003);
        }
        query.setPageNum(query.getPageNum() > 0 ? ((query.getPageNum() - 1) * query.getPageSize()) : CronConstant.PAGE_NUM);
        return msgMqDao.queryPageMsgMqByCondition(query);
    }

    /**
     * 根据主键查询信息
     *
     * @param id 主键
     * @return WSMsgMqSendRecord
     * @throws BusinessException
     */
    @Override
    public WSMsgMqSendRecord loadMsgMqById(String id) throws BusinessException {
        if (StringUtils.isBlank(id)) {
            throw new BusinessException("Parameters cannot be null!",ResultEnum.BAD_REQUEST.getCode());
        }
        return msgMqDao.loadMsgMqById(id);
    }

    /**
     * 创建信息
     *
     * @param bean 需要创建的信息
     * @return WSMsgMqSendRecord 创建后结果
     * @throws BusinessException
     */
    @Override
    public WSMsgMqSendRecord createMsgMq(WSMsgMqSendRecord bean) throws BusinessException {
        if(Objects.isNull(bean)){
            throw new BusinessException("Parameter can't be null or empty",ResultEnum.BAD_REQUEST.getCode());
        }
        msgMqDao.createMsgMq(bean);
        return loadMsgMqById(bean.getId());
    }

    @Override
    public int deleteById(String id, String productId) throws BusinessException {
        if (StringUtils.isBlank(id)) {
            throw new BusinessException("ID should not be empty!",ResultEnum.BAD_REQUEST.getCode());
        }
        if (StringUtils.isBlank(productId)) {
            throw new BusinessException("ProductId should not be empty!",ResultEnum.BAD_REQUEST.getCode());
        }
        Map<String, String> map = Maps.newHashMap();
        map.put("id", id);
        map.put("productId", productId);
        return msgMqDao.deleteById(map);
    }


}
