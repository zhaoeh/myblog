package com.riskcontrol.office.domain.rsp.black;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigInteger;


/**
 * @author Heng.zhang
 */
@ApiModel(value = "风控黑名单操作记录明细响应对象", description = "风控黑名单")
@Data
public class RiskBlackOperationDetailImRsp {

    @ApiModelProperty("ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    @ApiModelProperty(value = "操作日志主表id")
    private String blackId;

    @ApiModelProperty(value = "账号")
    private String loginName;

    @ApiModelProperty(value = "名")
    private String firstName;

    @ApiModelProperty(value = "中间名")
    private String middleName;


    @ApiModelProperty(value = "姓")
    private String lastName;
//    @ApiModelProperty(value = "全名")
//    private String allName;

    @ApiModelProperty(value = "生日")
    private String birthday;

    @ApiModelProperty(value = "注册IP")
    private String registerIp;

    @ApiModelProperty(value = "登陆IP")
    private String loginIp;

    @ApiModelProperty(value = "证件类型")
    private Integer idType;

    @ApiModelProperty(value = "证件ID")
    private String idNo;

    @ApiModelProperty(value = "电话号码")
    private String phoneNumber;

    @ApiModelProperty(value = "邮箱")
    private String email;

    @ApiModelProperty(value = "银行卡号")
    private String bankAccountNo;

    @ApiModelProperty(value = "状态 1：有效状态 0：无效状态")
    private Integer status;

    @ApiModelProperty(value = "操作的成功失败状态 1：成功 0：失败")
    private String operationStatus;

    @ApiModelProperty(value = "创建日期(Create Time)")
    protected String createDate;

}