package com.riskcontrol.office.domain.constans.req;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.riskcontrol.common.entity.request.BaseQueryReq;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigInteger;
import java.util.List;

@Data
@Schema(title = "更新用户的风控标签")
public class UpdateCustomerRiskLabelReq extends BaseQueryReq {
    private String customerId;
    private String customerName;
    private String remarks;
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private List<BigInteger> riskLabelIds;

}
