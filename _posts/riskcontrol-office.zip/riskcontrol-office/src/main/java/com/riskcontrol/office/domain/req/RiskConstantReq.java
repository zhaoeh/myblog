package com.riskcontrol.office.domain.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.constants.SQLConstants;
import com.riskcontrol.common.entity.request.BasePageRequest;
import com.riskcontrol.office.domain.validation.RiskConstantCreateReqValidator;
import com.riskcontrol.office.domain.validation.RiskConstantUpdateReqValidator;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;

@Data
@Schema(description="风控标签请求对象")
public class RiskConstantReq extends BasePageRequest {
    @Schema(description="主键id")
    @Query
    private BigInteger id;

    @Schema(description = "常量key")
    @JsonProperty("pKey")
    @Query(mt = SQLConstants.Query.LIKE)
    private String pKey;

    @Schema(description="常量值")
    @JsonProperty("pValue")
    @Query(mt = SQLConstants.Query.LIKE)
    private String pValue;

    @Schema(description="备注")
    @Query(mt = SQLConstants.Query.LIKE)
    private String remarks;

    @Schema(description = "标志:0-未启用；1-已启用")
    @Query
    private Integer isEnable;

    @Schema(description = "绑定的规则id（多个,分割）")
    private String ruleId;

    private static final long serialVersionUID = 1L;
}