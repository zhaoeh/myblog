package com.riskcontrol.office.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import javax.annotation.PostConstruct;
import java.util.Optional;

@Configuration
@RefreshScope
public class NacosConfig {


    private static final Logger logger = LoggerFactory.getLogger(NacosConfig.class);

    @Autowired
    private Environment environment;
    private static String productTenant;

    @PostConstruct
    public void init(){
        productTenant = getProperty("product.tenant", "00");
    }
    public static String getTenant() {
        return Optional.ofNullable(productTenant).orElseThrow(UnsupportedOperationException::new);
    }

    public String getProperty(String key, String defaultValue) {

        String property = environment.getProperty(key,defaultValue);
        logger.info("Get nacos property key:{}, defaultValue:{}, value:{} ",key,defaultValue,property);

        return property;
    }

    public static String getProperty(String key, String defaultValue, Environment environment) {
        String property = environment.getProperty(key,defaultValue);
        logger.info("Get nacos property key:{}, defaultValue:{}, value:{} ",key,defaultValue,property);

        return property;
    }
}
