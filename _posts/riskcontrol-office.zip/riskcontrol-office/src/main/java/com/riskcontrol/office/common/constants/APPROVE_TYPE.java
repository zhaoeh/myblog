package com.riskcontrol.office.common.constants;

import org.apache.commons.lang3.StringUtils;

/**
 * 审批类型
 * Created by Hassan on 2017/10/16 0016.
 */
public enum APPROVE_TYPE {

    WITHDRAW_TYPE("02", "取款提案", "withdrawal Request"),

    ;


    /**
     * 枚举类型代码
     **/
    private final String code;
    private final String cnName;
    private final String enName;


    APPROVE_TYPE(String code, String cnName, String enName) {
        this.code = code;
        this.cnName = cnName;
        this.enName = enName;
    }

    public static final APPROVE_TYPE getByCode(String code) {
        for (APPROVE_TYPE approveType : values()) {
            if (StringUtils.equals(approveType.getCode(), code)) {
                return approveType;
            }
        }
        return null;
    }

    public String getCode() {
        return this.code;
    }

    public String getCnName() {
        return cnName;
    }

    public String getEnName() {
        return enName;
    }
}
