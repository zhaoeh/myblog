package com.riskcontrol.office.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.datasource.DBSourceCheck;
import com.riskcontrol.office.datasource.DataSourceType;
import com.riskcontrol.office.domain.entity.TRiskActionRegistration;
import com.riskcontrol.office.domain.req.RiskActionRegistrationQueryRequest;
import com.riskcontrol.office.domain.rsp.RiskActionRegistrationResponse;
import com.riskcontrol.office.mapper.RiskActionRegistrationMapper;
import com.riskcontrol.office.service.RiskActionRegistrationService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

/**
 * @description: 白名单service impl
 * @author: ErHu.Zhao
 * @create: 2024-11-12
 **/
@Slf4j
@Service
public class RiskActionRegistrationServiceImpl  extends BaseServiceImpl<RiskActionRegistrationMapper, TRiskActionRegistration> implements RiskActionRegistrationService {

    /**
     * 注册表分页查询
     * @param request
     * @return
     */
    @Override
    @DBSourceCheck(DataSourceType.SLAVE)
    public PageModel<RiskActionRegistrationResponse> pageRegistrationList(RiskActionRegistrationQueryRequest request){
        LambdaQueryWrapper<TRiskActionRegistration> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(StringUtils.isNotBlank(request.getDeviceFingerprint()), TRiskActionRegistration::getDeviceFingerprint, request.getDeviceFingerprint())
                .eq((Objects.nonNull(request.getRegisterIp())), TRiskActionRegistration::getRegisterIp, request.getRegisterIp())
                .eq((Objects.nonNull(request.getLoginName())), TRiskActionRegistration::getLoginName, request.getLoginName())
                .eq((Objects.nonNull(request.getInterceptType())), TRiskActionRegistration::getInterceptType, request.getInterceptType());
        Page<TRiskActionRegistration> riskActionRegistrationPage = pageByWrapper(request, wrapper);
        if (CollUtil.isEmpty(riskActionRegistrationPage.getRecords())) {
            return new PageModel<>();
        }
        List<RiskActionRegistrationResponse> list = riskActionRegistrationPage.getRecords().stream().map(entity -> {
            RiskActionRegistrationResponse rsp = new RiskActionRegistrationResponse();
            BeanUtil.copyProperties(entity, rsp);
            return rsp;
        }).toList();
        PageModel<RiskActionRegistrationResponse> pageResult = new PageModel<>();
        pageResult.setData(list);
        pageResult.setPageNo((int) riskActionRegistrationPage.getCurrent());
        pageResult.setPageSize((int) riskActionRegistrationPage.getSize());
        pageResult.setTotalRow((int) riskActionRegistrationPage.getTotal());
        pageResult.setTotalPage((int) riskActionRegistrationPage.getPages());
        return pageResult;
    }


}
