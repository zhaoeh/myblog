package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.riskcontrol.common.annotation.Null2Empty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigInteger;

/**
 * @author Heng.zhang
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_risk_action_allow")
@ApiModel(value = "t_risk_action_allow对象", description = "风控行为白名单")
public class TRiskActionAllow extends BaseEntity{
    private static final long serialVersionUID = 1L;

    /** 类容（IP或者设备指纹 字符串） */
    @ApiModelProperty(value = "类容（IP或者设备指纹 字符串）")
    @TableField(value = "allow_record",fill = FieldFill.INSERT)
    private String allowRecord;

    /** 名单类型（0:ip ; 1:设备指纹） */
    @ApiModelProperty(value = "名单类型（0:ip ; 1:设备指纹）")
    @TableField(value = "allow_type")
    private Integer allowType;

    /** 名单规则（0：白名单；1：黑名单） */
    @ApiModelProperty(value = "名单规则（0：白名单；1：黑名单）")
    @TableField(value = "allow_rule")
    private Integer allowRule;

    /** 是否启用（0：启用；1：禁用） */
    @ApiModelProperty(value = "是否启用（0：启用；1：禁用）")
    @TableField(value = "is_enable")
    private Integer isEnable;


    @TableField(value = "source")
    private Integer source;

    /**
     * 创建时间
     */
    @TableField(value = "create_date")
    private String createDate;

    /**
     * 创建人
     */
    @TableField(value = "create_by",fill = FieldFill.INSERT)
    private String createBy;

    /**
     * 更新时间
     */
    @TableField(value = "update_date")
    private String updateDate;

    /**
     * 更新人
     */
    @TableField(value = "update_by",fill = FieldFill.INSERT)
    private String updateBy;


    @TableField(value = "remark",fill = FieldFill.INSERT)
    private String remark;

}