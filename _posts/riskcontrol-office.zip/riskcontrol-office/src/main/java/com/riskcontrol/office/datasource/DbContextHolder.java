package com.riskcontrol.office.datasource;

/**
 * 数据源上下文
 * @author dante
 */
public class DbContextHolder {
	//通过 ThreadLocal 维护当前线程的数据源信息，用于实现数据源的切换
	private final static ThreadLocal<String> local = new ThreadLocal<>();

	public static void setDbType(String name) {
		local.set(name);
	}

	public static String getDbType() {
		return local.get() == null ? DataSourceType.Default.getName() : local.get();
	}

    public static void clear() {
		local.remove();
    }
}