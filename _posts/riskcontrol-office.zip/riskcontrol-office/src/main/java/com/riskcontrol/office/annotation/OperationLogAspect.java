package com.riskcontrol.office.annotation;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.riskcontrol.office.domain.entity.TOperationLog;
import com.riskcontrol.office.domain.entity.TPbcDeploy;
import com.riskcontrol.office.domain.enums.OpTypeEnum;
import com.riskcontrol.office.service.TOperationLogService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Objects;

@Aspect
@Component
@Slf4j
@Order(99999)
public class OperationLogAspect {
    @Autowired
    private SqlSession sqlSession;

    @Autowired
    private TOperationLogService operationLogService;


    @Pointcut("@annotation(com.riskcontrol.office.annotation.EnableOperationLog)")
    public void operationLog() {
    }


    @Around("operationLog()")
    public Object doAround(ProceedingJoinPoint joinPoint) throws Throwable {
        Object res = null;
        //日操逻辑
        EnableOperationLog operationLogAn = null;
        Object oldObj = null;
        int opLogType = 0;
        try {
            MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
            Method targetMethod = methodSignature.getMethod();
            operationLogAn = targetMethod.getAnnotation(EnableOperationLog.class);
            opLogType = operationLogAn.opLogType().getType();
            if (OpTypeEnum.DELETE.getType() == opLogType) {//删除,查询历史记录
                //获取修改、删除、发布、撤销或配置之前的对象
                Class interfaceImpl = operationLogAn.mapperClass();
                Object instance = Proxy.newProxyInstance(interfaceImpl.getClassLoader(), new Class[]{interfaceImpl}, new ProxyView(sqlSession.getMapper(interfaceImpl)));
                Method method = instance.getClass().getMethod("selectById", Serializable.class);
                oldObj = method.invoke(instance, joinPoint.getArgs()[0].toString());
            }
        } catch (Exception e) {
            log.error("OperationLogAspect 操作失败：", e);
        } finally {
            try {
                //执行目标方法,不影响业务方法
                res = joinPoint.proceed();
                //方法执行完成后增加日志
                addOperationLog(joinPoint, res, operationLogAn, oldObj);
            } catch (Exception e) {
                throw e;
            }
        }
        return res;
    }

    private void addOperationLog(ProceedingJoinPoint joinPoint, Object res, EnableOperationLog operationLogAn, Object oldObj) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException, ClassNotFoundException, IOException {
        JSONObject retObj = JSONObject.parseObject(JSON.toJSON(res).toString());
        String code = retObj.getString("errCode");
        Object[] arguments = joinPoint.getArgs();
        String optLog = operationLogAn.opLog();
        TOperationLog operationLog = new TOperationLog();

        //获取当前登录角色
        String opBy = "";
        String productId = "";
        //todo 获取操作用户名
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if(!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())){
            opBy = userInfoVO.getUserInfo().getUsername();
        }
        //存储日志
        operationLog.setMenuName(operationLogAn.menuName());
        operationLog.setSubMenuName(operationLogAn.subMenuName());
        operationLog.setOpType(operationLogAn.opLogType().getType());
        operationLog.setOpLog(optLog);
        operationLog.setOpBy(opBy);
        operationLog.setOpIp(this.getRemoteHost());
        operationLog.setProductId(productId);
        operationLog.setReturnStr(StringUtils.truncate(retObj.toJSONString(),2550));
        String requestParam = getRequestParam(arguments);
        if ("0000".equals(code) && OpTypeEnum.DELETE.getType() == 3 && Objects.nonNull(oldObj)) {
            operationLog.setRequestStr(StringUtils.truncate(String.format("%s:删除数据%s", requestParam, oldObj),2550));
        } else {
            operationLog.setRequestStr(StringUtils.truncate(requestParam,2550) );
        }

        boolean ret = operationLogService.save(operationLog);
        log.info("执行写入日志操作.....................结果：{}", ret);
    }

    private String getRequestParam(Object[] arguments) {
        if (arguments.length <= 0) {
            return StringUtils.EMPTY;
        }
        for (Object argument : arguments) {
            if (argument instanceof MultipartFile ||
                    argument instanceof String ||
                    argument instanceof HttpServletRequest) {
                continue;
            }
            return JSONObject.toJSONString(argument);
        }
        return StringUtils.EMPTY;
    }

    /**
     * 处理完请求，打印返回内容结果
     *
     * @param ret
     */
    @AfterReturning(returning = "ret", pointcut = "operationLog()")
    public void doAfterReturning(Object ret) {
        log.info("方法的返回值 : " + ret);
    }

    /**
     * 获取目标主机的ip
     */
    private String getRemoteHost() {
        String XFor = StringUtils.EMPTY;
        ServletRequestAttributes sra = (ServletRequestAttributes)RequestContextHolder.getRequestAttributes();
        if(sra != null){
            HttpServletRequest request = sra.getRequest();
            if(request != null){
                String Xip = request.getHeader("X-Real-IP");
                XFor = request.getHeader("X-Forwarded-For");
                if (StringUtils.isNotBlank(XFor) && !"unknown".equalsIgnoreCase(XFor)) {
                    //多次反向代理后会有多个ip值,第一个ip才是真实ip
                    int index = XFor.indexOf(",");
                    if (index != -1) {
                        return XFor.substring(0, index);
                    } else {
                        return XFor;
                    }
                }
                XFor = Xip;
                if (StringUtils.isNotEmpty(XFor) && !"unKnown".equalsIgnoreCase(XFor)) {
                    return XFor;
                }
                if (StringUtils.isBlank(XFor) || "unKnown".equalsIgnoreCase(XFor)) {
                    XFor = request.getHeader("Proxy-Client-IP");
                }
                if (StringUtils.isBlank(XFor) || "unKnown".equalsIgnoreCase(XFor)) {
                    XFor = request.getHeader("WL-Proxy-Client-IP");
                }
                if (StringUtils.isBlank(XFor) || "unknown".equalsIgnoreCase(XFor)) {
                    XFor = request.getHeader("HTTP_CLIENT_IP");
                }
                if (StringUtils.isBlank(XFor) || "unKnown".equalsIgnoreCase(XFor)) {
                    XFor = request.getHeader("HTTP_X_FORWARDED_FOR");
                }
                if (StringUtils.isBlank(XFor) || "unknown".equalsIgnoreCase(XFor)) {
                    XFor = request.getRemoteAddr();
                }
            }
        }
        return XFor;
    }
}