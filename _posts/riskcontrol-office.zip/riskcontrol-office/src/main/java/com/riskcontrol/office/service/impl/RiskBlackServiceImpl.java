package com.riskcontrol.office.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cm.util.common.Constants;
import com.cn.schema.customers.WSCustomers;
import com.cn.schema.customers.WSCustomersBank;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequest;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.enums.EkycStatusEnum;
import com.riskcontrol.common.enums.RiskImportModelEnum;
import com.riskcontrol.common.enums.SENSITIVE_TYPE;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.utils.ExcelUtils;
import com.riskcontrol.common.utils.LogUtils;
import com.riskcontrol.common.utils.PHPDESEncrypt;
import com.riskcontrol.common.utils.SensitiveUtil;
import com.riskcontrol.office.common.constants.ConstantVars;
import com.riskcontrol.office.component.LambdaQueryWrapperX;
import com.riskcontrol.office.component.RiskBlackImportConvert;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.datasource.DBSourceCheck;
import com.riskcontrol.office.datasource.DataSourceType;
import com.riskcontrol.office.domain.entity.*;
import com.riskcontrol.office.domain.po.RiskBlackImportPO;
import com.riskcontrol.office.domain.req.black.RiskBlackImportRequest;
import com.riskcontrol.office.domain.req.black.RiskBlackPageRequest;
import com.riskcontrol.office.domain.req.black.RiskBlackUpdateRequest;
import com.riskcontrol.office.domain.rsp.black.RiskBlackRsp;
import com.riskcontrol.office.enums.RiskBlackOpStatusEnum;
import com.riskcontrol.office.mapper.*;
import com.riskcontrol.office.service.RiskBlackDoImportService;
import com.riskcontrol.office.service.RiskBlackOperationService;
import com.riskcontrol.office.service.RiskBlackService;
import com.riskcontrol.office.template.WsApiFeignTemplate;
import com.riskcontrol.office.util.RedisUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.math.BigInteger;
import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.riskcontrol.common.constants.Constant.RISK_IS_BLACK_KEY;
import static com.riskcontrol.common.enums.ResultEnum.READ_EXCEL_FAIL;
import static com.riskcontrol.common.utils.DateUtils.convertDateFormat;
import static com.riskcontrol.office.common.constants.ConstantVars.ONE;
import static com.riskcontrol.office.common.constants.ConstantVars.ZERO;
import static com.riskcontrol.office.common.constants.Constants.TWO;


/**
 * @author Heng.zhang
 */
@Service
@Slf4j
public class RiskBlackServiceImpl extends BaseServiceImpl<RiskBlackMapper, TRiskBlack> implements RiskBlackService {

    @Resource(name = "taskExecutor")
    protected ThreadPoolTaskExecutor executor;
    @Autowired
    private WsApiFeignTemplate wsApiFeignTemplate;

    @Resource
    private RiskBlackOperationDetailMapper detailMapper;

    @Resource
    private RiskBlackOperationMapper riskBlackOperationMapper;

    @Resource
    private RiskBlackOperationAccountDetailMapper riskBlackOperationAccountDetailMapper;

    @Resource
    private RiskBlackMapper riskBlackMapper;

    @Resource
    private KycRequestDao kycRequestDao;

    @Resource
    private EkycMapper ekycMapper;

    @Resource
    private RiskBlackOperationService riskBlackOperationService;

    @Resource
    private RiskBlackDoImportService riskBlackDoImportService;
    @DBSourceCheck(DataSourceType.SLAVE)
    @Override
    public PageModel<RiskBlackRsp> pageRiskBlackList(RiskBlackPageRequest req) {
        LambdaQueryWrapper<TRiskBlack> wrapper = buildWrapper(req);
        modifyWrapper(wrapper, req);
        wrapper.select(TRiskBlack::getId,
                        TRiskBlack::getIdNo,
                        TRiskBlack::getLoginName,
                        TRiskBlack::getFirstName,
                        TRiskBlack::getMiddleName,
                        TRiskBlack::getLastName,
                        TRiskBlack::getBirthday,
                        TRiskBlack::getRegisterIp,
                        TRiskBlack::getLoginIp,
                        TRiskBlack::getIdType,
                        TRiskBlack::getIdNo,
                        TRiskBlack::getPhoneNumber,
                        TRiskBlack::getEmail,
                        TRiskBlack::getBankAccountNo,
                        TRiskBlack::getSource,
                        TRiskBlack::getStatus,
                        TRiskBlack::getRemark,
                        TRiskBlack::getCreateDate,
                        TRiskBlack::getUpdateDate,
                        TRiskBlack::getCreateBy,
                        TRiskBlack::getUpdateBy
                )
                .and(StringUtils.isNotBlank(req.getIp()),
                        wrp -> wrp.eq(TRiskBlack::getRegisterIp, req.getIp())
                                .or()
                                .eq(TRiskBlack::getLoginIp, req.getIp()))
                .orderByDesc(TRiskBlack::getId);
        Page<TRiskBlack> tRiskBlackPage = pageByWrapper(req, wrapper);
        if (CollUtil.isEmpty(tRiskBlackPage.getRecords())) {
            return new PageModel<>();
        }
        PHPDESEncrypt phoneEncrypt = PHPDESEncrypt.getNewInstance(Constants.C66, SENSITIVE_TYPE.PHONE_NO.getEncryptCode());
        PHPDESEncrypt bankCardNoEncrypt = PHPDESEncrypt.getNewInstance(Constants.C66, SENSITIVE_TYPE.BANK_NO.getEncryptCode());

        List<RiskBlackRsp> list = tRiskBlackPage.getRecords().stream().map(entity -> {
            RiskBlackRsp rsp = new RiskBlackRsp();
            BeanUtil.copyProperties(entity, rsp);
            try {
                if(StringUtils.isNotBlank(rsp.getPhoneNumber())){
                    rsp.setPhoneNumber(SensitiveUtil.halfHideSensitive(SENSITIVE_TYPE.PHONE_NO.getDefaultHideType(), phoneEncrypt.decrypt(rsp.getPhoneNumber())));
                }
                if(StringUtils.isNotBlank(rsp.getBankAccountNo())){
                    StringBuilder sb = new StringBuilder();
                    String[] bankCardNos = rsp.getBankAccountNo().split(ConstantVars.SEPARATOR_COMMA);
                    if (bankCardNos.length > 0) {
                        for (String bankCardNo : bankCardNos) {
                            sb.append(SensitiveUtil.halfHideSensitive(SENSITIVE_TYPE.BANK_NO.getDefaultHideType(), bankCardNoEncrypt.decrypt(bankCardNo)));
                            sb.append(ConstantVars.SEPARATOR_COMMA);
                        }
                        rsp.setBankAccountNo(sb.substring(0, sb.length() - 1));
                    }
                }
            } catch (Exception e) {
                log.error("解密手机/银行卡号异常", e);
            }
            return rsp;
        }).toList();

        PageModel<RiskBlackRsp> riskBlackRsp = new PageModel<>();
        riskBlackRsp.setData(list);
        riskBlackRsp.setPageNo((int) tRiskBlackPage.getCurrent());
        riskBlackRsp.setPageSize((int) tRiskBlackPage.getSize());
        riskBlackRsp.setTotalRow((int) tRiskBlackPage.getTotal());
        riskBlackRsp.setTotalPage((int) tRiskBlackPage.getPages());
        return riskBlackRsp;
    }

    @Override
    public Boolean importExcel(RiskBlackImportRequest.RiskBlackImport importRequest) {
        int type = importRequest.getType();
        TRiskBlackOperation mainLog = TRiskBlackOperation.builder().
                opMode(type).
                status(RiskBlackOpStatusEnum.IN_PROGRESS.getCode()).
                operator(importRequest.getDataModifier()).
                build();
        boolean isSuccess = riskBlackOperationMapper.insert(mainLog) > 0;
        if (isSuccess) {
            byte[] bytes = importRequest.getContent();
            Map<String, String> mdcContextMap = LogUtils.getMDCContextMap();
            executor.submit(buildImportTask(bytes, type, mainLog,importRequest.getDataModifier(),mdcContextMap));
        }
        return true;
    }

    @Override
    public Boolean updateBlackStatus(RiskBlackUpdateRequest req) {
        boolean result;
        LambdaQueryWrapper<TRiskBlack> wrapper = buildWrapper(req);
        wrapper.select(TRiskBlack::getId,
                TRiskBlack::getLoginName,
                TRiskBlack::getSource);
        wrapper.eq(TRiskBlack::getId, req.getId());
        TRiskBlack blackInfo = getOne(wrapper);
        if (ObjectUtils.isEmpty(blackInfo)) {
            log.info("更新风控黑名单状态查询无数据,id:{}", req.getId());
            return false;
        }
        //更新黑名单主表状态
        TRiskBlack riskBlack = new TRiskBlack();
        riskBlack.setId(req.getId());
        riskBlack.setStatus(req.getStatus());
        if(Objects.equals(blackInfo.getSource().toString(),ConstantVars.TWO)){
            log.info("blackId：{}来源于pagcor，手动更新风控黑名单，来源变更为人工",req.getId());
            riskBlack.setSource(Integer.valueOf(ConstantVars.ZERO));
        }
        riskBlack.setUpdateBy(req.getDataModifier());
        riskBlack.setUpdateDate(DateUtil.now());
        // 记录操作日志
        TRiskBlackOperation mainLog = new TRiskBlackOperation();
        mainLog.setOpMode(Integer.valueOf(ConstantVars.TWO));
        mainLog.setStatus(RiskBlackOpStatusEnum.FINISHED.getCode());
        mainLog.setTotalNo(Integer.valueOf(ConstantVars.ONE));
        mainLog.setOpMode(Integer.valueOf(ConstantVars.TWO));
        mainLog.setOperator(req.getDataModifier());
        mainLog.setRemark("修改账户:" + blackInfo.getLoginName() + "的状态");
        mainLog.setSuccessNo(Integer.valueOf(ConstantVars.ONE));
        mainLog.setFailureNo(Integer.valueOf(ConstantVars.ZERO));
        try {
            log.info("黑名单更新状态，入参：{}",JSON.toJSONString(riskBlack));
            updateById(riskBlack);
            clearCache(blackInfo.getLoginName());
            result = true;
        } catch (Exception e) {
            log.error("{} 更新风控黑名单状态时异常! msg:{}", req.getId(), e.getMessage(), e);
            mainLog.setSuccessNo(Integer.valueOf(ConstantVars.ZERO));
            mainLog.setFailureNo(Integer.valueOf(ConstantVars.ONE));
            result = false;
        } finally {
            riskBlackOperationService.save(mainLog);
        }
        return result;
    }

    private Runnable buildImportTask(byte[] bytes, Integer type, TRiskBlackOperation mainLog,String operatorName,Map<String, String> mdcContextMap) {
        return () -> {
            LogUtils.setMDCContextMap(mdcContextMap);
            Integer errorCount=0;
            try {
                RiskBlackImportPO.BlackImportContext context = this.collectDates(bytes, type, mainLog.getId(),operatorName);
                if(context.getBlacks()==null && context.getReLogDetails()==null && context.getImLogDetails()==null ){
                    mainLog.setStatus(Integer.valueOf(TWO));
                }else {
                    mainLog.setStatus(Integer.valueOf(ONE));
                    if(RiskImportModelEnum.IMPORT_MODE.getType().equals(type)){
                        mainLog.setTotalNo(context.getTotalCount());
                        int successNo = context.getImLogDetails().stream().filter(x->x.getOperationStatus().equals(Integer.valueOf(ConstantVars.ONE))).collect(Collectors.toList()).size();
                        mainLog.setSuccessNo(successNo);
                        mainLog.setFailureNo(context.getTotalCount() >= successNo ? context.getTotalCount()-successNo : 0);
                    }
                    if(RiskImportModelEnum.ASSOCIATION_MODE.getType().equals(type)){
                        mainLog.setTotalNo(context.getTotalCount());
                        int successNo = context.getReLogDetails().keySet().stream().filter(x->x.getOperationStatus().equals(Integer.valueOf(ConstantVars.ONE))).collect(Collectors.toList()).size();
                        mainLog.setSuccessNo(successNo);
                        mainLog.setFailureNo(context.getTotalCount() >= successNo ? context.getTotalCount()-successNo : 0);
                    }
                }
                log.info("导入前收集数据 imLogDetails size：{},blacks size:{},reLogDetails size:{}",
                        CollectionUtil.size(context.getImLogDetails()), CollectionUtil.size(context.getBlacks()),CollectionUtil.size(context.getReLogDetails()));
                log.info("导入前日志主表：{}", JSON.toJSONString(mainLog));
                // 执行导入操作
                riskBlackDoImportService.doImports(context);
            } catch (Exception e) {
                log.error("风控黑名单异步导入操作发生错误，e:", e);
                errorCount=totalCount(bytes,type);
                mainLog.setStatus(Integer.valueOf(ConstantVars.TWO));
                mainLog.setTotalNo(errorCount);
                mainLog.setSuccessNo(Integer.valueOf(ConstantVars.ZERO));
                mainLog.setFailureNo(errorCount);
            } finally {
                // 日志明细入库成功，记录导入日志
                try {
                    log.info("风控黑名单插入主表后更新日志主表的入参：{}",JSON.toJSONString(mainLog));
                    riskBlackOperationMapper.updateById(mainLog);
                }catch (Exception e){
                    log.error("风控黑名单异步导入操作,更新日志主表发生错误，e:", e);
                }
            }
        };
    }

    private  int totalCount(byte[] bytes, Integer type){
        List<RiskBlackImportPO.ImportMode> imports;
        List<RiskBlackImportPO.AssociationMode> accImports;
        int count=0;
        InputStream inputStream = new ByteArrayInputStream(bytes);
        try{
            if(RiskImportModelEnum.ASSOCIATION_MODE.getType().equals(type)) {
                accImports = ExcelUtils.read(inputStream, RiskBlackImportPO.AssociationMode.class);
                count=accImports.stream().filter(Objects::nonNull).collect(Collectors.toList()).size();
            } else {
                imports = ExcelUtils.read(inputStream, RiskBlackImportPO.ImportMode.class);
                count=imports.stream().filter(Objects::nonNull).collect(Collectors.toList()).size();
            }

        } catch (Exception e) {
            log.error("解析文件失败", e);
            throw new BusinessException(READ_EXCEL_FAIL);
        }
        return  count;
    }

    /**
     * 通过file和type收集明细
     *
     * @param bytes
     * @param type
     * @return
     * @throws Exception
     */
    private RiskBlackImportPO.BlackImportContext collectDates(byte[] bytes, Integer type, BigInteger mainLogId, String operatorName) {
        RiskBlackImportPO.BlackImportContext context = new RiskBlackImportPO.BlackImportContext();
        if (RiskImportModelEnum.IMPORT_MODE.getType().equals(type)) {
            // 导入模式收集
            List<RiskBlackImportPO.ImportMode> imports;
            try (InputStream inputStream = new ByteArrayInputStream(bytes)) {
                imports = ExcelUtils.read(inputStream, RiskBlackImportPO.ImportMode.class);
                context.setTotalCount(imports.stream().filter(Objects::nonNull).collect(Collectors.toList()).size());
            } catch (Exception e) {
                log.error("解析文件失败", e);
                throw new BusinessException(READ_EXCEL_FAIL);
            }
            if (CollectionUtils.isEmpty(imports)) {
                return context;
            }
            imports = imports.stream().distinct().collect(Collectors.toList());
            List<TRiskBlackOperationDetail> details = RiskBlackImportConvert.INSTANT.convertImports(imports);
            populateBlacksForImportModel(context, details.stream().filter(Objects::nonNull).map(TRiskBlackOperationDetail::getLoginName).distinct()
                    .map(name->name.replaceAll("\t","")).collect(Collectors.toList()), mainLogId,operatorName);
        }
        if (RiskImportModelEnum.ASSOCIATION_MODE.getType().equals(type)) {
            // 关联模式收集
            List<RiskBlackImportPO.AssociationMode> imports;
            try (InputStream inputStream = new ByteArrayInputStream(bytes)) {
                imports = ExcelUtils.read(inputStream, RiskBlackImportPO.AssociationMode.class);
                context.setTotalCount(imports.stream().filter(Objects::nonNull).collect(Collectors.toList()).size());
            } catch (Exception e) {
                log.error("解析文件失败", e);
                throw new BusinessException(READ_EXCEL_FAIL);
            }
            if (CollectionUtils.isEmpty(imports)) {
                return context;
            }
            Map<TRiskBlackOperationDetail, List<TRiskBlackOperationAccountDetail>> detailsMap = new HashMap<>(128);
            imports.stream().filter(x->StringUtils.isNotBlank(x.getBirthday())).distinct().map(imp -> {
                RiskQueryKycRequest request = new RiskQueryKycRequest();
                request.setFirstName(imp.getFirstName());
                request.setMiddleName(imp.getMiddleName());
                request.setLastName(imp.getLastName());
                try {
                    request.setBirthday(convertDateFormat(imp.getBirthday()));
                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }
                return request;
            }).forEach(r -> {
                // 查询kyc
                TRiskBlackOperationDetail detail = RiskBlackImportConvert.INSTANT.convertRiskQuery(r);
                if (Objects.nonNull(detail)) {
                    r.setStatusList(ONE);
                    if(StringUtils.isBlank(r.getMiddleName())){
                        r.setMiddleName(null);
                    }
                    if(StringUtils.isBlank(r.getFirstName())){
                        r.setFirstName(null);
                    }
                    if(StringUtils.isBlank(r.getLastName())){
                        r.setLastName(null);
                    }

                    List<String> loginNames = collectLoginNames(r);
                    if (CollectionUtils.isEmpty(loginNames)) {
                        detail.setOperationStatus(Integer.valueOf(ConstantVars.ZERO));
                        detail.setBlackId(mainLogId);
                        detailsMap.put(detail, null);
                    } else {
                        List<TRiskBlackOperationAccountDetail> accountDetails = loginNames.stream().map(name -> TRiskBlackOperationAccountDetail.builder().loginName(name).build()).collect(Collectors.toList());
                        if (CollectionUtils.isEmpty(accountDetails)) {
                            detail.setOperationStatus(Integer.valueOf(ConstantVars.ZERO));
                        } else {
                            detail.setOperationStatus(Integer.valueOf(ConstantVars.ONE));
                        }
                        detail.setBlackId(mainLogId);
                        detailsMap.put(detail, accountDetails.stream().distinct().collect(Collectors.toList()));
                    }
                }
            });
            context.setReLogDetails(detailsMap);
            populateBlacksForAssociationModel(context, detailsMap.values().stream().filter(e -> !CollectionUtils.isEmpty(e)).flatMap(detail ->
                    detail.stream().map(TRiskBlackOperationAccountDetail::getLoginName)).distinct().collect(Collectors.toList()),operatorName);
        }

        return context;
    }

    /**
     * 根据条件收集kyc或者ekyc的loginNames*
     *
     * @param kycRequest
     * @return
     */
    private List<String> collectLoginNames(RiskQueryKycRequest kycRequest) {
        if (Objects.nonNull(kycRequest)) {
            TEkyc ekyc = new TEkyc();
            ekyc.setStatus(EkycStatusEnum.APPROVAL.getEkycStatus());
            ekyc.setFirstName(StringUtils.isBlank(kycRequest.getFirstName()) ? StrUtil.EMPTY : kycRequest.getFirstName());
            ekyc.setMiddleName(StringUtils.isBlank(kycRequest.getMiddleName()) ? StrUtil.EMPTY : kycRequest.getMiddleName());
            ekyc.setLastName(StringUtils.isBlank(kycRequest.getLastName()) ? StrUtil.EMPTY : kycRequest.getLastName());
            ekyc.setBirthday(StringUtils.isBlank(kycRequest.getBirthday()) ? StrUtil.EMPTY : kycRequest.getBirthday());

            log.info("关联模式导入，查询ekyc用户数据入参{}", JSON.toJSONString(kycRequest));
            List<TEkyc> ekycs = ekycMapper.selectList(new LambdaQueryWrapperX<TEkyc>().
                    eq(TEkyc::getStatus, ekyc.getStatus()).
                    eq(TEkyc::getFirstName, ekyc.getFirstName()).
                    eq(TEkyc::getMiddleName, ekyc.getMiddleName()).
                    eq(TEkyc::getLastName, ekyc.getLastName()).
                    eq(TEkyc::getBirthday, ekyc.getBirthday()));
            log.info("关联模式导入，查询ekyc用户数据返回{}", JSON.toJSONString(ekycs));
            log.info("关联模式导入，查询kyc用户数据入参{}", JSON.toJSONString(kycRequest));
            List<KycRequest> kycs = kycRequestDao.queryPageByConditionAll(kycRequest);
            log.info("关联模式导入，查询kyc用户数据返回{}", JSON.toJSONString(kycs));

            List<String> loginNames = Stream.concat(
                            ekycs.stream().filter(tEkyc -> Objects.nonNull(tEkyc) && StringUtils.isNotBlank(tEkyc.getLoginName())).map(TEkyc::getLoginName),
                            kycs.stream().filter(tKyc -> Objects.nonNull(tKyc) && StringUtils.isNotBlank(tKyc.getLoginName())).map(KycRequest::getLoginName)).
                    distinct().collect(Collectors.toList());
            return loginNames;
        }
        return null;
    }

    /**
     * 导入模式下填充黑名单集合
     *
     * @param names 导入名单集
     * @return 填充后的黑名单map，key为true表示有效黑名单用户集，为false表示无效黑名单用户集
     */
    private void populateBlacksForImportModel(RiskBlackImportPO.BlackImportContext context, List<String> names, BigInteger mainLogId,String operatorName) {
        if (CollectionUtils.isEmpty(names)) {
            return;
        }
        if (Objects.isNull(context)) {
            context = new RiskBlackImportPO.BlackImportContext();
        }
        List<TRiskBlack> blacks = new ArrayList<>();
        List<TRiskBlackOperationDetail> logDetails = new ArrayList<>();
        names.stream().filter(StringUtils::isNotBlank).forEach(name -> {
            WSCustomers wsCustomers = new WSCustomers();
            String customersBank="";
            try {
                wsCustomers = wsApiFeignTemplate.getSimpleCustomerByLoginName(Constants.C66, name);
                customersBank= wsApiFeignTemplate.getSimpleCustomerByBank(name).stream().map(WSCustomersBank::getBankAccountNo).collect(Collectors.joining(ConstantVars.SEPARATOR_COMMA));
            } catch (Exception e) {
                log.error("关联模式获取用户信息和银行卡失败",e);
                throw e;
            }
            if (Objects.isNull(wsCustomers) || Objects.isNull(wsCustomers.getLoginName())) {
                // 非法用户
                logDetails.add(TRiskBlackOperationDetail.builder().loginName(name).status(Integer.valueOf(ConstantVars.ZERO)).operationStatus(Integer.valueOf(ConstantVars.ZERO)).blackId(mainLogId).build());
            } else {
                // 收集黑名单列表信息
                var blackInfo = RiskBlackImportConvert.INSTANT.convert(wsCustomers);
                blackInfo.setStatus(Integer.valueOf(ONE));
                blackInfo.setBirthday(getWsBirthDay(wsCustomers));
                blackInfo.setBankAccountNo(customersBank);
                blackInfo.setSource(Integer.valueOf(ZERO));
                PHPDESEncrypt encrypt = PHPDESEncrypt.getNewInstance(Constants.C66, SENSITIVE_TYPE.PHONE_NO.getEncryptCode());
                try {
                    if(StringUtils.isNotBlank(blackInfo.getPhoneNumber())){
                        String md5Phone =  DigestUtils.md5Hex(encrypt.decrypt(blackInfo.getPhoneNumber()));
                        blackInfo.setPhoneMd5(md5Phone);
                    } else {
                        blackInfo.setPhoneMd5("");
                    }
                } catch (Exception e) {
                    log.error("封装黑名单数据：解密手机/银行卡号异常", e);
                }
                blackInfo.setCreateBy(operatorName);
                log.info("调用ws后，复制到blackInfo：{}", JSON.toJSONString(blackInfo));
                blacks.add(blackInfo);
                // 收集历史操作明细列表信息
                var detailInfo = RiskBlackImportConvert.INSTANT.convertBlack(RiskBlackImportConvert.INSTANT.convert(wsCustomers));
                // 合法用户
                detailInfo.setOperationStatus(Integer.valueOf(ONE));
//                detailInfo.setBirthday(formatDate(wsCustomers.getBirthday()));
                detailInfo.setBirthday(getWsBirthDay(wsCustomers));
                detailInfo.setBankAccountNo(customersBank);
                detailInfo.setBlackId(mainLogId);
                log.info("调用ws后，复制到detailInfo：{}", JSON.toJSONString(detailInfo));
                logDetails.add(detailInfo);
            }
        });
        context.setBlacks(blacks);
        context.setImLogDetails(logDetails);
    }

    /**
     * 关联模式下填充
     *
     * @param context
     * @param names
     */
    private void populateBlacksForAssociationModel(RiskBlackImportPO.BlackImportContext context, List<String> names, String operatorName) {
        if (CollectionUtils.isEmpty(names)) {
            return;
        }
        if (Objects.isNull(context)) {
            context = new RiskBlackImportPO.BlackImportContext();
        }
        List<TRiskBlack> blacks = new ArrayList<>();
        names.stream().filter(StringUtils::isNotBlank).forEach(name -> {
            WSCustomers wsCustomers = new WSCustomers();
            String customersBank="";
            try {
                wsCustomers = wsApiFeignTemplate.getSimpleCustomerByLoginName(Constants.C66, name);
                customersBank=wsApiFeignTemplate.getSimpleCustomerByBank(name).stream().map(WSCustomersBank::getBankAccountNo).collect(Collectors.joining(ConstantVars.SEPARATOR_COMMA));
            } catch (Exception e) {
                log.error("关联模式获取用户信息和银行卡失败",e);
                throw e;
            }
            if (Objects.nonNull(wsCustomers)) {
                var blackInfo= RiskBlackImportConvert.INSTANT.convert(wsCustomers);
                blackInfo.setStatus(Integer.valueOf(ConstantVars.ONE));
//                blackInfo.setBirthday(formatDate(wsCustomers.getBirthday()));
                blackInfo.setBirthday(getWsBirthDay(wsCustomers));
                blackInfo.setBankAccountNo(customersBank);
                blackInfo.setSource(Integer.valueOf(ONE));
                PHPDESEncrypt encrypt = PHPDESEncrypt.getNewInstance(Constants.C66, SENSITIVE_TYPE.PHONE_NO.getEncryptCode());
                try {
                    if(StringUtils.isNotBlank(blackInfo.getPhoneNumber())){
                        String md5Phone =  DigestUtils.md5Hex(encrypt.decrypt(blackInfo.getPhoneNumber()));
                        blackInfo.setPhoneMd5(md5Phone);
                    } else {
                        blackInfo.setPhoneMd5("");
                    }
                } catch (Exception e) {
                    log.error("封装黑名单数据：解密手机/银行卡号异常", e);
                }
                blackInfo.setCreateBy(operatorName);
                log.info("调用ws后，复制到blackInfo：{}", JSON.toJSONString(blackInfo));
                blacks.add(blackInfo);
            }
        });
        context.setBlacks(blacks);
    }

    public static String formatDate(String dateStr) {
        if (dateStr != null && dateStr.length() >= 10) {
            return dateStr.substring(0, 10);
        } else {
            return "";
        }
    }

    /**
     * 获取ws生日*
     *
     * @param wsCustomers
     * @return
     */
    private String getWsBirthDay(WSCustomers wsCustomers) {
        String birthday = null;
        if (Objects.nonNull(wsCustomers)) {
            birthday = StringUtils.isNotBlank(wsCustomers.getBirthday()) ? wsCustomers.getBirthday() : wsCustomers.getBirthDate();
            birthday = formatDate(birthday);
        }
        return birthday;
    }

    /**
     * 更新warpper*
     * @param wrapper
     * @param req
     */
    private void modifyWrapper(LambdaQueryWrapper<TRiskBlack> wrapper,RiskBlackPageRequest req){
        String firstName = req.getFirstName();
        String middleName = req.getMiddleName();
        String lastName = req.getLastName();
        if(StringUtils.isNotBlank(firstName) && StringUtils.isBlank(middleName) && StringUtils.isNotBlank(lastName)){
            wrapper.eq(TRiskBlack::getMiddleName,"");
        }
    }

    /**
     * 操作完成删除缓存*
     *
     * @param loginName
     */
    private void clearCache(String loginName) {
        RedisUtils.remove(String.format(RISK_IS_BLACK_KEY, loginName));
    }
}
