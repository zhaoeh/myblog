package com.riskcontrol.office.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.riskcontrol.office.domain.entity.TKycDeduplicate;
import org.apache.ibatis.annotations.Mapper;

/**
* @author dante
* @description 针对表【t_kyc_deduplicate(kyc证件去重表)】的数据库操作Mapper
* @createDate 2024-06-11 09:51:40
* @Entity com.riskcontrol.cron.entity.TKycDeduplicate
*/
@Mapper
public interface TKycDeduplicateMapper extends BaseMapper<TKycDeduplicate> {

}




