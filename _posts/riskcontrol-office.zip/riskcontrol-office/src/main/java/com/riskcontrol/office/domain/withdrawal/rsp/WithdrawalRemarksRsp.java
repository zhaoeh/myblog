package com.riskcontrol.office.domain.withdrawal.rsp;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(title = "取款备注<br/>Withdrawal remark")
public class WithdrawalRemarksRsp {
    @Schema(description = "remarks")
    private String remarks;

    @Schema(description = "create datetime")
    private String createDate;

    @Schema(description = "creator")
    private String createBy;
}