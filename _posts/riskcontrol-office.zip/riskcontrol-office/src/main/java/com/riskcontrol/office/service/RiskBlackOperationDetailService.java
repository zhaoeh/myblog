package com.riskcontrol.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.domain.entity.TRiskBlackOperationDetail;
import com.riskcontrol.office.domain.req.black.RiskBlackOperationDetailRequest;
import com.riskcontrol.office.domain.rsp.black.RiskBlackOperationAccountDetailReRsp;
import com.riskcontrol.office.domain.rsp.black.RiskBlackOperationDetailImRsp;

import java.math.BigInteger;


/**
 * @author Heng.zhang
 */
public interface RiskBlackOperationDetailService extends IService<TRiskBlackOperationDetail> {
    /**
     * 导入模式查询历史操作记录明细表分页列表 *
     *
     * @param req -
     * @return
     */
    PageModel<RiskBlackOperationDetailImRsp> getOperationDetailImPageList(RiskBlackOperationDetailRequest req);

    /**
     * 关联模式查询历史操作记录明细表分页列表 *
     *
     * @param req -
     * @return
     */
    PageModel<RiskBlackOperationAccountDetailReRsp> getOperationDetailRePageList(RiskBlackOperationDetailRequest req);

    TRiskBlackOperationDetail getOperationDetailReInfo(BigInteger id);
}
