package com.riskcontrol.office.service;

import com.cn.schema.customers.WSKycSheetRequest;
import com.riskcontrol.common.entity.request.QueryPageByKycRequestId;
import com.riskcontrol.common.entity.request.api.QueryKycRequestReq;
import com.riskcontrol.common.entity.request.api.UpdateKycRequestReq;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequest;
import com.riskcontrol.common.entity.request.kyc.WSKycRequestGw;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelRsp;
import com.riskcontrol.office.domain.constans.req.UpdateCustomerRiskLabelReq;
import com.riskcontrol.office.domain.customers.req.KycSheetRequest;
import com.riskcontrol.office.domain.customers.req.QueryCustomerByLoginNameReq;
import com.riskcontrol.office.domain.customers.req.QueryCustomersReq;
import com.riskcontrol.office.domain.customers.req.QueryParentAccountReq;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * C66 office
 */
public interface ICustomersService {
    /**
     * 查询KYC列表信息（KYC审批通过的数据则 不过滤 ASSIGNEE_BY"分配的审核人员"）
     * @param req
     * @return
     * @throws Exception
     */
    Response<PageModel<WSKycRequestGw>> queryKycRequestsNewRisk(QueryKycRequestReq req);

    Response<PageModel<KycSheetRequest>> queryKycSheetRequestsRisk(QueryKycRequestReq req);
    /**
     * 查询（导出）KYC信息
     * @param req
     * @return
     */
    Boolean updatePbcRequestRisk(UpdateKycRequestReq req);
    Response queryPageByKycRequestIdRisk(QueryPageByKycRequestId req);
    /**
     * 风控审核KYC*
     * @param req req
     * @return
     */
    Boolean updateKycRequestRisk(UpdateKycRequestReq req);


    Response uploadPBCInfoBatchNewRisk(MultipartFile files, HttpServletRequest baseReq) throws Exception;

    Response queryCustomerByLoginName(QueryCustomerByLoginNameReq req) throws Exception;

    Response<CustomerRiskLabelRsp> queryRiskLabel(QueryCustomersReq req);

    Boolean modifyRiskLabel(UpdateCustomerRiskLabelReq req);

    int queryKycRequestCount(RiskQueryKycRequest req);

}
