package com.riskcontrol.office.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.domain.entity.TRiskLabelOperationLog;
import com.riskcontrol.office.domain.req.RiskLabelOperationPageRequest;
import com.riskcontrol.office.mapper.TRiskLabelOperationLogMapper;
import com.riskcontrol.office.service.TRiskLabelOperationLogService;
import org.springframework.stereotype.Service;


@Service
public class TRiskLabelOperationLogServiceImpl extends BaseServiceImpl<TRiskLabelOperationLogMapper, TRiskLabelOperationLog> implements TRiskLabelOperationLogService {


    @Override
    public PageModel<TRiskLabelOperationLog> getOperationList(RiskLabelOperationPageRequest req) {
        LambdaQueryWrapper<TRiskLabelOperationLog> wrapper = buildWrapper(req);
        wrapper.orderByDesc(TRiskLabelOperationLog::getCreateDate);
        Page<TRiskLabelOperationLog> page = pageByWrapper(req, wrapper);
        PageModel<TRiskLabelOperationLog> pageResult = new PageModel<>();
        pageResult.setData(page.getRecords());
        pageResult.setPageNo((int) page.getCurrent());
        pageResult.setPageSize((int) page.getSize());
        pageResult.setTotalRow((int) page.getTotal());
        pageResult.setTotalPage((int) page.getPages());
        return pageResult;
    }
}
