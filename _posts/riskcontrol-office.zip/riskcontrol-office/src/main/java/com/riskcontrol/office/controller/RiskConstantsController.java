package com.riskcontrol.office.controller;

import com.digiplus.oms.aspect.annotation.PreAuthorize;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.annotation.EnableOperationLog;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.entity.TRiskConstants;
import com.riskcontrol.office.domain.enums.OpTypeEnum;
import com.riskcontrol.office.domain.req.RiskConstantEditReq;
import com.riskcontrol.office.domain.req.RiskConstantReq;
import com.riskcontrol.office.domain.validation.RiskConstantCreateReqValidator;
import com.riskcontrol.office.domain.validation.RiskConstantUpdateReqValidator;
import com.riskcontrol.office.mapper.TRiskConstantsMapper;
import com.riskcontrol.office.service.TRiskConstantsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;

/**
 * @author: sanji
 * @date: 2024/03/11 16:01
 */
@RestController
@RequestMapping("/risk_constants")
@Tag(name = "风控标签设置")
//@SecurityRequirement(name = HttpHeaders.AUTHORIZATION)
@Slf4j
public class RiskConstantsController {

    @Resource
    TRiskConstantsService riskConstantsService;
    @PreAuthorize("riskConfig_labelConfig_view,riskManage_withdraw_label")
    @PostMapping("/list")
    @Operation(tags ="风控标签设置" ,summary = "查询标签列表")
    @ResponseBody
    public R<PageModel<TRiskConstants>> queryConstantList(@RequestBody RiskConstantReq req) {
        return R.ok(riskConstantsService.queryConstantList(req));
    }
    @PreAuthorize("riskConfig_labelConfig_create")
    @PostMapping("/create")
    @Operation(tags ="风控标签设置" ,summary = "创建标签")
    @ResponseBody
//    @PreAuthorize("@pms.hasPermission('risk_constants_create')")
    @EnableOperationLog(menuName="风险控制配置",subMenuName="标签设置",opLog = "创建",opLogType= OpTypeEnum.CREATE,mapperClass = TRiskConstantsMapper.class)
    public R<Boolean> create(@RequestBody @Validated(RiskConstantCreateReqValidator.class) RiskConstantEditReq req) {
        return R.ok(riskConstantsService.create(req));
    }
    @PreAuthorize("riskConfig_labelConfig_modify")
    @PostMapping("/update")
    @Operation(tags ="风控标签设置" ,summary = "根据id修改标签配置")
    @ResponseBody
//    @PreAuthorize("@pms.hasPermission('risk_constants_update')")
    @EnableOperationLog(menuName="风控配置",subMenuName="标签设置",opLog = "更新",opLogType= OpTypeEnum.UPDATE,mapperClass = TRiskConstantsMapper.class)
    public R<Boolean> update(@RequestBody @Validated(RiskConstantUpdateReqValidator.class) RiskConstantEditReq req) {
        return R.ok(riskConstantsService.updateById(req));
    }
    @PreAuthorize("riskConfig_labelConfig_delete")
    @PostMapping("/delete/{id}")
    @Operation(tags ="风控标签设置" ,summary = "删除标签")
    @ResponseBody
//    @PreAuthorize("@pms.hasPermission('risk_constants_delete')")
    @EnableOperationLog(menuName="风控配置",subMenuName="标签设置",opLog = "删除",opLogType= OpTypeEnum.DELETE,mapperClass = TRiskConstantsMapper.class)
    public R<Boolean> delete(@PathVariable @NotNull @Validated BigInteger id) {
        return R.ok(riskConstantsService.deleteById(id));
    }

    @PreAuthorize("riskConfig_labelConfig_status")
    @PostMapping("/enable/{id}")
    @Operation(tags ="风控标签设置" ,summary = "启用标签")
    @ResponseBody
//    @PreAuthorize("@pms.hasPermission('risk_constants_delete')")
    @EnableOperationLog(menuName="风控配置",subMenuName="标签设置",opLog = "启用",opLogType= OpTypeEnum.ENABLE,mapperClass = TRiskConstantsMapper.class)
    public R<Boolean> enable(@PathVariable @NotNull @Validated BigInteger id) {
        RiskConstantEditReq req = new RiskConstantEditReq();
        req.setId(id);
        req.setIsEnable(1);
        return R.ok(riskConstantsService.updateById(req));
    }
    @PreAuthorize("riskConfig_labelConfig_status")
    @PostMapping("/disable/{id}")
    @Operation(tags ="风控标签设置" ,summary = "禁用标签")
    @ResponseBody
//    @PreAuthorize("@pms.hasPermission('risk_constants_delete')")
    @EnableOperationLog(menuName="风控配置",subMenuName="标签设置",opLog = "禁用",opLogType= OpTypeEnum.DISABLE,mapperClass = TRiskConstantsMapper.class)
    public R<Boolean> disable(@PathVariable @NotNull @Validated BigInteger id) {
        RiskConstantEditReq req = new RiskConstantEditReq();
        req.setId(id);
        req.setIsEnable(0);
        return R.ok(riskConstantsService.updateById(req));
    }

}
