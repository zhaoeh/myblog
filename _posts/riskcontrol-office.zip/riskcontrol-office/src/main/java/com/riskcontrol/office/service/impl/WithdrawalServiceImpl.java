package com.riskcontrol.office.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import com.agent.algorithm.entity.customer.QueryAgentCustomers;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cn.schema.agent.WSAgentTrans;
import com.cn.schema.agent.WSQueryAgentTrans;
import com.cn.schema.customers.WSCustomers;
import com.cn.schema.products.WSProductConstants;
import com.cn.schema.request.*;
import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.gw.datacenter.vo.order.OrderReq;
import com.gw.datacenter.vo.order.OrderSummaryNew;
import com.gw.datacenter.vo.pagainate.QueryResult;
import com.gw.datacenter.vo.pagainate.QueryResultWrapper;
import com.riskcontrol.common.client.LogApiFeign;
import com.riskcontrol.common.client.MessageApiFeign;
import com.riskcontrol.common.config.UserCenterSwitch;
import com.riskcontrol.common.entity.request.QueryLoginInfoReq;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelListRequest;
import com.riskcontrol.common.entity.request.message.PushContentReq;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.entity.response.QueryLoginInfoRsp;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.Result;
import com.riskcontrol.common.entity.response.kyc.RiskQueryKycRequestResponse;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelRsp;
import com.riskcontrol.common.service.GdApiFeignTemplate;
import com.riskcontrol.common.service.UserCenterTemplate;
import com.riskcontrol.common.service.WsFeignTemplate;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.common.utils.PHPDESEncrypt;
import com.riskcontrol.office.common.BaseService;
import com.riskcontrol.office.common.constants.APPROVE_TYPE;
import com.riskcontrol.office.common.constants.AccountTypeCatalog;
import com.riskcontrol.office.common.constants.ConstantVars;
import com.riskcontrol.office.common.constants.Constants;
import com.riskcontrol.office.common.enums.ErrorCodeEnum;
import com.riskcontrol.office.config.NacosConfig;
import com.riskcontrol.office.domain.enums.RejectReasonEnums;
import com.riskcontrol.office.domain.withdrawal.req.*;
import com.riskcontrol.office.domain.withdrawal.rsp.ReviewWithdrawalRequestRsp;
import com.riskcontrol.office.domain.withdrawal.rsp.WithdrawalRemarksRsp;
import com.riskcontrol.office.service.IWithdrawalService;
import com.riskcontrol.office.service.TRiskLabelRelationshipService;
import com.riskcontrol.office.template.RiskControlApiTemplate;
import com.riskcontrol.office.template.SmsApiTemplate;
import com.riskcontrol.office.util.AESCrypt;
import com.riskcontrol.office.util.RedisUtils;
import com.riskcontrol.office.util.aws.AWSS3Util;
import com.ws.SmsContent;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.text.MessageFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class WithdrawalServiceImpl extends BaseService implements IWithdrawalService {
    /**
     * 存款提案类型: 99=现金存款
     */
    private static final String CATA_LOG_CASH = "99";
    private static final String WITHDRAWAL_REVIEW_CACHE_KEY = "withdrawal_review_{0}_{1}";
    /**
     * REQUEST TYPE:02---WITHDRAW
     */
    public static final String REQUEST_TYPE_WITHDRAWAL = "02";
    /**
     * 只有订单为这3种状态时才可以审核: 0-Pending, 9-Pending2, 1-Processing
     */
    private static final List<String> AUDITABLE_FLAGS = Arrays.asList("0", "9", "1");
    private static final List<String> PARENT_LIMIT = Arrays.asList("SLS", "SLS1");
    @Resource
    private WsFeignTemplate wsTemplate;
    @Resource
    private UserCenterTemplate userCenterTemplate;
    @Resource
    private RiskControlApiTemplate riskControlApiTemplate;
    @Resource
    private SmsApiTemplate smsApiTemplate;
    @Resource
    private MessageApiFeign messageApiFeign;
    @Resource
    private LogApiFeign logApiFeign;
    @Resource
    private GdApiFeignTemplate gdApiFeignTemplate;
    @Resource
    private TRiskLabelRelationshipService riskLabelRelationshipService;
    @Value("${C66.push.exchange:exchange_template_job_message}")
    private String pushExchange;
    @Value("${C66.push.routing.key:C66.routing.template.job.message.queue}")
    private String pushRoutingKey;
    @Value("${C66.sms.push.enable:false}")
    private boolean enableSmsAndPush;

    private final ExecutorService executorService = Executors.newFixedThreadPool(5);

    @Resource
    private AWSS3Util awss3Util;

    @Override
    public Response queryList(HttpServletRequest request, QueryWithdrawalListReq req) {
        log.info("withdraw的渠道属性：" + req.getChanelType());
        Response<PageModel<JSONObject>> rsp = new Response<>();
        if (null == req.getPageNo()) {
            req.setPageNo(1);
        }

        if (null == req.getPageSize()) {
            req.setPageSize(20);
        }


        //C66 如果没有传状态,查询C66取款6种状态
        /*
         * 0: Waiting
         * 1: Processing
         * 2: Approved
         * 9: Pending2
         * -2: Canceled
         * -3: Rejected
         */
        if (StringUtils.isEmpty(req.getFlag())) {
            req.setFlag("0;1;2;9;-2;-3");
        }

        //默认包含ALL

        req.setBranchCode(StringUtils.isBlank(req.getBranchCode()) || "ALL".equals(req.getBranchCode()) ? "" : "ALL;" + req.getBranchCode());

        req.setParent(req.getParent());
        //时间必传
        if ((StrUtil.isEmpty(req.getProcessedDateBegin()) || StrUtil.isEmpty(req.getProcessedDateEnd()))
                && (StrUtil.isEmpty(req.getCreatedDateBegin()) || StrUtil.isEmpty(req.getCreatedDateEnd()))) {
            rsp.setHead(ErrorCodeEnum.DATE_MUST_NOT_BLANK.getErrHead());
            return rsp;
        }

        WSQueryWithdrawalRequests query = new WSQueryWithdrawalRequests();
        query.setAssigneeBy(req.getAssigneeBy());
        query.setAssigneeDateBegin(req.getAssigneeDateBegin());
        query.setAssigneeDateEnd(req.getAssigneeDateEnd());
        query.setSecondAssigneeTimeDateBegin(req.getSecondAssigneeTimeDateBegin());
        query.setSecondAssigneeTimeDateEnd(req.getSecondAssigneeTimeDateEnd());

        query.setPageSize(req.getPageSize());
        query.setPageNum(req.getPageNo());
        query.setProductId(req.getProductId());
        query.setLoginName(req.getCustomerName() != null ? req.getCustomerName().toLowerCase() : null);
        query.setBranchCode(req.getBranchCode());

        query.setCreatedBy(req.getCreatedBy() != null ? req.getCreatedBy().toLowerCase() : null);
        query.setCreatedDateBegin(req.getCreatedDateBegin());
        query.setCreatedDateEnd(req.getCreatedDateEnd());
        query.setAmountStart(req.getAmountStart());
        query.setAmountEnd(req.getAmountEnd());
        query.setFirstWithdrawal(req.getFirstWithdrawal());
        query.setLastUpdatedBy(req.getProcessedBy() != null ? req.getProcessedBy().toLowerCase() : null);
        query.setLastUpdateBegin(req.getProcessedDateBegin());
        query.setLastUpdateEnd(req.getProcessedDateEnd());
        query.setCatalog(req.getCatalog());// 改为可以从前端控制
        if (req.getParent() != null && req.getParent().length > 0) {
            List<String> parents = Arrays.asList(req.getParent());
            if (!parents.contains("ALL")) {
                query.setParent(String.join(";", parents));
            }
        }
        if (Objects.nonNull(req.getSiteId())) {
            query.setSiteId(req.getSiteId());
        }
//        String chanelType = CommonUtils.parentAccountScript("p.login_name", req.getProductId(), req.getChanelType());
//        query.setParentAccount(chanelType);
        query.setFlag(req.getFlag());
        query.setRequestId(req.getRequestId());
        query.setTransSiteId(req.getTransSiteId());
        if (Objects.isNull(query.getOrder())) {
            query.setOrder("decode");
        }
        WSQueryCountAmount wsQueryCountAmount = wsTemplate.queryWithdrawalCount(query);
        int count = Integer.parseInt(wsQueryCountAmount.getCount());
        List<WSWithdrawalRequests> result = wsTemplate.queryWithdrawalList(query);
        List<JSONObject> rsps = new ArrayList<>();
        if (BaseService.PRODUCT_ID_C66.equalsIgnoreCase(req.getProductId()) && !CollectionUtils.isEmpty(result)) {
            List<String> chanelTypeList = new ArrayList<>(Arrays.asList(ConstantVars.ONE, ConstantVars.THREE, ConstantVars.FOUR, ConstantVars.FIVE));
            if (StringUtils.isNotBlank(req.getChanelType()) && !req.getChanelType().contains(ConstantVars.TWO)) {
                chanelTypeList.retainAll(Arrays.asList(req.getChanelType().split(ConstantVars.SEMICOLON)));
            }

            QueryAgentCustomers queryAgentCustomers = new QueryAgentCustomers();
            // query agent type
            List<Long> customerIds = result.stream().map(wr -> Long.valueOf(wr.getCustomerId())).collect(Collectors.toList());
            queryAgentCustomers.setCustomerIds(customerIds);
            queryAgentCustomers.setPageSize(customerIds.size());

            RiskLabelListRequest listRequest = new RiskLabelListRequest();
            listRequest.setCustomerIds(customerIds);
            Future<List<CustomerRiskLabelRsp>> riskLabelFuture = executor.submit(() -> riskLabelRelationshipService.listCustomerRiskLabel(listRequest));
            List<CustomerRiskLabelRsp> riskLabelResult;
            try {
                riskLabelResult = riskLabelFuture.get(5, TimeUnit.SECONDS);
            } catch (Exception ignored) {
                riskLabelResult = new ArrayList<>();
            }
            final Map<String, JSONObject> riskLabelMap = new HashMap<>();
            riskLabelResult.forEach(rl -> {
                JSONObject rl0 = JSON.parseObject(JSON.toJSONString(rl));
                JSONArray riskLabels = rl0.getJSONArray("riskLabels");
                riskLabelMap.put(rl0.getString("customerId"), CollectionUtils.isEmpty(riskLabels) ? null : riskLabels.getJSONObject(0));
            });

            for (WSWithdrawalRequests wsWithdrawalRequests : result) {
                // 线上取款设置门店为 -
                if (wsWithdrawalRequests.getCatalog().equals(Constants.ZERO)) {
                    wsWithdrawalRequests.setWithdrawBranchName("-");
                }

//                String bankAccountName = null;
//                try {
//                    bankAccountName = PHPDESEncrypt.getNewInstance(req.getProductId(), "06").decrypt(wsWithdrawalRequests.getBankAccountName());
//                } catch (Exception e) {
//                    throw new RuntimeException(e);
//                }
                Integer siteId = wsWithdrawalRequests.getSiteId();
                String productVal = "";
                if (siteId != null) {
                    int productValue = siteId.intValue();
                    if (productValue == 2) {
                        productVal = "bingoplus2";
                    } else if (productValue == 3) {
                        productVal = "gameplus";
                    } else if (productValue == 4) {
                        productVal = "peryagame";
                    } else {
                        productVal = "bingoplus";
                    }
                }
                wsWithdrawalRequests.setBankAccountName(wsWithdrawalRequests.getBankAccountName());
                wsWithdrawalRequests.setBankAccountNo(wsWithdrawalRequests.getBankAccountNo());
                JSONObject jsonObject = JSONObject.parseObject(JSONObject.toJSONString(wsWithdrawalRequests))
                        .fluentPut("flagDesc", flagToFlagDesc(wsWithdrawalRequests.getFlag(), req.getLang()))
                        .fluentPut("product", productVal);
                JSONObject riskLabel = riskLabelMap.get(wsWithdrawalRequests.getCustomerId());
                if (riskLabel != null) {
                    jsonObject.put("riskLabelName", riskLabel.getString("riskLabelName"));
                    jsonObject.put("riskLabelId", riskLabel.getString("riskLabelId"));
                }
                jsonObject.putIfAbsent("chanelType", ConstantVars.TWO);
                jsonObject.put("accountType", -1);
                rsps.add(jsonObject);
            }
        }

        PageModel<JSONObject> page = new PageModel<>(count, req.getPageNo(), req.getPageSize());
        page.setStatistics(wsQueryCountAmount);
        page.setData(rsps);
        rsp.setBody(page);

        return rsp;
    }

    @Override
    public Response<String> approve(HttpServletRequest request, WithdrawalApproveReq req) {
        Response<String> response = new Response<>();
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        String operator = "";
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            operator = userInfoVO.getUserInfo().getUsername();
        }
        //审批人不能为空
        if (StringUtils.isEmpty(operator)) {
            response.setHead(ErrorCodeEnum.REVIEWER_MUST_NOT_BLANK.getErrHead());
            return response;
        }


        WSQueryWithdrawalRequests query = new WSQueryWithdrawalRequests();
        query.setProductId(req.getProductId());
        query.setRequestId(req.getRequestId());
        query.setCatalog(CATA_LOG_CASH);
        List<WSWithdrawalRequests> result = wsTemplate.queryWithdrawalList(query);
        if (result == null || result.isEmpty()) {
            response.setHead(ErrorCodeEnum.PROPOSALID_NOT_EXIST.getErrHead());
            return response;
        }

        //创建人与审核人不能为同一个人
        WSWithdrawalRequests withdrawalRequests = result.get(0);
        if (operator.equalsIgnoreCase(withdrawalRequests.getCreatedBy())) {
            response.setHead(ErrorCodeEnum.CREATOR_AND_APPROVER_ERROR.getErrHead());
            return response;
        }

        //取款提案审批为处理中 flag 0->1
        WSRequestsApprove wsRequestsApprove = new WSRequestsApprove();
        wsRequestsApprove.setRequestId(req.getRequestId());
        wsRequestsApprove.setIpAddress(req.getIpAddress());
        wsRequestsApprove.setRequestType(APPROVE_TYPE.WITHDRAW_TYPE.getCode());
        wsRequestsApprove.setUserType(Constants.USER_TYPE);
        wsRequestsApprove.setApproveBy(operator);
        if (StringUtils.isNotBlank(req.getReviewTime())) {
            wsRequestsApprove.setReviewTime(req.getReviewTime());
        }
        wsRequestsApprove.setOldflag(withdrawalRequests.getFlag());
        String newFlag;
        // 一审通过 1
        if (Constants.APPROVED_FLAG.equals(req.getFlag()) && Constants.PENDING_FLAG.equals(withdrawalRequests.getFlag())) {
            newFlag = Constants.APPROVED_WAIT;
            // 二审拒绝 -3
        } else if (Constants.APPROVE_TYPE_CANCLE.equals(req.getFlag()) && Constants.APPROVED_WAIT.equals(withdrawalRequests.getFlag())) {
            newFlag = Constants.REJECT_FLAG;
        } else {
            newFlag = req.getFlag();
        }
        wsRequestsApprove.setNewflag(newFlag);
        wsRequestsApprove.setIpAddress(req.getIpAddress());
        final String remarks = req.getRemarks();
        // 备注占位
        wsRequestsApprove.setRemarks(StringUtils.isBlank(withdrawalRequests.getRemarks()) ? "-," + remarks : remarks);

        //取款提案审批成功后 审批为完成 flag 1->2
        List<WSResponseApprove> approves = wsTemplate.approveWithdrawal(req.getProductId(), wsRequestsApprove);


        if (Constants.APPROVED_FLAG.equals(req.getFlag()) && !approves.isEmpty()) {
            wsRequestsApprove.setOldflag(Constants.FLAG_STR_ONE); //旧状态为1
            wsRequestsApprove.setNewflag(Constants.FLAG_STR_TWO); //新状态为2
            wsRequestsApprove.setRemarks(remarks);
            approves = wsTemplate.approveWithdrawal(req.getProductId(), wsRequestsApprove);
            if (Objects.isNull(approves)) {
                log.warn("取款失败！{}", req);
                response.setHead(ErrorCodeEnum.ERROR_WITHDRAW_FAILED.getErrHead());//取款失败
                return response;
            }
            response.setBody(Constants.WITHDRAW_HAS_APPROVED); //取款批准
        }

        if (approves != null && Constants.APPROVE_TYPE_CANCLE.equals(req.getFlag())) { //取款拒绝
            response.setBody(Constants.WITHDRAW_HAS_DENIED);
        } else if (approves != null && Constants.APPROVE_TYPE_APPROVE.equals(wsRequestsApprove.getNewflag())) {
            response.setBody(Constants.WITHDRAW_HAS_APPROVED);
        }
        return response;
    }

    @Override
    public Response auditWithdrawalRequest(WithdrawalRequestReq req, boolean isReject) throws Exception {
        Response<Boolean> response = new Response<>();
        final String productId = req.getProductId();
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        String operator;
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            operator = userInfoVO.getUserInfo().getUsername();
        } else {
            operator = "";
        }
        final String requestIds = req.getRequestId();
        final String oldFlag = req.getFlag();
        final String remark = req.getRemark();

        // 获取当前审核人信息
        String cacheKey = MessageFormat.format(WITHDRAWAL_REVIEW_CACHE_KEY, productId, requestIds);
        String reviewer = RedisUtils.get(cacheKey, String.class);
        if (StringUtils.isNotBlank(reviewer) && !operator.equalsIgnoreCase(reviewer)) {
            response.setHead(ErrorCodeEnum.ERROR_WITHDRAW_REVIEW_BY_OTHER.getHead(reviewer));
            return response;
        }

        try {
            String[] split = requestIds.split(";");
            for (String requestId : split) {
                // 获取此笔取款订单的信息
                WSQueryWithdrawalRequests queryWithdrawalRequests = new WSQueryWithdrawalRequests();
                queryWithdrawalRequests.setProductId(productId);
                queryWithdrawalRequests.setRequestId(requestId);
                queryWithdrawalRequests.setDeleteFlag("0");
                List<WSWithdrawalRequests> withdrawalRequestsList = wsTemplate.queryWithdrawalList(queryWithdrawalRequests);
                if (withdrawalRequestsList == null || withdrawalRequestsList.isEmpty()) {
                    response.setHead(ErrorCodeEnum.ERROR_WITHDRAW_NOT_EXIST.getErrHead());
                    return response;
                }
                WSWithdrawalRequests withdrawalRequest = withdrawalRequestsList.get(0);
                String withdrawalFlag = withdrawalRequest.getFlag();
                if (!AUDITABLE_FLAGS.contains(withdrawalFlag)) {
                    response.setHead(ErrorCodeEnum.ERROR_WITHDRAW_FLAG_INCORRECT.getErrHead());
                    return response;
                }
                if (PARENT_LIMIT.contains(withdrawalRequest.getRegisterBranchName()) && "a000001".equals(withdrawalRequest.getParent()) && split.length > 1) {
                    continue;
                }

                WSProductConstants wsProductConstant = wsTemplate.getProductConstants(req.getProductId(), Constants.PRODUCT_CONSTANTS_TYPE_0004, "WITHDRAW_AUTO_APPROVE_AMOUNT");
                String withdrawApproveAmount = wsProductConstant != null && StringUtils.isNotEmpty(wsProductConstant.getValue()) ? wsProductConstant.getValue() : "0";

                double withdrawalAmount = Double.parseDouble(withdrawalRequest.getAmount());
                String accountType = AccountTypeCatalog.getByAccountType(withdrawalRequest.getCatalog());

                String newFlag = "";
                switch (withdrawalFlag) {
                    case Constants.FLAG_STR_ZERO:// 当旧提案状态为0时: -2（Cancel by office）, -1（Cancel by player）, 9（1st Approve）, 1（Processing）
                        if (isReject) {
                            newFlag = Constants.APPROVE_TYPE_CANCLE;
                        } else if (!CATA_LOG_CASH.equals(withdrawalRequest.getCatalog()) && withdrawalAmount >= Double.parseDouble(withdrawApproveAmount)) {
//                            newFlag = Constants.APPROVE_TYPE_FIRST_APPROVE;
                            //当取款金额大于配置金额时需要门店先审核才能进风控
                            response.setHead(ErrorCodeEnum.ERROR_APPROVE_WITHDRAW.getErrHead());
                            return response;
                        } else {
                            newFlag = Constants.FLAG_STR_ONE;
                        }
                        break;
                    case Constants.FLAG_STR_NINE:// 当旧提案状态为9时: -2（Cancel by office）, -1（Cancel by player）, 1（Processing）
                        newFlag = isReject ? Constants.APPROVE_TYPE_CANCLE : Constants.FLAG_STR_ONE;
                        break;
                    case Constants.FLAG_STR_ONE:// 当旧提案状态为1时: -3（Reject）, 2（done）
                        newFlag = isReject ? Constants.APPROVE_TYPE_REJECT : Constants.APPROVE_TYPE_APPROVE;
                        break;
                }

                Long ttp = RedisUtils.ttp(cacheKey);

                WSRequestsApprove wsRequestsApprove = new WSRequestsApprove();
                wsRequestsApprove.setRequestId(requestId);
                wsRequestsApprove.setRequestType(REQUEST_TYPE_WITHDRAWAL);
                wsRequestsApprove.setUserType(Constants.USER_TYPE);

                wsRequestsApprove.setApproveBy(operator);
                wsRequestsApprove.setIpAddress(req.getIpAddress());
                wsRequestsApprove.setDeductAmount(Constants.ZERO);
                wsRequestsApprove.setRemarks(remark);
                if (StringUtils.isNotBlank(req.getReviewTime())) {
                    wsRequestsApprove.setReviewTime(req.getReviewTime());
                } else if (ttp != null && ttp > 0) {
                    long l = LocalDateTime.now().toEpochSecond(ZoneOffset.of("+8")) - (60 * 10 - ttp);
                    wsRequestsApprove.setReviewTime(LocalDateTime.ofInstant(Instant.ofEpochSecond(l), ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                }
                if (split.length > 1) {
                    wsRequestsApprove.setOldflag(Constants.ZERO);
                } else {
                    wsRequestsApprove.setOldflag(oldFlag);
                }
                wsRequestsApprove.setNewflag(newFlag);

                if (isReject) {
                    wsRequestsApprove.setRejectionReason(req.getRejectionReason());
                }

                List<WSResponseApprove> wsResponseApproves = wsTemplate.approveWithdrawal(productId, wsRequestsApprove);
                if (wsResponseApproves == null || wsResponseApproves.isEmpty()) {
                    response.setHead(ErrorCodeEnum.ERROR_WITHDRAW_FAILED.getErrHead());
                    return response;
                }
                // 取款失败发送短信
                if (isReject) {
                    String playerName = withdrawalRequest.getLoginName();
                    WSCustomers wsCustomer;
                    if (UserCenterSwitch.getSwitch()) {
                        wsCustomer = userCenterTemplate.getSimpleCustomerByLoginName(productId, playerName);
                    } else {
                        wsCustomer = wsTemplate.getCustomerByLoginName(productId, playerName);
                    }
                    //获取对应产线和短信模板Id
                    Map<String, String> productSwitchMap = redisUtils.entries("r-0013");
                    if (!productSwitchMap.isEmpty()) {
                        //获取产品全称
                        Map<String, String> productMap = redisUtils.entries("r-0017");
                        String product = "BingoPlus";
                        for (Map.Entry<String, String> entry : productMap.entrySet()) {
                            String key = entry.getKey();
                            String value = entry.getValue();
                            if (value.contains(withdrawalRequest.getTenant())) {
                                product = key;
                            }
                        }
                        log.info("失败短信触达 产品：{}",JSON.toJSONString(productSwitchMap));
                        if (productSwitchMap.containsKey(withdrawalRequest.getTenant().concat("-SMS"))) {
                            String finalProduct1 = product;
                            CompletableFuture.runAsync(() -> sendMessage(req, requestId, productId, withdrawalAmount, wsCustomer, productSwitchMap.get(withdrawalRequest.getTenant().concat("-SMS")),withdrawalRequest.getTenant(), finalProduct1), executorService);
                        }
                        if (productSwitchMap.containsKey(withdrawalRequest.getTenant().concat("-PUSH"))) {
                            String finalProduct = product;
                            CompletableFuture.runAsync(() -> pushMessage(req, requestId, withdrawalAmount, wsCustomer, productSwitchMap.get(withdrawalRequest.getTenant().concat("-PUSH")), finalProduct), executorService);
                        }
                    }
                }
            }

        } finally {
            RedisUtils.remove(cacheKey);
        }

        response.setBody(true);
        return response;
    }

    protected void sendMessage(WithdrawalRequestReq req,  String requestId,String productId, double withdrawalAmount, WSCustomers wsCustomer, String smsTemplateType,String tenant,String product) {
        try {
            log.info("取款审核失败后发送短信 requestId:{}", requestId);
            // 玩家信息
            SmsContent sendSMS = new SmsContent();
            // 开始发送短信
            sendSMS.setPhone(PHPDESEncrypt.getNewInstance(productId, "03").decrypt(wsCustomer.getPhone()));
            sendSMS.setLoginname(wsCustomer.getLoginName());
            //取款金额
            sendSMS.setParam1(withdrawalAmount + "");
            //提示内容
//            sendSMS.setParam2(Objects.requireNonNullElse(RejectReasonEnums.getReasonByType(req.getRejectionReason()), RejectReasonEnums.OTHER).getSmsMsg());
            sendSMS.setParam2(RejectReasonEnums.getSmsReasonByType(req.getRejectionReason(),product));
            //短信类型
            sendSMS.setSmstype(smsTemplateType);
            //是否使用模板:0使用，1不使用
            sendSMS.setUseTemplateFlag(ConstantVars.ZERO);
            sendSMS.setRequestId(requestId);
            sendSMS.setTenant(tenant);
            sendSMS.setSendType(ConstantVars.getSiteIdByTenant(tenant));
            smsApiTemplate.sendSMS(productId, sendSMS);
        } catch (Exception e) {
            log.error("取款审核失败后发送短信报错", e);
        }
    }

    private void pushMessage(WithdrawalRequestReq req, String requestId, double withdrawalAmount, WSCustomers wsCustomer, String pushTemplateType,String product) {
        try {
            log.info("取款审核失败后推送Push requestId:{}", requestId);
            PushContentReq pushContentReq = new PushContentReq();
            JSONObject params = new JSONObject();
            params.put("{0}", withdrawalAmount);
            params.put("{1}", RejectReasonEnums.getPushReasonByType(req.getRejectionReason(),product));
            pushContentReq.setLoginName(wsCustomer.getLoginName());
            pushContentReq.setBillNo(requestId);
            pushContentReq.setParamId(pushTemplateType);
            pushContentReq.setData(params);
            messageApiFeign.pushMessage(pushExchange, pushRoutingKey, JSONObject.toJSONString(pushContentReq));
        } catch (Exception e) {
            log.error("取款审核失败后推送push报错", e);
        }
    }


    @Override
    public Response reviewWithdrawalRequest(ReviewWithdrawalRequestReq req) throws Exception {
        Response<ReviewWithdrawalRequestRsp> response = new Response<>();
        final String productId = req.getProductId();

        UserInfoVO userInfoVO = CurrentUserUtil.get();
        String operator = "";// req.getLoginName();
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            operator = userInfoVO.getUserInfo().getUsername();
        }
        final String requestId = req.getRequestId();
        final String oldFlag = req.getFlag();

        try {
            String cacheKey = MessageFormat.format(WITHDRAWAL_REVIEW_CACHE_KEY, productId, requestId);
            String reviewer = RedisUtils.get(cacheKey, String.class);
            if (StringUtils.isNotBlank(reviewer) && !operator.equalsIgnoreCase(reviewer)) {
                response.setHead(ErrorCodeEnum.ERROR_WITHDRAW_REVIEW_BY_OTHER.getHead(reviewer));
                return response;
            }
            // 设置当前审核人员，10分钟过期时间
            RedisUtils.set(cacheKey, operator, 60 * 10L);

            // 获取此笔取款订单的信息
            WSQueryWithdrawalRequests queryWithdrawalRequests = new WSQueryWithdrawalRequests();
            queryWithdrawalRequests.setProductId(productId);
            queryWithdrawalRequests.setRequestId(requestId);
            queryWithdrawalRequests.setDeleteFlag("0");

            final String playerName;
            String registerBranch = null;
            final String withdrawAmount;
            String bankName = null;
            String bankAccountNo = null;
            String lastWithdrawBalance = "0";
            if (req.getAgentTransReq() == 1) {
                WSQueryAgentTrans agentTransQuery = new WSQueryAgentTrans();
                agentTransQuery.setRequestNo(req.getRequestId());
                agentTransQuery.setProductId(req.getProductId());
                List<WSAgentTrans> agentTransList = wsTemplate.queryAgentTrans(agentTransQuery).getWsAgentTrans();
                if (CollectionUtils.isEmpty(agentTransList)) {
                    response.setHead(ErrorCodeEnum.ERROR_WITHDRAW_NOT_EXIST.getErrHead());
                    return response;
                }
                WSAgentTrans agentTran = agentTransList.get(0);
                String withdrawalFlag = agentTran.getStatus();
                // 判断transfer from是否在一审二审状态
                if (!StringUtils.equals(withdrawalFlag, oldFlag) || Integer.valueOf(withdrawalFlag) > 0) {
                    response.setHead(ErrorCodeEnum.ERROR_WITHDRAW_FLAG_INCORRECT.getErrHead());
                    return response;
                }

                playerName = agentTran.getLoginName();
                // TODO  branchName
                withdrawAmount = agentTran.getAmount();
            } else {
                List<WSWithdrawalRequests> withdrawalRequestsList = wsTemplate.queryWithdrawalList(queryWithdrawalRequests);
                if (withdrawalRequestsList == null || withdrawalRequestsList.isEmpty()) {
                    response.setHead(ErrorCodeEnum.ERROR_WITHDRAW_NOT_EXIST.getErrHead());
                    return response;
                }
                WSWithdrawalRequests withdrawalRequest = withdrawalRequestsList.get(0);
                String withdrawalFlag = withdrawalRequest.getFlag();
                if (!StringUtils.equals(withdrawalFlag, oldFlag) || !AUDITABLE_FLAGS.contains(oldFlag)) {
                    response.setHead(ErrorCodeEnum.ERROR_WITHDRAW_FLAG_INCORRECT.getErrHead());
                    return response;
                }
                playerName = withdrawalRequest.getLoginName();
                registerBranch = withdrawalRequest.getRegisterBranchName();
                withdrawAmount = withdrawalRequest.getAmount();
                bankName = withdrawalRequest.getBankName();
                bankAccountNo = withdrawalRequest.getBankAccountNo();
                lastWithdrawBalance = Objects.requireNonNullElse(withdrawalRequest.getLastWithDrawalBalance(), "0");
            }

            // 获取玩家信息
            WSCustomers wsCustomer;
            if (UserCenterSwitch.getSwitch()) {
                wsCustomer = userCenterTemplate.getSimpleCustomerByLoginName(productId, playerName);
            } else {
                wsCustomer = wsTemplate.getCustomerByLoginName(productId, playerName);
            }

            if (Objects.isNull(wsCustomer)) {
                response.setHead(ErrorCodeEnum.ERROR_LOGINNAME_NOTEXIST.getErrHead());
                return response;
            }


            ReviewWithdrawalRequestRsp rspBody = new ReviewWithdrawalRequestRsp();
            rspBody.setAccount(playerName);
            rspBody.setRegisterBranch(registerBranch);
            rspBody.setFirstName(wsCustomer.getFirstName());
            rspBody.setMiddleName(wsCustomer.getMiddleName());
            rspBody.setLastName(wsCustomer.getLastName());
            rspBody.setWithdrawAmount(withdrawAmount);
            String lastTotalBalance = new BigDecimal(lastWithdrawBalance).add(new BigDecimal(wsCustomer.getGameCredit())).toPlainString();
            rspBody.setLastTotalBalance(lastTotalBalance);
            rspBody.setLastLocalBalance(lastWithdrawBalance);
            rspBody.setBank(bankName);
            rspBody.setAccountNo(bankAccountNo);

            //todo 补充返回值
            rspBody.setBirthday(DateUtils.stringToDate(wsCustomer.getBirthDate()));
            rspBody.setIdNo(wsCustomer.getFirstNoType());
            //查询kyc和pbc
            RiskQueryKycRequest query = new RiskQueryKycRequest();
//            query.setPageNum(1);
            query.setPageSize(1);
            query.setStatusList(wsCustomer.getKycStatus());
            query.setLoginName(playerName);
            RiskQueryKycRequestResponse kycRequestResponse = riskControlApiTemplate.queryKycPbcRequest(query, req.getProductId());
            kycRequestResponse.getData().forEach(kycRequest -> {
                try {
                    if (StringUtils.isNotBlank(kycRequest.getIdScan())) {
                        // 脏数据处理
                        if (JSON.isValid(kycRequest.getIdScan())) {
                            String imageKey = JSON.parseObject(kycRequest.getIdScan()).getString("imageKey");
                            kycRequest.setIdScanImagekey(imageKey);
                            kycRequest.setIdScan(imageKey.startsWith("http") ? imageKey : imageKey.contains("_md5") ? awss3Util.s3GetTxtUrl(imageKey) : awss3Util.s3GetUrl(imageKey));
                            kycRequest.setIdScanV2(AESCrypt.encryptCBC(imageKey.startsWith("http") ? imageKey : imageKey.contains("_md5") ? awss3Util.s3GetTxtUrl(imageKey) : awss3Util.s3GetUrl(imageKey), "20230103aes00001", "aes0000120230103"));
                        } else {
                            kycRequest.setIdScanImagekey(kycRequest.getIdScan());
                            kycRequest.setIdScan(kycRequest.getIdScan().startsWith("http") ? kycRequest.getIdScan() : kycRequest.getIdScan().contains("_md5") ? awss3Util.s3GetTxtUrl(kycRequest.getIdScan()) : awss3Util.s3GetUrl(kycRequest.getIdScan()));
                            kycRequest.setIdScanV2(AESCrypt.encryptCBC(kycRequest.getIdScan().startsWith("http") ? kycRequest.getIdScan() : kycRequest.getIdScan().contains("_md5") ? awss3Util.s3GetTxtUrl(kycRequest.getIdScan()) : awss3Util.s3GetUrl(kycRequest.getIdScan()), "20230103aes00001", "aes0000120230103"));
                        }
                    }
                } catch (Exception e) {
                    log.info("查询用户{}的证件照失败:{}", kycRequest.getLoginName(), e);
                }
                rspBody.setIdScan(kycRequest.getIdScan());
                rspBody.setPbcStatus(kycRequest.getPbcStatus());
            });

            String withdrawalInfo = riskControlApiTemplate.queryWithdrawalInfoByRequestId(requestId, productId);
            JSONObject withdrawalJson = JSON.parseObject(withdrawalInfo);
            if (!withdrawalJson.isEmpty()) {
                rspBody.setDsAmount(withdrawalJson.getString("sumPromotionAmount"));
                rspBody.setDpAmount(withdrawalJson.getString("sumAmount"));
                rspBody.setLocalBalance(withdrawalJson.getString("dstAmount"));
                String totalBalance = new BigDecimal(withdrawalJson.getString("dstAmount")).add(new BigDecimal(wsCustomer.getGameCredit())).toPlainString();
                rspBody.setTotalBalance(totalBalance);
                rspBody.setFixAmount(withdrawalJson.getString("fixAmount"));
//                rspBody.setTotalBetAmount(withdrawalJson.getString("validAccount"));
            }

            //账号状态变更记录
            WSQueryModifyAccountRequests queryRequest = new WSQueryModifyAccountRequests();
            queryRequest.setLoginName(playerName);
            queryRequest.setAccountType(Constants.FLAG_STR_THREE);
            queryRequest.setFlag(Constants.FLAG_STR_TWO);
            queryRequest.setOrder("created_date desc");
            queryRequest.setPageNum(1);
            queryRequest.setPageSize(6);
            List<WSModifyAccountRequests> accountModifyList = wsTemplate.queryModifyAccountRecord(queryRequest, req.getProductId());
            rspBody.setAccountModifyList(accountModifyList);
            response.setBody(rspBody);
        } catch (Exception e) {
            log.info("审核取款提案异常:{}", requestId, e);
        }
        return response;
    }

    /**
     * 查询同ip用户登录记录
     *
     * @return
     */
    @Override
    public Response querySameIpCustomersByIp(QueryLoginInfoReq loginInfoReq) {
        Response response = new Response<>();
        Result<Page<QueryLoginInfoRsp>> result = logApiFeign.queryLoginInfoByIp(loginInfoReq);
        response.setBody(result.getData());
        return response;
    }

    @Override
    public Response reviewWithdrawalRequestCancel(ReviewWithdrawalRequestReq req) throws Exception {
        Response<Boolean> response = new Response<>();
        final String productId = req.getProductId();
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        String operator = "";// req.getLoginName();
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            operator = userInfoVO.getUserInfo().getUsername();
        }
        final String requestId = req.getRequestId();

        String cacheKey = MessageFormat.format(WITHDRAWAL_REVIEW_CACHE_KEY, productId, requestId);
        String reviewer = RedisUtils.get(cacheKey, String.class);
        // 只有是自己审核的订单才能关闭
        if (StringUtils.isNotBlank(reviewer) && operator.equalsIgnoreCase(reviewer)) {
            RedisUtils.remove(cacheKey);
        }

        response.setBody(true);
        return response;
    }


    @Override
    public Response queryWithdrawalRemarks(QueryWithdrawalRemarksReq req) throws Exception {
        Response<List<WithdrawalRemarksRsp>> response = new Response<>();
        final String productId = req.getProductId();
        final String requestId = req.getRequestId();

        // 获取此笔取款订单的信息
        WSQueryWithdrawalRequests queryWithdrawalRequests = new WSQueryWithdrawalRequests();
        queryWithdrawalRequests.setProductId(productId);
        queryWithdrawalRequests.setRequestId(requestId);
        queryWithdrawalRequests.setDeleteFlag("0");
        List<WSWithdrawalRequests> withdrawalRequestsList = wsTemplate.queryWithdrawalList(queryWithdrawalRequests);
        if (withdrawalRequestsList == null || withdrawalRequestsList.isEmpty()) {
            response.setHead(ErrorCodeEnum.ERROR_WITHDRAW_NOT_EXIST.getErrHead());
            return response;
        }

        WSWithdrawalRequests withdrawalRequests = withdrawalRequestsList.get(0);
        String flag = withdrawalRequests.getFlag();
        String remarks = withdrawalRequests.getRemarks();
        if (StringUtils.isBlank(remarks)) {
            response.setBody(new ArrayList<>(0));
            return response;
        }
        String[] remarksArray = remarks.split(",");
        int maxIndex = remarksArray.length - 1;

        WithdrawalRemarksRsp rsp;
        List<WithdrawalRemarksRsp> list = new ArrayList<>(remarksArray.length);
        switch (flag) {
            case Constants.APPROVED_FLAG:
            case Constants.APPROVE_TYPE_CANCLE:
            case Constants.APPROVE_TYPE_REJECT:
                rsp = new WithdrawalRemarksRsp();
                rsp.setRemarks(remarksArray[maxIndex--]);
                rsp.setCreateBy(withdrawalRequests.getLastUpdatedBy());
                rsp.setCreateDate(withdrawalRequests.getLastUpdate());
                list.add(rsp);
                if (remarksArray.length == 4) {
                    rsp = new WithdrawalRemarksRsp();
                    rsp.setRemarks(remarksArray[maxIndex--]);
                    rsp.setCreateBy(withdrawalRequests.getProcessedBy());
                    rsp.setCreateDate(withdrawalRequests.getProcessedDate());
                    list.add(rsp);

                    rsp = new WithdrawalRemarksRsp();
                    rsp.setRemarks(remarksArray[maxIndex--]);
                    rsp.setCreateBy(withdrawalRequests.getAuditBy());
                    rsp.setCreateDate(withdrawalRequests.getAuditDate());
                    list.add(rsp);
                } else if (remarksArray.length == 3) {
                    rsp = new WithdrawalRemarksRsp();
                    rsp.setRemarks(remarksArray[maxIndex--]);
                    rsp.setCreateBy(StringUtils.isNotBlank(withdrawalRequests.getProcessedBy()) ? withdrawalRequests.getProcessedBy() : withdrawalRequests.getAuditBy());
                    rsp.setCreateDate(StringUtils.isNotBlank(withdrawalRequests.getProcessedDate()) ? withdrawalRequests.getProcessedDate() : withdrawalRequests.getAuditDate());
                    list.add(rsp);
                }
                break;
            case Constants.FLAG_STR_ONE:
                rsp = new WithdrawalRemarksRsp();
                rsp.setRemarks(remarksArray[maxIndex--]);
                rsp.setCreateBy(withdrawalRequests.getProcessedBy());
                rsp.setCreateDate(withdrawalRequests.getProcessedDate());
                list.add(rsp);
                if (remarksArray.length == 3) {
                    rsp = new WithdrawalRemarksRsp();
                    rsp.setRemarks(remarksArray[maxIndex--]);
                    rsp.setCreateBy(withdrawalRequests.getAuditBy());
                    rsp.setCreateDate(withdrawalRequests.getAuditDate());
                    list.add(rsp);
                }
                break;
            case Constants.FLAG_STR_NINE:
                rsp = new WithdrawalRemarksRsp();
                rsp.setRemarks(remarksArray[maxIndex--]);
                rsp.setCreateBy(withdrawalRequests.getAuditBy());
                rsp.setCreateDate(withdrawalRequests.getAuditDate());
                list.add(rsp);
                break;
        }
        // 最后将创建时系统自动生成的备注展示出来
        rsp = new WithdrawalRemarksRsp();
        rsp.setRemarks(remarksArray[0]);
        rsp.setCreateBy(Constants.USER_SYSTEM);
        rsp.setCreateDate(withdrawalRequests.getCreatedDate());
        list.add(rsp);

        response.setBody(list);
        return response;
    }

    /**
     * 查询取款提案汇总
     *
     * @param query
     * @return
     */
    @Override
    public int queryWithdrawalCount(WSQueryWithdrawalRequests query) {
        WSQueryCountAmount wsQueryCountAmount = wsTemplate.queryWithdrawalCount(query);
        return Integer.parseInt(wsQueryCountAmount.getCount());
    }


    @Override
    public Response getValidAccountAndWinOrLostAmount(ReviewWithdrawalRequestReq req) {
        Response response = new Response<>();
        WSQueryWithdrawalRequests queryWithdrawalRequests = new WSQueryWithdrawalRequests();
        queryWithdrawalRequests.setProductId(req.getProductId());
        queryWithdrawalRequests.setRequestId(req.getRequestId());
        queryWithdrawalRequests.setDeleteFlag("0");
        List<WSWithdrawalRequests> withdrawalRequestsList = wsTemplate.queryWithdrawalList(queryWithdrawalRequests);
        if (CollectionUtil.isNotEmpty(withdrawalRequestsList)) {
            WSWithdrawalRequests withdrawalRequest = withdrawalRequestsList.get(0);
            String startTime = withdrawalRequest.getLastWithDrawalDate();
            String endTime = withdrawalRequest.getCreatedDate();
            String loginName = withdrawalRequest.getLoginName();
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            LocalDate start = LocalDate.parse(startTime, dateTimeFormatter);
            LocalDate end = LocalDate.parse(endTime, dateTimeFormatter);
            BigDecimal validAccount = BigDecimal.ZERO;

            if (end.toEpochDay() - start.toEpochDay() > 3) {
                String startToday = LocalDateTime.of(start, LocalTime.MAX).format(dateTimeFormatter);
                String endToday = LocalDateTime.of(end.minusDays(1), LocalTime.MIN).format(dateTimeFormatter);


                OrderReq orderReq = new OrderReq();
                orderReq.setProductId(req.getProductId());
                orderReq.setLoginName(new String[]{loginName});
                orderReq.setBeginReckonTime(startTime);
                orderReq.setEndReckonTime(startToday);
                QueryResultWrapper result = gdApiFeignTemplate.getCountTotalStrRecordAndSummaryV2(orderReq);
                if (result != null && result.getUtilArray() != null) {
                    String[] utilArray = result.getUtilArray();
                    validAccount = validAccount.add(new BigDecimal(utilArray[2]));
                }

                orderReq.setBeginReckonTime(endToday);
                orderReq.setEndReckonTime(endTime);
                QueryResultWrapper result1 = gdApiFeignTemplate.getCountTotalStrRecordAndSummaryV2(orderReq);

                if (result != null && result1.getUtilArray() != null) {
                    String[] utilArray = result1.getUtilArray();
                    validAccount = validAccount.add(new BigDecimal(utilArray[2]));
                }
                QueryResult<OrderSummaryNew> summaryNewByLoginName = gdApiFeignTemplate.getSummaryNewByLoginName(req.getProductId(),loginName,
                        LocalDateTime.of(start.plusDays(1), LocalTime.MIN).format(dateTimeFormatter),
                        LocalDateTime.of(end.minusDays(2), LocalTime.MIN).format(dateTimeFormatter));

                log.info("summaryNewByLoginName： loginName={} ,validAccount={}", loginName, validAccount);

                if (summaryNewByLoginName != null
                        && summaryNewByLoginName.getTotalResult() != null
                        && summaryNewByLoginName.getTotalResult().getTotalWinLostAmount() != null
                        && summaryNewByLoginName.getTotalResult().getTotalValidAmount() != null) {
                    validAccount = validAccount.add(summaryNewByLoginName.getTotalResult().getTotalValidAmount());
                }

            } else {
                OrderReq orderReq = new OrderReq();
                orderReq.setProductId(req.getProductId());
                orderReq.setLoginName(new String[]{loginName});
                orderReq.setBeginReckonTime(startTime);
                orderReq.setEndReckonTime(endTime);
                QueryResultWrapper result = gdApiFeignTemplate.getCountTotalStrRecordAndSummaryV2(orderReq);
                if (result != null && result.getUtilArray() != null) {
                    String[] utilArray = result.getUtilArray();
                    validAccount = validAccount.add(new BigDecimal(utilArray[2]));
                }
            }
            JSONObject json = new JSONObject();
            json.put("totalBetAmount", validAccount);
            response.setBody(json);
        }
        return response;
    }
}
