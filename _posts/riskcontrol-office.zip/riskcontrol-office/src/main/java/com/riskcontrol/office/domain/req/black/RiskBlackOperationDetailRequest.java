package com.riskcontrol.office.domain.req.black;

import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.entity.request.BasePageRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;


/**
 * @author Heng.zhang
 */
@Data
@ApiModel(value = "风控黑名单操作日志明细查询请求对象", description = "风控黑名单操作日志明细查询请求对象")
public class RiskBlackOperationDetailRequest extends BasePageRequest {

    @Schema(description = "blackId", example = "1")
    @Query
    private String blackId;

    @Schema(description = "operationStatus", example = "1")
    @Query
    private String operationStatus;

}