package com.riskcontrol.office.service;

import com.gw.datacenter.vo.pagainate.PageModel;
import com.riskcontrol.office.domain.req.WhiteListCreationReq;
import com.riskcontrol.office.domain.req.WhiteListEditReq;
import com.riskcontrol.office.domain.req.WhiteListPageQueryReq;
import com.riskcontrol.office.domain.req.WhiteListupdateStatusReq;
import com.riskcontrol.office.domain.rsp.WhiteListPageQueryRsp;

public interface WhiteListService {

    Boolean create(WhiteListCreationReq req);

    Boolean whiteListEdit(WhiteListEditReq req);

    Boolean updateStatus(WhiteListupdateStatusReq req);

    PageModel<WhiteListPageQueryRsp> getPageWhilteList(WhiteListPageQueryReq req);
}
