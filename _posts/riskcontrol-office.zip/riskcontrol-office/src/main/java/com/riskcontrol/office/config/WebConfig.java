//package com.riskcontrol.office.config;
//
//import com.intech.dbcryptor.Cryptor;
//import com.zaxxer.hikari.HikariConfig;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.InitializingBean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
//
//import javax.annotation.Resource;
//
//@Configuration
//@Slf4j
//public class WebConfig implements WebMvcConfigurer, InitializingBean {
//
//    @Resource
//    private HikariConfig hikariConfig;
//
//    @Override
//    public void afterPropertiesSet() throws Exception {
//        if (hikariConfig != null) {
//            try {
//                hikariConfig.setUsername(Cryptor.decryptContent(hikariConfig.getUsername()));
//                hikariConfig.setPassword(Cryptor.decryptContent(hikariConfig.getPassword()));
//            } catch (Exception e) {
//                log.error("解密数据库信息错误，解密前账号{}，密码{}", hikariConfig.getUsername(), hikariConfig.getPassword(), e);
//                throw e;
//            }
//        }
//    }
//}
