package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * 操作日志表
 */
@Schema(description = "操作日志表")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@TableName(value = "t_operation_log")
public class TOperationLog extends BaseEntity {

    @TableField(value = "product_id")
    @Schema(description = "")
    private String productId;

    /**
     * 父菜单名称
     */
    @TableField(value = "menu_name")
    @Schema(description = "父菜单名称")
    private String menuName;

    /**
     * 子菜单名称
     */
    @TableField(value = "sub_menu_name")
    @Schema(description = "子菜单名称")
    private String subMenuName;

    /**
     * 操作类型(0:未知操作,1:创建,2:修改,3:删除,4:发布,5:撤销,6:配置,7:复制,8:维护,9:启用,10:禁用）
     */
    @TableField(value = "op_type")
    @Schema(description = "操作类型(0:未知操作,1:创建,2:修改,3:删除,4:发布,5:撤销,6:配置,7:复制,8:维护,9:启用,10:禁用）")
    private Integer opType;

    /**
     * 操作人
     */
    @TableField(value = "op_by")
    @Schema(description = "操作人")
    private String opBy;

    /**
     * 操作日志
     */
    @TableField(value = "op_log")
    @Schema(description = "操作日志")
    private String opLog;

    /**
     * 请求ip
     */
    @TableField(value = "op_ip")
    @Schema(description = "请求ip")
    private String opIp;

    /**
     * 返回结果
     */
    @TableField(value = "return_Str")
    @Schema(description = "返回结果")
    private String returnStr;

    /**
     * 请求参数
     */
    @TableField(value = "request_Str")
    @Schema(description = "请求参数")
    private String requestStr;

    @TableField(value = "create_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @Schema(description  = "创建日期(Create Time)")
    protected Date createTime;
}