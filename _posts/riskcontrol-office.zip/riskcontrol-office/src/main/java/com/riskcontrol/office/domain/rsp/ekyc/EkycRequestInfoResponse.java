package com.riskcontrol.office.domain.rsp.ekyc;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

/**
 * @description: ekyc查询用户状态响应
 * @author: ErHu.Zhao
 * @create: 2024-10-07
 **/
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class EkycRequestInfoResponse {
    @ApiModelProperty("ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    @ApiModelProperty("用户ID")
    private Long customerId;

    @ApiModelProperty("用户名")
    private String loginName;

    @ApiModelProperty("首名")
    private String firstName;

    @ApiModelProperty("中间名")
    private String middleName;

    @ApiModelProperty("尾名")
    private String lastName;

    @ApiModelProperty("生日")
    private String birthday;

    @ApiModelProperty("M=Male, F=Female")
    private String sex;

    @ApiModelProperty("证件证明照")
    private String idFrontImg;

    @ApiModelProperty("证件背面照")
    private String idBackImg;

    @ApiModelProperty("证件类型")
    private Integer idType;

    @ApiModelProperty("证件号")
    private String idNo;

    @ApiModelProperty("自拍照")
    private String faceImg;

    @ApiModelProperty(value = "自拍照url")
    private String faceUrl;

    @ApiModelProperty("证件证明照url")
    private String idFrontUrl;

    @ApiModelProperty("证件背面照url")
    private String idBackUrl;

    @ApiModelProperty("KYC审批状态 0初始化，1待完善信息，2 人工审批，3通过，5 自动拒绝，6手动拒绝, 7失效")
    private Integer status;

    @ApiModelProperty("创建时间")
    private String createDate;

    @ApiModelProperty("创建人")
    private String createdBy;

    @ApiModelProperty("审核人")
    private String approvedBy;

    @ApiModelProperty("血缘标记（BP、AP、 GP、PG、SP）")
    private String tenant;

    @ApiModelProperty("渠道(3:GLIFE,4:GPO,5:LAZADA,6:MAYA,7:PERYAGAME,99:WEBSITE,98:人工)")
    private String channel;

    @ApiModelProperty("业务编号（随机生成唯一号）")
    private String billNo;

    @ApiModelProperty("企业名称")
    private String employerName;

    @ApiModelProperty("永久居住地")
    private String address;

    @ApiModelProperty("出生地")
    private String birthPlace;

    @ApiModelProperty("现居地址")
    private String presentAddress;

    @ApiModelProperty("国籍")
    private String nationality;

    @ApiModelProperty("资金来源")
    private String sourceOfIncome;

    @ApiModelProperty("工作性质")
    private String natureOfWork;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("转人工审核原因")
    private Integer manualReason;

    @ApiModelProperty("人工提交截图")
    private String manualImg;

    @ApiModelProperty("人工提交截图url")
    private String manualUrl;

    @ApiModelProperty("拒绝原因")
    private String rejectReason;

    @ApiModelProperty(value = "第三方业务id")
    private String ekycTransactionId;

    @ApiModelProperty(value = "第三方获取结果时间")
    private String ekycResultDate;

    @ApiModelProperty(value = "第三方返回结果")
    private String ekycResult;

    @ApiModelProperty(value = "审批时间")
    private String approvedDate;

}
