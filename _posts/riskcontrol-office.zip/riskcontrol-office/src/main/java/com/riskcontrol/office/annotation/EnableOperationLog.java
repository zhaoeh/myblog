package com.riskcontrol.office.annotation;

import com.riskcontrol.office.domain.enums.OpTypeEnum;

import java.lang.annotation.*;

@Documented
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface EnableOperationLog {

    /**
     * 父菜单名称，必传
     * @return
     */
    String menuName() default "";

    /**
     * 子菜单名称，必传，若无子菜单，请传父菜单名称
     *
     * @return
     */
    String subMenuName() default "";

    /**
     * 操作类型（0:未知操作,1:创建,2:修改,3:删除,4:发布,5:撤销,6:配置,7:复制,8:维护,9:启用,10:禁用），必传
     *
     * @return
     */
    OpTypeEnum opLogType() default OpTypeEnum.UNKNOWN;

    /**
     * 操作描述，当opLogType=2或6时，非必传
     *
     * @return
     */
    String opLog() default "";

    /**
     * mapp interface Class
     * 对应的Mappper.java接口的class
     * 当opLogType=2或6时，必传
     *
     * @return
     */
    Class mapperClass() default Object.class;

}
