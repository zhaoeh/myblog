package com.riskcontrol.office.domain.req.black;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.riskcontrol.common.annotation.EnumValid;
import com.riskcontrol.common.annotation.MultipartFileValidate;
import com.riskcontrol.common.enums.RiskImportModelEnum;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotNull;

/**
 * @description: 风控黑名单导入请求
 * @author: ErHu.Zhao
 * @create: 2024-09-24
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Accessors(chain = true)
public class RiskBlackImportRequest {

    @NotNull(message = "file cannot be null")
    @MultipartFileValidate(maxSize = 3 * 1024 * 1024, extensions = {"xlsx", "xls"}, message = "file extension must be {target}")
    @JSONField(serialize = false)
    private MultipartFile file;

    @EnumValid(enumClass = RiskImportModelEnum.class, enumField = "type", message = "import model type must be {target}")
    @NotNull(message = "import model type cannot be null")
    private Integer type;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @Accessors(chain = true)
    public static class RiskBlackImport{

        @JsonProperty("content")
        @NotNull
        private byte[] content;

        @EnumValid(enumClass = RiskImportModelEnum.class, enumField = "type", message = "import model type must be {target}")
        private Integer type;

        @ApiModelProperty("最后一次最后修改的account")
        private String dataModifier;

    }

}
