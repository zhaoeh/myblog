package com.riskcontrol.office.domain.req;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.riskcontrol.common.annotation.MultipartFileValidate;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;
import java.util.List;

/**
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Accessors(chain = true)
@ApiModel(description = "风控标签导入")
public class RiskLabelImportRequest {

    @NotNull(message = "file cannot be null")
    @ApiModelProperty(value = "风控标签导入文件", required = true)
    @JSONField(serialize = false)
    @MultipartFileValidate(maxSize = 3 * 1024 * 1024, extensions = {"xlsx", "xls"}, message = "file extension must be {target}")
    private MultipartFile file;

    @NotEmpty(message = "riskLabelIds cannot be empty")
    @ApiModelProperty(value = "风控标签导入，标签id列表", required = true)
    private List<BigInteger> riskLabelIds;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @Accessors(chain = true)
    public static class RiskLabelImport {

        /**
         * 日志主表id*
         */
        private BigInteger mainLogId;

        @JsonProperty("content")
        private byte[] content;

        private List<String> importUsers;

        @NotEmpty(message = "riskLabelIds cannot be empty")
        private List<BigInteger> riskLabelIds;

        @ApiModelProperty("最后一次最后修改的account")
        private String dataModifier;

    }

}
