package com.riskcontrol.office.common.constants;

/**
 * 常量类
 *
 * @author Hassan
 */
public class Constants {

    public static final String RISK_CONSTANTS_CACHE_HASH="riskConstants";
    public static final String SUCCESS_CODE = "0000";
    public static final String ALL = "all";
    public static final String ZERO = "0";

    public static final String TWO = "2";
    /**
     * 系统参数
     */
    public static final String PRODUCT_CONSTANTS_TYPE_0004 = "0004";
    /**
     * 审批类型
     */
    public static final String PENDING_FLAG = "0";
    public static final String APPROVED_WAIT = "1";
    public static final String APPROVED_FLAG = "2";
    public static final String REJECT_FLAG = "-3";

    public static final String APPROVE_TYPE_APPROVE = "2";
    public static final String APPROVE_TYPE_CANCLE = "-2";
    public static final String APPROVE_TYPE_REJECT = "-3";

    public static final String WITHDRAW_HAS_APPROVED = "Withdraw has been approved";
    public static final String WITHDRAW_HAS_DENIED = "Withdraw has been denied";
    public static final String APPROVE_TYPE_FIRST_APPROVE = "9";
    public static final String FLAG_STR_ZERO = "0";
    public static final String FLAG_STR_ONE = "1";
    public static final String FLAG_STR_TWO = "2";
    public static final String FLAG_STR_THREE = "3";
    public static final String FLAG_STR_NINE = "9";

    /**
     * 系统用户 system
     */
    public static final String USER_SYSTEM = "system";
    public static final String USER_TYPE = "U";

    /**
     *  门店端查询用户详情接口 识别标识
     */
    public static final String BRANCH_CUST_DETAIL_DEPOSIT = "withdrawal";
    // 逗号分隔符
    public static final String SEPARATOR_COMMA = ",";

    public static final Integer CALC_AGE_BY_BIRTHDAY = 21;

    //图片格式
    public static String JPG = "FFD8FF";
    public static String PNG = "89504E47";

    /**
     * 系统常量类型
     */
    public static final String EKYC_REJECT_REASON = "r-0019";
    // 非法风控标签用户
    public static Integer INVALID_LABEL_STATUS = 1;
    // 合法风控标签用户
    public static Integer VALID_LABEL_STATUS = 1;

}
