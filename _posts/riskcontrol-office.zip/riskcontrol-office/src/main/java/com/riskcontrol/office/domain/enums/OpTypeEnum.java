package com.riskcontrol.office.domain.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum OpTypeEnum {
    UNKNOWN (0,"未知操作"),
    CREATE(1,"创建"),
    UPDATE(2,"修改"),
    DELETE(3,"删除"),
    RELEASE(4,"发布"),
    CANCEL(5,"撤销"),
    CONFIGURATION(6,"配置"),
    COPY(7,"复制"),
    MAINTAIN(8,"维护"),
    ENABLE(9,"启用"),
    DISABLE(10,"禁用"),
    APPROVAL(11,"审批"),
    REJECTED(12,"拒绝"),
    EXPORT(13,"导出"),
    RETRIAL_APPROVE(14,"重审"),;


    /**
     * 类型
     */
    private final int type;

    /**
     * 描述
     */
    private final String description;
}
