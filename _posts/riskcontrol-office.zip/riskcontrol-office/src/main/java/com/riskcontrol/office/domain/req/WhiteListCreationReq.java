package com.riskcontrol.office.domain.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "白名单创建请求对象")
public class WhiteListCreationReq {

    @Schema(description = "规则校验类型")
    @JsonProperty("allowType")
    private Integer allowType;

    @Schema(description = "规则校验名称")
    @JsonProperty("allowRecord")
    private String allowRecord;

    @Schema(description = "备注")
    private String remark;

}