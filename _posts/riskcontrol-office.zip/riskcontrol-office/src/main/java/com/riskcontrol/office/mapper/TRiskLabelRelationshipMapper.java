package com.riskcontrol.office.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.riskcontrol.office.domain.entity.TRiskLabelRelationship;
import com.riskcontrol.office.domain.req.RiskLabelPageReq;
import com.riskcontrol.office.domain.rsp.RiskLabelPageRsp;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface TRiskLabelRelationshipMapper extends BaseMapper<TRiskLabelRelationship> {

    //    IPage<TRiskLabelRelationship> selectRelationPage(Page<TRiskLabelRelationship> page, @Param("req") RiskLabelPageReq request);
    IPage<RiskLabelPageRsp> selectRelationPage(Page<RiskLabelPageRsp> page, @Param("req") RiskLabelPageReq request);

}