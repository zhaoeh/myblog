package com.riskcontrol.office.domain.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.math.BigInteger;
import java.util.List;

/**
 * @description: 风控标签修改请求
 * @author: ErHu.Zhao
 * @create: 2024-10-16
 **/
@Data
@ApiModel(description = "风控标签修改请求对象")
public class RiskLabelChangeReq {

    @NotBlank(message = "loginName cannot be blank")
    @ApiModelProperty(value = "账户名称", required = true)
    @JsonProperty("loginName")
    private String loginName;

    @ApiModelProperty(value = "标签id集", required = true)
    @JsonProperty("riskLabelIds")
    @NotEmpty(message = "riskLabelIds cannot be empty")
    private List<BigInteger> riskLabelIds;

}
