package com.riskcontrol.office.domain.withdrawal.req;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
@Schema(title = "打开取款提案审核请求参数<br/>Request parameters for review withdrawal")
public class ReviewWithdrawalRequestReq extends BaseReq {
    @NotBlank(message = "requestId can not be blank")
    @Schema(required = true, description = "取款提案单号<br/>Request ID of withdrawal")
    private String requestId;

    @Schema(required = true, description = "提案当前状态<br/>Current flag of withdrawal request")
    private String flag;
    /**
     * 是否查询代理转账 1 是
     * */
    private int agentTransReq;
}