package com.riskcontrol.office.datasource;

import java.lang.annotation.*;

/**
 * 數據源
 * @author dante
 */
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface DBSourceCheck {
    DataSourceType value() default DataSourceType.Default;
}
