package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigInteger;
import java.util.Date;

/**
    * 用户标签绑定关系表
    */
@Schema(description="用户标签绑定关系表")
@Data
@TableName(value = "t_risk_label_relationship")
public class TRiskLabelRelationship extends BaseEntity  {

    /**
     * 所属产品
     */
    @TableField(value = "product_id")
    @Schema(description="所属产品")
    private String productId;

    /**
     * 用户ID
     */
    @TableField(value = "customer_id")
    @Schema(description="用户ID")
    private Long customerId;

    /**
     * 标签ID
     */
    @TableField(value = "risk_label_id")
    @Schema(description="标签ID")
    private BigInteger riskLabelId;


    /**
     * 风控标签名称
     */
    @TableField(value = "risk_label_name")
    @Schema(description="风控标签名称")
    private String riskLabelName;

    /**
     * 风控标签Key
     */
    @TableField(value = "risk_label_key")
    @Schema(description="风控标签Key")
    private String riskLabelKey;

    /**
     * 用户登录名
     */
    @TableField(value = "login_name")
    @Schema(description="用户登录名")
    private String loginName;

    /**
     * 备注
     */
    @TableField(value = "remark")
    @Schema(description="备注")
    private String remark;

    /**
     * 创建人
     */
    @TableField(value = "create_by")
    @Schema(description="创建人")
    private String createBy;

    /**
     * 创建时间
     */
    @TableField(value = "create_time")
    @Schema(description="创建时间")
    private Date createTime;

    /**
     * 最后修改人
     */
    @TableField(value = "update_by")
    @Schema(description="最后修改人")
    private String updateBy;

    /**
     * 最后修改时间
     */
    @TableField(value = "update_time")
    @Schema(description="最后修改时间")
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}