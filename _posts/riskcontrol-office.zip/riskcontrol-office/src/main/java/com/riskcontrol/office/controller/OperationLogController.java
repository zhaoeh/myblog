package com.riskcontrol.office.controller;

import com.digiplus.oms.aspect.annotation.PreAuthorize;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.entity.TOperationLog;
import com.riskcontrol.office.domain.req.OperactionLogReq;
import com.riskcontrol.office.service.TOperationLogService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @author: sanji
 * @date: 2024/03/08 16:01
 */
@RestController
@RequestMapping("/operationLog")
@Tag(name = "操作日志")
//@SecurityRequirement(name = HttpHeaders.AUTHORIZATION)
@Slf4j
public class OperationLogController {

    @Resource
    TOperationLogService operationLogService;

    @PreAuthorize("risk_sys_oplog_query")
    @PostMapping("/queryList")
    @Operation(tags ="操作日志" ,summary = "查询操作日志列表")
    @ResponseBody
    public R<PageModel<TOperationLog>> queryList(@RequestBody @Validated OperactionLogReq req) {
        return R.ok(operationLogService.queryList(req));
    }
}
