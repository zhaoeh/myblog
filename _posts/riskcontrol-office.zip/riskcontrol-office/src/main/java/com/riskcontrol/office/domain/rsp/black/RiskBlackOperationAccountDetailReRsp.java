package com.riskcontrol.office.domain.rsp.black;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigInteger;


/**
 * @author Heng.zhang
 */
@ApiModel(value = "风控黑名单操作记录明细关联账户信息", description = "风控黑名单")
@Data
public class RiskBlackOperationAccountDetailReRsp {

    @ApiModelProperty("ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    @ApiModelProperty(value = "名")
    private String firstName;

    @ApiModelProperty(value = "中间名")
    private String middleName;


    @ApiModelProperty(value = "姓")
    private String lastName;

    @ApiModelProperty(value = "生日")
    private String birthday;

    @ApiModelProperty(value = "关联账户")
    private String allLoginName;

    @ApiModelProperty(value = "关联总数")
    private Integer loginNameCount;

    @ApiModelProperty(value = "操作的成功失败状态 1：成功 0：失败")
    private String operationStatus;


}