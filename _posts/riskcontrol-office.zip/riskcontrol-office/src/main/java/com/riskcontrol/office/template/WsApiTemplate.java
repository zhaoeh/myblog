//package com.riskcontrol.office.template;
//
//import com.cn.schema.agent.QueryAgentTransRequest;
//import com.cn.schema.agent.QueryAgentTransResponse;
//import com.cn.schema.agent.WSQueryAgentTrans;
//import com.cn.schema.customers.*;
//import com.cn.schema.products.*;
//import com.cn.schema.request.*;
//import com.cn.schema.urf.LoginOfficeRequest;
//import com.cn.schema.urf.LoginOfficeResponse;
//import com.cn.schema.urf.WSUsers;
//import com.riskcontrol.common.client.UserCenterFeign;
//import com.riskcontrol.common.client.WSFeign;
//import com.riskcontrol.common.config.C66Config;
//import com.riskcontrol.office.common.constants.ConstantVars;
//import com.riskcontrol.office.common.constants.Constants;
//import com.riskcontrol.office.common.enums.ErrorCodeEnum;
//import com.riskcontrol.office.common.exceptions.BizException;
//import com.riskcontrol.office.config.WsProductConfig;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.collections4.CollectionUtils;
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.oxm.UncategorizedMappingException;
//import org.springframework.stereotype.Component;
//import org.springframework.ws.client.WebServiceIOException;
//
//import javax.annotation.Resource;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.UUID;
//
//@Component
//@Slf4j
//public class WsApiTemplate {
//
//    @Resource
//    private WsProductConfig wsWsProductConfig;
//
//    public static final String WS_RESPONSE_DELIMITER = "^";
//    @Resource
//    private C66Config c66Config;
//    @Resource
//    private WSFeign wsFeign;
//    @Resource
//    private UserCenterFeign usFeign;
//
//    public WSCustomers getCustomerByLoginName(String productId, String loginName) {
//        try {
//            QueryCustomersBasicByLoginNameRequest request = new QueryCustomersBasicByLoginNameRequest();
//            request.setInfProductId(productId);
//            request.setInfPwd(wsWsProductConfig.getWsProductPwd());
//            request.setLoginName(loginName);
//            request.setHideSensitiveInfo(true);//隐藏微信号
//            QueryCustomersBasicByLoginNameResponse response = wsFeign.getSimpleCustomerByLoginName(request);
//            if (CollectionUtils.isEmpty(response.getWsCustomers())) {
//                return null;
//            } else {
//                return response.getWsCustomers().get(0);
//            }
//        } catch (Exception ex) {
//            log.error("调用WS接口异常，QueryCustomersBasicByLoginNameResponse错误", ex);
//            throw buildBizException(ex);
//        }
//    }
//    /**
//     * 根据登录名查询玩家（玩家详细信息查询）
//     * C66
//     *
//     * @param wsQueryCustomer
//     * @return
//     */
//    public WSCustomers queryCustomer(WSQueryCustomers wsQueryCustomer) {
//        try {
//            QueryCustomerByLoginNameRequest request = new QueryCustomerByLoginNameRequest();
//            request.setInfProductId(wsQueryCustomer.getProductId());
//            request.setInfPwd(wsWsProductConfig.getWsProductPwd());
//            request.setLoginName(wsQueryCustomer.getLoginName());
//            QueryCustomerByLoginNameResponse response = wsFeign.queryByLoginName(request);
//            return response == null ? null : response.getWSCustomers();
//        } catch (Exception ex) {
//            log.error("调用WS接口异常，QueryCustomerByLoginNameRequest错误", ex);
//            throw buildBizException(ex);
//        }
//    }
//
//    public List<WSCustomersBank> queryCustomerBanks(WSQueryCustomersBank wsQueryCustomersBank) {
//        if (StringUtils.equals(Constants.FLAG_STR_ONE, c66Config.getUserCenterCallSwitch())) {
//            QueryCustomersBankRequest request = new QueryCustomersBankRequest();
//            request.setInfProductId(wsQueryCustomersBank.getProductId());
//            request.setInfPwd(wsWsProductConfig.getWsProductPwd());
//            request.setWSQueryCustomersBank(wsQueryCustomersBank);
//            QueryCustomersBankResponse response = usFeign.queryCustomerBanks(request);
//            return response == null ? new ArrayList<>() : response.getWSCustomersBank();
//        } else {
//            try {
//                QueryCustomersBankRequest request = new QueryCustomersBankRequest();
//                request.setInfProductId(wsQueryCustomersBank.getProductId());
//                request.setInfPwd(wsWsProductConfig.getWsProductPwd());
//                request.setWSQueryCustomersBank(wsQueryCustomersBank);
//                QueryCustomersBankResponse response = wsFeign.queryCustomerBanks(request);
//                return response == null ? new ArrayList<>() : response.getWSCustomersBank();
//            } catch (Exception ex) {
//                log.error("调用WS接口异常，QueryCustomersBankResponse错误", ex);
//                throw buildBizException(ex);
//            }
//        }
//    }
//    public List<WSWithdrawalRequests> queryWithdrawalList(WSQueryWithdrawalRequests wsQueryWithdrawalRequests) {
//        try {
//            String productId = wsQueryWithdrawalRequests.getProductId();
//            QueryWithdrawalRequestsRequest request = new QueryWithdrawalRequestsRequest();
//            request.setInfProductId(productId);
//            request.setInfPwd(wsWsProductConfig.getWsProductPwd());
//            request.setWSQueryWithdrawalRequests(wsQueryWithdrawalRequests);
//            QueryWithdrawalRequestsResponse response = wsFeign.queryWithdrawalRequests(request);
//            return response.getWSWithdrawalRequests();
//        } catch (Exception ex) {
//            log.error("调用WS接口异常，QueryWithdrawalRequestsRequest", ex);
//            throw buildBizException(ex);
//        }
//    }
//
//
//    public List<WSResponseApprove> approveWithdrawal(String productId, WSRequestsApprove wSRequestsApprove) {
//        try {
//            RequestApproveRequest request = new RequestApproveRequest();
//            request.setInfProductId(productId);
//            request.setInfPwd(wsWsProductConfig.getWsProductPwd());
//            request.setWsRequestsApprove(wSRequestsApprove);
//            RequestApproveResponse response = wsFeign.requestApprove(request);
//            List<WSResponseApprove> wsResponseApproves = response.getWSResponseApprove();
//            if (!wsResponseApproves.isEmpty()) {
//                WSResponseApprove responseApprove = wsResponseApproves.get(0);
//                if (StringUtils.isNotEmpty(responseApprove.getErrorMsg())) {
//                    throw buildBizException(responseApprove.getErrorMsg());
//                }
//            }
//            return wsResponseApproves;
//        } catch (Exception ex) {
//            log.error("调用WS接口异常，RequestApproveRequest", ex);
//            throw buildBizException(ex);
//        }
//    }
//
//
//    public WSQueryCountAmount queryWithdrawalCount(WSQueryWithdrawalRequests wSQueryWithdrawalRequests) {
//        try {
//            String productId = wSQueryWithdrawalRequests.getProductId();
//            QueryCountWithdrawalRequestsRequest request = new QueryCountWithdrawalRequestsRequest();
//            request.setInfProductId(productId);
//            request.setInfPwd(wsWsProductConfig.getWsProductPwd());
//            request.setWSQueryWithdrawalRequests(wSQueryWithdrawalRequests);
//            QueryCountWithdrawalRequestsResponse response = wsFeign.queryCountWithdrawRequest(request);
//            return response.getWSQueryCountAmount();
//        } catch (Exception ex) {
//            log.error("调用WS接口异常，QueryCountWithdrawalRequestsRequest", ex);
//            throw buildBizException(ex);
//        }
//    }
//
//    /**
//     * 查询代理下级存取款的提案
//     */
//    public QueryAgentTransResponse queryAgentTrans(WSQueryAgentTrans query) {
//        try {
//            QueryAgentTransRequest request = new QueryAgentTransRequest();
//            request.setInfProductId(query.getProductId());
//            request.setInfPwd(wsWsProductConfig.getWsProductPwd());
//            request.setRequestUUID(UUID.randomUUID().toString());
//            request.setWsQueryAgentTrans(query);
//            return wsFeign.queryAgentTrans(request);
//        } catch (Exception ex) {
//            log.error("调用WS接口异常, queryCustAgentTransaction", ex);
//            throw buildBizException(ex);
//        }
//    }
//
//
//    public Integer queryProductConstantsCount(String productId, WSQueryProductConstants query) {
//        try {
//            QueryCountProductConstantsRequest request = new QueryCountProductConstantsRequest();
//            request.setInfProductId(productId);
//            request.setInfPwd(wsWsProductConfig.getWsProductPwd());
//            request.setWSQueryProductConstants(query);
//            QueryCountProductConstantsResponse response = wsFeign.queryProductConstantsCount(request);
//            return response.getCount();
//        } catch (Exception ex) {
//            log.error("调用WS接口异常，QueryCountProductConstantsRequest", ex);
//            throw buildBizException(ex);
//        }
//    }
//
//
//    public List<WSProductConstants> queryProductConstantsList(String productId, WSQueryProductConstants query) {
//        try {
//            QueryProductConstantsRequest request = new QueryProductConstantsRequest();
//            request.setInfProductId(productId);
//            request.setInfPwd(wsWsProductConfig.getWsProductPwd());
//            request.setWSQueryProductConstants(query);
//            QueryProductConstantsResponse result = wsFeign.getProductConstants(request);
//            return result.getWSProductConstants();
//        } catch (Exception ex) {
//            log.error("调用WS接口异常，QueryProductConstantsRequest", ex);
//            throw buildBizException(ex);
//        }
//    }
//
//
//
//    public WSProductConstants getProductConstants(String productId, String type, String key) {
//        // 优先从缓存获取常量
////        final String reidsGroupKey = productId.concat(":ws:product_constants");
////        final String reidsKey = productId + '_' + type + '_' + key;
////        Object productConstants = RedisUtils.get(String.join(":", reidsGroupKey, reidsKey));
////        if (productConstants != null) {
////            List<WSProductConstants> constants = (List<WSProductConstants>) productConstants;
////            return CollectionUtils.isEmpty(constants) ? null : constants.get(0);
////        }
//
//        try {
//            QueryProductConstantsRequest request = new QueryProductConstantsRequest();
//            request.setInfProductId(productId);
//            request.setInfPwd(wsWsProductConfig.getWsProductPwd());
//            WSQueryProductConstants wsQueryProductConstants = new WSQueryProductConstants();
//            wsQueryProductConstants.setProductId(productId);
//            wsQueryProductConstants.setType(type);
//            wsQueryProductConstants.setKey(key);
//            request.setWSQueryProductConstants(wsQueryProductConstants);
//            QueryProductConstantsResponse response = wsFeign.getProductConstants(request);
//            if (response.getWSProductConstants().isEmpty()) {
//                return null;
//            }
//            return response.getWSProductConstants().get(0);
//        } catch (Exception ex) {
//            log.error("调用WS接口异常，QueryProductConstantsResponse错误", ex);
//            throw ex;
//        }
//    }
//
//
//    public WSUsers userOfficeLogin(WSUsers user, String operateType) {
//        try {  //todo 1
//            String productId = user.getProductId();
//            LoginOfficeRequest request = new LoginOfficeRequest();
//            request.setInfProductId(productId);
//            request.setInfPwd(wsWsProductConfig.getWsProductPwd());
//            request.setInfFlag(operateType);
//            request.setWSUsers(user);
//            request.setFunctionIsNew(2);
//            LoginOfficeResponse response = wsFeign.userOfficeLogin(request);
//            return response == null ? null : response.getWSUsers();
//        } catch (Exception ex) {
//            log.error("调用WS接口异常，LoginOfficeRequest", ex);
//            throw buildBizException(ex);
//        }
//    }
//
//    private BizException buildBizException(String x) {
//        if (x.contains(WS_RESPONSE_DELIMITER)) {
//            return new BizException(x);
//        } else {
//            return new BizException(ErrorCodeEnum.ERROR_WS.getErrCode() + "^Business System Error[W]^" + x);
//        }
//    }
//
//    /**
//     * 将WS调用返回的异常封装为业务异常
//     *
//     * @param e WS异常，其message格式为 <b>CODE^英文描述信息^中文描述信息</b>
//     * @return
//     */
//    private BizException buildBizException(Exception e) {
//        if (e instanceof WebServiceIOException) {
//            return buildConectionException();
//        }
//        if (e instanceof UncategorizedMappingException) {
//            return buildParamsMapException();
//        }
//        String originErrMessage = e.getMessage();
//        String errCode, message;
//        if (StringUtils.contains(originErrMessage, WS_RESPONSE_DELIMITER)) {
//            String[] splits = originErrMessage.split("\\" + WS_RESPONSE_DELIMITER);
//            if (splits.length < 3) { //WS返回的错误信息不符合格式
//                errCode = ErrorCodeEnum.ERROR_WS.getErrCode();
//                message = originErrMessage;
//            } else {
//                errCode = ConstantVars.CODE_PREFIX_WS + splits[0];
//                message = splits[1] + WS_RESPONSE_DELIMITER + splits[2]; //只返回中文描述信息
//            }
//
//        } else if (e instanceof BizException) {
//
//            return (BizException) e;
//
//        } else if (StringUtils.isNotBlank(originErrMessage)) {
//            //为了兼容目前ws返回的错误消息没有^分隔符导致前端捕捉不到错误码的情况
//            errCode = "99985";
//            message = originErrMessage;
//        } else {
//            errCode = ErrorCodeEnum.ERROR_WS.getErrCode();
//            message = ErrorCodeEnum.ERROR_WS.getErrMsg();
//        }
//        return new BizException(errCode, message, e);
//    }
//
//    private BizException buildConectionException() {
//        return new BizException(ErrorCodeEnum.ERROR_WS.getErrCode(), "^Server Connect Error[W]^");
//    }
//
//    private BizException buildParamsMapException() {
//        return new BizException(ErrorCodeEnum.ERROR_WS.getErrCode(), "^Params Map System Error[W]^");
//    }
//}
