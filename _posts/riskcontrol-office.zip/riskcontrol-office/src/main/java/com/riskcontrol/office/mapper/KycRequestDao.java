package com.riskcontrol.office.mapper;

import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequest;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @program: riskcontrol-cron
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-10-04 15:51
 **/
@Mapper
public interface KycRequestDao {
    List<KycRequest> queryPageByConditionAll(RiskQueryKycRequest query);

}
