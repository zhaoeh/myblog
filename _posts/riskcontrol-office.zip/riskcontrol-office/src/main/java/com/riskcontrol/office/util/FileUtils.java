package com.riskcontrol.office.util;

import cn.hutool.crypto.digest.DigestUtil;
import com.riskcontrol.office.common.constants.Constants;
import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;

/**
 * 文件工具类
 */
public class FileUtils {

    private static final Logger logger = LoggerFactory.getLogger("FileUtils");

    public static String getSuffix(String fileName) {
        return fileName.substring(fileName.lastIndexOf("."));
    }


    public static String getIdentityFilePath(MultipartFile file) {
        return getMd5(file) + getSuffix(file.getOriginalFilename());
    }

    public static String getIdentityFilePath(InputStream file) {
        return getMd5(file) + ".jpg";
    }

    /**
     * 获取上传文件的md5
     *
     * @param file
     * @return
     */
    public static String getMd5(MultipartFile file) {
        try {
            return DigestUtils.md5Hex(file.getBytes());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return null;
    }

    public static String getMd5(InputStream inputStream) {
        try {
            return DigestUtils.md5Hex(inputStream);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return null;
    }

    public static String getMd5(String base64Str) {
        try {
            return DigestUtils.md5Hex(base64Str);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return null;
    }

    public static String getSuffix(byte[] bytes){
        String suffix = null;
        String type = bytesToHexString(bytes).toUpperCase();
        if (type.contains(Constants.JPG)){
            suffix = ".jpg";
        } else if(type.contains(Constants.PNG)){
            suffix = ".png";
        }
        return suffix;
    }


    /**
     * byte数组转换成16进制字符串
     *
     * @param src
     * @return
     */
    public static String bytesToHexString(byte[] src) {
        StringBuilder stringBuilder = new StringBuilder();
        if (src == null || src.length <= 0) {
            return null;
        }
        for (int i = 0; i < src.length; i++) {
            int v = src[i] & 0xFF;
            String hv = Integer.toHexString(v);
            if (hv.length() < 2) {
                stringBuilder.append(0);
            }
            stringBuilder.append(hv);
        }
        return stringBuilder.toString();
    }

    /**
     * 生成文件路径
     *
     * @param content 文件内容
     * @return path，唯一不可重复
     */
    public static String generatePath(byte[] content) {
        return DigestUtil.sha256Hex(content);
    }
}
