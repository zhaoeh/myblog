package com.riskcontrol.office.controller;

import com.gw.datacenter.vo.pagainate.PageModel;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.req.*;
import com.riskcontrol.office.domain.rsp.BlcackOpertionLogListPageQueryRsp;
import com.riskcontrol.office.domain.rsp.WhiteListPageQueryRsp;
import com.riskcontrol.office.service.TRiskActionAllowOperationLogService;
import com.riskcontrol.office.service.WhiteListService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @description: 黑白名单控制器
 * @author: ErHu.Zhao
 * @create: 2024-11-12
 **/
@RestController
@RequestMapping("/office/riskActionAllow")
@Tag(name = "风控黑白名单")
@Slf4j
public class RiskActionAllowController {

    @Autowired
    private WhiteListService whiteListService;

    @Resource
    private TRiskActionAllowOperationLogService tRiskActionAllowOperationLogService;
    @PostMapping("/create")
    @Operation(tags = "黑白名单", summary = "白名单创建")
    public R<Boolean> create(@RequestBody WhiteListCreationReq req) throws Exception {
        return R.ok(whiteListService.create(req));
    }

    @PostMapping("/edit")
    @Operation(tags = "黑白名单", summary = "白名单编辑")
    public R<Boolean> edit(@Validated @RequestBody WhiteListEditReq req) throws Exception {
        return R.ok(whiteListService.whiteListEdit(req));
    }

    @PostMapping("/updateStatus")
    @Operation(tags = "黑白名单", summary = "白名单状态编辑")
    public R<Boolean> updateStatus(@Validated @RequestBody WhiteListupdateStatusReq req) throws Exception {
        return R.ok(whiteListService.updateStatus(req));
    }

    @PostMapping("/getPageList")
    @Operation(tags = "黑白名单", summary = "白名单分页查询")
    public R<PageModel<WhiteListPageQueryRsp>> getPageWhilteList(@Validated @RequestBody WhiteListPageQueryReq req) throws Exception {
        return R.ok(whiteListService.getPageWhilteList(req));
    }

    @PostMapping("/getOperationList")
    @Operation(tags = "黑白名单", summary = "黑名单操作分页查询")
    public R<PageModel<BlcackOpertionLogListPageQueryRsp>> getPageBlackOperationList(@Validated @RequestBody BlackOperationListPageQueryReq req) throws Exception {
        return R.ok(tRiskActionAllowOperationLogService.getPageBlackOperationList(req));
    }


}
