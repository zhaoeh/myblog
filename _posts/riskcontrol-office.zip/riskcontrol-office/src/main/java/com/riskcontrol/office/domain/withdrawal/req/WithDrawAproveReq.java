package com.riskcontrol.office.domain.withdrawal.req;

import com.riskcontrol.common.entity.request.BaseQueryReq;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class WithDrawAproveReq extends BaseQueryReq {

    private BigDecimal amount;
    private String bankAccountName;
    private String bankAccountNo;
    private String bankAccountType;
    private String bankCity;
    private String bankId;
    private String bankName;
    private String bankProvince;
    private String branchCode;
    private String branchName;
    private String catalog;
    private String createdBy;
    private String createdDate;
    private String  currency;
    private String customerId;
    private String customerType;
    private String deleteFlag;
    private String domainName;
    private String endPointType;
    private String endPointUrl;
    private String exceptionPrompt;
    private String exceptionPromptType;
    private String firstWithdrawal;
    private String flag;
    private String ipAddress;
    private String lastUpdate;
    private String lastUpdatedBy;
    //private String loginName;
    private String processedBy;
    private String  processedDate;
    private String productId;
    private String  registerBranchCode;
    private String  registerBranchName;
    private String remarks;
    private String requestId;
    private String  riskCompletionTime;
    private String targetCurrency;
}
