package com.riskcontrol.office.common.constants;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/4/22 9:44
 */
public class RedisConstant {
    public static final String redisCacheableConnector = "::";//使用@Cacheable key的连接符
    public static String LABEL_RULE_KEY = "risk:label:rule"+redisCacheableConnector;//
    public static String CUSTOMER_LABEL_KEY = "risk:customer:label"+redisCacheableConnector;

    /**
     * kyc校验结果
     */
    public static final String KYC_VALID_EXISTS = "kyc:valid:%s:%s";
}
