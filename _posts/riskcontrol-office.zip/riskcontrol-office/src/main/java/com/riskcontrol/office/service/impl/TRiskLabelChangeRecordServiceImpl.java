package com.riskcontrol.office.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.domain.entity.TRiskLabelChangeRecord;
import com.riskcontrol.office.domain.req.RiskLabelOperationDetailPageRequest;
import com.riskcontrol.office.domain.rsp.RiskLabelOperationDetailPageRsp;
import com.riskcontrol.office.mapper.TRiskLabelChangeRecordMapper;
import com.riskcontrol.office.service.TRiskLabelChangeRecordService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 用户标签变更记录(TRiskLabelChangeRecord)表服务实现类
 *
 * @author makejava
 * @since 2024-06-06 15:27:24
 */
@Service("tRiskLabelChangeRecordService")
public class TRiskLabelChangeRecordServiceImpl extends BaseServiceImpl<TRiskLabelChangeRecordMapper, TRiskLabelChangeRecord> implements TRiskLabelChangeRecordService {

    @Override
    public PageModel<RiskLabelOperationDetailPageRsp> getOperationDetailList(RiskLabelOperationDetailPageRequest req) {
        LambdaQueryWrapper<TRiskLabelChangeRecord> wrapper = buildWrapper(req);
        wrapper.select(TRiskLabelChangeRecord::getId, TRiskLabelChangeRecord::getLoginName, TRiskLabelChangeRecord::getNewRiskLabelId, TRiskLabelChangeRecord::getOperationStatus);
        wrapper.orderByDesc(TRiskLabelChangeRecord::getCreateTime);
        Page<TRiskLabelChangeRecord> page = pageByWrapper(req, wrapper);
        PageModel<RiskLabelOperationDetailPageRsp> pageResult = new PageModel<>();
        List<RiskLabelOperationDetailPageRsp> list = page.getRecords().stream().map(x -> {
            RiskLabelOperationDetailPageRsp rsp = new RiskLabelOperationDetailPageRsp();
            BeanUtil.copyProperties(x, rsp);
            return rsp;
        }).toList();
        pageResult.setData(list);
        pageResult.setPageNo((int) page.getCurrent());
        pageResult.setPageSize((int) page.getSize());
        pageResult.setTotalRow((int) page.getTotal());
        pageResult.setTotalPage((int) page.getPages());
        return pageResult;
    }
}

