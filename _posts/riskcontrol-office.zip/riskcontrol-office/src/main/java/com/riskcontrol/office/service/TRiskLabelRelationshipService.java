package com.riskcontrol.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.request.label.RiskLabelListRequest;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelRsp;
import com.riskcontrol.office.domain.entity.TRiskLabelRelationship;
import com.riskcontrol.office.domain.req.RiskLabelChangeReq;
import com.riskcontrol.office.domain.req.RiskLabelImportRequest;
import com.riskcontrol.office.domain.req.RiskLabelPageReq;
import com.riskcontrol.office.domain.rsp.RiskLabelPageRsp;
import com.riskcontrol.office.domain.rsp.RiskLabelRelationRsp;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface TRiskLabelRelationshipService extends IService<TRiskLabelRelationship>{

    /**
     * 批量查询用户标签信息
     * @param request
     * @return
     */
    List<CustomerRiskLabelRsp> listCustomerRiskLabel(RiskLabelListRequest request);

    /**
     * 获取用户风控标签详情
     * @param customerId
     * @return
     */
    CustomerRiskLabelRsp getRiskLabelDetail(Long customerId);


    /**
     * 分页查询用户-标签关联关系*
     *
     * @param req
     * @return
     */
    PageModel<RiskLabelPageRsp> queryRiskLabelRelationships(RiskLabelPageReq req);

    /**
     * 修改用户标签*
     *
     * @param req
     * @return
     */
    Boolean modifyRiskLabelRelationship(RiskLabelChangeReq req);

    /**
     * 根据用户-标签关系loginName查询标签关系*
     *
     * @param loginName loginName
     * @return 标签关系
     */
    RiskLabelRelationRsp queryRiskLabelRelationshipByLoginName(@Param("loginName") String loginName);

    /**
     * 用户标签批量导入*
     *
     * @param importRequest
     * @return
     */
    Boolean importExcel(RiskLabelImportRequest.RiskLabelImport importRequest);
}
