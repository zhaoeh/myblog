package com.riskcontrol.office.mapper;

import com.riskcontrol.office.domain.entity.TRiskActionAllow;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RiskActionAllowMapper extends BaseMapperX<TRiskActionAllow> {
}