package com.riskcontrol.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.request.PbcCrawlerUpdateStatusReq;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.domain.entity.TPbcCrawlerResultNew;
import com.riskcontrol.office.domain.req.PbcCrawlerPageRequest;

public interface TPbcCrawlerResultNewService extends IService<TPbcCrawlerResultNew> {

    /**
     * 分页查询PBC列表
     *
     * @return
     */
    PageModel<TPbcCrawlerResultNew> queryList(PbcCrawlerPageRequest req);

    /**
     * 解除/禁用PBC
     *
     * @return
     */
    boolean updateStatus(PbcCrawlerUpdateStatusReq req);

}
