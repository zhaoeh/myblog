package com.riskcontrol.office.localcache;

/**
 * @author dante
 * @date 2024/03/21
 */
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.office.common.constants.Constants;
import com.riskcontrol.office.domain.entity.TSysConstants;
import com.riskcontrol.office.mapper.TSysConstantsMapper;
import com.riskcontrol.office.util.RedisUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
@Slf4j
@Component
public class LocalCacheRunner implements ApplicationRunner {
    @Resource
    TSysConstantsMapper constantsMapper;
    @Override
    public void run(ApplicationArguments args) throws Exception {
        // 在 Spring 启动后执行自定义初始化逻辑
        LambdaQueryWrapper<TSysConstants> wrapper =new LambdaQueryWrapper<>();
        wrapper.eq(TSysConstants::getIsDeleted, Constant.ZERO);
        wrapper.eq(TSysConstants::getIsEnable, Constant.ONE);
        List<TSysConstants> constantsList = constantsMapper.selectList(wrapper);
        Map<String, List<TSysConstants>> constantsMap = constantsList.stream()
                .collect(Collectors.groupingBy(TSysConstants::getSType));
        for (Map.Entry<String, List<TSysConstants>> typeMap : constantsMap.entrySet()
        ) {
            RedisUtils.remove(typeMap.getKey());
            Map<String, String> consMap = typeMap.getValue().stream().collect(Collectors.toMap(TSysConstants::getSKey, TSysConstants::getSValue));
            RedisUtils.setHashMap(typeMap.getKey(), consMap);
            log.info("=========初始化常量type:{}==========",typeMap.getKey());
        }
        log.info("=========初始化常量参数缓存结束==========");
    }
}

