package com.riskcontrol.office.util;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.common.RabbitMQMessage;
import com.cn.schema.customers.WSCustomers;
import com.cn.schema.other.WSMsgMqSendRecord;
import com.cn.schema.other.WSQueryMsgMqSendRecord;
import com.riskcontrol.office.service.MsgMqFacade;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.DefaultManagedAwareThreadFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

@Component
public class RabbitMQUtils {

    private static final Logger logger = LoggerFactory.getLogger("webservice_api_logger");
    private static final ReentrantLock lock = new ReentrantLock();


    private static RabbitTemplate rabbitTemplate;

    private static MsgMqFacade msgMqFacade;



    /**
     * 注入静态变量
     */
    @Autowired
    public void setRabbitTemplate(RabbitTemplate rabbitTemplate) {
        RabbitMQUtils.rabbitTemplate = rabbitTemplate;
    }

    @Autowired
    public void setMsgMqFacade(MsgMqFacade msgMqFacade) {
        RabbitMQUtils.msgMqFacade = msgMqFacade;
    }


    /**
     * 四种拒绝策略：
     * 1.AbortPolicy=线程满了, 抛异常；
     * 2.CallerRunsPolicy=线程满了,使用主线程执行
     * 3.DiscardOldestPolicy=线程满了,直接终止执行
     * 4.DiscardPolicy=线程满了,直接拒绝处理
     */
    protected static final ThreadPoolExecutor execuctor;

    static {
        DefaultManagedAwareThreadFactory factory = new DefaultManagedAwareThreadFactory();
        factory.setThreadNamePrefix("Rabbit ThreadPoolExecutor");
        execuctor = new ThreadPoolExecutor(
                10, 30, 5000, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(2048), factory, new ThreadPoolExecutor.AbortPolicy());
    }


    public static void send(EXCHANGE_ENUM instance, String message, String productId) {
        String uuid = MDC.get("ticket");
        String traceId = MDC.get("traceId");
        String spanId = MDC.get("spanId");
        execuctor.execute(() -> {
            MDC.put("uuid", uuid);
            MDC.put("traceId", traceId);
            MDC.put("spanId", spanId);
            boolean sendFlag = true;
            try {
                rabbitTemplate.convertAndSend(instance.getExchange(), productId + "." + instance.getRoutingKey(), message, message0 -> {
                    message0.getMessageProperties().setMessageId(UUID.randomUUID().toString());
                    return message0;
                });
                logger.info("{} 发送Rabbit消息成功！routingKey:{},消息内容：{}。", productId, instance.getRoutingKey(), message);
            } catch (Exception e) {
                sendFlag = false;
                logger.error("{} 发送Rabbit消息失败！routingKey:{},消息内容：{}。", productId, instance.getRoutingKey(), message, e);
            }
            // 发送失败添加jms消息发送数据库记录
            if (!sendFlag) {
                try {
                    WSMsgMqSendRecord bean = new WSMsgMqSendRecord();
                    bean.setProductId(productId);
                    bean.setRabbitExchangeName(instance.getExchange());
                    bean.setMsgData(message);
                    bean.setMsgType("2");
                    msgMqFacade.createMsgMq(bean);

                } catch (Exception e) {
                    logger.error("Rabbit消息发送失败，保存发送记录至数据库失败！exchange：{}， 消息内容：{}", instance.getExchange(), message, e);
                }
            } else {
                String id = "";
                String msgData = "";
                String msgProductId = "";
                try {
                    if (lock.tryLock()) {
                        WSQueryMsgMqSendRecord query = new WSQueryMsgMqSendRecord();
                        query.setProductId(productId);
                        query.setMsgType("2");
                        query.setFlag("0");
                        query.setPageSize(1000);
                        query.setPageNum(1);
                        query.setOrder("id");
                        List<WSMsgMqSendRecord> wsMsgMqSendRecords = msgMqFacade.queryPageMsgMqByCondition(query);
                        if (CollectionUtils.isNotEmpty(wsMsgMqSendRecords)) {
                            for (WSMsgMqSendRecord wsMsgMqSendRecord : wsMsgMqSendRecords) {
                                if (StringUtils.isBlank(wsMsgMqSendRecord.getRabbitExchangeName()) || StringUtils.isBlank(wsMsgMqSendRecord.getMsgData()) || StringUtils.isBlank(wsMsgMqSendRecord.getProductId())) {
                                    continue;
                                }
                                id = wsMsgMqSendRecord.getId();
                                msgData = wsMsgMqSendRecord.getMsgData();
                                msgProductId = wsMsgMqSendRecord.getProductId();
                                rabbitTemplate.convertAndSend(instance.getExchange(), wsMsgMqSendRecord.getProductId() + "." + instance.getRoutingKey(), wsMsgMqSendRecord.getMsgData());
                                msgMqFacade.deleteById(wsMsgMqSendRecord.getId(), productId);
                                logger.info("重新发送Rabbit消息成功！exchange：{}，消息内容：{},id:{}", wsMsgMqSendRecord.getRabbitExchangeName(), wsMsgMqSendRecord.getMsgData(), wsMsgMqSendRecord.getId());
                            }
                        }
                        lock.unlock();
                    }
                } catch (Exception e) {
                    logger.error("重新发送Rabbit MQ消息失败,id:{},产品ID:{},消息内容:{}", id, msgProductId, msgData, e);
                }
            }
        });

    }


    // 修改KYC发送消息.
    public static void sendCustomerUpdateKyc(JSONObject map) {
        RabbitMQMessage<JSONObject> message = new RabbitMQMessage<>(EXCHANGE_ENUM.CUSTOMER_UPDATE_KYC.getRoutingKey(), map);
        send(EXCHANGE_ENUM.CUSTOMER_UPDATE_KYC, JSONObject.toJSONString(message), map.getString("productId"));
    }
    public static JSONObject buildCustomerKycStatusParams(WSCustomers wsCustomers, String kycStatus) {
        return new JSONObject()
                .fluentPut("productId", wsCustomers.getProductId())
                .fluentPut("loginName", wsCustomers.getLoginName())
                .fluentPut("kycStatus", kycStatus)
                .fluentPut("parentId", wsCustomers.getParentId())
                .fluentPut("parentLoginName", wsCustomers.getParentLoginName())
                .fluentPut("domainName", wsCustomers.getDomainName())
                .fluentPut("createdDate", wsCustomers.getCreatedDate())
                .fluentPut("customerId", wsCustomers.getCustomerId())
                .fluentPut("tenant", wsCustomers.getTenant());
    }

    public enum EXCHANGE_ENUM {
        //登录
        CUSTOMER_LOGIN("exchange_customer_login", "customer.login"),
        //注册
        CUSTOMER_REGISTER("exchange_customer_register", "customer.register"),
        //绑定银行卡
        BIND_BANK_CARD("exchange_bind_bank_card", "bind.bank.card"),
        //绑定手机号
        BIND_MOBILE("exchange_ws_bind_mobile", "customer.bind.mobile"),
        //绑定邮箱
        BIND_EMAIL("exchange_customer_bind_email", "customer.bind.email"),
        //存款
        CUSTOMER_TOPUP("exchange_customer_topup", "customer.topup"),
        //洗码
        CUSTOMER_REBATE("exchange_customer_rebate", "customer.rebate"),
        //优惠申请
        CUSTOMER_PROMOTION("exchange_customer_promotion", "customer.promotion"),
        //额度修改
        CREDIT_MODIFY("exchange_credit_modify", "request.credit.modify"),
        //取款申请
        WITHDRAW_APPLY("exchange_withdraw_apply", "customer.withdraw.apply"),
        //取款审批
        WITHDRAW_APPROVE("exchange_withdraw_approve", "customer.withdraw.approve"),
        //在线支付
        ONLINE_PAY("exchange_online_pay", "customer.online.pay"),
        //KYC
        KYC_MATCH_RISK("exchange_kyc_match_risk", "kyc.match.risk"),
        //修改客户信息
        MODIFY_ACCOUNT("exchange_modify_account", "customer.modify.account"),
        //测试队列
        TEST_HEALTH("exchange_test_health", "ws.test.health"),
        //修改上级
        MODIFY_PARENT("exchange_modify_parent", "customer.modify.parent"),
        //修改手机号
        MODIFY_MOBILE("exchange_modify_mobile", "customer.modify.mobile"),
        //修改银行卡
        MODIFY_BANK_CARD("exchange_modify_bank_card", "modify.bank.card"),
        //修改等级
        MODIFY_LEVEL("exchange_modify_level", "customer.modify.level"),
        //第三方充值
        THIRD_CHARGE("exchange_third_charge", "third.charge"),
        //修改真实姓名
        MODIFY_REALNAME("exchange_modify_realname", "customer.modify.realname"),
        //验证归属地四要素信息
        REGION_VALIDATE("exchange_region_check", "region.check"),
        //关联账号额度兑换提案
        CREDIT_EXCHANGE("exchange_credit_convert", "credit_convert"),
        //佣金转下线/佣金转游戏
        CREDIT_COMMISSION("exchange_credit_commission", "credit.commission"),
        //修改三级分销币商标志
        MODIFY_CURRENCY_DEALER("exchange_modify_dealer", "customer.modify.dealer"),
        //取款取消
        WITHDRAW_CANCEL("exchange_withdraw_cancel", "customer.withdraw.cancel"),
        //个推消息
        PUSH_MESSAGE("exchange_public_ips", "public.ips.send"),
        //新增或修改开户渠道
        CUSTOMER_SOURCE_MOMAIN("exchange_customer_source_domain", "#.domain.update"),
        //创建银改提案
        CUSTOMER_BANK_REQUEST("exchange_customer_bank", "customer.customer.bank"),
        //触发对账记录
        CHECK_CREDIT_EXCEPTION_LOGS("exchange_check_credit_exception_logs", "check.credit.exception.logs"),
        // 新增潜力 vip 挖掘
        CREATE_POTENTIAL_VIP_CONFIG("exchange_create_potential_vip_config", "create.potential.vip.config"),
        // 同步潜力 vip 客户名单
        SYNC_POTENTIAL_VIP_CUSTOMER("exchange_sync_potential_vip_customer", "sync.potential.vip.customer"),

        // 修改玩家语言
        MODIFY_LANGUAGE("exchange_modify_language", "customer.modify.language"),

        JOB_MANAGE("exchange_job_manage", "job.manage"),
        // 玩家状态禁用
        CUSTOMER_DISABLE("exchange_customer_disable", "customer.disable"),
        // 修改用户上级消息队列(同步至活动系统)
        CUSTOMER_UPDATE_PARENT("exchange_customer_update_parent", "customer.update.parent"),
        // 修改用户KYC状态消息队列(同步至活动系统)
        CUSTOMER_UPDATE_KYC("exchange_customer_update_kyc", "customer.update.kyc"),
        // 新首存(同步至活动系统)
        CUSTOMER_UPDATE_NEW_FIRST_DEPOSIT("exchange_customer_update_new_first_deposit", "customer.update.new.first.deposit"),
        // 首存(同步至活动系统)
        CUSTOMER_UPDATE_FIRST_DEPOSIT("exchange_customer_update_first_deposit", "customer.update.first.deposit"),
        // 第三方绑定
        CUSTOMER_THIRD_BIND("exchange_customer_third_bind", "customer.third.bind"),
        // 用户登录日志信息同步到DC
        CUSTOMER_LOGIN_ITEM_TODC("exchange_customer_login_item_todc", "customer.login.item.todc"),

        // 消息推送之OTP类
        PUSH_CUSTOMER_OTP_MESSAGE("exchange_otp_message", "routing.otp.message.queue"),

        APPROVE_BANK_CARD("exchange_approve_bank_card", "routing.approve.bank.card"),
        // 发送存款完成消息
        DEPOSIT_COMPLETED("exchange_deposit_completed", "routing.deposit.completed"),

        // 报表人工重新汇总
        REPORT_MANUAL_RE_SUMMARY("exchange_report_manual_re_summary", "report.manual.re.summary");

        private String exchange;
        private String routingKey;

        EXCHANGE_ENUM(String exchange, String routingKey) {
            this.exchange = exchange;
            this.routingKey = routingKey;
        }

        public String getExchange() {
            return exchange;
        }

        public String getRoutingKey() {
            return routingKey;
        }
    }

}

