package com.riskcontrol.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gw.datacenter.vo.pagainate.PageModel;
import com.riskcontrol.office.domain.entity.TRiskActionAllowOperationLog;
import com.riskcontrol.office.domain.req.BlackOperationListPageQueryReq;
import com.riskcontrol.office.domain.req.WhiteListPageQueryReq;
import com.riskcontrol.office.domain.rsp.BlcackOpertionLogListPageQueryRsp;
import com.riskcontrol.office.domain.rsp.WhiteListPageQueryRsp;
import org.springframework.stereotype.Service;


public interface TRiskActionAllowOperationLogService  {
    PageModel<BlcackOpertionLogListPageQueryRsp> getPageBlackOperationList(BlackOperationListPageQueryReq req);
}
