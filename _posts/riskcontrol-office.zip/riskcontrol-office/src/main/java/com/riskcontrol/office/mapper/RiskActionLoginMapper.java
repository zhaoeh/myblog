package com.riskcontrol.office.mapper;

import com.riskcontrol.office.domain.entity.TRiskActionLogin;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RiskActionLoginMapper extends BaseMapperX<TRiskActionLogin> {
}