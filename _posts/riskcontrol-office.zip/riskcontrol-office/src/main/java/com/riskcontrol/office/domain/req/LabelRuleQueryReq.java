package com.riskcontrol.office.domain.req;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.entity.request.BasePageRequest;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigInteger;

@Data
@Schema(description="风控标签-规则关联关系 查询对象")
public class LabelRuleQueryReq extends BasePageRequest {
    @Schema(description = "标签Id")
    @Query
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger labelId;

    @Schema(description = "标签key")
    @Query
    private String labelKey;

    @Schema(description = "风控规则")
    @Query
    private String ruleAction;

    @Schema(description = "标志:0-未启用；1-已启用")
    @Query
    private Integer status;

    @Schema(description = "优先级")
    private Integer priority;

    private static final long serialVersionUID = 1L;
}