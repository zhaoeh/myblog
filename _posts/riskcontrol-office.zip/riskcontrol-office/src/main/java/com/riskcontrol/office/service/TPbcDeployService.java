package com.riskcontrol.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.domain.entity.TPbcDeploy;
import com.riskcontrol.office.domain.req.PbcDeployReq;

public interface TPbcDeployService extends IService<TPbcDeploy>{
    /**
     * 查询配置文件列表
     *
     * @return
     */
    PageModel<TPbcDeploy> getPBCDeployList(PbcDeployReq req);

    /**
     * 修该配置文件
     * @param req
     * @return
     */
    Boolean updateDeploy(PbcDeployReq req) throws Exception;

    /**
     * 停止PBC爬虫配置文件
     * @param req
     * @return
     */
    Boolean disableDeploy(PbcDeployReq req);

}
