package com.riskcontrol.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.domain.entity.TLabelRuleRelationship;
import com.riskcontrol.office.domain.req.LabelRuleEditReq;
import com.riskcontrol.office.domain.req.LabelRuleQueryReq;
import com.riskcontrol.office.domain.vo.TLabelRuleRelationshipVo;
import org.springframework.web.bind.annotation.RequestBody;

import java.math.BigInteger;

public interface TLabelRuleRelationshipService extends IService<TLabelRuleRelationship>{

    PageModel<TLabelRuleRelationship> queryLabelRuleList(@RequestBody LabelRuleQueryReq req);
    PageModel<TLabelRuleRelationshipVo> queryLabelRuleListVo(@RequestBody LabelRuleQueryReq req);
    boolean create(LabelRuleEditReq req);
    boolean updateById(LabelRuleEditReq req);
    boolean deleteById(BigInteger id);
    boolean updateStatusById(LabelRuleEditReq req);
}
