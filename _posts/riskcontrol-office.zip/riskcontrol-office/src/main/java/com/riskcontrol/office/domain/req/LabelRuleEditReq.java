package com.riskcontrol.office.domain.req;

import com.riskcontrol.office.domain.validation.LabelRuleRelationshipReqValidator;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;

@Data
@Schema(description="风控标签-规则关联关系 编辑对象")
public class LabelRuleEditReq {
    @Schema(description="主键id")
    @NotNull(groups = LabelRuleRelationshipReqValidator.class,message = "id can not  be null")
    private BigInteger id;

    @Schema(description = "风控规则")
    @NotBlank(message = "ruleAction can not  be null")
    private String ruleAction;

    @Schema(description="标签ID")
    @NotNull(message = "labelId can not  be null")
    private BigInteger labelId;

    @Schema(description="备注")
    @NotBlank(message = "remark can not  be null")
    private String remark;

    private Integer status;

    private static final long serialVersionUID = 1L;
}