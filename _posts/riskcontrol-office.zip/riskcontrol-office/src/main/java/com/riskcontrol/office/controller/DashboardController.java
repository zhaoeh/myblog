package com.riskcontrol.office.controller;

import com.cn.schema.request.WSQueryWithdrawalRequests;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequest;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.common.enums.KYCStatusEnum;
import com.riskcontrol.office.domain.rsp.PendingCount;
import com.riskcontrol.office.service.ICustomersService;
import com.riskcontrol.office.service.IWithdrawalService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.Date;

/**
 * @author: sanji
 * @desc: 仪表盘-首页数据
 * @date: 2024/8/2 9:30
 */
@Tag(name = "首页仪表盘", description = "首页仪表盘")
@RestController
@RequestMapping(value = "/dashboard")
@Slf4j
public class DashboardController {

    @Resource
    private IWithdrawalService withdrawalService;
    @Resource
    private ICustomersService customersService;
    @Operation(tags ="首页仪表盘" ,summary = "查询3天kyc&取款待审批数量")
    @PostMapping(value = "queryKycAndWithdrawPending")
    @ResponseBody
    public R<PendingCount> queryKycAndWithdrawPending() {
        PendingCount pendingCount = new PendingCount();
        Date date = new Date();
        Date startDate = DateUtils.addDay(date, -2);
        String beginDateStr = DateUtils.dateToString(startDate) + " 00:00:00";
        String endDateStr = DateUtils.formatToDayEnding(date);
        //查询3天内待审批取款数量
        WSQueryWithdrawalRequests query = new WSQueryWithdrawalRequests();
        query.setFlag("0;9");
        query.setProductId("C66");
        query.setCreatedDateBegin(beginDateStr);
        query.setCreatedDateEnd(endDateStr);
        pendingCount.setWithdrawCount(withdrawalService.queryWithdrawalCount(query));
        //查询3天内待审批KYC数量
        RiskQueryKycRequest req = new RiskQueryKycRequest();
        req.setCreatedDateBegin(beginDateStr);
        req.setCreatedDateEnd(endDateStr);
        req.setStatusList(String.valueOf(KYCStatusEnum.DISTRIBUTED.getKycStatus()));
        pendingCount.setKycCount(customersService.queryKycRequestCount(req));

        return R.ok(pendingCount);
    }

}
