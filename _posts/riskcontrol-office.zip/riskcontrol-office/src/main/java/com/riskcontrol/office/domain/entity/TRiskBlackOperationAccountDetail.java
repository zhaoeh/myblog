package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigInteger;

/**
 * @author Heng.zhang
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_risk_black_operation_log_account_detail")
@ApiModel(value = "t_risk_black_operation_log_account_detail", description = "黑名单历史操作记录明细的关联账号明细表")
public class TRiskBlackOperationAccountDetail extends BaseEntity {
    @ApiModelProperty("ID")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;


    @ApiModelProperty(value = "操作日志明细表id")
    private BigInteger logDetailId;

    @ApiModelProperty(value = "账号")
    private String loginName;

    @ApiModelProperty(value = "创建日期(Create Time)")
    protected String createDate;

}