package com.riskcontrol.office.core;

import com.baomidou.mybatisplus.extension.service.IService;

public interface BaseService<T> extends IService<T> {
}
