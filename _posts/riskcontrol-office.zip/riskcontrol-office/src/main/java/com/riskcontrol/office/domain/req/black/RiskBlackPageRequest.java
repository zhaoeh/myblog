package com.riskcontrol.office.domain.req.black;

import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.constants.SQLConstants;
import com.riskcontrol.common.entity.request.BasePageRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


/**
 * @author Heng.zhang
 */
@Data
@ApiModel(value = "风控黑名单分页查询请求对象", description = "风控黑名单分页查询参数")
public class RiskBlackPageRequest extends BasePageRequest {

    @ApiModelProperty("账号")
    @Query(field = "loginName")
    private String account;

    @ApiModelProperty("ip")
    private String ip;

    @ApiModelProperty("手机号")
    private String phoneNumber;

    @ApiModelProperty("手机号")
    @Query
    private String phoneMd5;

    @ApiModelProperty("证件id")
    @Query
    private String idNo;

    @ApiModelProperty("名字")
    @Query
    private String firstName;

    @ApiModelProperty("中间名")
    @Query
    private String middleName;

    @ApiModelProperty("姓")
    @Query
    private String lastName;

    @ApiModelProperty("生日")
    @Query
    private String birthday;
    @ApiModelProperty(value = "黑名单来源：0：人工、1：关联匹配、2：pagcor黑名单")
    @Query
    private String source;

}