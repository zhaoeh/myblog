package com.riskcontrol.office.domain.customers.rsp;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class WsCustomer implements Serializable {

	private static final long serialVersionUID = 1L;

	@ApiModelProperty("体育押金领取时间")
	protected String releaseTimeSport;

	@ApiModelProperty("电游押金领取时间")
	protected String releaseTimeSlot;

	@ApiModelProperty( value = "领取时间")
	private String actReceiveTime;

	@ApiModelProperty( value = "冻结金额",example = "1000")
	private String frozenAmount;

	@ApiModelProperty(value = "玩家类型：Normal、PreVIP、VIP,默认Normal")
	private String custType;

	@ApiModelProperty(value = "存款标识：1是0否， 13个自然周单笔存款是否达1万")
	private String depositFlag;

	@ApiModelProperty(value = "是否开通线上投注:1开通,0未开通")
	private String onlineBet;

    @ApiModelProperty(value = "体育站是否开通线上投注:1开通,0未开通")
	private String sportsBetFlag;
	@ApiModelProperty("注册时，保证金的状态")
	protected String marginSwitch;

	@ApiModelProperty(value = "有效投注标识：1是0否， 13个自然周单周达成7万流水")
	private String turnoverFlag;

	@ApiModelProperty(value = "VIP的有效时间")
	private String vipValidTime;
	private String province;
	private String city;
	private String postalCode;
	@ApiModelProperty(value = "通讯账号")
	protected String messager;
	@ApiModelProperty(value = "通讯账号")
	protected String viber;

	@ApiModelProperty("会员编号")
    private String customerId;

	@ApiModelProperty(required = true, value = "会员登录名")
    private String loginName;

	@ApiModelProperty(required = true, value = "会员类型")
    private String customerType;

	@ApiModelProperty("会员星级")
    private Integer starLevel;

	@ApiModelProperty("会员星级名称")
    private String starLevelName;

	@ApiModelProperty("会员手机号[遮盖]")
    private String mobileNo;

	@ApiModelProperty(value = "客户登录次数,登录时+1",example="100")
	protected String loginTimes;

	@Deprecated
	@ApiModelProperty("会员手机号Md5[废弃]")
    private String mobileNoMd5;

	@ApiModelProperty("性别")
    private String gender;

	@ApiModelProperty("出生日期")
    private String birthday;

	@ApiModelProperty("地址")
    private String address;

	@ApiModelProperty("注册日期")
    private String registDate;

	@ApiModelProperty("备注")
    private String remark;

	@ApiModelProperty("手机是否绑定[0:否; 1:是]")
    private Integer mobileNoBind;

	@ApiModelProperty("会员邮件账号[遮盖]")
    private String email;

	@ApiModelProperty("邮件是否绑定[0:否; 1:是]")
    private Integer emailBind;

	@ApiModelProperty("真实名称")
    private String realName;

	@Deprecated
	@ApiModelProperty("真实名称Md5值[废弃]")
	private String realNameMd5;

	@ApiModelProperty("预留信息")
    private String verifyCode;

	@ApiModelProperty("本地现金额度")
    private BigDecimal cashCredit;

	@ApiModelProperty("本地游戏额度")
    private BigDecimal gameCredit;

	@ApiModelProperty("绑定银行卡张数")
    private Integer bankCardNum;

	@ApiModelProperty("绑定比特币账号个数")
    private Integer btcNum;

	@ApiModelProperty("绑定USDT钱包个数")
	private Integer usdtNum;

	@ApiModelProperty("绑定币付宝账号个数")
	private Integer bfbNum;

	@ApiModelProperty("绑定小金库账号个数")
	private Integer dcboxNum;

    @ApiModelProperty("周有效投注额")
    private BigDecimal weeklyBetAmount;

    @ApiModelProperty("升星级所需投注额")
    private BigDecimal upgradeRequiredBetAmount;

    @ApiModelProperty("当月已领取总优惠额度")
    private BigDecimal promoAmountByMonth;

    @ApiModelProperty("当月已洗总洗码额度")
    private BigDecimal rebatedAmountByMonth;

    @ApiModelProperty("是否可以自助洗码[][0:否; 1:是]")
    private Integer xmFlag;

	@ApiModelProperty("创建时间")
	private String createdDate;

	@ApiModelProperty("产品ID")
	private String productId;

	@ApiModelProperty(value = "下线疑似套利标志[0-无套利  1-疑似套利]")
	private int downlineArbit;

	@ApiModelProperty(value = "线下转线上用户 0--门店  1--线上  3--既有门店  REGISTER_FROM_TYPE")
	private int offlineUser;

	@ApiModelProperty(value = "下线是否禁止洗吗")
	private int downlineDisXm;

	@ApiModelProperty(value = "状态")
	private String flag;

	@ApiModelProperty(value = "首次存款时间")
	private String firstDepositDate;

	@ApiModelProperty("用户星级")
	private String customerLevel;

	@ApiModelProperty("生日日期")
	private String birthDate;

	@ApiModelProperty("用户头像")
	private String headshot;

	@ApiModelProperty(required = true, value = "密码")
	private String pwd;

	@ApiModelProperty(value = "扩展字段")
	private String reserve4;

	@ApiModelProperty(value = "更新人")
	private String lastUpdatedBy;

	@ApiModelProperty("信用等级")
	private String depositLevel;

	@ApiModelProperty(value = "会员总积分")
	private String integral;

	@ApiModelProperty(value = "会员体育总积分")
	private String integralSport;

	@ApiModelProperty(value = "会员电游总积分")
	private String integralSlot;

	@ApiModelProperty(value = "会员已使用总积分")
	private String integralUsed;

	@ApiModelProperty(value = "手机号码[可解密]")
	private String phone;

	@ApiModelProperty(value = "手机是否通过验证")
	private int phoneValidateStatus;

	@ApiModelProperty(value = "手机是否有效状态")
	private String phoneFlag;

	@ApiModelProperty(value = "首次投注时间")
	private String firstBetTime;

	@ApiModelProperty(value = "注册类型")
	private String registerType;

	@ApiModelProperty(value = "绑定手机号")
	private String bondPhone;

	@Deprecated
	@ApiModelProperty(value = "手机号MD5值[废弃]")
	private String phoneMd5;

	@ApiModelProperty(value = "是否推荐")
	private String isRecommend;

	@ApiModelProperty(required = true, value = "IP地址")
	private String ipAddress;

	@ApiModelProperty(value = "推荐帐号ID")
	private String partnerCustomerId;

	@ApiModelProperty(value = "创建人")
	private String createdBy;

	@ApiModelProperty(value = "性别")
	private String sex;

	@ApiModelProperty(value = "旧密码")
	private String oldpwd;

	@ApiModelProperty(value = "设备ID")
	private String deviceId;

	@ApiModelProperty("电话号码前缀")
	private String phonePrefix;

	@ApiModelProperty(required = true, value = "域名")
	private String domainName;

	@ApiModelProperty("市场部标识,用于区别合作伙伴是否为市场部所有,0-否 1-是")
	private String isMarket;

	@ApiModelProperty("绑定账号")
	private String bindAccount;

	@ApiModelProperty("货币")
	private String currency;

	@ApiModelProperty("推荐人用户名")
	private String parentLoginName;

	@ApiModelProperty("推荐人ID")
	private String parentId;

	@ApiModelProperty("最后登录时间")
	private String lastLoginDate;

	@ApiModelProperty("最后登录ip")
	private String lastLoginIp;

	@ApiModelProperty("累计存款-不分类型")
	private String  depositAmount;

	@ApiModelProperty("俱乐部等级")
	private String  clubLevel;

	@ApiModelProperty("客户优先级[-5=套利客,-4=测试,-3=下线,-2=关注,-1=黑名单,0=普通会员，1=VIP,2=白名单,6=高频小额]")
	private String priorityLevel;

	@ApiModelProperty("活动/抽奖积分")
	private String integralDraw;

	@ApiModelProperty(value = "总有效投注额")
	private String sumBetAmount;

	@ApiModelProperty(value ="语音验证状态[0:未验证;1:已验证]")
	private Integer voiceVerifyStatus;


	@ApiModelProperty("晋级状态[0:禁用;1启用]")
	private String raiseLevelFlag;


	@ApiModelProperty("用户发送红包状态--1：启用、0：禁用")
	private String redEnvelopeStatus;

	@ApiModelProperty(value = "优惠启用标识，1-启用 0-不启用")
	private String promotionFlag;
	@ApiModelProperty("是否新用户标志位[1：表示新注册用户，其他：非新注册用户]")
	private Integer newAccountFlag;

	public Integer getNewAccountFlag() {
		return newAccountFlag;
	}

	public void setNewAccountFlag(Integer newAccountFlag) {
		this.newAccountFlag = newAccountFlag;
	}

	@ApiModelProperty(value = "门店编码",example="001")
	private String branchCode;

	@ApiModelProperty(value = "门店名称",example="Greenbelt4")
	private String branchName;

	@ApiModelProperty(value = "branchSupportedGames",example="5")
	protected String branchSupportedGames;

	@ApiModelProperty(value = "菲律宾人：姓",example="John")
	private String firstName;

	@ApiModelProperty(value = "菲律宾人：中间名",example="Gomez")
	private String middleName;

	@ApiModelProperty(value = "菲律宾人：名",example="Gonzales")
	private String lastName;

	@ApiModelProperty(value = "证件类型",example="0001")
	protected String firstIdType;

	@ApiModelProperty(value = "证件编号",example="9874685213498AE9875")
	protected String firstNoType;

	@ApiModelProperty(value = "证件照片ID",example="2749a1257c354e7bae424f3e3eea7f89")
	protected String firstIdScan;

	@ApiModelProperty(value = "证件照片ID-V2",example = "6454321213123401113132103")
	protected String firstIdScanV2;

	@ApiModelProperty(value = "first imageKey",example = "2542131321213123213")
	protected String firstImageKey;

	@ApiModelProperty(value = "证件类型",example="0001")
	protected String secondIdType;

	@ApiModelProperty(value = "证件编号",example="9874685213498AE9875")
	protected String secondNoType;

	@ApiModelProperty(value = "证件照片ID",example="2749a1257c354e7bae424f3e3eea7f89")
	protected String secondIdScan;

	@ApiModelProperty(value = "证件照片ID2-V2",example = "2456543213213543546166654656")
	protected String secondIdScanV2;

	@ApiModelProperty(value = "second imageKey",example = "554561464687313213")
	private String secondImageKey;

	@ApiModelProperty("国籍")
	protected String nationality;

	@ApiModelProperty(value = "是否激活：1是 0否", example = "0")
	protected String activation;

	@ApiModelProperty(value = "激活时间")
	protected String activitionTime;

	@ApiModelProperty(value = "0-门店注册  1-官网线上注册  3-既有门店导入注册", example = "0")
	protected Integer registerFromType;

	@ApiModelProperty("人脸识别图片")
	protected String original;

	@ApiModelProperty("职业")
	protected String occupation;

	@ApiModelProperty("收入来源")
	protected String sourceOfIncome;

	@ApiModelProperty("年收入")
	protected String annualIncome;

	@ApiModelProperty("社交媒体类型")
	private String socialMediaType;

	@ApiModelProperty("社交媒体值（联系账号）")
	private String socialMediaValue;

	@ApiModelProperty("玩家银行列表<br/>Player‘s bank account list")
	protected List<BankAccountInfo> bankAccountInfos;

	@ApiModelProperty("是否激活开关")
	protected Boolean isActiveSwitch;

	@ApiModelProperty("昵称")
	private String nickName;

	@ApiModelProperty("注册方式：1.username+pwd ,3.完整注册, 2.phone, 4. email, 5. google, 6.facebook")
	private String registerMethod;

	@ApiModelProperty("应用类型[1:web; 2:android; 3:ios; 4:h5]")
	private Integer appType;

	@ApiModelProperty("kyc status, if any")
	private String kycStatus;

	@ApiModelProperty("新首存日期")
	private String newFirstDepositStatDate;

	@ApiModelProperty(value = "注册网站标识：1bingo；2 sport)")
	protected int siteId;

	@ApiModelProperty(value = "Market :01  Website :02 Store :03 glife:4  blue chip:5")
	private String chanelType;



    @ApiModelProperty(required = false,value = "雇主名字")
    protected String reserve2;



    @ApiModelProperty(required = false ,value = "签名照片id")
    protected String reserve3;
	public String getChanelType() {
		return chanelType;
	}

	public void setChanelType(String chanelType) {
		this.chanelType = chanelType;
	}

	@ApiModelProperty(value = "FromFriend: 0 否，1 是")
	private String fromFriend;

	@ApiModelProperty(value = "风控标签名称")
	private String riskLabelName;
	private String riskLabelId;




	public String getReserve2() {
        return reserve2;
    }

    public void setReserve2(String reserve2) {
        this.reserve2 = reserve2;
    }

    public String getReserve3() {
        return reserve3;
    }

    public void setReserve3(String reserve3) {
        this.reserve3 = reserve3;
    }
	public int getSiteId() {
		return siteId;
	}

	public void setSiteId(int siteId) {
		this.siteId = siteId;
	}

	public int getOfflineUser() {
		return offlineUser;
	}

	public void setOfflineUser(int offlineUser) {
		this.offlineUser = offlineUser;
	}

	public String getFirstIdType() {
		return firstIdType;
	}

	public void setFirstIdType(String firstIdType) {
		this.firstIdType = firstIdType;
	}

	public String getFirstNoType() {
		return firstNoType;
	}

	public void setFirstNoType(String firstNoType) {
		this.firstNoType = firstNoType;
	}

	public String getFirstIdScan() {
		return firstIdScan;
	}

	public void setFirstIdScan(String firstIdScan) {
		this.firstIdScan = firstIdScan;
	}

	public void setFirstImageKey(String firstImageKey){this.firstImageKey=firstImageKey;}

	public String getFirstImageKey(){return firstImageKey;}

	public String getSecondIdType() {
		return secondIdType;
	}

	public void setSecondIdType(String secondIdType) {
		this.secondIdType = secondIdType;
	}

	public String getSecondNoType() {
		return secondNoType;
	}

	public void setSecondNoType(String secondNoType) {
		this.secondNoType = secondNoType;
	}

	public String getSecondIdScan() {
		return secondIdScan;
	}

	public void setSecondIdScan(String secondIdScan) {
		this.secondIdScan = secondIdScan;
	}

	public void setSecondImageKey(String secondImageKey){
		this.secondImageKey=secondImageKey;
	}

	public String getSecondImageKey(){return secondImageKey;}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getBranchSupportedGames() {
		return branchSupportedGames;
	}

	public void setBranchSupportedGames(String branchSupportedGames) {
		this.branchSupportedGames = branchSupportedGames;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDepositAmount() {
		return depositAmount;
	}

	public void setDepositAmount(String depositAmount) {
		this.depositAmount = depositAmount;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

    public String getMobileNoMd5() {
        return mobileNoMd5;
    }

    public void setMobileNoMd5(String mobileNoMd5) {
        this.mobileNoMd5 = mobileNoMd5;
    }

    public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getMobileNoBind() {
		return mobileNoBind;
	}

	public void setMobileNoBind(Integer mobileNoBind) {
		this.mobileNoBind = mobileNoBind;
	}

	public Integer getEmailBind() {
		return emailBind;
	}

	public void setEmailBind(Integer emailBind) {
		this.emailBind = emailBind;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public Integer getStarLevel() {
		return starLevel;
	}

	public void setStarLevel(Integer starLevel) {
		this.starLevel = starLevel;
	}

	public String getVerifyCode() {
		return verifyCode;
	}

	public void setVerifyCode(String verifyCode) {
		this.verifyCode = verifyCode;
	}

	public BigDecimal getCashCredit() {
		return cashCredit;
	}

	public void setCashCredit(BigDecimal cashCredit) {
		this.cashCredit = cashCredit;
	}

	public Integer getBankCardNum() {
		return bankCardNum;
	}

	public void setBankCardNum(Integer bankCardNum) {
		this.bankCardNum = bankCardNum;
	}

	public Integer getBtcNum() {
		return btcNum;
	}

	public void setBtcNum(Integer btcNum) {
		this.btcNum = btcNum;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getRegistDate() {
		return registDate;
	}

	public void setRegistDate(String registDate) {
		this.registDate = registDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public BigDecimal getGameCredit() {
		return gameCredit;
	}

	public void setGameCredit(BigDecimal gameCredit) {
		this.gameCredit = gameCredit;
	}

	public String getStarLevelName() {
		return starLevelName;
	}

	public void setStarLevelName(String starLevelName) {
		this.starLevelName = starLevelName;
	}

    public BigDecimal getWeeklyBetAmount() {
        return weeklyBetAmount;
    }

    public void setWeeklyBetAmount(BigDecimal weeklyBetAmount) {
        this.weeklyBetAmount = weeklyBetAmount;
    }

    public BigDecimal getUpgradeRequiredBetAmount() {
        return upgradeRequiredBetAmount;
    }

    public void setUpgradeRequiredBetAmount(BigDecimal upgradeRequiredBetAmount) {
        this.upgradeRequiredBetAmount = upgradeRequiredBetAmount;
    }
	public void setFirstIdScanV2(String firstIdScanV2){
		this.firstIdScanV2=firstIdScanV2;
	}

	public String getFirstIdScanV2(){
		return firstIdScanV2;
	}

	public void setSecondIdScanV2(String secondIdScanV2){
		this.secondIdScanV2=secondIdScanV2;
	}

	public String getSecondIdScanV2(){
		return secondIdScanV2;
	}

    public BigDecimal getPromoAmountByMonth() {
        return promoAmountByMonth;
    }

    public void setPromoAmountByMonth(BigDecimal promoAmountByMonth) {
        this.promoAmountByMonth = promoAmountByMonth;
    }

    public BigDecimal getRebatedAmountByMonth() {
        return rebatedAmountByMonth;
    }

    public void setRebatedAmountByMonth(BigDecimal rebatedAmountByMonth) {
        this.rebatedAmountByMonth = rebatedAmountByMonth;
    }

    public Integer getXmFlag() {
        return xmFlag;
    }

    public void setXmFlag(Integer xmFlag) {
        this.xmFlag = xmFlag;
    }

	public String getRealNameMd5() {
		return realNameMd5;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public int getDownlineArbit() {
		return downlineArbit;
	}

	public void setDownlineArbit(int downlineArbit) {
		this.downlineArbit = downlineArbit;
	}

	public int getDownlineDisXm() {
		return downlineDisXm;
	}

	public void setDownlineDisXm(int downlineDisXm) {
		this.downlineDisXm = downlineDisXm;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getFirstDepositDate() {
		return firstDepositDate;
	}

	public void setFirstDepositDate(String firstDepositDate) {
		this.firstDepositDate = firstDepositDate;
	}

	public String getCustomerLevel() {
		return customerLevel;
	}

	public void setCustomerLevel(String customerLevel) {
		this.customerLevel = customerLevel;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getHeadshot() {
		return headshot;
	}

	public void setHeadshot(String headshot) {
		this.headshot = headshot;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getReserve4() {
		return reserve4;
	}

	public void setReserve4(String reserve4) {
		this.reserve4 = reserve4;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getDepositLevel() {
		return depositLevel;
	}

	public void setDepositLevel(String depositLevel) {
		this.depositLevel = depositLevel;
	}

	public void setRealNameMd5(String realNameMd5) {
		this.realNameMd5 = realNameMd5;
	}

	public String getIntegral() {
		return integral;
	}

	public void setIntegral(String integral) {
		this.integral = integral;
	}

	public String getIntegralSport() {
		return integralSport;
	}

	public void setIntegralSport(String integralSport) {
		this.integralSport = integralSport;
	}

	public String getIntegralSlot() {
		return integralSlot;
	}

	public void setIntegralSlot(String integralSlot) {
		this.integralSlot = integralSlot;
	}

	public String getIntegralUsed() {
		return integralUsed;
	}

	public void setIntegralUsed(String integralUsed) {
		this.integralUsed = integralUsed;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPhoneFlag() {
		return phoneFlag;
	}

	public void setPhoneFlag(String phoneFlag) {
		this.phoneFlag = phoneFlag;
	}

	public String getFirstBetTime() {
		return firstBetTime;
	}

	public void setFirstBetTime(String firstBetTime) {
		this.firstBetTime = firstBetTime;
	}

	public String getRegisterType() {
		return registerType;
	}

	public void setRegisterType(String registerType) {
		this.registerType = registerType;
	}

	public String getBondPhone() {
		return bondPhone;
	}

	public void setBondPhone(String bondPhone) {
		this.bondPhone = bondPhone;
	}

	public String getPhoneMd5() {
		return phoneMd5;
	}

	public void setPhoneMd5(String phoneMd5) {
		this.phoneMd5 = phoneMd5;
	}

	public String getIsRecommend() {
		return isRecommend;
	}

	public void setIsRecommend(String isRecommend) {
		this.isRecommend = isRecommend;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getPartnerCustomerId() {
		return partnerCustomerId;
	}

	public void setPartnerCustomerId(String partnerCustomerId) {
		this.partnerCustomerId = partnerCustomerId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getOldpwd() {
		return oldpwd;
	}

	public void setOldpwd(String oldpwd) {
		this.oldpwd = oldpwd;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getPhonePrefix() {
		return phonePrefix;
	}

	public void setPhonePrefix(String phonePrefix) {
		this.phonePrefix = phonePrefix;
	}

	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public String getIsMarket() {
		return isMarket;
	}

	public void setIsMarket(String isMarket) {
		this.isMarket = isMarket;
	}

	public String getBindAccount() {
		return bindAccount;
	}

	public void setBindAccount(String bindAccount) {
		this.bindAccount = bindAccount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getParentLoginName() {
		return parentLoginName;
	}

	public void setParentLoginName(String parentLoginName) {
		this.parentLoginName = parentLoginName;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public String getLastLoginDate() {
		return lastLoginDate;
	}

	public void setLastLoginDate(String lastLoginDate) {
		this.lastLoginDate = lastLoginDate;
	}

	public int getPhoneValidateStatus() {
		return phoneValidateStatus;
	}

	public void setPhoneValidateStatus(int phoneValidateStatus) {
		this.phoneValidateStatus = phoneValidateStatus;
	}

	public String getClubLevel() {
		return clubLevel;
	}


	public String getRaiseLevelFlag() {
		return raiseLevelFlag;
	}

	public void setRaiseLevelFlag(String raiseLevelFlag) {
		this.raiseLevelFlag = raiseLevelFlag;
	}

	public void setClubLevel(String clubLevel) {
		this.clubLevel = clubLevel;
	}

	public String getIntegralDraw() {
		return integralDraw;
	}

	public void setIntegralDraw(String integralDraw) {
		this.integralDraw = integralDraw;
	}

	public String getSumBetAmount() {
		return sumBetAmount;
	}

	public void setSumBetAmount(String sumBetAmount) {
		this.sumBetAmount = sumBetAmount;
	}

	public Integer getVoiceVerifyStatus() {
		return voiceVerifyStatus;
	}

	public void setVoiceVerifyStatus(Integer voiceVerifyStatus) {
		this.voiceVerifyStatus = voiceVerifyStatus;
	}

	public String getRedEnvelopeStatus() {
		return redEnvelopeStatus;
	}

	public void setRedEnvelopeStatus(String redEnvelopeStatus) {
		this.redEnvelopeStatus = redEnvelopeStatus;
	}

	public String getPriorityLevel() {
		return priorityLevel;
	}

	public void setPriorityLevel(String priorityLevel) {
		this.priorityLevel = priorityLevel;
	}

	public Integer getUsdtNum() {
		return usdtNum;
	}

	public void setUsdtNum(Integer usdtNum) {
		this.usdtNum = usdtNum;
	}


	public String getLastLoginIp() {
		return lastLoginIp;
	}

	public void setLastLoginIp(String lastLoginIp) {
		this.lastLoginIp = lastLoginIp;
	}

	public String getPromotionFlag() {
		return promotionFlag;
	}

	public void setPromotionFlag(String promotionFlag) {
		this.promotionFlag = promotionFlag;
	}

	public Integer getBfbNum() {
		return bfbNum;
	}

	public String getLoginTimes() {
		return loginTimes;
	}

	public void setLoginTimes(String loginTimes) {
		this.loginTimes = loginTimes;
	}

	public void setBfbNum(Integer bfbNum) {
		this.bfbNum = bfbNum;
	}

	public Integer getDcboxNum() {
		return dcboxNum;
	}

	public void setDcboxNum(Integer dcboxNum) {
		this.dcboxNum = dcboxNum;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	public String getDepositFlag() {
		return depositFlag;
	}

	public void setDepositFlag(String depositFlag) {
		this.depositFlag = depositFlag;
	}

	public String getTurnoverFlag() {
		return turnoverFlag;
	}

	public void setTurnoverFlag(String turnoverFlag) {
		this.turnoverFlag = turnoverFlag;
	}

	public String getVipValidTime() {
		return vipValidTime;
	}

	public void setVipValidTime(String vipValidTime) {
		this.vipValidTime = vipValidTime;
	}

	public String getMessager() {
		return messager;
	}

	public void setMessager(String messager) {
		this.messager = messager;
	}

	public String getViber() {
		return viber;
	}

	public void setViber(String viber) {
		this.viber = viber;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getActivation() {
		return activation;
	}

	public void setActivation(String activation) {
		this.activation = activation;
	}

	public String getActivitionTime() {
		return activitionTime;
	}

	public void setActivitionTime(String activitionTime) {
		this.activitionTime = activitionTime;
	}

	public Integer getRegisterFromType() {
		return registerFromType;
	}

	public void setRegisterFromType(Integer registerFromType) {
		this.registerFromType = registerFromType;
	}

	public String getOnlineBet() {
		return onlineBet;
	}

	public void setOnlineBet(String onlineBet) {
		this.onlineBet = onlineBet;
	}

	public String getSportsBetFlag() {
		return sportsBetFlag;
	}

	public void setSportsBetFlag(String sportsBetFlag) {
		this.sportsBetFlag = sportsBetFlag;
	}

	public String getActReceiveTime() {
		return actReceiveTime;
	}

	public void setActReceiveTime(String actReceiveTime) {
		this.actReceiveTime = actReceiveTime;
	}

	public String getFrozenAmount() {
		return frozenAmount;
	}

	public void setFrozenAmount(String frozenAmount) {
		this.frozenAmount = frozenAmount;
	}

	public String getOriginal() {
		return original;
	}

	public void setOriginal(String original) {
		this.original = original;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getSourceOfIncome() {
		return sourceOfIncome;
	}

	public void setSourceOfIncome(String sourceOfIncome) {
		this.sourceOfIncome = sourceOfIncome;
	}

	public List<BankAccountInfo> getBankAccountInfos() {
		return bankAccountInfos;
	}

	public void setBankAccountInfos(List<BankAccountInfo> bankAccountInfos) {
		this.bankAccountInfos = bankAccountInfos;
	}

	public String getReleaseTimeSport() {
		return releaseTimeSport;
	}

	public void setReleaseTimeSport(String releaseTimeSport) {
		this.releaseTimeSport = releaseTimeSport;
	}

	public String getReleaseTimeSlot() {
		return releaseTimeSlot;
	}

	public void setReleaseTimeSlot(String releaseTimeSlot) {
		this.releaseTimeSlot = releaseTimeSlot;
	}

	public String getSocialMediaType() {
		return socialMediaType;
	}

	public void setSocialMediaType(String socialMediaType) {
		this.socialMediaType = socialMediaType;
	}

	public String getSocialMediaValue() {
		return socialMediaValue;
	}

	public void setSocialMediaValue(String socialMediaValue) {
		this.socialMediaValue = socialMediaValue;
	}

	public Boolean getActiveSwitch() {
		return isActiveSwitch;
	}

	public void setActiveSwitch(Boolean activeSwitch) {
		isActiveSwitch = activeSwitch;
	}

	public String getMarginSwitch() {
		return marginSwitch;
	}

	public void setMarginSwitch(String marginSwitch) {
		this.marginSwitch = marginSwitch;
	}

	public String getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public String getRegisterMethod() {
		return registerMethod;
	}

	public void setRegisterMethod(String registerMethod) {
		this.registerMethod = registerMethod;
	}

	public Integer getAppType() {
		return appType;
	}

	public void setAppType(Integer appType) {
		this.appType = appType;
	}

	public String getKycStatus() {
		return this.kycStatus;
	}

	public void setKycStatus(String kycStatus) {
		this.kycStatus = kycStatus;
	}

	public String getNewFirstDepositStatDate() {
		return newFirstDepositStatDate;
	}

	public void setNewFirstDepositStatDate(String newFirstDepositStatDate) {
		this.newFirstDepositStatDate = newFirstDepositStatDate;
	}

	public String getFromFriend() {
		return fromFriend;
	}

	public void setFromFriend(String fromFriend) {
		this.fromFriend = fromFriend;
	}

	public String getRiskLabelName() {
		return riskLabelName;
	}

	public void setRiskLabelName(String riskLabelName) {
		this.riskLabelName = riskLabelName;
	}

	public String getRiskLabelId() {
		return riskLabelId;
	}

	public void setRiskLabelId(String riskLabelId) {
		this.riskLabelId = riskLabelId;
	}

	@Override
	public String toString() {
		return "WsCustomer{" +
				"releaseTimeSport='" + releaseTimeSport + '\'' +
				", releaseTimeSlot='" + releaseTimeSlot + '\'' +
				", actReceiveTime='" + actReceiveTime + '\'' +
				", frozenAmount='" + frozenAmount + '\'' +
				", custType='" + custType + '\'' +
				", depositFlag='" + depositFlag + '\'' +
				", onlineBet='" + onlineBet + '\'' +
				", sportsBetFlag='" + sportsBetFlag + '\'' +
				", marginSwitch='" + marginSwitch + '\'' +
				", turnoverFlag='" + turnoverFlag + '\'' +
				", vipValidTime='" + vipValidTime + '\'' +
				", province='" + province + '\'' +
				", city='" + city + '\'' +
				", postalCode='" + postalCode + '\'' +
				", messager='" + messager + '\'' +
				", viber='" + viber + '\'' +
				", customerId='" + customerId + '\'' +
				", loginName='" + loginName + '\'' +
				", customerType='" + customerType + '\'' +
				", starLevel=" + starLevel +
				", starLevelName='" + starLevelName + '\'' +
				", mobileNo='" + mobileNo + '\'' +
				", loginTimes='" + loginTimes + '\'' +
				", mobileNoMd5='" + mobileNoMd5 + '\'' +
				", gender='" + gender + '\'' +
				", birthday='" + birthday + '\'' +
				", address='" + address + '\'' +
				", registDate='" + registDate + '\'' +
				", remark='" + remark + '\'' +
				", mobileNoBind=" + mobileNoBind +
				", email='" + email + '\'' +
				", emailBind=" + emailBind +
				", realName='" + realName + '\'' +
				", realNameMd5='" + realNameMd5 + '\'' +
				", verifyCode='" + verifyCode + '\'' +
				", cashCredit=" + cashCredit +
				", gameCredit=" + gameCredit +
				", bankCardNum=" + bankCardNum +
				", btcNum=" + btcNum +
				", weeklyBetAmount=" + weeklyBetAmount +
				", upgradeRequiredBetAmount=" + upgradeRequiredBetAmount +
				", promoAmountByMonth=" + promoAmountByMonth +
				", rebatedAmountByMonth=" + rebatedAmountByMonth +
				", xmFlag=" + xmFlag +
				", createdDate='" + createdDate + '\'' +
				", productId='" + productId + '\'' +
				", downlineArbit=" + downlineArbit +
				", downlineDisXm=" + downlineDisXm +
				", flag='" + flag + '\'' +
				", firstDepositDate='" + firstDepositDate + '\'' +
				", customerLevel='" + customerLevel + '\'' +
				", birthDate='" + birthDate + '\'' +
				", headshot='" + headshot + '\'' +
				", pwd='" + pwd + '\'' +
				", reserve4='" + reserve4 + '\'' +
				", lastUpdatedBy='" + lastUpdatedBy + '\'' +
				", depositLevel='" + depositLevel + '\'' +
				", integral='" + integral + '\'' +
				", integralUsed='" + integralUsed + '\'' +
				", phone='" + phone + '\'' +
				", phoneValidateStatus=" + phoneValidateStatus +
				", phoneFlag='" + phoneFlag + '\'' +
				", firstBetTime='" + firstBetTime + '\'' +
				", registerType='" + registerType + '\'' +
				", bondPhone='" + bondPhone + '\'' +
				", phoneMd5='" + phoneMd5 + '\'' +
				", isRecommend='" + isRecommend + '\'' +
				", ipAddress='" + ipAddress + '\'' +
				", partnerCustomerId='" + partnerCustomerId + '\'' +
				", createdBy='" + createdBy + '\'' +
				", sex='" + sex + '\'' +
				", oldpwd='" + oldpwd + '\'' +
				", deviceId='" + deviceId + '\'' +
				", phonePrefix='" + phonePrefix + '\'' +
				", domainName='" + domainName + '\'' +
				", isMarket='" + isMarket + '\'' +
				", bindAccount='" + bindAccount + '\'' +
				", currency='" + currency + '\'' +
				", parentLoginName='" + parentLoginName + '\'' +
				", parentId='" + parentId + '\'' +
				", lastLoginDate='" + lastLoginDate + '\'' +
				", lastLoginIp='" + lastLoginIp + '\'' +
				", depositAmount='" + depositAmount + '\'' +
				", clubLevel='" + clubLevel + '\'' +
				", priorityLevel='" + priorityLevel + '\'' +
				", integralDraw='" + integralDraw + '\'' +
				", sumBetAmount='" + sumBetAmount + '\'' +
				", voiceVerifyStatus=" + voiceVerifyStatus +
				", raiseLevelFlag='" + raiseLevelFlag + '\'' +
				", redEnvelopeStatus='" + redEnvelopeStatus + '\'' +
				", usdtNum='" + usdtNum + '\'' +
				", promotionFlag='" + promotionFlag + '\'' +
				", bfbNum='" + bfbNum + '\'' +
				", activation='" + activation + '\'' +
				", dcboxNum='" + dcboxNum + '\'' +
				", nickName='" + nickName + '\'' +
				", registerMethod=" + registerMethod + '\'' +
				", appType=" + appType + '\'' +
				", newFirstDepositStatDate=" + newFirstDepositStatDate + '\'' +
                ", reserve2=" + reserve2 + '\'' +
                ", reserve3=" + reserve3 + '\'' +
				", kycStatus=" + kycStatus +
				'}';
	}
}
