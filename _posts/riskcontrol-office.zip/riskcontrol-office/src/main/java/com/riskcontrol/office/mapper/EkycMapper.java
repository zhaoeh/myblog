package com.riskcontrol.office.mapper;

import com.riskcontrol.office.domain.entity.TEkyc;
import org.apache.ibatis.annotations.Mapper;


/**
 * @author Heng.zhang
 */
@Mapper
public interface EkycMapper extends BaseMapperX<TEkyc> {

}
