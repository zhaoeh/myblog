package com.riskcontrol.office.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ComponentScan(basePackages = {"com.riskcontrol.common.utils"})
public class WsProductConfig {

    @Value("${ws.product.id}")
    private String wsProductId;

    @Value("${ws.product.pwd}")
    private String wsProductPwd;

    @Value("${ws.terminal}")
    private String wsTerminal;

}
