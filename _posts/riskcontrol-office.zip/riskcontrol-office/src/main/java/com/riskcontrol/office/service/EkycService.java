package com.riskcontrol.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.domain.entity.TEkyc;
import com.riskcontrol.office.domain.req.ekyc.EkycQueryRequest;
import com.riskcontrol.office.domain.rsp.ekyc.EkycQueryResponse;


/**
 * @author Heng.zhang
 */
public interface EkycService extends IService<TEkyc> {

    /**
     * ekyc表分页查询
     * @param request
     * @return
     */
    PageModel<EkycQueryResponse> pageEkycList(EkycQueryRequest request);

    /**
     * 创建ekyc
     * @param ekycEntity
     * @return
     */
    boolean ekycCreate(TEkyc ekycEntity);

    /**
     * 通过loginname获取ekyc信息
     * @param loginName
     * @return
     */
    TEkyc getEkycInfo(String loginName);
}
