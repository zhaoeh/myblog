package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.Date;

import lombok.Data;

/**
 * pbc配置文件
 */
@Schema(description = "pbc数据")
@Data
@TableName(value = "t_pbc_crawler_result_new")
public class TPbcCrawlerResultNew extends BaseEntity {

    /**
     * 名字
     */
    @TableField(value = "first_name", fill = FieldFill.INSERT)
    @Schema(description = "名字")
    private String firstName;

    /**
     * 中间名
     */
    @TableField(value = "middle_name", fill = FieldFill.INSERT)
    @Schema(description = "中间名")
    private String middleName;

    /**
     * 姓
     */
    @TableField(value = "last_name", fill = FieldFill.INSERT)
    @Schema(description = "姓")
    private String lastName;

    /**
     * 生日
     */
    @TableField(value = "birth_date", fill = FieldFill.INSERT)
    @Schema(description = "生日")
    private String birthDate;

    /**
     * pogcor ID
     */
    @TableField(value = "guest_ext_id", fill = FieldFill.INSERT)
    @Schema(description = "pogcor ID")
    private String guestExtId;

    /**
     * 禁用状态（0解除；1禁用）
     */
    @TableField(value = "is_banned")
    @Schema(description = "禁用状态(0解除, 1禁用)")
    private Integer isBanned;

    /**
     * pogcor禁用来源. GOVT:政府官员, GEL:从业者, Banned:自主申请
     */
    @TableField(value = "source")
    @Schema(description = "pogcor禁用来源. GOVT:政府官员, GEL:从业者, Banned:自主申请")
    private String source;

    /**
     * 创建时间
     */
    @Schema(description = "创建时间")
    private String createDate;

    /**
     * 修改时间
     */
    @TableField(value = "update_date")
    @Schema(description = "修改时间")
    private String updateDate;

    /**
     * pogcor 创建时间
     */
    @TableField(value = "date_created")
    @Schema(description = "pogcor 创建时间")
    private String dateCreated;

    /**
     * 创建人
     */
    @TableField(value = "create_by")
    @Schema(description = "创建人")
    private String createBy;

    /**
     * 更新人
     */
    @TableField(value = "update_by")
    @Schema(description = "更新人")
    private String updateBy;
}