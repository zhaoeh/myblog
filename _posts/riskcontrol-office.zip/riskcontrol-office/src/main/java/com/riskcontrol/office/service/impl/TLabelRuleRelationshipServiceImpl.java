package com.riskcontrol.office.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.enums.RuleEnum;
import com.riskcontrol.common.enums.YesNoEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.utils.CommonUtil;
import com.riskcontrol.office.common.constants.RedisConstant;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.domain.entity.TLabelRuleRelationship;
import com.riskcontrol.office.domain.entity.TRiskConstants;
import com.riskcontrol.office.domain.req.LabelRuleEditReq;
import com.riskcontrol.office.domain.req.LabelRuleQueryReq;
import com.riskcontrol.office.domain.vo.TLabelRuleRelationshipVo;
import com.riskcontrol.office.mapper.TLabelRuleRelationshipMapper;
import com.riskcontrol.office.mapper.TRiskConstantsMapper;
import com.riskcontrol.office.service.TLabelRuleRelationshipService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;


@Service
public class TLabelRuleRelationshipServiceImpl extends BaseServiceImpl<TLabelRuleRelationshipMapper, TLabelRuleRelationship> implements TLabelRuleRelationshipService {

    @Autowired
    TRiskConstantsMapper riskConstantsMapper;
    @Autowired
    private RedisTemplate<String,String> redisTemplate;
    @Override
    public PageModel<TLabelRuleRelationship> queryLabelRuleList(LabelRuleQueryReq req) {
        LambdaQueryWrapper<TLabelRuleRelationship> wrapper = buildWrapper(req);
        Page<TLabelRuleRelationship> page = pageByWrapper(req,wrapper);
        PageModel<TLabelRuleRelationship> pageResult = new PageModel<>();
        pageResult.setData(page.getRecords());
        pageResult.setPageNo((int) page.getCurrent());
        pageResult.setPageSize((int) page.getSize());
        pageResult.setTotalRow((int) page.getTotal());
        pageResult.setTotalPage((int) page.getPages());
        return pageResult;
    }

    @Override
    public PageModel<TLabelRuleRelationshipVo> queryLabelRuleListVo(LabelRuleQueryReq req) {
        HashMap param = JSONObject.parseObject(JSONObject.toJSONString(req), HashMap.class);
        Page<TLabelRuleRelationshipVo> page = new Page<>(req.getPageNum(),req.getPageSize());
        OrderItem orderItem = new OrderItem("priority", false);
        if (StringUtils.isNotBlank(req.getSortName())) {
            String underlineCase = CommonUtil.toUnderlineCase(req.getSortName());
            orderItem = new OrderItem(underlineCase, req.getIsAsc());
        }
        page.setOrders(List.of(orderItem));
        Page<TLabelRuleRelationshipVo> result = this.baseMapper.queryList(page, param);
        PageModel<TLabelRuleRelationshipVo> pageResult = new PageModel<>();
        pageResult.setData(result.getRecords());
        pageResult.setPageNo((int) result.getCurrent());
        pageResult.setPageSize((int) result.getSize());
        pageResult.setTotalRow((int) result.getTotal());
        pageResult.setTotalPage((int) result.getPages());
        return pageResult;
    }

    @Override
    public boolean create(LabelRuleEditReq req) throws BusinessException{
        TRiskConstants tRiskConstants = riskConstantsMapper.selectById(req.getLabelId());
        if(null == tRiskConstants){
            throw new BusinessException("label not exist",ResultEnum.BAD_REQUEST.getCode());
        }
        if(!RuleEnum.getAllRuleMap().containsKey(req.getRuleAction())){
            throw new BusinessException("ruleAction not exist",ResultEnum.BAD_REQUEST.getCode());
        }
        TLabelRuleRelationship entity = JSONObject.parseObject(JSONObject.toJSONString(req),TLabelRuleRelationship.class);
        entity.setLabelKey(tRiskConstants.getPKey());
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if(!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())){
            entity.setCreateBy(userInfoVO.getUserInfo().getUsername());
            entity.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        return this.save(entity);
    }

    @Override
    public boolean updateById(LabelRuleEditReq req) {
        TRiskConstants tRiskConstants = riskConstantsMapper.selectById(req.getLabelId());
        if(null == tRiskConstants){
            throw new BusinessException("label not exist",ResultEnum.BAD_REQUEST.getCode());
        }
        if(!RuleEnum.getAllRuleMap().containsKey(req.getRuleAction())){
            throw new BusinessException("ruleAction not exist",ResultEnum.BAD_REQUEST.getCode());
        }
        TLabelRuleRelationship entity = JSONObject.parseObject(JSONObject.toJSONString(req),TLabelRuleRelationship.class);
        entity.setLabelKey(tRiskConstants.getPKey());
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if(!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())){
            entity.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        redisTemplate.delete(RedisConstant.LABEL_RULE_KEY + req.getLabelId());//删除标签-规则关系缓存
        return this.updateById(entity);
    }

    @Override
    public boolean deleteById(BigInteger id) {
        TLabelRuleRelationship rule = this.getById(id);
        if(rule.getStatus().equals(YesNoEnum.YES.getIntCode())){
            throw new BusinessException("Please disable before deleting",ResultEnum.BAD_REQUEST.getCode());
        }
        redisTemplate.delete(RedisConstant.LABEL_RULE_KEY + rule.getLabelId());//删除标签-规则关系缓存
        return this.removeById(id);
    }
    @Override
    public boolean updateStatusById(LabelRuleEditReq req) {
        TLabelRuleRelationship entity = JSONObject.parseObject(JSONObject.toJSONString(req),TLabelRuleRelationship.class);
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if(!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())){
            entity.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        redisTemplate.delete(RedisConstant.LABEL_RULE_KEY + req.getLabelId());//删除标签-规则关系缓存
        return this.updateById(entity);
    }
}
