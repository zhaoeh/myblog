package com.riskcontrol.office.service.impl;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.digiplus.common.service.KafkaShieldService;
import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.datasource.DBSourceCheck;
import com.riskcontrol.office.datasource.DataSourceType;
import com.riskcontrol.office.domain.entity.RiskFilterLog;
import com.riskcontrol.office.domain.entity.TSysConstants;
import com.riskcontrol.office.domain.req.RiskFilterLogReq;
import com.riskcontrol.office.domain.withdrawal.req.WithdrawalApproveReq;
import com.riskcontrol.office.mapper.RiskFilterLogMapper;
import com.riskcontrol.office.mapper.TSysConstantsMapper;
import com.riskcontrol.office.service.RiskFilterLogService;
import com.riskcontrol.office.util.RedisUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 风控拦截日志表服务接口实现
 *
 * @author dante
 * @description 由 Mybatisplus Code Generator 创建
 * @since 2024-04-18 16:45:29
 */
@Slf4j
@Service
public class RiskFilterLogServiceImpl extends BaseServiceImpl<RiskFilterLogMapper, RiskFilterLog> implements RiskFilterLogService {
    private static final String WITHDRAWAL_REVIEW_CACHE_KEY = "withdrawal_review_{0}_{1}";
    @Resource
    private AmqpTemplate rabbitMq;
    @Autowired
    private KafkaShieldService kafkaShieldService;

    @Resource
    private TSysConstantsMapper sysConstantsMapper;
    @DBSourceCheck(DataSourceType.SLAVE)
    @Override
    public PageModel<RiskFilterLog> queryList(RiskFilterLogReq req) {
        Page<RiskFilterLog> page = pageByWrapper(req, buildWrapper(req));
        PageModel<RiskFilterLog> pageResult = new PageModel<>();
        pageResult.setData(page.getRecords());
        pageResult.setPageNo((int) page.getCurrent());
        pageResult.setPageSize((int) page.getSize());
        pageResult.setTotalRow((int) page.getTotal());
        pageResult.setTotalPage((int) page.getPages());
        return pageResult;
    }

    @Override
    public String retryRiskWithdrawApprove(WithdrawalApproveReq req) {
        if (StringUtils.isEmpty(req.getRequestId())) {
            log.info("Parameter does not exist");
            return "Parameter does not exist";
        }
        LambdaQueryWrapper<TSysConstants> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(TSysConstants::getIsDeleted, Constant.ZERO);
        wrapper.eq(TSysConstants::getIsEnable, Constant.ONE);
        wrapper.eq(TSysConstants::getSKey, "jms-withdraw-risk-retry-mq");
        wrapper.eq( TSysConstants::getSType, "r-0014");
        TSysConstants tSysConstants = sysConstantsMapper.selectOne(wrapper);
        String sendMqFlag = Objects.nonNull(tSysConstants)? tSysConstants.getSValue() : Constant.ZERO ;//风控重审队列（0:kafka；1:rabbitmq）
        List<String> requestIdList = Arrays.stream(req.getRequestId().split(";"))
                .collect(Collectors.toList());
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        String operator;
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            operator = userInfoVO.getUserInfo().getUsername();
        } else {
            operator = "";
        }
        requestIdList.forEach(requestId->{
            try {
                String cacheKey = MessageFormat.format(WITHDRAWAL_REVIEW_CACHE_KEY, Constant.C66_PRODUCT_ID, requestId);
                String reviewer = RedisUtils.get(cacheKey, String.class);
                if (StringUtils.isNotEmpty(reviewer) && !operator.equalsIgnoreCase(reviewer)) {//不是自己获取的锁，跳过
                    log.info("当前取款单 requestId:{} ,正在被审批中", requestId);
                }else{
                    // 只有是自己审核的订单才能关闭,删除操作人后才能进入重审，避免延迟导致消息直接被过滤
                    if (StringUtils.isNotBlank(reviewer) && operator.equalsIgnoreCase(reviewer)) {
                        RedisUtils.remove(cacheKey);
                    }
                    JSONObject messageJson = new JSONObject();
                    messageJson.put("productId",req.getProductId());
                    messageJson.put("requestId",requestId);
                    if(sendMqFlag.equals(Constant.ONE)){
                        JSONObject newMsg=new JSONObject();
                        newMsg.put("msgContent", messageJson);
                        newMsg.put("routingKey", "customer.withdraw.apply");
                        String jsonString = JSON.toJSONString(newMsg);
                        Message message = MessageBuilder.withBody(jsonString.getBytes())
                                .setContentType(MessageProperties.CONTENT_TYPE_JSON)
                                .build();
                        rabbitMq.convertAndSend("exchange_risk_withdraw_apply_retry", "routing.risk.withdraw.apply.retry", message);
                        log.info("retryRisk 推送数据到rabbitmq:{}", messageJson.toJSONString());
                    }else{
                        kafkaShieldService.asyncSend("topic_risk_withdraw_retry",messageJson);
                        log.info("retryRisk 推送数据到kafka:{}", messageJson.toJSONString());
                    }
                }
            } catch (Exception e) {
                log.error("risk withdraw approve retry error", e);
            }
        });
        return StrUtil.EMPTY;
    }
}