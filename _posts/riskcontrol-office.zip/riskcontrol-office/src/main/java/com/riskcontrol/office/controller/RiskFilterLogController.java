package com.riskcontrol.office.controller;

import cn.hutool.core.util.StrUtil;
import com.digiplus.oms.aspect.annotation.PreAuthorize;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.annotation.EnableOperationLog;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.entity.RiskFilterLog;
import com.riskcontrol.office.domain.enums.OpTypeEnum;
import com.riskcontrol.office.domain.req.RiskFilterLogReq;
import com.riskcontrol.office.domain.withdrawal.req.WithdrawalApproveReq;
import com.riskcontrol.office.service.RiskFilterLogService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;


/**
 * @author dante
 */
@RestController
@RequestMapping("office/riskFilterLog")
@Tag(name = "风控拦截日志")
//@SecurityRequirement(name = HttpHeaders.AUTHORIZATION)
@Slf4j
public class RiskFilterLogController {

    @Resource
    RiskFilterLogService riskFilterLogService;

    @PreAuthorize("risk_filter_log_query")
    @PostMapping("/queryList")
    @Operation(tags = "风控拦截日志", summary = "查询风控拦截日志列表")
    @ResponseBody
    public R<PageModel<RiskFilterLog>> queryList(@RequestBody @Validated RiskFilterLogReq req) {
        return R.ok(riskFilterLogService.queryList(req));
    }

    @PreAuthorize("riskManage_withdraw_retrial_approve")
    @PostMapping("/retrialApprove")
    @Operation(tags = "风控管理", summary = "取款重审")
    @EnableOperationLog(menuName = "风控管理", subMenuName = "风控重审", opLog = "风控重审", opLogType = OpTypeEnum.RETRIAL_APPROVE)
    @ResponseBody
    public R<Boolean> retrialApprove(@RequestBody WithdrawalApproveReq req) {
        String result = riskFilterLogService.retryRiskWithdrawApprove(req);
        return StrUtil.isNotEmpty(result) ? R.failed(result): R.ok() ;
    }

}
