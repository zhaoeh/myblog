package com.riskcontrol.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.office.domain.rsp.black.RiskBlackOperationAccountInfoRsp;
import com.riskcontrol.office.domain.entity.TRiskBlackOperationAccountDetail;

import java.math.BigInteger;
import java.util.List;


/**
 * @author Heng.zhang
 */
public interface RiskBlackOperationAccountDetailService extends IService<TRiskBlackOperationAccountDetail> {

    /**
     * 查询详情
     * @param ids
     * @return
     */
    List<TRiskBlackOperationAccountDetail> getAccountList(List<BigInteger> ids);

    RiskBlackOperationAccountInfoRsp getOperationAccountReInfo(BigInteger detailId);

}
