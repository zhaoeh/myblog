package com.riskcontrol.office.domain.rsp.black;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


/**
 * @author Heng.zhang
 */
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(value = "风控黑名单操作记录明细关联账户信息", description = "风控黑名单")
@Data
public class RiskBlackOperationAccountInfoRsp {
    @ApiModelProperty(value = "名")
    private String firstName;

    @ApiModelProperty(value = "中间名")
    private String middleName;


    @ApiModelProperty(value = "姓")
    private String lastName;

    @ApiModelProperty(value = "生日")
    private String birthday;

    @ApiModelProperty(value = "关联账户")
    private List<AssociationAccount> associationAccount;

    @NoArgsConstructor
    @AllArgsConstructor
    @Data
    public static class AssociationAccount{
        @ApiModelProperty(value = "关联账户")
        private String loginName;
    }
}