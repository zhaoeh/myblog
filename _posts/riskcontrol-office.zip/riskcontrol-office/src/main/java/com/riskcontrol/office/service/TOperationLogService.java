package com.riskcontrol.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.domain.entity.TOperationLog;
import com.riskcontrol.office.domain.req.OperactionLogReq;

public interface TOperationLogService extends IService<TOperationLog>{
    PageModel<TOperationLog> queryList(OperactionLogReq req);

}
