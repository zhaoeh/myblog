package com.riskcontrol.office.domain.req;

import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.entity.request.BasePageRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Heng.zhang
 */
@Data
@ApiModel(value = "用户登录注册日志", description = "用户注册明细分页查询")
public class RiskActionRegistrationQueryRequest extends BasePageRequest {

//    @ApiModelProperty("createDate Begin")
//    @Query(field = "createDate", mt = SQLConstants.Query.GE)
//    private String dateBegin;
//
//    @ApiModelProperty("createDate End")
//    @Query(field = "createDate", mt = SQLConstants.Query.LE)
//    private String dateEnd;

    @ApiModelProperty("账号")
    @Query
    private String deviceFingerprint;

    @ApiModelProperty("注册IP地址")
    @Query
    private String registerIp;

    @ApiModelProperty("用户名")
    @Query
    private String loginName;

    @ApiModelProperty("拦截类型（0：通过；1：ip；2：设备指纹；3：ip+设备指纹）")
    @Query
    private String interceptType;

}
