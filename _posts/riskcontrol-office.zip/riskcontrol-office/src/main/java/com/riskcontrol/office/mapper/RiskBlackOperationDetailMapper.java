package com.riskcontrol.office.mapper;

import com.riskcontrol.office.domain.entity.TRiskBlackOperationDetail;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author Heng.zhang
 */
@Mapper
public interface RiskBlackOperationDetailMapper extends BaseMapperX<TRiskBlackOperationDetail> {

}
