package com.riskcontrol.office.service;

import com.cn.schema.other.WSMsgMqSendRecord;
import com.cn.schema.other.WSQueryMsgMqSendRecord;
import com.riskcontrol.common.exception.BusinessException;

import java.util.List;


/**
 * MQ消息发送记录表服务层接口类
 *
 * @author wade
 * @date 2018-08-29 09:52:47.
 */
public interface MsgMqService {

    /**
     * 查询符合条件的信息分页
     *
     * @param query 查询条件
     * @return List<WSMsgMqSendRecord> MQ消息发送记录表列表
     * @throws BusinessException
     */
    List<WSMsgMqSendRecord> queryPageMsgMqByCondition(WSQueryMsgMqSendRecord query) throws BusinessException;


    /**
     * 根据ID查询信息
     *
     * @param id 主键
     * @return WSMsgMqSendRecord
     * @throws BusinessException
     */
    WSMsgMqSendRecord loadMsgMqById(String id) throws BusinessException;

    /**
     * 创建信息
     *
     * @param bean 需要创建的信息
     * @return WSMsgMqSendRecord 创建后结果
     * @throws BusinessException
     */
    WSMsgMqSendRecord createMsgMq(WSMsgMqSendRecord bean) throws BusinessException;


    /**
     * 删除
     *
     * @param id
     * @return
     * @throws BusinessException
     */
    int deleteById(String id, String productId) throws BusinessException;

}
