package com.riskcontrol.office.domain.customers.req;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/10/21 10:59
 */
@Data
public class KycSheetRequest implements Serializable {
    @ApiModelProperty("Id, primary Key")
    private String id;
    @ApiModelProperty("customer Login Name")
    private String loginName;
    @ApiModelProperty("id Type")
    private String idType;
    @ApiModelProperty("id snapshot storage address")
    private String idScan;
    @ApiModelProperty("id status")
    private String status;
    @ApiModelProperty("realName")
    private String realName;
    @ApiModelProperty("firstName")
    private String firstName;
    @ApiModelProperty("middleName")
    private String middleName;
    @ApiModelProperty("lastName")
    private String lastName;
    @ApiModelProperty("sex")
    private String sex;
    @ApiModelProperty("address")
    private String address;
    @ApiModelProperty("assigneeTime")
    private String assigneeTime;
    @ApiModelProperty("pbcStatus")
    private String pbcStatus;
    @ApiModelProperty("processLog")
    private String processLog;
    @ApiModelProperty("billNo")
    private String billNo;
    @ApiModelProperty(
            value = "birthday",
            example = "YYYY-MM-DD"
    )
    private String birthday;
    @ApiModelProperty("assigneeBy")
    private String assigneeBy;
    @ApiModelProperty("approved By")
    private String approvedBy;
    @ApiModelProperty(
            value = "product 产品名称",
            example = "BP,AP"
    )
    private String product;
    @ApiModelProperty(
            value = "channel 渠道",
            example = "与网关对应：3-GLIFE, 4-GPO(占位), 5-LAZADA, 6-MAYA, 99-WEBSITE"
    )
    private String channel;
    @ApiModelProperty("pbc approved By")
    private String pbcApprovedBy;
    @ApiModelProperty("approved Date")
    private String approvedDate;
    @ApiModelProperty("pbc approved Date")
    private String pbcApprovedDate;
    @ApiModelProperty("created Date")
    private String createdDate;
}
