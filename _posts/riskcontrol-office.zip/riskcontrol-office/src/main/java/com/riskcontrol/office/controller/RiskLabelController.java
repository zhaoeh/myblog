package com.riskcontrol.office.controller;

import cn.hutool.core.io.IoUtil;
import com.alibaba.fastjson.JSON;
import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.common.validation.EasyExcelTemplateValidator;
import com.riskcontrol.office.domain.entity.TRiskLabelOperationLog;
import com.riskcontrol.office.domain.req.*;
import com.riskcontrol.office.domain.rsp.RiskLabelDetailsRsp;
import com.riskcontrol.office.domain.rsp.RiskLabelOperationDetailPageRsp;
import com.riskcontrol.office.domain.rsp.RiskLabelPageRsp;
import com.riskcontrol.office.domain.rsp.RiskLabelRelationRsp;
import com.riskcontrol.office.service.TRiskConstantsService;
import com.riskcontrol.office.service.TRiskLabelChangeRecordService;
import com.riskcontrol.office.service.TRiskLabelOperationLogService;
import com.riskcontrol.office.service.TRiskLabelRelationshipService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.List;
import java.util.Objects;

/**
 * @description: 风控标签控制器
 * @author: ErHu.Zhao
 * @create: 2024-10-16
 **/
@RestController
@RequestMapping("/office/riskLabel")
@Tag(name = "风控标签关系")
@Slf4j
public class RiskLabelController {

    @Autowired
    private TRiskLabelRelationshipService riskLabelRelationshipService;

    @Autowired
    private TRiskConstantsService constantsService;

    @Autowired
    private TRiskLabelOperationLogService riskLabelOperationLogService;

    @Autowired
    private TRiskLabelChangeRecordService riskLabelChangeRecordService;

    @PostMapping("/getPageList")
    @Operation(tags = "风控标签关系", summary = "风控用户标签关联分页列表")
    public R<PageModel<RiskLabelPageRsp>> getPage(@RequestBody RiskLabelPageReq request) {
        return R.ok(riskLabelRelationshipService.queryRiskLabelRelationships(request));
    }

    @GetMapping("/getLabels")
    @Operation(tags = "风控标签关系", summary = "查询风控标签")
    public R<List<RiskLabelDetailsRsp>> getLabelByTypeId(@RequestParam(required = false) String type) {
        return R.ok(constantsService.queryConstantByType(type));
    }

    @PostMapping("/getOperationList")
    @Operation(tags ="风控标签关系" ,summary = "查看历史操作记录列表接口")
    public R<PageModel<TRiskLabelOperationLog>> getOperationList(@RequestBody RiskLabelOperationPageRequest request) {
        return R.ok(riskLabelOperationLogService.getOperationList(request));
    }

    @PostMapping("/getOperationDetailList")
    @Operation(tags ="风控标签关系" ,summary = "查看历史操作记录列表明细接口")
    public R<PageModel<RiskLabelOperationDetailPageRsp>> getOperationDetailList(@RequestBody @Validated RiskLabelOperationDetailPageRequest request) {
        return R.ok(riskLabelChangeRecordService.getOperationDetailList(request));
    }

    @PostMapping("/update")
    @Operation(tags = "风控标签关系", summary = "修改用户风控标签关系")
    public R<Boolean> updateRelations(@RequestBody @Validated RiskLabelChangeReq request) {
        return R.ok(riskLabelRelationshipService.modifyRiskLabelRelationship(request));
    }

    @GetMapping("/info/{loginName}")
    @Operation(tags = "风控标签关系", summary = "根据loginName查询用户标签关系")
    public R<RiskLabelRelationRsp> getLabelRelationById(@PathVariable("loginName") @Validated @NotNull String loginName) {
        return R.ok(riskLabelRelationshipService.queryRiskLabelRelationshipByLoginName(loginName));
    }


    @PostMapping("/create")
    @Operation(tags ="风控标签关系" ,summary = "导入用户风控标签关系")
    public R<Boolean> importExcel(@Validated RiskLabelImportRequest importRequest) throws IOException {
        boolean isValid = EasyExcelTemplateValidator.validateTemplate(importRequest.getFile(), 0);
        if (!isValid) {
            return R.failed("The Excel template is incorrect. Please check if the column headers meet the requirements.");
        }
        byte[] content = IoUtil.readBytes(importRequest.getFile().getInputStream());
        RiskLabelImportRequest.RiskLabelImport riskLabelImport = new RiskLabelImportRequest.RiskLabelImport();
        riskLabelImport.setContent(content);
        riskLabelImport.setRiskLabelIds(importRequest.getRiskLabelIds());
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        log.info("导入用户风控标签，获取登录用户，userInfoVO：{}", JSON.toJSONString(userInfoVO));
        if (!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())) {
            riskLabelImport.setDataModifier(userInfoVO.getUserInfo().getUsername());
        }
        return R.ok(riskLabelRelationshipService.importExcel(riskLabelImport));
    }
}
