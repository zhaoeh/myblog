package com.riskcontrol.office.domain.rsp;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigInteger;
import java.util.Date;

/**
 * @description: 风控标签vo
 * @author: ErHu.Zhao
 * @create: 2024-10-16
 **/
@ApiModel(value = "风控标签常量vo", description = "风控标签常量vo")
@Data
public class RiskLabelDetailsRsp {


    @ApiModelProperty("ID")
    private BigInteger id;

    @ApiModelProperty("所属产品")
    private String productId;

    @ApiModelProperty("标签值")
    private String pValue;

    /**
     * 常量key
     */
    @ApiModelProperty("常量key")
    private String pKey;

    @Schema(description = "常量类型")
    private String pType;

    /**
     * 描述
     */
    @ApiModelProperty("描述")
    private String remarks;

    /**
     * ip地址
     */
    @JsonIgnore
    @ApiModelProperty("ip地址")
    private String ipAddress;

    /**
     * 标志:0-未启用；1-已启用
     */
    @JsonIgnore
    @ApiModelProperty("标志:0-未启用；1-已启用")
    private Integer isEnable;

    /**
     * 是否删除：0-否 ；1-是
     */
    @JsonIgnore
    @ApiModelProperty("是否删除：0-否 ；1-是")
    private Integer isDeleted;

    /**
     * 创建人
     */
    @JsonIgnore
    @ApiModelProperty("创建人")
    private String createBy;

    @JsonIgnore
    @ApiModelProperty("创建日期(Create Time)")
    protected Date createTime;

    /**
     * 最后修改人
     */
    @JsonIgnore
    @ApiModelProperty("最后修改人")
    private String updateBy;

    /**
     * 最后修改时间
     */
    @JsonIgnore
    @ApiModelProperty("最后修改时间")
    private Date updateTime;

    /**
     * 优先级
     */
    @JsonIgnore
    @ApiModelProperty("优先级")
    private Integer priority;

}
