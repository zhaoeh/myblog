package com.riskcontrol.office.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.enums.EkycStatusEnum;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.domain.entity.TEkyc;
import com.riskcontrol.office.domain.entity.TRiskBlack;
import com.riskcontrol.office.domain.req.black.RiskBlackPageRequest;
import com.riskcontrol.office.domain.req.ekyc.EkycQueryRequest;
import com.riskcontrol.office.domain.rsp.ekyc.EkycQueryResponse;
import com.riskcontrol.office.mapper.EkycMapper;
import com.riskcontrol.office.service.EkycService;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.FastDateFormat;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


/**
 * @author Heng.zhang
 */
@Service
@Slf4j
public class EkycServiceImpl extends BaseServiceImpl<EkycMapper, TEkyc> implements EkycService {

    @Override
    public PageModel<EkycQueryResponse> pageEkycList(EkycQueryRequest req) {
        if(StringUtils.isNotBlank(req.getLoginName())){
            req.setDateBegin(null);
            req.setDateEnd(null);
        }
        checkQueryDateCannotSpanDays(req);
        LambdaQueryWrapper<TEkyc> wrapper = buildWrapper(req);
        modifyWrapper(wrapper,req);
        wrapper.orderByDesc(TEkyc::getCreateDate);
        Page<TEkyc> page = pageByWrapper(req, wrapper);
        List<EkycQueryResponse> ekycList = page.getRecords().stream().map(p -> {
            EkycQueryResponse rsp = new EkycQueryResponse();
            BeanUtil.copyProperties(p, rsp);
            return rsp;
        }).collect(Collectors.toList());
        PageModel<EkycQueryResponse> riskBlackRsp = new PageModel<>();
        riskBlackRsp.setData(ekycList);
        riskBlackRsp.setPageNo((int) page.getCurrent());
        riskBlackRsp.setPageSize((int) page.getSize());
        riskBlackRsp.setTotalRow((int) page.getTotal());
        riskBlackRsp.setTotalPage((int) page.getPages());
        return riskBlackRsp;
    }

    /**
     * 更新warpper*
     * @param wrapper
     * @param req
     */
    private void modifyWrapper(LambdaQueryWrapper<TEkyc> wrapper, EkycQueryRequest req){
        String firstName = req.getFirstName();
        String middleName = req.getMiddleName();
        String lastName = req.getLastName();
        if(StringUtils.isNotBlank(firstName) && StringUtils.isBlank(middleName) && StringUtils.isNotBlank(lastName)){
            wrapper.eq(TEkyc::getMiddleName,"");
        }
    }

    @Override
    public boolean ekycCreate(TEkyc ekycEntity){
        return save(ekycEntity);
    }

    @Override
    public TEkyc getEkycInfo(String loginName) {
        LambdaQueryWrapper<TEkyc> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(TEkyc::getLoginName, loginName);
        wrapper.last("LIMIT 1");
        TEkyc info = getOne(wrapper);
        return Optional.ofNullable(info).orElse(null);
    }

    @SneakyThrows
    private void checkQueryDateCannotSpanDays(EkycQueryRequest req){
        if(StringUtils.isNotBlank(req.getDateBegin()) || StringUtils.isNotBlank(req.getDateEnd())){
            if(StringUtils.isBlank(req.getDateBegin()) || StringUtils.isBlank(req.getDateEnd())){
                throw new BusinessException(ResultEnum.EKYC_QUERY_DATE_CANNOT_SPAN_DAYS_ERROR);
            }
            var fastDateFormatOne = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss");
            var fastDateFormatTwo = FastDateFormat.getInstance("yyyy-MM-dd");
            if(!fastDateFormatTwo.format(fastDateFormatOne.parse(req.getDateBegin())).equals(fastDateFormatTwo.format(fastDateFormatOne.parse(req.getDateEnd())))){
                throw new BusinessException(ResultEnum.EKYC_QUERY_DATE_CANNOT_SPAN_DAYS_ERROR);
            }
        }
    }
}
