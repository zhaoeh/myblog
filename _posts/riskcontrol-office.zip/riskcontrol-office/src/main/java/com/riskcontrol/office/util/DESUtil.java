package com.riskcontrol.office.util;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.DESedeKeySpec;
import java.security.SecureRandom;

public class DESUtil {

	private static final String DES = "DES";

	private static final String PADDING = "DES/ECB/PKCS5Padding";

	private static final String DEFAULT_INCODING = "utf-8";

	private static final Logger logger = LoggerFactory.getLogger(DESUtil.class);

	public static String encrypt(String data, String key) {
		try {
			return Base64.encodeBase64String(encrypt(data.getBytes(DEFAULT_INCODING), key.getBytes(DEFAULT_INCODING)));
		} catch (Exception ex) {
			logger.error("加密失败", ex);
		}
		return null;
	}

	private static byte[] encrypt(byte[] code, byte[] key) throws Exception {
		SecureRandom sr = new SecureRandom();
		// 生成密钥
		DESKeySpec dks = new DESKeySpec(key);
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(DES);
		SecretKey secretKey = keyFactory.generateSecret(dks);
		// 进行加密
		Cipher cipher = Cipher.getInstance(PADDING);
		cipher.init(Cipher.ENCRYPT_MODE, secretKey, sr);
		return cipher.doFinal(code);
	}

	public static String decrypt(String data, String key) {
		try {
			return new String(decrypt(Base64.decodeBase64(data), key.getBytes(DEFAULT_INCODING)), DEFAULT_INCODING);
		} catch (Exception ex) {
			logger.error("解密失败", ex);
		}
		return null;
	}

	private static byte[] decrypt(byte[] src, byte[] key) throws Exception {
		SecureRandom sr = new SecureRandom();
		DESKeySpec dks = new DESKeySpec(key);
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(DES);
		SecretKey sectetKey = keyFactory.generateSecret(dks);
		Cipher cipher = Cipher.getInstance(PADDING);
		cipher.init(Cipher.DECRYPT_MODE, sectetKey, sr);
		return cipher.doFinal(src);
	}

	public static String ipsEncrypt(String key,String text){
		try {
			byte[] src = text.getBytes("utf-8");
			//DESedeKeySpec会帮你生成24位秘钥，key可以是任意长度
			DESedeKeySpec spec = new DESedeKeySpec(key.getBytes("utf-8"));
			SecretKeyFactory factory = SecretKeyFactory.getInstance("DESede");
			SecretKey secretKey = factory.generateSecret(spec);
			Cipher cipher = Cipher.getInstance("DESede/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, secretKey);
			byte[] res = cipher.doFinal(src);
			//encodeBase64会对字符串3位一组自动补全，因而最后可能会出现 == 或者 =
			return new String(Base64.encodeBase64(res), "utf-8");
		} catch (Exception e) {
			System.out.println("error");
		}
		return null;
	}


	public static void main(String[] args) throws Exception {

		String key0 = DESUtil.decrypt("JCM4SnQeDSMh+o52i4wFuQ74xLAEl9nUaUew37nxIKM5ysu9/qYyX0rQn2dbYoSK2sjvNO8bfBoVeYMIQsnGpoTA45dJh/tm0jyjjXe1knKGQBtLu6qQQ6hFmkZK+zfrQxvDQo+fQzPCfa1UkklvZg4HmTAijqw5fLz/m9valAj6oo0rW+/n+rTBbWZ1rPBwe6NenN+zvt5ITo22Kxbk0+YM1FGbXEIsHGq6ckXqdPPlA8E6TVMhRX/vDkK7y8Zvd0V6S25NtL1tLIvAky1+hw/iwH/RBlQCu0FcIJSzvYdNClxYNEHv6tDeBFA0Mdg9onkoW9cNZgoH69lKSYJ12vP0hy5KSIZaWnKufS0LkgYTtnngWjgtkAobHBse3nflyg2J3J4+6rZKKFuVlh3ah7tGaMMyHKLDH+qTeEiULT96dhHZI/oy+VvVFuIprySBShgQBIWKaJz2R30cMzcHVJ67O51M0pymY7dIcocxBkk1dwlQJX+VgheLnZHEZQk58DOLszbMVZyN7cO9g5SQA58dulE6WM1Uspn2aFVcwd5cRCV5Bokuagnnjndgps/OgOOwdVPhNjDsWmwheLfvFGMq5n3jrtDWOxj7ZMHEz/HU3neqqMV8+3rSBsFP9SrRfVJ7nI/Rmgpc8RbXJyr5FYW4V+sNbErV686P/dG5A3JbD9+rMQzQ9cLUrBA0lhpF14R9p9zzOFdoMuE03iXeOJU1P/9cNGblA0hURtqzNfGmoOx0a5Ym8rFN5NEVS6p8GEo9V4tLTtHm0Jp6XBU3YxlsRp2VKgRv6bv2AhWIHZ6jUcjEr87JsGIE4Hjbff62DjLved/pdeTwm2hbN1qF70Iszra37IeClUOHP3S/1YOOnZ9MeX0U+iGypz/IpPRG6xd2v3cRSArprCKpN5bViixLbQypdBMBXZocFpwknC9vJWmx+KRik9/RvaeyyUQVKe5EhasArvp/5WFh92NFx1nNl9CdrcqlR6onBFZjH2TUrbzi7Wo2bSgas4on1WqUrXt2UvBe709vjMNhn3sXfDNgnzOO77AUNJw9mbBV8wV2SPrLukvwZH6uIJmYvassU3SuA3EFm/uKB87Zhq95/02iBRBm6hnzEC9LnUkcJGQ=", "c34d23bd0fdd4f79ae6f7815412681e1");
		String token="6sNvgv4wu0KNh4yb79UwkGcJ5f+smmzCPS/AG8p24qvkXUow0p89myCX/Jo7RIt/OLbj0c2rfDP6Fi8Mi2xBywHf4M2rErSkBk8W0KNN8ViAJ1IT5+GiZdliNPIQnpKMgnjBPJnpc8AXyLYpFJhdVVv0I7mEMbBSGu9Fs558/14ItvnQe1EOr4pjktv3Js9gEFdahn2k4j0=";
		System.out.println(key0);
		//		String qid = "ee341e20a0df0ae2446f28b9a70123d7";
//		String appId = "A06H501";
//		String v = "1.0.0";
//		String body = "{\"productId\":\"A06\",\"loginName\":\"czhiban5\",\"flag\":9}";
//		String x1 = DESUtil.decrypt(token, key0);
//		JSONObject xo = JSONObject.parseObject(x1);
//		String _source = NepUtil.sort(body, false) + qid + appId + v + token + xo.getString("u2token");
//		System.out.println(_source);
//		String _sign = DigestUtils.md5Hex(_source);
//		System.out.println(_sign);
//		String x1 = "+KRik9/RvaeyyUQVKe5EhasArvp/5WFh92NFx1nNl9CdrcqlR6onBFZjH2TUrbzi7Wo2bSgas4on1WqUrXt2UvBe709vjMNhn3sXfDNgnzOO77AUNJw9mbBV8wV2SPrLukvwZH6uIJmYvassU3SuA3EFm/uKB87Zhq95/02iBRBm6hnzEC9LnUkcJGQ=";
////		String s = DESUtil.decrypt(x1, key0);
//		System.out.println(key0);
//		//System.out.println(DESUtil.decrypt("6sNvgv4wu0Kw/v8RltpRRYF/GwjaFENitdwoE7WH9SUbg08dUoo25RfItikUmF1VroEtcgRXWd4mEt6YHwITriuwoEyV2c0E7mHHlFiQMh9eOYFoSeg1EA==", key0));
//		System.out.println(StringUtils.containsNone("aweawer ","-"));

//		String data = "JMsEYj2vdQ2ZjoB2BF8zVq2VChLmXL0H1b/M7heZhFKEC1Yvnssp74Raj4x3+Z+I5//MsO2VkUwj26VyNGMf06yjHruVxQ1/jeem0F4NSixS0Hy3b2b/xbXJqdls3TN7u+cSDhGPEZKQ8oRr7Lg3QqovTdYcxgvCz8gv317mR75IUs+ocWlMGaaIpmgdQV8V1e/gnLgg4B48bI/UWXodwRWawU99x4UiolQx8ocbjY+CnKAa8tJr7LthhhItvBc92HHNb0QregZtQg/l4Fp/swGonA2f5al2/pNK8Mn2r0Ip78brMc1RoFKDnIWvUE79jMIoN2XViMzVw0+lzuCk6Y3vhbbQ/Lc7ltyuWcE6ee++YMgDyHqdZ8APmgwmTAix";
//		String key = "cca619fb";
//		String str = DESUtil.decrypt(data,key);
//		System.out.println(str);
//		String s = "afwekjr awerjaklwr";
//		System.out.println(s.replaceAll("\t|\r|\n",""));
//		System.out.println(Cryptor.decryptContent("zagvdsPd7ko{DVwPN5E;{LFb3hWk(tGfAtlFhagU,`VJ"));


//		String s = "http://graph.facebook.com/132513302876705/picture?type\u003dlarge";
//		String s1 = "/externals/C66FM/img/_wms/_l/avatar/awe.png";
////		System.out.println(NepUtil.isWebToken(s));
//	System.out.println(StringUtils.isNotBlank(s)&&(!s.contains("google"))&&( !s.contains("facebook")));
//	System.out.println(StringUtils.isNotBlank(s)&&StringUtils.containsAny(s1,"google","facebook"));
////	System.out.println(ConstantVars.Cache.QUERY_BALANCE_LIMIT.getKey("", "bingoplusbul5rq"));
//		System.out.println(Cryptor.decryptContent("UJpIwi`vAYS5ItZO3neDHDdsE[qWefuKGbn@APTa{N7J"));
	}
}