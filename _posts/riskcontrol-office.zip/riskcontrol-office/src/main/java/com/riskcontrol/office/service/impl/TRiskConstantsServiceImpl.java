package com.riskcontrol.office.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.digiplus.oms.domain.res.UserInfoVO;
import com.digiplus.oms.util.CurrentUserUtil;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.enums.YesNoEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.office.common.constants.RedisConstant;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.domain.entity.TLabelRuleRelationship;
import com.riskcontrol.office.domain.entity.TRiskConstants;
import com.riskcontrol.office.domain.entity.TRiskLabelRelationship;
import com.riskcontrol.office.domain.req.RiskConstantEditReq;
import com.riskcontrol.office.domain.req.RiskConstantReq;
import com.riskcontrol.office.domain.rsp.RiskLabelDetailsRsp;
import com.riskcontrol.office.mapper.TLabelRuleRelationshipMapper;
import com.riskcontrol.office.mapper.TRiskConstantsMapper;
import com.riskcontrol.office.mapper.TRiskLabelRelationshipMapper;
import com.riskcontrol.office.service.TRiskConstantsService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@Slf4j
public class TRiskConstantsServiceImpl extends BaseServiceImpl<TRiskConstantsMapper, TRiskConstants> implements TRiskConstantsService {
    @Autowired
    private RedisTemplate<String,String> redisTemplate;
    @Autowired
    private TLabelRuleRelationshipMapper labelRuleRelationshipMapper;
    @Autowired
    private TRiskLabelRelationshipMapper RiskLabelRelationshipMapper;

    @Override
    public PageModel<TRiskConstants> queryConstantList(RiskConstantReq req) {
        LambdaQueryWrapper<TRiskConstants> wrapper = buildWrapper(req);
        wrapper.eq(TRiskConstants::getIsDeleted,0);
        if(StringUtils.isBlank(req.getSortName())){
            req.setSortName("priority");
        }
        Page<TRiskConstants> page = pageByWrapper(req,wrapper);
        PageModel<TRiskConstants> pageResult = new PageModel<>();
        pageResult.setData(page.getRecords());
        pageResult.setPageNo((int) page.getCurrent());
        pageResult.setPageSize((int) page.getSize());
        pageResult.setTotalRow((int) page.getTotal());
        pageResult.setTotalPage((int) page.getPages());
        return pageResult;
    }

    @Override
    public boolean create(RiskConstantEditReq req) {
        LambdaQueryWrapper<TRiskConstants> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(TRiskConstants::getPriority,req.getPriority());
        wrapper.eq(TRiskConstants::getIsDeleted,YesNoEnum.NO.getCode());
        List<TRiskConstants> oldLabels = this.list(wrapper);
        if(CollectionUtils.isNotEmpty(oldLabels)){
            throw new BusinessException(" Exist the same priority for key ："+oldLabels.get(0).getPKey(),ResultEnum.BAD_REQUEST.getCode());
        }
        TRiskConstants entity = JSONObject.parseObject(JSONObject.toJSONString(req),TRiskConstants.class);
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if(!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())){
            entity.setCreateBy(userInfoVO.getUserInfo().getUsername());
            entity.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        entity.setProductId(Constant.C66_PRODUCT_ID);
        return this.save(entity);
    }
    @Override
    public boolean updateById(RiskConstantEditReq req) {
        LambdaQueryWrapper<TRiskConstants> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(TRiskConstants::getPriority,req.getPriority());
        wrapper.eq(TRiskConstants::getIsDeleted,YesNoEnum.NO.getCode());
        wrapper.notIn(TRiskConstants::getId,req.getId());
        List<TRiskConstants> oldLabels = this.list(wrapper);
        if(CollectionUtils.isNotEmpty(oldLabels)){
            throw new BusinessException(" Exist the same priority for key ："+oldLabels.get(0).getPKey(),ResultEnum.BAD_REQUEST.getCode());
        }
        TRiskConstants entity = JSONObject.parseObject(JSONObject.toJSONString(req),TRiskConstants.class);
        entity.setPKey(null);
        entity.setPValue(null);
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if(!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())){
            entity.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        redisTemplate.delete(RedisConstant.LABEL_RULE_KEY + req.getId());//删除标签-规则关系缓存
        return this.updateById(entity);
    }

    @Override
    public boolean deleteById(BigInteger id) {
        TRiskConstants entity = new TRiskConstants();
        entity.setId(id);
        UserInfoVO userInfoVO = CurrentUserUtil.get();
        if(!Objects.isNull(userInfoVO) && !Objects.isNull(userInfoVO.getUserInfo())){
            entity.setUpdateBy(userInfoVO.getUserInfo().getUsername());
        }
        entity.setIsDeleted(1);
        TRiskConstants oldRiskConstants = this.getById(id);
        if(oldRiskConstants.getIsEnable().equals(YesNoEnum.YES.getIntCode())){
            throw new BusinessException("Please disable before deleting",ResultEnum.BAD_REQUEST.getCode());
        }
        boolean flag = this.updateById(entity);
        if(flag){
            LambdaQueryWrapper<TLabelRuleRelationship> labelRuleWrapper = new LambdaQueryWrapper<>();
            labelRuleWrapper.eq(TLabelRuleRelationship::getLabelId,id);
            int deleteRule = labelRuleRelationshipMapper.delete(labelRuleWrapper);//删除标签-规则关系
            Boolean deleteRuleRedis = redisTemplate.delete(RedisConstant.LABEL_RULE_KEY + id);//删除标签-规则关系缓存
            log.info("删除标签规则 labelId:{}, db：{},redis:{}",id,deleteRule,deleteRuleRedis);
            LambdaQueryWrapper<TRiskLabelRelationship> labelRelationWrapper = new LambdaQueryWrapper<>();
            labelRelationWrapper.eq(TRiskLabelRelationship::getRiskLabelId,id);
            List<TRiskLabelRelationship> labelRelationships = RiskLabelRelationshipMapper.selectList(labelRelationWrapper);
            if(CollectionUtils.isNotEmpty(labelRelationships)){
                List<String> customerIds = labelRelationships.stream().map(c-> RedisConstant.CUSTOMER_LABEL_KEY+c.getCustomerId()).collect(Collectors.toList());
                int deleteCusLabel = RiskLabelRelationshipMapper.delete(labelRelationWrapper);//删除用户标签关系
                Long deleteCusLabelRedis = redisTemplate.delete(customerIds);//删除相关用户的标签缓存
                log.info("删除用户标签 labelId:{}, db：{},redis:{}",id,deleteCusLabel,deleteCusLabelRedis);
            }
            //todo 用户标签关系表，暂时不操作，看后续是否有要求
        }
        return flag;
    }

    @Override
    public List<RiskLabelDetailsRsp> queryConstantByType(String type) {
        LambdaQueryWrapper<TRiskConstants> labelRuleWrapper = new LambdaQueryWrapper<>();
        labelRuleWrapper.eq(TRiskConstants::getIsDeleted, YesNoEnum.NO.getIntCode()).eq(TRiskConstants::getIsEnable, YesNoEnum.YES.getIntCode());
        if (StringUtils.isNotBlank(type)) {
            labelRuleWrapper.eq(TRiskConstants::getPType, type);
        }
        return this.list(labelRuleWrapper).stream().map(de -> {
            RiskLabelDetailsRsp rsp = new RiskLabelDetailsRsp();
            BeanUtils.copyProperties(de, rsp);
            return rsp;
        }).collect(Collectors.toList());
    }

    @Override
    public List<RiskLabelDetailsRsp> queryConstantById(List<Integer> ids) {
        LambdaQueryWrapper<TRiskConstants> labelRuleWrapper = new LambdaQueryWrapper<>();
        labelRuleWrapper.eq(TRiskConstants::getIsDeleted, 0).eq(TRiskConstants::getIsEnable, 1);
        if (CollectionUtils.isNotEmpty(ids)) {
            ids = ids.stream().distinct().collect(Collectors.toList());
            labelRuleWrapper.in(TRiskConstants::getId, ids);
        }
        return this.list(labelRuleWrapper).stream().map(de -> {
            RiskLabelDetailsRsp rsp = new RiskLabelDetailsRsp();
            BeanUtils.copyProperties(de, rsp);
            return rsp;
        }).collect(Collectors.toList());
    }


}
