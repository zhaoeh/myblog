package com.riskcontrol.office.service;

import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.office.domain.constans.req.QueryConstantsListReq;

import javax.servlet.http.HttpServletRequest;

public interface IConstantsService {

    Response queryList(HttpServletRequest request, QueryConstantsListReq req);

}
