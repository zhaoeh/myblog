package com.riskcontrol.office.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.riskcontrol.office.domain.entity.TPbcCrawlerResultNew;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TPbcCrawlerResultNewMapper extends BaseMapper<TPbcCrawlerResultNew> {
}