package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;


/**
 * eKYC结果表
 */
@TableName(value = "t_ekyc")
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class TEkyc extends  BaseEntity{


    /**
     * 用户ID
     */
    @TableField(value = "customer_id",fill = FieldFill.INSERT)
    private Long customerId;

    /**
     * 用户名
     */
    @TableField(value = "login_name",fill = FieldFill.INSERT)
    private String loginName;

    /**
     * 首名
     */
    @TableField(value = "first_name",fill = FieldFill.INSERT)
    private String firstName;

    /**
     * 中间名
     */
    @TableField(value = "middle_name",fill = FieldFill.INSERT)
    private String middleName;

    /**
     * 尾名
     */
    @TableField(value = "last_name",fill = FieldFill.INSERT)
    private String lastName;

    /**
     * 生日
     */
    @TableField(value = "birthday",fill = FieldFill.INSERT)
    private String birthday;

    /**
     * M=Male, F=Female
     */
    @TableField(value = "sex",fill = FieldFill.INSERT)
    private String sex;

    /**
     * 证件证明照
     */
    @TableField(value = "id_front_img",fill = FieldFill.INSERT)
    private String idFrontImg;

    /**
     * 证件背面照
     */
    @TableField(value = "id_back_img",fill = FieldFill.INSERT)
    private String idBackImg;

    /**
     * 证件类型
     */
    @TableField(value = "id_type")
    private Integer idType;

    /**
     * 证件号
     */
    @TableField(value = "id_no",fill = FieldFill.INSERT)
    private String idNo;

    /**
     * 自拍照
     */
    @TableField(value = "face_img", fill = FieldFill.INSERT)
    private String faceImg;

    /**
     * KYC状态 -1待提交 0 待审核，1 通过，2 拒绝，3手动拒绝
     */
    @TableField(value = "`status`")
    private Integer status;

    /**
     * 创建时间
     */
    @TableField(value = "create_date",fill = FieldFill.INSERT)
    private String createDate;

    /**
     * 创建人
     */
    @TableField(value = "create_by",fill = FieldFill.INSERT)
    private String createBy;

    /**
     * 更新时间
     */
    private String updateDate;

    /**
     * 更新人
     */
    @TableField(value = "update_by",fill = FieldFill.INSERT)
    private String updateBy;

    /**
     * 血缘标记（BP、AP、 GP、PG、SP）
     */
    @TableField(value = "tenant",fill = FieldFill.INSERT)
    private String tenant;

    /**
     * 渠道(3:GLIFE,4:GPO,5:LAZADA,6:MAYA,7:PERYAGAME,99WEBSITE,98:人工)
     */
    @TableField(value = "channel",fill = FieldFill.INSERT)
    private String channel;

    /**
     * 企业名称
     */
    @TableField(value = "employer_name",fill = FieldFill.INSERT)
    private String employerName;

    /**
     * 永久居住地
     */
    @TableField(value = "address",fill = FieldFill.INSERT)
    private String address;

    /**
     * 出生地
     */
    @TableField(value = "birth_place",fill = FieldFill.INSERT)
    private String birthPlace;

    /**
     * 现居地址
     */
    @TableField(value = "present_address",fill = FieldFill.INSERT)
    private String presentAddress;

    /**
     * 国籍
     */
    @TableField(value = "nationality",fill = FieldFill.INSERT)
    private String nationality;

    /**
     * 资金来源
     */
    @TableField(value = "source_of_income",fill = FieldFill.INSERT)
    private String sourceOfIncome;

    /**
     * 工作性质
     */
    @TableField(value = "nature_of_work",fill = FieldFill.INSERT)
    private String natureOfWork;

    /**
     * 备注
     */
    @TableField(value = "remark",fill = FieldFill.INSERT)
    private String remark;

    /**
     * 拒绝原因
     */
    @TableField(value = "reject_reason",fill = FieldFill.INSERT)
    private String rejectReason;

}