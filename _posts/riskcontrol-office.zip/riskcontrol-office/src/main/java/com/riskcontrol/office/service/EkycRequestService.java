package com.riskcontrol.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cn.schema.customers.WSCustomers;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.domain.entity.TEkyc;
import com.riskcontrol.office.domain.entity.TEkycRequest;
import com.riskcontrol.office.domain.req.ekyc.EkycRequestApprovedRequest;
import com.riskcontrol.office.domain.req.ekyc.EkycRequestCreateRequest;
import com.riskcontrol.office.domain.req.ekyc.EkycRequestQueryRequest;
import com.riskcontrol.office.domain.req.ekyc.EkycRequestUpdateRequest;
import com.riskcontrol.office.domain.rsp.ekyc.EkycRequestInfoResponse;
import com.riskcontrol.office.domain.rsp.ekyc.EkycRequestQueryResponse;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigInteger;
import java.util.Map;


/**
 * @author Heng.zhang
 */
public interface EkycRequestService  extends IService<TEkycRequest> {

    /**
     * ekyc申请表分页查询
     * @param req
     * @return
     */
    PageModel<EkycRequestQueryResponse> pageEkycRequestList(EkycRequestQueryRequest req);

    /**
     * 通过id查询ekyc申请表
     * @param id
     * @return
     */
    EkycRequestInfoResponse getEkycRequestDetail(BigInteger id);

    /**
     * 创建提案
     * @param request
     * @return
     */
    boolean ekycRequestCreate(EkycRequestCreateRequest request);


    /**
     * 更新提案
     * @param request
     * @return
     */
    boolean ekycRequestUpdate(EkycRequestUpdateRequest request);


    /**
     * 审核提案
     * @param request
     * @return
     */
    boolean ekycRequestApproved(EkycRequestApprovedRequest request);


    /**
     * 查询顶部计数器接口
     */
    Long getTopCount();

    /**
     * 上传文件*
     *
     * @param file
     */
    Map<String, String> upload(MultipartFile file);

    Boolean updateWsUserInfo(TEkyc ekyc, WSCustomers wsCustomers);
}
