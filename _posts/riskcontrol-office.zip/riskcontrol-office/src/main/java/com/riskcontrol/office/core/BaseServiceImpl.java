package com.riskcontrol.office.core;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.constants.SQLConstants;
import com.riskcontrol.common.entity.request.BasePageRequest;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.utils.ClassUtil;
import com.riskcontrol.common.utils.CommonUtil;
import com.riskcontrol.common.utils.ListUtil;
import com.riskcontrol.office.domain.entity.BaseEntity;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Field;
import java.util.Collection;
import java.util.List;

/**
 * Mybatis-plus BaseService(抽取分页等共通接口) TODO 优化用
 *
 * @param <M> mapper(BaseMapper子类)
 * @param <T> entity(BaseEntity子类)
 */
public abstract class BaseServiceImpl<M extends BaseMapper<T>, T extends BaseEntity> extends ServiceImpl<M, T> implements BaseService<T> {

    /**
     * 分页查询(无VO转换;不包含排序)
     *
     * @param query requestDto
     * @return 分页数据
     */
    protected <Q extends BasePageRequest> Page<T> page(Q query) {
        LambdaQueryWrapper<T> wrapper = buildWrapper(query);
        return pageByWrapper(query, wrapper);
    }

    /**
     * 分页查询(无VO转换;不包含排序)
     *
     * @param query requestDto
     * @return 分页数据
     */
    protected <V, Q extends BasePageRequest> Page<V> pageVO(Q query, Class<V> clazz) {
        LambdaQueryWrapper<T> wrapper = buildWrapper(query);
        return pageVoByWrapper(query, wrapper, clazz);
    }

    /**
     * 分页查询(无VO转换;包含排序，目前只支持单字段排序)
     *
     * @param query        requestDto
     * @param queryWrapper queryWrapper
     * @return 分页数据
     */
    protected Page<T> pageByWrapper(BasePageRequest query, Wrapper<T> queryWrapper) {
        Page<T> page = new Page<>();
        page.setCurrent(query.getPageNum());
        page.setSize(query.getPageSize());
        if (StringUtils.isNotBlank(query.getSortName())) {
            String underlineCase = CommonUtil.toUnderlineCase(query.getSortName());
            OrderItem orderItem = new OrderItem(underlineCase, query.getIsAsc());
            page.setOrders(List.of(orderItem));
        }
        return this.page(page, queryWrapper);
    }

    /**
     * 分页查询(VO转换;包含排序，目前只支持单字段排序)
     *
     * @param query        requestDto
     * @param queryWrapper queryWrapper
     * @param clazz        VO类型
     * @param <V>          VO类型
     * @return 分页数据
     */
    protected <V> Page<V> pageVoByWrapper(BasePageRequest query, Wrapper<T> queryWrapper, Class<V> clazz) {
        Page<T> page = new Page<>();
        page.setCurrent(query.getPageNum());
        page.setSize(query.getPageSize());
        if (StringUtils.isNotBlank(query.getSortName())) {
            String underlineCase = CommonUtil.toUnderlineCase(query.getSortName());
            OrderItem orderItem = new OrderItem(underlineCase, query.getIsAsc());
            page.setOrders(List.of(orderItem));
        }
        Page<T> iPage = this.page(page, queryWrapper);
        Page<V> tiPage = new Page<>();
        tiPage.setRecords(ListUtil.copyList(iPage.getRecords(), clazz));
        tiPage.setPages(iPage.getPages());
        tiPage.setCurrent(iPage.getCurrent());
        tiPage.setSize(iPage.getSize());
        tiPage.setTotal(iPage.getTotal());
        return tiPage;
    }

    /**
     * 构建查询条件
     *
     * @param w   requestDto
     * @param <W> requestDto
     * @return 查询条件
     */
    protected <W> LambdaQueryWrapper<T> buildWrapper(W w) {
        QueryWrapper<T> query = new QueryWrapper<>();
//        query.eq("is_deleted", 0);
        Field[] fields = w.getClass().getDeclaredFields();
        // 循环每个字段
        for (Field field : fields) {
            field.setAccessible(true);
            Object o;
            try {
                o = field.get(w);
            } catch (IllegalAccessException e) {
                log.error("反射获取值异常", e);
                throw new BusinessException(ResultEnum.FRAMEWORK_ERROR);
            }

            // 获取Query条件
            Query queryMethod = field.getAnnotation(Query.class);
            if (queryMethod == null) {
                continue;
            }

            // 当字段为空且需要进行非空校验时跳过，不拼接该参数
            if (ObjectUtils.isEmpty(o) && queryMethod.check()) {
                continue;
            }

            // 获取字段对应的db字段(推荐，即保持和entity字段名一致)
            String dbName = field.getName();
            // 如果指定了数据库(实体类)字段，则优先使用数据库字段
            if (StringUtils.isNotEmpty(queryMethod.field())) {
                dbName = queryMethod.field();
            }
            // 获取到字段的情况下，获取每个字段上的注解
            if (ClassUtil.fieldInClass(dbName, getEntityClass())) {
                dbName = CommonUtil.toUnderlineCase(dbName);
                // 判断每个条件的查询方法
                switch (queryMethod.mt()) {
                    case SQLConstants.Query.EQ:
                        query.eq(dbName, o);
                        break;
                    case SQLConstants.Query.LIKE:
                        query.like(dbName, o);
                        break;
                    case SQLConstants.Query.LIKE_RIGHT:
                        query.likeRight(dbName, o);
                        break;
                    case SQLConstants.Query.IN:
                        if (o instanceof Collection) {
                            query.in(dbName, (Collection<?>) o);
                        } else {
                            query.in(dbName, o);
                        }
                        break;
                    case SQLConstants.Query.NE:
                        query.ne(dbName, o);
                        break;
                    case SQLConstants.Query.GT:
                        query.gt(dbName, o);
                        break;
                    case SQLConstants.Query.GE:
                        query.ge(dbName, o);
                        break;
                    case SQLConstants.Query.LT:
                        query.lt(dbName, o);
                        break;
                    case SQLConstants.Query.LE:
                        query.le(dbName, o);
                        break;
                    default:
                        break;
                }
            }
        }
        return query.lambda();
    }


}
