package com.riskcontrol.office.domain.req.ekyc;

import com.riskcontrol.common.annotation.EnumValid;
import com.riskcontrol.common.entity.request.BasePageRequest;
import com.riskcontrol.common.enums.CardTypeEnum;
import com.riskcontrol.common.enums.TenantEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.math.BigInteger;

/**
 * @author Heng.zhang
 */
@Data
@ApiModel(value = "Ekyc申请表新增", description = "Ekyc申请表新增")
public class EkycRequestUpdateRequest extends BasePageRequest {
    @ApiModelProperty("ID")
    private BigInteger id;

    @ApiModelProperty(required = true, value = "首名")
    @NotBlank(message = "firstName cannot be blank")
    private String firstName;

    @ApiModelProperty("中间名")
    private String middleName;

    @ApiModelProperty(required = true, value = "尾名")
    @NotBlank(message = "lastName cannot be blank")
    private String lastName;

    @ApiModelProperty(required = true, value = "生日")
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "birthday format error")
    @NotBlank(message = "birthday cannot be blank")
    private String birthday;

    @ApiModelProperty(required = true, value = "性别")
    @Pattern(regexp = "M|F", message = "set must be M or F")
    @NotBlank(message = "sex cannot be blank")
    private String sex;

    @ApiModelProperty(required = true, value = "证件正面照")
    @NotBlank(message = "idFrontImg cannot be blank")
    private String idFrontImg;

    @ApiModelProperty(required = true, value = "证件背面照")
    @NotBlank(message = "idBackImg cannot be blank")
    private String idBackImg;

    @ApiModelProperty(required = true, value = "证件类型")
    @NotNull(message = "idType cannot be null")
    @EnumValid(enumClass = CardTypeEnum.class, enumField = "code",message = "idType must belong to {target}")
    private Integer idType;

    @ApiModelProperty(required = true, value = "证件号")
    @NotBlank(message = "idNo cannot be blank")
    private String idNo;

    @ApiModelProperty(required = true, value = "自拍照")
    @NotBlank(message = "faceImg cannot be blank")
    private String faceImg;

    @ApiModelProperty(required = true, value = "血缘标记（BP、AP、 GP、PG、SP）")
    @EnumValid(enumClass = TenantEnum.class, enumField = "name",message = "tenant must belong to {target}")
    @NotBlank(message = "tenant cannot be blank")
    private String tenant;

    @ApiModelProperty("企业名称")
    private String employerName;

    @ApiModelProperty("永久居住地")
    private String address;

    @ApiModelProperty("出生地")
    private String birthPlace;

    @ApiModelProperty("现居地址")
    private String presentAddress;

    @ApiModelProperty("国籍")
    private String nationality;

    @ApiModelProperty("资金来源")
    private String sourceOfIncome;

    @ApiModelProperty("工作性质")
    private String natureOfWork;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("人工提交截图")
    private String manualImg;

}
