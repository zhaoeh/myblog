package com.riskcontrol.office.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
    * 手机号黑名单
    */
@Schema(description="手机号黑名单")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@TableName(value = "t_phone_number_blacklist")
public class TPhoneNumberBlacklist extends BaseEntity {
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.ASSIGN_ID)
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    /**
     * 所有历史绑定的用户ID，逗号分隔，按照时间顺序增加
     */
    @TableField(value = "history")
    @Schema(description="所有历史绑定的用户ID，逗号分隔，按照时间顺序增加")
    private String history;

    /**
     * 所属产品
     */
    @TableField(value = "product_id")
    @Schema(description="所属产品")
    private String productId;

    /**
     * 手机号码
     */
    @TableField(value = "phone")
    @Schema(description="手机号码")
    private String phone;

    /**
     * 手机号码md5
     */
    @TableField(value = "phone_md5")
    @Schema(description="手机号码md5")
    private String phoneMd5;

    /**
     * 状态：0-失效，1-生效中
     */
    @TableField(value = "`status`")
    @Schema(description="状态：0-失效，1-生效中")
    private Integer status;

    /**
     * 备注
     */
    @TableField(value = "remarks")
    @Schema(description="备注")
    private String remarks;

    /**
     * 创建人
     */
    @TableField(value = "create_by")
    @Schema(description="创建人")
    private String createBy;

    @TableField(value = "create_time")
    @Schema(description  = "创建日期(Create Time)")
    protected Date createTime;

    /**
     * 最后一次最后修改的account
     */
    @TableField(value = "data_modifier")
    @Schema(description="最后一次最后修改的account")
    private String dataModifier;

    /**
     * 最后修改时间
     */
    @TableField(value = "last_update_time")
    @Schema(description="最后修改时间")
    private Date lastUpdateTime;

    private static final long serialVersionUID = 1L;
}