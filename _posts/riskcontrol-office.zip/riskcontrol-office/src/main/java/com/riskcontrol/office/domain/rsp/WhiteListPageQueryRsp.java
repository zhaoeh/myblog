package com.riskcontrol.office.domain.rsp;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.math.BigInteger;

/**
 * @description: 白名单分页查询返回
 * @author: Yu.Guo
 * @create: 2024-11-15
 **/
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class WhiteListPageQueryRsp {
    @Schema(description = "白名单主键")
    @JsonProperty("id")
    private BigInteger id;

    @Schema(description = "ip地址")
    @JsonProperty("allowRecord")
    private String allowRecord;

    @Schema(description = "规则限制行为（0：登录：1：注册）")
    @JsonProperty("allowAction")
    private Integer allowAction;

    @Schema(description = "名单规则（0：白名单；1：黑名单）")
    @JsonProperty("allowRule")
    private Integer allowRule;

    @Schema(description = "规则校验类型（0：ip ; 1：设备指纹；）")
    @JsonProperty("allowType")
    private Integer allowType;


    @Schema(description = "可用状态（0：可用；1：禁用）")
    @JsonProperty("isEnable")
    private Integer isEnable;

    @Schema(description = "备注")
    @JsonProperty("remark")
    private String remark;

    @Schema(description = "创建人")
    @ApiModelProperty("createBy")
    private String createBy;

    @Schema(description = "创建时间")
    @ApiModelProperty("createDate")
    private String createDate;

    @ApiModelProperty("更新人")
    private String updateBy;

    @ApiModelProperty("更新时间")
    private String updateDate;
}
