package com.riskcontrol.office.domain.rsp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/8/7 14:57
 */
@ApiModel(value = "查询大数据存款、投注、取款报表响应对象", description = "查询大数据存款、投注、取款报表响应对象")
@Data
public class PlayerReportRsp {
    @ApiModelProperty("用户名")
    protected String account;
    @ApiModelProperty("上级")
    protected String parent;
    @ApiModelProperty("门店编码")
    protected String branch;
    @ApiModelProperty("门店名称")
    protected String branchName;
    @ApiModelProperty(value = "存款金额")
    protected BigDecimal deposit;
    @ApiModelProperty(value = "取款金额")
    protected BigDecimal withdrawal;
    @ApiModelProperty(value = "有效投注额（大数据反应部分游戏可能存在负数的情况，不建议使用）")
    protected BigDecimal turnover;
    @ApiModelProperty(value = "投注额")
    protected BigDecimal newbetAmount;
    @ApiModelProperty(value = "投注比 投注额/存款额")
    protected BigDecimal betAmountDepositRate;
    @ApiModelProperty(value = "盈利金额")
    protected BigDecimal winAndLoss;
    @ApiModelProperty(value = "派彩")
    protected BigDecimal payout;
    @ApiModelProperty(value = "奖池收益")
    protected BigDecimal jackpot;
    @ApiModelProperty(value = "游戏收益")
    protected BigDecimal grossGamingRevenue;
    @ApiModelProperty(value = "优惠金额")
    protected BigDecimal promotionAmount;
}
