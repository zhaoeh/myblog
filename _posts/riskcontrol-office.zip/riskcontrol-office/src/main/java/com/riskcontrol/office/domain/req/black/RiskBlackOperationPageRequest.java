package com.riskcontrol.office.domain.req.black;

import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.constants.SQLConstants;
import com.riskcontrol.common.entity.request.BasePageRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;


/**
 * @author Heng.zhang
 */
@Data
@ApiModel(value = "风控黑名单操作日志分页查询请求对象", description = "风控黑名单操作日志分页查询参数")
public class RiskBlackOperationPageRequest extends BasePageRequest {

    @Schema(description = "createdDate Begin", example = "")
    @Query(field = "create_date", mt = SQLConstants.Query.GE)
    private String createdDateBegin;

    @Schema(description = "createdDate End", example = "")
    @Query(field = "create_date", mt = SQLConstants.Query.LE)
    private String createdDateEnd;

}