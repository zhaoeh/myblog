package com.riskcontrol.office.util.aws;

import com.cn.schema.request.common.BUCKET_FILE;
import com.google.common.io.ByteStreams;
import com.riskcontrol.office.common.constants.ConstantVars;
import com.riskcontrol.office.util.RedisUtils;
import com.riskcontrol.office.util.oss.OssProperties;
import com.riskcontrol.office.util.oss.OssService;
import net.coobird.thumbnailator.Thumbnails;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.bouncycastle.util.encoders.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.ObjectCannedACL;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.time.Duration;
import java.time.Instant;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * 亚马逊s3
 */
public class AwsServiceImpl implements OssService {

    protected static Logger logger = LoggerFactory.getLogger("AwsServiceImpl");


    /**
     * minioClient
     */
    private OssProperties ossProperties;

    private GenericObjectPool<S3Client> s3ClientObjectPool;



    public AwsServiceImpl(OssProperties ossProperties) {
        this.ossProperties = ossProperties;


        // 环境中没有配置亚马逊云存储参数时，跳过初始化
        logger.info("AWSS3Util 配置初始化,aws.s3.bucketName:{},aws.s3.region:{},aws.s3.accessKeyId:{},aws.s3.secretAccessKey:{}.",ossProperties.getBucketName(),ossProperties.getRegion(),ossProperties.getAccessKeyId(),ossProperties.getSecretAccessKey());

        GenericObjectPoolConfig poolConfig = new GenericObjectPoolConfig();
        poolConfig.setMaxIdle(50);
        poolConfig.setMaxTotal(50);
        poolConfig.setMinIdle(50);

        AwsBasicCredentials credentials = AwsBasicCredentials.create(ossProperties.getAccessKeyId(), ossProperties.getSecretAccessKey());
        S3Client s3 = S3Client.builder().credentialsProvider(StaticCredentialsProvider.create(credentials)).region(Region.of(ossProperties.getRegion())).build();

        s3ClientObjectPool = new GenericObjectPool<S3Client>(new S3ClientFactory(ossProperties.getAccessKeyId(), ossProperties.getSecretAccessKey(), ossProperties.getRegion()), poolConfig);


        //初始化文件桶
        //for (BUCKET_FILE bucket_file : BUCKET_FILE.values()) {
        //existAndMake(bucket_file.bucket());
        //}
        //初始化无权限文件
//        InputStream pictureStream = null;
//        try {
//            logger.info("初始化aws s3文件存储客户端,bucket为{}", ossProperties.getIdentityBucketName());
//            pictureStream = getClass().getClassLoader().getResourceAsStream(IDENTITY_NO_PERMIT_PICTURE);
//            uploadFile(BUCKET_FILE.IDENTITY.bucket(), pictureStream, MimeTypeUtils.IMAGE_PNG.toString(), IDENTITY_NO_PERMIT_PICTURE);
//        } catch (Exception e) {
//            logger.error("初始化无权限文件失败", e);
//        } finally {
//            IOUtils.closeQuietly(pictureStream);
//        }

    }

    class S3ClientFactory extends BasePooledObjectFactory<S3Client> {

        private String regionStr;

        private String accessKeyId;

        private String secretAccessKey;


        public S3ClientFactory(String accessKeyId, String secretAccessKey, String regionStr) {
            this.accessKeyId = accessKeyId;
            this.secretAccessKey = secretAccessKey;
            this.regionStr = regionStr;
        }


        @Override
        public S3Client create() throws Exception {
            AwsBasicCredentials credentials = AwsBasicCredentials.create(accessKeyId, secretAccessKey);
            S3Client s3 = S3Client.builder().credentialsProvider(StaticCredentialsProvider.create(credentials)).region(Region.of(regionStr)).build();
            return s3;
        }

        @Override
        public PooledObject<S3Client> wrap(S3Client s3Client) {
            return new DefaultPooledObject<>(s3Client);
        }


    }


    @Override
    public String uploadFile(String bucketName, InputStream stream, String contentType, String fileName) throws Exception {
        // 上传文件路径
        S3Client s3Client = null;
        try {
            // 上传文件
            s3Client = s3ClientObjectPool.borrowObject();
            if (Objects.isNull(s3Client)) {
                logger.error("s3Client is null:{}", s3Client);
                return "";
            }
            s3Client.putObject(PutObjectRequest.builder().bucket(bucketName).acl(ObjectCannedACL.PUBLIC_READ).contentType(contentType).key(fileName).build(),
                    RequestBody.fromInputStream(stream, stream.available()));
            return fileName;
        } catch (Exception e) {
            logger.error("{}文件上传失败", fileName, e);
            return "";
        }finally {
            if (s3Client != null) {
                s3ClientObjectPool.returnObject(s3Client);
            }
        }
    }

    @Override
    public InputStream getFile(String bucketName, String objectName) {
        S3Client s3Client = null;
        try {
            // 获取文件
            s3Client = s3ClientObjectPool.borrowObject();
            GetObjectRequest getObjectRequest = GetObjectRequest.builder().bucket(bucketName).key(objectName).build();
            return s3Client.getObject(getObjectRequest);
        } catch (Exception e) {
            logger.error("{}文件获取失败", objectName, e);
            return null;
        } finally {
            if (s3Client != null) {
                s3ClientObjectPool.returnObject(s3Client);
            }
        }
    }

    @Override
    public String getFileBase64(String bucketName, String key) {
        S3Client s3Client = null;
        try {
            Instant start = Instant.now();
            s3Client = s3ClientObjectPool.borrowObject();
            GetObjectRequest req = GetObjectRequest.builder().bucket(bucketName).key(key).build();
            ResponseInputStream<GetObjectResponse> object = s3Client.getObject(req);
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            Thumbnails.of(object).scale(1f).toOutputStream(outputStream);

            Instant end = Instant.now();
            logger.info("s3GetObject 耗时:" + Duration.between(start, end).toMillis());

            return java.util.Base64.getEncoder().encodeToString(outputStream.toByteArray());
        } catch (Exception e) {
            logger.error("S3读取失败", e);
            return "";
        } finally {
            if (s3Client != null) {
                s3ClientObjectPool.returnObject(s3Client);
            }
        }
    }


    @Override
    public void putObject(String bucketName, String base64Img, String key) {
        S3Client s3Client = null;
        try {
            Instant start = Instant.now();
            s3Client = s3ClientObjectPool.borrowObject();
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

            File f = new File(key + ".jpg");

            Thumbnails.of(new ByteArrayInputStream(Base64.decode(base64Process(base64Img)))).scale(1f).toFile(f);

            //Put a file into the bucket
            s3Client.putObject(PutObjectRequest.builder().bucket(bucketName).key(key).build(),
                    RequestBody.fromFile(f)
            );
            Instant end = Instant.now();
            logger.info("s3PutObject KEY:{} 耗时: {}", key, Duration.between(start, end).toMillis());
        } catch (Exception e) {
            logger.error("S3上传失败", e);
        } finally {
            if (s3Client != null) {
                s3ClientObjectPool.returnObject(s3Client);
            }
        }
    }

    // 注意: 敏感数据请勿使用public
    @Override
    public String putObject(String bucketName, File base64Img, String key, boolean isPublic) {
        S3Client s3Client = null;
        try {
            Instant start = Instant.now();
            s3Client = s3ClientObjectPool.borrowObject();
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

            //Put a file into the bucket
            PutObjectRequest.Builder requestBuilder = PutObjectRequest.builder().bucket(bucketName).key(key);
            if (isPublic){
                requestBuilder.acl(ObjectCannedACL.PUBLIC_READ);
            }
            s3Client.putObject(requestBuilder.build(),
                    RequestBody.fromFile(base64Img)
            );
            Instant end = Instant.now();
            logger.info("s3PutObject KEY:{} 耗时: {}", key, Duration.between(start, end).toMillis());

            return isPublic?getPublicUrl(key):key;
        } catch (Exception e) {
            logger.error("S3上传失败 {}，{}" , key,e);
            return "";
        } finally {
            if (s3Client != null) {
                s3ClientObjectPool.returnObject(s3Client);
            }
        }
    }

    @Override
    public void putObject(String bucketName, byte[] base64Img, String key) {
        S3Client s3Client = null;
        try {
            Instant start = Instant.now();
            s3Client = s3ClientObjectPool.borrowObject();
            //Put a file into the bucket
            s3Client.putObject(PutObjectRequest.builder().bucket(bucketName).key(key).build(),
                    RequestBody.fromBytes(base64Img)
            );
            Instant end = Instant.now();
            logger.info("s3PutObject 耗时:" + Duration.between(start, end).toMillis());
        } catch (Exception e) {
            logger.error("S3上传失败", e);
        } finally {
            if (s3Client != null) {
                s3ClientObjectPool.returnObject(s3Client);
            }
        }
    }

    @Override
    public byte[] getFileByte(String bucketName, String key) {
        S3Client s3Client = null;
        try {
            Instant start = Instant.now();
            s3Client = s3ClientObjectPool.borrowObject();
            GetObjectRequest req = GetObjectRequest.builder().bucket(bucketName).key(key).build();
            ResponseInputStream<GetObjectResponse> object = s3Client.getObject(req);
            Instant end = Instant.now();
            logger.info("s3GetObjectByte 耗时:" + Duration.between(start, end).toMillis());

            return ByteStreams.toByteArray(object);
        } catch (Exception e) {
            logger.error("S3读取失败", e);
            return null;
        } finally {
            if (s3Client != null) {
                s3ClientObjectPool.returnObject(s3Client);
            }
        }
    }

    @Override
    public String getFileUrl(String bucketName, String key) {

        if (StringUtils.isBlank(key))
            return "";
        String fileUrl=  RedisUtils.get(bucketName + ConstantVars.COLON_SPLIT + key,String.class);
        if(StringUtils.isBlank(fileUrl)){
            Instant start = Instant.now();
            GetObjectRequest getObjectRequest = GetObjectRequest.builder().bucket(bucketName).key(key).build();
            GetObjectPresignRequest getObjectPresignRequest = GetObjectPresignRequest.builder().signatureDuration(Duration.ofDays(1)).getObjectRequest(getObjectRequest).build();
            AwsBasicCredentials credentials = AwsBasicCredentials.create(ossProperties.getAccessKeyId(), ossProperties.getSecretAccessKey());
            S3Presigner presigner = S3Presigner.builder().credentialsProvider(StaticCredentialsProvider.create(credentials)).region(Region.of(ossProperties.getRegion())).build();

            PresignedGetObjectRequest presignedGetObjectRequest = presigner.presignGetObject(getObjectPresignRequest);
            Instant end = Instant.now();
            logger.info("s3GetUrl KEY:{} 耗时: {}", key, Duration.between(start, end).toMillis());
            fileUrl = presignedGetObjectRequest.url() + "";
            RedisUtils.setExpire(bucketName + ConstantVars.COLON_SPLIT + key,fileUrl,23L, TimeUnit.HOURS);
        }
        return fileUrl;

    }

    @Override
    public String getFileTxtUrl(String bucketName, String objectName) {
        if (StringUtils.isBlank(objectName))
            return "";
        String fileUrl=  RedisUtils.get(bucketName + ConstantVars.COLON_SPLIT + objectName,String.class);
        if(StringUtils.isBlank(fileUrl)){
            GetObjectRequest getObjectRequest = GetObjectRequest.builder().bucket(bucketName).key(objectName).build();
            GetObjectPresignRequest getObjectPresignRequest = GetObjectPresignRequest.builder().signatureDuration(Duration.ofDays(1)).getObjectRequest(getObjectRequest).build();
            AwsBasicCredentials credentials = AwsBasicCredentials.create(ossProperties.getAccessKeyId(), ossProperties.getSecretAccessKey());
            S3Presigner presigner = S3Presigner.builder().credentialsProvider(StaticCredentialsProvider.create(credentials)).region(Region.of(ossProperties.getRegion())).build();

            PresignedGetObjectRequest presignedGetObjectRequest = presigner.presignGetObject(getObjectPresignRequest);
            fileUrl = presignedGetObjectRequest.url() + "";
            RedisUtils.setExpire(bucketName + ConstantVars.COLON_SPLIT + objectName,fileUrl,23L, TimeUnit.HOURS);
        }
        return fileUrl;
    }

    @Override
    public String getFileUrl(String bucketName, String key, String suffix) {
        return getFileUrl(bucketName, key);
    }

    @Override
    public String putObject(String bucketName, File base64Img, String key, String suffix, boolean isPublic) {
        return this.putObject(bucketName, base64Img, key, isPublic);
    }

    private String getBucketName(String bucketName) {
        if (BUCKET_FILE.IDENTITY.bucket().equals(bucketName)) {
            return ossProperties.getIdentityBucketName();
        }
        return null;
    }

    private String base64Process(String base64Str) {
        if (!StringUtils.isEmpty(base64Str)) {
            String photoBase64 = base64Str.substring(0, 30).toLowerCase();
            int indexOf = photoBase64.indexOf("base64,");
            if (indexOf > 0) {
                base64Str = base64Str.substring(indexOf + 7);
            }

            return base64Str;
        } else {
            return "";
        }
    }

    public String getPublicUrl(String key){
        return "https://"+ossProperties.getBucketName()+".s3."+ossProperties.getRegion()+".amazonaws.com/"+key;
    }

}
