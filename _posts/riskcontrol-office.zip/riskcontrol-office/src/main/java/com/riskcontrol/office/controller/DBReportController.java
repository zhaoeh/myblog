package com.riskcontrol.office.controller;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.digiplus.oms.aspect.annotation.PreAuthorize;
import com.riskcontrol.common.client.DBReportApiFeign;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.req.PlayerReportReq;
import com.riskcontrol.office.domain.rsp.PlayerReportRsp;
import io.swagger.annotations.ApiOperation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/8/8 14:25
 */
@Tag(name = "首页仪表盘", description = "首页仪表盘")
@RestController
@RequestMapping(value = "/db_report")
@Slf4j
public class DBReportController {

    @Resource
    private DBReportApiFeign dbReportApiFeign;
    @PreAuthorize("riskManage_crawl_query,riskManage_crawl_export")
    @ApiOperation(value = "根据日期、存款区间 查询所有用户投注、存取款、优惠数据", tags = "大数据接口")
    @PostMapping(value = "getPlayerReportPage")
    @ResponseBody
    public R<PageModel<PlayerReportRsp>> getPlayerReportPage(@Validated @RequestBody PlayerReportReq req) {
        PageModel<PlayerReportRsp> page = new PageModel<>(req.getPageNo(),req.getPageSize());
        if(StringUtils.isBlank(req.getOrderByFields())
                || !req.getOrderByFields().equals("betAmountDepositRate") && !req.getOrderByFields().equals("deposit")){
            req.setOrderByFields("betAmountDepositRate" + (req.isOrderByAsc()? " asc" : " desc"));
        }else{
            req.setOrderByFields(req.getOrderByFields() + (req.isOrderByAsc()? " asc" : " desc"));
        }
        JSONObject param = JSONObject.parseObject(JSONObject.toJSONString(req));
        log.info("query bd-report-api： /getPlayerReportPage request:{}",JSONObject.toJSONString(req));
        JSONObject result = dbReportApiFeign.getPlayerReportPage(param);
        if(!Objects.isNull(result)){
            if(result.getBoolean("success")){
                JSONObject data = result.getJSONObject("data");
                int total = data.getInteger("total");
                List<PlayerReportRsp> reportRspList = data.getObject("rows",new TypeReference<List<PlayerReportRsp>>(){});
                page.setTotalRow(total);
                page.setData(reportRspList);
                return R.ok(page);
            }
        }
        log.warn("query bd-report-api： /getPlayerReportPage warn ,result:{}",result.toJSONString());
        return R.failed("query bd-report-api error");
    }
}
