package com.riskcontrol.office.common.enums;

import com.riskcontrol.common.entity.response.Response;
import org.apache.commons.lang3.StringUtils;

/**
 * @author dante
 */
public enum ErrorCodeEnum {

    ERROR_WS("10001", "ws service error"),
    ERROR_LOGINNAME_NOTEXIST("10002", "loginName not exist"),
    ERROR_AGENT_PARSE_ERROR("10003", "error agent parse error"),
    ERROR_WITHDRAW_FAILED("10004", "error withdraw failed"),
    ERROR_WITHDRAW_NOT_EXIST("10005", "error withdraw not exist"),
    // 当前订单状态和数据库里的不符
    ERROR_WITHDRAW_FLAG_INCORRECT("10006", "The current order status does not match the database"),
    ERROR_AGENT_ERROR("10007", "error agent error"),
    ERROR_AGENT_EXCEPTION("10008", "error agent exception"),
    // 当前订单正被其他人审核
    ERROR_WITHDRAW_REVIEW_BY_OTHER("10009", "The order has been transaction by %s, please try again later"),
    ERROR_ACCOUNT_EMPTY("10010", "error account empty"),
    ERROR_ACCOUNT_NOTEXIST("10011", "error account notexist"),
    ERROR_UPDATE_KYC_REQUEST_RISK("10012", "error update kyc request risk"),
    ERROR_UPDATE_PBC_REQUEST_RISK("10013", "error update pbc request risk"),
    ERROR_BRANCH_SECONDID_NO_EMPTY("10014", "ERROR BRANCH SECONDID NO EMPTY " ),
    ERROR_ACCESS_DENIED("10015","ERROR ACCESS DENIED"),
    ERROR_APPROVE_WITHDRAW("10016", "error approve withdraw ,The store needs to pass the first trial first."),
    REVIEWER_PASSWORD_INCORRECT("10017", "REVIEWER PASSWORD INCORRECT"),
    REVIEWER_BRANCH_NOT_MATCH("10018", "REVIEWER BRANCH NOT MATCH"),
    CREATOR_AND_APPROVER_ERROR("10019", "The reviewer and the submitter must be different"),
    PROPOSALID_NOT_EXIST("10020", "PROPOSALID NOT EXIST"),
    REVIEWER_MUST_NOT_BLANK("10021", "REVIEWER MUST NOT BLANK"),
    ERROR_VALID_KYC_ID_EXISTS("10023", "this Type card and ID number is already registered"),
    IDNO_IDTYPE_PARAM_EMPTY_ERROR("10024", "idNo or idType empty error"),
    DATE_MUST_NOT_BLANK("10025", "DATETIME MUST NOT BLANK"),;


    ;
    private String errCode;

    private String errMsg;


    ErrorCodeEnum(String errCode, String errMsg) {
        this.errCode = errCode;
        this.errMsg = errMsg;
    }

    public String getErrCode() {
        return errCode;
    }

    public String getErrMsg() {
        return errMsg;
    }


    public Response.Head getErrHead() {
        return getHead(this.name());
    }

    public Response.Head getHead(String name) {
        Response.Head x = new Response.Head();
        x.setErrCode(errCode);
        x.setErrMsg(String.format(errMsg,name));
        return x;
    }

    public static ErrorCodeEnum getErrEnumByCode(String errCode) {
        ErrorCodeEnum[] codeEnums = ErrorCodeEnum.values();
        for (ErrorCodeEnum codeEnum : codeEnums) {
            if (StringUtils.equals(codeEnum.getErrCode(), errCode)) {
                return codeEnum;
            }
        }
        return null;
    }
}
