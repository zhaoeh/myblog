package com.riskcontrol.office.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.riskcontrol.office.domain.entity.TLabelRuleRelationship;
import com.riskcontrol.office.domain.vo.TLabelRuleRelationshipVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Map;

@Mapper
public interface TLabelRuleRelationshipMapper extends BaseMapper<TLabelRuleRelationship> {
    Page<TLabelRuleRelationshipVo> queryList(Page<TLabelRuleRelationshipVo> page, @Param("param") Map param);
}