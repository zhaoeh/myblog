package com.riskcontrol.office.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.riskcontrol.office.domain.entity.TRiskLabelOperation;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author Heng.zhang
 */
@Mapper
public interface RiskLabelOperationMapper extends BaseMapper<TRiskLabelOperation> {

}
