package com.riskcontrol.office.domain.req;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;

@Data
@Schema(description="修改设备指纹风控规则状态对象")
public class DeviceRiskRuleUpdateReq {
    private static final long serialVersionUID = 1L;
    
    @ApiModelProperty(required = true, value = "主键id")
    @NotNull(message = "id cannot be null")
    private BigInteger id;

    @ApiModelProperty(required = true, value = "可用状态")
    @NotBlank(message = "isEnable cannot be null")
    private Byte isEnable;

}
