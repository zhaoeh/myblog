package com.riskcontrol.office.domain.req.ekyc;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotNull;

@Data
public class EkycFileUploadRequest {

    @NotNull(message = "文件附件不能为空")
    private MultipartFile file;

    @Schema(description = "文件附件", example = "biyuanma.png")
    private String path;

    @NotNull(message = "登陆人不能为空")
    private String loginName;

}
