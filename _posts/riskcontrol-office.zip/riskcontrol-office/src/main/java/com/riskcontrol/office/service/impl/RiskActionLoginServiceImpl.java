package com.riskcontrol.office.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.core.BaseServiceImpl;
import com.riskcontrol.office.datasource.DBSourceCheck;
import com.riskcontrol.office.datasource.DataSourceType;
import com.riskcontrol.office.domain.entity.TRiskActionLogin;
import com.riskcontrol.office.domain.entity.TRiskActionRegistration;
import com.riskcontrol.office.domain.req.RiskActionLoginQueryRequest;
import com.riskcontrol.office.domain.req.RiskActionRegistrationQueryRequest;
import com.riskcontrol.office.domain.rsp.RiskActionLogInResponse;
import com.riskcontrol.office.domain.rsp.RiskActionRegistrationResponse;
import com.riskcontrol.office.mapper.RiskActionLoginMapper;
import com.riskcontrol.office.mapper.RiskActionRegistrationMapper;
import com.riskcontrol.office.service.RiskActionLoginService;
import com.riskcontrol.office.service.RiskActionRegistrationService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

/**
 * zhang heng
 */
@Slf4j
@Service
public class RiskActionLoginServiceImpl extends BaseServiceImpl<RiskActionLoginMapper, TRiskActionLogin> implements RiskActionLoginService {

    /**
     * 注册表分页查询
     * @param request
     * @return
     */
    @Override
    @DBSourceCheck(DataSourceType.SLAVE)
    public PageModel<RiskActionLogInResponse> pageLoginList(RiskActionLoginQueryRequest request){
        LambdaQueryWrapper<TRiskActionLogin> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(StringUtils.isNotBlank(request.getDeviceFingerprint()), TRiskActionLogin::getDeviceFingerprint, request.getDeviceFingerprint())
                .eq((Objects.nonNull(request.getLoginIp())), TRiskActionLogin::getLoginIp, request.getLoginIp())
                .eq((Objects.nonNull(request.getLoginName())), TRiskActionLogin::getLoginName, request.getLoginName())
                .eq((Objects.nonNull(request.getInterceptType())), TRiskActionLogin::getInterceptType, request.getInterceptType());
        Page<TRiskActionLogin> riskActionLoginPage = pageByWrapper(request, wrapper);
        if (CollUtil.isEmpty(riskActionLoginPage.getRecords())) {
            return new PageModel<>();
        }
        List<RiskActionLogInResponse> list = riskActionLoginPage.getRecords().stream().map(entity -> {
            RiskActionLogInResponse rsp = new RiskActionLogInResponse();
            BeanUtil.copyProperties(entity, rsp);
            return rsp;
        }).toList();
        PageModel<RiskActionLogInResponse> pageResult = new PageModel<>();
        pageResult.setData(list);
        pageResult.setPageNo((int) riskActionLoginPage.getCurrent());
        pageResult.setPageSize((int) riskActionLoginPage.getSize());
        pageResult.setTotalRow((int) riskActionLoginPage.getTotal());
        pageResult.setTotalPage((int) riskActionLoginPage.getPages());
        return pageResult;
    }


}
