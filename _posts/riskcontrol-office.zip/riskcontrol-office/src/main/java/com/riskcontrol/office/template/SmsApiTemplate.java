package com.riskcontrol.office.template;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.other.SendSMSResponse;
import com.riskcontrol.office.common.constants.ConstantVars;
import com.riskcontrol.office.common.enums.ErrorCodeEnum;
import com.riskcontrol.office.common.exceptions.BizException;
import com.riskcontrol.office.config.EncodeKeyConfig;
import com.riskcontrol.office.config.NacosConfig;
import com.riskcontrol.office.util.Convert;
import com.riskcontrol.office.util.sms.SmsSendUtil;
import com.ws.SmsContent;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.UncategorizedMappingException;
import org.springframework.stereotype.Component;
import org.springframework.ws.client.WebServiceIOException;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Slf4j
@Component
public class SmsApiTemplate {
    public static final String WS_RESPONSE_DELIMITER = "^";
    @Autowired
    protected EncodeKeyConfig encodeKeyConfig;

    /**
     * 发送短信
     *
     * @param productId
     * @param smsContent
     * @return
     */
    public boolean sendSMS(String productId, SmsContent smsContent) {
        try {
            String productKey = encodeKeyConfig.getSmsSystemkey(productId);
            List<SmsContent> smsList = new ArrayList<>();
            String result = "";
            String countryCode = "0063";
            smsContent.setCountryCode(countryCode);
            smsContent.setParam10(ConstantVars.ZERO);
            smsContent.setProductid(productId);
            String tenant = Optional.ofNullable(smsContent.getTenant()).orElse(NacosConfig.getTenant());
            smsContent.setTenant(tenant);
            if (StringUtils.isNotBlank(smsContent.getUseTemplateFlag())) {
                smsContent.setUseTemplateFlag(smsContent.getUseTemplateFlag());
            } else {
                smsContent.setUseTemplateFlag("0");
            }
            String key = smsContent.getLoginname() + productId + productKey + smsContent.getPhone() + smsContent.getSmstype();// 加密方法
            String enkey = Convert.md5Hex(key);
            smsContent.setKey(enkey);
            smsList.add(smsContent);

            result = SmsSendUtil.callSmsApi(smsList);

            SendSMSResponse response = new SendSMSResponse();

            if (isJson(result, SendSMSResponse.class)) {
                response = JSONObject.parseObject(result, SendSMSResponse.class);
            } else response.setResult(result);

            log.info("loginName：{}，uuid:{}", smsContent.getLoginname(), genRequestUUID());
            return "0".equals(response.getResult());
        } catch (Exception ex) {
            log.error("loginName：{}，uuid:{}", smsContent.getLoginname(), genRequestUUID(), ex);
            throw buildBizException(ex);
        }
    }

    private String genRequestUUID() {
        return UUID.randomUUID().toString().replace("-", "").toLowerCase();
    }

    /**
     * 将WS调用返回的异常封装为业务异常
     *
     * @param e WS异常，其message格式为 <b>CODE^英文描述信息^中文描述信息</b>
     * @return
     */
    private BizException buildBizException(Exception e) {
        if (e instanceof WebServiceIOException) {
            return buildConectionException();
        }
        if (e instanceof UncategorizedMappingException) {
            return buildParamsMapException();
        }
        String originErrMessage = e.getMessage();
        String errCode, message;
        if (StringUtils.contains(originErrMessage, WS_RESPONSE_DELIMITER)) {
            String[] splits = originErrMessage.split("\\" + WS_RESPONSE_DELIMITER);
            if (splits.length < 3) { //WS返回的错误信息不符合格式
                errCode = ErrorCodeEnum.ERROR_WS.getErrCode();
                message = originErrMessage;
            } else {
                errCode = ConstantVars.CODE_PREFIX_WS + splits[0];
                message = splits[1] + WS_RESPONSE_DELIMITER + splits[2]; //只返回中文描述信息
            }

        } else if (e instanceof BizException) {

            return (BizException) e;

        } else {
            errCode = ErrorCodeEnum.ERROR_WS.getErrCode();
            message = ErrorCodeEnum.ERROR_WS.getErrMsg();
        }
        return new BizException(errCode, message, e);
    }


    private BizException buildConectionException() {
        return new BizException(ErrorCodeEnum.ERROR_WS.getErrCode(), "^Server Connect Error[W]^");
    }

    private BizException buildParamsMapException() {
        return new BizException(ErrorCodeEnum.ERROR_WS.getErrCode(), "^Params Map System Error[W]^");
    }

    // Checks if Json string syntax is correct
    private boolean isJson(String content, Class respClass) {
        if (StringUtils.isBlank(content)) return true;
        try {
            JSONObject.parseObject(content, respClass);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
