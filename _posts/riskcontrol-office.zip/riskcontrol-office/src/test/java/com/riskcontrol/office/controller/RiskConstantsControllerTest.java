package com.riskcontrol.office.controller;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.common.utils.PHPDESEncrypt;
import com.riskcontrol.office.domain.req.RiskConstantReq;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.math.BigInteger;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.authentication;
import static org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers.authenticated;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2023/11/14 14:15
 */
public class RiskConstantsControllerTest extends BaseControllerTest{
    @Test
    @DisplayName("测试/risk_constants/list接口")
    void test() throws Exception {
        PHPDESEncrypt.getNewInstance("C66","01");
    }
    @Test
    @DisplayName("测试/risk_constants/list接口")
    void queryList() throws Exception {
        JSONObject object = new JSONObject();
        object.put("pKey","RISK");
        object.put("productId","C66");
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/risk_constants/list")
                        .with(authentication(authentication))
                        .content(object.toJSONString())
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data.totalRow", Matchers.greaterThanOrEqualTo(0)))
                .andReturn();
    }

    @Test
    @DisplayName("测试/risk_constants/create接口")
    void create() throws Exception {
        RiskConstantReq req = new RiskConstantReq();
        req.setPKey("test_key");
        req.setPValue("test_value");
        req.setRemarks("remarks...");
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/risk_constants/create")
                        .with(authentication(authentication))
                        .content(JSONObject.toJSONString(req))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }
    @Test
    @Rollback(false)
    @DisplayName("测试/risk_constants/update接口")
    void update() throws Exception {
        RiskConstantReq req = new RiskConstantReq();
        req.setId(BigInteger.valueOf(17L));
        req.setPKey("test_key_update");
        req.setPValue("test_update");
        req.setRemarks("remarks_update...");
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/risk_constants/update")
                        .with(authentication(authentication))
                        .content(JSONObject.toJSONString(req))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }

    @Test
    @Rollback(false)
    @DisplayName("测试/risk_constants/delete接口")
    void delete() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/risk_constants/delete/17")
                        .with(authentication(authentication))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }

    @Test
    @Rollback(false)
    @DisplayName("测试/risk_constants/disable接口")
    void disable() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/risk_constants/disable/17")
                        .with(authentication(authentication))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }

    @Test
    @Rollback(false)
    @DisplayName("测试/risk_constants/enable接口")
    void enable() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/risk_constants/enable/17")
                        .with(authentication(authentication))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }
}
