package com.riskcontrol.office.controller;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.common.entity.request.api.*;
import com.riskcontrol.office.domain.req.PbcDeployReq;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.math.BigInteger;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.authentication;
import static org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers.authenticated;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/03/15 14:15
 */
public class PbcDeployControllerTest extends BaseControllerTest{

    @Test
    @DisplayName("测试deploy接口")
    void deploy() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/office/pbc/deploy")
                        .with(authentication(authentication))
                        .content(new JSONObject().toJSONString())
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data.totalRow", Matchers.greaterThanOrEqualTo(0)))
                .andReturn();
    }

    @Test
    @DisplayName("测试updateDeploy接口")
    void updateDeploy() throws Exception {
        PbcDeployReq req = new PbcDeployReq();
        req.setId(BigInteger.valueOf(1));
        req.setSystemId("PBC");
        req.setPassword("test_password");
        req.setUserName("test_name");
        req.setStartTime("00:00:00");
        req.setEndTime("23:59:59");
        req.setFrequency(30);
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/office/pbc/updateDeploy")
                        .with(authentication(authentication))
                        .content(JSONObject.toJSONString(req))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.equalTo(true)))
                .andReturn();
    }

    @Test
    @DisplayName("测试deleteDeploy接口")
    void deleteDeploy() throws Exception {
        PbcDeployReq req = new PbcDeployReq();
        req.setId(BigInteger.valueOf(1));
        req.setSystemId("PBC");
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/office/pbc/deleteDeploy")
                        .with(authentication(authentication))
                        .content(JSONObject.toJSONString(req))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.notNullValue()))
                .andReturn();
    }
}
