package com.riskcontrol.office.utils;

import java.util.HashSet;
import java.util.Set;

/**
 * @author martin
 */
public class AuthorityUtils {
    public final static Set<String> permissions = new HashSet<>();

    static {
        permissions.add("system_constants_create");
    }
}
