package com.riskcontrol.office.controller;

import com.alibaba.fastjson.JSONObject;
import com.intech.dbcryptor.Cryptor;
import com.riskcontrol.office.domain.req.SysConstantReq;
import com.zaxxer.hikari.HikariConfig;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import javax.annotation.Resource;

import java.math.BigInteger;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.authentication;
import static org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers.authenticated;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2023/11/14 14:15
 */
public class SysConstantsControllerTest extends BaseControllerTest{
    @Test
    @DisplayName("测试/sys_constants/list接口")
    void queryList() throws Exception {
        String username=Cryptor.encryptContent("DyjU,{lariNZmwmLaiwbIrkDSHELzo5yO,AvTqyf2AlJ");
        String password=Cryptor.encryptContent("qsJB5M:2f(`Yy(A:Wu@;smFQwSQeiBE(IRNPfVWlSBJJ");
        System.out.println("===================username:"+username+"||password:"+password);
//        JSONObject object = new JSONObject();
//        object.put("sKey","RISK");
//        object.put("productId","C66");
//        mockMvc.perform(MockMvcRequestBuilders
//                        .post("/sys_constants/list")
//                        .with(authentication(authentication))
//                        .content(object.toJSONString())
//                        .accept(MediaType.APPLICATION_JSON)
//                        .contentType(MediaType.APPLICATION_JSON_VALUE)
//                )
//                .andExpect(MockMvcResultMatchers.status().isOk())
//                .andExpect(authenticated().withAuthentication(authentication))
//                .andDo(MockMvcResultHandlers.print())
//                .andExpect(MockMvcResultMatchers.jsonPath( "data.totalRow", Matchers.greaterThanOrEqualTo(0)))
//                .andReturn();
    }

    @Test
    @Rollback(false)
    @DisplayName("测试/sys_constants/create接口")
    void create() throws Exception {
        SysConstantReq req = new SysConstantReq();
        req.setProductId("C66");
        req.setSType("PARENT_ACCOUNT");
        req.setSKey("C66_PARENT_ACCOUNT_2");
        req.setSValue("2");
        req.setRemarks("remarks...");
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/sys_constants/create")
                        .with(authentication(authentication))
                        .content(JSONObject.toJSONString(req))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }
    @Test
    @Rollback(false)
    @DisplayName("测试/sys_constants/update接口")
    void update() throws Exception {
        SysConstantReq req = new SysConstantReq();
        req.setId(BigInteger.valueOf(1));
        req.setSType("test_type_update");
        req.setSKey("test_key_update");
        req.setSValue("test_update");
        req.setRemarks("remarks_update...");
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/sys_constants/update")
                        .with(authentication(authentication))
                        .content(JSONObject.toJSONString(req))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }

    @Test
    @Rollback(false)
    @DisplayName("测试/sys_constants/delete接口")
    void delete() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/sys_constants/delete/1")
                        .with(authentication(authentication))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }

    @Test
    @Rollback(false)
    @DisplayName("测试/sys_constants/disable接口")
    void disable() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/sys_constants/disable/1")
                        .with(authentication(authentication))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }

    @Test
    @Rollback(false)
    @DisplayName("测试/sys_constants/enable接口")
    void enable() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/sys_constants/enable/1")
                        .with(authentication(authentication))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }
}
