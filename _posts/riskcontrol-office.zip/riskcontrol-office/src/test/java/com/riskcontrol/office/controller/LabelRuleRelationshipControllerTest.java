package com.riskcontrol.office.controller;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.common.enums.RuleEnum;
import com.riskcontrol.office.domain.req.LabelRuleEditReq;
import com.riskcontrol.office.domain.req.LabelRuleQueryReq;
import com.riskcontrol.office.domain.req.RiskConstantReq;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.math.BigInteger;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.authentication;
import static org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers.authenticated;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2023/11/14 14:15
 */
public class LabelRuleRelationshipControllerTest extends BaseControllerTest{

    @Test
    @DisplayName("测试/labelRule/list接口")
    void queryLabelRuleList() throws Exception {
        LabelRuleQueryReq req = new LabelRuleQueryReq();
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/labelRule/list")
                        .with(authentication(authentication))
                        .content(JSONObject.toJSONString(req))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data.totalRow", Matchers.greaterThanOrEqualTo(0)))
                .andReturn();
    }

    @Test
    @DisplayName("测试/labelRule/create接口")
    void create() throws Exception {
        LabelRuleEditReq req = new LabelRuleEditReq();
        req.setLabelId(BigInteger.valueOf(3));
        req.setRuleAction(RuleEnum.TRANSFERRED_TO_MANUAL_REVIEW.getRuleAction());
        req.setRemark("remarks...");
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/labelRule/create")
                        .with(authentication(authentication))
                        .content(JSONObject.toJSONString(req))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }
    @Test
    @Rollback(false)
    @DisplayName("测试/risk_constants/update接口")
    void update() throws Exception {
        LabelRuleEditReq req = new LabelRuleEditReq();
        req.setId(BigInteger.valueOf(1));
        req.setLabelId(BigInteger.valueOf(2));
        req.setRuleAction(RuleEnum.TRANSFERRED_TO_MANUAL_REVIEW.getRuleAction());
        req.setRemark("remarks.sds..");
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/labelRule/update")
                        .with(authentication(authentication))
                        .content(JSONObject.toJSONString(req))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }

    @Test
    @Rollback(false)
    @DisplayName("测试/labelRule/delete接口")
    void delete() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/labelRule/delete/1")
                        .with(authentication(authentication))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }

    @Test
    @Rollback(false)
    @DisplayName("测试/risk_constants/disable接口")
    void disable() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/labelRule/disable/1")
                        .with(authentication(authentication))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }

    @Test
    @Rollback(false)
    @DisplayName("测试/risk_constants/enable接口")
    void enable() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/labelRule/enable/1")
                        .with(authentication(authentication))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(authenticated().withAuthentication(authentication))
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "data", Matchers.is(true)))
                .andReturn();
    }
}
