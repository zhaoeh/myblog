package com.riskcontrol.office.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.req.ekyc.EkycQueryRequest;
import com.riskcontrol.office.domain.req.ekyc.EkycRequestQueryRequest;
import com.riskcontrol.office.domain.rsp.ekyc.EkycQueryResponse;
import com.riskcontrol.office.domain.rsp.ekyc.EkycRequestInfoResponse;
import com.riskcontrol.office.domain.rsp.ekyc.EkycRequestQueryResponse;
import org.apache.hc.core5.net.URIBuilder;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.test.annotation.DirtiesContext;

import java.math.BigInteger;
import java.net.URISyntaxException;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DirtiesContext
public class EkycControllerTest {

    @Autowired
    private TestRestTemplate testRestTemplate;

    @Test
    void pageEkycList() throws URISyntaxException, JsonProcessingException {
        var url = new URIBuilder("/office/ekyc/queryList").build();
        var body = new EkycQueryRequest();
        body.setPageNum(1);
        body.setPageSize(10);
        body.setStatus(List.of(1));
        var response = this.testRestTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(body), new ParameterizedTypeReference<R<PageModel<EkycQueryResponse>>>() {
        });
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(0, response.getBody().getCode());
        assertEquals(1, response.getBody().getData().getPageNo());
        assertEquals(10, response.getBody().getData().getPageSize());
        assertTrue(response.getBody().getData().getData().size() > 0);
        var result = response.getBody().getData().getData().get(0);
        assertNotNull(result.getId());
    }

    @Test
    void pageEkycRequestList() throws URISyntaxException, JsonProcessingException {
        var url = new URIBuilder("/office/ekycRequest/queryList").build();
        var body = new EkycRequestQueryRequest();
        body.setPageNum(1);
        body.setPageSize(10);
        body.setStatus(List.of(1));
        var response = this.testRestTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(body), new ParameterizedTypeReference<R<PageModel<EkycRequestQueryResponse>>>() {
        });
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(0, response.getBody().getCode());
        assertEquals(1, response.getBody().getData().getPageNo());
        assertEquals(10, response.getBody().getData().getPageSize());
        assertTrue(response.getBody().getData().getData().size() > 0);
        var result = response.getBody().getData().getData().get(0);
        assertNotNull(result.getId());
    }

    @Test
    void queryRiskLabel() throws URISyntaxException, JsonProcessingException {
        // 获取一条数据的id
        BigInteger id;
        {
            var url = new URIBuilder("/office/ekycRequest/queryList").build();
            var body = new EkycRequestQueryRequest();
            body.setPageNum(1);
            body.setPageSize(10);
            body.setStatus(List.of(1));
            var response = this.testRestTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(body), new ParameterizedTypeReference<R<PageModel<EkycRequestQueryResponse>>>() {
            });
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(0, response.getBody().getCode());
            assertEquals(1, response.getBody().getData().getPageNo());
            assertEquals(10, response.getBody().getData().getPageSize());
            assertTrue(response.getBody().getData().getData().size() > 0);
            var result = response.getBody().getData().getData().get(0);
            assertNotNull(result.getId());
            id = result.getId();
        }
        // 获取详情
        {
            var url = new URIBuilder("/office/ekycRequest/detail").appendPathSegments(String.valueOf(id)).build();
            var response = this.testRestTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(null), new ParameterizedTypeReference<R<EkycRequestInfoResponse>>() {
            });
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(0, response.getBody().getCode());
            var result = response.getBody().getData();
            assertNotNull(result.getId());
        }
    }

}
