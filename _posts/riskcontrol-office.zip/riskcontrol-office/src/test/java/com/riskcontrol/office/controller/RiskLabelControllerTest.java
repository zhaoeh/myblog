package com.riskcontrol.office.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.office.common.R;
import com.riskcontrol.office.domain.entity.TRiskLabelOperationLog;
import com.riskcontrol.office.domain.req.RiskLabelOperationDetailPageRequest;
import com.riskcontrol.office.domain.req.RiskLabelOperationPageRequest;
import com.riskcontrol.office.domain.rsp.RiskLabelOperationDetailPageRsp;
import com.riskcontrol.office.mapper.TPbcCrawlerResultNewMapper;
import org.apache.hc.core5.net.URIBuilder;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.test.annotation.DirtiesContext;
import javax.annotation.Resource;
import java.math.BigInteger;
import java.net.URISyntaxException;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DirtiesContext
public class RiskLabelControllerTest {

    @Autowired
    private TestRestTemplate testRestTemplate;

    @Resource
    private TPbcCrawlerResultNewMapper pbcCrawlerResultNewMapper;

    @Test
    void getOperationList() throws URISyntaxException, JsonProcessingException {
        var url = new URIBuilder("/office/riskLabel/getOperationList").build();
        var body = new RiskLabelOperationPageRequest();
        body.setPageNum(1);
        body.setPageSize(10);
        var response = this.testRestTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(body), new ParameterizedTypeReference<R<PageModel<TRiskLabelOperationLog>>>() {
        });
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(0, response.getBody().getCode());
        assertEquals(1, response.getBody().getData().getPageNo());
        assertEquals(10, response.getBody().getData().getPageSize());
        assertTrue(response.getBody().getData().getData().size() > 0);
        var result = response.getBody().getData().getData().get(0);
        assertNotNull(result.getId());
    }

    @Test
    void getOperationDetailList() throws URISyntaxException, JsonProcessingException {
        // 获取id
        BigInteger id;
        {
            var url = new URIBuilder("/office/riskLabel/getOperationList").build();
            var body = new RiskLabelOperationPageRequest();
            body.setPageNum(1);
            body.setPageSize(10);
            var response = this.testRestTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(body), new ParameterizedTypeReference<R<PageModel<TRiskLabelOperationLog>>>() {
            });
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(0, response.getBody().getCode());
            assertEquals(1, response.getBody().getData().getPageNo());
            assertEquals(10, response.getBody().getData().getPageSize());
            assertTrue(response.getBody().getData().getData().size() > 0);
            var result = response.getBody().getData().getData().get(0);
            assertNotNull(result.getId());
            id = result.getId();
        }

        var url = new URIBuilder("/office/riskLabel/getOperationDetailList").build();
        var body = new RiskLabelOperationDetailPageRequest();
        body.setPageNum(1);
        body.setPageSize(10);
        body.setId(id);
        var response = this.testRestTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(body), new ParameterizedTypeReference<R<PageModel<RiskLabelOperationDetailPageRsp>>>() {
        });
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(0, response.getBody().getCode());
        assertEquals(1, response.getBody().getData().getPageNo());
        assertEquals(10, response.getBody().getData().getPageSize());
        assertTrue(response.getBody().getData().getData().size() > 0);
        var result = response.getBody().getData().getData().get(0);
        assertNotNull(result.getId());
    }

}

