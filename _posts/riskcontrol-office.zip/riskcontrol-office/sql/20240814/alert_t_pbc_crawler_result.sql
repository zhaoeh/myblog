-- 删除重复数据
delete from t_pbc_crawler_result r
where r.id in (
    select id from
        (select id from t_pbc_crawler_result t,(select max(id) as max_id,source_id from t_pbc_crawler_result
                                                group by source_id
                                                HAVING count(source_id) > 1) t1
         where t.source_id = t1.source_id
           and t.id not in (t1.max_id)) tmp
);
-- 执行增加索引
ALTER TABLE `t_pbc_crawler_result`
    ADD UNIQUE INDEX `uk_source_id`(`source_id`) COMMENT 'kyc_id';