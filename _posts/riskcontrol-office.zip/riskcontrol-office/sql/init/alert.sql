ALTER TABLE `t_risk_constants`
    ADD COLUMN `priority` tinyint UNSIGNED NOT NULL COMMENT '优先级',
DROP INDEX `idx_product_id_p_type`,
ADD  UNIQUE KEY `uk_key`(`p_key`);


ALTER TABLE `t_risk_label_relationship`
    ADD INDEX `idx_customer_id` (`customer_id`),
    ADD INDEX `idx_label_id` (`risk_label_id`);


ALTER TABLE t_kyc_request_process_log
    MODIFY COLUMN remark VARCHAR(500);
