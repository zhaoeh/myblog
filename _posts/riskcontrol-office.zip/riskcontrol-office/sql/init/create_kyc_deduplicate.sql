CREATE TABLE `t_kyc_deduplicate` (
                                     `id` bigint unsigned NOT NULL AUTO_INCREMENT,
                                     `id_type` tinyint unsigned NOT NULL COMMENT '证件类型',
                                     `id_no` varchar(64) NOT NULL COMMENT '证件号码',
                                     PRIMARY KEY (`id`),
                                     UNIQUE KEY `uk_type_no` (`id_type`,`id_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4  COMMENT='kyc证件去重表';