ALTER TABLE `t_kyc_request`
    ADD COLUMN `auto_pbc` tinyint DEFAULT 0 COMMENT '是否系统处理pbc（0:否；1是）';
ALTER TABLE `t_operation_log`
    MODIFY COLUMN `op_by` varchar(128) NULL DEFAULT '' COMMENT '操作人';
ALTER TABLE `t_kyc_request`
    MODIFY COLUMN `created_by` varchar(128) DEFAULT NULL COMMENT '创建人',
    MODIFY COLUMN `update_by` varchar(128)  DEFAULT NULL COMMENT '更新人',
    MODIFY COLUMN `approved_by` varchar(128) DEFAULT NULL COMMENT '审核人' ,
    MODIFY COLUMN `pbc_approved_by` varchar(128)  DEFAULT NULL COMMENT 'pbc审核人' ;

ALTER TABLE `t_message_record`
    MODIFY COLUMN `create_by` varchar(128) DEFAULT NULL COMMENT '创建人',
    MODIFY COLUMN `update_by` varchar(128) DEFAULT NULL COMMENT '更新人';

ALTER TABLE `t_phone_number_blacklist`
    MODIFY COLUMN `create_by` varchar(128) DEFAULT NULL COMMENT '创建人',
    MODIFY COLUMN `data_modifier` varchar(128) DEFAULT NULL COMMENT '最后一次最后修改的account';
ALTER TABLE `t_risk_constants`
    MODIFY COLUMN `create_by` varchar(128) DEFAULT NULL COMMENT '创建人',
    MODIFY COLUMN `update_by` varchar(128) DEFAULT NULL COMMENT '最后修改人';
ALTER TABLE `t_risk_label_change_record`
    MODIFY COLUMN `create_by` varchar(128) DEFAULT NULL COMMENT '创建人';

ALTER TABLE `t_risk_label_relationship`
    MODIFY COLUMN `create_by` varchar(128) DEFAULT NULL COMMENT '创建人' ,
    MODIFY COLUMN `update_by` varchar(128) DEFAULT NULL COMMENT '最后修改人';

ALTER TABLE `t_sys_constants`
    MODIFY COLUMN `create_by` varchar(128) DEFAULT NULL COMMENT '创建人',
    MODIFY COLUMN `update_by` varchar(128) DEFAULT NULL COMMENT '最后修改人';

INSERT INTO `t_sys_constants` (`product_id`, `s_key`, `s_value`, `s_type`, `remarks`, `is_enable`, `is_deleted`, `create_by`, `create_time`, `update_by`, `update_time`) VALUES ('C66', 'jms-withdraw-risk-retry-mq', '1', 'r-0014', '风控重审队列（0:kafka；1:rabbitmq）', 1, 0, NULL, '2024-07-01 10:09:05', NULL, '2024-08-16 11:37:54');
