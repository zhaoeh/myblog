CREATE TABLE `t_risk_label_operation_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `operator` varchar(128) NOT NULL DEFAULT '' COMMENT '操作人',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态 0:执行中 1:执行完成 2:执行失败',
  `op_mode` tinyint(1) NOT NULL DEFAULT '0' COMMENT '操作类型 0:导入模式 1:手动更新',
  `total_no` int NOT NULL DEFAULT '0' COMMENT '操作的账号量',
  `success_no` int NOT NULL DEFAULT '0' COMMENT '成功数量',
  `failure_no` int NOT NULL DEFAULT '0' COMMENT '失败数量',
  `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `finish_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '完成时间',
  `remark` varchar(200) NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `idx_create_date` (`create_date`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COMMENT='风控用户标签历史操作记录表';


ALTER TABLE t_risk_label_change_record ADD operation_status tinyint(1) NOT NULL DEFAULT 1 COMMENT '账户匹配状态 1：合法 0：非法';
ALTER TABLE t_risk_label_change_record ADD log_id varchar(50) NOT NULL DEFAULT '' COMMENT '日志主表id';

ALTER TABLE `t_risk_label_relationship`
DROP INDEX `idx_label_id`,
ADD INDEX `idx_labelId_loginName`(`risk_label_id`, `login_name`) USING BTREE;


--调整表字段为非空，优化空值字段
update t_risk_constants set p_type = '0101' where p_type ='' or p_type is null;
update t_risk_constants set p_key = '' where p_key is null;
update t_risk_constants set p_value = '' where p_value is null;

ALTER TABLE `t_risk_constants`
    MODIFY COLUMN `p_key` varchar(30) NOT NULL DEFAULT '' COMMENT '常量key',
    MODIFY COLUMN `p_value` varchar(255) NOT NULL DEFAULT '' COMMENT '常量值' ,
    MODIFY COLUMN `p_type` varchar(255)  NOT NULL DEFAULT '' COMMENT '常量type';

