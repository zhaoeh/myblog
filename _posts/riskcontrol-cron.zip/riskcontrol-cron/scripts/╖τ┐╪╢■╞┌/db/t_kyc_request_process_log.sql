-- risk_control_cron.t_kyc_request_process_log definition

CREATE TABLE `t_kyc_request_process_log`
(
    `id`             bigint NOT NULL AUTO_INCREMENT,
    `kyc_request_id` varchar(100)  DEFAULT NULL,
    `dispatch_by`    varchar(100)  DEFAULT NULL,
    `create_time`    datetime                                                         DEFAULT NULL,
    `remark`         varchar(100)  DEFAULT NULL,
    `type`           varchar(100)  DEFAULT NULL,
    `last_stauts`    bigint                                                           DEFAULT NULL,
    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE KEY `T_KYC_REQUEST_PROCESS_LOG_PK` (`id`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4  COMMENT='kyc日志记录';