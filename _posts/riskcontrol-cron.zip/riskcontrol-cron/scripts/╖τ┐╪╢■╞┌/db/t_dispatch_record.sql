-- risk_control_cron.t_dispatch_record definition

CREATE TABLE `t_dispatch_record` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `user_login_name` varchar(20)  NOT NULL COMMENT '接受派单后台风控账号',
    `assignee_time` datetime NOT NULL COMMENT '订单分配时间',
    `order_style` varchar(20)  NOT NULL COMMENT '订单类型 KYC, Withdraw',
    `serial_number` varchar(20)  NOT NULL COMMENT '订单id 如果是KYC 则是KYC RequestId, Withdraw 类型T_WITHDRAWAL_REQUESTS REQUEST_ID',
    `created_date` datetime NOT NULL,
    `updated_date` datetime DEFAULT NULL,
    `customer_id` bigint DEFAULT NULL,
    `status` bigint DEFAULT NULL COMMENT '派单状态,0 已派单，1以接单',
    PRIMARY KEY (`id`),
    CONSTRAINT `SYS_C0051239` CHECK ((`user_login_name` is not null)),
    CONSTRAINT `SYS_C0051240` CHECK ((`assignee_time` is not null)),
    CONSTRAINT `SYS_C0051241` CHECK ((`order_style` is not null)),
    CONSTRAINT `SYS_C0051242` CHECK ((`serial_number` is not null)),
    CONSTRAINT `SYS_C0051243` CHECK ((`created_date` is not null))
) ENGINE=InnoDB AUTO_INCREMENT=6935 DEFAULT CHARSET=utf8mb4  COMMENT='派单记录表';