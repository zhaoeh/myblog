-- risk_control_cron.t_error definition

CREATE TABLE `t_error` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `product_id` varchar(5)  DEFAULT NULL,
    `error_code` varchar(10)  DEFAULT NULL,
    `class_name` varchar(200)  DEFAULT NULL,
    `message_en` varchar(400)  DEFAULT NULL COMMENT '英文消息',
    `message_cn` varchar(400)  DEFAULT NULL COMMENT '中文消息',
    `solution` varchar(200)  DEFAULT NULL,
    `remark` varchar(200)  DEFAULT NULL COMMENT '备注信息',
    `message_th` varchar(400)  DEFAULT NULL COMMENT '泰国语消息',
    `message_vi` varchar(400)  DEFAULT NULL COMMENT '越南语消息',
    `message_ja` varchar(400)  DEFAULT NULL COMMENT '日本语消息',
    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE KEY `BIN$pguZK0mQbqfgU1BIQgp1rw==$0` (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4  COMMENT='Error信息表';


ALTER TABLE t_error MODIFY COLUMN id bigint auto_increment NOT NULL COMMENT '主键';
ALTER TABLE t_error MODIFY COLUMN product_id varchar(5)  NULL COMMENT '产品ID';
ALTER TABLE t_error MODIFY COLUMN error_code varchar(10)  NULL COMMENT '错误码';
ALTER TABLE t_error MODIFY COLUMN class_name varchar(200)  NULL COMMENT '错误码对应类名';
ALTER TABLE t_error MODIFY COLUMN solution varchar(200)  NULL COMMENT '解决方案';
ALTER TABLE t_error MODIFY COLUMN message_th varchar(400)  NULL COMMENT '错误码泰文描述';
ALTER TABLE t_error MODIFY COLUMN message_vi varchar(400)  NULL COMMENT '错误码越南语描述';
