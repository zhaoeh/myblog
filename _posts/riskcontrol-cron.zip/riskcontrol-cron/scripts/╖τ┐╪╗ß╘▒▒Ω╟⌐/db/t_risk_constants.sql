-- risk_control_cron.t_risk_constants definition

-- 创建风控字典表
CREATE TABLE `t_risk_constants` (
      `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
      `product_id` varchar(64) DEFAULT NULL COMMENT '所属产品',
      `p_key` varchar(30) DEFAULT NULL COMMENT '常量key',
      `p_value` varchar(255) DEFAULT NULL COMMENT '常量值',
      `p_type` varchar(20) DEFAULT NULL COMMENT '类型',
      `remarks` varchar(255) DEFAULT NULL COMMENT '描述',
      `ip_address` varchar(100) DEFAULT NULL COMMENT 'ip地址',
      `is_enable` tinyint NOT NULL DEFAULT '0' COMMENT '标志:0-未启用；1-已启用',
      `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '是否删除：0-否 ；1-是',
      `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
      `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      `update_by` varchar(64) DEFAULT NULL COMMENT '最后修改人',
      `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
      PRIMARY KEY (`id`),
      KEY `idx_p_type_p_key` (`p_type`,`p_key`) USING BTREE,
      KEY `idx_product_id_p_type` (`product_id`,`p_type`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4  COMMENT='风控常量表';


-- 初始化风控字典表数据
INSERT INTO t_risk_constants(product_id, p_key, p_value, p_type, remarks, ip_address, is_enable, is_deleted, create_by, create_time, update_by) VALUES('C66', 'RISK_WHITE_LIST', 'Whitelist', '0101', '用户标签-白名单','127.0.0.1' ,1,0,'system', now(), NULL);
INSERT INTO t_risk_constants(product_id, p_key, p_value, p_type, remarks, ip_address, is_enable, is_deleted, create_by, create_time, update_by) VALUES('C66', 'RISK_REGULAR', 'Regular', '0101', '用户标签-普通用户', '127.0.0.1',1,0, 'system', now(), NULL);
INSERT INTO t_risk_constants(product_id, p_key, p_value, p_type, remarks, ip_address, is_enable, is_deleted, create_by, create_time, update_by) VALUES('C66', 'RISK_FOCUS', 'Focus', '0101', '用户标签-关注', '127.0.0.1',1,0, 'system', now(), NULL);
INSERT INTO t_risk_constants(product_id, p_key, p_value, p_type, remarks, ip_address, is_enable, is_deleted, create_by, create_time, update_by) VALUES('C66', 'RISK_ARBITRAGE_USERS', 'Arbitrage Users', '0101', '用户标签-套利客', '127.0.0.1',1,0, 'system', now(), NULL);
INSERT INTO t_risk_constants(product_id, p_key, p_value, p_type, remarks, ip_address, is_enable, is_deleted, create_by, create_time, update_by) VALUES('C66', 'RISK_BLACKLIST', 'Blacklist', '0101', '用户标签-黑名单', '127.0.0.1',1,0, 'system', now(), NULL);
INSERT INTO t_risk_constants(product_id, p_key, p_value, p_type, remarks, ip_address, is_enable, is_deleted, create_by, create_time, update_by) VALUES('C66', 'RISK_SUSPECTED_ARBITRAGE_USER', 'Suspected Arbitrage User', '0101', '用户标签-疑似套利', '127.0.0.1',1,0, 'system', now(), NULL);
INSERT INTO t_risk_constants(product_id, p_key, p_value, p_type, remarks, ip_address, is_enable, is_deleted, create_by, create_time, update_by) VALUES('C66', 'RISK_TEST', 'Test', '0101', '用户标签-测试', '127.0.0.1',1,0, 'system', now(), NULL);
