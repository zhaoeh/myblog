-- risk_control_cron.t_risk_label_relationship definition

-- 创建标签历史变更表
CREATE TABLE `t_risk_label_change_record` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `product_id` varchar(3) DEFAULT NULL COMMENT '所属产品',
    `customer_id` bigint NOT NULL COMMENT '用户ID',
    `login_name` varchar(30) DEFAULT NULL COMMENT '用户登录名',
    `new_risk_label_id` varchar(200) DEFAULT NULL COMMENT '新风控标签ID，多个逗号隔开',
    `new_risk_label_name` varchar(200) DEFAULT NULL COMMENT '新风控标签名称，多个逗号隔开',
    `old_risk_label_id` varchar(200) DEFAULT NULL COMMENT '旧风控标签ID，多个逗号隔开',
    `old_risk_label_name` varchar(200) DEFAULT NULL COMMENT '旧风控标签名称，多个逗号隔开',
    `remark` varchar(150) DEFAULT NULL COMMENT '备注',
    `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
    `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4  COMMENT='用户标签变更记录';

