create table t_phone_number_blacklist
(
    id bigint unsigned auto_increment comment '主键'
        primary key,
    history varchar(500) not null comment '所有历史绑定的用户ID，逗号分隔，按照时间顺序增加',
    product_id varchar(10) null comment '所属产品',
    phone varchar(400) null comment '手机号码',
    phone_md5 varchar(400) not null comment '手机号码md5',
    status tinyint default 1 not null comment '状态：0-失效，1-生效中',
    remarks varchar(500) null comment '备注',
    create_by varchar(64) null comment '创建人',
    create_time datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    data_modifier varchar(64) null comment '最后一次最后修改的account',
    last_update_time datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '最后修改时间',
    constraint uk_phone_md5
        unique (phone_md5)
)
    comment '手机号黑名单';

