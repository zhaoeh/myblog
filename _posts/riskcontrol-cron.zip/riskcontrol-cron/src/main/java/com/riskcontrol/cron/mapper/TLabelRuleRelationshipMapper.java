package com.riskcontrol.cron.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.entity.TLabelRuleRelationship;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.cache.annotation.Cacheable;

import java.util.List;

@Mapper
public interface TLabelRuleRelationshipMapper extends BaseMapper<TLabelRuleRelationship> {

    //根据标签key获取绑定且启用的规则
    @Cacheable(cacheNames = CronConstant.LABEL_RULE_KEY, key = "#labelKey")//默认2小时过期
    List<String> selectRuleByLabel(String labelKey);

}