package com.riskcontrol.cron.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.pojo.TRiskActionLogin;
import com.riskcontrol.common.entity.request.device.LoginCheckRequest;
import com.riskcontrol.common.entity.response.device.LoginCheckResponse;
import com.riskcontrol.common.enums.RiskActionTypeEnum;

public interface TRiskActionLoginService extends IService<TRiskActionLogin> {

    /**
     * 登陆风控检查
     */
    LoginCheckResponse loginCheck(LoginCheckRequest loginCheckRequest);

    /**
     * 手机号黑名单检查
     */
    boolean isPhoneBlack(String phoneNumber);

    /**
     * 设备指纹黑名单
     */
    boolean isDeviceBlack(String deviceFingerprint, String ipAddress, String loginName, String tenant, RiskActionTypeEnum ruleAction);

    /**
     * ip黑名单检查
     */
    boolean isIpBlack(String deviceFingerprint, String ipAddress, String loginName, String tenant, RiskActionTypeEnum ruleAction);

    /**
     * 设备指纹和ip的组合黑名单
     *
     * @param deviceFingerprint
     * @return
     */
    boolean isDeviceAndIpBlack(String deviceFingerprint, String ipAddress, String loginName, String tenant, RiskActionTypeEnum ruleAction);

    /**
     * 用户黑名单检查
     */
    boolean isUserBlack(String loginName);

    /**
     * 保存登陆风控明细
     */
    void saveRiskActionLogin(LoginCheckRequest loginCheckRequest, int interceptType);
}
