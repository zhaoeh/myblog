package com.riskcontrol.cron.utils;


import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

@Component
public class DateUtil {
    public static final SimpleDateFormat sdf = new SimpleDateFormat();

    /**
     * @param date
     * @return String
     */
    public static synchronized String getDateSecondFormat(Date date) {
        String pattern = "yyyy-MM-dd HH:mm:ss";
        return getDateFormat(date, pattern);
    }

    public static synchronized String getDateW3CFormat(Date date) {
        String pattern = "yyyy-MM-dd HH:mm:ss";
        return getDateFormat(date, pattern);
    }

    /**
     * @param date
     * @param pattern
     * @return String
     */
    public static synchronized String getDateFormat(Date date,
                                                    String pattern) {
        synchronized (sdf) {
            String str = null;
            sdf.applyPattern(pattern);
            str = sdf.format(date);
            return str;
        }
    }


    /**
     * 将日期对象转换成为指定日期、时间格式的字符串形式。如果日期对象为空，返回 一个空字符串对象，而不是一个空对象。
     *
     * @param theDate 将要转换为字符串的日期对象。
     * @param hasTime 如果返回的字符串带时间则为true
     * @return 转换的结果
     */
    public static synchronized String toString(Date theDate, boolean hasTime) {
        /**
         * 详细设计： 1.如果有时间，则设置格式为getDateTimeFormat的返回值 2.否则设置格式为getDateFormat的返回值
         * 3.调用toString(Date theDate, DateFormat theDateFormat)
         */
        DateFormat theFormat;
        if (hasTime) {
            theFormat = getDateTimeFormat();
        } else {
            theFormat = getDateFormat();
        }
        return toString(theDate, theFormat);
    }

    /**
     * 标准日期格式
     */
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy");
    /**
     * 标准时间格式
     */
    private static final SimpleDateFormat DATE_TIME_FORMAT = new SimpleDateFormat("MM/dd/yyyy HH:mm");

    private static final DateTimeFormatter DATE_TIME_FORMAT_BAK = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");


    /**
     * 创建一个标准日期格式的克隆
     *
     * @return 标准日期格式的克隆
     */
    public static synchronized DateFormat getDateFormat() {
        /**
         * 详细设计： 1.返回DATE_FORMAT
         */
        SimpleDateFormat theDateFormat = (SimpleDateFormat) DATE_FORMAT.clone();
        theDateFormat.setLenient(false);
        return theDateFormat;
    }

    /**
     * 创建一个标准时间格式的克隆
     *
     * @return 标准时间格式的克隆
     */
    public static synchronized DateFormat getDateTimeFormat() {
        /**
         * 详细设计： 1.返回DATE_TIME_FORMAT
         */
        SimpleDateFormat theDateTimeFormat = (SimpleDateFormat) DATE_TIME_FORMAT.clone();
        theDateTimeFormat.setLenient(false);
        return theDateTimeFormat;
    }


    /**
     * 将一个日期对象转换成为指定日期、时间格式的字符串。 如果日期对象为空，返回一个空字符串，而不是一个空对象。
     *
     * @param theDate       要转换的日期对象
     * @param theDateFormat 返回的日期字符串的格式
     * @return 转换结果
     */
    public static synchronized String toString(Date theDate, DateFormat theDateFormat) {
        /**
         * 详细设计： 1.theDate为空，则返回"" 2.否则使用theDateFormat格式化
         */
        if (theDate == null) {
            return "";
        }
        return theDateFormat.format(theDate);
    }

    public static synchronized Date parseDateFormat(String strDate,
                                                    String pattern) {
        synchronized (sdf) {
            Date date = null;
            sdf.applyPattern(pattern);
            try {
                date = sdf.parse(strDate);
            } catch (Exception e) {
            }
            return date;
        }
    }

    public static final String FMT_YYYY_MM_DD = "yyyy-MM-dd";
    public static final String FMT_YYYY_MM = "yyyy-MM";

    /**
     * Retrieves the system time of the machine (no offset)
     */
    public static synchronized int between4StringDate(String before, String after) {
        Date bef = parseDateFormat(before, FMT_YYYY_MM_DD);
        Date aft = parseDateFormat(after, FMT_YYYY_MM_DD);

        long between = (aft.getTime() - bef.getTime()) / 1000 / 60 / 60 / 24;
        return (int) Math.abs(between);
    }

    public static final Timestamp now() {
        return toTimestamp(nowCalendar(), 0);
    }

    public static final Calendar nowCalendar() {
        return Calendar.getInstance();
    }

    public static final Timestamp toTimestamp(Calendar calendar, long millisecondsInAnHour) {
        return new Timestamp(calendar.getTimeInMillis() + TIMEZONE_OFFSET * millisecondsInAnHour);
    }

    public static final Integer TIMEZONE_OFFSET = 0;

    public static final String format(Object date, String pattern) {
        if (date == null) {
            return null;
        }
        if (pattern == null) {
            return format(date, DATE_PATTERN.YYYY_MM_DD);
        }
        return new SimpleDateFormat(pattern).format(date);
    }

    public static final String getDateBeginning(Date date) {
        return format(date, DATE_PATTERN.YYYY_MM_DD) + " " + DATE_PATTERN.STATR_TIME_STR;
    }

    public static final String getDateEnding(Date date) {
        return format(date, DATE_PATTERN.YYYY_MM_DD) + " " + DATE_PATTERN.END_TIME_END_STR;
    }

    public interface DATE_PATTERN {
        String YYYY_MM_DD = "yyyy-MM-dd";
        String STATR_TIME_STR = "00:00:00";
        String END_TIME_END_STR = "23:59:59";
    }

    /**
     * 去除日期的-后转数字
     *
     * @param param 日期字符串
     * @return 纯数字
     */
    public static int convertDateToInt(String param) {
        return Integer.valueOf(StringUtils.remove(param, "-"));
    }

    /**
     * left是否是right之前的时间
     *
     * @param left  左侧时间
     * @param right 右侧时间
     * @return 左侧时间是右侧时间之前的时间
     */
    public static boolean isBefore(String left, String right) {
        LocalDateTime leftTime = LocalDateTime.parse(left, DATE_TIME_FORMAT_BAK);
        LocalDateTime rightTime = LocalDateTime.parse(right, DATE_TIME_FORMAT_BAK);
        return leftTime.isBefore(rightTime);
    }

    /**
     * 将字符串时间转换为时间
     *
     * @param time
     * @return
     */
    public static LocalDateTime convertToLocalDateTime(String time) {
        return LocalDateTime.parse(time, DATE_TIME_FORMAT_BAK);
    }
}
