package com.riskcontrol.cron.xxljob;

import com.riskcontrol.common.annotation.LogUUID;
import com.riskcontrol.cron.service.PhoneNumberBlacklistService;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @program: riskcontrol-cron
 * @description: 定期检查手机号码黑名单数据是否生效持续180天，超过180后重置为失效状态
 * @author: Colson
 * @create: 2023-10-31 15:18
 */
@Component
@Slf4j
public class PhoneBlacklistStatusResetJob {

    @Resource
    private PhoneNumberBlacklistService phoneNumberBlacklistService;

    /**
     * 每天凌晨2点，跑手机号黑名单库，
     * 超过180天未发生解绑操作的手机号，自动从黑名单库中移除。（status 改为0）*
     */
    @XxlJob("phoneStatusReset")
    @LogUUID
    public void resetPhoneBlacklistStatusTask() {
        log.info("resetPhoneBlacklistStatusTask start");
        // 最后更新时间超过180天时，自动解绑（status更新为0）
        phoneNumberBlacklistService.checkAndResetStatus();
        log.info("resetPhoneBlacklistStatusTask end");
    }


}
