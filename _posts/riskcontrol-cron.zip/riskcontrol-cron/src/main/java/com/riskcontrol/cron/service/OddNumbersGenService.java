package com.riskcontrol.cron.service;

import com.cn.schema.request.WSOddNumbersGen;
import com.riskcontrol.common.exception.BusinessException;


/**
 * 单号生成服务层接口类
 *
 * @author wade
 * @date 2019-02-22 14:24:01.
 */
public interface OddNumbersGenService {

    char serial_start = 'A';
    char serial_end = 'Z';
    int num_start = 1;
    int requestid_num_end = 99;


    /**
     * 根据ID查询信息
     *
     * @param id 主键
     * @return WSOddNumbersGen
     * @throws BusinessException
     */
    WSOddNumbersGen loadOddNumbersGenById(String id) throws BusinessException;

    /**
     * 创建信息
     *
     * @param bean 需要创建的信息
     * @return WSOddNumbersGen 创建后结果
     * @throws BusinessException
     */
    WSOddNumbersGen createOddNumbersGen(WSOddNumbersGen bean) throws BusinessException;


    /**
     * 单个生成提案编号
     *
     * @param productId
     * @param requestType
     * @return
     * @throws BusinessException
     */
    String singleGenRequestId(String productId, String requestType) throws BusinessException;

}
