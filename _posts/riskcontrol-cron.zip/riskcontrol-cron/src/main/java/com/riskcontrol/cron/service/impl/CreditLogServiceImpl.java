package com.riskcontrol.cron.service.impl;

import com.cn.schema.creditlogs.*;

import com.riskcontrol.common.client.WSFeign;
import com.riskcontrol.common.config.WsCommonConfig;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.cron.service.CreditLogService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;


import javax.annotation.Resource;
import java.util.List;

@Service
public class CreditLogServiceImpl implements CreditLogService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private WsCommonConfig wsCommonConfig;
    @Resource
    private WSFeign wsFeign;

    /**
     * 查询额度记录
     * @param query
     * @return
     */
    @Override
    public List<WSCreditLogs> getCreditLogs(WSQueryCreditLogs query) {
        QueryCreditLogsRequest request = new QueryCreditLogsRequest();
        request.setInfProductId(wsCommonConfig.getWsProductId());
        request.setInfPwd(wsCommonConfig.getWsProductPwd());
        request.setTerminal(wsCommonConfig.getWsTerminal());
        request.setWSQueryCreditLogs(query);
        request.setRequestUUID(MDC.get(Constant.MDC_UUID_KEY));
        QueryCreditLogsResponse response = wsFeign.getCreditLogs(request);
        return response.getWSCreditLogs();
    }



}
