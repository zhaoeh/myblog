package com.riskcontrol.cron.mapper;

import com.riskcontrol.cron.entity.TRiskBlack;
import org.apache.ibatis.annotations.Mapper;


/**
 * @author Heng.zhang
 */
@Mapper
public interface RiskBlackMapper extends BaseMapperX<TRiskBlack> {

}
