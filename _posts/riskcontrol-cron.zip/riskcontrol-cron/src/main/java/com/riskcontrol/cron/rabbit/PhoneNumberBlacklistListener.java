package com.riskcontrol.cron.rabbit;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.common.annotation.LogUUID;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.entity.TLogRecord;
import com.riskcontrol.cron.entity.TMessageRecord;
import com.riskcontrol.cron.enums.LogRecordTypeEnum;
import com.riskcontrol.cron.enums.MessageRecordStatusEnum;
import com.riskcontrol.cron.service.KycRequestService;
import com.riskcontrol.cron.service.LogRecordService;
import com.riskcontrol.cron.service.MessageRecordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

import static com.riskcontrol.cron.constants.CronConstant.ONE;

/**
 * @program: riskcontrol-api
 * @description: 手机号码黑名单解绑消息消费
 * @author: Colson
 * @create: 2023-10-16 14:56
 */
@Component
@Slf4j
public class PhoneNumberBlacklistListener {


    @Resource
    private MessageRecordService messageRecordService;

    @Resource
    private KycRequestService kycRequestService;

    @Resource
    private LogRecordService logRecordService;


    @RabbitListener(bindings = @QueueBinding(
            value = @Queue(value = "${unbind.phone.number.queue.name}", durable = "true", autoDelete = "false"),
            exchange = @Exchange(value = "${unbind.phone.number.exchange.name}", type = "topic"),
            key = "#{'${unbind.phone.number.routing.key}'.split(';')}")
    )
    @LogUUID
    public void phoneNumberBlacklistListener(Message msg) {
        if (msg == null) {
            log.info("手机号码更新消息为空");
            return;
        }
        String msgBody = new String(msg.getBody());
        log.info("phoneNumberBlacklistListener msgBody={}", msgBody);
        String flagStr = "flag";
        String msgContentStr = "msgContent";
        String uuidStr = "uuid";
        String uuid = null;
        String flag = null;
        try {
            JSONObject msgContentObj = JSONObject.parseObject(msgBody).getJSONObject(msgContentStr);
            if (msgContentObj == null) {
                log.info("phoneNumberBlacklistListener msgContentObj is null");
                return;
            }
            uuid = msgContentObj.getString(uuidStr);
            flag = msgContentObj.getString(flagStr);
            if (StrUtil.isNotBlank(uuid)){
                TMessageRecord messageRecord = messageRecordService.getMessageRecordByUUID(uuid);
                if (messageRecord != null) {
                    // 消息中的uuid已存在消息表中，将记录加入日志表
                    saveLogRecord(LogRecordTypeEnum.WARN.getValue(), msgBody, uuid,"uuid exist", null);
                    log.info("phoneNumberBlacklistListener msgContentUUID={} exist ", uuid);
                } else {
                    messageRecordService.saveMessageRecord(msgBody);
                }
            }
            log.info("phoneNumberBlacklistListener uuid={}, flag={} start", uuid, flag);
            if ("17".equals(flag)) { //修改手机号
                messageRecordService.checkMessageRecord(msgBody);
            }
        } catch (Exception e) {
            messageRecordService.updateStatusByUUID(uuid, MessageRecordStatusEnum.CONSUMPTION_FAILURE.getValue());
            saveLogRecord(LogRecordTypeEnum.ERROR.getValue(), msgBody, uuid, "exception", e.toString());
            log.info("phoneNumberBlacklistListener 手机号码消息数据异常，处理失败, error={}", e.toString());
        }
        log.info("phoneNumberBlacklistListener uuid={}， flag={} end", uuid, flag);
    }


    /**
     * 记录日志 *
     *
     * @param logRecordType 日志记录类型
     * @param receiveParam  接收参数
     * @param uuid          消息中的uuid，用于检查时快速匹配数据
     * @param remark        日志备注
     * @param logMsg        logMsg
     */
    private void saveLogRecord(String logRecordType, String receiveParam, String uuid, String remark, String logMsg) {
        // 消息中的uuid已存在消息表中，将记录加入日志表
        TLogRecord tLogRecord = new TLogRecord();
        tLogRecord.setModuleName(CronConstant.DOMAIN_NAME)
                .setLocation("PhoneNumberBlacklistListener")
                .setType(logRecordType)
                .setReceiveParam(receiveParam)
                .setLogMessage(logMsg)
                .setRemark(remark + ", UUID：" + uuid);
        logRecordService.save(tLogRecord);
    }

}
