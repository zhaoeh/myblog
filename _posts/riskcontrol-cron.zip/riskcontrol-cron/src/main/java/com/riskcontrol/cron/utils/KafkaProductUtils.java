package com.riskcontrol.cron.utils;

import io.netty.util.HashedWheelTimer;
import io.netty.util.Timeout;
import io.netty.util.TimerTask;
import io.netty.util.internal.ThreadLocalRandom;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.SuccessCallback;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

@Component
@Slf4j
public class KafkaProductUtils {

    @Resource
    private KafkaTemplate<String, String> kafkaTemplate;


    private final HashedWheelTimer timer = new HashedWheelTimer(1, TimeUnit.SECONDS);

    public void pushKafkaMsg(final String topic,final String message){
        ProducerRecord<String,String> producerRecord = new ProducerRecord<>(topic,message);
        kafkaTemplate.send(producerRecord).addCallback((SuccessCallback) result -> {
            log.info("pushKafkaMsg success {}",result);
        }, ex -> {
            log.error("pushKafkaMsg failure "+ producerRecord.value(),ex);
            TimerTask timerTask = new TimerTask() {
                @Override
                public void run(Timeout timeout) throws Exception {
                    pushKafkaMsg(topic, message);
                }
            };
            timer.newTimeout(timerTask, ThreadLocalRandom.current().nextInt(2, 5), TimeUnit.SECONDS);
        });
    }
}
