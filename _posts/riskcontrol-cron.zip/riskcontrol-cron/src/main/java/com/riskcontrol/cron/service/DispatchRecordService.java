package com.riskcontrol.cron.service;

import com.cn.schema.request.WSDispatchRecord;
import com.riskcontrol.common.exception.BusinessException;

import java.util.List;

public interface DispatchRecordService {

    int create(WSDispatchRecord bean) throws BusinessException;


    int create(List<WSDispatchRecord> bean) throws BusinessException;

    /**
     *confirm 接单
     * @param orderStyle
     * @param loginName
     * @param requestIds
     * @return
     */
    int confirm(String orderStyle, String loginName, List<String> requestIds)throws BusinessException;

    /**
     *获取该角色等待审核的总数
     * @param loginName
     * @return
     */
    int getPendingRequest(String loginName)throws BusinessException;
}
