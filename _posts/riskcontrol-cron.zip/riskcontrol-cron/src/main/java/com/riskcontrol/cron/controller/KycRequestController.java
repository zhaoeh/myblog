package com.riskcontrol.cron.controller;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.customers.*;
import com.cn.schema.request.*;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.request.kyc.RiskCreateKycRequestRequest;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequest;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequestRequest;
import com.riskcontrol.common.entity.request.kyc.RiskUpdateKycRequestRequest;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.kyc.RiskQueryKycRequestResponse;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.datasource.DBSourceCheck;
import com.riskcontrol.cron.datasource.DataSourceType;
import com.riskcontrol.cron.enums.ErrCodeEnum;
import com.riskcontrol.cron.service.CustomersFacade;
import com.riskcontrol.cron.service.KycRequestProcessLogService;
import com.riskcontrol.cron.service.KycRequestService;
import com.riskcontrol.cron.utils.CommonLogic;
import com.riskcontrol.cron.utils.DateUtil;
import com.riskcontrol.cron.utils.RedisUtil;
import com.riskcontrol.cron.utils.ValidationUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @program: riskcontrol-cron
 * @description: kyc controller
 * @author: Erhu.Zhao
 * @create: 2023-10-04 15:42
 **/
@RestController
@RequestMapping("/customers/kyc_request")
@Api("KYC相关接口")
@Slf4j
public class KycRequestController {

    /**
     * 日志
     */
    protected final Logger webserviceApiLogger = LoggerFactory.getLogger("webservice_api_logger");

    @Autowired
    private KycRequestService kycRequestService;


    @Autowired
    private KycRequestProcessLogService kycRequestProcessLogService;


    @Autowired
    private CustomersFacade customersFacade;

    @Resource
    protected RedisUtil redisUtil;
    /**
     * 分页查询接口,返回记录条数和当前页的信息
     *
     * @param request 分页查询条件
     * @return response 记录总条数和当前页的信息
     * @throws Exception
     */
    @ApiOperation(
            value = "分页查询接口",
            notes = "分页查询接口,返回记录总条数和当前页的信息",
            response = QueryKycRequestResponse.class,
            httpMethod = "POST"
    )
    @RequestMapping(method = RequestMethod.POST, value = "/query")
    @ResponseBody
    public Response<RiskQueryKycRequestResponse> queryPage(@RequestBody RiskQueryKycRequestRequest request) throws Exception {
        try {
            checkPidAndPwd(request.getInfProductId(), request.getInfPwd(), this.getClass());
            RiskQueryKycRequest params = null != request.getParams() ? request.getParams() : new RiskQueryKycRequest();
            if (StringUtils.isEmpty(params.getProductId())) {
                params.setProductId(request.getInfProductId());
            }
            int count = kycRequestService.countOfQueryPage(params);
            List<KycRequest> list = new ArrayList();
            if (count > 0) {
                list = kycRequestService.queryPage(params);
            }
            return Response.body(new RiskQueryKycRequestResponse(count, list));
        } catch (BusinessException e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage());
            throw e;
        } catch (Exception e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage(), e);
            throw new Exception(ErrCodeEnum.MSG_100002.getErrMsg());
        }
    }
    @RequestMapping(method = RequestMethod.POST, value = "/queryKycStatusByCustomerId")
    @ResponseBody
    @DBSourceCheck(DataSourceType.SLAVE)
    public Response<List<Integer>> queryKycStatusByCustomerId(@RequestBody RiskQueryKycRequest kycRequest) throws Exception {
        try {
            List<Integer> statusList = kycRequestService.queryKycStatusByCustomerId(kycRequest);
            return Response.body(statusList);
        } catch (BusinessException e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", kycRequest.getCustomerId(), e.getMessage());
            throw e;
        } catch (Exception e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", kycRequest.getCustomerId(), e.getMessage(), e);
            throw new Exception(ErrCodeEnum.MSG_100002.getErrMsg());
        }
    }
    /**
     * 创建接口
     *
     * @param request 创建信息
     * @return response 操作结果以及实体类信息（包括创建成功后的记录ID）
     * @throws Exception
     */
    @ApiOperation(
            value = "创建接口",
            notes = "创建接口,返回操作结果以及创建的实体信息",
            response = CreateCustomerKycResponse.class,
            httpMethod = "POST"
    )
    @RequestMapping(method = RequestMethod.POST, value = "/create")
    @ResponseBody
    public Response<CreateKycRequestResponse> create(@RequestBody RiskCreateKycRequestRequest request) throws Exception {
        try {
            checkPidAndPwd(request.getInfProductId(), request.getInfPwd(), this.getClass());
            request.getWsKycRequest().setProductId(request.getInfProductId());
            return Response.body(new CreateKycRequestResponse(kycRequestService.create(request.getWsKycRequest())));
        } catch (BusinessException e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage());
            throw e;
        } catch (Exception e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage(), e);
            throw new Exception(ErrCodeEnum.MSG_100002.getErrMsg());
        }
    }

    /**
     * 更新接口
     *
     * @param request 更新信息
     * @return response 操作结果以及实体类信息（包括创建成功后的记录ID）
     * @throws Exception
     */
    @ApiOperation(
            value = "更新接口",
            notes = "更新接口,返回被更新的条数",
            response = ModifyKycRequestResponse.class,
            httpMethod = "POST"
    )
    @RequestMapping(method = RequestMethod.POST, value = "/update")
    @ResponseBody
    public Response<ModifyKycRequestResponse> update(@RequestBody RiskUpdateKycRequestRequest request) throws Exception {
        try {
            checkPidAndPwd(request.getInfProductId(), request.getInfPwd(), this.getClass());
            request.getWsKycRequest().setProductId(request.getInfProductId());

            ValidationUtils.checkRequiredValue(request.getWsKycRequest().getId());

            return Response.body(new ModifyKycRequestResponse(kycRequestService.update(request)));
        } catch (BusinessException e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage());
            throw e;
        } catch (Exception e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage(), e);
            throw new Exception(ErrCodeEnum.MSG_100002.getErrMsg());
        }
    }

    @RequestMapping(method = RequestMethod.POST, value = "/pbcModifyStatus")
    @ResponseBody
    public Response<ModifyKycRequestResponse> pbcModifyStatus(@RequestBody RiskUpdateKycRequestRequest request) throws Exception {
        String lockKey = String.format(CronConstant.KYC_UPDATE_PBC_LOCK,request.getWsKycRequest().getId());
        try {
            if(redisUtil.tryLock(lockKey,30,-1, TimeUnit.SECONDS)){
                checkPidAndPwd(request.getInfProductId(), request.getInfPwd(), this.getClass());
                request.getWsKycRequest().setProductId(request.getInfProductId());

                ValidationUtils.checkRequiredValue(request.getWsKycRequest().getId());

                return Response.body(new ModifyKycRequestResponse(kycRequestService.pbcModifyStatus(request.getWsKycRequest())));
            }else{
                throw new BusinessException(ResultEnum.FAIL.getCode(), "Do not repeat the request");
            }
        } catch (BusinessException e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage());
            throw e;
        } catch (Exception e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage(), e);
            throw new Exception(ErrCodeEnum.MSG_100002.getErrMsg());
        }finally {
            redisUtil.unLock(lockKey);
        }
    }

    /**
     * KYC 数量查询接口
     *
     * @param request 数量查询条件
     * @return response 数量查询响应
     * @throws Exception 异常信息
     */
    @ApiOperation(
            value = "kyc count查询接口",
            notes = "查询kyc count",
            response = QueryKycRequestResponse.class,
            httpMethod = "POST"
    )
    @RequestMapping(method = RequestMethod.POST, value = "/count")
    @ResponseBody
    public Response<QueryKycRequestResponse> count(@RequestBody RiskQueryKycRequestRequest request) throws Exception {
        try {
            checkPidAndPwd(request.getInfProductId(), request.getInfPwd(), this.getClass());
            RiskQueryKycRequest params = null != request.getParams() ? request.getParams() : new RiskQueryKycRequest();
            if (StringUtils.isEmpty(params.getProductId())) {
                params.setProductId(request.getInfProductId());
            }
            int count = kycRequestService.countAllowMiddleNameIsNullKycNotLike(params);
            return Response.body(new QueryKycRequestResponse(count, null));
        } catch (BusinessException e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage());
            throw e;
        } catch (Exception e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage(), e);
            throw new Exception(ErrCodeEnum.MSG_100002.getErrMsg());
        }
    }

    @RequestMapping(method = RequestMethod.POST, value = "/pbcDispatch")
    @ResponseBody
    public Response<ModifyKycRequestResponse> pbcDispatch(@RequestBody RiskUpdateKycRequestRequest request) throws Exception {
        try {
            checkPidAndPwd(request.getInfProductId(), request.getInfPwd(), this.getClass());
            request.getWsKycRequest().setProductId(request.getInfProductId());

            ValidationUtils.checkRequiredValue(request.getWsKycRequest().getId());

            return Response.body(new ModifyKycRequestResponse(kycRequestService.pbcDispatch(request.getWsKycRequest())));
        } catch (BusinessException e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage());
            throw e;
        } catch (Exception e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage(), e);
            throw new Exception(ErrCodeEnum.MSG_100002.getErrMsg());
        }
    }

    @RequestMapping(method = RequestMethod.POST, value = "/queryWaitPendingCount")
    @ResponseBody
    public Response<QueryCountResponse> queryWaitPendingCount(@RequestPayload @RequestBody KycRequest request) throws Exception {
        QueryCountResponse response = new QueryCountResponse();
        try {
            response.setCount(kycRequestService.countWaitPending(request));
        } catch (BusinessException e) {
            webserviceApiLogger.error("{} count wait pending {} call interface fail! msg:{}", request.getLoginName(), e.getMessage(), e);
        }
        return Response.body(response);
    }

    /**
     * 派单
     *
     * @param request 派单请求参数
     * @return 派单响应参数
     * @throws Exception 异常信息
     */
    @RequestMapping(method = RequestMethod.POST, value = "/dispatch")
    @ResponseBody
    public Response<RiskQueryKycRequestResponse> dispatch(@RequestPayload @RequestBody RiskQueryKycRequest request) throws Exception {
        RiskQueryKycRequestResponse response = new RiskQueryKycRequestResponse();
        try {
            List<KycRequest> wsKycRequests = customersFacade.dispatchKycRequest(request);
            response.setData(wsKycRequests);
            response.setCount(wsKycRequests.size());
        } catch (BusinessException e) {
            webserviceApiLogger.error("{} dispatch call {} interface fail! msg:{}", request.getLoginName(), e.getMessage(), e);
        }
        return Response.body(response);
    }

    /**
     * 取消派单
     *
     * @param request 取消派单参数
     * @return 取消派单响应
     * @throws Exception 异常
     */
    @RequestMapping(method = RequestMethod.POST, value = "/dispatchCancel")
    @ResponseBody
    public Response<KycDispatchConfirmResponse> cancelDispatch(@RequestPayload @RequestBody RiskQueryKycRequest request) throws Exception {
        KycDispatchConfirmResponse response = new KycDispatchConfirmResponse();
        try {
            response.setResult(kycRequestService.cancelDispatch(request.getLoginName()) > 0);
        } catch (BusinessException e) {
            webserviceApiLogger.error("{} cancel dispatch  call {} interface fail! msg:{}", request.getLoginName(), e.getMessage(), e);
        }
        return Response.body(response);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/queryKycPbcRequest")
    @ResponseBody
    public Response<RiskQueryKycRequestResponse> queryKycPbcRequest(@RequestBody RiskQueryKycRequestRequest request) throws Exception {
        try {
            checkPidAndPwd(request.getInfProductId(), request.getInfPwd(), this.getClass());
            RiskQueryKycRequest params = null != request.getParams() ? request.getParams() : new RiskQueryKycRequest();
            if (StringUtils.isEmpty(params.getProductId())) {
                params.setProductId(request.getInfProductId());
            }

            RiskQueryKycRequest queryKycRequest = request.getParams();
            if (StringUtils.isBlank(queryKycRequest.getLoginName())) {
                if (StringUtils.isBlank(queryKycRequest.getCreatedDateBegin())) {
                    queryKycRequest.setCreatedDateBegin(DateUtil.getDateBeginning(new Date()));
                }
                if (StringUtils.isBlank(queryKycRequest.getCreatedDateEnd())) {
                    queryKycRequest.setCreatedDateEnd(DateUtil.getDateEnding(new Date()));
                }
                ValidationUtils.checkDateRange(queryKycRequest.getCreatedDateBegin(), queryKycRequest.getCreatedDateEnd(), ErrCodeEnum.MSG_381042);
                request.setParams(queryKycRequest);
            }
            params.setPageNum(CommonLogic.buildFirstPageParamOfMySql(params.getPageNum(), params.getPageSize()));

            int count = kycRequestService.countKycPbc(params);


            List<KycRequest> list = new ArrayList();
            if (count > 0) {
                list = kycRequestService.queryKycPbcPage(params);
            }
            return Response.body(new RiskQueryKycRequestResponse(count, list));
        } catch (BusinessException e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage());
            throw e;
        } catch (Exception e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage(), e);
            throw new Exception(ErrCodeEnum.MSG_100002.getErrMsg());
        }
    }

    @RequestMapping(method = RequestMethod.POST, value = "/queryKycSheetRequest")
    @ResponseBody
    public Response<QueryKycSheetListRequestResponse> queryKycSheetRequest(@RequestBody RiskQueryKycRequestRequest request) throws Exception {
        try {
            checkPidAndPwd(request.getInfProductId(), request.getInfPwd(), this.getClass());
            RiskQueryKycRequest params = null != request.getParams() ? request.getParams() : new RiskQueryKycRequest();
            if (StringUtils.isEmpty(params.getProductId())) {
                params.setProductId(request.getInfProductId());
            }
            RiskQueryKycRequest kycParams = request.getParams();
            kycParams.setPageNum(CommonLogic.buildFirstPageParamOfMySql(kycParams.getPageNum(), kycParams.getPageSize()));
            int count = kycRequestService.countKycPbcNew(kycParams);
            List<KycRequest> list = new ArrayList();
            List<WSKycSheetRequest> sheetList = new ArrayList();
            if (count > 0) {
                list = kycRequestService.queryKycSheetList(kycParams);
                for (int i = 0; i < list.size(); i++) {
                    KycRequest kyc = list.get(i);
                    WSKycSheetRequest kycSheet = new WSKycSheetRequest();
                    BeanUtils.copyProperties(kycSheet, kyc);
                    kycSheet.setRealName(kyc.getFirstName() + (kyc.getMiddleName() == null ? " " : (" " + kyc.getMiddleName() + " ")) + kyc.getLastName());

  /*                  if(kyc.getType()!=null && !kyc.getType().equals("")){
                        if(kyc.getType().equals("PBC approved")){
                            kycSheet.setPbcApprovedBy(kyc.getPbcApprovedBy());
                            kycSheet.setPbcApprovedDate(kyc.getPbcApprovedDate());
                        }else {
                            kycSheet.setPbcApprovedBy("");
                            kycSheet.setPbcApprovedDate("");
                        }
                    }*/

                    sheetList.add(kycSheet);
                }
            }
            log.info("结果数据:{}", sheetList);
            return Response.body(new QueryKycSheetListRequestResponse(count, sheetList));
        } catch (BusinessException e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage());
            throw e;
        } catch (Exception e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage(), e);
            throw new Exception(ErrCodeEnum.MSG_100002.getErrMsg());
        }
    }
//

    @RequestMapping(method = RequestMethod.POST, value = "/countKycPbcRequest")
    @ResponseBody
    public Response<QueryKycRequestResponse> countKycPbcRequest(@RequestBody RiskQueryKycRequestRequest request) throws Exception {
        try {
            checkPidAndPwd(request.getInfProductId(), request.getInfPwd(), this.getClass());
            RiskQueryKycRequest params = null != request.getParams() ? request.getParams() : new RiskQueryKycRequest();
            if (StringUtils.isEmpty(params.getProductId())) {
                params.setProductId(request.getInfProductId());
            }
            RiskQueryKycRequest queryKycRequest = request.getParams();
            if (StringUtils.isBlank(queryKycRequest.getLoginName())) {
                if (StringUtils.isBlank(queryKycRequest.getCreatedDateBegin())) {
                    queryKycRequest.setCreatedDateBegin(DateUtil.getDateBeginning(new Date()));
                }
                if (StringUtils.isBlank(queryKycRequest.getCreatedDateEnd())) {
                    queryKycRequest.setCreatedDateEnd(DateUtil.getDateEnding(new Date()));
                }
                ValidationUtils.checkDateRange(queryKycRequest.getCreatedDateBegin(), queryKycRequest.getCreatedDateEnd(), ErrCodeEnum.MSG_381042);
                request.setParams(queryKycRequest);
            }
            int count = kycRequestService.countKycPbc(params);
            return Response.body(new QueryKycRequestResponse(count, null));
        } catch (BusinessException e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage());
            throw e;
        } catch (Exception e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage(), e);
            throw new Exception(ErrCodeEnum.MSG_100002.getErrMsg());
        }
    }


    @RequestMapping(method = RequestMethod.POST, value = "/bactchModifyPbcStatus")
    @ResponseBody
    public Response<BatchModifyPbcRequestResponse> bactchModifyPbcStatus(@RequestBody BatchUpdateKycRequestRequest request) throws Exception {
        try {
            checkPidAndPwd(request.getInfProductId(), request.getInfPwd(), this.getClass());
            BatchModifyPbcRequestResponse response = kycRequestService.bactchModifyPbcStatus(request);
            log.info("BatchModifyPbcRequestResponse response:{}", JSONObject.toJSONString(response));
            return Response.body(response);
        } catch (BusinessException e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage());
            throw e;
        } catch (Exception e) {
            webserviceApiLogger.error("{} call interface fail! msg:{}", request.getInfProductId(), e.getMessage(), e);
            throw new Exception(ErrCodeEnum.MSG_100002.getErrMsg());
        }
    }

    @RequestMapping(method = RequestMethod.POST, value = "/queryPageByKycRequestId")
    @ResponseBody
    public Response<QueryKycRequestProcessLogResponse> queryPageByKycRequestId(@RequestPayload @RequestBody UpdateKycRequestRequest request) throws Exception {
        QueryKycRequestProcessLogResponse response = new QueryKycRequestProcessLogResponse();

        response.setData(kycRequestProcessLogService.queryPageByKycRequestId(request.getWsKycRequest().getId()));
        return Response.body(response);

    }

    @RequestMapping(method = RequestMethod.POST, value = "/checkDispatchConfirm")
    @ResponseBody
    public Response<KycDispatchConfirmResponse> checkDispatchConfirm(@RequestPayload @RequestBody KycDispatchConfirmRequest request) {
        KycDispatchConfirmResponse response = new KycDispatchConfirmResponse();
        try {
            response.setResult(customersFacade.checkDispatchKycRequestConfirm(request));
            return Response.body(response);
        } catch (Exception e) {
            webserviceApiLogger.error("{} check dispatch Confirm {} interface fail! msg:{}", request.getLoginName(), e.getMessage(), e);
        }
        return Response.body(response);
    }

    /**
     * 校验产品ID和密码是否合法
     * ws的加密验证，风控不需要使用了
     * @param infProductId 产品ID
     * @param infPwd       产品密码
     * @param clazz
     * @throws BusinessException
     */
    @Deprecated
    protected void checkPidAndPwd(String infProductId, String infPwd, Class clazz) throws BusinessException {
//        if (!CheckUtil.isNotEmpty(infProductId)
//                || !CheckUtil.isNotEmpty(infPwd)
//                || !checkUtil.checkPidAndPwd(infProductId, infPwd, clazz)) {
//            throw new BusinessException(ErrCodeEnum.MSG_100000);
//        }
    }


    @RequestMapping(method = RequestMethod.POST, value = "/dispatchConfirm")
    @ResponseBody
    public Response<KycDispatchConfirmResponse> dispatchConfirm(@RequestPayload @RequestBody KycDispatchConfirmRequest request) throws Exception {
        KycDispatchConfirmResponse response = new KycDispatchConfirmResponse();
        try {
            response.setResult(customersFacade.dispatchKycRequestConfirm(request));
            return Response.body(response);
        } catch (Exception e) {
            webserviceApiLogger.error("{} dispatch Confirm {} interface fail! msg:{}", request.getLoginName(), e.getMessage(), e);
        }
        return Response.body(response);
    }

    /**
     * 修改派单用户配置
     *
     * @param request 派单配置请求
     * @return 派单配置修改后结果
     */
    @RequestMapping(method = RequestMethod.POST, value = "/modifyCustomConfiguration")
    @ResponseBody
    public JSONObject modifyCustomConfiguration(@RequestPayload @RequestBody JSONObject request) {
        return kycRequestService.modifyCustomConfiguration(request);
    }


    /**
     * 自动通过KYC和PB
     *
     * @param request
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, value = "/autoApproveKycAndPbc")
    @ResponseBody
    public Response<ModifyKycRequestResponse> autoApproveKycAndPbc(@RequestBody RiskUpdateKycRequestRequest request) {
        Response<ModifyKycRequestResponse> response = new Response<>();
        checkPidAndPwd(request.getInfProductId(), request.getInfPwd(), this.getClass());
        request.getWsKycRequest().setProductId(request.getInfProductId());
        ValidationUtils.checkRequiredValue(request.getWsKycRequest().getLoginName());
        response.setBody(new ModifyKycRequestResponse(kycRequestService.autoApproveKycAndPbc(request.getWsKycRequest())));
        return response;
    }

    @ApiOperation(
            value = "获取审核中的订单数量",
            notes = "获取审核中的订单数量",
            response = DispatchPendingCountResponse.class,
            httpMethod = "POST"
    )
    @RequestMapping(method = RequestMethod.POST, value = "/pending_count")
    @ResponseBody
    public Response<DispatchPendingCountResponse> dispatchRequestPendingCount(@RequestPayload @RequestBody WSDispatchRecord request) throws Exception {
        DispatchPendingCountResponse response = new DispatchPendingCountResponse();
        try {
            response.setCount(kycRequestService.getPendingRequest(request.getUserLoginName()));
        } catch (BusinessException e) {
            webserviceApiLogger.error("{} count wait pending {} call interface fail! msg:{}",request.getUserLoginName() , e.getMessage(), e);
        }
        return Response.body(response);
    }
    @ApiOperation(
            value = "kyc id重复检验接口",
            notes = "检验kyc idNo和idType",
            response = Boolean.class,
            httpMethod = "POST"
    )
    @RequestMapping(method = RequestMethod.POST, value = "/validKycIdAndType")
    @ResponseBody
    public Response<Boolean> validKycIdAndType(Integer idType,String idNo) throws Exception {
        try {
            return Response.body(kycRequestService.validKycIdAndTypeExist(idType,idNo));
        } catch (BusinessException e) {
            webserviceApiLogger.error("{} call interface fail! idType:{},idNo:{}", idType,idNo, e.getMessage());
            throw e;
        } catch (Exception e) {
            webserviceApiLogger.error("{} call interface fail! idType:{},idNo:{}", idType,idNo, e.getMessage(), e);
            throw new Exception(ErrCodeEnum.MSG_100002.getErrMsg());
        }
    }
    @ApiOperation(
            value = "查询指定用户kyc信息，最有效的一条 ",
            notes = "已审批>待审批>拒绝>未提交",
            response = KycRequest.class,
            httpMethod = "POST"
    )
    @RequestMapping(method = RequestMethod.POST, value = "/queryKycByLoginNameOrderOne")
    @ResponseBody
    public Response<KycRequest> queryKycByLoginNameOrderOne(@RequestBody RiskQueryKycRequest query){
        return Response.body(kycRequestService.queryKycByLoginNameOrderOne(query));
    }
}
