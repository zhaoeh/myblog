package com.riskcontrol.cron.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.cm.util.common.Constants;
import com.cn.schema.customers.WSCustomers;
import com.riskcontrol.common.client.MessageApiFeign;
import com.riskcontrol.common.config.UserCenterSwitch;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.pojo.Ekyc;
import com.riskcontrol.common.entity.pojo.EkycDeduplicate;
import com.riskcontrol.common.entity.pojo.EkycRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycExtendRequest;
import com.riskcontrol.common.entity.request.message.PushContentReq;
import com.riskcontrol.common.entity.zoloz.EkycContext;
import com.riskcontrol.common.enums.EkycReasonEnums;
import com.riskcontrol.common.enums.EkycStatusEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.service.UserCenterTemplate;
import com.riskcontrol.common.service.WsFeignTemplate;
import com.riskcontrol.common.utils.*;
import com.riskcontrol.cron.constants.ConstantVars;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.constants.ProjectConstant;
import com.riskcontrol.cron.convert.EkycConvert;
import com.riskcontrol.cron.convert.EkycRequestConvert;
import com.riskcontrol.cron.convert.WSCustomersConvert;
import com.riskcontrol.cron.mapper.EkycDeduplicateMapper;
import com.riskcontrol.cron.mapper.EkycMapper;
import com.riskcontrol.cron.mapper.EkycRequestMapper;
import com.riskcontrol.cron.service.EkycExtendService;
import com.riskcontrol.cron.template.SmsApiTemplate;
import com.riskcontrol.cron.utils.ProductConstantsLoader;
import com.riskcontrol.cron.utils.RedisUtil;
import com.ws.SmsContent;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigInteger;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;

import static com.riskcontrol.common.constants.Constant.RISK_EKYC_STATUS_KEY;
import static com.riskcontrol.common.enums.ResultEnum.*;

/**
 * @description: ekyc完善扩展信息接口实现
 * @author: ErHu.Zhao
 * @create: 2024-10-09
 **/
@Component
@Slf4j
public class EkycExtendServiceImpl implements EkycExtendService {

    /**
     * 单例线程池，负责发送短信*
     */
    @Resource(name = "customizedExecutorService")
    private ThreadPoolExecutor executorService;

    @Resource
    private UserCenterTemplate userCenterTemplate;

    @Resource
    private WsFeignTemplate wsFeignTemplate;

    @Resource
    private EkycMapper ekycMapper;

    @Resource
    private EkycRequestMapper ekycRequestMapper;

    @Resource
    private EkycDeduplicateMapper ekycDeduplicateMapper;

    @Resource
    private RedisUtil redisUtil;

    @Resource
    private SmsApiTemplate smsApiTemplate;

    @Resource
    private MessageApiFeign messageApiFeign;

    @Value("${C66.push.exchange:exchange_template_job_message}")
    private String pushExchange;

    @Value("${C66.push.routing.key:C66.routing.template.job.message.queue}")
    private String pushRoutingKey;

    /**
     * 通过动作*
     *
     * @param context
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public Boolean doActionOfEkycApproval(EkycContext context) {
        try {
            // 更新ekyc_request
            Optional.ofNullable(this.copy(context)).map(re -> {
                re.setStatus(EkycStatusEnum.APPROVAL.getEKycReqStatus());
                re.setUpdateBy(context.getLoginName());
                Date date = new Date();
                re.setUpdateExDate(date);
                re.setApprovedBy(CronConstant.MODIFY_DEFAULT_SYSTEM);
                re.setApprovedDate(date);
                ekycRequestMapper.updateById(re);
                context.setEkycRequest(re);
                return re;
            }).map(re -> ekycMapper.selectOne(Ekyc::getLoginName, context.getLoginName())).map(k -> {
                BigInteger originalId = k.getId();
                EkycConvert.INSTANT.copyValidatedProperties(context.getEkycRequest(), k);
                k.setId(originalId);
                k.setStatus(EkycStatusEnum.APPROVAL.getEkycStatus());
                k.setUpdateBy(context.getLoginName());
                k.setUpdateDate(new Date());
                // 更新ekyc
                ekycMapper.updateById(k);
                context.setEkyc(k);
                // 更新证件使用记录表
                this.doUpdateDeduplicate(context);
                return k;
            }).orElseThrow(() -> {
                // 更新时主表不存在记录直接抛出异常
                throw new BusinessException(EKYC_NOT_EXISTS_ERROR);
            });

            // 从ws获取用户信息并修改用户、处理消息
            Optional.ofNullable(context.getOriWsCustomers()).map(ws -> {
                if (modifyUserInfo(context)) {
                    // ws修改用户信息成功则异步发送消息
                    String tenant = context.getEkycRequest().getTenant();
                    Map<String, String> contextMap = LogUtils.getMDCContextMap();
                    initMsg(() -> redisUtil.entries("r-0013"), context,
                            EkycContext.buildTask(tenant.concat(Constant.EKYC_SUCCESS_SMS_SUFFIX), () -> CompletableFuture.runAsync(() -> {
                                LogUtils.setMDCContextMap(contextMap);
                                try {
                                    log.info("ekyc补充信息审核通过后发送短信开始，当前用户：{}，requestId是：{}，billNo是：{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo());
                                    //提示内容
                                    this.doSendMessage(context, buildSmsContentAction(context, null));
                                } catch (Exception e) {
                                    log.error("ekyc补充信息审核通过后发送短信报错，当前用户：{}，requestId是：{}，billNo是：{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo(), e);
                                }
                            }, executorService)),
                            EkycContext.buildTask(tenant.concat(Constant.EKYC_SUCCESS_PUSH_SUFFIX), () -> CompletableFuture.runAsync(() -> {
                                LogUtils.setMDCContextMap(contextMap);
                                try {
                                    log.info("ekyc补充信息审核通过后推送消息开始，当前用户：{}，requestId是：{}，billNo是：{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo());
                                    //提示内容
                                    this.doPushMessage(context, buildPushContentAction(context, null));
                                } catch (Exception e) {
                                    log.error("ekyc补充信息审核通过后推送消息报错，当前用户：{}，requestId是：{}，billNo是：{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo(), e);
                                }
                            }, executorService))).doTasks((logInfo, format) ->
                            log.info("ekyc补充信息审核通过，消息容器配置为空，当前用户：{}，requestId：{}，billNo：{}，日志对象为：{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo(), format));
                } else {
                    throw new BusinessException(EKYC_UPDATE_WS_ERROR);
                }
                return ws;
            }).orElseThrow(() -> {
                log.error("ekyc补充信息报错，ws不存在用户，当前用户：{}，requestId是：{}，billNo是：{},WSCustomers:{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo(), JSONObject.toJSONString(context.getOriWsCustomers()));
                throw new BusinessException(EKYC_USER_NOT_EXISTS_ERROR);
            });
        } finally {
            clearCache(context.getLoginName());
        }
        return true;
    }

    /**
     * 拒绝动作*
     *
     * @param context
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public Boolean doActionOfEkycReject(EkycContext context) {
        try {
            Supplier<String> rejectReasonSupplier = () -> this.supplyRejectReason(context,(logInfo, format) -> log.info("ekyc extend获取拒绝原因，当前用户：{}，requestId是：{}，billNo是：{}，日志对象为：{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo(), format));
            String reason = Optional.ofNullable(context.getRejectReason(rejectReasonSupplier)).filter(StringUtils::isNotBlank).orElseGet(rejectReasonSupplier);
            Optional.of(this.copy(context)).map(re -> {
                re.setRejectReason(reason);
                re.setStatus(EkycStatusEnum.REJECTED_AUTO.getEKycReqStatus());
                re.setUpdateBy(context.getLoginName());
                Date date = new Date();
                re.setUpdateExDate(date);
                re.setApprovedBy(CronConstant.MODIFY_DEFAULT_SYSTEM);
                re.setApprovedDate(date);
                // 更新ekyc_request
                ekycRequestMapper.updateById(re);
                context.setEkycRequest(re);
                // 更新ekyc
                return ekycMapper.selectOne(Ekyc::getLoginName, context.getLoginName());
            }).map(k -> {
                int status = k.getStatus();
                if (!Objects.equals(EkycStatusEnum.APPROVAL.getEkycStatus(), status)) {
                    // ekyc状态不为approval，则更新ekyc
                    k.setStatus(EkycStatusEnum.REJECTED_AUTO.getEkycStatus());
                    k.setRejectReason(context.getRejectReason(rejectReasonSupplier));
                    k.setUpdateBy(context.getLoginName());
                    k.setUpdateDate(new Date());
                    log.info("ekyc补充信息审核拒绝后更新主表，当前用户：{}，requestId是：{}，billNo是：{}，statusInDb：{}，update ekyc：{}",
                            context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo(), status, JSONObject.toJSONString(k));
                    ekycMapper.updateById(k);
                }
                context.setEkyc(k);
                // 更新ekyc
                return k;
            }).orElseThrow(() -> {
                // 更新时主表不存在记录直接抛出异常
                throw new BusinessException(EKYC_NOT_EXISTS_ERROR);
            });
            Map<String, String> contextMap = LogUtils.getMDCContextMap();
            String tenant = context.getEkycRequest().getTenant();
            initMsg(() -> redisUtil.entries("r-0013"), context,
                    EkycContext.buildTask(tenant.concat(Constant.EKYC_REJECT_SMS_SUFFIX), () -> CompletableFuture.runAsync(() -> {
                        LogUtils.setMDCContextMap(contextMap);
                        try {
                            log.info("ekyc补充信息审核拒绝后发送短信开始，当前用户：{}，requestId是：{}，billNo是：{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo());
                            //提示内容
                            this.doSendMessage(context, buildSmsContentAction(context, reason));
                        } catch (Exception e) {
                            log.error("ekyc补充信息审核拒绝后发送短信报错，当前用户：{}，requestId是：{}，billNo是：{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo(), e);
                        }
                    }, executorService)),
                    EkycContext.buildTask(tenant.concat(Constant.EKYC_REJECT_PUSH_SUFFIX), () -> CompletableFuture.runAsync(() -> {
                        LogUtils.setMDCContextMap(contextMap);
                        try {
                            log.info("ekyc补充信息审核拒绝后推送消息开始，当前用户：{}，requestId是：{}，billNo是：{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo());
                            //提示内容
                            this.doPushMessage(context, buildPushContentAction(context, reason));
                        } catch (Exception e) {
                            log.error("ekyc补充信息审核拒绝后推送消息报错，当前用户：{}，requestId是：{}，billNo是：{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo(), e);
                        }
                    }, executorService))).doTasks((logInfo, format) ->
                    log.info("ekyc补充信息审核拒绝，消息任务拒绝执行，当前用户：{}，requestId：{}，billNo：{}，日志对象为：{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo(), format));
        } finally {
            clearCache(context.getLoginName());
        }
        return true;
    }

    /**
     * 转人工动作*
     *
     * @param context
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public Boolean doActionOfEkycManual(EkycContext context) {
        try {
            Optional.of(this.copy(context)).map(re -> {
                re.setStatus(EkycStatusEnum.PENDING.getEKycReqStatus());
                re.setManualReason(context.getManualReason().getId());
                re.setUpdateBy(context.getLoginName());
                re.setUpdateExDate(new Date());
                // 更新ekyc_request
                ekycRequestMapper.updateById(re);
                context.setEkycRequest(re);
                // 更新ekyc
                return ekycMapper.selectOne(Ekyc::getLoginName, context.getLoginName());
            }).map(k -> {
                // 主表状态为通过, 不更新主表.
                if(k.getStatus() == EkycStatusEnum.APPROVAL.getEkycStatus()){
                    return k;
                }
                k.setStatus(EkycStatusEnum.PENDING.getEkycStatus());
                k.setUpdateBy(context.getLoginName());
                k.setUpdateDate(new Date());
                // 更新ekyc
                ekycMapper.updateById(k);
                context.setEkyc(k);
                return k;
            }).orElseThrow(() -> {
                // 更新时主表不存在记录直接抛出异常
                throw new BusinessException(EKYC_NOT_EXISTS_ERROR);
            });
        } finally {
            clearCache(context.getLoginName());
        }
        return true;
    }

    /**
     * 构建sms内容补充器*
     *
     * @param context
     * @param reason
     * @return
     */
    private Consumer<SmsContent> buildSmsContentAction(EkycContext context, String reason) {
        String tenant = context.getEkycRequest().getTenant();
        return smsContent -> {
            smsContent.setTenant(tenant);
            smsContent.setSendType(ConstantVars.getSiteIdByTenant(tenant));
            // 成功不需要添加消息变量
            if (Objects.nonNull(reason)) {
                smsContent.setParam1(reason);
            }
            //短信类型
            smsContent.setSmstype(context.getSmsTask().getMsgType());
        };
    }

    /**
     * 构建msg消息补充器*
     *
     * @param context
     * @param reason
     * @return
     */
    private Consumer<PushContentReq> buildPushContentAction(EkycContext context, String reason) {
        return pushContent -> {
            JSONObject params = new JSONObject();
            if (Objects.nonNull(reason)) {
                params.put("{0}", reason);
            }
            //推送类型
            pushContent.setParamId(context.getPushTask().getMsgType());
            pushContent.setData(params);
        };
    }

    /**
     * 修改用户信息*
     */
    private Boolean modifyUserInfo(EkycContext context) {
        log.info("ekyc modifyUserInfo 更新T_CUSTOMERS start");
        WSCustomers result;
        WSCustomers up = Optional.ofNullable(context.getUpWsCustomers()).orElseGet(() -> {
            WSCustomers updated = WSCustomersConvert.INSTANT.convert(Optional.ofNullable(context.getOriWsCustomers()).orElseThrow(() -> {
                log.error("ekyc补充信息报错，ws不存在用户，当前用户：{}，requestId是：{}，billNo是：{},WSCustomers:{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo(), JSONObject.toJSONString(context.getOriWsCustomers()));
                throw new BusinessException(EKYC_USER_NOT_EXISTS_ERROR);
            }));
            CopyWsCustomerUtil.copy(context.getEkyc(), updated);
            return updated;
        });
        if (UserCenterSwitch.getSwitch()) {
            log.info("ekyc modifyUserInfo userCenterTemplate更新T_CUSTOMERS，request:{}", JSONObject.toJSONString(up));
            result = userCenterTemplate.completeCustomer(up);
        } else {
            log.info("ekyc modifyUserInfo wsFeignTemplate更新T_CUSTOMERS，request:{}", JSONObject.toJSONString(up));
            result = wsFeignTemplate.completeCustomer(up);
        }
        log.info("ekyc modifyUserInfo auto 更新T_CUSTOMERS end,result is {}", JSONObject.toJSONString(result));
        return true;
    }

    /**
     * 初始化消息容器*
     *
     * @param context
     * @param smsTask
     */
    private EkycContext initMsg(Supplier<Map<String, String>> productSwitchSupplier,
                                EkycContext context, EkycContext.MsgTask smsTask,
                                EkycContext.MsgTask pushTask) {
        //获取对应产线和短信模板Id
        Map<String, String> productSwitchMap = Objects.isNull(productSwitchSupplier) ? redisUtil.entries("r-0013") : productSwitchSupplier.get();
        Optional.ofNullable(productSwitchMap).filter(m -> !m.isEmpty()).ifPresentOrElse(m -> {
            context.initMsgTasks(m, smsTask, pushTask, (logInfo, format) ->
                    log.info("ekyc消息容器初始化，当前用户：{}，requestId：{}，billNo：{}，日志对象为：{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo(), format));
            log.info("ekyc消息容器初始化，触发产品：{}", JSON.toJSONString(productSwitchMap));
        }, () -> log.info("ekyc消息容器为空，当前用户：{}，requestId：{}，billNo：{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo()));
        return context;
    }


    /**
     * 执行发送短信*
     *
     * @param context
     * @param smsContentAction
     */
    private void doSendMessage(EkycContext context, Consumer<SmsContent> smsContentAction) {
        // 获取ws用户信息
        WSCustomers wsCustomers = Objects.isNull(context.getUpWsCustomers()) ? context.getOriWsCustomers() : context.getUpWsCustomers();
        Optional.ofNullable(wsCustomers).orElseThrow(() -> {
            log.error("ekyc补充信息报错，ws不存在用户，当前用户：{}，requestId是：{}，billNo是：{},WSCustomers:{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo(), JSONObject.toJSONString(wsCustomers));
            throw new BusinessException(EKYC_USER_NOT_EXISTS_ERROR);
        });
        Optional.ofNullable(wsCustomers.getPhone()).filter(StringUtils::isNotBlank).map(phone -> {
            try {
                phone = PHPDESEncrypt.getNewInstance(Constants.C66, "03").decrypt(wsCustomers.getPhone());
            } catch (Exception e) {
                throw new BusinessException(EKYC_PHONE_DECRYPT_ERROR);
            }
            return phone;
        }).ifPresentOrElse(phoneToUse -> {
            SmsContent sendSMS = new SmsContent();
            // 开始发送短信
            sendSMS.setPhone(phoneToUse);
            sendSMS.setLoginname(context.getLoginName());
            //是否使用模板:0使用，1不使用
            sendSMS.setUseTemplateFlag(ConstantVars.ZERO);
            String billNo = context.getEkycRequest().getBillNo();
            sendSMS.setRequestId(billNo);
            if (Objects.nonNull(smsContentAction)) {
                smsContentAction.accept(sendSMS);
            }
            log.info("ekyc发送短信，当前用户是：{}，requestId:{}；billNo：{}，短信请求：{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), billNo, JSONObject.toJSONString(sendSMS));
            smsApiTemplate.sendSMS(Constants.C66, sendSMS);
        }, () -> log.info("ekyc发送短信忽略，当前用户：{}，requestId：{}，billNo：{},wsCustomers:{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo(), JSONObject.toJSONString(wsCustomers)));
    }

    /**
     * 执行推送消息*
     *
     * @param context
     * @param pushContentAction
     */
    private void doPushMessage(EkycContext context, Consumer<PushContentReq> pushContentAction) {
        PushContentReq pushContentReq = new PushContentReq();
        pushContentReq.setLoginName(context.getLoginName());
        pushContentReq.setBillNo(context.getEkycRequest().getBillNo());
        if (Objects.nonNull(pushContentAction)) {
            pushContentAction.accept(pushContentReq);
        }
        log.info("ekyc推送消息，当前用户是：{}，requestId:{}；billNo：{}，push请求：{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo(), JSONObject.toJSONString(pushContentReq));
        messageApiFeign.pushMessage(pushExchange, pushRoutingKey, JSONObject.toJSONString(pushContentReq));
    }

    /**
     * 操作完成删除缓存*
     *
     * @param loginName
     */
    private void clearCache(String loginName) {
        String cacheKey = String.format(RISK_EKYC_STATUS_KEY, loginName);
        log.info("ekyc补充信息完毕，开始删除缓存key {}", cacheKey);
        redisUtil.remove(cacheKey);
        log.info("ekyc补充信息完毕，结束删除缓存key {}", cacheKey);
    }

    /**
     * 拷贝请求数据到持久层对象*
     *
     * @param context 上下文
     * @return 拷贝后的数据对象
     */
    private EkycRequest copy(EkycContext context) {
        EkycRequest ekycRequest = context.getEkycRequest();
        EkycExtendRequest ekycExtendRequest = context.getEkycExtendRequest();
        EkycRequestConvert.INSTANT.copyValidatedProperties(ekycExtendRequest, ekycRequest);
        String middleNameFromRequest = ekycExtendRequest.getMiddleName();
        if (Objects.nonNull(middleNameFromRequest) && StringUtils.isBlank(middleNameFromRequest)) {
            ekycRequest.setMiddleName(Strings.EMPTY);
        }
        return ekycRequest;
    }

    /**
     * 提供拒绝原因*
     *
     * @param action 执行器
     * @return 拒绝原因
     */
    private String supplyRejectReason(EkycContext context,BiConsumer<Map<String, Object>, String> action) {
        String rejectReasonFromConfig = StringUtils.EMPTY;
        if(BooleanUtils.isTrue(context.getDeduplicateLimit())){
            rejectReasonFromConfig = ProductConstantsLoader.obtainProductConstantRedis(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0019, ProjectConstant.EKYC_SAME_ID);
        }else if(BooleanUtils.isFalse(context.getValidateAge())){
            rejectReasonFromConfig = ProductConstantsLoader.obtainProductConstantRedis(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0019, ProjectConstant.AGE_DOES_NOT_MATCH);
        }else{
            rejectReasonFromConfig = ProductConstantsLoader.obtainProductConstantRedis(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0019, ProjectConstant.EKYC_REFUSE_AUTO_REASON);
        }
        String rejectReasonToUse = StringUtils.isBlank(rejectReasonFromConfig) ? EkycReasonEnums.EXTEND_REJECT_REASON.getDisplayMsg() : rejectReasonFromConfig;
        return CommonUtil.doAction(rejectReasonToUse, action, MapUtil.of("rejectReasonFromConfig", rejectReasonFromConfig, "rejectReasonToUse", rejectReasonToUse));
    }



    /**
     * 更新证件使用记录*
     *
     * @param context
     */
    private void doUpdateDeduplicate(EkycContext context) {
        Ekyc ekyc = context.getEkyc();
        // 更新证件使用中间表
        String idNo = ekyc.getIdNo();
        Integer idType = ekyc.getIdType();
        if (StringUtils.isNotBlank(idNo) && Objects.nonNull(idType)) {
            EkycDeduplicate ekycDeduplicate = ekycDeduplicateMapper.selectOne(new LambdaUpdateWrapper<EkycDeduplicate>()
                    .eq(EkycDeduplicate::getIdNo, idNo)
                    .eq(EkycDeduplicate::getIdType, idType));
            String loginName = context.getLoginName();
            if (Objects.isNull(ekycDeduplicate)) {
                EkycDeduplicate entity = new EkycDeduplicate();
                entity.setIdNo(idNo);
                entity.setIdType(idType);
                entity.setLoginName(loginName);
                ekycDeduplicateMapper.insert(entity);
            } else {
                Optional.ofNullable(ekycDeduplicate.getLoginName()).filter(StringUtils::isNotBlank).
                        ifPresentOrElse(bindNames -> {
                            if (Arrays.stream(bindNames.split(ConstantVars.SEMICOLON)).noneMatch(str -> str.equals(loginName))) {
                                ekycDeduplicate.setLoginName(bindNames + ConstantVars.SEMICOLON + loginName);
                                ekycDeduplicateMapper.updateById(ekycDeduplicate);
                            }
                        }, () -> {
                            ekycDeduplicate.setLoginName(loginName);
                            ekycDeduplicateMapper.updateById(ekycDeduplicate);
                        });
            }
        }
    }
}
