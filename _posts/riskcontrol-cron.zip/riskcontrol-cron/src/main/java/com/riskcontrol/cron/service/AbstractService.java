package com.riskcontrol.cron.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AbstractService {

    protected final Logger logger = LoggerFactory.getLogger("webservice_api_logger");

}
