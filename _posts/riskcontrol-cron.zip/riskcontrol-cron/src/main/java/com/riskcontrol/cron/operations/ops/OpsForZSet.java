package com.riskcontrol.cron.operations.ops;

import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * @program: riskcontrol-cron
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-11-17 11:32
 */
@Component
public class OpsForZSet extends OpsFor implements Ops {

    @Override
    public String operation() {
        return "opsForZSet";
    }

    public Boolean add(Serializable key, Object value, Double score) {
        return this.redisTemplate.opsForZSet().add(key, value, score);
    }

    public Object randomMember(Serializable key) {
        return this.redisTemplate.opsForZSet().randomMember(key);
    }
}