package com.riskcontrol.cron.utils;

import com.riskcontrol.common.config.WsCommonConfig;
import com.riskcontrol.cron.config.BusinessConfig;
import com.riskcontrol.cron.constants.CronConstant;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public final class MultiProductUtil {

    private static BusinessConfig businessConfig;

    private static WsCommonConfig wsCommonConfig;

    public MultiProductUtil(BusinessConfig businessConfig, WsCommonConfig wsCommonConfig) {
        MultiProductUtil.businessConfig = businessConfig;
        MultiProductUtil.wsCommonConfig = wsCommonConfig;
    }

    /**
     * 获取默认的productId
     *
     * @return 默认的productId
     */
    public static String getDefaultProductId() {
        return isMultiProduct() ? businessConfig.getPropertyByKey(CronConstant.MULTI_PRODUCT_SETTING) : getWsProductId(CronConstant.WS_PRODUCT_ID);
    }

    /**
     * 是否存在多例产品id
     *
     * @return 结果
     */
    public static boolean isMultiProduct() {
        return StringUtils.isNotBlank(businessConfig.getPropertyByKey(CronConstant.MULTI_PRODUCT_CONVERT));
    }


    private static String getWsProductId(String key) {
        return Optional.ofNullable(MultiProductUtil.wsCommonConfig.getWsProductId()).filter(StringUtils::isNotBlank).orElse(businessConfig.getPropertyByKey(key));
    }
}