package com.riskcontrol.cron.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.riskcontrol.cron.entity.TPbcCrawlerResultNew;

public interface TPbcCrawlerResultNewMapper extends BaseMapper<TPbcCrawlerResultNew> {
}