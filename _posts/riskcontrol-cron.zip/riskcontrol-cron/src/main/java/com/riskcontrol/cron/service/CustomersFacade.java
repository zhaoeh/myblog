package com.riskcontrol.cron.service;

import com.cn.schema.request.KycDispatchConfirmRequest;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequest;
import com.riskcontrol.common.exception.BusinessException;

import java.util.List;

/**
 * Created by Wason.H on 2018/4/6.
 * 客户信息业务层
 */
public interface CustomersFacade {
    /**
     * 派单请求
     *
     * @param riskQueryKycRequest
     * @return
     * @throws BusinessException
     */
    List<KycRequest> dispatchKycRequest(RiskQueryKycRequest riskQueryKycRequest) throws BusinessException;

    boolean checkDispatchKycRequestConfirm(KycDispatchConfirmRequest request);

    /**
     * 派单请求确认
     *
     * @param request kyc派单请求确认request
     * @return 派单请求确认结果
     * @throws BusinessException 自定义异常
     */
    Boolean dispatchKycRequestConfirm(KycDispatchConfirmRequest request) throws BusinessException;
}
