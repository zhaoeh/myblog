package com.riskcontrol.cron.operations.ops;

import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * @program: riskcontrol-cron
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-11-17 11:32
 */
@Component
public class OpsForValue extends OpsFor implements Ops{

    public void set(Serializable key, Object value) {
        redisTemplate.opsForValue().set(key, value);
    }

    public Object get(Serializable key) {
        return redisTemplate.opsForValue().get(key);
    }

    @Override
    public String operation() {
        return "opsForValue";
    }
}