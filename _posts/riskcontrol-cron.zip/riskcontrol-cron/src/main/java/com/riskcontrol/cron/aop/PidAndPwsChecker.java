//package com.riskcontrol.cron.aop;
//
//import com.riskcontrol.common.aop.AfterParams;
//import com.riskcontrol.common.aop.BeforeParams;
//import com.riskcontrol.common.aop.CommonAspectRunner;
//import com.riskcontrol.common.exception.BusinessException;
//import com.riskcontrol.cron.enums.ErrCodeEnum;
//import com.riskcontrol.cron.utils.CheckUtil;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//import org.springframework.util.ReflectionUtils;
//
//import java.lang.reflect.Field;
//import java.util.Optional;
//
///**
// * pid和pws校验器
// *
// * @program: riskcontrol-cron
// * @description: 校验pid和pws是否合法
// * @author: Erhu.Zhao
// * @create: 2023-10-24 13:57
// **/
//@Component
//public class PidAndPwsChecker implements CommonAspectRunner {
//    /**
//     * 校验工具类
//     */
//    @Autowired
//    protected CheckUtil checkUtil;
//
//    @Override
//    public Object before(BeforeParams beforeParams) throws Exception {
//        Object[] params = Optional.ofNullable(beforeParams).map(p -> p.getParams()).orElse(new Object[0]);
//        if (params.length > 0) {
//            Object paramOne = params[0];
//            Class<?> targetClass = paramOne.getClass();
//            Field infProductId = ReflectionUtils.findField(targetClass, "infProductId", String.class);
//            Field infPwd = ReflectionUtils.findField(targetClass, "infPwd", String.class);
//            ReflectionUtils.makeAccessible(infProductId);
//            ReflectionUtils.makeAccessible(infPwd);
//            String infProductIdValue = (String) ReflectionUtils.getField(infProductId, paramOne);
//            String infPwdValue = (String) ReflectionUtils.getField(infPwd, paramOne);
//            checkPidAndPwd(infProductIdValue, infPwdValue, targetClass);
//        }
//        return null;
//    }
//
//    @Override
//    public Object after(AfterParams afterParams) throws Exception {
//        return null;
//    }
//
//    /**
//     * 校验产品ID和密码是否合法
//     *
//     * @param infProductId 产品ID
//     * @param infPwd       产品密码
//     * @param clazz
//     * @throws BusinessException
//     */
//    private void checkPidAndPwd(String infProductId, String infPwd, Class clazz) throws BusinessException {
//        if (!CheckUtil.isNotEmpty(infProductId)
//                || !CheckUtil.isNotEmpty(infPwd)
//                || !checkUtil.checkPidAndPwd(infProductId, infPwd, clazz)) {
//            throw new BusinessException(ErrCodeEnum.MSG_100000);
//        }
//    }
//}
