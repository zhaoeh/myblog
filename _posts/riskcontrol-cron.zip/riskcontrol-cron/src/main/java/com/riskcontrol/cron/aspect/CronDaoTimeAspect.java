package com.riskcontrol.cron.aspect;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.date.TimeInterval;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Service;

/**
 * @program: riskcontrol-cron
 * @description: 打印接口调用时间
 * @author: Colson
 * @create: 2023-12-14 11:41
 */
@Aspect
@Service
@Slf4j
public class CronDaoTimeAspect {

    @Pointcut("execution(* com.riskcontrol.cron.mapper..*(..))")
    public void cronDaoPointCut(){

    }


    @Around(value = "cronDaoPointCut()")
    public Object aroundCronDaoMethod(ProceedingJoinPoint joinPoint) throws Throwable{
        TimeInterval timer = DateUtil.timer();
        Object obj = joinPoint.proceed();
        long timeResult = timer.interval();
        log.info("aroundCronDaoMethod location={}, timeResult={}/ms, obj = {}",
                joinPoint.getSignature().toShortString(), timeResult, StringUtils.truncate(JSONObject.toJSONString(obj),500));
        return obj;
    }

}
