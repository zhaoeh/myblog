package com.riskcontrol.cron.support;

import com.riskcontrol.common.enums.RiskFilterSourceEnum;
import com.riskcontrol.common.enums.RiskFilterStatusEnum;
import com.riskcontrol.common.enums.RiskFilterTypeEnum;
import com.riskcontrol.common.enums.RuleEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.utils.LogUtils;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.constants.ProjectConstant;
import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.engine.OriWithdrawReqContext;
import com.riskcontrol.cron.engine.WithdrawContext;
import com.riskcontrol.cron.entity.RiskFilterLog;
import com.riskcontrol.cron.service.WithdrawService;
import com.riskcontrol.cron.utils.ProductConstantsLoader;
import com.riskcontrol.cron.utils.RedisUtil;
import io.reactivex.rxjava3.core.Flowable;
import io.reactivex.rxjava3.processors.PublishProcessor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;
import java.util.function.Supplier;

import static com.riskcontrol.cron.enums.WithdrawFilterEnum.CURRENT_ENTER_MANUALLY;
import static com.riskcontrol.cron.enums.WithdrawFilterEnum.NEXT_ENTER_MANUALLY;

/**
 * @description: WithdrawServiceDelegate
 * @author: ErHu.Zhao
 * @create: 2024-09-17
 **/
@Component
@Slf4j
public class WithdrawServiceDelegate {

    @Resource(name = "withdrawExecutorService")
    private ThreadPoolExecutor executorService;

    @Resource(name = "withdrawExecutorTimeOutService")
    private ThreadPoolExecutor executorTimeOutService;

    @Resource
    private WithdrawService withdrawService;

    @Resource
    private RedisUtil redisUtil;


    /**
     * 处理取款消息
     *
     * @param req
     */
    public void handleWithdraw(OriWithdrawReq req) {
        log.info("进入[双流程]处理，正常流程和熔断流程异步进行，requestId:{}", req.getRequestId());
        // 设置风控日志记录器
        req.setContext(buildOriWithdrawReqContext());
        Map<String, String> mdcContextMap = LogUtils.getMDCContextMap();
        int out = obtainTimeOut(mdcContextMap);
        log.info("进入[双流程]处理,前置打印executorService activeCount：{} , queue size：{} ,executorTimeOutService activeCount {}，queue size：{} ，超时时间为：{}",
                executorService.getActiveCount(), executorService.getQueue().size(),
                executorTimeOutService.getActiveCount(), executorTimeOutService.getQueue().size(),
                out);
        // 正常流程全部在任务线程池中运行
        CompletableFuture<Boolean> taskFuture = CompletableFuture.supplyAsync(() -> {
            LogUtils.setMDCContextMap(mdcContextMap);
            boolean needManual = needManual(req);
            if (needManual) {
                // 转人工处理
                return buildManualTask(req);
            } else {
                // 进入正常流程
                return buildNormalTask(req);
            }
        }, executorService);

        // 熔断流程全部在超时线程池中运行
        // 使用rx监听任务，任务本身逻辑：监听taskFuture是否已经完成

        CompletableFuture.runAsync(() -> {
            LogUtils.setMDCContextMap(mdcContextMap);
            StopWatch sw = new StopWatch(mdcContextMap.get("uuid"));
            sw.start();
            try {
                // 任务完成，终止监听
                if (taskFuture.isDone() && !taskFuture.isCompletedExceptionally() && !taskFuture.isCancelled()) {
                    sw.stop();
                    log.info("[熔断流程]执行耗时为：{},  requestId :{} ,主流程执行完成，不处理熔断逻辑", sw.getTotalTimeMillis(), req.getRequestId());

                    return;
                }
                boolean needManual = needManual(req);
                if (needManual) {
                    // 转人工处理
                    buildManualTask(req);
                } else {
                    buildDowngradeTask(req);
                }
            } catch (Throwable e) {
                dispatchToGlobalException(e, req, mdcContextMap);
            }
            sw.stop();
            log.info("[熔断流程]执行耗时为：{} , requestId :{}", sw.getTotalTimeMillis(), req.getRequestId());
        }, CompletableFuture.delayedExecutor(out, TimeUnit.SECONDS, executorTimeOutService));
    }

    /**
     * 构建人工处理任务
     *
     * @param req           原始请求
     * @return 人工处理任务
     */
    private Boolean buildManualTask(OriWithdrawReq req) {
        
        OriWithdrawReqContext context = req.getContext();
        if (context.isManuallyExecuted()) {
            log.info("[进入转人工流程]处理，requestId:{}，当前消息已经被转人工处理，忽略执行", req.getRequestId());
            return true;
        }
        req.getContext().setManuallyExecuted(Boolean.TRUE);
        // 分布式锁保证幂等状态
        String lockKey = buildLockKey(CronConstant.WITHDRAW_MANUALLY_LOCK, req.getRequestId());
        boolean isLocked = false;
        boolean result = false;
        try {
            log.info("[进入转人工流程]风控取款转人工进入审批处理，requestId:{}", req.getRequestId());
            isLocked = redisUtil.tryLock(lockKey, 2, 0, TimeUnit.SECONDS);
            if (isLocked) {
                log.info("[进入转人工流程]当前消息 requestId {} 成功获取到redis锁，key：{}， 上一笔请求状态为-4，直接进入人工处理", req.getRequestId(), lockKey);
                result = withdrawService.modifyExceptionPrompt(withdrawService.weaveLogicForWithdrawContext(new WithdrawContext(), c -> {
                    c.setReq(req);
                    c.setAutoApprove(false);
                    c.setExceptionPromptType(CURRENT_ENTER_MANUALLY.getType());
                    c.setExceptionPrompt(CURRENT_ENTER_MANUALLY.getFilterMsg());
                    return c;
                }));
            }
        } finally {
            if (isLocked) {
                log.info("[进入转人工流程]当前消息 requestId {}，主动释放redis锁，key：{}", req.getRequestId(), lockKey);
                redisUtil.unLock(lockKey);
            }
        }
        return result;
    }

    /**
     * 构建正常任务
     *
     * @param req           原始请求
     * @return 正常任务
     */
    private Boolean buildNormalTask(OriWithdrawReq req) {
        log.info("[双流程][进入正常流程]当前消息 requestId {} 进入正常处理流程", req.getRequestId());
        String lockKey = buildLockKey(CronConstant.WITHDRAW_ENTER_POOL_LOCK, req.getRequestId());
        boolean isLocked = false;
        try {
            isLocked = redisUtil.tryLock(lockKey, 1, 0, TimeUnit.SECONDS);
            if (isLocked) {
                req.getContext().setEnterTaskPool(Boolean.TRUE);
            }
        } finally {
            if (isLocked) {
                redisUtil.unLock(lockKey);
            }
        }
        // 无论是否超时，都执行正常流程
        return withdrawService.withdrawRisk(req, true, false);
    }

    /**
     * 构建熔断处理任务
     *
     * @param req           原始请求
     * @return 熔断处理任务
     */
    private Boolean buildDowngradeTask(OriWithdrawReq req) {
        // 处理5s超时，超时后同时执行熔断流程
        log.info("[进入熔断流程]当前消息 requestId {} 进入超时熔断处理流程", req.getRequestId());
        return withdrawService.withdrawRiskWithDowngrade(req);
    }


    /**
     * 分发给future全局异常处理器
     *
     * @param e   future链路异常
     * @param req 取款订单请求
     * @return 异常日志记录结果
     */
    private Boolean dispatchToGlobalException(Throwable e, OriWithdrawReq req, Map<String, String> mdcContextMap) {
        LogUtils.setMDCContextMap(mdcContextMap);
        log.error("[双流程][进入异常流程]当前取款订单requestId:{}发生异常", req.getRequestId(), e);
        if (req.getContext().isIgnoreLogger()) {
            log.info("[双流程][进入异常流程]风控日志记录已经记录，本次忽略，requestId:{}", req.getRequestId());
            return true;
        }
        if (Objects.nonNull(req.getContext().getRiskFilterLogger())) {
            String message;
            if (e instanceof BusinessException) {
                message = Objects.nonNull(e.getCause()) ? e.getCause().getMessage() : e.getMessage();
            } else {
                message = e.getMessage();
            }
            log.info("[双流程][进入异常流程]开始记录风控日志，requestId:{}，error message:{}", req.getRequestId(), message);
            RiskFilterLog riskFilterLog = new RiskFilterLog();
            riskFilterLog.setFilterType(RiskFilterTypeEnum.WITHDRAW_RISK.getCode());
            riskFilterLog.setStatus(RiskFilterStatusEnum.INITIAL.getCode());
            riskFilterLog.setSource(RiskFilterSourceEnum.WITHDRAW_RISK.getCode());
            riskFilterLog.setRequestId(req.getRequestId());
            riskFilterLog.setRiskRuleAction(RuleEnum.TRANSFERRED_TO_MANUAL_REVIEW.getRuleAction());
            riskFilterLog.setErrorMsg(StringUtils.substring(message, 0, 255));
            req.getContext().getRiskFilterLogger().accept(true, true, req.getRequestId(), riskFilterLog);
            log.info("[双流程][进入异常流程]结束记录风控日志，requestId:{}，error message:{}", req.getRequestId(), message);
        }
        return true;
    }

    /**
     * 获取任务执行超时时间
     *
     * @return
     */
    private int obtainTimeOut(Map<String, String> mdcContextMap) {
        LogUtils.setMDCContextMap(mdcContextMap);
        int defaultOut = 5;
        int out = defaultOut;
        try {
            String timeOut = ProductConstantsLoader.obtainProductConstantRedis(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0014, ProjectConstant.JMS_WITHDRAW_RISK_LISTENER_TIMEOUT);
            out = Integer.valueOf(timeOut);
        } catch (Exception e) {
            log.info("JMS_WITHDRAW_RISK_LISTENER_TIMEOUT 配置无效，取默认值5秒钟");
        }
        out = out <= 0 ? defaultOut : out;
        return out;
    }

    /**
     * 当前订单是否需要转人工
     *
     * @param req 当前订单信息
     * @return 是否需要转人工 true：需要 false：无上一笔记录返回false
     */
    private Boolean needManual(OriWithdrawReq req) {
        Boolean needManual;
        log.info("[开始获取当前消息上一笔请求]风控取款 withdrawRisk 取款单requestId:{}", req.getRequestId());
        needManual = Optional.ofNullable(withdrawService.queryLastOrder(req)).map(e -> NEXT_ENTER_MANUALLY.getType().equals(e.getExceptionPromptType())).orElse(false);
        log.info("[结束获取当前消息上一笔请求]风控取款 withdrawRisk 取款单requestId:{}，needManual：{}", req.getRequestId(), needManual);
        return needManual;
    }

    /**
     * 构建任务前置后置织入器集
     *
     * @return 构建任务前置后置织入器集
     */
    private Map<Consumer<Supplier<String>>, Consumer<Supplier<String>>> buildBeginWithFinals() {
        log.info("[双流程][前置逻辑]开始构建前置后置织入器集");
        Map<Consumer<Supplier<String>>, Consumer<Supplier<String>>> beginWithFinals = new LinkedHashMap<>(128);
        Map<String, String> mdcContextMap = LogUtils.getMDCContextMap();
        if (Objects.nonNull(mdcContextMap)) {
            beginWithFinals.put(s -> LogUtils.setMDCContextMap(mdcContextMap), s -> LogUtils.cleanLogUUID());
        }
        log.info("[双流程][前置逻辑]结束构建前置后置织入器集，size:{}", beginWithFinals.size());
        return beginWithFinals;
    }

    /**
     * 构建消息上下文
     *
     * @return 消息上下文
     */
    private OriWithdrawReqContext buildOriWithdrawReqContext() {
        OriWithdrawReqContext context = new OriWithdrawReqContext();
        context.setRiskFilterLogger(withdrawService::handleRiskLog);
        if (Objects.isNull(context.getOrderChain())) {
            context.setOrderChain(new ConcurrentHashMap<>(4));
        }
        return context;
    }

    /**
     * 构建分布式锁 key
     *
     * @param prefix 前缀
     * @param id     id
     * @return key
     */
    private String buildLockKey(String prefix, String id) {
        return String.format(prefix, id);
    }

}
