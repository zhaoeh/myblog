package com.riskcontrol.cron.controller;

import com.cn.schema.products.WSProductConstants;
import com.cn.schema.products.WSQueryProductConstants;
import com.riskcontrol.common.entity.request.api.QueryRiskConstants;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.api.RiskConstantsRsp;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.cron.enums.ErrCodeEnum;
import com.riskcontrol.cron.service.TRiskConstantsService;
import com.riskcontrol.cron.utils.ProductConstantsLoader;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 产品常量配置controller
 *
 * @program: riskcontrol-cron
 * @description: 获取产品常量配置控制器
 * @author: Erhu.Zhao
 * @create: 2023-10-26 15:22
 **/
@RestController
@RequestMapping("/productConstants")
@Api("产品常量相关接口")
@Slf4j
public class ProductConsQueryController {

    @Autowired
    private TRiskConstantsService riskConstantsService;
    @Deprecated
    @ApiOperation(
            value = "产品常量列表接口",
            notes = "产品常量列表接口，返回符合条件的产品常量列表",
            response = Response.class,
            httpMethod = "POST"
    )
    @RequestMapping(method = RequestMethod.POST, value = "/queryList")
    @ResponseBody
    public Response<List<WSProductConstants>> queryProductConstants(@RequestBody WSQueryProductConstants request) throws Exception {
        try {
            Response<List<WSProductConstants>> response = new Response<>();
            response.setBody(ProductConstantsLoader.obtainProductConstantsListEnv(request));
            return response;
        } catch (BusinessException e) {
            throw e;
        } catch (Exception e) {
            log.error("{} call interface fail! msg:{}", request.getProductId(), e.getMessage(), e);
            throw new Exception(ErrCodeEnum.MSG_100002.getErrMsg());
        }
    }

    @ApiOperation(
            value = "风控常量列表接口",
            notes = "风控常量列表接口，返回符合条件的常量列表",
            response = Response.class,
            httpMethod = "POST"
    )
    @RequestMapping(method = RequestMethod.POST, value = "/queryRiskConstantsList")
    @ResponseBody
    public Response<List<RiskConstantsRsp>> queryRiskConstantsList(@RequestBody QueryRiskConstants request) throws Exception {
        try {
            Response<List<RiskConstantsRsp>> response = new Response<>();
            List<RiskConstantsRsp> constantsRsps = riskConstantsService.queryRiskConstantsList(request);
            response.setBody(constantsRsps);
            return response;
        } catch (BusinessException e) {
            throw e;
        } catch (Exception e) {
            log.error("{} call interface fail! msg:{}", request.getProductId(), e.getMessage(), e);
            throw new Exception(ErrCodeEnum.MSG_100002.getErrMsg());
        }
    }
}
