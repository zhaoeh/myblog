package com.riskcontrol.cron.convert.component;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Condition;

import java.util.Objects;

/**
 * @description: 映射器条件
 * @author: ErHu.Zhao
 * @create: 2024-10-24
 **/
public class MappingConditions {

    /**
     * 判断源字段是否为空白符*
     *
     * @param source
     * @return
     */
    @Condition
    public boolean isNotBlank(String source) {
        return StringUtils.isNotBlank(source);
    }

    /**
     * 判断源字段是否不为null*
     *
     * @param source
     * @return
     */
    @Condition
    public boolean isNotNull(Integer source) {
        return Objects.nonNull(source);
    }
}
