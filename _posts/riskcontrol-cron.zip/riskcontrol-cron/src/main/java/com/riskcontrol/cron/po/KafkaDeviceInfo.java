package com.riskcontrol.cron.po;

import com.riskcontrol.common.entity.request.device.LoginCheckRequest;
import com.riskcontrol.common.entity.request.device.RegisterSaveRequest;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * kafka消费信息
 */
@Getter
@Setter
@Accessors(chain = true)
public class KafkaDeviceInfo {
    /**
     * 设备信息的JsonString
     */
    private String deviceInfo;

    /**
     * 注册风控明细
     */
    private RegisterSaveRequest registerSaveRequest;

    /**
     * 注册的拦截类型
     */
    private Integer interceptTypeOfRegisterSaveRequest;

    /**
     * 登陆风控明细
     */
    private LoginCheckRequest loginCheckRequest;

    /**
     * 登陆是否被拦截
     */
    private Integer interceptTypeOfLoginCheckRequest;

}
