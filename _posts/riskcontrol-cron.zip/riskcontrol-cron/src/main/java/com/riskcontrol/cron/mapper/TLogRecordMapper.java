package com.riskcontrol.cron.mapper;

import com.riskcontrol.cron.entity.TLogRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 日志记录表 Mapper 接口
 * </p>
 *
 * @author Colson
 * @since 2023-10-19
 */
public interface TLogRecordMapper extends BaseMapper<TLogRecord> {

}
