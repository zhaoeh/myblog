package com.riskcontrol.cron.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigInteger;

import lombok.Data;

/**
 * kyc证件去重表
 * @author dante
 * @TableName t_kyc_deduplicate
 */
@TableName(value ="t_kyc_deduplicate")
@Data
public class TKycDeduplicate implements Serializable {
    /**
     * 
     */
    @TableId(type = IdType.AUTO)
    private BigInteger id;

    /**
     * 证件类型
     */
    private Integer idType;

    /**
     * 证件号码
     */
    private String idNo;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}