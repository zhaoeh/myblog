package com.riskcontrol.cron.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.riskcontrol.cron.entity.TKycDeduplicate;
import com.riskcontrol.cron.service.TKycDeduplicateService;
import com.riskcontrol.cron.mapper.TKycDeduplicateMapper;
import org.springframework.stereotype.Service;

/**
* @author dante
* @description 针对表【t_kyc_deduplicate(kyc证件去重表)】的数据库操作Service实现
* @createDate 2024-06-11 09:51:40
*/
@Service
public class TKycDeduplicateServiceImpl extends ServiceImpl<TKycDeduplicateMapper, TKycDeduplicate>
    implements TKycDeduplicateService {

}




