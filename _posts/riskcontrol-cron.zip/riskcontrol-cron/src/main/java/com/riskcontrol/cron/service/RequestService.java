/**
 * @Overview:提案service接口
 * @author sky.x
 * @History:
 * 2012-05-31  sky.x AOFFICE-362  【WS,OFFICE】:新增存款，取款，洗码，优惠，修正额度，额度记录分组报表功能
 */
package com.riskcontrol.cron.service;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.creditlogs.QueryDepositTransWithCheckResponse;
import com.cn.schema.creditlogs.WSQueryDepositTrans;
import com.cn.schema.customers.WSCustomers;
import com.cn.schema.request.*;

import java.math.BigDecimal;
import java.util.List;

public interface RequestService {

	// approval
	WSResponseApprove requestApprove(WSRequestsApprove wsRequestsApprove);

	boolean modifyExceptionPrompt( WSWithdrawalRequests wsWithdrawalRequests);


	/**
	 * 查询优惠报表总条数
	 *
	 * @author sky.x
	 * @param query
	 * @return WSQueryCountPAmount
	 * @throws Exception
	 */
    WSQueryCountPAmount getCountReportPromotion(WSQueryPromotionRequests query) throws Exception;



//	void createRequestBalance(WSRequestBalance requestBalance);


	/**
	 * 查询存款交易记录
	 *
	 * @param query
	 * @return
	 */
	QueryDepositTransWithCheckResponse queryDepositTransRecord(WSQueryDepositTrans query) throws Exception;

	WSQueryCountAmount queryCountWithdrawRequest(WSQueryWithdrawalRequests wsQueryWithdrawalRequest);

	/**
	 * 查询取款提案(有限字段，只查提案表，没有联表查询)
	 */
	QueryWithdrawalRequestsResponse queryWithdrawalRequestDesc(JSONObject query) throws Exception;

	BigDecimal[] getValidAccountAndWinOrLostAmount(String startTime, String endTime, String productId, String loginName);

	BigDecimal getPlayerTotalDeposit(String startTime, String endTime, String loginName);
}
