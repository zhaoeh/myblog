package com.riskcontrol.cron.utils;

import com.alibaba.fastjson.JSONObject;
import com.cm.util.common.Constants;
import com.riskcontrol.common.client.SmsApiFeign;
import com.riskcontrol.cron.component.LoggingInterceptorCommon;
import com.riskcontrol.cron.config.EncodeKeyConfig;
import com.riskcontrol.cron.config.NacosConfig;
import com.ws.SmsContent;
import com.ws.SmsContentRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author dante
 * @date 2024/03/13
 */
@Slf4j
@Component
public class SmsSendUtil {
    static String className = SmsSendUtil.class.getName();

    private static EncodeKeyConfig encodeKeyConfig;

    private static Environment environment;

    private static SmsApiFeign smsApiFeign;

    @Autowired
    public void setSmsApiFeign(SmsApiFeign smsApiFeign) {
        SmsSendUtil.smsApiFeign = smsApiFeign;
    }

    @Autowired
    public void setEncodeKeyConfig(EncodeKeyConfig encodeKeyConfig) {
        SmsSendUtil.encodeKeyConfig = encodeKeyConfig;
    }

    @Autowired
    public void setEnvironment(Environment environment) {
        SmsSendUtil.environment = environment;
    }

    /**
     * * 调用短信平台接口
     *
     * @param list
     * @return
     */
    public static String callSmsApi(List<SmsContent> list) {
        return callSmsApi(list, false);
    }

    private static String callSmsApi(List<SmsContent> list, boolean isMarket) {
        try {
            String code = "-999";
            if (CollectionUtils.isEmpty(list)) {
                log.info("SMS 发送内容list为空,不进行发送");
                return code;
            }
            String productId = list.get(0).getProductid();
            String productKey = encodeKeyConfig.getSmsSystemkey(productId);
            SmsContentRequest request = new SmsContentRequest();
            //如果是C31发送短信 如果电话是以0开头的  去掉0
            for (SmsContent content : list) {
                String phone = content.getPhone();
                if (isMultiProduct() && StringUtils.isNotBlank(phone)) {
                    if (phone.contains(Constants.COMMA_SYMBOL)) {
                        String[] split = phone.split(Constants.COMMA_SYMBOL);
                        List<String> phoneList = new ArrayList<>();
                        for (String item : split) {
                            if (item.startsWith(Constants.STR_FLAG_ZERO)) {
                                item = item.substring(1);
                            }
                            phoneList.add(item);
                        }
                        phone = StringUtils.join(phoneList, Constants.COMMA_SYMBOL);
                    } else {
                        if (phone.startsWith(Constants.STR_FLAG_ZERO)) {
                            phone = phone.substring(1);
                        }
                    }
                    content.setPhone(phone);
                    String key = content.getLoginname() + productId + productKey + content.getPhone() + content.getSmstype();// 加密方法
                    String enkey = Convert.md5Hex(key);
                    content.setKey(enkey);
                }
                // 打印短信日志
                log.info("SMS 发送内容 产品：{} 对象：{} countryCode: {} 内容：{},{},{},smstype:{},useTemplateFlag:{},key:{},customerLevel:{}", content.getProductid(), content.getLoginname(), content.getCountryCode(), content.getParam1(), content.getParam2(), content.getParam3(), content.getSmstype(), content.getUseTemplateFlag(), content.getKey(), content.getCustomerLevel());
            }
            request.setSmsContents(list);
            request.setUuid(MDC.get("qid"));
            String resultStr = smsApiFeign.sendSms(request);
            if (StringUtils.isNotEmpty(resultStr)) {
                log.info("SMS 发送短信返回数据: {}", LoggingInterceptorCommon.hideParam(resultStr));
                JSONObject jsonObject = JSONObject.parseObject(resultStr);
                code = jsonObject.getString("body");
            }
            return code;
        } catch (Exception ex) {
            log.error(className + " call sms interface fail! msg", ex);
            return "-999";
        }
    }

    private static boolean isMultiProduct() {
        String multiProductConvert = NacosConfig.getProperty(Constants.MULTI_PRODUCT_CONVERT, "", environment);
        return StringUtils.isNotBlank(multiProductConvert);
    }
}
