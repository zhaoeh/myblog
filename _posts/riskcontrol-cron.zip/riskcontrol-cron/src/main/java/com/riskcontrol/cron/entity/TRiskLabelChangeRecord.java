package com.riskcontrol.cron.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import lombok.experimental.Accessors;

/**
 * <p>
 * 用户标签绑定关系表
 * </p>
 *
 * @author Yannis
 * @since 2024-01-11
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("t_risk_label_change_record")
@Accessors(chain = true)
@ApiModel(value = "TRiskLabelChangeRecord对象", description = "用户标签绑定关系表")
public class TRiskLabelChangeRecord extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("所属产品")
    private String productId;

    @ApiModelProperty("用户ID")
    private Long customerId;

    @ApiModelProperty("用户登录名")
    private String loginName;

    @ApiModelProperty("新风控标签ID，多个逗号隔开")
    private String newRiskLabelId;

    @ApiModelProperty("新风控标签名称，多个逗号隔开")
    private String newRiskLabelName;

    @ApiModelProperty("旧风控标签ID，多个逗号隔开")
    private String oldRiskLabelId;

    @ApiModelProperty("旧风控标签名称，多个逗号隔开")
    private String oldRiskLabelName;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("创建人")
    private String createBy;

}
