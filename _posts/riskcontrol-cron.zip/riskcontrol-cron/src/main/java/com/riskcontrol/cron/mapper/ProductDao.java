package com.riskcontrol.cron.mapper;

import com.cn.schema.products.WSProducts;
import com.cn.schema.products.WSQueryProducts;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;


/**
 * 产品定义数据访问层
 *
 * @author Wason.H
 * @date 2018-02-24 16:17:48.
 */
@Repository
public interface ProductDao {

    /**
     * 查询符合条件的数量
     *
     * @param query 查询条件
     * @return Integer 符合条件的数量
     */
    Integer countByCondition(WSQueryProducts query);


    /**
     * 查询符合条件的信息分页
     *
     * @param query 查询条件
     * @return List<WSProducts> 产品定义列表
     */
    List<WSProducts> queryPageByCondition(WSQueryProducts query);


    /**
     * 根据ID查询信息
     *
     * @param primaryKeys 主键
     * @return WSProducts
     */
    WSProducts loadById(Map<String, Object> primaryKeys);


    /**
     * 修改信息.返回操作结果
     *
     * @param bean 产品定义
     * @return Integer
     */
    Integer modify(WSProducts bean);


    /**
     * 新增信息.返回操作结果
     *
     * @param bean 产品定义
     * @return Integer
     */
    Integer create(WSProducts bean);

    /**
     * 查询所有的ProductId
     *
     * @return
     */
    List<String> queryAllProductId();

    /**
     * 获取当前有效的产品列表
     *
     * @param effect_products
     * @return
     */
    List<String> queryCurrentEffectProducts(@Param("list") String[] effect_products);
}