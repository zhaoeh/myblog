package com.riskcontrol.cron.utils;

import com.riskcontrol.cron.constants.CronConstant;

import java.util.Collection;

public class CommonLogic {

    private static final String EMPTY_STRING = "";

    public static boolean isNull(Object object) {
        return object == null;
    }

    public static boolean isEmpty(Object object) {
        return isNull(object);
    }

    public static boolean isEmpty(String str) {
        return isNull(str) || EMPTY_STRING.equals(str);
    }

    public static boolean isEmpty(Object[] obj) {
        return isNull(obj) || obj.length == 0;
    }

    @SuppressWarnings("unchecked")
    public static boolean isEmpty(Collection map) {
        return isNull(map) || map.isEmpty();
    }


    public static boolean equals(Object a, Object b) {
        if (isNull(a)) {
            return isNull(b);
        }

        return a.equals(b);
    }

    /**
     * 针对mysql构建第一个分页参数
     *
     * @param pageNum  pageNum
     * @param pageSize pageSize
     * @return 针对mysql使用的pageNum
     */
    public static int buildFirstPageParamOfMySql(int pageNum, int pageSize) {
        return pageNum > 0 ? ((pageNum - 1) * pageSize) : CronConstant.PAGE_NUM;
    }

}
