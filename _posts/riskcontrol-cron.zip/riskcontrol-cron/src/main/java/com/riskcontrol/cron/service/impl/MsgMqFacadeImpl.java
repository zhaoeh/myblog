package com.riskcontrol.cron.service.impl;

import com.cn.schema.other.WSMsgMqSendRecord;
import com.cn.schema.other.WSQueryMsgMqSendRecord;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.cron.enums.ErrCodeEnum;
import com.riskcontrol.cron.service.MsgMqFacade;
import com.riskcontrol.cron.service.MsgMqService;
import com.riskcontrol.cron.utils.ValidationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * MQ消息发送记录表业务层实现类
 *
 * @author wade
 * @date 2018-08-29 09:52:47.
 */
@Service
public class MsgMqFacadeImpl implements MsgMqFacade {

    @Autowired
    private MsgMqService msgMqService;


    /**
     * 查询符合条件的信息分页
     *
     * @param query 查询条件
     * @return List<WSMsgMqSendRecord> MQ消息发送记录表列表
     * @throws BusinessException
     */
    @Override
    public List<WSMsgMqSendRecord> queryPageMsgMqByCondition(WSQueryMsgMqSendRecord query) throws BusinessException {
        return msgMqService.queryPageMsgMqByCondition(query);
    }


    /**
     * 创建信息
     *
     * @param bean 需要创建的信息
     * @return WSMsgMqSendRecord 创建后结果
     * @throws BusinessException
     */
    @Override
    public WSMsgMqSendRecord createMsgMq(WSMsgMqSendRecord bean) throws BusinessException {
        return msgMqService.createMsgMq(bean);
    }

    /**
     * 删除消息
     *
     * @param id
     * @return
     * @throws BusinessException
     */
    @Override
    public int deleteById(String id, String productId) throws BusinessException {
        ValidationUtils.checkIsNotEmpty(id, ErrCodeEnum.MSG_500046);
        ValidationUtils.checkIsNotEmpty(productId, ErrCodeEnum.MSG_403606);
        int length = id.split(",").length;
        if (length > 1000) {
            ValidationUtils.exceptionMsg(ErrCodeEnum.MSG_504318);
        }
        return msgMqService.deleteById(id, productId);
    }


}
