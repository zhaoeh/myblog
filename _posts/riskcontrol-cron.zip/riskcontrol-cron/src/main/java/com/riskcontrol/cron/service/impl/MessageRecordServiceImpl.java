package com.riskcontrol.cron.service.impl;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.request.api.PhoneNumberBlacklistCreateRequest;
import com.riskcontrol.common.entity.response.api.PhoneNumberBlacklistRsp;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.entity.BaseFullEntity;
import com.riskcontrol.cron.entity.TMessageRecord;
import com.riskcontrol.cron.entity.TPhoneNumberBlacklist;
import com.riskcontrol.cron.enums.MessageRecordStatusEnum;
import com.riskcontrol.cron.enums.PhoneNumberBlacklistStatusEnum;
import com.riskcontrol.cron.mapper.MessageRecordMapper;
import com.riskcontrol.cron.service.MessageRecordService;
import com.riskcontrol.cron.service.PhoneNumberBlacklistService;
import com.riskcontrol.cron.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 消息记录表 服务实现类
 * </p>
 *
 * @author Colson
 * @since 2023-10-16
 */
@Slf4j
@Service
public class MessageRecordServiceImpl extends ServiceImpl<MessageRecordMapper, TMessageRecord> implements MessageRecordService {

    @Resource
    private MessageRecordMapper messageRecordMapper;

    @Resource
    private PhoneNumberBlacklistService phoneNumberBlacklistService;

    @Value("${unbind.phone.number.exchange.name}")
    private String unbidPhoneNumberExchangeName;
    @Autowired
    private RedisUtil redisUtil;

    @Override
    public TMessageRecord getMessageRecordByUUID(String uuid) {
        return messageRecordMapper.selectOne(Wrappers.lambdaQuery(TMessageRecord.class)
                .eq(TMessageRecord::getContentUuid, uuid));
    }

    @Override
    public Long countByPhoneMd5AndFlag17(String phoneMd5) {
        return messageRecordMapper.selectCount(Wrappers.lambdaQuery(TMessageRecord.class)
                .eq(TMessageRecord::getPhoneMd5, phoneMd5)
                .eq(TMessageRecord::getFlag, CronConstant.MESSAGE_FLAG_MODIFY_PHONE));
    }

    @Override
    public void saveMessageRecord(String msgBody) {
        JSONObject jsonObject = JSONObject.parseObject(msgBody);
        JSONObject msgContentObj = jsonObject.getJSONObject("msgContent");
        String msgContentUUID = msgContentObj.getString("uuid");
        String productId = msgContentObj.getString("productId");
        JSONObject customerObj = msgContentObj.getJSONObject("customer");
        String customerId = customerObj.getString("customerId");
        String phoneMd5 = customerObj.getString("phoneMd5");
        TMessageRecord tMessageRecord = new TMessageRecord();
        tMessageRecord.setRoutingKey(jsonObject.getString("routingKey"));
        tMessageRecord.setContentUuid(msgContentUUID);
        tMessageRecord.setFlag(msgContentObj.getString("flag"));
        tMessageRecord.setOldValue(msgContentObj.getString("oldValue"));
        tMessageRecord.setNewValue(msgContentObj.getString("newValue"));
        tMessageRecord.setOldValueMd5(msgContentObj.getString("oldValueMd5"));
        tMessageRecord.setNewValueMd5(msgContentObj.getString("newValueMd5"));
        tMessageRecord.setProductId(productId);
        tMessageRecord.setCustomerId(customerId);
        tMessageRecord.setDomainName(customerObj.getString("domainName"));
        tMessageRecord.setIpAddress(customerObj.getString("ipAddress"));
        tMessageRecord.setUpdateBy(customerObj.getString("lastUpdatedBy"));
        tMessageRecord.setLoginName(customerObj.getString("loginName"));
        tMessageRecord.setCurrency(customerObj.getString("currency"));
        tMessageRecord.setPhone(customerObj.getString("phone"));
        tMessageRecord.setPhoneValidateStatus(customerObj.getString("phoneValidateStatus"));
        tMessageRecord.setRegisterFromType(customerObj.getString("registerFromType"));
        tMessageRecord.setSiteId(customerObj.getString("siteId"));
        tMessageRecord.setPhoneMd5(phoneMd5);
        tMessageRecord.setStatus(MessageRecordStatusEnum.TO_BE_CONSUMED.getValue());
        tMessageRecord.setExchangeName(unbidPhoneNumberExchangeName);
        tMessageRecord.setCreateBy(CronConstant.MODIFY_DEFAULT_SYSTEM);
        save(tMessageRecord);
        log.info("saveMessageRecord msgContentUUID={} saved ", msgContentUUID);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void checkMessageRecord(String msgBody) {
        JSONObject jsonObject = JSONObject.parseObject(msgBody);
        JSONObject msgContentObj = jsonObject.getJSONObject("msgContent");
        JSONObject customerObj = msgContentObj.getJSONObject("customer");
        String customerId = customerObj.getString("customerId");
        // 使用消息中的旧手机号匹配手机号码黑名单表数据
        String phoneOldValueMd5 = msgContentObj.getString("oldValueMd5");
        String oldValue = msgContentObj.getString("oldValue");
        String uuid = msgContentObj.getString("uuid");
        // 查询近180天内的手机号修改消息
        DateTime beforeHalfYearStr = DateUtil.offsetDay(new DateTime(), -180);
        Long countPhone = messageRecordMapper.selectCount(Wrappers.lambdaQuery(TMessageRecord.class)
                .eq(TMessageRecord::getOldValueMd5, phoneOldValueMd5)
                .eq(TMessageRecord::getFlag, CronConstant.MESSAGE_FLAG_MODIFY_PHONE)
                .ge(BaseFullEntity::getCreateTime, DateUtil.formatDateTime(beforeHalfYearStr))
                .le(BaseFullEntity::getCreateTime, DateUtil.now())
        );
        log.info("checkMessageRecord uuid={}, countPhone={}, beforeHalfYearStr={}", uuid, countPhone, beforeHalfYearStr);
        if (countPhone > 1) {
            // 同一个手机号修改次数大于1时，检测手机号黑名单表最后更新时间是否在180天之内
            PhoneNumberBlacklistRsp blacklistDetail = phoneNumberBlacklistService.getPhoneNumberBlacklistByPhoneMd5(phoneOldValueMd5);
            if (blacklistDetail == null || blacklistDetail.getId() == null) {
                // 180天之内更新第二次手机号码后，将该手机号加入黑名单
                PhoneNumberBlacklistCreateRequest createRequest = new PhoneNumberBlacklistCreateRequest();
                createRequest.setPhoneMd5(phoneOldValueMd5);
                createRequest.setPhone(oldValue);
                createRequest.setDataModifier(CronConstant.MODIFY_DEFAULT_SYSTEM);
                createRequest.setHistory(customerId);
                createRequest.setStatus(PhoneNumberBlacklistStatusEnum.IN_EFFECT.getValue());
                phoneNumberBlacklistService.createPhoneNumberBlacklist(createRequest);
                log.info("checkMessageRecord uuid={}, createPhoneNumberBlacklist", uuid);
            } else {
                // 手机号180天内一次以上的修改，并且黑名单表中存在该手机号码，状态改为生效中，并追加history customerId
                TPhoneNumberBlacklist tPhoneNumberBlacklist = new TPhoneNumberBlacklist();
                List<String> historyList = StrUtil.split(blacklistDetail.getHistory(), Constant.COMMA_SYMBOL);
                if (!historyList.contains(customerId)) {
                    String allHistoryStr = blacklistDetail.getHistory() + Constant.COMMA_SYMBOL + customerId;
                    if (StrUtil.length(allHistoryStr) > CronConstant.PHONE_NUMBER_BLACKLIST_HISTORY_MAXLENGTH) {
                        // history长度超过500，移除最前面的customerId后拼接
                        String subHistory = StrUtil.subAfter(allHistoryStr, ",", false);
                        tPhoneNumberBlacklist.setHistory(subHistory);
                    } else {
                        tPhoneNumberBlacklist.setHistory(allHistoryStr);
                    }
                }
                tPhoneNumberBlacklist.setStatus(PhoneNumberBlacklistStatusEnum.IN_EFFECT.getValue());
                tPhoneNumberBlacklist.setDataModifier(CronConstant.MODIFY_DEFAULT_SYSTEM);
                tPhoneNumberBlacklist.setId(blacklistDetail.getId());
                phoneNumberBlacklistService.updateById(tPhoneNumberBlacklist);
                redisUtil.remove(String.format(Constant.PHONE_BLACK_LIST_KEY, tPhoneNumberBlacklist.getPhoneMd5()));

                log.info("checkMessageRecord uuid={}, phoneNumberBlacklistService update Id={}", uuid, tPhoneNumberBlacklist);
            }
        }
        updateStatusByUUID(uuid, MessageRecordStatusEnum.CONSUMED.getValue());
    }

    @Override
    public void updateStatusByUUID(String uuid, Integer status) {
        log.info("updateStatusByUUID uuid={}, status={}", uuid, status);
        if (StrUtil.isBlank(uuid)) {
            log.info("messageRecord uuid is null");
            return;
        }
        TMessageRecord messageRecord = getMessageRecordByUUID(uuid);
        if (messageRecord == null) {
            log.info("messageRecord not exist, uuid={}", uuid);
            return;
        }
        TMessageRecord tMessageRecord = new TMessageRecord();
        tMessageRecord.setStatus(status);
        update(tMessageRecord, Wrappers.lambdaQuery(TMessageRecord.class).eq(TMessageRecord::getContentUuid, uuid));
    }

    @Override
    public TMessageRecord getFlag17AndLatestByOldPhoneMd5(String oldPhoneMd5) {
        return messageRecordMapper.selectOne(Wrappers.lambdaQuery(TMessageRecord.class)
                .eq(TMessageRecord::getOldValueMd5, oldPhoneMd5)
                .eq(TMessageRecord::getFlag, CronConstant.MESSAGE_FLAG_MODIFY_PHONE)
                .orderByDesc(BaseFullEntity::getUpdateTime)
                .last("limit 1"));
    }
}
