package com.riskcontrol.cron.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.common.entity.device.RiskActionDeviceInfo;
import com.riskcontrol.cron.mapper.RiskActionDeviceInfoMapper;
import com.riskcontrol.cron.service.RiskActionService;
import com.riskcontrol.cron.wrapper.LambdaQueryWrapperX;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Objects;

/**
 * @description: 风控设备指纹service impl
 * @author: ErHu.Zhao
 * @create: 2024-11-14
 **/
@Service
@Slf4j
public class RiskActionServiceImpl implements RiskActionService {

    @Resource
    private RiskActionDeviceInfoMapper deviceInfoMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int saveDeviceInfo(String deviceInfo) {
        log.info("risk action，准备保存设备信息：{}", deviceInfo);
        if (StringUtils.isNotBlank(deviceInfo)) {
            RiskActionDeviceInfo device = JSONObject.parseObject(deviceInfo, RiskActionDeviceInfo.class);
            log.info("risk action，保存设备信息，originStr：{}，insertStr：{}", deviceInfo, JSONObject.toJSONString(device));
            if (Objects.isNull(device) || StringUtils.isBlank(device.getConstId())) {
                // 设备信息对象为null或者设备指纹为空白，跳过保存
                return 0;
            }
            // 设备指纹id：先删后插
            deviceInfoMapper.delete(new LambdaQueryWrapperX<RiskActionDeviceInfo>().eq(RiskActionDeviceInfo::getConstId, device.getConstId()));
            return deviceInfoMapper.insert(device);
        }
        return 0;
    }
}
