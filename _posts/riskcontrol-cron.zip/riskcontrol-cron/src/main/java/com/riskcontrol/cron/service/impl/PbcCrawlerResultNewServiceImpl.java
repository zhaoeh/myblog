package com.riskcontrol.cron.service.impl;

import cn.hutool.extra.spring.SpringUtil;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.riskcontrol.common.entity.request.PbcCrawlerUpdateStatusReq;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.cron.entity.TPbcCrawlerResultNew;
import com.riskcontrol.cron.mapper.TPbcCrawlerResultNewMapper;
import com.riskcontrol.cron.service.EkycBlackForPbcService;
import com.riskcontrol.cron.service.PbcCrawlerResultNewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
public class PbcCrawlerResultNewServiceImpl extends ServiceImpl<TPbcCrawlerResultNewMapper, TPbcCrawlerResultNew> implements PbcCrawlerResultNewService {

    @Autowired
    private TPbcCrawlerResultNewMapper pbcCrawlerResultNewMapper;

    @Override
    @Transactional(rollbackFor = Throwable.class)
    public boolean updateStatus(PbcCrawlerUpdateStatusReq req) {
        var pbc = pbcCrawlerResultNewMapper.selectById(req.getId());
        if (pbc.getIsBanned() == (int) req.getIsBanned()) {
            // 如果is_banned状态没有任何改变, 则直接返回.
            return true;
        }
        pbc.setIsBanned(req.getIsBanned());
        pbc.setUpdateDate(DateUtils.getCurrentDateTime());
        var isUpdateSuccess = pbcCrawlerResultNewMapper.updateById(pbc) > 0;
        if (isUpdateSuccess) {
            SpringUtil.getBean(EkycBlackForPbcService.class).changeTRiskBlackStatusFromPBC(pbc);
        }
        return isUpdateSuccess;
    }

    @Override
    @Transactional(rollbackFor = Throwable.class)
    public List<String> insertOrUpdatePbcCrawler(TPbcCrawlerResultNew pbcCrawlerResultNew) {
        if (pbcCrawlerResultNew.getId() == null) {
            this.pbcCrawlerResultNewMapper.insert(pbcCrawlerResultNew);
        } else {
            this.pbcCrawlerResultNewMapper.updateById(pbcCrawlerResultNew);
        }
        return SpringUtil.getBean(EkycBlackForPbcService.class).changeTRiskBlackStatusFromPBC(pbcCrawlerResultNew);
    }

}
