package com.riskcontrol.cron.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.riskcontrol.common.entity.pojo.TRiskActionRegistration;
import com.riskcontrol.common.entity.request.device.RegisterCheckRequest;
import com.riskcontrol.common.entity.request.device.RegisterSaveRequest;
import com.riskcontrol.common.entity.response.device.RegisterCheckDetailResponse;
import com.riskcontrol.common.entity.response.device.RegisterCheckResponse;
import com.riskcontrol.common.enums.RiskActionInterceptTypeEnum;
import com.riskcontrol.common.enums.RiskActionTypeEnum;
import com.riskcontrol.cron.kafka.KafkaTopic;
import com.riskcontrol.cron.mapper.TRiskActionRegistrationMapper;
import com.riskcontrol.cron.po.KafkaDeviceInfo;
import com.riskcontrol.cron.service.TRiskActionLoginService;
import com.riskcontrol.cron.service.TRiskActionRegistrationService;
import com.riskcontrol.cron.utils.KafkaProductUtils;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static com.riskcontrol.common.constants.CronConstant.MODIFY_DEFAULT_SYSTEM;

@Service
public class TRiskActionRegistrationServiceImpl extends ServiceImpl<TRiskActionRegistrationMapper, TRiskActionRegistration> implements TRiskActionRegistrationService {

    @Autowired
    private TRiskActionLoginService riskActionLoginService;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private KafkaProductUtils kafkaProductUtils;

    @Override
    @SneakyThrows
    public RegisterCheckResponse registerCheck(RegisterCheckRequest registerCheckRequest) {
        // 初始化RegisterCheckResponse和KafkaDeviceInfo
        var registerCheckResponse = new RegisterCheckResponse()
                .setIsBlack(false)
                .setDetails(new RegisterCheckDetailResponse()
                        .setIsDeviceBlack(false)
                        .setIsIpBlack(false)
                );
        var kafkaDeviceInfo = new KafkaDeviceInfo()
                .setDeviceInfo(registerCheckRequest.getDeviceInfo());

        // 检查设备指纹黑名单
        if (!registerCheckResponse.getIsBlack()) {
            var isDeviceBlack = riskActionLoginService.isDeviceBlack(registerCheckRequest.getDeviceFingerprint(), registerCheckRequest.getRegisterIp(), "", registerCheckRequest.getTenant(), RiskActionTypeEnum.REGISTER);
            if (isDeviceBlack) {
                registerCheckResponse.getDetails().setIsDeviceBlack(true);
                registerCheckResponse.setIsBlack(true);

                kafkaDeviceInfo.setRegisterSaveRequest(this.objectMapper.readValue(this.objectMapper.writeValueAsString(registerCheckRequest), RegisterSaveRequest.class))
                        .setInterceptTypeOfRegisterSaveRequest(RiskActionInterceptTypeEnum.DEVICE_BLOCK.getId());
            }
        }

        // 检查ip黑名单
        if (!registerCheckResponse.getIsBlack()) {
            var isIpBlack = riskActionLoginService.isIpBlack(registerCheckRequest.getDeviceFingerprint(), registerCheckRequest.getRegisterIp(), "", registerCheckRequest.getTenant(), RiskActionTypeEnum.REGISTER);
            if (isIpBlack) {
                registerCheckResponse.getDetails().setIsIpBlack(true);
                registerCheckResponse.setIsBlack(true);

                kafkaDeviceInfo.setRegisterSaveRequest(this.objectMapper.readValue(this.objectMapper.writeValueAsString(registerCheckRequest), RegisterSaveRequest.class))
                        .setInterceptTypeOfRegisterSaveRequest(RiskActionInterceptTypeEnum.IP_BLOCK.getId());
            }
        }

        // 检查设备指纹和ip的组合黑名单
        if (!registerCheckResponse.getIsBlack()) {
            var isDeviceAndIpBlack = riskActionLoginService.isDeviceAndIpBlack(registerCheckRequest.getDeviceFingerprint(), registerCheckRequest.getRegisterIp(), "", registerCheckRequest.getTenant(), RiskActionTypeEnum.REGISTER);
            if (isDeviceAndIpBlack) {
                registerCheckResponse.getDetails()
                        .setIsDeviceBlack(true)
                        .setIsIpBlack(true);
                registerCheckResponse.setIsBlack(true);

                kafkaDeviceInfo.setRegisterSaveRequest(this.objectMapper.readValue(this.objectMapper.writeValueAsString(registerCheckRequest), RegisterSaveRequest.class))
                        .setInterceptTypeOfRegisterSaveRequest(RiskActionInterceptTypeEnum.IP_DEVICE_BLOCK.getId());
            }
        }

        // push设备信息, 注册风控明细到kafka
        kafkaProductUtils.pushKafkaMsg(KafkaTopic.DEVICE_KYC_TOPIC_SELF, this.objectMapper.writeValueAsString(kafkaDeviceInfo));

        return registerCheckResponse;
    }

    @Override
    public boolean registerSave(RegisterSaveRequest registerSaveRequest, int interceptType) {
        var riskActionRegistration = new TRiskActionRegistration();
        riskActionRegistration.setDeviceFingerprintToken(Optional.ofNullable(registerSaveRequest.getDeviceFingerprintToken()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionRegistration.setDeviceFingerprint(Optional.ofNullable(registerSaveRequest.getDeviceFingerprint()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionRegistration.setRegisterIp(Optional.ofNullable(registerSaveRequest.getRegisterIp()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionRegistration.setPhoneNumber(Optional.ofNullable(registerSaveRequest.getPhoneNumber()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionRegistration.setProductId(Optional.ofNullable(registerSaveRequest.getProductId()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionRegistration.setLoginName(Optional.ofNullable(registerSaveRequest.getLoginName()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionRegistration.setTenant(Optional.ofNullable(registerSaveRequest.getTenant()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionRegistration.setChannel(Optional.ofNullable(registerSaveRequest.getChannel()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionRegistration.setDomainName(Optional.ofNullable(registerSaveRequest.getDomainName()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionRegistration.setCreateBy(MODIFY_DEFAULT_SYSTEM);
        riskActionRegistration.setUpdateBy(MODIFY_DEFAULT_SYSTEM);
        riskActionRegistration.setInterceptType(interceptType);
        return this.save(riskActionRegistration);
    }

}
