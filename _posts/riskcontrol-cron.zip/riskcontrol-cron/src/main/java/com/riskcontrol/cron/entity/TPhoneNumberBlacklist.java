package com.riskcontrol.cron.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotBlank;

/**
 * @program riskcontrol-cron
 * @description 手机号码黑名单，部分字段名由DP指定，故不使用基类
 * @author Colson
 * @date 2023/9/26 10:30
 **/
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_phone_number_blacklist")
@ApiModel(value = "TPhoneNumberBlacklist对象", description = "手机号黑名单")
public class TPhoneNumberBlacklist extends BaseEntity{

    @ApiModelProperty("所有历史绑定的用户ID，逗号分隔，按照时间顺序增加")
    private String history;

    @ApiModelProperty("所属产品")
    private String productId;

    @ApiModelProperty("手机号码")
    private String phone;

    @ApiModelProperty("手机号码md5")
    private String phoneMd5;

    @ApiModelProperty("状态：0-失效，1-生效中")
    private Integer status;

    @ApiModelProperty("创建人")
    private String createBy;

    @ApiModelProperty("最后一次最后修改的account")
    private String dataModifier;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("最后修改时间")
    private String lastUpdateTime;

    @ApiModelProperty("备注")
    private String remarks;
}