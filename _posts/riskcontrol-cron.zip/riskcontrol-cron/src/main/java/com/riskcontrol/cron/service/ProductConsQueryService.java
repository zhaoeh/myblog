package com.riskcontrol.cron.service;

import com.cn.schema.products.WSProductConstants;
import com.cn.schema.products.WSQueryProductConstants;

import java.util.List;
import java.util.stream.Stream;

/**
 * 产品常量查询服务
 *
 * @program: riskcontrol-cron
 * @description: 产品常量查询服务接口
 * @author: Erhu.Zhao
 * @create: 2023-10-25 18:30
 **/
public interface ProductConsQueryService {

    /**
     * 根据参数获取产品常量
     *
     * @param request 请求参数
     * @return 产品常量instance
     */
    Stream<WSProductConstants> obtainProductConstants(WSQueryProductConstants request);


    /**
     * 根据参数构建产品常量请求对象，方便客户端操作
     *
     * @param productId 产品id
     * @param type      产品类型
     * @param key       产品key
     * @return 产品常量请求instance
     */
    static WSQueryProductConstants generateRequestByParams(String productId, String type, String key) {
        WSQueryProductConstants request = new WSQueryProductConstants();
        request.setProductId(productId);
        request.setType(type);
        request.setKey(key);
        return request;
    }
    /**
     * 根据参数获取产品常量
     *
     * @param request 请求参数
     * @return 产品常量instance
     */
    List<WSProductConstants> obtainProductConstantsRedis(WSQueryProductConstants request);
}
