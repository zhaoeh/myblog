package com.riskcontrol.cron.service;

import com.riskcontrol.common.entity.request.PbcCrawlerUpdateStatusReq;
import com.riskcontrol.cron.entity.TPbcCrawlerResultNew;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

public interface PbcCrawlerResultNewService extends IService<TPbcCrawlerResultNew>{

    /**
     * 解除/禁用PBC
     *
     * @return
     */
    boolean updateStatus(PbcCrawlerUpdateStatusReq req);

    /**
     * 插入或更新PBC
     * @param pbcCrawlerResultNew
     * @return loginNameList
     */
    List<String> insertOrUpdatePbcCrawler(TPbcCrawlerResultNew pbcCrawlerResultNew);
}
