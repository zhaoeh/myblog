package com.riskcontrol.cron.xxljob;

import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.cn.schema.request.QueryWithdrawalRequestsResponse;
import com.cn.schema.request.WSQueryWithdrawalRequests;
import com.cn.schema.request.WSWithdrawalRequests;
import com.riskcontrol.common.annotation.LogUUID;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.cron.service.RequestService;
import com.riskcontrol.cron.service.WithdrawService;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/8/15 15:10
 */
@Component
@Slf4j
public class PullWithdrawToApproveJob {
    @Autowired
    private RequestService requestService;
    @Resource
    private WithdrawService withdrawService;
    /**
     * 定时抓取3分钟前未经过风控审核的取款数据
     */
    @XxlJob("pullWithdrawDoRiskJob")
    @LogUUID
    public void pullWithdrawDoRiskJob() throws Exception {
        log.info("pullWithdrawDoRiskJob start");
        String param = XxlJobHelper.getJobParam();
        int beforeMinute = 3;
        int beforeBeginMinute = 6;
        boolean isRisk = false;
        if(StringUtils.isNotBlank(param)){
            JSONObject jsonParam = JSONObject.parseObject(param);
            beforeMinute = jsonParam.getInteger("beforeMinute");
            beforeBeginMinute = jsonParam.getInteger("beforeBeginMinute");
            isRisk = jsonParam.getBooleanValue("isRisk");
        }
        Date date = new Date();
        Date endDate = DateUtils.addMinutes(date, -beforeMinute);
        Date beginDate = DateUtils.addMinutes(date, -beforeBeginMinute);
        WSQueryWithdrawalRequests queryWithdrawalRequests = new WSQueryWithdrawalRequests();
        queryWithdrawalRequests.setProductId(Constant.C66_PRODUCT_ID);
        queryWithdrawalRequests.setCatalog("0;11;12;13;14;15");
        queryWithdrawalRequests.setCreatedDateBegin(DateUtil.formatDateTime(beginDate));
        queryWithdrawalRequests.setCreatedDateEnd(DateUtil.formatDateTime(endDate));
        queryWithdrawalRequests.setFlag("0;9");
        queryWithdrawalRequests.setPageSize(5000);
        queryWithdrawalRequests.setOrder("asc");
        JSONObject query = JSONObject.parseObject(JSONObject.toJSONString(queryWithdrawalRequests));
        if(!isRisk){//查询是否需要查询风控已审核的数据，默认过滤风控审核过
            query.put("exceptionPromptType","true");//true表示不查询已审核过数据
        }
        QueryWithdrawalRequestsResponse response = requestService.queryWithdrawalRequestDesc(query);
        if(Objects.isNull(response) || Objects.isNull(response.getWSWithdrawalRequests())){
            return;
        }
        List<WSWithdrawalRequests> withdrawalRequestsList = response.getWSWithdrawalRequests();
        withdrawalRequestsList.forEach(withdraw->{
            log.info("pullWithdrawDoRiskJob 循环遍历抓取的数据:{}", JSONObject.toJSONString(withdraw));
            try {
                withdrawService.sendWithToRiskMq(withdraw.getRequestId(), Constant.C66_PRODUCT_ID);
            } catch (Exception e) {
                log.error("pullWithdrawDoRiskJob error", e);
            }
        });
        log.info("pullWithdrawDoRiskJob start");
    }

}
