package com.riskcontrol.cron.engine.node;

import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.engine.WithdrawContext;
import com.yomahub.liteflow.annotation.LiteflowComponent;
import com.yomahub.liteflow.core.NodeComponent;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.math.RoundingMode;

@LiteflowComponent("calcDifferenceNode")
@Slf4j
public class CalcDifferenceNode extends AbstractWhenNode {
    @Override
    public void processWhen() throws Exception {
        WithdrawContext context = this.getFirstContextBean();
        OriWithdrawReq req = context.getReq();
        BigDecimal difference = req.getLastWithDrawalBalance()
                .add(context.getSumAmount()).add(context.getSumPromotionAmount())
                .add(context.getWinOrLostAmount()).add(context.getFixAmount()).subtract(context.getWithdrawalRequestsAmount()).subtract(context.getDstAmount()).setScale(2, RoundingMode.HALF_UP);

        context.setDifference(difference);
    }
}
