package com.riskcontrol.cron.service.impl;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.cm.util.common.Constants;
import com.cn.schema.customers.WSCustomers;
import com.cn.schema.customers.WSCustomersBank;
import com.riskcontrol.common.constants.CronConstant;
import com.riskcontrol.common.entity.pojo.Ekyc;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.request.ekyc.TRiskBlackOperation;
import com.riskcontrol.common.enums.*;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.common.utils.PHPDESEncrypt;
import com.riskcontrol.cron.constants.ConstantVars;
import com.riskcontrol.cron.convert.PbcBlackConvert;
import com.riskcontrol.cron.entity.TPbcCrawlerResultNew;
import com.riskcontrol.cron.entity.TRiskBlack;
import com.riskcontrol.cron.enums.KYCStatusEnum;
import com.riskcontrol.cron.mapper.*;
import com.riskcontrol.cron.service.EkycBlackForPbcService;
import com.riskcontrol.cron.service.EkycPbcService;
import com.riskcontrol.cron.template.WsApiFeignTemplate;
import com.riskcontrol.cron.utils.DateUtil;
import com.riskcontrol.cron.utils.RedisUtil;
import com.riskcontrol.cron.wrapper.LambdaQueryWrapperX;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.FastDateFormat;
import org.jinq.orm.stream.JinqStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.*;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import static com.riskcontrol.common.constants.Constant.RISK_IS_BLACK_KEY;
import static com.riskcontrol.common.enums.EkycStatusEnum.APPROVAL;
import static com.riskcontrol.common.enums.ResultEnum.*;
import static com.riskcontrol.cron.constants.CronConstant.MODIFY_DEFAULT_SYSTEM;
import static com.riskcontrol.cron.constants.CronConstant.ONE;

/**
 * @description: pbc黑名单service impl
 * @author: ErHu.Zhao
 * @create: 2024-10-30
 **/
@Slf4j
@Service
public class EkycBlackForPbcServiceImpl implements EkycBlackForPbcService {

    @Resource
    private EkycMapper ekycMapper;

    @Resource
    private KycRequestDao kycRequestDao;

    @Resource
    private RiskBlackMapper riskBlackMapper;

    @Resource
    private TPbcCrawlerResultNewMapper tPbcCrawlerResultNewMapper;

    @Autowired
    private EkycPbcService ekycPbcService;

    @Resource
    private WsApiFeignTemplate wsApiFeignTemplate;

    @Resource
    private RedisUtil redisUtil;

    @Resource
    private RiskBlackOperationMapper blackOperationMapper;

    @Override
    public void handleEkycBlackForPbc(String loginName, Boolean isOldKyc) {
        log.info("进入ekyc(kyc)转移黑名单，loginName：{}，isOldKyc：{}", loginName, isOldKyc);
        try {
            doHandleEkycBlackForPbc(loginName, isOldKyc);
        } finally {
            clearCache(loginName);
        }
    }

    @Override
    @SneakyThrows
    public List<String> changeTRiskBlackStatusFromPBC(TPbcCrawlerResultNew pbcCrawlerResultNew) {
        log.info("进入PBC转移黑名单, pbcId:{}, firstName:{}, middleName:{}, lastName:{}, birthDate:{}", pbcCrawlerResultNew.getId(), pbcCrawlerResultNew.getFirstName(), pbcCrawlerResultNew.getMiddleName(), pbcCrawlerResultNew.getLastName(), pbcCrawlerResultNew.getBirthDate());
        List<BlackForPbcHolder> blackForPbcHolderList = new ArrayList<>();
        // ekyc列表
        {
            var lambdaQueryWrapper = new LambdaQueryWrapper<Ekyc>();
            lambdaQueryWrapper.eq(Ekyc::getStatus, APPROVAL.getEkycStatus());
            lambdaQueryWrapper.eq(Ekyc::getFirstName, pbcCrawlerResultNew.getFirstName());
            lambdaQueryWrapper.eq(Ekyc::getLastName, pbcCrawlerResultNew.getLastName());
            lambdaQueryWrapper.eq(Ekyc::getMiddleName, pbcCrawlerResultNew.getMiddleName());
            // 政府官员 或者 生日无效, 不进行生日判断
            if (!(pbcCrawlerResultNew.getSource().equals(PbcSourceEnum.GOVT.getName()) || StringUtils.isBlank(pbcCrawlerResultNew.getBirthDate()) || FastDateFormat.getInstance(DateUtil.FMT_YYYY_MM_DD).parse(pbcCrawlerResultNew.getBirthDate()).before(FastDateFormat.getInstance(DateUtil.FMT_YYYY_MM_DD).parse("1924-01-01")))) {
                lambdaQueryWrapper.eq(Ekyc::getBirthday, pbcCrawlerResultNew.getBirthDate());
            }

            var ekycList = ekycMapper.selectList(lambdaQueryWrapper);
            blackForPbcHolderList.addAll(ekycList.stream().map(ekyc -> BlackForPbcHolder.builder().ekyc(ekyc).kycRequest(null).loginName(ekyc.getLoginName()).build()).toList());
        }
        // kyc列表.
        {
            var birthDateParam = "";
            // 政府官员 或者 生日无效, 不进行生日判断
            if (!(pbcCrawlerResultNew.getSource().equals(PbcSourceEnum.GOVT.getName()) || FastDateFormat.getInstance(DateUtil.FMT_YYYY_MM_DD).parse(pbcCrawlerResultNew.getBirthDate()).before(FastDateFormat.getInstance(DateUtil.FMT_YYYY_MM_DD).parse("1924-01-01")))) {
                birthDateParam = pbcCrawlerResultNew.getBirthDate();
            }

            var kycList = kycRequestDao.queryKycForPbcByCondition(pbcCrawlerResultNew.getFirstName(), pbcCrawlerResultNew.getMiddleName(), pbcCrawlerResultNew.getLastName(), birthDateParam, APPROVAL.getEkycStatus());
            blackForPbcHolderList.addAll(kycList.stream().map(kyc -> BlackForPbcHolder.builder().ekyc(null).kycRequest(kyc).loginName(kyc.getLoginName()).build()).toList());
        }
        // 按loginName分组去重, ekyc排在前, kyc排在后, 每组取第一个
        blackForPbcHolderList = JinqStream.from(blackForPbcHolderList)
                .group(s -> s.getLoginName(), (loginName, t) ->
                        t.sortedBy(m -> m.getEkyc() == null)
                                .findFirst()
                                .get())
                .select(s -> s.getTwo())
                .toList();
        log.info("PBC转移黑名单匹配ekyc和kyc, pbcId:{}, firstName:{}, middleName:{}, lastName:{}, birthDate:{}, matchCount:{}, hasMatchEkycOrKyc:{}", pbcCrawlerResultNew.getId(), pbcCrawlerResultNew.getFirstName(), pbcCrawlerResultNew.getMiddleName(), pbcCrawlerResultNew.getLastName(), pbcCrawlerResultNew.getBirthDate(), blackForPbcHolderList.size(), !blackForPbcHolderList.isEmpty());
        for (var blackForPbcHolder : blackForPbcHolderList) {
            doHandleTRiskBlackFromPBC(blackForPbcHolder, pbcCrawlerResultNew);
        }
        return blackForPbcHolderList.stream().map(BlackForPbcHolder::getLoginName).toList();
    }

    // 根据ekyc或kyc处理黑名单
    private void doHandleTRiskBlackFromPBC(BlackForPbcHolder blackForPbcHolder, TPbcCrawlerResultNew pbcCrawlerResultNew) {
        log.info("进入PBC转移用户黑名单, pbcId:{}, firstName:{}, middleName:{}, lastName:{}, birthDate:{}, loginName:{}, isBanned:{}", pbcCrawlerResultNew.getId(), pbcCrawlerResultNew.getFirstName(), pbcCrawlerResultNew.getMiddleName(), pbcCrawlerResultNew.getLastName(), pbcCrawlerResultNew.getBirthDate(), pbcCrawlerResultNew.getBirthDate(), pbcCrawlerResultNew.getIsBanned());
        var riskBlack = riskBlackMapper.selectOne(new LambdaQueryWrapperX<TRiskBlack>().
                eq(TRiskBlack::getLoginName, blackForPbcHolder.getLoginName()));
        if (riskBlack == null) {
            // 用户黑名单不存在, 新建用户黑名单
            riskBlack = TRiskBlack.builder().source(RiskBlackSourceEnum.PAGCOR.getCode()).loginName(blackForPbcHolder.getLoginName()).build();
            riskBlack = wrapperRiskBlackWithHit(riskBlack, blackForPbcHolder);
            riskBlack.setStatus(pbcCrawlerResultNew.getIsBanned() == PbcBannedEnum.DISABLE.getId() ? RiskBlackStatusEnum.VALID.getCode() : RiskBlackStatusEnum.INVALID.getCode());
            ekycPbcService.doInsertBlack(riskBlack);
            log.info("PBC新建用户黑名单成功, pbcId:{}, firstName:{}, middleName:{}, lastName:{}, birthDate:{}, loginName:{}, riskBlackId:{}, riskBlackStatus:{}", pbcCrawlerResultNew.getId(), pbcCrawlerResultNew.getFirstName(), pbcCrawlerResultNew.getMiddleName(), pbcCrawlerResultNew.getLastName(), pbcCrawlerResultNew.getBirthDate(), blackForPbcHolder.getLoginName(), riskBlack.getId(), riskBlack.getStatus());
            // 记录用户黑名单操作日志
            TRiskBlackOperation mainLog = TRiskBlackOperation.builder().opMode(3).status(1).operator(CronConstant.MODIFY_DEFAULT_SYSTEM).totalNo(1).successNo(1).failureNo(0).build();
            blackOperationMapper.insert(mainLog);
        } else if (riskBlack.getStatus() == RiskBlackStatusEnum.INVALID.getCode() || riskBlack.getSource() == RiskBlackSourceEnum.PAGCOR.getCode()) {
            // 当黑名单状态为0:INVALID 或者来源为pagcor, 更新用户黑名单.
            riskBlack.setStatus(pbcCrawlerResultNew.getIsBanned() == PbcBannedEnum.DISABLE.getId() ? RiskBlackStatusEnum.VALID.getCode() : RiskBlackStatusEnum.INVALID.getCode());
            riskBlack.setSource(RiskBlackSourceEnum.PAGCOR.getCode());
            riskBlack.setUpdateDate(DateUtils.getCurrentDateTime());
            riskBlack.setUpdateBy(MODIFY_DEFAULT_SYSTEM);
            this.riskBlackMapper.updateById(riskBlack);
            log.info("PBC更新用户黑名单成功, pbcId:{}, firstName:{}, middleName:{}, lastName:{}, birthDate:{}, loginName:{}, riskBlackId:{}, riskBlackStatus:{}", pbcCrawlerResultNew.getId(), pbcCrawlerResultNew.getFirstName(), pbcCrawlerResultNew.getMiddleName(), pbcCrawlerResultNew.getLastName(), pbcCrawlerResultNew.getBirthDate(), blackForPbcHolder.getLoginName(), riskBlack.getId(), riskBlack.getStatus());
            // 记录黑名单操作日志
            TRiskBlackOperation mainLog = TRiskBlackOperation.builder().opMode(3).status(1).operator(CronConstant.MODIFY_DEFAULT_SYSTEM).totalNo(1).successNo(1).failureNo(0).build();
            blackOperationMapper.insert(mainLog);
        }
    }

    private void doHandleEkycBlackForPbc(String loginName, Boolean isOldKyc) {
        log.info("ekyc(kyc)转移黑名单，loginName：{}，isOldKyc：{}", loginName, isOldKyc);
        Optional.ofNullable(loginName).filter(StringUtils::isNotBlank).map(name -> buildBlackForPbcHolder(loginName, isOldKyc)).
                ifPresentOrElse(holder -> doHandlePbcBlack(holder), () -> {
                    throw new BusinessException(EKYC_LOGIN_NAME_IS_BLANK);
                });
    }

    private BlackForPbcHolder buildBlackForPbcHolder(String loginName, Boolean isOldKyc) {

        // 查询ekyc主表，获取通过状态的记录，通过loginName带索引，从DB中查询出来，在应用中做状态判断
        Supplier<Ekyc> ekycSupplier = () -> Optional.ofNullable(ekycMapper.selectOne(Wrappers.lambdaQuery(Ekyc.class).eq(Ekyc::getLoginName, loginName))).
                filter(ekyc -> Objects.equals(APPROVAL.getEkycStatus(), ekyc.getStatus())).orElse(null);

        //查询老kyc，取最近一条通过状态的记录
        Supplier<KycRequest> kycRequestSupplier = () -> Optional.ofNullable(kycRequestDao.queryByConditionWithDesc(Map.of("loginName", loginName, "status", KYCStatusEnum.APPROVED.getKycStatus(), "order", "approved_date"))).
                orElseThrow(() -> {
                    throw new BusinessException(KYC_NOT_EXISTS_ERROR);
                });

        KycRequest kycRequest = null;
        Ekyc ekyc = null;
        if (Objects.isNull(isOldKyc)) {
            // 优先查询ekyc，如不存在，再查询老kyc提案
            ekyc = ekycSupplier.get();
            if (Objects.isNull(ekyc)) {
                kycRequest = kycRequestSupplier.get();
            }
        } else {
            if (BooleanUtils.isTrue(isOldKyc)) {
                kycRequest = kycRequestSupplier.get();
            } else {
                ekyc = ekycSupplier.get();
            }
        }
        BlackForPbcHolder holder = BlackForPbcHolder.builder().ekyc(ekyc).kycRequest(kycRequest).build();
        log.info("ekyc(kyc)转移黑名单，loginName：{}，isOldKyc：{}，holder：{}", loginName, isOldKyc, JSONObject.toJSONString(holder));
        return holder.isBothNull(() -> {
            throw new BusinessException(KYC_MOST_ONE_NULL_ERROR);
        }).bindLoginName(loginName);
    }

    /**
     * 处理ekyc pbc 黑名单*
     *
     * @param holder holder
     */
    private void doHandlePbcBlack(BlackForPbcHolder holder) {
        log.info("ekyc(kyc)转移黑名单，holder：{}", JSONObject.toJSONString(holder));
        // 根据姓名和pbc状态(禁用状态的用户)查询黑名单用户列表
        List<TPbcCrawlerResultNew> pbcList = tPbcCrawlerResultNewMapper.selectList(new LambdaQueryWrapper<TPbcCrawlerResultNew>().
                eq(TPbcCrawlerResultNew::getFirstName, holder.getFirstName()).
                eq(TPbcCrawlerResultNew::getMiddleName, holder.getMiddleName()).
                eq(TPbcCrawlerResultNew::getLastName, holder.getLastName()).
                eq(TPbcCrawlerResultNew::getIsBanned, PbcBannedEnum.DISABLE.getId()));
        log.info("ekyc(kyc)转移黑名单，准备命中pbc黑名单，holder：{}，pbcList size：{}", JSONObject.toJSONString(holder), CollectionUtils.size(pbcList));
        TRiskBlack black = initBlack(holder, pbcList, this::initBlackDelegate);
        TRiskBlackOperation mainLog = TRiskBlackOperation.builder().opMode(3).status(1).operator(CronConstant.MODIFY_DEFAULT_SYSTEM).status(1).totalNo(1).successNo(1).failureNo(0).build();
        Optional.ofNullable(wrapperRiskBlackWithHit(black, holder)).ifPresent(tRiskBlack -> {
            try {
                if (ekycPbcService.doInsertBlack(tRiskBlack)) {
                    blackOperationMapper.insert(mainLog);
                }
            } catch (Exception e) {
                mainLog.setFailureNo(1);
                mainLog.setSuccessNo(0);
                blackOperationMapper.insert(mainLog);
            }
        });
    }

    /**
     * 初始化black*
     *
     * @param holder
     * @param pbcHit
     * @return
     */
    private TRiskBlack initBlackDelegate(BlackForPbcHolder holder, TPbcCrawlerResultNew pbcHit) {
        boolean isHitPbcBlack = Objects.nonNull(pbcHit);
        Supplier<TRiskBlack> resultBlackSupplier;
        // 执行命中逻辑后，根据loginName查询黑名单表是否已经录入当前用户
        TRiskBlack existsRisk = riskBlackMapper.selectOne(Wrappers.lambdaQuery(TRiskBlack.class).eq(TRiskBlack::getLoginName, holder.getLoginName()));
        if (Objects.nonNull(existsRisk)) {
            if (isValidBlackWithSourceAndStatus(existsRisk, null, RiskBlackStatusEnum.VALID.getCode()) && isIgnoreUpdate(existsRisk, holder)) {
                // 风控黑名单已经存在当前用户，且状态有效+核心信息未变更，则跳过
                resultBlackSupplier = isHitPbcBlack ? () -> {
                    log.info("ekyc(kyc)转移黑名单，命中pbc黑名单，但该用户已经存在于风控黑名单中(状态有效且全名称生日未变化)，跳过插入，holder：{}，pbcHit：{}，existsRisk：{}", JSONObject.toJSONString(holder), JSONObject.toJSONString(pbcHit), JSONObject.toJSONString(existsRisk));
                    return null;
                } : () -> {
                    log.info("ekyc(kyc)转移黑名单，未命中pbc黑名单，但该用户已经存在于风控黑名单中(状态有效且全名称生日未变化)，跳过插入，holder：{}，existsRisk：{}", JSONObject.toJSONString(holder), JSONObject.toJSONString(existsRisk));
                    return null;
                };
            } else {
                // 否则：状态无效||核心信息变化 ；则重新开启，且设置来源
                existsRisk.setStatus(RiskBlackStatusEnum.VALID.getCode());
                resultBlackSupplier = isHitPbcBlack ? () -> {
                    existsRisk.setSource(RiskBlackSourceEnum.PAGCOR.getCode());
                    log.info("ekyc(kyc)转移黑名单，命中pbc黑名单，但该用户已经存在于风控黑名单中(状态无效或者全名称生日发生变化)，参与更新，holder：{}，pbcHit：{}，existsRisk：{}", JSONObject.toJSONString(holder), JSONObject.toJSONString(pbcHit), JSONObject.toJSONString(existsRisk));
                    return existsRisk;
                } : () -> {
                    existsRisk.setSource(RiskBlackSourceEnum.RELATION.getCode());
                    log.info("ekyc(kyc)转移黑名单，未命中pbc黑名单，但该用户已经存在于风控黑名单中(状态无效或者全名称生日发生变化)，参与更新，holder：{}，pbcHit：{}，existsRisk：{}", JSONObject.toJSONString(holder), JSONObject.toJSONString(existsRisk));
                    return existsRisk;
                };
            }
        } else {
            resultBlackSupplier = isHitPbcBlack ? () -> {
                TRiskBlack resultBlack = TRiskBlack.builder().source(RiskBlackSourceEnum.PAGCOR.getCode()).build();
                log.info("ekyc(kyc)转移黑名单，命中pbc黑名单，holder：{}，pbcHit：{}，resultBlack：{}", JSONObject.toJSONString(holder), JSONObject.toJSONString(pbcHit), JSONObject.toJSONString(resultBlack));
                return resultBlack;
            } : () -> {
                TRiskBlack resultBlack = TRiskBlack.builder().source(RiskBlackSourceEnum.RELATION.getCode()).build();
                log.info("ekyc(kyc)转移黑名单，未命中pbc黑名单，且该用户不在风控黑名单中，跳过插入，holder：{}，resultBlack：{}", JSONObject.toJSONString(holder), JSONObject.toJSONString(resultBlack));
                return null;
            };
        }
        return resultBlackSupplier.get();
    }

    /**
     * 校验风控黑名单用户是否来源于指定source以及状态是否有效*
     *
     * @param existsRisk
     * @param source
     * @param status
     * @return
     */
    private boolean isValidBlackWithSourceAndStatus(TRiskBlack existsRisk, Integer source, Integer status) {
        Objects.requireNonNull(existsRisk);
        boolean from = Objects.isNull(source) ? Boolean.TRUE : Objects.equals(source, existsRisk.getSource());
        boolean isValid = Objects.isNull(status) ? Boolean.TRUE : Objects.equals(RiskBlackStatusEnum.VALID.getCode(), existsRisk.getStatus());
        return from && isValid;
    }

    /**
     * 是否忽略更新*
     *
     * @param existsRisk
     * @param holder
     * @return
     */
    private boolean isIgnoreUpdate(TRiskBlack existsRisk, BlackForPbcHolder holder) {
        Objects.requireNonNull(existsRisk);
        Objects.requireNonNull(holder);
        return StringUtils.equals(existsRisk.getFirstName(), holder.getFirstName()) &&
                StringUtils.equals(existsRisk.getMiddleName(), holder.getMiddleName()) &&
                StringUtils.equals(existsRisk.getLastName(), holder.getLastName()) &&
                StringUtils.equals(existsRisk.getBirthday(), holder.getBirthday());
    }

    /**
     * 包装命中的黑名单实体*
     *
     * @param black
     * @param holder
     * @return
     */
    private TRiskBlack wrapperRiskBlackWithHit(TRiskBlack black, BlackForPbcHolder holder) {
        log.info("ekyc(kyc)转移黑名单，包装命中的黑名单实体，holder：{}，black：{}", JSONObject.toJSONString(holder), JSONObject.toJSONString(black));
        if (Objects.nonNull(black)) {
            KycRequest kycRequest = holder.getKycRequest();
            Ekyc ekyc = holder.getEkyc();
            Runnable transferTask = Objects.nonNull(ekyc) ? () -> PbcBlackConvert.INSTANT.copyValidatedProperties(ekyc, black) : () -> PbcBlackConvert.INSTANT.copyValidatedProperties(kycRequest, black);
            if (Objects.nonNull(black.getId())) {
                transferTask.run();
                black.setUpdateBy(MODIFY_DEFAULT_SYSTEM);
                black.setUpdateDate(null);
                log.info("ekyc(kyc)转移黑名单，包装命中的黑名单实体，black id不为空，直接参与更新，holder：{}，black：{}", JSONObject.toJSONString(holder), JSONObject.toJSONString(black));
                return black;
            }
            String loginName = holder.getLoginName();
            WSCustomers wsCustomers = null;
            String customersBank = null;
            try {
                wsCustomers = wsApiFeignTemplate.getSimpleCustomerByLoginName(Constants.C66, loginName);
                customersBank = wsApiFeignTemplate.getSimpleCustomerByBank(loginName).stream().map(WSCustomersBank::getBankAccountNo).collect(Collectors.joining(ConstantVars.SEPARATOR_COMMA));
            } catch (Exception e) {
                log.error("ekyc(kyc)转移黑名单，从ws获取用户信息/获取银行卡失败，使用kyc信息兜底，kycRequest：{}，ekyc：{}", JSONObject.toJSONString(kycRequest), JSONObject.toJSONString(ekyc), e);
            }

            if (Objects.nonNull(wsCustomers) && StringUtils.isNotBlank(wsCustomers.getLoginName())) {
                // ws返回合法有效数据，则填充ws合法数据
                PbcBlackConvert.INSTANT.copyValidatedProperties(wsCustomers, black);
                log.info("ekyc(kyc)转移黑名单，填充ws有效数据，holder：{}，black：{}，wsCustomers：{}", JSONObject.toJSONString(holder), JSONObject.toJSONString(black), JSONObject.toJSONString(wsCustomers));
            }

            // 使用ekyc或者kyc关键信息填充黑名单（注意，ws返回的核心数据在成功响应时已复制到黑名单实体中）
            transferTask.run();
            log.info("ekyc(kyc)转移黑名单，使用ekyc(kyc)数据覆盖主体信息（姓名生日等），holder：{}，black：{}", JSONObject.toJSONString(holder), JSONObject.toJSONString(black));

            black.setStatus(Integer.valueOf(ONE));
            black.setBankAccountNo(StringUtils.isNotBlank(customersBank) ? customersBank : "");
            try {
                if (StringUtils.isNotBlank(black.getPhoneNumber())) {
                    PHPDESEncrypt encrypt = PHPDESEncrypt.getNewInstance(Constants.C66, SENSITIVE_TYPE.PHONE_NO.getEncryptCode());
                    String md5Phone = DigestUtils.md5Hex(encrypt.decrypt(black.getPhoneNumber()));
                    black.setPhoneMd5(md5Phone);
                } else {
                    black.setPhoneMd5("");
                }
            } catch (Exception e) {
                log.error("ekyc(kyc)转移黑名单，解密ws手机号异常，phoneMd5默认设置空字符串", e);
                black.setPhoneMd5("");
            }
            black.setCreateBy(MODIFY_DEFAULT_SYSTEM);
            log.info("ekyc(kyc)转移黑名单，组装后的黑名单信息：{}", JSON.toJSONString(black));

            return black;
        }
        return null;
    }


    /**
     * 获取ws生日*
     *
     * @param wsCustomers
     * @return
     */
    private String getWsBirthDay(WSCustomers wsCustomers) {
        String birthday = null;
        if (Objects.nonNull(wsCustomers)) {
            birthday = StringUtils.isNotBlank(wsCustomers.getBirthday()) ? wsCustomers.getBirthday() : wsCustomers.getBirthDate();
            birthday = formatDate(birthday);
        }
        return birthday;
    }

    public static String formatDate(String dateStr) {
        if (dateStr != null && dateStr.length() >= 10) {
            return dateStr.substring(0, 10);
        } else {
            return "";
        }
    }


    /**
     * 判断当前kyc用户是否应该录入黑名单主表
     *
     * @param holder        holder
     * @param pbcRecords    pbc黑名单记录集
     * @param blackDelegate 后置操作
     * @return
     */
    private TRiskBlack initBlack(BlackForPbcHolder holder, List<TPbcCrawlerResultNew> pbcRecords,
                                 BiFunction<BlackForPbcHolder, TPbcCrawlerResultNew, TRiskBlack> blackDelegate) {
        Objects.requireNonNull(blackDelegate);
        if (CollectionUtils.isEmpty(pbcRecords)) {
            return blackDelegate.apply(holder, null);
        }

        TPbcCrawlerResultNew hitPbc;
        Predicate<TPbcCrawlerResultNew> conditionOfSource = pbc -> PbcSourceEnum.GOVT.getName().equals(pbc.getSource());
        Predicate<TPbcCrawlerResultNew> conditionOfBirthday = pbc -> StringUtils.isBlank(pbc.getBirthDate()) ||
                DateUtil.parseDateFormat(pbc.getBirthDate(), DateUtil.FMT_YYYY_MM_DD).before(DateUtil.parseDateFormat("1924-01-01", DateUtil.FMT_YYYY_MM_DD));
        Predicate<TPbcCrawlerResultNew> conditionOfKycBirthday = pbc -> Objects.equals(holder.getBirthday(), pbc.getBirthDate());
        if (pbcRecords.stream().anyMatch(conditionOfSource)) {
            // 同名pbc用户中，存在任意一个source 为 GOVT 的，当前用户即命中黑名单
            hitPbc = pbcRecords.stream().filter(conditionOfSource).findFirst().orElse(null);
            log.info("ekyc(kyc)转移黑名单，命中pbc黑名单，source存在\"GOVT\"，holder：{}，hitPbc record：{}", JSONObject.toJSONString(holder), JSONObject.toJSONString(hitPbc));
            return blackDelegate.apply(holder, hitPbc);
        } else if (pbcRecords.stream().anyMatch(conditionOfBirthday)) {
            // 否则：同名pbc用户中，存在任意一个生日为空，或者小于 1924-01-01 的用户， 当前用户即命中黑名单
            hitPbc = pbcRecords.stream().filter(conditionOfBirthday).findFirst().orElse(null);
            log.info("ekyc(kyc)转移黑名单，命中pbc黑名单，pbc黑名单中birthday不合法，holder：{}，hitPbc record：{}", JSONObject.toJSONString(holder), JSONObject.toJSONString(hitPbc));
            return blackDelegate.apply(holder, hitPbc);
        } else if (pbcRecords.stream().anyMatch(conditionOfKycBirthday)) {
            // 否则：同名pbc用户中，存在任意一个生日域当前用户匹配的，当前用户即命中黑名单
            hitPbc = pbcRecords.stream().filter(conditionOfKycBirthday).findFirst().orElse(null);
            log.info("ekyc(kyc)转移黑名单，命中pbc黑名单，pbc黑名单中birthday匹配，holder：{}，hitPbc record：{}", JSONObject.toJSONString(holder), JSONObject.toJSONString(hitPbc));
            return blackDelegate.apply(holder, hitPbc);
        } else {
            // 兜底：上述条件都不成立，则交给客户端提供命中逻辑
            return blackDelegate.apply(holder, null);
        }
    }

    /**
     * 操作完成删除缓存*
     *
     * @param loginName
     */
    private void clearCache(String loginName) {
        String cacheKey = String.format(RISK_IS_BLACK_KEY, loginName);
        log.info("ekyc(kyc)转移黑名单，开始删除缓存key {}", cacheKey);
        redisUtil.remove(cacheKey);
        log.info("ekyc(kyc)转移黑名单，结束删除缓存key {}", cacheKey);
    }

    @Builder
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    static class BlackForPbcHolder {
        private KycRequest kycRequest;
        private Ekyc ekyc;
        private String loginName;

        String getFirstName() {
            String firstName = Objects.nonNull(ekyc) ? ekyc.getFirstName() : kycRequest.getFirstName();
            return StringUtils.isBlank(firstName) ? StrUtil.EMPTY : firstName;
        }

        String getMiddleName() {
            String middleName = Objects.nonNull(ekyc) ? ekyc.getMiddleName() : kycRequest.getMiddleName();
            return StringUtils.isBlank(middleName) ? StrUtil.EMPTY : middleName;
        }

        String getLastName() {
            String lastName = Objects.nonNull(ekyc) ? ekyc.getLastName() : kycRequest.getLastName();
            return StringUtils.isBlank(lastName) ? StrUtil.EMPTY : lastName;
        }

        String getBirthday() {
            String birthday = Objects.nonNull(ekyc) ? ekyc.getBirthday() : kycRequest.getBirthday();
            return StringUtils.isBlank(birthday) ? StrUtil.EMPTY : birthday;
        }

        BlackForPbcHolder bindLoginName(String loginName) {
            this.loginName = loginName;
            return this;
        }

        /**
         * 判断两个元素是否都为null*
         *
         * @return
         */
        BlackForPbcHolder isBothNull(Runnable bothNullAction) {
            Objects.requireNonNull(bothNullAction);
            boolean isBothNull = Objects.isNull(ekyc) && Objects.isNull(kycRequest);
            if (isBothNull) {
                bothNullAction.run();
            }
            return this;
        }
    }

}
