package com.riskcontrol.cron.utils;

import org.slf4j.MDC;

import java.util.UUID;

public class LogUtils {
    public static String[] getLogTickets() {
        String[] tickets = new String[3];
        tickets[0] = MDC.get("ticket");
        tickets[1] = MDC.get("traceId");
        tickets[2] = MDC.get("spanId");
        return tickets;
    }


    public static void removeLogTickets() {
        MDC.remove("ticket");
        MDC.remove("traceId");
        MDC.remove("spanId");
    }


    public static void setLogTickets(String[] tickets) {
        MDC.put("uuid",tickets[0]);
        MDC.put("traceId", tickets[1]);
        MDC.put("spanId", tickets[2]);
    }
    public static void generatedThreadLogUUID() {
        cleanLogUUID();
        String uuid = UUID.randomUUID().toString().replaceAll("-", "");
        MDC.put("uuid", uuid);
        MDC.put("ticket",uuid);
    }
    public static void cleanLogUUID() {
        MDC.remove("uuid");
        MDC.remove("ticket");
    }
}
