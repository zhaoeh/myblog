package com.riskcontrol.cron.support;

import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.concurrent.Callable;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * @description: 任务环绕器，begin周期织入初始化逻辑，finally部分织入结束逻辑
 * @author: ErHu.Zhao
 * @create: 2024-09-21
 **/
public class TaskAround {

    /**
     * 环绕Runnable任务
     *
     * @param task             runnable task
     * @param taskDescSupplier 任务描述供应器
     * @param beginWithFinals  前置后置织入器集
     * @return runnable task
     */
    public static Runnable aroundRunnable(Runnable task, Supplier<String> taskDescSupplier, Map<Consumer<Supplier<String>>, Consumer<Supplier<String>>> beginWithFinals) {
        return () -> {
            List<Consumer<Supplier<String>>> finals = null;
            try {
                finals = acceptBegins(taskDescSupplier, beginWithFinals);
                task.run();
            } finally {
                acceptFinals(taskDescSupplier, finals);
            }
        };
    }

    /**
     * 环绕Callable任务
     *
     * @param task            Callable task
     * @param taskDescSupplier 任务描述供应器
     * @param beginWithFinals 前置后置织入器集
     * @param <T>             入参泛型
     * @return Callable task
     */
    public static <T> Callable<T> aroundCallable(Callable<T> task, Supplier<String> taskDescSupplier, Map<Consumer<Supplier<String>>, Consumer<Supplier<String>>> beginWithFinals) {
        return () -> {
            List<Consumer<Supplier<String>>> finals = null;
            try {
                finals = acceptBegins(taskDescSupplier, beginWithFinals);
                return task.call();
            } finally {
                acceptFinals(taskDescSupplier, finals);
            }
        };
    }

    /**
     * 环绕Supplier任务
     *
     * @param task            Supplier task
     * @param taskDescSupplier 任务描述供应器
     * @param beginWithFinals 前置后置织入器集
     * @param <T>             入参泛型
     * @return Supplier task
     */
    public static <T> Supplier<T> aroundSupply(Supplier<T> task, Supplier<String> taskDescSupplier, Map<Consumer<Supplier<String>>, Consumer<Supplier<String>>> beginWithFinals) {
        return () -> {
            List<Consumer<Supplier<String>>> finals = null;
            try {
                finals = acceptBegins(taskDescSupplier, beginWithFinals);
                return task.get();
            } finally {
                acceptFinals(taskDescSupplier, finals);
            }
        };
    }

    /**
     * 环绕Function任务
     *
     * @param task            Function task
     * @param taskDescSupplier 任务描述供应器
     * @param beginWithFinals 前置后置织入器集
     * @param <T>             入参泛型
     * @param <R>             出参泛型
     * @return Function task
     */
    public static <T, R> Function<T, R> aroundFunction(Function<T, R> task, Supplier<String> taskDescSupplier, Map<Consumer<Supplier<String>>, Consumer<Supplier<String>>> beginWithFinals) {
        return (T t) -> {
            List<Consumer<Supplier<String>>> finals = null;
            try {
                finals = acceptBegins(taskDescSupplier, beginWithFinals);
                return task.apply(t);
            } finally {
                acceptFinals(taskDescSupplier, finals);
            }
        };
    }

    /**
     * 执行初始化织入逻辑
     *
     * @param taskDescSupplier        任务描述供应器
     * @param beginWithFinals 前置后置织入器集
     * @return 后置织入器集
     */
    private static List<Consumer<Supplier<String>>> acceptBegins(Supplier<String> taskDescSupplier, Map<Consumer<Supplier<String>>, Consumer<Supplier<String>>> beginWithFinals) {
        if (CollectionUtils.isEmpty(beginWithFinals)) {
            return null;
        }
        List<Consumer<Supplier<String>>> finals = new ArrayList<>();
        beginWithFinals.forEach((k, v) -> {
            if (Objects.nonNull(k)) {
                k.accept(taskDescSupplier);
            }
            if (Objects.nonNull(v)) {
                finals.add(v);
            }
        });
        return finals.size() > 0 ? finals : null;
    }

    /**
     * 执行结束织入逻辑
     *
     * @param taskDescSupplier 任务描述供应器
     * @param finals           后置织入器集
     */
    private static void acceptFinals(Supplier<String> taskDescSupplier, List<Consumer<Supplier<String>>> finals) {
        if (Objects.nonNull(finals)) {
            Iterator<Consumer<Supplier<String>>> f = finals.iterator();
            while (f.hasNext()) {
                f.next().accept(taskDescSupplier);
            }
        }
    }
}
