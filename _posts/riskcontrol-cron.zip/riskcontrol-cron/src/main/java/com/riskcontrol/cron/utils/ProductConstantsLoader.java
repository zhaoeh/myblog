package com.riskcontrol.cron.utils;

import cn.hutool.core.util.StrUtil;
import com.cn.schema.products.WSProductConstants;
import com.cn.schema.products.WSQueryProductConstants;
import com.riskcontrol.cron.service.ProductConsQueryService;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @program: riskcontrol-cron
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-10-27 09:57
 **/
@Component
public class ProductConstantsLoader {

    private static ProductConsQueryService productConsQueryService;

    public ProductConstantsLoader(ProductConsQueryService productConsQueryService) {
        ProductConstantsLoader.productConsQueryService = productConsQueryService;
    }

    /**
     * 根据条件查询产品常量集合，取自redis
     *
     * @param request 请求对象
     * @return 产品常量集合
     */
    public static List<WSProductConstants> obtainProductConstantsListRedis(WSQueryProductConstants request) {
        return ProductConstantsLoader.productConsQueryService.obtainProductConstantsRedis(request);
    }
    /**
     * 根据条件查询产品常量集合,取自nacos配置
     *
     * @param request 请求对象
     * @return 产品常量集合
     */
    public static List<WSProductConstants> obtainProductConstantsListEnv(WSQueryProductConstants request) {
        return ProductConstantsLoader.productConsQueryService.obtainProductConstants(request).collect(Collectors.toList());
    }
    /**
     * 根据产品id，type，key获取产品常量的value,取自redis
     *
     * @param productId productId
     * @param type      type
     * @param key       key
     * @return value
     */
    public static String obtainProductConstantRedis(String productId, String type, String key) {
        List<WSProductConstants> constantsRedis = productConsQueryService.obtainProductConstantsRedis(ProductConsQueryService.generateRequestByParams(productId, type, key));
        if (CollectionUtils.isEmpty(constantsRedis)){
            return StrUtil.EMPTY;
        }else {
            return constantsRedis.stream().findFirst().get().getValue();
        }
    }
    /**
     * 根据产品id，type，key获取产品常量的value,取自nacos配置
     *
     * @param productId productId
     * @param type      type
     * @param key       key
     * @return value
     */
    public static String obtainProductConstantEnv(String productId, String type, String key) {
        return productConsQueryService.obtainProductConstants(ProductConsQueryService.generateRequestByParams(productId, type, key)).findFirst().get().getValue();
    }
}
