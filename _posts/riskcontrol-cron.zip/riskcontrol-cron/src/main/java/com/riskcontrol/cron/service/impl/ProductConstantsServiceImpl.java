//package com.riskcontrol.cron.service.impl;
//
//import com.cn.schema.products.WSProductConstants;
//import com.cn.schema.products.WSQueryProductConstants;
//import com.riskcontrol.common.exception.BusinessException;
//import com.riskcontrol.cron.constants.CronConstant;
//import com.riskcontrol.cron.enums.BakErrCodeEnum;
//import com.riskcontrol.cron.enums.ErrCodeEnum;
//import com.riskcontrol.cron.mapper.ProductConstantDao;
//import com.riskcontrol.cron.service.ProductConstantsService;
//import com.riskcontrol.cron.utils.RedisUtil;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.cache.annotation.CacheEvict;
//import org.springframework.cache.annotation.Cacheable;
//import org.springframework.cache.annotation.Caching;
//import org.springframework.stereotype.Service;
//import org.springframework.util.CollectionUtils;
//import org.springframework.util.StringUtils;
//
//import java.util.List;
//import java.util.Map;
//import java.util.Objects;
//import java.util.Optional;
//
//@Service
//@Slf4j
//public class ProductConstantsServiceImpl implements ProductConstantsService {
//    @Autowired
//    private ProductConstantDao productConstantDao;
//    @Autowired
//    private RedisUtil redisUtil;
//
//    @Override
//    @Cacheable(cacheNames = CronConstant.CACHE_NAME_PRODUCT_CONSTANTS, key = "#productId +'_'+ #pType+'_' +#pKey")
//    public String getValueByKey(String pType, String pKey, String productId) {
//        return productConstantDao.getValueByKey(pType, pKey, productId);
//    }
//
//    @Override
//    public String loadValueOnlyByKey(String productId, String pKey) throws BusinessException {
//        if (StringUtils.hasText(productId) && StringUtils.hasText(pKey)) {
//            WSQueryProductConstants query = new WSQueryProductConstants();
//            query.setProductId(productId);
//            query.setKey(pKey);
//            List<WSProductConstants> wsProductConstants = productConstantDao.queryPageByCondition(query);
//            if (CollectionUtils.isEmpty(wsProductConstants)) {
//                log.error("产品:" + productId + " 常量key:" + pKey + "不存在！");
//                return "";
//            }
//            return Optional.ofNullable(wsProductConstants.get(0).getValue()).orElseThrow(() -> new BusinessException(BakErrCodeEnum.PRODUCT_CONSTANTS_NOT_EXISTS));
//        }
//        throw new BusinessException(ErrCodeEnum.MSG_500000);
//    }
//
//    @Override
//    @Cacheable(cacheNames = CronConstant.CACHE_NAME_PRODUCT_CONSTANTS, key = "#map['productId'] + '_' + #map['types']")
//    public List<WSProductConstants> getAgLineAndRate(Map map) {
//        return productConstantDao.getAgLineAndRate(map);
//    }
//
//    @Override
//    @Caching(evict = {
//            @CacheEvict(cacheNames = CronConstant.CACHE_NAME_PRODUCT_CONSTANTS, key = "#bean.productId +'_'+ #bean.type+'_' +#bean.key"),
//            @CacheEvict(cacheNames = CronConstant.CACHE_NAME_PRODUCT_CONSTANTS, key = "#bean.productId+'_0003,0005,0006'"),
//            @CacheEvict(cacheNames = CronConstant.CACHE_NAME_PRODUCT_CONSTANTS, key = "#bean.productId + '_' + #bean.key")
//    })
//    public Integer create(WSProductConstants bean) {
//        return productConstantDao.create(bean);
//    }
//
//    @Override
//    public Integer modify(WSProductConstants bean) {
//        return productConstantDao.modify(bean);
//    }
//
//    @Override
//    public Integer delete(String primaryKey) {
//        WSProductConstants bean = productConstantDao.loadById(primaryKey);
//        if (Objects.nonNull(bean)) {
//            redisUtil.remove(CronConstant.CACHE_NAME_PRODUCT_CONSTANTS + "::" + bean.getProductId() + "_" + bean.getType() + "_" + bean.getKey());
//            redisUtil.remove(CronConstant.CACHE_NAME_PRODUCT_CONSTANTS + "::" + bean.getProductId() + "_0003,0005,0006");
//            redisUtil.remove(CronConstant.CACHE_NAME_PRODUCT_CONSTANTS + "::" + bean.getProductId() + "_" + bean.getKey());
//        }
//        return productConstantDao.delete(primaryKey);
//    }
//
//    @Cacheable(cacheNames = CronConstant.CACHE_NAME_PRODUCT_CONSTANTS, key = "#request.productId + '_' + #request.type+'_' + #request.key")
//    @Override
//    public List<WSProductConstants> queryByCondition(WSQueryProductConstants request) {
//        return productConstantDao.queryPageByCondition(request);
//    }
//}
