package com.riskcontrol.cron.utils;


import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.cron.enums.ErrCodeEnum;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author sanco
 */
public class ValidationUtils {
    private final static Logger logger = LoggerFactory.getLogger("webservice_api_logger");

    /**
     * 整数正则
     **/
    private static Pattern INTEGER_PATTERN = Pattern.compile("^-?(([1-9]\\d*$)|0)");

    /**
     * 日期正则
     **/
    private static Pattern DATE_TIME_PATTERN = Pattern.compile("^(?:(?!0000)[0-9]{4}-(?:(?:0[1-9]|1[0-2])-(?:0[1-9]|1[0-9]" +
            "|2[0-8])|(?:0[13-9]|1[0-2])-(?:29|30)|(?:0[13578]|1[02])-31)|(?:[0-9]{2}(?:0[48]|[2468][048]|[13579][26])|(?:0[48]|" +
            "[2468][048]|[13579][26])00)-02-29) (20|21|22|23|[0-1]?\\d):[0-5]?\\d:[0-5]?\\d$");


    /**
     * 数字正则 包含小数 小数位只能为零  例如 20.00
     **/

    /**
     * 检查对象是否为空:为空则抛出异常
     *
     * @throws BusinessException
     */
    public static void checkIsNull(Object obj, ErrCodeEnum errCodeEnum, Object... values) throws BusinessException {
        if (null == obj) {
            exceptionMsg(errCodeEnum, values);
        }
    }

    /**
     * 检查字符串是否为空,为空则抛出异常
     *
     * @throws BusinessException
     */
    public static void checkStrIsEmpty(String str, ErrCodeEnum errCodeEnum) throws BusinessException {
        if (StringUtils.isBlank(str)) {
            exceptionMsg(errCodeEnum);
        }
    }


    /**
     * 校验不允许为空：为空就报错
     * {@code value} 为空或{@code ""} ,抛出异常：{@code CrownOASException}
     *
     * @param value       值
     * @param errCodeEnum 错误码s
     * @throws BusinessException 检查异常
     */
    public static void checkIsNotEmpty(String value, ErrCodeEnum errCodeEnum) throws BusinessException {
        if (StringUtils.isBlank(value)) {
            exceptionMsg(errCodeEnum);
        }
    }


    /**
     * <p>
     * 对可选的参数是否为整数校验： <br/>
     * 如果传入的值为空则不校验，否则校验是否为整数字符串
     * </p>
     * 可以代替 CheckUtil.checkIsIntNumber(String) 部分功能
     *
     * @param value 校验的值
     * @throws BusinessException 不通过则抛出异常
     */
    public static void optionalIsIntNumber(String value, ErrCodeEnum errCodeEnum) throws BusinessException {
        if (StringUtils.isNotBlank(value)) {
            Matcher matcher = INTEGER_PATTERN.matcher(value);
            if (!matcher.matches()) {
                exceptionMsg(errCodeEnum);
            }
        }
    }


    /**
     * <p>
     * 对可选的参数的日期格式校验:<br/>
     * 如果传入的值为空则不校验,否则校验值是否合法的日期格式:yyyy-MM-dd HH:mm:ss
     * </p>
     *
     * @param value       值
     * @param errCodeEnum 错误码
     * @throws BusinessException
     */
    public static void optionalCheckDateFormat(String value, ErrCodeEnum errCodeEnum) throws BusinessException {
        if (StringUtils.isNotBlank(value)) {
            Matcher matcher = DATE_TIME_PATTERN.matcher(value);
            if (!matcher.matches()) {
                exceptionMsg(errCodeEnum);
            }
        }
    }

    /**
     * 校验失败的异常信息的处理
     *
     * @param errCodeEnum 错误枚举
     * @throws BusinessException
     */
    public static void exceptionMsg(ErrCodeEnum errCodeEnum, Object... values) throws BusinessException {
        String errMsg = errCodeEnum.getErrMsg(values);
        logger.info(errMsg);
        throw new BusinessException(errCodeEnum);
    }

    /**
     * 校验必填参数是否合法
     *
     * @param val
     * @throws BusinessException
     */
    public static void checkRequiredValue(Object val) throws BusinessException {
        logger.info("checkRequiredValue:val{}", val);
        if (Objects.isNull(val)) {
            exceptionMsg(ErrCodeEnum.MSG_500000, "val is null");
        }
        if (String.class.isInstance(val) && StringUtils.isBlank(val.toString())) {
            exceptionMsg(ErrCodeEnum.MSG_500000, "val is null");
        }
    }

    public static void checkDateRange(String begin, String end, ErrCodeEnum errCodeEnum) throws BusinessException {
        if (DateUtil.between4StringDate(begin, end) > 31) {
            exceptionMsg(errCodeEnum);
        }
    }

}
