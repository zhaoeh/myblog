package com.riskcontrol.cron.xxljob;

import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.nacos.shaded.com.google.common.collect.Lists;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.cm.util.common.Constants;
import com.cn.schema.customers.WSCustomers;
import com.cn.schema.customers.WSKycRequestProcessLog;
import com.riskcontrol.common.annotation.LogUUID;
import com.riskcontrol.common.config.UserCenterSwitch;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.pojo.Ekyc;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.enums.EkycStatusEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.service.UserCenterTemplate;
import com.riskcontrol.common.service.WsFeignTemplate;
import com.riskcontrol.common.utils.CopyWsCustomerUtil;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.entity.PagcorRecord;
import com.riskcontrol.cron.entity.RiskKycRequest;
import com.riskcontrol.cron.entity.TPbcCrawlerResultNew;
import com.riskcontrol.cron.mapper.EkycMapper;
import com.riskcontrol.cron.mapper.KycRequestDao;
import com.riskcontrol.cron.service.KycRequestProcessLogService;
import com.riskcontrol.cron.service.PbcCrawlerResultNewService;
import com.riskcontrol.cron.utils.RedisUtil;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.annotation.XxlJob;
import com.xxl.job.core.util.DateUtil;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static com.riskcontrol.cron.constants.CronConstant.WAIT_PBC_KEY;

/**
 * @author: sanji
 * @desc: 抓取pagcor黑名单数据，更新pbc状态
 * @date: 2024/6/3 10:12
 */
@Component
@Slf4j
@RestController
public class EkycRetryUpdateWsJob {
    @Resource
    private EkycMapper ekycMapper;
    @Resource
    private UserCenterTemplate userCenterTemplate;
    @Resource
    private WsFeignTemplate wsFeignTemplate;
    @XxlJob("ekycRetryUpdateWsJob")
    public void ekycRetryUpdateWsJob(){

        String param = XxlJobHelper.getJobParam();
        if(StringUtils.isNotBlank(param)){
            log.info("重新同步{}已通过ekyc数据到ws",param);
            List<Ekyc> ekycs = ekycMapper.selectList(Wrappers.lambdaQuery(Ekyc.class)
                    .ge(Ekyc::getUpdateDate, param + " 00:00:00")
                    .le(Ekyc::getUpdateDate, param + " 23:59:59")
                    .eq(Ekyc::getStatus, EkycStatusEnum.APPROVAL.getEkycStatus()));
            log.info("重新同步{}已通过ekyc数据到ws,查询到通过的ekyc数量：{}",param,ekycs.size());
            if(!CollectionUtils.isEmpty(ekycs)){
                for(Ekyc ekyc : ekycs){
                    try{
                        //只同步重要信息
                        WSCustomers ws = new WSCustomers();
                        ws.setProductId(Constant.C66_PRODUCT_ID);
                        CopyWsCustomerUtil.copy(ekyc,ws);
                        WSCustomers result;
                        if (UserCenterSwitch.getSwitch()) {
                            log.info("ekyc modifyUserInfo userCenterTemplate更新T_CUSTOMERS，request:{}", JSONObject.toJSONString(ws));
                            result = userCenterTemplate.completeCustomer(ws);
                        } else {
                            log.info("ekyc modifyUserInfo wsFeignTemplate更新T_CUSTOMERS，request:{}", JSONObject.toJSONString(ws));
                            result = wsFeignTemplate.completeCustomer(ws);
                        }
                        log.info("ekyc modifyUserInfo auto 更新T_CUSTOMERS end,result is {}", JSONObject.toJSONString(result));
                    }catch (Exception e){
                        log.error("ekycRetryUpdateWsJob error",e);
                    }
                }
            }
            log.info("重新同步{}已通过ekyc数据到ws,完成",param);
        }
    }

}
