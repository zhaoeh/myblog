package com.riskcontrol.cron.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.pojo.TRiskActionRegistration;
import com.riskcontrol.common.entity.request.device.RegisterCheckRequest;
import com.riskcontrol.common.entity.request.device.RegisterSaveRequest;
import com.riskcontrol.common.entity.response.device.RegisterCheckResponse;

public interface TRiskActionRegistrationService extends IService<TRiskActionRegistration> {

    RegisterCheckResponse registerCheck(RegisterCheckRequest registerCheckRequest);

    boolean registerSave(RegisterSaveRequest registerSaveRequest, int interceptType);

}