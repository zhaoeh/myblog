package com.riskcontrol.cron.utils;

import com.alibaba.fastjson.JSONObject;

/**
 * @program: riskcontrol-cron
 * @description: 用户派单配置helper
 * @author: Erhu.Zhao
 * @create: 2023-11-16 09:56
 */
public class CustomConfigurationHelper {

    /**
     * 获取kyc配置
     *
     * @param customConfiguration 用户派单配置对象
     * @return kyc派单配置
     */
    public static JSONObject obtainKycConfiguration(JSONObject customConfiguration) {
        return customConfiguration.getJSONObject("kyc");
    }

    /**
     * 获取withdraw配置
     *
     * @param customConfiguration 用户派单配置对象
     * @return withdraw派单配置
     */
    public static JSONObject obtainWithdrawConfiguration(JSONObject customConfiguration) {
        return customConfiguration.getJSONObject("withdraw");
    }

    /**
     * 获取queryKey
     *
     * @param customConfiguration 用户派单配置对象
     * @return 查询key
     */
    public static String obtainQueryKey(JSONObject customConfiguration) {
        return customConfiguration.getString("queryKey");
    }

    /**
     * 获取redis key
     *
     * @param content 用户派单配置实体
     * @return redis key
     */
    public static String obtainRedisKey(JSONObject content) {
        return content.getString("redisKey");
    }

    /**
     * 获取hash key
     *
     * @param content 用户派单配置实体
     * @return hash key
     */
    public static String obtainHashKey(JSONObject content) {
        return content.getString("hashKey");
    }

    /**
     * 获取hash value
     *
     * @param content 用户派单配置实体
     * @return hash value
     */
    public static Object obtainHashValue(JSONObject content) {
        return content.get("hashValue");
    }
}