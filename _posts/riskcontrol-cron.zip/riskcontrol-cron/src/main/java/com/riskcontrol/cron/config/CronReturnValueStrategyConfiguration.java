package com.riskcontrol.cron.config;

import com.riskcontrol.common.config.ReturnValueStrategyConfiguration;
import com.riskcontrol.common.entity.response.Response;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor;

import java.util.HashMap;
import java.util.Map;

/**
 * @program: riskcontrol-cron
 * @description: cron服务controller返回对象统一包装处理配置
 * @author: Erhu.Zhao
 * @create: 2023-12-01 16:12
 */
@Component
public class CronReturnValueStrategyConfiguration implements ReturnValueStrategyConfiguration {

    @Override
    public boolean supportsDoThis() {
        return true;
    }

    @Override
    public Map<String, ReturnValueStrategy> replacedHandlerAndStrategy() {
        Map<String, ReturnValueStrategy> target = new HashMap<>(12);
        target.put(RequestResponseBodyMethodProcessor.class.getName(), this::handleReturnValue);
        return target;
    }

    private Object handleReturnValue(Object returnValue) {
        if (Response.class.isInstance(returnValue) || ResponseEntity.class.isInstance(returnValue)) {
            return returnValue;
        }
        return Response.body(returnValue);
    }
}