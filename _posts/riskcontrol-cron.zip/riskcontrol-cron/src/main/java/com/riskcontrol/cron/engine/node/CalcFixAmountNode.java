package com.riskcontrol.cron.engine.node;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.date.TimeInterval;
import com.cn.schema.creditlogs.WSCreditLogs;
import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.engine.WithdrawContext;
import com.riskcontrol.cron.service.CreditLogService;
import com.yomahub.liteflow.annotation.LiteflowComponent;
import com.yomahub.liteflow.core.NodeComponent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.List;

/**
 * 查询额度修正金额
 * @author dante
 */
@LiteflowComponent("calcFixAmountNode")
@Slf4j
public class CalcFixAmountNode extends AbstractWhenNode {
    @Autowired
    private CreditLogService creditLogService;
    @Override
    public void processWhen() throws Exception {
        WithdrawContext context = this.getFirstContextBean();
        OriWithdrawReq req = context.getReq();

        TimeInterval timer = DateUtil.timer();
        BigDecimal fixAmount = BigDecimal.ZERO;

        com.cn.schema.creditlogs.WSQueryCreditLogs creditLogs = new com.cn.schema.creditlogs.WSQueryCreditLogs();
        creditLogs.setProductId(req.getProductId());
        creditLogs.setLoginName(req.getLoginName());
        creditLogs.setCreatedDateBegin(req.getLastWithDrawalDate());
        creditLogs.setCreatedDateEnd(req.getCreatedDate());
        creditLogs.setTransCode("111301;111300");
        creditLogs.setPageSize(5000);
        List<WSCreditLogs> creditLogsList = creditLogService.getCreditLogs(creditLogs);
        log.info("取款申请withdrawRisk loginName:{} getCreditLogs Timer {} ms", req.getLoginName(), timer.intervalRestart());
        for (WSCreditLogs creditLog : creditLogsList) {
            if (creditLog.getTransCode().equals("111301")) {
                fixAmount = fixAmount.add(new BigDecimal(creditLog.getAmount()));
            }
            if (creditLog.getTransCode().equals("111300")) {
                fixAmount = fixAmount.subtract(new BigDecimal(creditLog.getAmount()));
            }
        }
        context.setFixAmount(fixAmount);
    }
}
