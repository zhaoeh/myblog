package com.riskcontrol.cron.engine;

import com.cn.schema.products.WSProductConstants;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
public class WithdrawContext extends AbstractContext{
    // 第一个条件：会员有优惠且未投注时，取款转人工
    public String UNUSED_PROMOTION_ENABLED = null;
    public String QUERY_BET_ENABLED = null;//查询投注数据开关
    public String MAX_UNUSED_PROMOTION_AMOUNT = null;  // 设置取款金额阈值，例如100.0


    // 新规则：系统连续通过的笔数或金额条件达到设定的值时，取款转人工
    public String CONSECUTIVE_PASSES_ENABLED = null;
    public String MAX_CONSECUTIVE_PASSES = null;  // 设置连续通过的笔数阈值，例如5
    public String MAXIMUM_TOTAL_PASSED_AMOUNT = null;  // 设置通过的总金额阈值，例如2000.0
    public String FIRST_WITHDRAWAL_CHECK_AMOUNT = null;  // 首次取款自动通过最大金额

    public String WD_MANUAL_MIN_NUM;  // 单日取款次数超过x转人工
    public String WD_MANUAL_MIN_AMOUNT;  // 单日取款次数超过x转人工最小金额
    public String MANUAL_TYPE;  // 转人工规则，多个','分割exceptionPromptType
    public String RISK_AUTO_APPROVE;
    public String RISK_AUTO_APPROVE_MAX_AMOUNT;

    // 新规则：XX天未取款，期间内有存款，并且本次取款金额小于等于期间内存款总金额的XX倍，则可以通过，否则转人工
    public String MAX_QUERY_DEPOSIT_DAYS= null;// XX天未取款
    public String DEPOSIT_WITHDRAWAL_RATIO = null;// xx倍
    public long RISK_WITHDRAWAL_DIFFDAY = 0;// 最后取款跟当前取款时间差大于90天才进行规则校验

    @JsonIgnore
    private List<WSProductConstants> productConstantsList;

    /**
     * 命中规则集合
     */
    @JsonIgnore
    public Map<String,String> filter = new HashMap<>();

    /**最终是否自动通过*/
    private boolean autoApprove;
    private OriWithdrawReq req;

    /**
     * 走人工，和ws交互使用的规则
     */
    private String exceptionPromptType;
    private String exceptionPrompt;


    private boolean withdrawRiskKey;

    private BigDecimal todayLimit = BigDecimal.ZERO;//当天通过的累计取款额
    private int todayPass; //当天通过的取款次数
    private BigDecimal totalPassedAmount;//连续通过金额
    private int totalPassedCount;//连续通过次数
    private BigDecimal sumAmount=BigDecimal.ZERO;//时间段内总存款额
    private BigDecimal sumPromotionAmount = BigDecimal.ZERO;//查询优惠金额
    private BigDecimal validAccount=BigDecimal.ZERO;//投注额
    private BigDecimal winOrLostAmount=BigDecimal.ZERO;//盈利率
    private BigDecimal fixAmount=BigDecimal.ZERO;//额度修正金额
    private BigDecimal withdrawalRequestsAmount;//传入取款金额
    private BigDecimal dstAmount=BigDecimal.ZERO;//余额
    private BigDecimal sumDpAmount=BigDecimal.ZERO;//指定时间段内总存款额

    //core amount
    private BigDecimal difference=BigDecimal.ZERO;//存取差
    private BigDecimal profit=BigDecimal.ZERO;//盈利率
    private BigDecimal betRate=BigDecimal.ZERO;//投注比

    @JsonIgnore
    private boolean glifeDomain;
}
