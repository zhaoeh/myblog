package com.riskcontrol.cron.service.impl;

import com.cn.schema.request.KycDispatchConfirmRequest;
import com.cn.schema.request.WSDispatchRecord;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequest;
import com.riskcontrol.common.enums.YesNoEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.constants.ProjectConstant;
import com.riskcontrol.cron.enums.ErrCodeEnum;
import com.riskcontrol.cron.service.CustomersFacade;
import com.riskcontrol.cron.service.DispatchRecordService;
import com.riskcontrol.cron.service.KycRequestService;
import com.riskcontrol.cron.utils.ProductConstantsLoader;
import com.riskcontrol.cron.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by Wason.H on 2018/4/6.
 * 客户信息层实现类
 */
@Service
@Slf4j
public class CustomersFacadeImpl implements CustomersFacade {

    @Resource
    protected RedisUtil redisUtil;
    @Resource
    private KycRequestService kycRequestService;
    @Autowired
    private DispatchRecordService dispatchRecordService;
//    @Autowired
//    private OthersService othersService;
//    @Autowired
//    private ProductConsQueryService productConsQueryService;

    /**
     * 请求派kyc 请求
     *
     * @return
     */
    @Override
    public List<KycRequest> dispatchKycRequest(RiskQueryKycRequest riskQueryKycRequest) throws BusinessException {
        int pageSize = Integer.valueOf(ProductConstantsLoader.obtainProductConstantRedis("C66", "0016", ProjectConstant.DISPATCH_WEIGHT_MAXIMUM_ORDER_PER_SESSION));
//        WSProductConstants maxDispatch = productConstantService.loadByPKey("C66", "0016", Constant.DISPATCH_WEIGHT_MAXIMUM_ORDER_PER_SESSION);
//        int pageSize = Integer.valueOf(othersService.getProductConstantByEnums(ProductConstantEnum.MAXIMUM_ORDER_PER_SESSION));
//        int pageSize = Integer.valueOf(productConstantsConfig.getPropertyByParams("C66", "0016", ProjectConstant.DISPATCH_WEIGHT_MAXIMUM_ORDER_PER_SESSION));
//        if(maxDispatch != null){
//            pageSize = Integer.parseInt(maxDispatch.getValue());
//        }
        final String loginName = riskQueryKycRequest.getLoginName();
        riskQueryKycRequest.setPageSize(pageSize);
        riskQueryKycRequest.setPageNum(1);
        riskQueryKycRequest.setLoginName(null);
        riskQueryKycRequest.setStatusList("0");
        riskQueryKycRequest.setOrder("ID ASC");
        riskQueryKycRequest.setDispatchStatus("0");
        final String lockKycKey = CronConstant.DISPATCH_KYC_LOCK_SUFFIX;
        boolean dispatchLock = redisUtil.tryLock(lockKycKey, 30, 5, TimeUnit.SECONDS);
        if (!dispatchLock) {
            log.error("dispatch kyc try lock failed");
            throw new BusinessException(ErrCodeEnum.MSG_000000);
        }
        try {
            List<KycRequest> wsKycRequests = kycRequestService.queryPage(riskQueryKycRequest);
            log.info("dispatchKycRequest 方法查询 kycRequestService.queryPage(riskQueryKycRequest);--------------------------DispatchStatus:{}", CollectionUtils.isEmpty(wsKycRequests) ? null : wsKycRequests.get(0).getDispatchStatus());
            log.info("dispatchKycRequest 方法查询 kycRequestService.queryPage(riskQueryKycRequest);--------------------------kycId:{}", CollectionUtils.isEmpty(wsKycRequests) ? null : wsKycRequests.get(0).getId());
            log.info("dispatchKycRequest 方法查询 kycRequestService.queryPage(riskQueryKycRequest);--------------------------updateTime:{}", CollectionUtils.isEmpty(wsKycRequests) ? null : wsKycRequests.get(0).getUpdateDate());
            log.info("dispatchKycRequest 方法查询 kycRequestService.queryPage(riskQueryKycRequest); 获得锁:{}-------------------------Thread.currentThread().getId:{}", lockKycKey, Thread.currentThread().getId());
            if (wsKycRequests.isEmpty()) {
                return wsKycRequests;
            }
            List<WSDispatchRecord> wsDispatchRecords = new ArrayList<>();
            wsKycRequests.forEach(v -> {
                v.setDispatchStatus(CronConstant.DISPATCH_STATUS_ASSIGN);
                WSDispatchRecord record = new WSDispatchRecord();
                record.setCustomerId(v.getCustomerId());
                record.setStatus(YesNoEnum.NO.getIntCode());
                record.setOrderStyle(CronConstant.DISPATCH_ORDER_KYC);
                record.setSerialNumber(v.getId());
                record.setUserLoginName(loginName);
                wsDispatchRecords.add(record);
            });
            kycRequestService.modifyDispatchStatus(wsKycRequests);
            dispatchRecordService.create(wsDispatchRecords);
            return wsKycRequests;
        } finally {
            log.info("dispatchKycRequest 方法查询 释放锁:{}-------------------------Thread.currentThread().getId:{}", lockKycKey, Thread.currentThread().getId());
            redisUtil.unLock(lockKycKey);
        }
    }

    @Override
    public boolean checkDispatchKycRequestConfirm(KycDispatchConfirmRequest request) {
        List<KycRequest> dispatch = kycRequestService.getConfirmDispatchByIds(request);
        if (CollectionUtils.isEmpty(dispatch)) {
            return false;
        }
        for (KycRequest kyc : dispatch) {
            //已接单状态其他人不会再接单
            if (2 == kyc.getDispatchStatus()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public Boolean dispatchKycRequestConfirm(KycDispatchConfirmRequest request) throws BusinessException {
        // 修改派单记录
        int record = dispatchRecordService.confirm(CronConstant.DISPATCH_ORDER_KYC, request.getLoginName(), request.getIds());
        return record == 0 ? Boolean.FALSE : (kycRequestService.modifyConfirmDispatch(request) != 0);
    }
}