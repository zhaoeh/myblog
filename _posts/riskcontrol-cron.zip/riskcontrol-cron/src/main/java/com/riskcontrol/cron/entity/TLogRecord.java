package com.riskcontrol.cron.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * <p>
 * 日志记录表
 * </p>
 *
 * @author Colson
 * @date 2023-10-19 17:55
 */
@Getter
@Setter
@Accessors(chain = true)
@TableName("t_log_record")
@ApiModel(value = "TLogRecord对象", description = "日志记录表")
public class TLogRecord extends BaseFullEntity {

    @ApiModelProperty("系统模块名称")
    private String moduleName;

    @ApiModelProperty("日志记录位置描述，例：类名+方法名等关键字用于快速定位")
    private String location;

    @ApiModelProperty("日志类型：ERROR，INFO...")
    private String type;

    @ApiModelProperty("日志信息")
    private String logMessage;

    @ApiModelProperty("请求url")
    private String requestUrl;

    @ApiModelProperty("请求参数")
    private String requestParam;

    @ApiModelProperty("接收参数")
    private String receiveParam;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("创建人")
    private String createBy;

    @ApiModelProperty("更新人")
    private String updateBy;
}
