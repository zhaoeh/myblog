package com.riskcontrol.cron.aop;

import com.cn.schema.customers.WSKycRequest;
import com.cn.schema.customers.WSKycRequestProcessLog;
import com.riskcontrol.common.aop.AfterParams;
import com.riskcontrol.common.aop.BeforeParams;
import com.riskcontrol.common.aop.CommonAspectRunner;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.cron.entity.RiskKycRequest;
import com.riskcontrol.cron.mapper.KycRequestDao;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;

/**
 * 同步更新process id到kyc_request表中
 *
 * @program: riskcontrol-cron
 * @description: 插入process表时同步将process id同步更新到kyc_request表中
 * @author: Erhu.Zhao
 * @create: 2023-10-20 17:37
 **/
@Component
public class SynProcessLogToRequest implements CommonAspectRunner {

    @Autowired
    private KycRequestDao kycRequestDao;

    @Override
    public Object before(BeforeParams beforeParams) throws Exception {
        return null;
    }

    @Override
    public Object after(AfterParams afterParams) throws Exception {
        Object[] params = Optional.ofNullable(afterParams).map(p -> p.getParams()).orElse(new Object[0]);
        if (params.length > 0) {
            Object paramOne = params[0];
            if (WSKycRequestProcessLog.class.isInstance(paramOne)) {
                synProcessLogIdToRequest((WSKycRequestProcessLog) paramOne);
            }
        }
        return null;
    }

    private void synProcessLogIdToRequest(WSKycRequestProcessLog log) {
        RiskKycRequest riskKycRequest = buildSynRequest(log);
        if (Objects.isNull(riskKycRequest)) {
            return;
        }
        kycRequestDao.update(riskKycRequest);
    }

    private RiskKycRequest buildSynRequest(WSKycRequestProcessLog log) {
        String requestId = log.getKycRequestId();
        if (StringUtils.isBlank(requestId)) {
            return null;
        }
        KycRequest kycRequest = new KycRequest();
        kycRequest.setId(requestId);

        String processLogType = log.getType();
        String processLogRemark = log.getRemark();
        if (StringUtils.isBlank(processLogType) && StringUtils.isBlank(processLogRemark)) {
            return null;
        }
        return RiskKycRequest.builder().kycRequest(kycRequest).processLogType(processLogType).processLogRemark(processLogRemark).build();
    }
}
