package com.riskcontrol.cron.service.impl;

import cn.hutool.core.date.TimeInterval;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.cn.schema.common.RabbitMQMessage;
import com.cn.schema.customers.*;
import com.cn.schema.request.KycDispatchConfirmRequest;
import com.digiplus.common.exception.KafkaShieldException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.riskcontrol.common.config.UserCenterConstant;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequest;
import com.riskcontrol.common.entity.request.kyc.RiskUpdateKycRequestRequest;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.constants.ProjectConstant;
import com.riskcontrol.cron.datasource.DBSourceCheck;
import com.riskcontrol.cron.datasource.DataSourceType;
import com.riskcontrol.cron.entity.RiskKycRequest;
import com.riskcontrol.cron.entity.TKycDeduplicate;
import com.riskcontrol.cron.enums.ErrCodeEnum;
import com.riskcontrol.cron.enums.KYCStatusEnum;
import com.riskcontrol.cron.enums.PBCStatusEnum;
import com.riskcontrol.cron.kafka.KafkaTopic;
import com.riskcontrol.cron.mapper.DispatchRecordDao;
import com.riskcontrol.cron.mapper.KycRequestDao;
import com.riskcontrol.cron.mapper.KycRequestProcessLogDao;
import com.riskcontrol.cron.mapper.TKycDeduplicateMapper;
import com.riskcontrol.cron.service.AbstractService;
import com.riskcontrol.cron.service.KycRequestProcessLogService;
import com.riskcontrol.cron.service.KycRequestService;
import com.riskcontrol.cron.service.OddNumbersGenService;
import com.riskcontrol.cron.template.WsApiFeignTemplate;
import com.riskcontrol.cron.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

import static com.riskcontrol.cron.constants.CronConstant.WAIT_PBC_KEY;

/**
 * @program: riskcontrol-cron
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-10-04 15:49
 **/
@Service
@Slf4j
public class KycRequestServiceImpl extends AbstractService implements KycRequestService {
    @Value("${aws.s3.bucketName:}")
    private String bucketName;
    @Resource
    private RedisTemplate<Serializable, Object> redisTemplate;

    @Autowired
    private OddNumbersGenService oddNumbersGenService;

    @Autowired
    private RedisUtil redisUtil;

    @Resource
    private KycRequestProcessLogService kycRequestProcessLogService;

    @Resource
    private KycRequestDao kycRequestDao;

    @Autowired
    private DispatchRecordDao dispatchRecordDao;

    @Resource
    private KycRequestProcessLogDao kycRequestProcessLogDao;

    @Autowired
    private WsApiFeignTemplate wsApiFeignTemplate;
    @Resource
    private TKycDeduplicateMapper kycDeduplicateMapper;
    @Autowired
    private UserCenterConstant userCenterConstant;
    @Autowired
    private KafkaProductUtils kafkaProductUtils;
    
    @Override
    public Integer count(RiskQueryKycRequest query) throws BusinessException {
        return kycRequestDao.countByCondition(query);
    }

    @Override
    public Integer countAllowMiddleNameIsNullKycNotLike(RiskQueryKycRequest query) throws BusinessException {
        return kycRequestDao.countByConditionKycNotLike(query);
    }
    @DBSourceCheck(DataSourceType.SLAVE)
    @Override
    public Integer countOfQueryPage(RiskQueryKycRequest query) {
        TimeInterval timer = cn.hutool.core.date.DateUtil.timer();
        Integer result = kycRequestDao.countOfQueryPageByCondition(query);
        logger.info("countOfQueryPage result={}， timer.interval={}", result, timer.interval());
        return result;
    }
    @DBSourceCheck(DataSourceType.SLAVE)
    @Override
    public Integer countOfQueryPageNotLike(RiskQueryKycRequest query) {
        TimeInterval timer = cn.hutool.core.date.DateUtil.timer();
        Integer result = kycRequestDao.countOfQueryPageByConditionNotLike(query);
        logger.info("countOfQueryPage result={}， timer.interval={}", result, timer.interval());
        return result;
    }
    @DBSourceCheck(DataSourceType.SLAVE)
    @Override
    public List<KycRequest> queryPage(RiskQueryKycRequest query) throws BusinessException {
        ValidationUtils.checkIsNull(query, ErrCodeEnum.MSG_500018);
        if (query.getPageSize() == 0) {
            query.setPageSize(CronConstant.PAGE_SIZE);
        } else if (query.getPageSize() > CronConstant.PAGE_MAX_SIZE) {
            throw new BusinessException(ErrCodeEnum.MSG_100003);
        }
        if (StringUtils.isBlank(query.getOrder())) {
            query.setOrder("ID DESC");
        }
        query.setPageNum(CommonLogic.buildFirstPageParamOfMySql(query.getPageNum(), query.getPageSize()));
        return kycRequestDao.queryPageByCondition(query);
    }

    @Override
    public int create(KycRequest bean) throws BusinessException {
        log.info("KycRequestServiceImpl create bean={}", bean);
        ValidationUtils.checkIsNull(bean, ErrCodeEnum.MSG_500018);
        String requestId = oddNumbersGenService.singleGenRequestId(bean.getProductId(), CronConstant.REQUEST_TYPE_DEPOSIT);
        bean.setBillNo(requestId);
        bean.setId(null);
        if (StringUtils.isBlank(bean.getMiddleName())) {
            bean.setMiddleName(null);
        }
        log.info("KycRequestServiceImpl create bean.getTenant={}", bean.getTenant());
        bean.setProduct(bean.getTenant());
        int insert = kycRequestDao.insert(bean);
        if (insert > 0 && bean.getStatus().equalsIgnoreCase(CronConstant.ONE)) {
            log.info("kyc_request create 审核通过并添加记录 kycId={}, customerId={}", bean.getId(), bean.getCustomerId());
            if (StringUtils.isNotEmpty(bean.getIdType()) && StringUtils.isNotEmpty(bean.getIdNo())) {
                TKycDeduplicate kycDeduplicate = new TKycDeduplicate();
                kycDeduplicate.setIdNo(bean.getIdNo());
                kycDeduplicate.setIdType(Integer.valueOf(bean.getIdType()));
                if (!validKycIdAndTypeExist(kycDeduplicate.getIdType(), bean.getIdNo())) {
                    kycDeduplicateMapper.insert(kycDeduplicate);
                }
            }

            WSKycRequestProcessLog wsKycRequestProcessLog = new WSKycRequestProcessLog();
            wsKycRequestProcessLog.setDispatchBy(bean.getApprovedBy());
            wsKycRequestProcessLog.setKycRequestId(bean.getId());
            wsKycRequestProcessLog.setRemark("KYC approved by " + bean.getApprovedBy());
            wsKycRequestProcessLog.setType("KYC approved");
            kycRequestProcessLogService.insert(wsKycRequestProcessLog);

            //如果是审核通过，则发送KYC通过的消息到MQ
            if (StringUtils.isNotBlank(bean.getStatus()) && "1".equals(bean.getStatus())) {
                //把已kyc审批通过的，记录到redis，待定时job获取更新pbc
                redisUtil.addZSet(WAIT_PBC_KEY,bean.getId(),System.currentTimeMillis());
                WSCustomers wsCustomers = new WSCustomers();
                wsCustomers.setProductId(bean.getProductId());
                wsCustomers.setLoginName(bean.getLoginName());
                wsCustomers.setKycStatus(bean.getStatus());
                wsCustomers.setCustomerId(bean.getCustomerId());
                String tenant = StringUtils.isEmpty(bean.getProduct()) ? "00" : bean.getProduct();
                wsCustomers.setTenant(tenant);
                log.info("kyc_request create 审核通过 发送消息tenant={}", tenant);
                this.sendApproveKycMq(bean, wsCustomers);


            }
        }
        redisUtil.remove(String.format(Constant.RISK_KYC_LATEST_KEY, bean.getCustomerId()));//更新完成删除kyc缓存(fastgame 补充kyc信息需求)
        return insert;
    }

    private void sendApproveKycMq(KycRequest bean, WSCustomers wsCustomers) {
        String mqSwitch = ProductConstantsLoader.obtainProductConstantRedis(Constant.C66_PRODUCT_ID, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0004, ProjectConstant.MESSAGE_APPROVE_KYC_SWITCH);
        JSONObject oldKycMsg = RabbitMQUtils.buildCustomerKycStatusParams(wsCustomers, bean.getStatus());
        if("1".equals(mqSwitch)){
            RabbitMQUtils.sendCustomerUpdateKyc(oldKycMsg);
        }else if("2".equals(mqSwitch)){
            RabbitMQMessage<JSONObject> message = new RabbitMQMessage<>(RabbitMQUtils.EXCHANGE_ENUM.CUSTOMER_UPDATE_KYC.getRoutingKey(), oldKycMsg);
            kafkaProductUtils.pushKafkaMsg(KafkaTopic.APPROVE_KYC_TOPIC,JSONObject.toJSONString(message));
        }else{
            logger.info("sendCustomerUpdateKyc MESSAGE_PUSH_APPROVE_KYC_SWITCH is close");
        }
        //单独尝试一条风控自己消费的消息
        JSONObject selfObject = new JSONObject();
        selfObject.put("loginName",wsCustomers.getLoginName());
        selfObject.put("productId",wsCustomers.getProductId());
        selfObject.put("isOldKyc",true);//用来判断是否老kyc
        kafkaProductUtils.pushKafkaMsg(KafkaTopic.APPROVE_KYC_TOPIC_SELF,selfObject.toJSONString());
    }

    @Override
    public int update(RiskUpdateKycRequestRequest updateKycRequestRequest) throws BusinessException, KafkaShieldException, JsonProcessingException {
        logger.info("KycRequestServiceImpl update Request={}", updateKycRequestRequest);
        KycRequest bean = updateKycRequestRequest.getWsKycRequest();
        logger.info("c66-ws bean.getSex={}", bean.getSex());
        String key = String.format(Constant.RISK_KYC_FLAG_KEY, bean.getCustomerId());
        logger.info("c66-ws bean.getBirthday={}", bean.getBirthday());
        KycRequest kycRequest = kycRequestDao.queryKycById(bean.getId());
        if (kycRequest == null) {
            logger.warn("c66-ws kyc update 没有找到对应记录");
            throw new BusinessException("kyc request can't find",ErrCodeEnum.MSG_335010.getCode());
        }
        //只更新扩展信息，没有状态等修改，且数据库middleName不为空，set
        String status = bean.getStatus();
        if(StringUtils.isBlank(status)
                && StringUtils.isBlank(bean.getMiddleName())
                && StringUtils.isNotBlank(kycRequest.getMiddleName())){
            bean.setMiddleName(kycRequest.getMiddleName());
        }
        int update = kycRequestDao.updateKyc(RiskKycRequest.builder().kycRequest(bean).build());
        WSKycRequestProcessLog wsKycRequestProcessLog = new WSKycRequestProcessLog();
        wsKycRequestProcessLog.setDispatchBy(bean.getApprovedBy());
        wsKycRequestProcessLog.setKycRequestId(bean.getId());

        if (update > 0 && status.equalsIgnoreCase(CronConstant.ONE)) {
            //把已kyc审批通过的，记录到redis，待定时job获取更新pbc
            redisUtil.addZSet(WAIT_PBC_KEY,bean.getId(),System.currentTimeMillis());
            //判断是否存在，不存在就插入
            if (StringUtils.isNotEmpty(bean.getIdType()) && StringUtils.isNotEmpty(bean.getIdNo())) {
                TKycDeduplicate kycDeduplicate = new TKycDeduplicate();
                kycDeduplicate.setIdNo(bean.getIdNo());
                kycDeduplicate.setIdType(Integer.valueOf(bean.getIdType()));
                if (!validKycIdAndTypeExist(kycDeduplicate.getIdType(), bean.getIdNo())) {
                    kycDeduplicateMapper.insert(kycDeduplicate);
                }
            }
            /**
             *  用戶kyc审核通过 消息推送
             */
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("loginName", bean.getLoginName());
            jsonObject.put("customerId", bean.getCustomerId());
            jsonObject.put("paramId", "OTP_010");

            String mqSwitch = ProductConstantsLoader.obtainProductConstantRedis(Constant.C66_PRODUCT_ID, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0004, ProjectConstant.MESSAGE_PUSH_SWITCH);
            if("1".equals(mqSwitch)){
                RabbitMQUtils.pushOTPMessage(jsonObject, bean.getProductId());
            }else if("2".equals(mqSwitch)){
                jsonObject.put("billNo", UUID.randomUUID().toString().replaceAll("-", ""));
                RabbitMQMessage<JSONObject> message = new RabbitMQMessage<>(RabbitMQUtils.EXCHANGE_ENUM.PUSH_CUSTOMER_OTP_MESSAGE.getRoutingKey(), jsonObject);
                kafkaProductUtils.pushKafkaMsg(KafkaTopic.OTP_MESSAGE_TOPIC,JSONObject.toJSONString(message));
            }else{
                logger.info("pushOTPMessage,messagePushSwitch is close");
            }

            WSCustomers customers = wsApiFeignTemplate.getSimpleCustomerByLoginName(bean.getProductId(),bean.getLoginName());
            Optional.ofNullable(customers).ifPresent(it -> {
                String tenant = StringUtils.isEmpty(kycRequest.getProduct()) ? "00" : kycRequest.getProduct();
                it.setTenant(tenant);
                log.info("kyc_request update 审核通过 发送消息tenant={}", tenant);
                this.sendApproveKycMq(bean, it);
            });
            wsKycRequestProcessLog.setRemark("KYC approved by " + bean.getApprovedBy());
            wsKycRequestProcessLog.setType("KYC approved");

        }
        if (update > 0 && status.equalsIgnoreCase(CronConstant.THREE)) {
            wsKycRequestProcessLog.setRemark(bean.getRemark());
            wsKycRequestProcessLog.setType("KYC rejected");
        }
        if (update > 0 && StringUtils.isBlank(status)) {
            wsKycRequestProcessLog.setRemark(bean.getRemark());
            wsKycRequestProcessLog.setType(bean.getType());
        }

        kycRequestProcessLogService.insert(wsKycRequestProcessLog);
        redisUtil.remove(key);
        redisUtil.remove(String.format(Constant.RISK_KYC_LATEST_KEY, kycRequest.getCustomerId()));//更新完成删除kyc缓存(fastgame 补充kyc信息需求)
        return update;
    }

    @Override
    public int pbcModifyStatus(KycRequest bean) {
        int update = 0;
        try {
            String approvedBy = bean.getApprovedBy();
            String approvedDate = bean.getApprovedDate();
            bean.setPbcApprovedBy(approvedBy);
            bean.setPbcApprovedDate(approvedDate);

            bean.setApprovedBy(null);//t_kyc_requests表中 APPROVED_BY列存储 kyc审核人员信息 置为空时 xml方法才不会更新这个字段值
            bean.setApprovedDate(null);//t_kyc_requests表中 APPROVED_DATE列存储 kyc审核时间 置为空时 xml方法才不会更新这个字段值
            update = kycRequestDao.updateKyc(RiskKycRequest.builder().kycRequest(bean).build());
            WSKycRequestProcessLog wsKycRequestProcessLog = new WSKycRequestProcessLog();
            wsKycRequestProcessLog.setDispatchBy(approvedBy);
            wsKycRequestProcessLog.setKycRequestId(bean.getId());
            if (update > 0 && bean.getPbcStatus().equals(1)) {
                wsKycRequestProcessLog.setRemark("PBC approved by " + approvedBy);
                wsKycRequestProcessLog.setType("PBC approved");
            }
            if (update > 0 && bean.getPbcStatus().equals(3)) {
                wsKycRequestProcessLog.setRemark(bean.getRemark());
                wsKycRequestProcessLog.setType("PBC rejected");
            }

            // 添加处理日志 start
            wsKycRequestProcessLog.setLastStauts(0);
            wsKycRequestProcessLog.setCreateTime(new Date());
            if (wsKycRequestProcessLog.getKycRequestId() != null) {
                kycRequestProcessLogDao.updateStatusByKycId(wsKycRequestProcessLog.getKycRequestId());
            }
            int result = kycRequestProcessLogDao.insert(wsKycRequestProcessLog);
            log.info("KycRequestServiceImpl update result={}", result);
            KycRequest kycRequest = new KycRequest();
            kycRequest.setId(wsKycRequestProcessLog.getKycRequestId());

            kycRequestDao.update(RiskKycRequest.builder().kycRequest(kycRequest).processLogType(wsKycRequestProcessLog.getType())
                    .processLogRemark(wsKycRequestProcessLog.getRemark()).build());
            // 添加处理日志 end
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("pbcModifyStatus 出现异常 具体信息：{}", e.getMessage());
        }
        return update;
    }

    @Override
    public int pbcDispatch(KycRequest bean) {
        bean.setPbcStatus(0);
        int update = kycRequestDao.update(RiskKycRequest.builder().kycRequest(bean).build());
        WSKycRequestProcessLog wsKycRequestProcessLog = new WSKycRequestProcessLog();
        wsKycRequestProcessLog.setDispatchBy("c66");
        wsKycRequestProcessLog.setKycRequestId(bean.getId());
        wsKycRequestProcessLog.setRemark("PBC distributed to " + bean.getApprovedBy());

        int coutPbcDispatchRecord = dispatchRecordDao.queryPbcCountBySerialNumber(bean.getId());
        //如果kyc记录是重新派单的话
        if (coutPbcDispatchRecord > 1) {
            wsKycRequestProcessLog.setType("PBC re-distributed");
        } else {
            wsKycRequestProcessLog.setType("PBC distributed");
        }
        kycRequestProcessLogService.insert(wsKycRequestProcessLog);
        return update;
    }

    @Override
    public int countWaitPending(KycRequest query) throws BusinessException {
        return kycRequestDao.countWaitingPendingByAssignee(query.getLoginName());
    }

    @Override
    public int modifyDispatchStatus(List<KycRequest> requests) throws BusinessException {
        return kycRequestDao.modifyDispatchStatus(requests.get(0).getDispatchStatus(), requests);
    }

    @Override
    public int cancelDispatch(String userLoginName) {
        return kycRequestDao.modifyResetDispatchStatus(userLoginName);
    }
    @DBSourceCheck(DataSourceType.SLAVE)
    @Override
    public int countKycPbc(RiskQueryKycRequest params) {
        return kycRequestDao.countKycByCondition(params);

    }
    @DBSourceCheck(DataSourceType.SLAVE)
    @Override
    public List<KycRequest> queryKycPbcPage(RiskQueryKycRequest params) {
        return kycRequestDao.queryKycPbcPageByCondition(params);

    }
    @DBSourceCheck(DataSourceType.SLAVE)
    @Override
    public int countKycPbcNew(RiskQueryKycRequest kycParams) {
        return kycRequestDao.countKycPbcByCondition(kycParams);

    }
    @DBSourceCheck(DataSourceType.SLAVE)
    @Override
    public List<KycRequest> queryKycSheetList(RiskQueryKycRequest kycParams) throws Exception {
        ValidationUtils.checkIsNull(kycParams, ErrCodeEnum.MSG_500018);
/*        if (StringUtils.isBlank(params.getOrder())) {
            params.setOrder("ID DESC");
        }*/
        return kycRequestDao.queryKycPbcPageByCondition(kycParams);
    }

    private String generateRedisFailListKey(String redisCommonKey) {
        return redisCommonKey + "FailList";
    }

    private String generateRedisSucessListKey(String redisCommonKey) {
        return redisCommonKey + "SucessList";
    }

    private String generateRedisFailKey(String redisCommonKey, int cycleIndex) {
        return redisCommonKey + ":fail:" + cycleIndex;
    }

    private String generateRedisSuccKey(String redisCommonKey, int cycleIndex) {
        return redisCommonKey + ":succ:" + cycleIndex;
    }


    private long getRandomInt() {
        Random r = new Random();
        int i = r.nextInt(7200);
        return i;
    }

    private void addFailInfoToRedis(String failKey, Object kyc) {
        Random r = new Random();
        redisUtil.set(failKey, kyc, Long.valueOf(getRandomInt()));
    }

    private String generateRedisKeyByDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        return "C66:uploadPbcBatch:" + sdf.format(new Date());
    }


    public KycRequest queryByCondition(QueryKycByConditionRequest request) {
        return kycRequestDao.queryByCondition(request);
    }

    private void addSucessInfoToRedis(String succKey, Object kyc) {
        //TODO 改成随机时间
        redisUtil.set(succKey, kyc, Long.valueOf(getRandomInt()));
    }


    private void saveSucessToRedis(List<Map<String, Object>> hashSuccessList, String billNo, Integer pbcStatus, String successkey) {
        Map<String, Object> successHash = new HashMap<>();

        successHash.put(billNo, pbcStatus);

        //将执行失败的  导入表单中的信息放入list集合
        hashSuccessList.add(successHash);

        addSucessInfoToRedis(successkey, successHash);
        //addSucessInfoToRedis(successkey, JSONObject.toJSON(kyc));
    }

    private void saveFailToRedis(List<Map<String, Object>> hashFailList, String billNo, Integer pbcStatus, String failkey) {
        Map<String, Object> failHash = new HashMap<>();

        failHash.put(billNo, pbcStatus);

        //将执行失败的  导入表单中的信息放入list集合
        hashFailList.add(failHash);

        //addFailInfoToRedis(failkey, JSONObject.toJSON(kyc));

        //将执行失败的  导入表单中的信息存入redis
        addFailInfoToRedis(failkey, failHash);

    }

    @Override
    public BatchModifyPbcRequestResponse bactchModifyPbcStatus(BatchUpdateKycRequestRequest request) {
        List<WSKycSheetRequest> kycList = request.getWsKycSheetRequestList();
        List<WSKycSheetRequest> kycFailList = new ArrayList<>();

        List<Map<String, Object>> hashFailList = new ArrayList<>();
        List<Map<String, Object>> hashSuccessList = new ArrayList<>();
        int sumCount = 0;
        String redisCommonKey = generateRedisKeyByDate();
        String redisSucessListKey = generateRedisSucessListKey(redisCommonKey);
        String redisFailListKey = generateRedisFailListKey(redisCommonKey);
        try {
            for (int i = 0; i < kycList.size(); i++) {
                String failkey = generateRedisFailKey(redisCommonKey, i);
                String successkey = generateRedisSuccKey(redisCommonKey, i);
                WSKycSheetRequest kycRequest = kycList.get(i);
                QueryKycByConditionRequest wsKycRequest = new QueryKycByConditionRequest();
                wsKycRequest.setBillNo(kycRequest.getBillNo().replaceAll("\t", ""));
                wsKycRequest.setProductId(request.getInfProductId());
                //系统中存储得kyc信息
                KycRequest kycInfo = queryByCondition(wsKycRequest);
                //未查询到数据则进入下一次循环
                if (kycInfo == null) {
                    kycRequest.setPbcStatus(kycRequest.getPbcStatus() == null ? null : PBCStatusEnum.getPbcEnumByStatus(Integer.valueOf(kycRequest.getPbcStatus())).getPbcStatusString());
                    kycFailList.add(kycRequest);
                    continue;
                }
                int pbcStatus = kycInfo.getPbcStatus();
                int kycStatuc = Integer.parseInt(kycInfo.getStatus());
                //如果kyc状态不是1 或者 pbc状态不是0得话 不能被审核
                if (!(kycStatuc == KYCStatusEnum.APPROVED.getKycStatus() && pbcStatus == PBCStatusEnum.DISTRIBUTED.getPbcStatus())) {
                    continue;
                }
                Integer pbcStatusRequest = StringUtils.isBlank(kycRequest.getPbcStatus()) ? null : Integer.valueOf(kycRequest.getPbcStatus());
                PBCStatusEnum pbcEnum = (pbcStatusRequest == null ? null : PBCStatusEnum.getPbcEnumByStatus(pbcStatusRequest));
                if (pbcEnum == null) {
                    //将billo和传入的pbcOperation值存入redis
                    saveFailToRedis(hashFailList, kycInfo.getBillNo(), pbcStatus, failkey);
                    //未查询到对应的pbc信息(Excel中 pbc内容不正确)
                    kycFailList.add(kycRequest);
                    continue;
                } else {
                    //导入的pbcStatus
                    kycInfo.setPbcStatus(pbcStatusRequest);
                    kycInfo.setUpdateBy(request.getOperator());
                    kycInfo.setApprovedDate(DateUtil.getDateW3CFormat(new Date()));
                    kycInfo.setApprovedBy(request.getOperator());
                    kycInfo.setUpdateDate(DateUtil.getDateW3CFormat(new Date()));
                    //如果是admin，可以查看所有的
                    if (StringUtils.isBlank(request.getOperator())) {
                        kycInfo.setPbcApprovedBy("c66");
                    } else {
                        kycInfo.setPbcApprovedBy(request.getOperator());
                    }
                    //将pbc信息更新到系统中
                    int updateCount = pbcModifyStatus(kycInfo);
                    if (updateCount > 0) {//更新成功
                        sumCount++;
                        saveSucessToRedis(hashSuccessList, kycRequest.getBillNo(), pbcStatusRequest, successkey);
                    } else {
                        saveFailToRedis(hashFailList, kycRequest.getBillNo(), pbcStatusRequest, failkey);
                        //更新失败，返回该条数据给前端，让客户下载
                        kycFailList.add(kycRequest);
                    }
                }
          /*  kycInfo.setProductId(request.getInfProductId());
            ValidationUtils.checkRequiredValue(kycInfo.getId());
            int count = pbcModifyStatus(kycInfo);*/
                //request.getWsKycRequest().setProductId(request.getInfProductId());
                //ValidationUtils.checkRequiredValue(request.getWsKycRequest().getId());
                //new ModifyKycRequestResponse(kycRequestService.pbcModifyStatus(request.getWsKycRequest());
           /* if(count>0){
                sumCount++;
            }else{

            }*/
            }
        } catch (Exception e) {
            e.printStackTrace();
            //resp.setHead((ErrorCode.ErrKey.ERROR_UPLOAD_PBC_EXCE_EXCEPTION).getErrHead());
            logger.error("{}   bactchModifyPbcStatus 出异常了. redisCommonKey={}, 异常信息:{}", new Date(), redisCommonKey, e.getMessage());
        } finally {
            if (kycFailList.size() > 0) {
                //将执行失败的导入信息 list集合存入redis
                addFailInfoToRedis(redisFailListKey, hashFailList);
            } else {
                //将执行成功的导入信息 list集合存入redis
                addSucessInfoToRedis(redisSucessListKey, hashSuccessList);
            }
        }
        return new BatchModifyPbcRequestResponse(kycFailList, sumCount);
    }

    @Override
    public List<KycRequest> getConfirmDispatchByIds(KycDispatchConfirmRequest request) {
        return kycRequestDao.queryKycByIds(request.getIds());
    }

    @Override
    public int modifyConfirmDispatch(KycDispatchConfirmRequest request) throws BusinessException {
        request.getIds().stream().forEach(e -> {
            int coutDispatchRecord = dispatchRecordDao.queryCountBySerialNumber(e);
            WSKycRequestProcessLog wsKycRequestProcessLog = buildWSKycRequestProcessLog(e, request.getLoginName(), coutDispatchRecord);
            kycRequestProcessLogService.insert(wsKycRequestProcessLog);
        });

        return kycRequestDao.modifyAssigneeBy(request.getLoginName(), request.getIds());
    }

    @Override
    public JSONObject modifyCustomConfiguration(JSONObject request) {
        log.info("[modifyCustomConfiguration method] request is {}", JSONObject.toJSONString(request));
        JSONObject kyc = CustomConfigurationHelper.obtainKycConfiguration(request);
        JSONObject withdraw = CustomConfigurationHelper.obtainWithdrawConfiguration(request);
        String queryKey = CustomConfigurationHelper.obtainQueryKey(request);
        refreshCustomConfiguration(kyc);
        refreshCustomConfiguration(withdraw);
        JSONObject response = flushHashValue(queryKey);
        log.info("[modifyCustomConfiguration method] response is {}", JSONObject.toJSONString(response));
        return response;
    }

    @Override
    public int autoApproveKycAndPbc(KycRequest request) {
        String cacheKey = request.getProductId() + ProjectConstant.KYC_REQUEST_DONE + request.getLoginName();

        // 已完成KYC
        if (redisUtil.exists(cacheKey)) {
            return 99;
        }
        //校验生日是否正确
        if(StringUtils.isNotBlank(request.getBirthday())){
            try {
                DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(DateUtils.DATE_FORMAT2);
                LocalDate birthDay = LocalDate.parse(request.getBirthday(), dateTimeFormatter);
                request.setBirthday(birthDay.format(DateTimeFormatter.ISO_DATE));
            } catch (DateTimeParseException e) {
                try {
                    //如果第二次转换还异常，生日格式错误，抛出异常
                    LocalDate.parse(request.getBirthday(), DateTimeFormatter.ofPattern(DateUtils.DATE_FORMAT));
                }catch (DateTimeParseException e2){
                    throw new BusinessException(ResultEnum.KYC_BIRTHDAY_ERROR);
                }

            }
        }
        int effectLine = kycRequestDao.countEndingRequest(request.getProductId(), request.getLoginName());

        // 不存在终结的kyc提案（pbc通过或拒绝）
        if (effectLine == 0) {
            // kyc新建 kyc通过 pbc通过
            effectLine = createKycPbcRequest(request);
            logger.info("autoApproveKycAndPbc createKycPbcRequest bean after effectLine {}", effectLine);
        }
        // 保存已完成kyc的客户
        redisUtil.set(cacheKey, effectLine, Long.valueOf(new Random().nextInt(30) * 24 * 60 * 60));

        return effectLine;
    }

    @Override
    public int getPendingRequest(String loginName) {
        return dispatchRecordDao.queryPendingCount(loginName);
    }

    private int createKycPbcRequest(KycRequest bean) {
        KycRequest wsKycRequest = new KycRequest();
        wsKycRequest.setLoginName(bean.getLoginName());
        wsKycRequest.setProductId(bean.getProductId());
        wsKycRequest.setCustomerId(bean.getCustomerId());
        wsKycRequest.setProduct(bean.getProduct());
        wsKycRequest.setChannel(bean.getChannel()); // 所有渠道请查看 ChannelEnum.java
        wsKycRequest.setCreatedBy("c66");
        wsKycRequest.setUpdateBy("c66");
        wsKycRequest.setApprovedBy("c66");
        wsKycRequest.setPbcApprovedBy("c66");
        wsKycRequest.setCreatedDate(DateUtil.getDateFormat(new Date(), DateUtils.DATE_TIME_FORMAT));
        wsKycRequest.setUpdateDate(DateUtil.getDateFormat(new Date(), DateUtils.DATE_TIME_FORMAT));
        wsKycRequest.setApprovedDate(DateUtil.getDateFormat(new Date(), DateUtils.DATE_TIME_FORMAT));
        wsKycRequest.setPbcApprovedDate(DateUtil.getDateFormat(new Date(), DateUtils.DATE_TIME_FORMAT));
        wsKycRequest.setStatus(KYCStatusEnum.KYC_STATUS_APPROVED);
        wsKycRequest.setPbcStatus(PBCStatusEnum.PBC_STATUS_APPROVED);

        wsKycRequest.setSex(bean.getSex());
        wsKycRequest.setCountry(bean.getCountry());
        wsKycRequest.setLastName(bean.getLastName());
        wsKycRequest.setFirstName(bean.getFirstName());
        wsKycRequest.setMiddleName(bean.getMiddleName());
        wsKycRequest.setBirthday(bean.getBirthday());
        wsKycRequest.setAddress(bean.getAddress());

        wsKycRequest.setIdNo(bean.getIdNo());
        wsKycRequest.setIdType(bean.getIdType());
        wsKycRequest.setIdScan(bean.getIdScan());
        wsKycRequest.setIdScanV2(bean.getIdScanV2());
        wsKycRequest.setIdScanImagekey(bean.getIdScanImagekey());

        logger.info("createKycPbcRequest wsKycRequest {}", wsKycRequest);
        return this.createAuto(wsKycRequest);
    }

    public int createAuto(KycRequest bean) {
        ValidationUtils.checkIsNull(bean, ErrCodeEnum.MSG_500018);
        String requestId = oddNumbersGenService.singleGenRequestId(bean.getProductId(), CronConstant.REQUEST_TYPE_DEPOSIT);
        bean.setBillNo(requestId);
        int insert = kycRequestDao.insert(bean);

        logger.info("kyc_request createAuto 审核通过并添加记录 kycId={}, customerId={}", bean.getId(), bean.getCustomerId());
        WSKycRequestProcessLog wsKycRequestProcessLog = new WSKycRequestProcessLog();
        wsKycRequestProcessLog.setDispatchBy(bean.getApprovedBy());
        wsKycRequestProcessLog.setKycRequestId(bean.getId());
        wsKycRequestProcessLog.setRemark("KYC & PBC approved by " + bean.getApprovedBy());
        wsKycRequestProcessLog.setType("KYC & PBC approved");
        kycRequestProcessLogService.insert(wsKycRequestProcessLog);

        //如果是审核通过，则发送KYC通过的消息到MQ
        if (StringUtils.isNotBlank(bean.getStatus()) && "1".equals(bean.getStatus())) {
            WSCustomers wsCustomers = new WSCustomers();
            wsCustomers.setProductId(bean.getProductId());
            wsCustomers.setLoginName(bean.getLoginName());
            wsCustomers.setKycStatus(bean.getStatus());
            wsCustomers.setCustomerId(bean.getCustomerId());
            String tenant = StringUtils.isEmpty(bean.getProduct()) ? "00" : bean.getProduct();
            wsCustomers.setTenant(tenant);
            log.info("kyc_request createAuto 审核通过 发送消息tenant={}", tenant);
            this.sendApproveKycMq(bean, wsCustomers);
        }
        redisUtil.remove(String.format(Constant.RISK_KYC_LATEST_KEY, bean.getCustomerId()));//更新完成删除kyc缓存(fastgame 补充kyc信息需求)

        return insert;
    }

    /**
     * WSKycRequestProcessLog对象实体
     *
     * @param requestId          request id
     * @param loginName          登录者
     * @param coutDispatchRecord 派单记录数
     * @return WSKycRequestProcessLog instance
     */
    private WSKycRequestProcessLog buildWSKycRequestProcessLog(String requestId, String loginName, int coutDispatchRecord) {
        WSKycRequestProcessLog wsKycRequestProcessLog = new WSKycRequestProcessLog();
        wsKycRequestProcessLog.setDispatchBy(loginName);
        wsKycRequestProcessLog.setKycRequestId(requestId);
        wsKycRequestProcessLog.setRemark("KYC distributed to " + loginName);
        wsKycRequestProcessLog.setDispatchBy("c66");
        //如果kyc记录是重新派单的话
        if (coutDispatchRecord > 1) {
            wsKycRequestProcessLog.setType("KYC re-distributed");
        } else {
            wsKycRequestProcessLog.setType("KYC distributed");
        }
        return wsKycRequestProcessLog;
    }

    private boolean shouldBePut2RedisHash(String redisKey, String hashKey, Object hashValue) {
        return StringUtils.isNotBlank(redisKey) && StringUtils.isNotBlank(hashKey) && !Objects.isNull(hashValue);
    }

    /**
     * 刷新派单用户配置
     *
     * @param content 派单用户配置域
     */
    private void refreshCustomConfiguration(JSONObject content) {
        String redisKey = CustomConfigurationHelper.obtainRedisKey(content);
        String hashKey = CustomConfigurationHelper.obtainHashKey(content);
        Object hashValue = CustomConfigurationHelper.obtainHashValue(content);
        if (shouldBePut2RedisHash(redisKey, hashKey, hashValue)) {
            redisUtil.putForHash(redisKey, hashKey, hashValue);
        }
    }

    /**
     * 刷出hash value
     *
     * @param queryKey 查询key
     * @return 查询key对应的hash value
     */
    private JSONObject flushHashValue(String queryKey) {
        return Optional.ofNullable(queryKey).filter(StringUtils::isNotBlank).map(e -> new JSONObject().fluentPut("data", redisUtil.entries(queryKey))).orElse(new JSONObject());
    }

    @Override
    public List<Integer> queryKycStatusByCustomerId(RiskQueryKycRequest kycRequest) {
        return kycRequestDao.queryKycStatusByCustomerId(kycRequest);
    }

    /**
     * 校验kyc id和type是否存在
     *
     * @param idType 证件类型
     * @param idNo   证件号码
     * @return true
     */
    @Override
    public boolean validKycIdAndTypeExist(Integer idType, String idNo) {
        try {
            String key = String.format(CronConstant.KYC_VALID_EXISTS, idType, idNo);
            Boolean bool = redisUtil.get(key, Boolean.class);
            if (Objects.nonNull(bool)) {
                return bool;
            }
            LambdaQueryWrapper<TKycDeduplicate> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(TKycDeduplicate::getIdType, idType);
            queryWrapper.eq(TKycDeduplicate::getIdNo, idNo);
            boolean exists = kycDeduplicateMapper.exists(queryWrapper);
            if (exists) {
                //缓存时长5小时
                redisUtil.set(key, true, 5 * 60 * 60L);
            }
            return exists;
        } catch (Exception e) {
            log.error("valid kyc exists error idType:{},idNo:{}", idType, idNo, e);
        }
        return false;
    }

    @Override
    public KycRequest queryKycByLoginNameOrderOne(RiskQueryKycRequest query){
        String key = String.format(Constant.RISK_KYC_LATEST_KEY, query.getCustomerId());//(fastgame 补充kyc信息需求)
        KycRequest kycBean = redisUtil.get(key, KycRequest.class);
        if (Objects.nonNull(kycBean)) {
            return kycBean;
        }
        RiskQueryKycRequest param = new RiskQueryKycRequest();
        param.setCustomerId(query.getCustomerId());
        param.setOrder("(case `status` when 1 then '3' when 0 then '1' else '0' end) desc,created_date desc");
        param.setPageNum(0);
        param.setPageSize(1);
        List<KycRequest> kycRequests = kycRequestDao.queryPageByCondition(param);
        if(CollectionUtils.isEmpty(kycRequests)){
            return null;
        }
        kycBean = kycRequests.get(0);
        redisUtil.set(key, kycBean,  60 * 60L);
        return kycBean;
    }

}
