package com.riskcontrol.cron.config;

import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.redisson.connection.DnsAddressResolverGroupFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.cache.RedisCacheWriter;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.io.Serializable;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;


@Configuration
@EnableCaching
class RedisConfig {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Value("${spring.redis.cluster.nodes}")
    private String redisNodes;

    @Value("${redisson.cluster.timeout}")
    private int timeout;

    @Value("${redisson.cluster.keepAlive}")
    private boolean keepAlive;

    @Value("${redisson.cluster.retryInterval}")
    private int retryInterval;

    @Value("${redisson.cluster.connectTimeout}")
    private int connectTimeout;

    @Value("${redisson.cluster.idleConnectionTimeout}")
    private int idleConnectionTimeout;

    @Value("${redisson.cluster.pingConnectionInterval}")
    private int pingConnectionInterval;

    @Value("${redisson.cluster.masterConnectionPoolSize}")
    private int masterConnectionPoolSize;

    @Value("${redisson.cluster.slaveConnectionPoolSize}")
    private int slaveConnectionPoolSize;

    @Value("${redisson.cluster.checkLockSyncedSlaves}")
    private boolean checkLockSyncedSlaves;

    @Value("${redisson.cluster.nettyThreads}")
    private int nettyThreads;

    @Value("${spring.redis.password}")
    private String password;

    @Value("${spring.redis.ssl:false}")
    private boolean sslEnable;

    /**
     * 缓存配置管理器
     *
     * @param factory
     * @return
     */
    @Bean
    @Primary
    public CacheManager cacheManager(RedisConnectionFactory factory) {
        // 配置序列化（缓存默认有效期 2小时）
        RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig().entryTtl(Duration.ofHours(2));
        RedisCacheConfiguration redisCacheConfiguration = config.serializeKeysWith(RedisSerializationContext.SerializationPair.fromSerializer(new StringRedisSerializer()))
                .serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(new GenericJackson2JsonRedisSerializer()));

        // 以锁写入的方式创建RedisCacheWriter对象
        //RedisCacheWriter writer = RedisCacheWriter.lockingRedisCacheWriter(factory);
        // 创建默认缓存配置对象
        /* 默认配置，设置缓存有效期 1小时*/
        //RedisCacheConfiguration defaultCacheConfig = RedisCacheConfiguration.defaultCacheConfig().entryTtl(Duration.ofHours(1));
        /* 自定义配置test:demo 的超时时间为 5分钟*/
        RedisCacheManager cacheManager = RedisCacheManager.builder(RedisCacheWriter.lockingRedisCacheWriter(factory)).cacheDefaults(redisCacheConfiguration)
                .transactionAware().build();
        return cacheManager;
    }

    @Bean
    public RedissonClient redissonClient() {
        String[] nodesUrl = redisNodes.split(",");
        List<String> clusterNodes = new ArrayList<>();
        for (int i = 0; i < nodesUrl.length; i++) {
            if(sslEnable){
                clusterNodes.add("rediss://" + nodesUrl[i]); //ssl 配置
            }else{
                clusterNodes.add("redis://" + nodesUrl[i]);
            }
            logger.info("redissonClient clusterNodes load nodes:{}",clusterNodes.get(i));
        }
        Config config = new Config();
        // 集群配置信息
        //  参数详解见 SLS confluence pageId=17018896
        config.useClusterServers()
                .setTimeout(timeout)
                .setKeepAlive(keepAlive) // redisTCP保活 检测死节点
                .setRetryInterval(retryInterval)
                .setConnectTimeout(connectTimeout)
                .setIdleConnectionTimeout(idleConnectionTimeout)
                .setPingConnectionInterval(pingConnectionInterval)
                .setMasterConnectionPoolSize(masterConnectionPoolSize)
                .setSlaveConnectionPoolSize(slaveConnectionPoolSize)
                .setPassword(password)
                .addNodeAddress(clusterNodes.toArray(new String[clusterNodes.size()]))
                .setSslEnableEndpointIdentification(!sslEnable);

        // 线上异常提示： Try to increase nettyThreads and/ or timeout settings
        config.setAddressResolverGroupFactory(new DnsAddressResolverGroupFactory())
                .setNettyThreads(nettyThreads)
                .setCheckLockSyncedSlaves(checkLockSyncedSlaves);

        RedissonClient redissonClient = Redisson.create(config);
        return redissonClient;
    }

    @Bean
    public RedisTemplate<Serializable, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<Serializable, Object> template = new RedisTemplate<Serializable, Object>();
        template.setConnectionFactory(redisConnectionFactory);
        template.setDefaultSerializer(new StringRedisSerializer());
        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(new GenericJackson2JsonRedisSerializer());
        template.setHashKeySerializer(new StringRedisSerializer());
        template.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());
        template.afterPropertiesSet();
        return template;
    }
}

