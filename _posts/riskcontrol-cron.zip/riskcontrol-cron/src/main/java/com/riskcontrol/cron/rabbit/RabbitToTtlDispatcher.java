//package com.riskcontrol.cron.rabbit;
//
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.amqp.core.Message;
//import org.springframework.amqp.core.MessageBuilder;
//import org.springframework.amqp.core.MessageProperties;
//import org.springframework.amqp.rabbit.core.RabbitTemplate;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
///**
// * @description:
// * @author: ErHu.Zhao
// * @create: 2024-09-27
// **/
//@Component
//@Slf4j
//public class RabbitToTtlDispatcher {
//    @Autowired
//    private RabbitTemplate rabbitTemplate;
//
//    public void dispatchMessage() {
//        Message message = MessageBuilder.withBody(jsonString.getBytes())
//                .setContentType(MessageProperties.CONTENT_TYPE_JSON)
//                .build();
//        rabbitTemplate.convertAndSend("withdraw_exchange_ttl_order", "withdraw.ttl.order.routing", message);
//    }
//
//}
