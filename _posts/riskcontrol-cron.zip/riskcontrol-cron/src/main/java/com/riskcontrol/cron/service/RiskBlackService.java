package com.riskcontrol.cron.service;

/**
 * @author Heng.zhang
 */
public interface RiskBlackService {


    /**
     * @param loginName
     * @return
     */
    Boolean getBlackStatus(String loginName);

}
