package com.riskcontrol.cron.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.riskcontrol.cron.entity.TPBCDeploy;
import org.apache.ibatis.annotations.Select;

import java.util.List;


public interface TPBCDeployMapper  extends BaseMapper<TPBCDeploy> {

    @Select("select id,system_id,system_name,main_address,sub_address,user_name,REPEAT('*',LENGTH (password)) as password,IFNULL(start_time, '') as start_time,IFNULL(end_time, '') as end_time,frequency,CASE when status = 1 then 'enable' ELSE 'disable' END as status,create_date,create_by,IFNULL(update_date, '') as update_date,IFNULL(update_by, '') as update_by,IFNULL(delete_date, '') as delete_date,IFNULL(delete_by, '') as delete_by,is_valid from t_pbc_deploy where is_valid = 'Y'")
    List<TPBCDeploy> selectLists();
}
