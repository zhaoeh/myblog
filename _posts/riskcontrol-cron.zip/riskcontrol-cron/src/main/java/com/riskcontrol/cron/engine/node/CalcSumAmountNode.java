package com.riskcontrol.cron.engine.node;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.date.TimeInterval;
import com.cn.schema.creditlogs.QueryDepositTransWithCheckResponse;
import com.cn.schema.creditlogs.WSQueryDepositTrans;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.engine.WithdrawContext;
import com.riskcontrol.cron.service.RequestService;
import com.yomahub.liteflow.annotation.LiteflowComponent;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * 时间段内总存款额
 *
 * @author dante
 */
@LiteflowComponent("calcSumAmountNode")
@Slf4j
public class CalcSumAmountNode extends AbstractWhenNode {
    @Autowired
    private RequestService requestService;

    @Override
    public void processWhen() throws Exception {
        WithdrawContext context = this.getFirstContextBean();
        OriWithdrawReq req = context.getReq();

        TimeInterval timer = DateUtil.timer();


        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDate start = LocalDate.parse(req.getLastWithDrawalDate(), dateTimeFormatter);
        LocalDate end = LocalDate.parse(req.getCreatedDate(), dateTimeFormatter);
        long diffDay = end.toEpochDay() - start.toEpochDay();
        int queryDays = StringUtils.isNotBlank(context.getMAX_QUERY_DEPOSIT_DAYS()) ?
                (Math.min(Integer.parseInt(context.getMAX_QUERY_DEPOSIT_DAYS()), 90)) : 90;
        String startDate = DateUtils.localDateToString(start);
        //拦截判断指定期间取款金额获取
        if (diffDay > queryDays) {
            String configDay = DateUtils.getBeforeDate(DateUtils.stringToDate(req.getCreatedDate(), DateUtils.DATE_FORMAT), -queryDays);
            //配置时间跟最后取款时间比较，大于于取配置时间，大于取最后取款日期
            String starTime = DateUtil.compare(DateUtil.parseDate(configDay), DateUtil.parseDate(req.getLastWithDrawalDate())) > 0
                    ? configDay : startDate;
            BigDecimal sumDpAmount = requestService.getPlayerTotalDeposit(starTime, DateUtils.localDateToString(end), req.getLoginName());
            log.info("取款申请withdrawRisk loginName:{},starTime：{} ,getPlayerTotalDeposit Timer {} ms", req.getLoginName(), starTime, timer.intervalRestart());
            context.setSumDpAmount(sumDpAmount);
        }
        //时间段内总存款额
        BigDecimal sumAmount = BigDecimal.ZERO;
        //大于7天，查大数据 ，可能是第一次取款
        if (diffDay > 7) {
            sumAmount = requestService.getPlayerTotalDeposit(startDate, DateUtils.localDateToString(end), req.getLoginName());
            log.info("取款申请withdrawRisk loginName:{},startDate：{} ,getPlayerTotalDeposit Timer {} ms", req.getLoginName(), startDate, timer.intervalRestart());
        } else {
            //查询取款交易记录
            WSQueryDepositTrans wsQueryDepositTrans = new WSQueryDepositTrans();
            wsQueryDepositTrans.setProductId(req.getProductId());
            wsQueryDepositTrans.setLoginName(req.getLoginName());
            wsQueryDepositTrans.setLastUpdateBegin(req.getLastWithDrawalDate());
            wsQueryDepositTrans.setLastUpdateEnd(req.getCreatedDate());
            wsQueryDepositTrans.setDeleteFlag("0");
            wsQueryDepositTrans.setStatus("2");
            QueryDepositTransWithCheckResponse queryDepositTransWithCheckResponse = requestService.queryDepositTransRecord(wsQueryDepositTrans);
            log.info("取款申请withdrawRisk loginName:{},queryDepositTransRecord Timer {} ms", req.getLoginName(), timer.intervalRestart());
            if (queryDepositTransWithCheckResponse != null && StringUtils.isNotBlank(queryDepositTransWithCheckResponse.getAmount())) {
                sumAmount = new BigDecimal(queryDepositTransWithCheckResponse.getAmount());
            }
        }
        context.setRISK_WITHDRAWAL_DIFFDAY(diffDay);
        context.setMAX_QUERY_DEPOSIT_DAYS(String.valueOf(queryDays));
        context.setSumAmount(sumAmount);
        //获取配置天数，没配置默认取90，大于90取90
//        int queryDays = StringUtils.isNotBlank(context.getMAX_QUERY_DEPOSIT_DAYS()) ? (Math.min(Integer.parseInt(context.getMAX_QUERY_DEPOSIT_DAYS()), 90)): 90;
//        String configDay = DateUtils.getBeforeDate(DateUtils.stringToDate(req.getCreatedDate(), DateUtils.DATE_TIME_FORMAT), - queryDays);
//        //配置时间跟最后取款时间比较，小于取配置时间，大于取最后取款日期
//        String starTime = DateUtil.compare(DateUtil.parseDate(configDay), DateUtil.parseDate(req.getLastWithDrawalDate())) < 0 ? configDay : req.getLastWithDrawalDate();
//        BigDecimal totalDeposit = requestService.getPlayerTotalDeposit(starTime, req.getCreatedDate(), req.getLoginName());
//        log.info("取款申请withdrawRisk loginName:{},starTime：{} ,getPlayerTotalDeposit Timer {} ms", req.getLoginName(),starTime, timer.intervalRestart());
//        context.setSumAmount(sumAmount);
//        //查询取款交易记录
//        WSQueryDepositTrans wsQueryDepositTrans = new WSQueryDepositTrans();
//        wsQueryDepositTrans.setProductId(req.getProductId());
//        wsQueryDepositTrans.setLoginName(req.getLoginName());
//        wsQueryDepositTrans.setLastUpdateBegin(req.getLastWithDrawalDate());
//        wsQueryDepositTrans.setLastUpdateEnd(req.getCreatedDate());
//        wsQueryDepositTrans.setDeleteFlag("0");
//        wsQueryDepositTrans.setStatus("2");
//
//        TimeInterval timer = DateUtil.timer();
//        QueryDepositTransWithCheckResponse queryDepositTransWithCheckResponse = requestService.queryDepositTransRecord(wsQueryDepositTrans);
//        //时间段内总存款额
//        BigDecimal sumAmount = BigDecimal.ZERO;
//        if (queryDepositTransWithCheckResponse != null && StringUtils.isNotBlank(queryDepositTransWithCheckResponse.getAmount())) {
//            sumAmount = new BigDecimal(queryDepositTransWithCheckResponse.getAmount());
//        }
//        context.setSumAmount(sumAmount);
    }
}
