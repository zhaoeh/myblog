//package com.riskcontrol.cron.service;
//
//import java.util.List;
//
//
///**
// * 产品定义服务层接口类
// *
// * @author Wason.H
// * @date 2018-02-24 16:17:48.
// */
//public interface ProductService {
//
//    /**
//     * 获取所有的产品ID
//     *
//     * @param productId
//     * @return 所有产品ID 或者 空list
//     */
//    List<String> getProductIds(String productId);
//}
