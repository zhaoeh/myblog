package com.riskcontrol.cron.aspect;

import com.riskcontrol.cron.datasource.DBSourceCheck;
import com.riskcontrol.cron.datasource.DataSourceType;
import com.riskcontrol.cron.datasource.DbContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

/**
 * aop
 *
 * @author dante
 */
@Slf4j
@Aspect
@Component
@Order(-1)
@RefreshScope
public class DataSourceAsp {

    @Pointcut(value = "@annotation(com.riskcontrol.cron.datasource.DBSourceCheck)")
    void dataSourcePointcut() {

    }

    @Before(value = "dataSourcePointcut()")
    public void doBefore(JoinPoint point) {
        Method m = ((MethodSignature) point.getSignature()).getMethod();
        DBSourceCheck dbSourceCheck = m.getAnnotation(DBSourceCheck.class);
        if (dbSourceCheck != null) {
            log.info("正在使用数据库：{}查询数据源", dbSourceCheck.value());
            DbContextHolder.setDbType(dbSourceCheck.value().getName());
            return;
        }
        DbContextHolder.setDbType(DataSourceType.Default.getName());
    }

    @After(value = "dataSourcePointcut()")
    public void doAfter(JoinPoint point) {
        DbContextHolder.setDbType(DataSourceType.Default.getName());
    }
}