package com.riskcontrol.cron.service.impl;

import com.cn.schema.other.WSMsgMqSendRecord;
import com.cn.schema.other.WSQueryMsgMqSendRecord;
import com.google.common.collect.Maps;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.enums.ErrCodeEnum;
import com.riskcontrol.cron.mapper.MsgMqDao;
import com.riskcontrol.cron.service.AbstractService;
import com.riskcontrol.cron.service.MsgMqService;
import com.riskcontrol.cron.utils.CommonLogic;
import com.riskcontrol.cron.utils.ValidationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * MQ消息发送记录表服务层实现类
 *
 * @author wade
 * @date 2018-08-29 09:52:47.
 */
@Service
public class MsgMqServiceImpl extends AbstractService implements MsgMqService {

    @Autowired
    private MsgMqDao msgMqDao;

    /**
     * 查询符合条件的信息分页
     *
     * @param query 查询条件
     * @return List<WSMsgMqSendRecord> MQ消息发送记录表列表
     * @throws BusinessException
     */
    @Override
    public List<WSMsgMqSendRecord> queryPageMsgMqByCondition(WSQueryMsgMqSendRecord query) throws BusinessException {
        query = checkMsgMqQueryPagePara(query);
        if (query.getPageSize() == 0) {
            query.setPageSize(CronConstant.PAGE_SIZE);
        } else if (query.getPageSize() > CronConstant.PAGE_MAX_SIZE) {
            throw new BusinessException(ErrCodeEnum.MSG_100003);
        }
        query.setPageNum(CommonLogic.buildFirstPageParamOfMySql(query.getPageNum(), query.getPageSize()));
        return msgMqDao.queryPageMsgMqByCondition(query);
    }

    /**
     * 查询分页参数检查
     *
     * @param query 查询条件
     * @return query 设置后的查询条件
     * @throws BusinessException
     */
    private WSQueryMsgMqSendRecord checkMsgMqQueryPagePara(WSQueryMsgMqSendRecord query) throws BusinessException {
        //查询参数校验
        ValidationUtils.checkIsNull(query, ErrCodeEnum.MSG_500018);
        return query;
    }

    /**
     * 根据主键查询信息
     *
     * @param id 主键
     * @return WSMsgMqSendRecord
     * @throws BusinessException
     */
    @Override
    public WSMsgMqSendRecord loadMsgMqById(String id) throws BusinessException {

        if (null == id) {
            throw new BusinessException(ErrCodeEnum.MSG_500000);
        }
        return msgMqDao.loadMsgMqById(id);
    }

    /**
     * 创建信息
     *
     * @param bean 需要创建的信息
     * @return WSMsgMqSendRecord 创建后结果
     * @throws BusinessException
     */
    @Override
    public WSMsgMqSendRecord createMsgMq(WSMsgMqSendRecord bean) throws BusinessException {
        ValidationUtils.checkIsNull(bean, ErrCodeEnum.MSG_500018);
        msgMqDao.createMsgMq(bean);
        return loadMsgMqById(bean.getId());
    }


    @Override
    public int deleteById(String id, String productId) throws BusinessException {
        ValidationUtils.checkIsNull(id, ErrCodeEnum.MSG_504301);
        ValidationUtils.checkIsNull(productId, ErrCodeEnum.MSG_403606);
        Map<String, String> map = Maps.newHashMap();
        map.put("id", id);
        map.put("productId", productId);
        return msgMqDao.deleteById(map);
    }
}
