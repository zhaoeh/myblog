package com.riskcontrol.cron.core;

import com.baomidou.mybatisplus.extension.service.IService;

public interface BaseService<T> extends IService<T> {
}
