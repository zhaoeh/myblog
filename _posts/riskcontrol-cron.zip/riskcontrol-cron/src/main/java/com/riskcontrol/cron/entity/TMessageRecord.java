package com.riskcontrol.cron.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 消息记录表
 * </p>
 *
 * @author Colson
 * @program: riskcontrol-cron
 * @date  2023-10-16
 */
@Getter
@Setter
@TableName("t_message_record")
@ApiModel(value = "TMessageRecord对象", description = "消息记录表")
public class TMessageRecord extends BaseFullEntity {

    private static final long serialVersionUID = 1L;


    @ApiModelProperty("rabbitMQ exchange name")
    private String exchangeName;

    @ApiModelProperty("队列名称")
    private String routingKey;

    @ApiModelProperty("消息类型")
    private String flag;

    @ApiModelProperty("域名")
    private String domainName;

    @ApiModelProperty("所属产品")
    private String productId;

    @ApiModelProperty("登录用户名")
    private String loginName;

    @ApiModelProperty("用户id")
    private String customerId;

    @ApiModelProperty("ip")
    private String ipAddress;

    @ApiModelProperty("加密手机号码")
    private String phoneMd5;

    @ApiModelProperty("旧值")
    private String oldValue;

    @ApiModelProperty("新值")
    private String newValue;

    @ApiModelProperty("旧值MD5")
    private String oldValueMd5;

    @ApiModelProperty("新值MD5")
    private String newValueMd5;

    @ApiModelProperty("货币")
    private String currency;

    @ApiModelProperty("手机号码")
    private String phone;

    @ApiModelProperty("手机号码验证状态")
    private String phoneValidateStatus;

    @ApiModelProperty("注册来源类型")
    private String registerFromType;

    @ApiModelProperty("站点ID")
    private String siteId;

    @ApiModelProperty("消息处理状态：0-待消费，1-已消费，2-消费失败")
    private Integer status;

    @ApiModelProperty("消息内容uuid")
    private String contentUuid;

    @ApiModelProperty("创建人")
    private String createBy;

    @ApiModelProperty("更新人")
    private String updateBy;

}
