package com.riskcontrol.cron.engine.node;

import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.engine.WithdrawContext;
import com.riskcontrol.cron.enums.WithdrawFilterEnum;
import com.yomahub.liteflow.annotation.LiteflowComponent;
import com.yomahub.liteflow.core.NodeIfComponent;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@LiteflowComponent("dateCheckNode")
@Slf4j
public class DateCheckNode extends NodeIfComponent {
    @Override
    public boolean processIf() throws Exception {
        return true;
    }
}
