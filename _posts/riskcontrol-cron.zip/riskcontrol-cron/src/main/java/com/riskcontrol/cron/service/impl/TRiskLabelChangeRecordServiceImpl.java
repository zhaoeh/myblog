package com.riskcontrol.cron.service.impl;

import com.riskcontrol.cron.core.BaseServiceImpl;
import com.riskcontrol.cron.entity.TRiskLabelChangeRecord;
import com.riskcontrol.cron.mapper.TRiskLabelChangeRecordMapper;
import com.riskcontrol.cron.service.TRiskLabelChangeRecordService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户标签绑定关系表 服务实现类
 * </p>
 *
 * @author Yannis
 * @since 2024-01-11
 */
@Service
public class TRiskLabelChangeRecordServiceImpl extends BaseServiceImpl<TRiskLabelChangeRecordMapper, TRiskLabelChangeRecord> implements TRiskLabelChangeRecordService {

}
