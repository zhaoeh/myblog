package com.riskcontrol.cron.controller;

import com.riskcontrol.common.entity.request.api.QueryRiskConstants;
import com.riskcontrol.common.entity.request.label.RiskLabelBindingRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelByCustomerIdRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelListRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelRemoveBindingRequest;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.api.RiskConstantsRsp;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelRsp;
import com.riskcontrol.cron.service.TRiskConstantsService;
import com.riskcontrol.cron.service.TRiskLabelRelationshipService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @program: riskcontrol-api
 * @description: 风控标签
 * @author: Colson
 * @create: 2024-01-11 18:28
 */
@RestController
@RequestMapping("/risk/label")
@Api("风控标签相关接口")
public class RiskLabelController {

    @Resource
    private TRiskLabelRelationshipService riskLabelRelationshipService;

    @Resource
    private TRiskConstantsService riskConstantsService;

    @PostMapping("list")
    @ApiOperation(value = "获取所有风控标签")
    public Response<List<RiskConstantsRsp>> listRiskLabel() {
        return Response.body(riskConstantsService.listAllRiskLabel());
    }

    @PostMapping("listByParam")
    @ApiOperation(value = "通过查询条件获取所有风控标签")
    public Response<List<RiskConstantsRsp>> queryRiskConstantsList(@RequestBody QueryRiskConstants request) {
        return Response.body(riskConstantsService.doQueryRiskConstantsList(request));
    }

    @PostMapping("customer/list")
    @ApiOperation(value = "批量查询用户风控标签")
    public Response<List<CustomerRiskLabelRsp>> listCustomerRiskLabel(@Valid @RequestBody RiskLabelListRequest request) {
        return Response.body(riskLabelRelationshipService.listCustomerRiskLabel(request));
    }

    @PostMapping("customer/detail")
    @ApiOperation(value = "用户风控标签详情")
    public Response<CustomerRiskLabelRsp> detail(@Valid @RequestBody RiskLabelByCustomerIdRequest request) {
        return Response.body(riskLabelRelationshipService.getRiskLabelDetail(request));
    }

    @PostMapping("customer/getCustomerLabelRules")
    @ApiOperation(value = "根据用户id获取优先级最高的标签绑定的规则集合")
    public Response<List<String>> getCustomerLabelRules(@RequestParam Long customerId) {
        return Response.body(riskLabelRelationshipService.getCustomerLabelRules(customerId));
    }

    @PostMapping("customer/binding")
    @ApiOperation(value = "绑定用户风控标签")
    public Response<Boolean> binding(@Valid @RequestBody RiskLabelBindingRequest request) {
        return Response.body(riskLabelRelationshipService.bindingCustomerRiskLabel(request));
    }

    @PostMapping("customer/removeLabel")
    @ApiOperation(value = "解除用户风控标签")
    public Response<Boolean> removeLabel(@Valid @RequestBody RiskLabelRemoveBindingRequest request) {
        return Response.body(riskLabelRelationshipService.removeLabel(request));
    }

}
