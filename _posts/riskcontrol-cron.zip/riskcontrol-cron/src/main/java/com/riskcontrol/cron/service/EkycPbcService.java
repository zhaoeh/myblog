package com.riskcontrol.cron.service;

import com.riskcontrol.cron.entity.TRiskBlack;

/**
 * @description: ekyc pbc 服务
 * @author: ErHu.Zhao
 * @create: 2024-10-30
 **/
public interface EkycPbcService {

    /**
     * 插入黑名单*
     *
     * @param black 黑名单实体
     * @return 是否插入成功 true：插入成功  false：插入失败
     */
    Boolean doInsertBlack(TRiskBlack black);
}
