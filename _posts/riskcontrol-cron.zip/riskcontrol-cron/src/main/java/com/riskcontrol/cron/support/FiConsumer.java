package com.riskcontrol.cron.support;

/**
 * @description: 4参消费者
 * @author: ErHu.Zhao
 * @create: 2024-09-19
 **/
@FunctionalInterface
public interface FiConsumer<P1, P2, P3, P4> {

    void accept(P1 p1, P2 p2, P3 p3, P4 p4);
}
