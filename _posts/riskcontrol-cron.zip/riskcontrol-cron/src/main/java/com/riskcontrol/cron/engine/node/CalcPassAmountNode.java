package com.riskcontrol.cron.engine.node;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.date.TimeInterval;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cn.schema.creditlogs.QueryDepositTransWithCheckResponse;
import com.cn.schema.creditlogs.WSQueryDepositTrans;
import com.cn.schema.request.QueryWithdrawalRequestsResponse;
import com.cn.schema.request.WSQueryWithdrawalRequests;
import com.cn.schema.request.WSWithdrawalRequests;
import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.engine.WithdrawContext;
import com.riskcontrol.cron.service.RequestService;
import com.yomahub.liteflow.annotation.LiteflowComponent;
import com.yomahub.liteflow.core.NodeComponent;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 计算时间段连续通过的次数和金额
 * @author dante
 */
@LiteflowComponent("calcPassAmountNode")
@Slf4j
public class CalcPassAmountNode extends AbstractWhenNode {
    @Autowired
    private RequestService requestService;
    @Override
    public void processWhen() throws Exception {
        WithdrawContext context = this.getFirstContextBean();
        OriWithdrawReq req = context.getReq();

        TimeInterval timer = DateUtil.timer();
        WSQueryWithdrawalRequests queryWithdrawalRequests = new WSQueryWithdrawalRequests();
        queryWithdrawalRequests.setProductId(req.getProductId());
        queryWithdrawalRequests.setLoginName(req.getLoginName());
        queryWithdrawalRequests.setCatalog("0;11;12;13;14;15");
        queryWithdrawalRequests.setPageSize(100);
        QueryWithdrawalRequestsResponse queryWithdrawalRequestsResponse = requestService.queryWithdrawalRequestDesc(JSONObject.parseObject(JSONObject.toJSONString(queryWithdrawalRequests)));

        List<WSWithdrawalRequests> withdrawalRequestsList = queryWithdrawalRequestsResponse.getWSWithdrawalRequests();

        log.info("取款申请withdrawRisk loginName:{} queryCountWithdrawRequest Timer {} ms", req.getLoginName(), timer.intervalRestart());
        BigDecimal todayLimit = BigDecimal.ZERO;
        BigDecimal totalPassedAmount = BigDecimal.ZERO;
        if (!withdrawalRequestsList.isEmpty()) {
            BigDecimal withdrawalAmount = BigDecimal.ZERO;
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            List<WSWithdrawalRequests> collect = withdrawalRequestsList.stream().filter(Objects::nonNull).filter(w -> LocalDate.parse(w.getCreatedDate(), dateTimeFormatter).equals(LocalDate.now()) && ("1".equals(w.getFlag()) || "2".equals(w.getFlag()))).collect(Collectors.toList());
            if (!collect.isEmpty()) {
                double sum = collect.stream().mapToDouble(w -> new BigDecimal(w.getAmount()).doubleValue()).sum();
                if (sum > 0) {
                    withdrawalAmount = BigDecimal.valueOf(sum);
                }
            }
            context.setTodayPass(collect.size());
            todayLimit = todayLimit.add(withdrawalAmount);

            List<WSWithdrawalRequests> collected = withdrawalRequestsList.stream().filter(Objects::nonNull).filter(w -> !"0".equals(w.getFlag())).collect(Collectors.toList());

            if (!collected.isEmpty()) {
                List<WSWithdrawalRequests> sortedWithdrawal = collected.stream().filter(Objects::nonNull).sorted(Comparator.comparing(WSWithdrawalRequests::getCreatedDate).reversed()).collect(Collectors.toList());
                List<WSWithdrawalRequests> passedList = new ArrayList<>();

                for (WSWithdrawalRequests withdrawalRequests : sortedWithdrawal) {
                    if ("0".equals(withdrawalRequests.getExceptionPromptType())) {
                        passedList.add(withdrawalRequests);
                    } else {
                        break;
                    }
                }
                context.setTotalPassedCount(passedList.size());
                totalPassedAmount = BigDecimal.valueOf(passedList.stream().mapToDouble(w -> Double.parseDouble(w.getAmount())).sum());
            }
        }
        todayLimit = todayLimit.add(req.getAmount());

        context.setTotalPassedAmount(totalPassedAmount);
        context.setTodayLimit(todayLimit);
    }
}
