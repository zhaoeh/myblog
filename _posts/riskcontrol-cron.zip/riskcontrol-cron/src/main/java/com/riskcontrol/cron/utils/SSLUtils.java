package com.riskcontrol.cron.utils;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.springframework.context.annotation.Bean;

import javax.net.ssl.*;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/6/3 16:15
 */
public class SSLUtils {
    public static void trustAllHosts() {
        // 创建SSLContext对象，并使用我们定义的信任管理器初始化
        try {
            // 初始化SSLContext
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, getTrustManager(), new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier((hostname,session) -> true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 创建一个信任所有证书的TrustManager
    public static TrustManager[] getTrustManager(){
        TrustManager[]  trustManagers = new TrustManager[]{
                new X509TrustManager() {
                    @Override
                    public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {

                    }

                    @Override
                    public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {

                    }

                    @Override
                    public X509Certificate[] getAcceptedIssuers() {
                        return new X509Certificate[]{};
                    }
                }
        };
        return trustManagers;
    }
}
