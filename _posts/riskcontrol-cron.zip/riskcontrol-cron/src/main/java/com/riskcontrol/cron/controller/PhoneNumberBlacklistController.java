package com.riskcontrol.cron.controller;

import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.request.api.*;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.api.PhoneCoolingDownPeriodRsp;
import com.riskcontrol.common.entity.response.api.PhoneNumberBlacklistRsp;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.cron.datasource.DBSourceCheck;
import com.riskcontrol.cron.datasource.DataSourceType;
import com.riskcontrol.cron.entity.TPhoneNumberBlacklist;
import com.riskcontrol.cron.service.PhoneNumberBlacklistService;
import com.riskcontrol.cron.utils.RedisUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @program: riskcontrol-cron
 * @description: 手机号黑名单 前端控制器
 * @author: Colson
 * @create: 2023-09-26 14:19
 */
@Slf4j
@RestController
@RequestMapping("/phoneNumberBlacklist")
@Api("手机号码黑名单相关接口")
public class PhoneNumberBlacklistController {

    @Resource
    private PhoneNumberBlacklistService phoneNumberBlacklistService;
    @Resource
    private RedisUtil redisUtil;

    @PostMapping("page")
    @ApiOperation(value = "手机号码黑名单分页列表")
    @DBSourceCheck(DataSourceType.SLAVE)
    public Response<PageModel<PhoneNumberBlacklistRsp>> getPage(@RequestBody PhoneNumberBlacklistPageRequest request) {
        Response<PageModel<PhoneNumberBlacklistRsp>> response = new Response<>();
        response.setBody(phoneNumberBlacklistService.pagePhoneNumberBlackList(request));
        return response;
    }

    @PostMapping("list")
    @ApiOperation(value = "手机号码黑名单列表")
    @DBSourceCheck(DataSourceType.SLAVE)
    public Response<List<PhoneNumberBlacklistRsp>> getList(@RequestBody PhoneNumberBlacklistRequest request) {
        Response<List<PhoneNumberBlacklistRsp>> response = new Response<>();
        response.setBody(phoneNumberBlacklistService.listPhoneNumberBlacklist(request));
        return response;
    }

    @PostMapping("one")
    @ApiOperation(value = "根据手机号码查询黑名单（单条查询）")
    public Response<PhoneNumberBlacklistRsp> getOne(@RequestBody PhoneNumberBlacklistGetOneRequest request) {
        Response<PhoneNumberBlacklistRsp> response = new Response<>();
        PhoneNumberBlacklistRsp phoneNumberBlacklistRsp = phoneNumberBlacklistService.getPhoneNumberBlacklist(request);
        response.setBody(phoneNumberBlacklistRsp);
        if(phoneNumberBlacklistRsp == null){
            response.setHead(ResultEnum.PHONE_NUMBER_BLACKLIST_NOT_EXIST.getCode(), ResultEnum.PHONE_NUMBER_BLACKLIST_NOT_EXIST.getMessage());
        }
        return response;
    }

    @PostMapping("create")
    @ApiOperation(value = "创建手机号码黑名单")
    public Response<Boolean> create(@Valid @RequestBody PhoneNumberBlacklistCreateRequest request) {
        Response<Boolean> response = new Response<>();
        Boolean blacklistFlag = phoneNumberBlacklistService.createPhoneNumberBlacklist(request);
        response.setBody(blacklistFlag);
        if (blacklistFlag){
            redisUtil.remove(String.format(Constant.PHONE_BLACK_LIST_KEY, request.getPhoneMd5()));
        }
        return response;
    }


    @PostMapping("updateHistory")
    @ApiOperation(value = "更新手机号码黑名单绑定用户ID")
    public Response<Boolean> updateHistory(@Valid @RequestBody PhoneNumberBlacklistUpdateHistoryRequest request) {
        Response<Boolean> response = new Response<>();
        TPhoneNumberBlacklist blacklist = phoneNumberBlacklistService.getById(request.getId());
        if (ObjectUtils.isNotEmpty(blacklist)){
            Boolean blackListFlag = phoneNumberBlacklistService.updatePhoneNumberBlacklistHistory(request);
            response.setBody(blackListFlag);
            redisUtil.remove(String.format(Constant.PHONE_BLACK_LIST_KEY, blacklist.getPhoneMd5()));
        }
        return response;
    }


    @PostMapping("updateStatus")
    @ApiOperation(value = "更新手机号码黑名单状态")
    public Response<Boolean> updateStatus(@Valid @RequestBody PhoneNumberBlacklistUpdateStatusRequest request) {
        Response<Boolean> response = new Response<>();
        TPhoneNumberBlacklist blacklist = phoneNumberBlacklistService.getById(request.getId());
        if (ObjectUtils.isNotEmpty(blacklist)) {
            Boolean flag = phoneNumberBlacklistService.updatePhoneNumberBlacklistStatus(request);
            response.setBody(flag);
            redisUtil.remove(String.format(Constant.PHONE_BLACK_LIST_KEY, blacklist.getPhoneMd5()));
        }
        return response;
    }

    @PostMapping("coolingDownPeriod")
    @ApiOperation(value = "查询手机号码是否在冷却期内")
    public Response<PhoneCoolingDownPeriodRsp> coolingDownPeriod(@RequestBody PhoneCoolingDownPeriodRequest request) {
        Response<PhoneCoolingDownPeriodRsp> response = new Response<>();
        response.setBody(phoneNumberBlacklistService.getCoolingDownPeriod(request));
        return response;
    }


    @GetMapping("task/test")
    @ApiOperation(value = "测试定时任务重置失效的手机号码黑名单状态")
    public Response<Boolean> taskReset() {
        log.info("task/test taskReset 测试定时任务重置失效的手机号码黑名单状态");
        Response<Boolean> response = new Response<>();
        response.setBody(phoneNumberBlacklistService.checkAndResetStatus());
        return response;
    }


}
