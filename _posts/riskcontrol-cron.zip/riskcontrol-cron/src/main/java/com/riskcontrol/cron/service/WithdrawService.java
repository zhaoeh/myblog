package com.riskcontrol.cron.service;

import com.cn.schema.request.WSWithdrawalRequests;
import com.digiplus.common.exception.KafkaShieldException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.engine.WithdrawContext;
import com.riskcontrol.cron.entity.RiskFilterLog;

import java.util.function.Function;

/**

 * @Overview:风控取款审核服务
 */
public interface WithdrawService {
    /**
     * 发送取款审核到重试mq消息队列（开关控制发送rabbitmq和kafka）
     * @param requestId
     * @param productId
     * @throws KafkaShieldException
     * @throws JsonProcessingException
     */
    void sendWithToRiskMq(String requestId, String productId) throws KafkaShieldException, JsonProcessingException;
    /**
     * 取款风控方法
     *
     * @param req      生成的取款提案
     * @param withdrawRiskKey 取款风控JMS_WITHDRAW_RISK开关
     * @param withdrawRiskRetryKey 取款风控JMS_WITHDRAW_RISK_RETRY重试开关
     * @return
     */
    boolean withdrawRisk(OriWithdrawReq req, boolean withdrawRiskKey, boolean withdrawRiskRetryKey);

    /**
     * 获取取款信息
     * @param requestId
     * @param productId
     * @return
     */
    String queryWithdrawalInfo(String requestId, String productId);

    /**
     * 获取当前取款订单信息
     *
     * @param req        当前订单请求
     * @param isUseCache 是否使用缓存
     * @return 当前取款订单信息
     */
    WSWithdrawalRequests queryCurrentOrder(OriWithdrawReq req, boolean isUseCache);

    /**
     * 获取当前订单的上一笔取款订单信息
     *
     * @param req 当前订单请求
     * @return 上一笔取款订单信息
     */
    WSWithdrawalRequests queryLastOrder(OriWithdrawReq req);

    /**
     * 自动审核通过
     *
     * @param context 上下文
     * @return 是否审核通过 true：通过 false：未通过
     */
    boolean requestApprove(WithdrawContext context);

    /**
     * 人工审核
     *
     * @param context 上下文
     * @return
     */
    boolean modifyExceptionPrompt(WithdrawContext context);

    /**
     * 熔断处理流程
     *
     * @param req
     * @return
     */
    boolean withdrawRiskWithDowngrade(OriWithdrawReq req);

    /**
     * 为 WithdrawContext 织入逻辑
     *
     * @param context 上下文
     * @param mapper  逻辑映射器
     * @return 织入逻辑后的上下文
     */
    WithdrawContext weaveLogicForWithdrawContext(WithdrawContext context, Function<WithdrawContext, WithdrawContext> mapper);

    /**
     * 风控日志记录
     *
     * @param filterFlag           是否开启日志记录
     * @param withdrawRiskRetryKey 是否开启重试
     * @param requestId            当前取款订单请求id
     * @param riskFilterLog        日志实体
     */
    void handleRiskLog(boolean filterFlag, boolean withdrawRiskRetryKey, String requestId, RiskFilterLog riskFilterLog);
}
