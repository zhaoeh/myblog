package com.riskcontrol.cron.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.riskcontrol.common.entity.request.device.LoginCheckRequest;
import com.riskcontrol.common.entity.request.device.RegisterCheckRequest;
import com.riskcontrol.common.entity.request.device.RegisterSaveRequest;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.device.LoginCheckResponse;
import com.riskcontrol.common.entity.response.device.RegisterCheckResponse;
import com.riskcontrol.common.enums.RiskActionInterceptTypeEnum;
import com.riskcontrol.cron.kafka.KafkaTopic;
import com.riskcontrol.cron.po.KafkaDeviceInfo;
import com.riskcontrol.cron.service.TRiskActionLoginService;
import com.riskcontrol.cron.service.TRiskActionRegistrationService;
import com.riskcontrol.cron.utils.KafkaProductUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author Heng.zhang
 */
@RestController
@Api("风控行为规则")
@RequestMapping("/risk/check")
@Slf4j
public class RiskDeviceController {

    @Autowired
    private TRiskActionRegistrationService riskActionRegistrationService;

    @Autowired
    private TRiskActionLoginService riskActionLoginService;

    @Autowired
    private KafkaProductUtils kafkaProductUtils;

    @Autowired
    private ObjectMapper objectMapper;

    @PostMapping(value = "/registerCheck")
    @ApiOperation(value = "注册风控校验")
    @ResponseBody
    public Response<RegisterCheckResponse> registerCheck(@RequestBody RegisterCheckRequest registerCheckRequest) {
        return Response.body(riskActionRegistrationService.registerCheck(registerCheckRequest));
    }

    @PostMapping(value = "/registerSave")
    @ApiOperation(value = "注册风控信息写入")
    @ResponseBody
    public Response<Boolean> registerSave(@RequestBody RegisterSaveRequest registerSaveRequest) throws JsonProcessingException {
        // push注册风控明细到kafka
        kafkaProductUtils.pushKafkaMsg(KafkaTopic.DEVICE_KYC_TOPIC_SELF, this.objectMapper.writeValueAsString(new KafkaDeviceInfo()
                .setRegisterSaveRequest(registerSaveRequest)
                .setInterceptTypeOfRegisterSaveRequest(StringUtils.isBlank(registerSaveRequest.getDeviceFingerprint()) || StringUtils.isBlank(registerSaveRequest.getRegisterIp()) ? RiskActionInterceptTypeEnum.DEVICE_ABNORMAL_THROUGH.getId() : RiskActionInterceptTypeEnum.PASS_THROUGH.getId())
        ));
        return Response.body(true);
    }

    @PostMapping(value = "/loginCheck")
    @ApiOperation(value = "登录风控校验")
    @ResponseBody
    public Response<LoginCheckResponse> loginCheck(@RequestBody LoginCheckRequest loginCheckRequest) {
        return Response.body(riskActionLoginService.loginCheck(loginCheckRequest));
    }

}
