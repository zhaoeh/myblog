///**
// * @Overview:产品信息处理相关接口实现类
// * @author sky.x
// * @History: 2013-02-12 重新整理代码
// */
//package com.riskcontrol.cron.service.impl;
//
//import com.cn.schema.products.WSProductConstants;
//import com.cn.schema.products.WSQueryProductConstants;
//import com.riskcontrol.cron.constants.CronConstant;
//import com.riskcontrol.cron.dao.BaseDao;
//import com.riskcontrol.cron.dao.WSProductConstantsRowMapper;
//import com.riskcontrol.cron.service.BaseServiceImpl;
//import com.riskcontrol.cron.service.WSProductsService;
//import com.riskcontrol.cron.utils.CommonLogic;
//import com.riskcontrol.cron.utils.MultiProductUtil;
//import com.riskcontrol.cron.utils.RedisUtil;
//import org.springframework.stereotype.Service;
//import org.springframework.util.StringUtils;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
///**
// * 产品信息处理相关接口实现类
// */
//@Service
//public class WSProductsServiceImpl extends BaseServiceImpl implements WSProductsService {
//
//
//    public List<WSProductConstants> queryProductConstantsReal(BaseDao dao, WSQueryProductConstants query) throws Exception {
//        // / 根据查询参数得到查询条件和SQL
//        Map<Object, Object> map;
//        if (null == query || !query.isAllData()) {
//            // 分页查询
//            map = getQueryProductConstantsSql(query, 1);
//        } else {
//            // 查询符合条件所有数据
//            map = getQueryProductConstantsSql(query, 0);
//        }
//        String sql = (String) map.get("sql");
//        List<Object> params = (List<Object>) map.get("params");
//        List<WSProductConstants> list = dao.sqlQuery(sql, params, new WSProductConstantsRowMapper(), WSProductConstants.class);
//        if (!CommonLogic.isEmpty(list)) {
//            return list;
//        } else {
//            return null;
//        }
//    }
//
//    private void packageSqlAndParamsByCondition(StringBuilder sql, List<Object> params, WSQueryProductConstants query, int flag) {
//        // 0=查询SQL 1=分页查询SQL,2=查询COUNT SQL
//        if (0 == flag || 1 == flag) {
//            sql.append("SELECT * FROM t_product_constants t WHERE t.p_key != 'AAC001' ");
//        } else {
//            sql.append("SELECT count(1) FROM t_product_constants t WHERE 1=1");
//        }
//        // 取默认分页参数
//        int pageNum = CronConstant.PAGE_NUM;
//        int pageSize = CronConstant.PAGE_SIZE;
//        // 根据条件拼装SQL和参数列表
//        if (null != query) {
//            if (checkIsEmpty(query.getId())) {
//                sql.append(" and t.id = ?");
//                params.add(query.getId());
//            }
//
//            if (checkIsEmpty(query.getProductId())) {
//                sql.append(" and t.product_id = ?");
//                params.add(query.getProductId());
//            }
//
//            if (checkIsEmpty(query.getKey())) {
//                if (query.getKey().contains("%") || query.getKey().contains("_")) {
//                    sql.append(" and t.p_key like ?");
//                } else {
//                    sql.append(" and t.p_key = ?");
//                }
//                params.add(query.getKey());
//            }
//
//            if (checkIsEmpty(query.getValue())) {
//                if (query.getValue().contains("%") || query.getValue().contains("_")) {
//                    sql.append(" and t.p_value like ?");
//                } else {
//                    sql.append(" and t.p_value = ?");
//                }
//                params.add(query.getValue());
//            }
//
//            if (checkIsEmpty(query.getType())) {
//                sql.append(" and t.p_type = ?");
//                params.add(query.getType());
//            }
//
//            if (checkIsEmpty(query.getCreatedBy())) {
//                sql.append(" and t.created_by = ?");
//                params.add(query.getCreatedBy());
//            }
//
//            if (checkIsEmpty(query.getLastUpdatedBy())) {
//                sql.append(" and t.update_by = ?");
//                params.add(query.getLastUpdatedBy());
//            }
//
//            if (checkIsEmpty(query.getCreatedDateBegin())) {
//                sql.append(" and t.create_time >= str_to_date(?,'%Y-%m-%d %H:%i:%S')");
//                params.add(query.getCreatedDateBegin());
//            }
//
//            if (checkIsEmpty(query.getCreatedDateEnd())) {
//                sql.append(" and t.create_time <= str_to_date(?,'%Y-%m-%d %H:%i:%S')");
//                params.add(query.getCreatedDateEnd());
//            }
//
//            if (checkIsEmpty(query.getLastUpdateBegin())) {
//                sql.append(" and t.update_time >= str_to_date(?,'%Y-%m-%d %H:%i:%S')");
//                params.add(query.getLastUpdateBegin());
//            }
//
//            if (checkIsEmpty(query.getLastUpdateEnd())) {
//                sql.append(" and t.update_time <= str_to_date(?,'%Y-%m-%d %H:%i:%S')");
//                params.add(query.getLastUpdateEnd());
//            }
//
//            if (checkIsEmpty(query.getOrder())) {
//                sql.append(" order by t.").append(query.getOrder());
//            } else {
//                sql.append(" order by t.p_key,t.update_time desc");
//            }
//
//            if (query.getPageSize() != 0) {
//                pageSize = query.getPageSize();
//            }
//
//            if (query.getPageNum() != 0) {
//                pageNum = query.getPageNum();
//            }
//        } else {
//            sql.append(" order by t.configuration_id");
//        }
//
//        // 分页查询 of mysql
//        if (1 == flag) {
//            sql.append(" limit ?,? ");
//            params.add(CommonLogic.buildFirstPageParamOfMySql(pageNum, pageSize));
//            params.add(pageSize);
//        }
//    }
//
//    /**
//     * 根据查询条件拼装查询SQL
//     *
//     * @param WSQueryProductConstants query
//     * @param int                     flag 0=分页查询SQL 1=查询SQL,2=查询COUNT SQL
//     * @return Map<Object, Object>
//     * @throws Exception
//     * @author sky.x
//     */
//    private Map<Object, Object> getQueryProductConstantsSql(
//            WSQueryProductConstants query, int flag) throws Exception {
//        Map<Object, Object> map = new HashMap<Object, Object>();
//        StringBuilder sql = new StringBuilder();
//        List<Object> params = new ArrayList<Object>();
//        packageSqlAndParamsByCondition(sql, params, query, flag);
//        map.put("sql", sql.toString());
//        map.put("params", params);
//        return map;
//    }
//
//
//    @Override
//    public List<WSProductConstants> queryProductConstants(BaseDao dao, WSQueryProductConstants query) throws Exception {
//        // Redis 中查询
//        if (StringUtils.hasText(query.getKey()) && StringUtils.hasText(query.getType())) {
//            String infProductId = query.getProductId().contains(";") ? MultiProductUtil.getDefaultProductId() : query.getProductId();
//            // Redis主分组key
//            String redisGroupKey = RedisUtil.genRedisGroupKey(infProductId, CronConstant.WSRedisHash.PRODUCT_CONSTANTS);
//            String redisKey = RedisUtil.genRedisKey(infProductId, query.getType(), query.getKey());
//
//            //判断是否使用新的 redis 缓存模式
//            boolean isNewCacheMode = redisUtil.isNewCacheMode(infProductId);
//            String newRedisKey = RedisUtil.genRedisKey(redisGroupKey, redisKey);
//
//            List<WSProductConstants> result = null;
//
//            // 从 redis 中获取
//            if (isNewCacheMode && redisUtil.exists(newRedisKey)) {
//                //webserviceApiLogger.info("Redis: {} WSProductsServiceImpl query from redis key: {} exist, new redis cache mode ", infProductId, newRedisKey);
//                result = redisUtil.get(newRedisKey, new ArrayList<WSProductConstants>().getClass());
//            } else if (redisUtil.hashexist(redisGroupKey, redisKey)) {
//                //webserviceApiLogger.info("Redis: {} WSProductsServiceImpl query from redis key: {} exist ", infProductId, redisKey);
//                result = redisUtil.getHash(redisGroupKey, redisKey, new ArrayList<WSProductConstants>().getClass());
//            }
//
//            // 从数据库中获取
//            if (result == null) {
//                //webserviceApiLogger.info("Redis: {} WSProductsServiceImpl query redis key: {} not exist query DB", infProductId, redisKey);
//                result = queryProductConstantsReal(dao, query);
//                if (!CommonLogic.isEmpty(result)) {
//                    if (isNewCacheMode) {
//                        //webserviceApiLogger.info("Redis: {} WSProductsServiceImpl set redis key: {}   ", infProductId, newRedisKey);
//                        redisUtil.set(newRedisKey, result, CronConstant.WSRedisExpireTime.PRODUCT_CONSTANTS);
//                    } else {
//                        //webserviceApiLogger.info("Redis: {} WSProductsServiceImpl set redis key: {}   ", infProductId, redisKey);
//                        redisUtil.setHash(redisGroupKey, redisKey, result);
//                    }
//                }
//            }
//
//            return result;
//        } else {
//            return queryProductConstantsReal(dao, query);
//        }
//    }
//}
