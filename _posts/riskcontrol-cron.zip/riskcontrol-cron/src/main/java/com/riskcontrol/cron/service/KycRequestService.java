package com.riskcontrol.cron.service;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.customers.BatchModifyPbcRequestResponse;
import com.cn.schema.customers.BatchUpdateKycRequestRequest;
import com.cn.schema.request.KycDispatchConfirmRequest;
import com.digiplus.common.exception.KafkaShieldException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequest;
import com.riskcontrol.common.entity.request.kyc.RiskUpdateKycRequestRequest;
import com.riskcontrol.common.exception.BusinessException;

import java.util.List;

/**
 * @program: riskcontrol-cron
 * @description:kyc service
 * @author: Erhu.Zhao
 * @create: 2023-10-04 15:45
 **/

public interface KycRequestService {

    /**
     * 查询kyc count数
     *
     * @param query 查询条件
     * @return kyc count
     * @throws BusinessException 自定义异常
     */
    Integer count(RiskQueryKycRequest query) throws BusinessException;

    /**
     * 统计重复kyc-允许中间名为空 *
     * @param query -
     * @return
     * @throws BusinessException
     */
    Integer countAllowMiddleNameIsNullKycNotLike(RiskQueryKycRequest query) throws BusinessException;

    /**
     * 针对queryPage查询的count查询
     *
     * @param query 查询条件
     * @return count总数
     */
    Integer countOfQueryPage(RiskQueryKycRequest query);


    /**
     * 针对queryPage查询的count查询[loginName精确查询]
     *
     * @param query 查询条件
     * @return count总数
     */
    Integer countOfQueryPageNotLike(RiskQueryKycRequest query);

    /**
     * 带条件的分页查询kyc
     *
     * @param query 查询条件
     * @return 分页结果
     * @throws BusinessException 自定义异常
     */
    List<KycRequest> queryPage(RiskQueryKycRequest query) throws BusinessException;

    /**
     * 新增kyc
     *
     * @param bean 入参
     * @return 新增条数
     * @throws BusinessException 自定义异常
     */
    int create(KycRequest bean) throws BusinessException;

    /**
     * 更新kyc
     *
     * @param updateKycRequestRequest 入参
     * @return 更新条数
     * @throws BusinessException 自定义异常
     */
    int update(RiskUpdateKycRequestRequest updateKycRequestRequest) throws BusinessException, KafkaShieldException, JsonProcessingException;

    int pbcModifyStatus(KycRequest wsKycRequest);

    int pbcDispatch(KycRequest wsKycRequest);

    int countWaitPending(KycRequest query)throws BusinessException;

    int modifyDispatchStatus(List<KycRequest> wsKycRequests)  throws BusinessException;

    /**
     * 取消派单，修改已经派单的订单状态
     * @param userLoginName
     * @return
     */
    int cancelDispatch(String userLoginName) throws BusinessException;

    int countKycPbc(RiskQueryKycRequest params);

    List<KycRequest> queryKycPbcPage(RiskQueryKycRequest params);

    int countKycPbcNew(RiskQueryKycRequest kycParams);

    List<KycRequest> queryKycSheetList(RiskQueryKycRequest kycParams)  throws Exception;

    BatchModifyPbcRequestResponse bactchModifyPbcStatus(BatchUpdateKycRequestRequest request);

    List<KycRequest> getConfirmDispatchByIds(KycDispatchConfirmRequest request);

    int modifyConfirmDispatch(KycDispatchConfirmRequest request) throws BusinessException;;

    JSONObject modifyCustomConfiguration(JSONObject request);

    /**
     * 自动通过KYC和PBC
     * @param wsKycRequest -
     * @return
     */
    int autoApproveKycAndPbc(KycRequest wsKycRequest);

    int getPendingRequest(String loginName);

    List<Integer> queryKycStatusByCustomerId(RiskQueryKycRequest kycRequest);

    /**
     * 校验kyc id和type是否存在
     * @param idType 证件类型
     * @param idNo 证件号码
     * @return true
     */
    boolean validKycIdAndTypeExist(Integer idType,String idNo);

    /**
     * 查询指定用户kyc信息，最有效的一条 已审批>待审批>拒绝>未提交
     * @param query
     * @return
     */
    KycRequest queryKycByLoginNameOrderOne(RiskQueryKycRequest query);

}
