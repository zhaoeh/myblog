package com.riskcontrol.cron.mapper;

import com.riskcontrol.common.entity.pojo.EkycRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycQueryRequest;
import com.riskcontrol.cron.wrapper.LambdaQueryWrapperX;

/**
 * ekyc request mapper*
 */
public interface EkycRequestMapper extends BaseMapperX<EkycRequest> {

    default EkycRequest queryCurrentKycRequest(EkycQueryRequest param) {
        return selectList(new LambdaQueryWrapperX<EkycRequest>().
                eqIfHasText(EkycRequest::getLoginName, param.getAccount()).
                neIfHasText(EkycRequest::getChannel, param.getChannelId())
                .orderByDesc(EkycRequest::getCreateDate).last("limit 1")).stream().findFirst().orElse(null);

    }
}
