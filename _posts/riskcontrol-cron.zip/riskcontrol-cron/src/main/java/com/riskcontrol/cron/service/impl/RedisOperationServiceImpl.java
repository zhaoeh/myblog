package com.riskcontrol.cron.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.cron.operations.core.OperationProcessor;
import com.riskcontrol.cron.service.RedisOperationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @program: riskcontrol-cron
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-11-17 11:17
 */
@Service
@Slf4j
public class RedisOperationServiceImpl implements RedisOperationService {

    @Autowired
    private OperationProcessor processor;

    @Override
    public JSONObject processRedisAction(JSONObject operation) {
        log.info("[processRedisAction method] begin to handle processRedisAction,request is {}", JSONObject.toJSONString(operation));
        JSONObject response = processor.processOperation(operation);
        log.info("[processRedisAction method] end to handle processRedisAction,response is {}", JSONObject.toJSONString(response));
        return response;
    }

}