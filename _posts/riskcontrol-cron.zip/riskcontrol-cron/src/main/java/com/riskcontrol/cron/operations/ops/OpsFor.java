package com.riskcontrol.cron.operations.ops;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;

import java.io.Serializable;

/**
 * @program: riskcontrol-cron
 * @description: 中间层
 * @author: Erhu.Zhao
 * @create: 2023-11-17 14:13
 */
public abstract class OpsFor implements Ops {
    @Autowired
    RedisTemplate<Serializable, Object> redisTemplate;

    @Override
    public Boolean delete(Serializable key) {
        return this.redisTemplate.delete(key);
    }
}