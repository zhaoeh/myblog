//package com.riskcontrol.cron.service.impl;
//
//import com.cn.schema.products.WSProductConstants;
//import com.cn.schema.products.WSQueryProductConstants;
//import com.riskcontrol.cron.service.ProductConsQueryService;
//import org.springframework.stereotype.Service;
//
//import java.util.stream.Stream;
//
///**
// * 产品常量查询服务接口，基于DB
// *
// * @program: riskcontrol-cron
// * @description:
// * @author: Erhu.Zhao
// * @create: 2023-10-27 12:08
// **/
//@Service
//public class ProductConsQueryOfDbServiceImpl implements ProductConsQueryService {
//
//    private ProductConstantsService productConstantsService;
//
//    public ProductConsQueryOfDbServiceImpl(ProductConstantsService productConstantsService) {
//        this.productConstantsService = productConstantsService;
//    }
//
//    @Override
//    public Stream<WSProductConstants> obtainProductConstants(WSQueryProductConstants request) {
//        return productConstantsService.queryByCondition(request).stream();
//    }
//}
