package com.riskcontrol.cron.mapper;

import com.riskcontrol.common.entity.pojo.EkycDeduplicate;

/**
 * 证件号记录mapper*
 */
public interface EkycDeduplicateMapper extends BaseMapperX<EkycDeduplicate> {

}
