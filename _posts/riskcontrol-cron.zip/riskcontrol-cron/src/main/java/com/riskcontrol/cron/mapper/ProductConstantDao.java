package com.riskcontrol.cron.mapper;

import com.cn.schema.products.WSProductConstants;
import com.cn.schema.products.WSQueryProductConstants;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;


/**
 * 产品常量数据访问层
 *
 * @author Wason.H
 * @date 2018-02-26 13:13:26.
 */
@Repository
public interface ProductConstantDao {

    /**
     * 查询符合条件的数量
     *
     * @param query 查询条件
     * @return Integer 符合条件的数量
     */
    Integer countByCondition(WSQueryProductConstants query);


    /**
     * 查询符合条件的信息分页
     *
     * @param query 查询条件
     * @return List<WSProductConstants> 产品常量列表
     */
    List<WSProductConstants> queryPageByCondition(WSQueryProductConstants query);


    /**
     * 根据ID查询信息
     *
     * @param primaryKey 主键
     * @return WSProductConstants
     */
    WSProductConstants loadById(String primaryKey);

    /**
     * 根据Key查询信息
     *
     * @param paras 参数
     * @return WSProductConstants
     */
    WSProductConstants loadByPKey(Map paras);


    /**
     * 修改信息.返回操作结果
     *
     * @param bean 产品常量
     * @return Integer
     */
    Integer modify(WSProductConstants bean);


    /**
     * 新增信息.返回操作结果
     *
     * @param bean 产品常量
     * @return Integer
     */
    Integer create(WSProductConstants bean);

    /**
     * 删除信息.返回操作结果
     *
     * @param primaryKey 主键
     * @return Integer
     */
    Integer delete(String primaryKey);

    /**
     * 获取产品配置的key {@code AAC001}
     *
     * @param productId
     * @return
     */
    String getProductConstantKey(@Param("productId") String productId);


    /**
     * 根据key和type和productId获取value
     *
     * @param pType
     * @param pKey
     * @param productId
     * @return
     */
    String getValueByKey(@Param("pType") String pType, @Param("pKey") String pKey, @Param("productId") String productId);

    /**
     * 根据产品id跟pType批量查询
     *
     * @param map
     * @return
     */
    List<WSProductConstants> getAgLineAndRate(Map map);

    /**
     * 根据keys 查询values
     *
     * @param productId
     * @param pType
     * @param pKeys
     * @return
     */
    List<WSProductConstants> queryByKeys(@Param("productId") String productId,
                                         @Param("pType") String pType,
                                         @Param("pKeys") List<String> pKeys);
}