package com.riskcontrol.cron.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.cron.entity.TRiskBlack;
import com.riskcontrol.cron.mapper.RiskBlackMapper;
import com.riskcontrol.cron.service.EkycPbcService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Objects;

/**
 * @description: PBC服务impl
 * @author: ErHu.Zhao
 * @create: 2024-10-30
 **/
@Service
@Slf4j
public class EkycPbcServiceImpl implements EkycPbcService {

    @Resource
    private RiskBlackMapper riskBlackMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean doInsertBlack(TRiskBlack black) {
        log.info("ekyc(kyc)开始转移黑名单，执行黑名单插入，black：{}", JSONObject.toJSONString(black));
        if (Objects.nonNull(black)) {
            return riskBlackMapper.insertOrUpdate(black);
        }
        return false;
    }
}
