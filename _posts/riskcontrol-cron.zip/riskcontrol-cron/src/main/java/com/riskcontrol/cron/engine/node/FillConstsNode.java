package com.riskcontrol.cron.engine.node;

import com.cn.schema.products.WSProductConstants;
import com.cn.schema.products.WSQueryProductConstants;
import com.riskcontrol.cron.constants.ProjectConstant;
import com.riskcontrol.cron.engine.WithdrawContext;
import com.riskcontrol.cron.service.ProductConsQueryService;
import com.riskcontrol.cron.utils.ProductConstantsLoader;
import com.yomahub.liteflow.annotation.LiteflowComponent;
import com.yomahub.liteflow.core.NodeComponent;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@LiteflowComponent("fillConstsNode")
@Slf4j
public class FillConstsNode extends AbstractWhenNode {
    @Override
    public void processWhen() throws Exception {
        WithdrawContext context = this.getFirstContextBean();
        WSQueryProductConstants productConstants = ProductConsQueryService.generateRequestByParams(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0016, null);
        List<WSProductConstants> productConstantsList = ProductConstantsLoader.obtainProductConstantsListRedis(productConstants);
        productConstantsList.forEach(constant -> {
            if (constant.getKey().equals(ProjectConstant.UNUSED_PROMOTION_ENABLED)) {
                context.UNUSED_PROMOTION_ENABLED = constant.getValue();
            }
            if (constant.getKey().equals(ProjectConstant.MAX_UNUSED_PROMOTION_AMOUNT)) {
                context.MAX_UNUSED_PROMOTION_AMOUNT = constant.getValue();
            }
            if (constant.getKey().equals(ProjectConstant.CONSECUTIVE_PASSES_ENABLED)) {
                context.CONSECUTIVE_PASSES_ENABLED = constant.getValue();
            }
            if (constant.getKey().equals(ProjectConstant.MAX_CONSECUTIVE_PASSES)) {
                context.MAX_CONSECUTIVE_PASSES = constant.getValue();
            }
            if (constant.getKey().equals(ProjectConstant.MAXIMUM_TOTAL_PASSED_AMOUNT)) {
                context.MAXIMUM_TOTAL_PASSED_AMOUNT = constant.getValue();
            }
            if (constant.getKey().equals(ProjectConstant.FIRST_WITHDRAWAL_CHECK_AMOUNT)) {
                context.FIRST_WITHDRAWAL_CHECK_AMOUNT = constant.getValue();
            }
            if (constant.getKey().equals(ProjectConstant.WD_MANUAL_MIN_NUM)) {
                context.WD_MANUAL_MIN_NUM = constant.getValue();
            }
            if (constant.getKey().equals(ProjectConstant.WD_MANUAL_MIN_AMOUNT)) {
                context.WD_MANUAL_MIN_AMOUNT = constant.getValue();
            }
            if (constant.getKey().equals(ProjectConstant.MANUAL_TYPE)) {
                context.MANUAL_TYPE = constant.getValue();
            }
            if (constant.getKey().equals(ProjectConstant.RISK_AUTO_APPROVE)) {
                context.RISK_AUTO_APPROVE = constant.getValue();
            }
            if (constant.getKey().equals(ProjectConstant.RISK_AUTO_APPROVE_MAX_AMOUNT)) {
                context.RISK_AUTO_APPROVE_MAX_AMOUNT = constant.getValue();
            }
            if (constant.getKey().equals(ProjectConstant.QUERY_BET_ENABLED)) {
                context.QUERY_BET_ENABLED = constant.getValue();
            }
            if (constant.getKey().equals(ProjectConstant.MAX_QUERY_DEPOSIT_DAYS)) {
                context.MAX_QUERY_DEPOSIT_DAYS = constant.getValue();
            }
            if (constant.getKey().equals(ProjectConstant.DEPOSIT_WITHDRAWAL_RATIO)) {
                context.DEPOSIT_WITHDRAWAL_RATIO = constant.getValue();
            }
        });
        context.setProductConstantsList(productConstantsList);


    }
}
