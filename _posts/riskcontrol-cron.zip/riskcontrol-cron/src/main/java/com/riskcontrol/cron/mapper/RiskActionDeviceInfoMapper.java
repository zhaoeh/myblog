package com.riskcontrol.cron.mapper;

import com.riskcontrol.common.entity.device.RiskActionDeviceInfo;

/**
 * @description: 设备信息
 * @author: ErHu.Zhao
 * @create: 2024-11-14
 **/
public interface RiskActionDeviceInfoMapper extends BaseMapperX<RiskActionDeviceInfo> {
}
