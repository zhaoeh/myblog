package com.riskcontrol.cron.convert;

import com.cn.schema.customers.WSCustomers;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface WSCustomersConvert {

    WSCustomersConvert INSTANT = Mappers.getMapper(WSCustomersConvert.class);

    WSCustomers convert(WSCustomers source);
}
