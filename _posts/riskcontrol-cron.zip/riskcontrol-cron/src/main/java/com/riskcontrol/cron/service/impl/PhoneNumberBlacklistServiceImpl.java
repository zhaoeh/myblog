package com.riskcontrol.cron.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cm.util.common.Constants;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.request.api.*;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.entity.response.api.PhoneCoolingDownPeriodRsp;
import com.riskcontrol.common.entity.response.api.PhoneNumberBlacklistRsp;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.enums.SENSITIVE_TYPE;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.utils.PHPDESEncrypt;
import com.riskcontrol.common.utils.SensitiveUtil;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.core.BaseServiceImpl;
import com.riskcontrol.cron.datasource.DBSourceCheck;
import com.riskcontrol.cron.datasource.DataSourceType;
import com.riskcontrol.cron.entity.BaseEntity;
import com.riskcontrol.cron.entity.BaseFullEntity;
import com.riskcontrol.cron.entity.TMessageRecord;
import com.riskcontrol.cron.entity.TPhoneNumberBlacklist;
import com.riskcontrol.cron.enums.BakErrCodeEnum;
import com.riskcontrol.cron.enums.PhoneNumberBlacklistStatusEnum;
import com.riskcontrol.cron.mapper.MessageRecordMapper;
import com.riskcontrol.cron.mapper.PhoneNumberBlacklistMapper;
import com.riskcontrol.cron.service.PhoneNumberBlacklistService;
import com.riskcontrol.cron.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigInteger;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @program: riskcontrol-cron
 * @description: 手机号黑名单 服务实现类
 * @author: Colson
 * @create: 2023-09-26 14:15
 */
@Service
@Slf4j
public class PhoneNumberBlacklistServiceImpl extends BaseServiceImpl<PhoneNumberBlacklistMapper, TPhoneNumberBlacklist> implements PhoneNumberBlacklistService {

    @Resource
    private MessageRecordMapper messageRecordMapper;

    @Value("${C66.phone.coolingDownPeriod}")
    private Integer coolingDownPeriod;

    @Value("${C66.phone.blacklist-expiration-days}")
    private Integer blacklistExpirationDays;

    @Autowired
    private RedisUtil redisUtil;
    @DBSourceCheck(DataSourceType.SLAVE)
    @Override
    public PageModel<PhoneNumberBlacklistRsp> pagePhoneNumberBlackList(PhoneNumberBlacklistPageRequest req) {
        Page<TPhoneNumberBlacklist> page = pageByWrapper(req, buildWrapper(req));
        if (CollectionUtil.isEmpty(page.getRecords())) {
            return new PageModel<>();
        }
        PHPDESEncrypt encrypt = PHPDESEncrypt.getNewInstance(Constants.C66, "03");//03手机号加密
        List<PhoneNumberBlacklistRsp> list = page.getRecords().stream().map(p -> {
            PhoneNumberBlacklistRsp rsp = new PhoneNumberBlacklistRsp();
            BeanUtil.copyProperties(p, rsp);
            try {
                String decrypt = encrypt.decrypt(rsp.getPhone());
                SensitiveUtil.halfHideSensitive(SENSITIVE_TYPE.PHONE_NO.getDefaultHideType(),decrypt);
                rsp.setPhone(SensitiveUtil.halfHideSensitive(SENSITIVE_TYPE.PHONE_NO.getDefaultHideType(),encrypt.decrypt(rsp.getPhone())));
            } catch (Exception e) {
                log.error("解密手机异常",e);
            }
            return rsp;
        }).collect(Collectors.toList());
        PageModel<PhoneNumberBlacklistRsp> pageResult = new PageModel<>();
        pageResult.setData(list);
        pageResult.setPageNo((int) page.getCurrent());
        pageResult.setPageSize((int) page.getSize());
        pageResult.setTotalRow((int) page.getTotal());
        pageResult.setTotalPage((int) page.getPages());
        return pageResult;
    }
    @DBSourceCheck(DataSourceType.SLAVE)
    @Override
    public List<PhoneNumberBlacklistRsp> listPhoneNumberBlacklist(PhoneNumberBlacklistRequest req) {
        List<TPhoneNumberBlacklist> blacklist = list(buildWrapper(req));
        if (CollectionUtil.isEmpty(blacklist)) {
            return ListUtil.empty();
        }
        PHPDESEncrypt encrypt = PHPDESEncrypt.getNewInstance(Constants.C66, "03");//03手机号加密
        return blacklist.stream().map(b -> {
            PhoneNumberBlacklistRsp rsp = new PhoneNumberBlacklistRsp();
            BeanUtil.copyProperties(b, rsp);
            try {
                String decrypt = encrypt.decrypt(rsp.getPhone());
                SensitiveUtil.halfHideSensitive(SENSITIVE_TYPE.PHONE_NO.getDefaultHideType(),decrypt);
                rsp.setPhone(SensitiveUtil.halfHideSensitive(SENSITIVE_TYPE.PHONE_NO.getDefaultHideType(),encrypt.decrypt(rsp.getPhone())));
            } catch (Exception e) {
                log.error("解密手机异常",e);
            }
            return rsp;
        }).collect(Collectors.toList());
    }
    @DBSourceCheck(DataSourceType.SLAVE)
    @Override
    public PhoneNumberBlacklistRsp getPhoneNumberBlacklist(PhoneNumberBlacklistGetOneRequest req) {
        boolean flag = (StrUtil.isNotBlank(req.getPhoneMd5()) && null != req.getId()) || (StrUtil.isBlank(req.getPhoneMd5()) && null == req.getId());
        if (flag) {
            throw new BusinessException(ResultEnum.ID_OR_PHONE_NUMBER_ONLY_ONE);
        }
        TPhoneNumberBlacklist blacklist = null;
        if (null != req.getId()) {
            blacklist = getOne(Wrappers.lambdaQuery(TPhoneNumberBlacklist.class).eq(TPhoneNumberBlacklist::getId, req.getId()));
        } else if (StrUtil.isNotBlank(req.getPhoneMd5())) {
            blacklist = getOne(Wrappers.lambdaQuery(TPhoneNumberBlacklist.class).eq(TPhoneNumberBlacklist::getPhoneMd5, req.getPhoneMd5()));
        }
        if (blacklist == null) {
            return null;
        }
        // 检查最后更新时间到当前时间是否超过180天，半年后更新黑名单状态为无效
        long days = DateUtil.betweenDay(DateUtil.parseDateTime(blacklist.getLastUpdateTime()), DateUtil.date(), false);
        if (days > blacklistExpirationDays && blacklist.getStatus() == 1) {
            blacklist.setStatus(0);
            updateById(blacklist);
            redisUtil.remove(String.format(Constant.PHONE_BLACK_LIST_KEY, blacklist.getPhoneMd5()));
        }
        blacklist = getById(blacklist.getId());
        PhoneNumberBlacklistRsp rsp = new PhoneNumberBlacklistRsp();
        BeanUtil.copyProperties(blacklist, rsp);
        return rsp;
    }

    @Override
    public Boolean createPhoneNumberBlacklist(PhoneNumberBlacklistCreateRequest req) {
        long count = count(Wrappers.lambdaQuery(TPhoneNumberBlacklist.class).eq(TPhoneNumberBlacklist::getPhoneMd5, req.getPhoneMd5()));
        if (count > 0) {
            throw new BusinessException(BakErrCodeEnum.PHONE_NUMBER_BLACKLIST_EXIST);
        }
        TPhoneNumberBlacklist phoneNumberBlacklist = new TPhoneNumberBlacklist();
        BeanUtil.copyProperties(req, phoneNumberBlacklist);
        if (StrUtil.isBlank(req.getProductId())) {
            phoneNumberBlacklist.setProductId(Constant.C66_PRODUCT_ID);
        }
        phoneNumberBlacklist.setCreateBy(req.getDataModifier());
        return save(phoneNumberBlacklist);
    }

    @Override
    public Boolean updatePhoneNumberBlacklistHistory(PhoneNumberBlacklistUpdateHistoryRequest req) {
        TPhoneNumberBlacklist dbBlacklist = getPhoneNumberBlacklistByIdOrPhoneMd5(req.getId(), req.getPhoneMd5());
        TPhoneNumberBlacklist updateBlack = new TPhoneNumberBlacklist();
        List<String> historyList = StrUtil.split(dbBlacklist.getHistory(), Constant.COMMA_SYMBOL);
        // 历史数据不包含时，追加history
        if (!historyList.contains(req.getHistory())) {
            String allHistoryStr = dbBlacklist.getHistory() + Constant.COMMA_SYMBOL + req.getHistory();
            // history长度超过500时，移除最前面的customerId，先进先出
            if (StrUtil.length(allHistoryStr) > CronConstant.PHONE_NUMBER_BLACKLIST_HISTORY_MAXLENGTH) {
                log.info("history 字符长度超出500, history={}", allHistoryStr);
                String subHistory = StrUtil.subAfter(allHistoryStr, ",", false);
                log.info("history 截取后, history={}", subHistory);
                updateBlack.setHistory(subHistory);
            } else {
                updateBlack.setHistory(allHistoryStr);
            }
        }
        updateBlack.setId(dbBlacklist.getId());
        updateBlack.setDataModifier(req.getDataModifier());
        updateBlack.setRemarks(req.getRemarks());
        return updateBlacklist(updateBlack);
    }

    @Override
    public Boolean updatePhoneNumberBlacklistStatus(PhoneNumberBlacklistUpdateStatusRequest req) {
        TPhoneNumberBlacklist dbBlacklist = getPhoneNumberBlacklistByIdOrPhoneMd5(req.getId(), req.getPhoneMd5());
        TPhoneNumberBlacklist updateBlack = new TPhoneNumberBlacklist();
        updateBlack.setId(dbBlacklist.getId());
        updateBlack.setStatus(req.getStatus());
        updateBlack.setDataModifier(req.getDataModifier());
        updateBlack.setRemarks(req.getRemarks());
        return updateBlacklist(updateBlack);
    }

    @Override
    public PhoneNumberBlacklistRsp getPhoneNumberBlacklistByPhoneMd5(String phoneMd5) {
        TPhoneNumberBlacklist phoneNumber = getOne(Wrappers.lambdaQuery(TPhoneNumberBlacklist.class).eq(TPhoneNumberBlacklist::getPhoneMd5, phoneMd5));
        PhoneNumberBlacklistRsp rsp = new PhoneNumberBlacklistRsp();
        BeanUtil.copyProperties(phoneNumber, rsp);
        return rsp;
    }

    @Override
    public PhoneCoolingDownPeriodRsp getCoolingDownPeriod(PhoneCoolingDownPeriodRequest request) {
        if (StrUtil.isBlank(request.getOldPhoneMd5())) {
            throw new BusinessException(ResultEnum.OLD_PHONE_MD5_IS_NULL);
        }
        LambdaQueryWrapper<TMessageRecord> messageRecordQuery = Wrappers.lambdaQuery(TMessageRecord.class)
                .eq(TMessageRecord::getFlag, CronConstant.MESSAGE_FLAG_MODIFY_PHONE)
                .eq(TMessageRecord::getNewValueMd5, request.getOldPhoneMd5())
                .eq(StrUtil.isNotBlank(request.getCustomerId()), TMessageRecord::getCustomerId, request.getCustomerId())
                .isNotNull(TMessageRecord::getOldValueMd5)
                .orderByDesc(BaseFullEntity::getUpdateTime)
                .last("limit 1");

        TMessageRecord messageRecord = messageRecordMapper.selectOne(messageRecordQuery);

        PhoneCoolingDownPeriodRsp rsp = new PhoneCoolingDownPeriodRsp();
        if (messageRecord == null) {
            rsp.setIsCoolDownPeriod(false);
        } else {
            DateTime updateTime = DateUtil.parseDateTime(messageRecord.getUpdateTime());
            long coolDays = DateUtil.betweenDay(updateTime, DateUtil.date(), false);
            long days = coolingDownPeriod - coolDays;
            if (days < 1) {
                rsp.setIsCoolDownPeriod(false);
            } else {
                rsp.setDays(String.valueOf(days));
                rsp.setIsCoolDownPeriod(true);
            }
        }
        return rsp;
    }

    @Override
    public Boolean checkAndResetStatus() {
        DateTime before180Date = DateUtil.offsetDay(DateUtil.date(), -blacklistExpirationDays);
        log.info("checkAndResetStatus before180Date={}", before180Date);
        List<TPhoneNumberBlacklist> phoneNumberBlacklists = list(Wrappers.lambdaQuery(TPhoneNumberBlacklist.class)
                .eq(TPhoneNumberBlacklist::getStatus, PhoneNumberBlacklistStatusEnum.IN_EFFECT.getValue())
                .lt(TPhoneNumberBlacklist::getLastUpdateTime, DateUtil.formatDateTime(before180Date))
        );
        log.info("checkAndResetStatus phoneNumberBlacklists.size={}", phoneNumberBlacklists.size());
        if (CollectionUtil.isEmpty(phoneNumberBlacklists)) {
            log.info("checkAndResetStatus no need to update status");
            return true;
        }
        List<BigInteger> ids = phoneNumberBlacklists.stream().map(BaseEntity::getId).collect(Collectors.toList());
        TPhoneNumberBlacklist tPhoneNumberBlacklistUpdate = new TPhoneNumberBlacklist();
        tPhoneNumberBlacklistUpdate.setDataModifier(CronConstant.MODIFY_DEFAULT_SYSTEM);
        tPhoneNumberBlacklistUpdate.setStatus(PhoneNumberBlacklistStatusEnum.INVALID.getValue());
        return update(tPhoneNumberBlacklistUpdate, Wrappers.lambdaQuery(TPhoneNumberBlacklist.class)
                .in(BaseEntity::getId, ids));
    }

    /**
     * 根据ID或手机号查询手机号码黑名单信息*
     *
     * @param id       -
     * @param phoneMd5 -
     * @return 手机号码黑名单信息
     */
    private TPhoneNumberBlacklist getPhoneNumberBlacklistByIdOrPhoneMd5(BigInteger id, String phoneMd5) {
        boolean flag = (StrUtil.isNotBlank(phoneMd5) && null != id) || (StrUtil.isBlank(phoneMd5) && null == id);
        if (flag) {
            throw new BusinessException(BakErrCodeEnum.ID_OR_PHONE_NUMBER_ONLY_ONE);
        }
        TPhoneNumberBlacklist dbBlacklist = null;
        if (null != id) {
            dbBlacklist = getOne(Wrappers.lambdaQuery(TPhoneNumberBlacklist.class).eq(TPhoneNumberBlacklist::getId, id));
        } else if (StrUtil.isNotBlank(phoneMd5)) {
            dbBlacklist = getOne(Wrappers.lambdaQuery(TPhoneNumberBlacklist.class).eq(TPhoneNumberBlacklist::getPhoneMd5, phoneMd5));
        }
        if (null == dbBlacklist) {
            throw new BusinessException(BakErrCodeEnum.PHONE_NUMBER_BLACKLIST_NOT_EXIST);
        }
        return dbBlacklist;
    }

    private Boolean updateBlacklist(TPhoneNumberBlacklist updateBlack) {
        String errorMsg = "Data too long";
        try {
            redisUtil.remove(String.format(Constant.PHONE_BLACK_LIST_KEY, updateBlack.getPhoneMd5()));
            return updateById(updateBlack);
        } catch (DataIntegrityViolationException ex) {
            if (Objects.requireNonNull(ex.getMessage()).contains(errorMsg)) {
                throw new BusinessException(BakErrCodeEnum.UPDATE_HISTORY_TOO_LONG_ERROR);
            }
        }
        return false;
    }

}
