package com.riskcontrol.cron.datasource;

/**
 * 手动切换数据源
 * @author dante
 */
public class DataSourceSwitch {
    public static void switchToPrimary() {
        DbContextHolder.setDbType(DataSourceType.Default.getName());
    }

    public static void switchToSlave() {
        DbContextHolder.setDbType(DataSourceType.SLAVE.getName());
    }
    public static void clear() {
        DbContextHolder.clear();
    }
}
