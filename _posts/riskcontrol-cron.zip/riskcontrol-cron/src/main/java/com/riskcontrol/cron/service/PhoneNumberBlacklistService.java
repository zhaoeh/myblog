package com.riskcontrol.cron.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.request.api.*;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.entity.response.api.PhoneCoolingDownPeriodRsp;
import com.riskcontrol.common.entity.response.api.PhoneNumberBlacklistRsp;
import com.riskcontrol.cron.entity.TPhoneNumberBlacklist;

import java.util.List;

/**
 * @program: riskcontrol-cron
 * @description: 手机号黑名单 服务类
 * @author: Colson
 * @create: 2023-09-26 14:15
 */
public interface PhoneNumberBlacklistService extends IService<TPhoneNumberBlacklist> {

    /**
     * 分页查询手机黑名单 *
     *
     * @param req -
     * @return
     */
    PageModel<PhoneNumberBlacklistRsp> pagePhoneNumberBlackList(PhoneNumberBlacklistPageRequest req);

    /**
     * 列表查询手机号码黑名单 *
     *
     * @param req -
     * @return
     */
    List<PhoneNumberBlacklistRsp> listPhoneNumberBlacklist(PhoneNumberBlacklistRequest req);

    /**
     * 单一查询手机号码黑名单信息，查询为空时会报业务异常*
     *
     * @param req -
     * @return:
     */
    PhoneNumberBlacklistRsp getPhoneNumberBlacklist(PhoneNumberBlacklistGetOneRequest req);

    /**
     * 创建手机号码黑名单信息 *
     *
     * @param req -
     * @return
     */
    Boolean createPhoneNumberBlacklist(PhoneNumberBlacklistCreateRequest req);

    /**
     * 更新手机号码黑名单绑定用户ID信息 *
     *
     * @param req -
     * @return
     */
    Boolean updatePhoneNumberBlacklistHistory(PhoneNumberBlacklistUpdateHistoryRequest req);

    /**
     * 更新手机号码黑名单状态信息 *
     *
     * @param req -
     * @return
     */
    Boolean updatePhoneNumberBlacklistStatus(PhoneNumberBlacklistUpdateStatusRequest req);


    /**
     * 根据手机号码查询*
     *
     * @param phone -
     * @return -
     */
    PhoneNumberBlacklistRsp getPhoneNumberBlacklistByPhoneMd5(String phone);

    /**
     * 查询手机号码是否在冷却期内*
     *
     * @param request -
     * @return -
     */
    PhoneCoolingDownPeriodRsp getCoolingDownPeriod(PhoneCoolingDownPeriodRequest request);

    /**
     * 最后更新时间超过180天时，自动解绑（status更新为0）*
     *
     * @return -
     */
    Boolean checkAndResetStatus();
}
