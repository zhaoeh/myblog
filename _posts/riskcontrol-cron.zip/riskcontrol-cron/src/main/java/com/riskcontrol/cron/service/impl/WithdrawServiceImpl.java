package com.riskcontrol.cron.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.StopWatch;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.cn.schema.customers.WSCustomers;
import com.cn.schema.request.*;
import com.digiplus.common.exception.KafkaShieldException;
import com.digiplus.common.service.KafkaShieldService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.enums.RiskFilterSourceEnum;
import com.riskcontrol.common.enums.RiskFilterStatusEnum;
import com.riskcontrol.common.enums.RiskFilterTypeEnum;
import com.riskcontrol.common.enums.RuleEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.utils.LogUtils;
import com.riskcontrol.cron.config.WithdrawPropertiesConfig;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.constants.ProjectConstant;
import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.engine.WithdrawContext;
import com.riskcontrol.cron.entity.RiskFilterLog;
import com.riskcontrol.cron.mapper.RiskFilterLogMapper;
import com.riskcontrol.cron.service.RequestService;
import com.riskcontrol.cron.service.WithdrawService;
import com.riskcontrol.cron.template.WsApiFeignTemplate;
import com.riskcontrol.cron.utils.DateUtil;
import com.riskcontrol.cron.utils.ProductConstantsLoader;
import com.riskcontrol.cron.utils.RedisUtil;
import com.yomahub.liteflow.core.FlowExecutor;
import com.yomahub.liteflow.flow.LiteflowResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.text.MessageFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.function.Supplier;

import static com.riskcontrol.cron.constants.CronConstant.MODIFY_DEFAULT_SYSTEM;
import static com.riskcontrol.cron.constants.CronConstant.WITHDRAWAL_REVIEW_CACHE_KEY;
import static com.riskcontrol.cron.enums.WithdrawFilterEnum.NEXT_ENTER_MANUALLY;
import static com.riskcontrol.cron.kafka.KafkaTopic.WITHDRAW_RISK_RETRY_TOPIC;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/8/14 17:24
 */
@Service
@Slf4j
public class WithdrawServiceImpl implements WithdrawService {
    @Resource
    private FlowExecutor flowExecutor;
    @Resource
    private RedisUtil redisUtil;
    @Resource
    private RiskFilterLogMapper riskFilterLogMapper;
    @Autowired
    private RequestService requestService;
    @Autowired
    private WsApiFeignTemplate wsApiFeignTemplate;
    @Autowired
    private KafkaShieldService kafkaShieldService;
    @Resource
    private AmqpTemplate rabbitMq;
    @Autowired
    private WithdrawPropertiesConfig config;
    private String PULL_WITHDRAW_TO_RISK_KEY="pull_withdraw_to_risk_{0}_{1}";


    @Override
    public void sendWithToRiskMq(String requestId, String productId) throws KafkaShieldException, JsonProcessingException {
        String retryMq = ProductConstantsLoader.obtainProductConstantRedis(productId, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0014, ProjectConstant.JMS_WITHDRAW_RISK_RETRY_MQ);
        String cacheKey = MessageFormat.format(WITHDRAWAL_REVIEW_CACHE_KEY, Constant.C66_PRODUCT_ID, requestId);
        String reviewer = redisUtil.get(cacheKey, String.class);
        String sendKey = MessageFormat.format(PULL_WITHDRAW_TO_RISK_KEY, Constant.C66_PRODUCT_ID, requestId);
        boolean hasSend = redisUtil.exists(sendKey);
        if(hasSend){
            log.info("sendWithToRiskMq requestId:{}已经抓取推送过",requestId);
            return;
        }
        if (StringUtils.isNotEmpty(reviewer)) {
            log.info("sendWithToRiskMq requestId:{}正在被审批中", requestId);
            return;
        }
        redisUtil.set(sendKey,"1",180L);//3分钟内不在重复推送
        JSONObject messageJson=new JSONObject();
        messageJson.put("productId",productId);
        messageJson.put("requestId", requestId);
        if (CronConstant.ENABLED.equals(retryMq)) {//rabbitmq
            JSONObject newMsg=new JSONObject();
            newMsg.put("msgContent", messageJson);
            newMsg.put("routingKey", "customer.withdraw.apply");
            String jsonString = JSON.toJSONString(newMsg);
            Message message = MessageBuilder.withBody(jsonString.getBytes())
                    .setContentType(MessageProperties.CONTENT_TYPE_JSON)
                    .build();
            rabbitMq.convertAndSend(CronConstant.MqConstants.RETRY_EXCHANGE, CronConstant.MqConstants.RETRY_ROUTING_KEY, message);
            log.info("sendWithToRiskMq 抓取后推送数据到rabbitmq:{}", messageJson.toJSONString());
        }else{//发送kafka
            kafkaShieldService.asyncSend(WITHDRAW_RISK_RETRY_TOPIC,messageJson);
            log.info("sendWithToRiskMq 抓取后推送数据到kafka:{}", messageJson.toJSONString());
        }

    }
    /**
     * 取款风控方法
     *
     * @param req      生成的取款提案
     * @param withdrawRiskKey 取款风控JMS_WITHDRAW_RISK开关
     * @param withdrawRiskRetryKey 取款风控JMS_WITHDRAW_RISK_RETRY重试开关
     * @return
     */
    @Override
    public boolean withdrawRisk(OriWithdrawReq req, boolean withdrawRiskKey,boolean withdrawRiskRetryKey) {
        log.info("withdrawRisk 开始处理风控取款审核");
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        boolean flag = false;
        String cacheKey = StringUtils.EMPTY;
        String requestId = req.getRequestId();
        String productId = req.getProductId();
        boolean filterFlag = false;//是否需要写入拦截日志
        RiskFilterLog riskFilterLog = new RiskFilterLog();
        riskFilterLog.setFilterType(RiskFilterTypeEnum.WITHDRAW_RISK.getCode());
        riskFilterLog.setStatus(RiskFilterStatusEnum.INITIAL.getCode());
        riskFilterLog.setSource(RiskFilterSourceEnum.WITHDRAW_RISK.getCode());
        riskFilterLog.setRequestId(req.getRequestId());
        riskFilterLog.setRiskRuleAction(RuleEnum.TRANSFERRED_TO_MANUAL_REVIEW.getRuleAction());
        // 获取当前审核人信息
        cacheKey = MessageFormat.format(WITHDRAWAL_REVIEW_CACHE_KEY, productId, requestId);
        String reviewer = redisUtil.get(cacheKey, String.class);
        if (StringUtils.isNotEmpty(reviewer)) {
            log.info("风控取款 withdrawRisk 当前取款单 requestId:{} ,正在被手动审批中，消息丢弃", requestId);
            return false;
        }
        try{
            // 设置当前审核人员，10分钟过期时间
            redisUtil.set(cacheKey, MODIFY_DEFAULT_SYSTEM, 60 * 5L);

            //检验取款单状态是否还是处于pending，非门店
            WSWithdrawalRequests withdrawalRequest = this.queryCurrentOrder(req, false);
            if (withdrawalRequest == null) {
                log.info("风控取款 withdrawRisk 取款单requestId:{}不存在，消息丢弃",requestId);
                return false;
            }
            String withdrawalFlag = withdrawalRequest.getFlag();
            if (!Constant.ZERO.equals(withdrawalFlag) || "99".equals(withdrawalRequest.getCatalog())) {
                log.info("风控取款 withdrawRisk 取款单requestId:{}状态不是pending状态,或者是门店单 flag:{}，消息丢弃", requestId,withdrawalFlag);
                return false;
            }
            req = JSONObject.parseObject(JSONObject.toJSONString(withdrawalRequest),OriWithdrawReq.class);
            WSCustomers wsCustomers = wsApiFeignTemplate.getSimpleCustomerByLoginName(productId, withdrawalRequest.getLoginName());
            if(Objects.isNull(wsCustomers)){
                log.info("风控取款 withdrawRisk 查询用户信息不存在，取款单requestId:{}，消息丢弃", requestId);
                return false;
            }
            req.setParent(wsCustomers.getParentLoginName());

            log.info("取款申请withdrawRisk：{}", JSONObject.toJSONString(req));
            WithdrawContext context = new WithdrawContext();
            Map<String, String> mdcContextMap = LogUtils.getMDCContextMap();
            context.setUuid(mdcContextMap.get("uuid"));
            context.setReq(req);
            context.setWithdrawRiskKey(withdrawRiskKey);

            //注册来源和取款来源都是glife
            String glifeCheckFlag = ProductConstantsLoader.obtainProductConstantRedis(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0014, ProjectConstant.WITHDRAW_RISK_GLIFE_AUTO);
            context.setGlifeDomain("1".equals(glifeCheckFlag) &&
                    wsCustomers.getDomainName().equalsIgnoreCase("glife") &&
                    withdrawalRequest.getCatalog().equals("13"));


            LiteflowResponse response = flowExecutor.execute2Resp("rewriteWithEngineChain-1.1", null, context);
            flag = context.isAutoApprove();//是否被pending,false 表示被拦截，需要重试
            context = response.getFirstContextBean();
            context.setProductConstantsList(null);//移除常量，内容太长了
            riskFilterLog.setRequestJson(JSONObject.toJSONString(context));
            // 规则引擎失败或和ws交互失败，记录失败日志
            if (!response.isSuccess() || !withdrawRiskPostProcess(req, flag, context)) {
                flag = false;
                filterFlag = true;
                Exception e = response.getCause();
                riskFilterLog.setErrorMsg(StringUtils.substring(response.getMessage(),0,255));
                log.error("风控取款 withdrawRisk 处理异常:{}", response.getMessage(), e);
            } else {
                riskFilterLog.setAuditTime(new Date());
                riskFilterLog.setCompleteTime(new Date());
                riskFilterLog.setStatus(flag ? RiskFilterStatusEnum.RELEASED.getCode() : RiskFilterStatusEnum.INTERCEPTED.getCode());
                if (!context.filter.isEmpty()) {//有命中规则
                    filterFlag = true;
                }
                riskFilterLog.setFilterReason(context.getFilter().toString());//没有命中也填充，重试后没命中规则可更新记录
            }

            stopWatch.stop();
            log.info("取款申请withdrawRisk requestId:{} 校验耗时：{}s flag:{}", req.getRequestId(), stopWatch.getTotalTimeSeconds(), flag);
        }catch (Exception e){
            String message;
            if (e instanceof BusinessException) {
                message = Objects.nonNull(e.getCause()) ? e.getCause().getMessage() : e.getMessage();
            } else {
                message = e.getMessage();
            }
            log.error("取款申请withdrawRisk error ", e);
            filterFlag = true;
            riskFilterLog.setErrorMsg(StringUtils.substring(message, 0, 255));
        }finally {
            if(StringUtils.isNotBlank(cacheKey)){
                redisUtil.remove(cacheKey);
            }
            if(Objects.nonNull(req.getContext().getRiskFilterLogger())){
                req.getContext().getRiskFilterLogger().accept(filterFlag, withdrawRiskRetryKey, requestId, riskFilterLog);
            }else{
                handleRiskLog(filterFlag, withdrawRiskRetryKey, requestId, riskFilterLog);
            }
            // 此处记录过日志，则设置忽略记录日志
            req.getContext().setIgnoreLogger(Boolean.TRUE);
        }
        return flag;
    }

    /**
     * 人工审核接口
     * @param context 规则引擎上下文
     */
    @Override
    public boolean modifyExceptionPrompt(WithdrawContext context) {
        OriWithdrawReq req = context.getReq();
        boolean resultStatus = false;
        log.info("[修改风控原因]，RequestId={}", req.getRequestId());
        // 人工审核一定需要命中规则
        if (StringUtils.isNotBlank(context.getExceptionPromptType())) {
            WSWithdrawalRequests wsWithdrawalRequests = new WSWithdrawalRequests();
            wsWithdrawalRequests.setExceptionPromptType(context.getExceptionPromptType());
            wsWithdrawalRequests.setExceptionPrompt(context.getExceptionPrompt());
            wsWithdrawalRequests.setProductId(req.getProductId());
            wsWithdrawalRequests.setLoginName(req.getLoginName());
            wsWithdrawalRequests.setRequestId(req.getRequestId());
            resultStatus = requestService.modifyExceptionPrompt(wsWithdrawalRequests);
            if (!resultStatus) {
                log.error("WithdrawServiceImpl#modifyExceptionPrompt 保存风控信息错误：RequestId:{} ExceptionPrompt:{}", wsWithdrawalRequests.getRequestId(), wsWithdrawalRequests.getExceptionPrompt());
            }
        }
        log.info("[修改风控原因]结束, RequestId={}, 执行结果为：{}", req.getRequestId(), resultStatus);
        return resultStatus;
    }

    /**
     * 自动审核接口
     * @param context 规则引擎上下文
     */
    @Override
    public boolean requestApprove(WithdrawContext context){
        OriWithdrawReq req = context.getReq();
        log.info("[审批通过]开始，RequestId={}", req.getRequestId());
        WSRequestsApprove wsRequestsApprove = new WSRequestsApprove();
        wsRequestsApprove.setRequestId(req.getRequestId());
        wsRequestsApprove.setOldflag("0");//只审批状态为0的
        wsRequestsApprove.setExceptionPromptType("0");
        WSResponseApprove wsResponseApprove = requestService.requestApprove(wsRequestsApprove);
        log.info("[审批通过]更新风控类型结束, RequestId={}, 执行结果为：{}", req.getRequestId(), wsResponseApprove.isResultStatus());
        return wsResponseApprove.isResultStatus();
    }

    /**
     * 获取用户取款信息
     * @param requestId
     * @param productId
     * @return
     */
    @Override
    public String queryWithdrawalInfo(String requestId, String productId){
        JSONObject result=new JSONObject();
        try {
            WSQueryWithdrawalRequests queryWithdrawalRequests = new WSQueryWithdrawalRequests();
            queryWithdrawalRequests.setProductId(productId);
            queryWithdrawalRequests.setRequestId(requestId);
            queryWithdrawalRequests.setDeleteFlag("0");
            QueryWithdrawalRequestsResponse responseWs = requestService.queryWithdrawalRequestDesc(JSONObject.parseObject(JSONObject.toJSONString(queryWithdrawalRequests)));
            List<WSWithdrawalRequests> withdrawalRequestsList = responseWs.getWSWithdrawalRequests();
            if (CollectionUtil.isNotEmpty(withdrawalRequestsList)){
                WSWithdrawalRequests withdrawalRequest = withdrawalRequestsList.get(0);
                WithdrawContext context = new WithdrawContext();
                OriWithdrawReq req= JSONObject.parseObject(JSONObject.toJSONString(withdrawalRequest),OriWithdrawReq.class);
                context.setReq(req);
                context.setQUERY_BET_ENABLED(Constant.ONE);
                context.setUNUSED_PROMOTION_ENABLED(Constant.ONE);
                LiteflowResponse response = flowExecutor.execute2Resp("withdrawalInfoEngineChain", null, context);
                context = response.getFirstContextBean();
                if (!response.isSuccess()) {
                    Exception e = response.getCause();
                    log.error("获取取款信息 queryWithdrawInfo 处理异常:{}", response.getMessage(), e);
                } else {
                    return  JSONObject.toJSONString(context);
                }
            }else {
                log.error("查询取款提案数据为空 requestId:{}",requestId);
            }
        }catch (Exception e){
            log.error("==查询取款信息异常==",e);
        }
        return result.toJSONString();
    }

    @Override
    public WSWithdrawalRequests queryCurrentOrder(OriWithdrawReq req, boolean isUseCache) {
        String requestId = req.getRequestId();
        Supplier<WSWithdrawalRequests> supplier = () -> {
            log.info("[获取当前消息]风控取款 withdrawRisk 取款单requestId:{}", req.getRequestId());
            WSWithdrawalRequests result = null;
            WSQueryWithdrawalRequests queryWithdrawalRequests = new WSQueryWithdrawalRequests();
            String productId = req.getProductId();
            queryWithdrawalRequests.setProductId(productId);
            queryWithdrawalRequests.setRequestId(requestId);
            queryWithdrawalRequests.setDeleteFlag("0");
            QueryWithdrawalRequestsResponse responseWs;
            try {
                responseWs = requestService.queryWithdrawalRequestDesc(JSONObject.parseObject(JSONObject.toJSONString(queryWithdrawalRequests)));
                List<WSWithdrawalRequests> withdrawalRequestsList = responseWs.getWSWithdrawalRequests();
                if (!CollectionUtils.isEmpty(withdrawalRequestsList)) {
                    result = withdrawalRequestsList.get(0);
                }
            } catch (Exception e) {
                log.error("取款申请withdrawRisk error ", e);
                throw new BusinessException("取款申请withdrawRisk error", 778, e);
            }
            log.info("[获取当前消息]风控取款 withdrawRisk 取款单requestId:{},当前消息订单信息为:{}", req.getRequestId(), JSONObject.toJSONString(result));
            return result;
        };
        if (isUseCache) {
            // 使用缓存则优先从上下文获取，获取不到兜底查询ws
            return Optional.ofNullable(req.getContext().getOrderChain()).map(m -> m.get(requestId)).
                    map(m -> {
                        log.info("[获取当前消息]从上下文缓存中直接获取，风控取款 withdrawRisk 取款单requestId:{}", req.getRequestId());
                        return m;
                    }).orElseGet(supplier);
        } else {
            // 否则直接走供应器获取实时结果
            return supplier.get();
        }
    }

    @Override
    public WSWithdrawalRequests queryLastOrder(OriWithdrawReq req) {
        log.info("[获取当前消息上一笔请求]风控取款 withdrawRisk 取款单requestId:{}", req.getRequestId());
        WSWithdrawalRequests lastOrder;
        Map<String, WSWithdrawalRequests> orderChain = req.getContext().getOrderChain();
        lastOrder = orderChain.get(CronConstant.LAST_ORDER + req.getRequestId());
        if(Objects.nonNull(lastOrder)){
            log.info("[获取当前消息上一笔请求]风控取款 withdrawRisk 取款单requestId:{}，从上下文中获取上一笔订单：{}", req.getRequestId(), JSONObject.toJSONString(lastOrder));
            return lastOrder;
        }
        String requestId = req.getRequestId();
        WSWithdrawalRequests currentOrder = queryCurrentOrder(req, true);
        if (Objects.isNull(currentOrder)) {
            log.info("[获取当前消息上一笔请求]风控取款 withdrawRisk 取款单requestId:{}不存在，消息丢弃", requestId);
            return null;
        }
        // 注册当前订单
        registerOrder(CronConstant.CURRENT_ORDER, orderChain, currentOrder);
        String currentOrderCreatedDate = currentOrder.getCreatedDate();
        if (StringUtils.isBlank(currentOrderCreatedDate)) {
            log.info("[获取当前消息上一笔请求]风控取款 withdrawRisk 取款单requestId:{}创建时间为空，消息丢弃", requestId);
            return null;
        }
        WSQueryWithdrawalRequests queryWithdrawalRequests = new WSQueryWithdrawalRequests();
        queryWithdrawalRequests.setProductId(req.getProductId());
        queryWithdrawalRequests.setLoginName(req.getLoginName());
        queryWithdrawalRequests.setCatalog("0;11;12;13;14;15");
        queryWithdrawalRequests.setPageSize(5);
        queryWithdrawalRequests.setLoginName(currentOrder.getLoginName());
        QueryWithdrawalRequestsResponse responseWs;
        try {
            // 查询当前订单信息
            String request = JSONObject.toJSONString(queryWithdrawalRequests);
            log.info("[获取当前消息上一笔请求]风控取款 withdrawRisk 取款单requestId:{}，获取上一笔订单请求参数request：{}", requestId, request);
            responseWs = requestService.queryWithdrawalRequestDesc(JSONObject.parseObject(request));
            List<WSWithdrawalRequests> withdrawalRequestsList = responseWs.getWSWithdrawalRequests();
            if (!CollectionUtils.isEmpty(withdrawalRequestsList)) {
                lastOrder = withdrawalRequestsList.stream().filter(Objects::nonNull).filter(e -> {
                            if (StringUtils.isNotBlank(e.getCreatedDate())) {
                                return DateUtil.isBefore(e.getCreatedDate(), currentOrderCreatedDate);
                            }
                            return false;
                        }).
                        sorted(Comparator.comparing(WSWithdrawalRequests::getCreatedDate, Comparator.comparing(DateUtil::convertToLocalDateTime).reversed())).findFirst().orElse(null);
                // 注册上一笔订单
                registerOrder(CronConstant.LAST_ORDER, orderChain, lastOrder);
            }
        } catch (Exception e) {
            log.error("[获取当前消息上一笔请求]当前取款订单requestId:{}，取款申请withdrawRisk error ", requestId, e);
            throw new BusinessException("[获取当前消息上一笔请求]取款申请withdrawRisk error", 779, e);
        }
        req.getContext().setOrderChain(orderChain);
        log.info("[获取当前消息]风控取款 withdrawRisk 取款单requestId:{},当前消息上一笔订单信息为:{}", req.getRequestId(), JSONObject.toJSONString(lastOrder));
        return lastOrder;
    }

    /**
     * 风控取款后置流程处理
     *
     * @param req              取款请求
     * @param isNotHitRiskRule 是否未命中风控规则 true：未命中 false：命中
     * @param context          风控规则上下文
     * @return 是否执行成功 true：执行成功 false：实行失败
     */
    private boolean withdrawRiskPostProcess(OriWithdrawReq req, boolean isNotHitRiskRule, WithdrawContext context) {
        String lockKey = buildLockKey(req);
        boolean isLocked = false;
        try {
            log.info("[正常流程]风控取款正常流程进入审批处理，requestId:{},withdrawMainLockExpire:{} 秒,withdrawMainLockWait:{} 秒", req.getRequestId(), config.getWithdrawMainLockExpire(), config.getWithdrawMainLockWait());
            isLocked = redisUtil.tryLock(lockKey, config.getWithdrawMainLockExpire(), config.getWithdrawMainLockWait(), TimeUnit.SECONDS);
            if (isLocked) {
                log.info("[正常流程]风控取款正常流程进入审批处理，requestId:{},获取到redis锁，key:{}", req.getRequestId(), lockKey);
                WSWithdrawalRequests currentOrder = this.queryCurrentOrder(req, false);
                if (Objects.isNull(currentOrder)) {
                    log.info("[正常流程]风控取款 withdrawRisk 取款单requestId:{}不存在，消息丢弃", req.getRequestId());
                    return false;
                }
                String flag = currentOrder.getFlag();
                log.info("[正常流程]进入风控取款正常流程分发,flag：{}，isNotHitRiskRule:{}", flag, isNotHitRiskRule);
                if ("0".equals(flag)) {
                    // flag=0 处理待审批的订单
                    log.info("[正常流程]风控取款正常流程,flag：{}，isNotHitRiskRule:{}", flag, isNotHitRiskRule);
                    return isNotHitRiskRule ? requestApprove(context) : modifyExceptionPrompt(context);
                } else {
                    return !"9".equals(flag) && !isNotHitRiskRule ? modifyExceptionPrompt(this.weaveLogicForWithdrawContext(new WithdrawContext(), c -> {
                        log.info("[正常流程-被熔断记录拦截]风控取款正常流程,flag：{}，isNotHitRiskRule:{}", flag, isNotHitRiskRule);
                        c.setReq(req);
                        c.setAutoApprove(false);
                        c.setExceptionPromptType(NEXT_ENTER_MANUALLY.getType());
                        c.setExceptionPrompt(String.format("%s [hit: %s]",NEXT_ENTER_MANUALLY.getFilterMsg(), context.getExceptionPrompt()));
                        c.filter.put(NEXT_ENTER_MANUALLY.getType(), NEXT_ENTER_MANUALLY.getFilterMsg());
                        return c;
                    })) : true;
                }
            }
        } finally {
            if (isLocked) {
                log.info("[正常流程]风控取款正常流程，主动释放redis锁，key：{}", lockKey);
                redisUtil.unLock(lockKey);
            }
        }
        return false;
    }

    @Override
    public boolean withdrawRiskWithDowngrade(OriWithdrawReq req) {
        log.info("[熔断流程]开始进入熔断流程，执行中，requestId:{}", req.getRequestId());
        String lockKey = buildLockKey(req);
        boolean isLocked = false;
        try {
            String requestId = req.getRequestId();
            log.info("[熔断流程]风控取款熔断流程进入审批处理，requestId:{},withdrawLowLockExpire:{} 秒,withdrawLowLockWait:{} 秒", requestId, config.getWithdrawLowLockExpire(), config.getWithdrawLowLockWait());
            isLocked = redisUtil.tryLock(lockKey, config.getWithdrawLowLockExpire(), config.getWithdrawLowLockWait(), TimeUnit.SECONDS);
            if (isLocked) {
                log.info("[熔断流程]风控取款熔断流程进入审批处理，requestId:{},获取到redis锁，key:{}", req.getRequestId(), lockKey);
                WSWithdrawalRequests currentOrder = this.queryCurrentOrder(req, false);
                if (Objects.isNull(currentOrder)) {
                    log.info("[熔断流程] 风控取款 withdrawRisk 取款单requestId:{}不存在，消息丢弃", requestId);
                    return false;
                }
                String flag = currentOrder.getFlag();
                log.info("[熔断流程]进入风控取款熔断流程分发，requestId：{}，flag：{}", requestId, flag);
                if ("0".equals(flag)) {
                    // 处理待审批的订单，直接自动通过
                    log.info("[熔断流程]风控取款熔断流程，requestId：{}，flag：{}", requestId, flag);
                    this.requestApprove(this.weaveLogicForWithdrawContext(new WithdrawContext(), c -> {
                        c.setReq(req);
                        c.setAutoApprove(true);
                        return c;
                    }));
                }
                log.info("[熔断流程]熔断流程执行完毕，requestId:{}", req.getRequestId());
            } else {
                log.info("[熔断流程]熔断流程获取redis锁失败，requestId:{}", req.getRequestId());
            }
        } finally {
            if (isLocked) {
                log.info("[熔断流程]风控取款熔断流程，主动释放redis锁，key：{}", lockKey);
                redisUtil.unLock(lockKey);
            }
        }
        return true;
    }

    /**
     * 构建分布式锁key
     *
     * @param req 取款订单请求
     * @return 分布式锁key
     */
    private String buildLockKey(OriWithdrawReq req) {
        return String.format(CronConstant.WITHDRAW_LOCK, req.getRequestId());
    }

    @Override
    public WithdrawContext weaveLogicForWithdrawContext(WithdrawContext context, Function<WithdrawContext, WithdrawContext> mapper) {
        Assert.notNull(context, "WithdrawContext cannot be null");
        if (Objects.isNull(mapper)) {
            return context;
        }
        if (StringUtils.isBlank(context.getUuid())) {
            Map<String, String> mdcContextMap = LogUtils.getMDCContextMap();
            context.setUuid(mdcContextMap.get("uuid"));
        }
        return mapper.apply(context);
    }

    @Override
    public void handleRiskLog(boolean filterFlag, boolean withdrawRiskRetryKey, String requestId, RiskFilterLog riskFilterLog) {
        LambdaQueryWrapper<RiskFilterLog> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(RiskFilterLog::getRequestId, requestId);
        queryWrapper.eq(RiskFilterLog::getFilterType, RiskFilterTypeEnum.WITHDRAW_RISK.getCode());
        RiskFilterLog filterLog = riskFilterLogMapper.selectOne(queryWrapper);
        //重审
        if (withdrawRiskRetryKey && Objects.nonNull(filterLog)) {
            riskFilterLog.setRetryNum(Optional.ofNullable(filterLog.getRetryNum()).orElse(0) + 1);
            riskFilterLog.setId(filterLog.getId());
            riskFilterLogMapper.updateById(riskFilterLog);
        }
        //第一次判断拦截
        if (filterFlag && Objects.isNull(filterLog)) {
            riskFilterLog.setRetryNum(0);
            riskFilterLogMapper.insert(riskFilterLog);
        }
    }

    /**
     * 向订单链注册订单
     *
     * @param orderChain 订单链实例
     * @param order      订单实例
     * @return 注册后的订单链实例
     */
    private Map<String, WSWithdrawalRequests> registerOrder(String keyFlag, Map<String, WSWithdrawalRequests> orderChain, WSWithdrawalRequests order) {
        if (Objects.isNull(orderChain)) {
            return null;
        }
        if (Objects.isNull(order) || StringUtils.isBlank(order.getRequestId())) {
            return orderChain;
        }
        orderChain.put(order.getRequestId() + keyFlag, order);
        return orderChain;
    }

}
