package com.riskcontrol.cron.controller;

import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.cron.service.WithdrawService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
@RestController
@RequestMapping("/customers/withdrawal")
@Api("取款相关接口")
@Slf4j
public class WithdrawalReqController {
    @Resource
    private WithdrawService withdrawService;
    @ApiOperation(
            value = "查询指定用户取款金额信息",
            httpMethod = "POST"
    )
    @RequestMapping(method = RequestMethod.POST, value = "/queryWithdrawInfoByRequestId")
    @ResponseBody
    public Response<String> queryWithdrawInfoByRequestId(String requestId, String productId){
        return Response.body(withdrawService.queryWithdrawalInfo(requestId,productId));
    }
}
