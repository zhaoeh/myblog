package com.riskcontrol.cron.datasource;

import com.intech.dbcryptor.Cryptor;
import com.zaxxer.hikari.HikariDataSource;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * 数据源配置
 *
 * @author dante
 */
@Slf4j
@Configuration
public class DataSourceConfig {

    @Value("${spring.datasource.hikari.idle-timeout:600000}")
    private int idleTimeout;
    //
    @Value("${spring.datasource.hikari.connection-timeout:30000}")
    private String connectionTimeout;

    @Value("${spring.datasource.hikari.max-lifetime:1765000}")
    private long maxLifetime;

    @Value("${spring.datasource.hikari.maximum-pool-size:20}")
    private int maximumPoolSize;


    @Bean
    @ConfigurationProperties("spring.datasource")
    public DataSourceProperties primaryDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean
    @ConfigurationProperties("spring.datasource.slave")
    public DataSourceProperties slaveDataSourceProperties() {
        return new DataSourceProperties();
    }


    @Bean(name = "dynamicDataSource")
    public DataSource dataSource(DataSourceProperties primaryDataSourceProperties, DataSourceProperties slaveDataSourceProperties) {
        DynamicDataSource dynamicDataSource = new DynamicDataSource();
        // 创建default数据源
        HikariDataSource defaultDataSource = getHikariDataSource(primaryDataSourceProperties);
        // 创建assistant数据源
        HikariDataSource assistantDataSource = getHikariDataSource(slaveDataSourceProperties);
        // 将数据源放入Map
        Map<Object, Object> map = new HashMap<>();
        map.put(DataSourceType.Default.getName(), defaultDataSource);
        map.put(DataSourceType.SLAVE.getName(), assistantDataSource);
        dynamicDataSource.setTargetDataSources(map);
        //默认数据源
        dynamicDataSource.setDefaultTargetDataSource(defaultDataSource);
        return dynamicDataSource;
    }

    @NotNull
    private HikariDataSource getHikariDataSource(DataSourceProperties properties) {
        String username = properties.getUsername();
        String password = properties.getPassword();
        try {
            username = Cryptor.decryptContent(username);
        } catch (Exception e) {
            log.error("数据库用户名解密失败.", e);
        }
        try {
            password = Cryptor.decryptContent(password);
        } catch (Exception e) {
            log.error("数据库密码解密失败.", e);
        }
        // 创建数据源
        HikariDataSource defaultDataSource = DataSourceBuilder.create()
                .type(HikariDataSource.class)
                .driverClassName(properties.getDriverClassName())
                .url(properties.getUrl())
                .username(username)
                .password(password)
                .build();
        defaultDataSource.setMaximumPoolSize(maximumPoolSize);
        defaultDataSource.setIdleTimeout(idleTimeout);
        defaultDataSource.setConnectionTimeout(Long.parseLong(connectionTimeout));
        defaultDataSource.setMaxLifetime(maxLifetime);
        return defaultDataSource;
    }
}
