package com.riskcontrol.cron.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.collection.ListUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.riskcontrol.common.entity.request.label.RiskLabelBindingRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelByCustomerIdRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelListRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelRemoveBindingRequest;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelDetailRsp;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelRsp;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.enums.YesNoEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.constants.ProjectConstant;
import com.riskcontrol.cron.core.BaseServiceImpl;
import com.riskcontrol.cron.entity.BaseEntity;
import com.riskcontrol.cron.entity.TRiskConstants;
import com.riskcontrol.cron.entity.TRiskLabelChangeRecord;
import com.riskcontrol.cron.entity.TRiskLabelRelationship;
import com.riskcontrol.cron.mapper.TLabelRuleRelationshipMapper;
import com.riskcontrol.cron.mapper.TRiskConstantsMapper;
import com.riskcontrol.cron.mapper.TRiskLabelChangeRecordMapper;
import com.riskcontrol.cron.mapper.TRiskLabelRelationshipMapper;
import com.riskcontrol.cron.service.TRiskLabelRelationshipService;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 用户标签绑定关系表 服务实现类
 * </p>
 *
 * @author Yannis
 * @since 2024-01-11
 */
@Service
public class TRiskLabelRelationshipServiceImpl extends BaseServiceImpl<TRiskLabelRelationshipMapper, TRiskLabelRelationship> implements TRiskLabelRelationshipService {

    @Resource
    private TRiskConstantsMapper riskConstantsMapper;
    @Resource
    private TRiskLabelChangeRecordMapper riskLabelChangeRecordMapper;
    @Resource
    private TRiskLabelRelationshipMapper labelRelationshipMapper;
    @Resource
    private TLabelRuleRelationshipMapper labelRuleRelationshipMapper;

    /**
     * 批量查询用户标签信息*
     *
     * @param request -
     * @return -
     */
    @Override
    public List<CustomerRiskLabelRsp> listCustomerRiskLabel(RiskLabelListRequest request) {
        if (CollectionUtil.isEmpty(request.getCustomerIds())) {
            return ListUtil.empty();
        }

        // 无绑定标签时返回普通标签
        List<CustomerRiskLabelDetailRsp> customerRiskLabelDetailRspList = new ArrayList<>();
        TRiskConstants riskConstants = riskConstantsMapper.selectOne(Wrappers.lambdaQuery(TRiskConstants.class)
                .eq(TRiskConstants::getPKey, CronConstant.LabelKey.RISK_REGULAR));
        CustomerRiskLabelDetailRsp riskLabelDetailRsp = new CustomerRiskLabelDetailRsp();
        riskLabelDetailRsp.setRiskLabelId(riskConstants.getId())
                .setRiskLabelName(riskConstants.getPValue())
                .setProductId(riskConstants.getProductId());
        customerRiskLabelDetailRspList.add(riskLabelDetailRsp);
        // 查询用户风控标签绑定关系
        List<TRiskLabelRelationship> riskLabelRelationshipList = labelRelationshipMapper.queryListByCustomerIds(request.getCustomerIds(), ProjectConstant.PRODUCT_CONSTANTS_TYPE_RISK_LABEL_0101);
        //根据customerId 分组
        Map<Long, List<TRiskLabelRelationship>> riskLabelRelationshipGroupMap = riskLabelRelationshipList.stream()
                .collect(Collectors.groupingBy(TRiskLabelRelationship::getCustomerId));

        List<CustomerRiskLabelRsp> rspList = new ArrayList<>();
        request.getCustomerIds().forEach(customerId -> {
            List<TRiskLabelRelationship> riskLabelRelationshipListTemp = riskLabelRelationshipGroupMap.get(customerId);
            CustomerRiskLabelRsp rsp = new CustomerRiskLabelRsp();
            if (CollectionUtil.isNotEmpty(riskLabelRelationshipListTemp)) {
                TRiskLabelRelationship tempRelationship = riskLabelRelationshipListTemp.get(0);
                rsp.setCustomerId(String.valueOf(customerId))
                        .setLoginName(tempRelationship.getLoginName())
                        .setRemark(tempRelationship.getRemark() == null ? StrUtil.EMPTY : tempRelationship.getRemark())
                        .setProductId(tempRelationship.getProductId())
                        .setCreateBy(tempRelationship.getCreateBy())
                        .setCreateTime(tempRelationship.getCreateTime())
                        .setUpdateBy(tempRelationship.getUpdateBy())
                        .setUpdateTime(tempRelationship.getUpdateTime());
                // 用户绑定标签信息
                List<CustomerRiskLabelDetailRsp> customerRiskLabelDetailRsp = new ArrayList<>();
                riskLabelRelationshipListTemp.forEach(label -> {
                    CustomerRiskLabelDetailRsp riskLabelDetailRspTemp = new CustomerRiskLabelDetailRsp();
                    riskLabelDetailRspTemp.setRiskLabelId(label.getRiskLabelId())
                            .setRiskLabelName(label.getRiskLabelName())
                            .setRiskLabelKey(label.getRiskLabelKey())
                            .setProductId(label.getProductId());
                    customerRiskLabelDetailRsp.add(riskLabelDetailRspTemp);
                });
                rsp.setRiskLabels(customerRiskLabelDetailRsp);
            } else {
                rsp.setCustomerId(String.valueOf(customerId))
                        .setRemark(StrUtil.EMPTY)
                        .setCreateBy("-")
                        .setCreateTime("-")
                        .setUpdateTime("-")
                        .setUpdateBy("-");
                // 无绑定关系数据时默认普通标签
                rsp.setRiskLabels(customerRiskLabelDetailRspList);
            }
            rspList.add(rsp);
        });
        return rspList;
    }

    @Override
    @Cacheable(cacheNames = CronConstant.CUSTOMER_All_LABEL, key = "#request.customerId")//默认2小时过期
    public CustomerRiskLabelRsp getRiskLabelDetail(RiskLabelByCustomerIdRequest request) {
        if (null == request.getCustomerId()) {
            return new CustomerRiskLabelRsp();
        }
        RiskLabelListRequest listRequest = new RiskLabelListRequest();
        listRequest.setCustomerIds(CollUtil.toList(request.getCustomerId()));
        List<CustomerRiskLabelRsp> customerRiskLabelRsps = listCustomerRiskLabel(listRequest);
        return customerRiskLabelRsps.get(0);
    }

    /**
     * 根据用户名称查询风控标签
     * (默认用户id合法)
     */
    @Override
    public List<TRiskLabelRelationship> queryByCustomerId(String customerId) {
        return labelRelationshipMapper.queryListByCustomerIds(CollUtil.toList(Long.valueOf(customerId)), ProjectConstant.PRODUCT_CONSTANTS_TYPE_RISK_LABEL_0101);
    }

    /**
     * 根据用户id获取优先级最高的标签绑定的规则集合
     *
     * @param customerId
     * @return -
     */
    @Override
    public List<String> getCustomerLabelRules(@NotNull Long customerId) {
        String labelKey = labelRelationshipMapper.selectCustomerLabelByPriority(customerId);
        return labelRuleRelationshipMapper.selectRuleByLabel(labelKey);
    }

    @Caching(evict = {
            @CacheEvict(cacheNames = CronConstant.CUSTOMER_All_LABEL, key = "#request.customerId"),
    })//删除 用户绑定标签缓存
    @Transactional(rollbackFor = Exception.class)
    @Override
    public Boolean bindingCustomerRiskLabel(RiskLabelBindingRequest request) {
        if (CollectionUtil.isEmpty(request.getRiskLabelIds())) {
            throw new BusinessException(ResultEnum.RISK_LABEL_ID_IS_EMPTY);
        }
        // 根据customerId检查当前绑定的标签信息
        LambdaQueryWrapper<TRiskLabelRelationship> currentLabelList = Wrappers.lambdaQuery(TRiskLabelRelationship.class)
                .eq(TRiskLabelRelationship::getCustomerId, request.getCustomerId());

        List<TRiskLabelRelationship> currentRelationshipList = list(currentLabelList);
        List<BigInteger> currentLabelIdListSort = currentRelationshipList.stream().map(TRiskLabelRelationship::getRiskLabelId).sorted().collect(Collectors.toList());
        List<BigInteger> requestLabelIdListSort = request.getRiskLabelIds().stream().distinct().sorted().collect(Collectors.toList());

        String oldLabelNameArrStr = currentRelationshipList.stream().map(TRiskLabelRelationship::getRiskLabelName).collect(Collectors.joining(","));
        String oldLabelIdArrStr = currentRelationshipList.stream().map(r -> String.valueOf(r.getRiskLabelId())).collect(Collectors.joining(","));
        // 查询标签信息
        List<TRiskConstants> riskLabelList = riskConstantsMapper.selectList(Wrappers.lambdaQuery(TRiskConstants.class)
                .in(BaseEntity::getId, request.getRiskLabelIds())
                .eq(TRiskConstants::getIsEnable, YesNoEnum.YES.getCode())
                .eq(TRiskConstants::getIsDeleted,YesNoEnum.NO.getCode()));
        Map<BigInteger, String> riskLabelMap = riskLabelList.stream().collect(Collectors.toMap(BaseEntity::getId, TRiskConstants::getPValue));
        boolean labelChangeFlag = false;
        boolean remarkChangeFlag = false;
        boolean equalsFlag = currentLabelIdListSort.equals(requestLabelIdListSort);
        if (!equalsFlag) {
            labelChangeFlag = true;
            // 标签信息变更，删除原绑定关系
            remove(currentLabelList);
            // 添加用户风控标签绑定关系
            riskLabelList.forEach(r -> {
                TRiskLabelRelationship riskLabelRelationship = new TRiskLabelRelationship();
                riskLabelRelationship.setRiskLabelId(r.getId())
                        .setCustomerId(request.getCustomerId())
                        .setRiskLabelKey(r.getPKey())
                        .setRiskLabelName(riskLabelMap.get(r.getId()))
                        .setRemark(request.getRemarks())
                        .setProductId(request.getProductId())
                        .setLoginName(request.getLoginName())
                        .setUpdateBy(request.getOperator())
                        .setUpdateTime(DateUtil.now())
                        .setCreateBy(request.getOperator())
                        .setCreateTime(DateUtil.now());
                save(riskLabelRelationship);
            });
        } else {
            // 标签信息未变更，检查备注是否变更
            if (CollectionUtil.isNotEmpty(currentRelationshipList)) {
                String currentRemark = currentRelationshipList.get(0).getRemark();
                boolean allBlankFlag = StrUtil.isBlank(currentRemark) && StrUtil.isBlank(request.getRemarks());
                remarkChangeFlag = !allBlankFlag && !(StrUtil.equals(currentRemark, request.getRemarks()));
                if (remarkChangeFlag) {
                    // 更新绑定关系备注
                    TRiskLabelRelationship update = new TRiskLabelRelationship();
                    update.setRemark(request.getRemarks())
                            .setUpdateTime(DateUtil.now())
                            .setUpdateBy(request.getOperator());
                    update(update, Wrappers.lambdaQuery(TRiskLabelRelationship.class).eq(TRiskLabelRelationship::getCustomerId, request.getCustomerId()));
                }
            }
        }
        if (labelChangeFlag || remarkChangeFlag) {
            // 添加变更记录
            TRiskLabelChangeRecord riskLabelChangeRecord = new TRiskLabelChangeRecord();
            riskLabelChangeRecord.setProductId(request.getProductId())
                    .setCustomerId(request.getCustomerId())
                    .setLoginName(request.getLoginName().trim())
                    .setNewRiskLabelId(riskLabelList.stream().map(r -> String.valueOf(r.getId())).collect(Collectors.joining(",")))
                    .setNewRiskLabelName(riskLabelList.stream().map(TRiskConstants::getPValue).collect(Collectors.joining(",")))
                    .setOldRiskLabelName(oldLabelNameArrStr)
                    .setOldRiskLabelId(oldLabelIdArrStr)
                    .setRemark(request.getRemarks())
                    .setCreateBy(request.getOperator())
                    .setCreateTime(DateUtil.now());
            riskLabelChangeRecordMapper.insert(riskLabelChangeRecord);
        }
        return true;
    }

    @Caching(evict = {
            @CacheEvict(cacheNames = CronConstant.CUSTOMER_All_LABEL, key = "#request.customerId"),
    })//删除 用户绑定标签缓存
    @Override
    public boolean removeLabel(RiskLabelRemoveBindingRequest request) {
        TRiskConstants riskConstants = riskConstantsMapper.selectOne(Wrappers.lambdaQuery(TRiskConstants.class).eq(TRiskConstants::getPKey, request.getLabelKey()));
        if(null == riskConstants){
            return false;
        }
        LambdaQueryWrapper<TRiskLabelRelationship> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(TRiskLabelRelationship::getCustomerId, request.getCustomerId());
        queryWrapper.eq(TRiskLabelRelationship::getRiskLabelKey, request.getLabelKey());
        int count = labelRelationshipMapper.delete(queryWrapper);

        if(count > 0){
            // 添加变更记录
            TRiskLabelChangeRecord riskLabelChangeRecord = new TRiskLabelChangeRecord();
            riskLabelChangeRecord.setProductId(request.getProductId())
                    .setCustomerId(request.getCustomerId())
                    .setLoginName(request.getLoginName())
                    .setOldRiskLabelName(riskConstants.getPValue())
                    .setOldRiskLabelId(String.valueOf(riskConstants.getId()))
                    .setRemark(request.getRemarks())
                    .setCreateBy(request.getOperator())
                    .setCreateTime(DateUtil.now());
            riskLabelChangeRecordMapper.insert(riskLabelChangeRecord);
        }
        return count > 0;
    }
}
