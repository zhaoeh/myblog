package com.riskcontrol.cron.mapper;

import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.entity.TRiskLabelRelationship;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.cache.annotation.Cacheable;

import java.util.List;

/**
 * <p>
 * 用户标签绑定关系表 Mapper 接口
 * </p>
 *
 * @author Yannis
 * @since 2024-01-11
 */
public interface TRiskLabelRelationshipMapper extends BaseMapper<TRiskLabelRelationship> {

    //通过用户id获取绑定优先级最高的标签
    @Cacheable(cacheNames = CronConstant.CUSTOMER_LABEL_KEY, key = "#customerId")//默认2小时过期
    String selectCustomerLabelByPriority(long customerId);

    @Select({
            "<script>",
            "SELECT lr.product_id,lr.customer_id,lr.login_name,lr.remark,lr.create_by,lr.create_time,lr.update_by,lr.update_time,",
            "rc.id as risk_label_id,rc.p_key as risk_label_key,rc.p_value as risk_label_name",
            "FROM t_risk_label_relationship lr JOIN t_risk_constants rc ON lr.risk_label_id = rc.id",
            "WHERE rc.p_type = #{type} AND lr.customer_id IN",
            "<foreach item='id' collection='customerIds' open='(' separator=',' close=')'>",
            "#{id}",
            "</foreach>",
            "</script>"
    })
    List<TRiskLabelRelationship> queryListByCustomerIds(@Param("customerIds") List<Long> customerIds,@Param("type")String type);
}
