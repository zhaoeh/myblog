package com.riskcontrol.cron.service;

/**
 * @description: 风控设备指纹service
 * @author: ErHu.Zhao
 * @create: 2024-11-14
 **/
public interface RiskActionService {

    int saveDeviceInfo(String deviceInfo);
}
