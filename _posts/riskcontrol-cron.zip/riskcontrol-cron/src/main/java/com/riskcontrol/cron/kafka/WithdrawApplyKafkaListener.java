package com.riskcontrol.cron.kafka;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.common.annotation.LogUUID;
import com.riskcontrol.common.utils.LogUtils;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.constants.ProjectConstant;
import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.service.WithdrawService;
import com.riskcontrol.cron.support.WithdrawServiceDelegate;
import com.riskcontrol.cron.utils.ProductConstantsLoader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutorService;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/8/14 17:31
 */
@Component
@Slf4j
public class WithdrawApplyKafkaListener {
    @Resource(name = "withdrawExecutorService")
    private ExecutorService executorService;
    @Resource
    private WithdrawService withdrawService;
    @Resource
    private WithdrawServiceDelegate withdrawServiceDelegate;

    @KafkaListener(topics = {KafkaTopic.WITHDRAW_RISK_TOPIC},groupId = "group_risk_withdraw",
            containerFactory = "batchFactory",  errorHandler = "myConsumerAwareErrorHandler")
    @LogUUID
    public void withdrawApplyListenerKafka(JSONObject message, Acknowledgment ack) {
        if (Objects.isNull(message)) {
            log.info("取款申请message消息为空");
            return;
        }
        log.info("riskcontrol-cron 处理取款申请kafka消息：{}", message.toJSONString());
        try {
            OriWithdrawReq req = JSONObject.parseObject(message.toJSONString(), OriWithdrawReq.class);

            //风控功能开关
            String withdrawRiskKey = ProductConstantsLoader.obtainProductConstantRedis(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0014, ProjectConstant.JMS_WITHDRAW_RISK);
            String withdrawListenerAsyncKey = ProductConstantsLoader.obtainProductConstantRedis(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0014, ProjectConstant.JMS_WITHDRAW_RISK_LISTENER_ASYNC);
            log.info("取款风控JMS_WITHDRAW_RISK开关:{};取款风控WITHDRAW_RISK_LISTENER_ASYNC开关:{}", withdrawRiskKey, withdrawListenerAsyncKey);
            if (CronConstant.ENABLED.equals(withdrawRiskKey)) {
                Map<String, String> mdcContextMap = LogUtils.getMDCContextMap();
                if (CronConstant.ENABLED.equals(withdrawListenerAsyncKey)) {
                    withdrawServiceDelegate.handleWithdraw(req);
                } else {
                    executorService.submit(() -> {
                        try {
                            LogUtils.setMDCContextMap(mdcContextMap);
                            withdrawService.withdrawRisk(req, true, false);
                        } catch (Exception e) {
                            log.error("withdrawRisk error", e);
                        }
                    });
                }
            } else {
                withdrawService.withdrawRisk(req, false,false);
                log.info("取款风控JMS_WITHDRAW_RISK开关:{}，消息丢弃", withdrawRiskKey);
            }
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
        }finally {
            ack.acknowledge();
        }
    }

    @KafkaListener(topics = {KafkaTopic.WITHDRAW_RISK_RETRY_TOPIC},groupId = "group_risk_withdraw_retry",
            containerFactory = "batchFactory",  errorHandler = "myConsumerAwareErrorHandler")
    @LogUUID
    public void withdrawApplyListenerKafkaRetry(JSONObject message, Acknowledgment ack) {
        if (Objects.isNull(message)) {
            log.info("取款申请message消息为空");
            return;
        }
        log.info("riskcontrol-cron 重试处理取款申请kafka消息：{}", message.toJSONString());
        try {
            OriWithdrawReq req = JSONObject.parseObject(message.toJSONString(), OriWithdrawReq.class);

            String withdrawRiskKeyRetry = ProductConstantsLoader.obtainProductConstantRedis(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0014, ProjectConstant.JMS_WITHDRAW_RISK_RETRY);
            log.info("取款风控JMS_WITHDRAW_RISK_RETRY 重审开关:{}", withdrawRiskKeyRetry);
            if (!CronConstant.ENABLED.equals(withdrawRiskKeyRetry)) {
                log.info("取款风控JMS_WITHDRAW_RISK_RETRY 重审开关:{}，消息丢弃", withdrawRiskKeyRetry);
                return;
            }
            //风控功能开关
            String withdrawRiskKey = ProductConstantsLoader.obtainProductConstantRedis(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0014, ProjectConstant.JMS_WITHDRAW_RISK);
            String withdrawListenerAsyncKey = ProductConstantsLoader.obtainProductConstantRedis(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0014, ProjectConstant.JMS_WITHDRAW_RISK_LISTENER_ASYNC);
            log.info("取款风控JMS_WITHDRAW_RISK开关:{};取款风控WITHDRAW_RISK_LISTENER_ASYNC开关:{}", withdrawRiskKey, withdrawListenerAsyncKey);
            if (CronConstant.ENABLED.equals(withdrawRiskKey)) {
                Map<String, String> mdcContextMap = LogUtils.getMDCContextMap();
                if (CronConstant.ENABLED.equals(withdrawListenerAsyncKey)) {
                    withdrawServiceDelegate.handleWithdraw(req);
                } else {
                    executorService.submit(() -> {
                        try {
                            LogUtils.setMDCContextMap(mdcContextMap);
                            withdrawService.withdrawRisk(req, true, true);
                        } catch (Exception e) {
                            log.error("withdrawRisk error", e);
                        }
                    });
                }
            } else {
                withdrawService.withdrawRisk(req, false,true);
                log.info("取款风控JMS_WITHDRAW_RISK开关:{}，消息丢弃", withdrawRiskKey);
            }
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
        }finally {
            ack.acknowledge();
        }
    }
}
