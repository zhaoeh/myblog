package com.riskcontrol.cron.engine.node;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.date.TimeInterval;
import com.cn.schema.request.WSQueryCountPAmount;
import com.cn.schema.request.WSQueryPromotionRequests;
import com.cn.schema.request.WSWithdrawalRequests;
import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.engine.WithdrawContext;
import com.riskcontrol.cron.enums.WithdrawFilterEnum;
import com.riskcontrol.cron.service.RequestService;
import com.yomahub.liteflow.annotation.LiteflowComponent;
import com.yomahub.liteflow.core.NodeComponent;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

/**
 * 查询优惠金额
 * @author dante
 */
@LiteflowComponent("calcSumPromAmountNode")
@Slf4j
public class CalcSumPromAmountNode extends AbstractWhenNode {
    @Autowired
    private RequestService requestService;
    @Override
    public void processWhen() throws Exception {
        WithdrawContext context = this.getFirstContextBean();
        if (!"1".equals(context.UNUSED_PROMOTION_ENABLED)) {
            return;
        }
        OriWithdrawReq req = context.getReq();

        TimeInterval timer = DateUtil.timer();

        WSQueryPromotionRequests wsQueryPromotionRequest = new WSQueryPromotionRequests();
        wsQueryPromotionRequest.setProductId(req.getProductId());
        wsQueryPromotionRequest.setLoginName(req.getLoginName());
        wsQueryPromotionRequest.setDeleteFlag("0");
        wsQueryPromotionRequest.setLastUpdateBegin(req.getLastWithDrawalDate());
        wsQueryPromotionRequest.setLastUpdateEnd(req.getCreatedDate());
        wsQueryPromotionRequest.setFlag("2");
        WSQueryCountPAmount wsQueryCountPAmount = requestService.getCountReportPromotion(wsQueryPromotionRequest);
        log.info("取款申请withdrawRisk loginName:{} getCountReportPromotion Timer {} ms", req.getLoginName(), timer.intervalRestart());
        //查询优惠金额
        BigDecimal sumPromotionAmount = BigDecimal.ZERO;
        if (wsQueryCountPAmount != null && StringUtils.isNotBlank(wsQueryCountPAmount.getSumAmount())) {
            sumPromotionAmount = new BigDecimal(wsQueryCountPAmount.getSumAmount());
        }
        context.setSumPromotionAmount(sumPromotionAmount);
    }

}
