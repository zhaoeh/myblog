package com.riskcontrol.cron.engine;

import lombok.Data;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/6/4 14:38
 */
@Data
public class AbstractContext {
    //用来接收主线程的uuid
    public String uuid;
}
