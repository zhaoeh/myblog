package com.riskcontrol.cron.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

/**
 * @description: 取款属性项配置
 * @author: ErHu.Zhao
 * @create: 2024-09-19
 **/
@Configuration
@RefreshScope
@Data
public class WithdrawPropertiesConfig {

    /**
     * 核心线程数
     */
    @Value("${withdraw.rist.thread.core-pool-size:1}")
    private int withdrawCorePoolSize;

    /**
     * 最大线程数
     */
    @Value("${withdraw.rist.thread.maximum-pool-size:25}")
    private int withdrawMaximumPoolSize;

    /**
     * 阻塞队列大小
     */
    @Value("${withdraw.rist.thread.block-queue-size:300}")
    private int withdrawBlockQueueSize;

    /**
     * 正常流程线程获取redis锁的自动过期时间，默认值 240  单位：秒
     */
    @Value("${withdraw.rist.main.lock-expire-seconds:240}")
    private int withdrawMainLockExpire;

    /**
     * 正常流程线程获取redis锁阻塞等待时间，默认值 60  单位：秒
     */
    @Value("${withdraw.rist.main.lock-wait-seconds:60}")
    private int withdrawMainLockWait;

    /**
     * 熔断流程线程获取redis锁的自动过期时间，默认值 30  单位：秒
     */
    @Value("${withdraw.rist.low.lock-expire-seconds:30}")
    private int withdrawLowLockExpire;

    /**
     * 熔断流程线程获取redis锁的自动过期时间，默认值 0  单位：秒
     */
    @Value("${withdraw.rist.low.lock-wait-seconds:0}")
    private int withdrawLowLockWait;
}
