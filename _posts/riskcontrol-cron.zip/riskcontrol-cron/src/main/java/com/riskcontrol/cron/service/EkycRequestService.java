package com.riskcontrol.cron.service;

import com.riskcontrol.common.entity.pojo.Ekyc;
import com.riskcontrol.common.entity.pojo.EkycRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycCreateRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycExtendRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycUpdateRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycZolozErrorRequest;

import java.math.BigInteger;

public interface EkycRequestService {

    /**
     * 查询ekyc状态*
     *
     * @return
     */
    Ekyc queryEkycStatus(String loginName);

    /**
     * 查询目标用户最近一笔kyc*
     *
     * @param loginName
     * @return
     */
    EkycRequest queryCurrentKycRequest(String loginName);

    /**
     * 根据id查询ekyc提案*
     *
     * @param id
     * @return
     */
    EkycRequest queryEkycRequest(BigInteger id);

    /**
     * 更新ekyc提案*
     *
     * @param request
     * @return
     */
    Boolean modifyEkycRequest(EkycExtendRequest request);

    /**
     * ekyc创建提案
     */
    Boolean createEkycRequest(EkycCreateRequest request);

    /**
     * 更新第三方成功认证信息
     */
    Boolean saveVerificationInfo(EkycUpdateRequest request);

    /**
     * 第三方认证失败之后更新ekyc
     */
    Boolean updateEkycStatus(EkycZolozErrorRequest request);
}
