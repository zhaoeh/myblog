package com.riskcontrol.cron.operations.ops;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.Map;

/**
 * @program: riskcontrol-cron
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-11-17 11:32
 */
@Component
public class OpsForHash extends OpsFor implements Ops {

    @Override
    public String operation() {
        return "opsForHash";
    }

    public void put(Serializable key, Object hashKey, Object value) {
        redisTemplate.opsForHash().put(key, hashKey, value);
    }

    public Object get(Serializable key, Object hashKey) {
        return redisTemplate.opsForHash().get(key, hashKey);
    }

    public Map<Object, Object> entries(Serializable key) {
        return redisTemplate.opsForHash().entries(key);
    }

}