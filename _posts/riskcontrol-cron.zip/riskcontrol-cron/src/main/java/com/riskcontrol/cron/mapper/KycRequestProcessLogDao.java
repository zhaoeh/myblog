package com.riskcontrol.cron.mapper;

import com.cn.schema.customers.WSKycRequestProcessLog;
import com.riskcontrol.common.entity.response.kyc.RiskKycRequestProcessLogResponse;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface KycRequestProcessLogDao {

    int insert(WSKycRequestProcessLog wsKycRequestProcessLog);

    int updateStatusByKycId(@Param("kycRequestId") String kycRequestId);

    List<WSKycRequestProcessLog> queryPageByKycRequestId(String id);

    /**
     * 与queryPageByKycRequestId方法查询逻辑相同，Date类型为String，
     * 1.避免时间格式化导致的时区问题 2.与ws解耦 *
     * @param id
     * @return
     */
    List<RiskKycRequestProcessLogResponse> riskQueryPageByKycRequestId(String id);
}
