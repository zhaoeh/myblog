package com.riskcontrol.cron.service.impl;

import com.riskcontrol.cron.entity.TRiskBlack;
import com.riskcontrol.cron.mapper.RiskBlackMapper;
import com.riskcontrol.cron.service.RiskBlackService;
import com.riskcontrol.cron.wrapper.LambdaQueryWrapperX;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Optional;


/**
 * @author Heng.zhang
 */
@Service
@Slf4j
public class RiskBlackServiceImpl implements RiskBlackService {


    @Resource
    private RiskBlackMapper riskBlackMapper;

    @Override
    public Boolean getBlackStatus(String loginName) {
        TRiskBlack result = riskBlackMapper.selectOne(new LambdaQueryWrapperX<TRiskBlack>().select(TRiskBlack::getLoginName).
                eq(TRiskBlack::getLoginName, loginName).
                eq(TRiskBlack::getStatus, 1).last("LIMIT 1"));
        return Optional.ofNullable(result).isPresent();
    }
}
