//package com.riskcontrol.cron.service.impl;
//
//
//
//
//import com.cn.schema.products.QueryProductConstantsRequest;
//import com.cn.schema.products.QueryProductConstantsResponse;
//import com.cn.schema.products.WSProductConstants;
//import com.cn.schema.products.WSQueryProductConstants;
//
//
//import com.riskcontrol.common.client.WSFeign;
//import com.riskcontrol.common.config.WsCommonConfig;
//import com.riskcontrol.common.constants.Constant;
//import com.riskcontrol.cron.config.BusinessConfig;
//
//import com.riskcontrol.cron.constants.CronConstant;
//import com.riskcontrol.cron.service.OthersService;
//
//import org.apache.commons.collections4.CollectionUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.slf4j.MDC;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//
//import javax.annotation.Resource;
//import java.util.*;
//
//
///**
// * Other Service
// * @author Angus.Z
// */
//@Service
//public class OthersServiceImpl implements OthersService {
//    private final Logger logger = LoggerFactory.getLogger(this.getClass());
//
//    @Resource
//    private WsCommonConfig wsCommonConfig;
//    @Resource
//    private WSFeign wsFeign;
//    @Autowired
//    private BusinessConfig businessConfig;
//
//    /**
//     * 查询产品常量配置 ws
//     * @param wsQueryProductConstants
//     * @return
//     */
//    @Override
//    public List<WSProductConstants> getProductConstants(WSQueryProductConstants wsQueryProductConstants) {
//        QueryProductConstantsRequest request = new QueryProductConstantsRequest();
//        request.setInfProductId(wsCommonConfig.getWsProductId());
//        request.setInfPwd(wsCommonConfig.getWsProductPwd());
//        request.setWSQueryProductConstants(wsQueryProductConstants);
//        request.setRequestUUID(MDC.get(Constant.MDC_UUID_KEY));
//        QueryProductConstantsResponse response =wsFeign.getProductConstants(request);
//        return response.getWSProductConstants();
//    }
//
//    @Override
//    public List<WSProductConstants> getProductConstants(String type) {
//        try {
//            WSQueryProductConstants wsQueryProductConstants = new WSQueryProductConstants();
//            wsQueryProductConstants.setAllData(true);
//            wsQueryProductConstants.setType(type);
//            wsQueryProductConstants.setPageSize(2000);
//            wsQueryProductConstants.setPageNum(1);
//            wsQueryProductConstants.setProductId(wsCommonConfig.getWsProductId());
//            return getProductConstants(wsQueryProductConstants);
//        } catch (Exception e) {
//            logger.error("Query constants of type {} error", type, e);
//        }
//        return Collections.EMPTY_LIST;
//    }
//
//    @Override
//    public String getProductConstant(String type, String key) {
//        try {
//            WSQueryProductConstants wsQueryProductConstants = new WSQueryProductConstants();
//            wsQueryProductConstants.setProductId(wsCommonConfig.getWsProductId());
//            wsQueryProductConstants.setType(type);
//            wsQueryProductConstants.setKey(key);
//            wsQueryProductConstants.setAllData(true);
//            List<WSProductConstants> constants = getProductConstants(wsQueryProductConstants);
//            if (CollectionUtils.isNotEmpty(constants)) {
//                return constants.get(0).getValue();
//            }
//        } catch (Exception e) {
//            logger.error("Query constant {}-{} error", type, key, e);
//        }
//        return "";
//    }
//
//
//}
