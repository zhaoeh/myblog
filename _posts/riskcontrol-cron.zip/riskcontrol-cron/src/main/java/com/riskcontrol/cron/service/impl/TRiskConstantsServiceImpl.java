package com.riskcontrol.cron.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.request.api.QueryRiskConstants;
import com.riskcontrol.common.entity.response.api.RiskConstantsRsp;
import com.riskcontrol.cron.constants.ProjectConstant;
import com.riskcontrol.cron.core.BaseServiceImpl;
import com.riskcontrol.cron.entity.TRiskConstants;
import com.riskcontrol.cron.mapper.TRiskConstantsMapper;
import com.riskcontrol.cron.service.TRiskConstantsService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 风控常量表 服务实现类
 * </p>
 *
 * @author Yannis
 * @since 2024-01-11
 */
@Service
public class TRiskConstantsServiceImpl extends BaseServiceImpl<TRiskConstantsMapper, TRiskConstants> implements TRiskConstantsService {

    @Override
    public List<RiskConstantsRsp> queryRiskConstantsList(QueryRiskConstants request) {
        request.setIsDeleted(Constant.FLAG_NO);
        request.setIsEnable(Constant.FLAG_YES);
        request.setPType(ProjectConstant.PRODUCT_CONSTANTS_TYPE_RISK_LABEL_0101);
        return doQueryRiskConstantsList(request);
    }

    @Override
    public List<RiskConstantsRsp> doQueryRiskConstantsList(QueryRiskConstants request) {
        List<TRiskConstants> riskConstants = list(buildWrapper(request));
        List<RiskConstantsRsp> constantsRsp = riskConstants.stream().map(p -> {
            RiskConstantsRsp rsp = new RiskConstantsRsp();
            BeanUtil.copyProperties(p, rsp);
            return rsp;
        }).collect(Collectors.toList());
        return constantsRsp;
    }
    @Override
    public List<RiskConstantsRsp> listAllRiskLabel() {
        QueryRiskConstants request = new QueryRiskConstants();
        return queryRiskConstantsList(request);
    }
}
