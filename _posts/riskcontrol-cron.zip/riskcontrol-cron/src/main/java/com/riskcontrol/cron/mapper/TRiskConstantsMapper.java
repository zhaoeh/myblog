package com.riskcontrol.cron.mapper;

import com.riskcontrol.cron.entity.TRiskConstants;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 风控常量表 Mapper 接口
 * </p>
 *
 * @author Yannis
 * @since 2024-01-11
 */
public interface TRiskConstantsMapper extends BaseMapper<TRiskConstants> {

}
