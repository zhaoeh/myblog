package com.riskcontrol.cron.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.riskcontrol.cron.entity.TPhoneNumberBlacklist;

/**
 * @program: riskcontrol-cron
 *
 * @description: 手机号黑名单 Mapper 接口
 *
 * @author: Colson
 *
 * @create: 2023-09-26 14:19
 */
public interface PhoneNumberBlacklistMapper extends BaseMapper<TPhoneNumberBlacklist> {

}
