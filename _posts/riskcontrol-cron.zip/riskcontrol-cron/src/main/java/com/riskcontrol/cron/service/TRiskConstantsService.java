package com.riskcontrol.cron.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.request.api.QueryRiskConstants;
import com.riskcontrol.common.entity.response.api.RiskConstantsRsp;
import com.riskcontrol.cron.entity.TRiskConstants;

import java.util.List;

/**
 * <p>
 * 风控常量表 服务类
 * </p>
 *
 * @author Yannis
 * @since 2024-01-11
 */
public interface TRiskConstantsService extends IService<TRiskConstants> {

    /**
     * 根据条件查询(可用)风控标签常量列表
     */
    List<RiskConstantsRsp> queryRiskConstantsList(QueryRiskConstants request);

    /**
     * 根据条件查询标签常量列表
     */
    List<RiskConstantsRsp> doQueryRiskConstantsList(QueryRiskConstants request);


    /**
     * 查询所有（可用）风控标签
     */
    List<RiskConstantsRsp> listAllRiskLabel();
}
