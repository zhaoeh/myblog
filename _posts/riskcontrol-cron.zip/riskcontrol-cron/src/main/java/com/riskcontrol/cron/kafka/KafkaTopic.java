package com.riskcontrol.cron.kafka;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/8/15 11:12
 */
@Component
public class KafkaTopic {
    public final static String WITHDRAW_RISK_TOPIC = "topic_user_withdraw_risk";
    public final static String WITHDRAW_RISK_RETRY_TOPIC = "topic_risk_withdraw_retry";
    public final static String OTP_MESSAGE_TOPIC = "topic_otp_message";
    public final static String APPROVE_KYC_TOPIC = "topic_approve_kyc";
    public final static String UPDATE_CUSTOMER_INFO_TOPIC = "topic_update_customer_info";

    public final static String APPROVE_KYC_TOPIC_SELF = "topic_approve_kyc_self";
    @Bean
    public NewTopic topicRisk() {
        return new NewTopic(WITHDRAW_RISK_TOPIC, 9, (short) 3);
    }
    @Bean
    public NewTopic topicRiskRetry() {
        return new NewTopic(WITHDRAW_RISK_RETRY_TOPIC, 3, (short) 3);
    }
    @Bean
    public NewTopic topicOTPMessage() {
        return new NewTopic(OTP_MESSAGE_TOPIC, 3, (short) 3);
    }
    @Bean
    public NewTopic topicApproveKyc() {
        return new NewTopic(APPROVE_KYC_TOPIC, 3, (short) 3);
    }
    @Bean
    public NewTopic topicCustomerInfo() {
        return new NewTopic(UPDATE_CUSTOMER_INFO_TOPIC, 3, (short) 3);
    }
    @Bean
    public NewTopic topicApproveKycSelf() {
        return new NewTopic(APPROVE_KYC_TOPIC_SELF, 3, (short) 3);
    }
}
