package com.riskcontrol.cron.xxljob;

import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.cn.schema.customers.WSKycRequestProcessLog;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.riskcontrol.common.annotation.LogUUID;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.enums.PbcBannedEnum;
import com.riskcontrol.common.enums.PbcSourceEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.entity.PagcorRecord;
import com.riskcontrol.cron.entity.RiskKycRequest;
import com.riskcontrol.cron.entity.TPbcCrawlerResultNew;
import com.riskcontrol.cron.mapper.KycRequestDao;
import com.riskcontrol.cron.service.EkycBlackForPbcService;
import com.riskcontrol.cron.service.KycRequestProcessLogService;
import com.riskcontrol.cron.service.PbcCrawlerResultNewService;
import com.riskcontrol.cron.utils.RedisUtil;
import com.xxl.job.core.handler.annotation.XxlJob;
import com.xxl.job.core.util.DateUtil;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.jinq.orm.stream.JinqStream;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import static com.riskcontrol.common.constants.Constant.RISK_IS_BLACK_KEY;
import static com.riskcontrol.cron.constants.CronConstant.MODIFY_DEFAULT_SYSTEM;
import static com.riskcontrol.cron.constants.CronConstant.WAIT_PBC_KEY;
import static eu.ciechanowiec.sneakyfun.SneakyConsumer.sneaky;

/**
 * @author: sanji
 * @desc: 抓取pagcor黑名单数据，更新pbc状态
 * @date: 2024/6/3 10:12
 */
@Component
@Slf4j
public class ApprovePbcJob {
    @Value("${pagcor.url:}")
    private String pagcorUrl;
    @Value("${pagcor.username:}")
    private String pagcorUsername;
    @Value("${pagcor.password:}")
    private String pagcorPassword;
    @Value("${pbc.lark.url:}")
    private String larkBotUrl;
    @Resource
    private KycRequestDao kycRequestDao;
    @Resource
    private KycRequestProcessLogService kycRequestProcessLogService;
    @Resource(name = "kdlOkHttpClient")
    private OkHttpClient client;
    @Resource
    private RedisUtil redisUtil;
    @Resource
    private PbcCrawlerResultNewService pbcCrawlerResultNewService;
    @Resource
    private EkycBlackForPbcService ekycBlackForPbcService;
    @Resource
    private ObjectMapper objectMapper;
    final static String PAGCOR_COOKIE = "risk:pagcor:cookie";
    static HashMap<String, String> header = new HashMap<>();

    static {
        header.put("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
        header.put("Accept-Language'", "zh-CN,zh;q=0.9,en;q=0.8");
        header.put("Sec-Fetch-Dest", "document");
        header.put("Sec-Fetch-Mode", "navigate");
        header.put("Sec-Fetch-Site", "none");
        header.put("Sec-Fetch-User", "?1");
        header.put("Upgrade-Insecure-Requests", "1");
        header.put("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36");
        header.put("sec-ch-ua", "Not A(Brand\";v=\"99\", \"Google Chrome\";v=\"121\", \"Chromium\";v=\"121\"");
        header.put("sec-ch-ua-mobile", "?0");
        header.put("sec-ch-ua-platform", "Windows");
        header.put("Connection", "keep-alive");
    }

    private final static String MIN_DATE_KEY = "RISK:PBC_MIN_DATE_KEY";

    @XxlJob("approvePbcJob")
    @LogUUID
    @Deprecated
    public void approvePbcJob() {
        //获取查询最小时间，并将本次查询数据最小创建时间放入到redis，供下一次查询
        KycRequest kycRequest;
        while (true) {
            Optional<ZSetOperations.TypedTuple<Object>> zSetOperation = Optional.ofNullable(redisUtil.zSetPopMin(WAIT_PBC_KEY));
            if (!zSetOperation.isPresent()) {
                log.info("approvePbcJob 没有从redis中获取到 待审批pbc的kyc信息");
                return;
            }
            String kycId = String.valueOf(zSetOperation.get().getValue());
            log.info("approvePbcJob 获取到需要审批的kyc id:{}", kycId);
            kycRequest = kycRequestDao.queryKycById(kycId);
            if (null != kycRequest && kycRequest.getPbcStatus().equals(0)) {
                break;
            }
        }

        String firstName = kycRequest.getFirstName();
        String lastName = kycRequest.getLastName();
        String middleName = StringUtils.isBlank(kycRequest.getMiddleName()) ? StringUtils.EMPTY : kycRequest.getMiddleName();
        String birthday = kycRequest.getBirthday();
        int pbcStatus = 1;//1通过，3拒绝
        KycRequest updateBean = new KycRequest();
        updateBean.setId(kycRequest.getId());
        updateBean.setAutoPbc(1);
        WSKycRequestProcessLog wsKycRequestProcessLog = new WSKycRequestProcessLog();
        String lockKey = String.format(CronConstant.KYC_UPDATE_PBC_LOCK, kycRequest.getId());
        try {
            if (!StringUtils.isAllBlank(firstName, lastName)) {
                if (redisUtil.tryLock(lockKey, 30, -1, TimeUnit.SECONDS)) {
                    //获取登录cookie
                    String cookie = getPagcorCookie();
                    if (StringUtils.isNotBlank(cookie)) {
                        //查询pagcor黑名单，全量查询
                        RequestBody formBody = new FormBody.Builder()
                                .add("SearchString", String.format("%s %s %s", firstName, middleName, lastName))
                                .add("LookUp", "X")
                                .add("SelectedDB", "4")
                                .build();
                        List<PagcorRecord> recordList = searchPagcorRecord(cookie, formBody);
                        log.info("查询pagcor用户黑名单数量:{}", recordList.size());
                        //匹配用户名及生日，都匹配则是黑名单用户
                        Optional<PagcorRecord> hit = recordList.stream().filter(p ->
                                        p.getFirstName().equalsIgnoreCase(firstName)
                                                && p.getLastName().equalsIgnoreCase(lastName)
                                                && p.getMiddleName().equalsIgnoreCase(middleName)
                                                && birthday.equals(DateUtils.format(p.getBirthDate(), "yyyy-MM-dd"))
                                                && (StringUtils.isBlank(p.getIsBanned()) || p.getIsBanned().equalsIgnoreCase("true")))//是否封禁
                                .findAny();
                        if (hit.isPresent()) {
                            log.info("查询pagcor用户黑名单 命中：{}", JSONObject.toJSONString(hit.get()));
                            pbcStatus = 3;
                        }
                    }
                    updateBean.setPbcApprovedBy("system-cron");
                    updateBean.setPbcApprovedDate(DateUtils.getCurrentDate());
                    if (pbcStatus == 3) {
                        updateBean.setPbcStatus(3);
                        wsKycRequestProcessLog.setRemark("system rejected");
                        wsKycRequestProcessLog.setType("PBC rejected");
                    } else {
                        updateBean.setPbcStatus(1);
                        wsKycRequestProcessLog.setRemark("PBC approved by system-cron");
                        wsKycRequestProcessLog.setType("PBC approved");
                    }
                    wsKycRequestProcessLog.setKycRequestId(updateBean.getId());
                    wsKycRequestProcessLog.setDispatchBy("system-cron");
                } else {
                    log.info("查询pagcor用户黑名单 该笔订单：{}正在被审批，跳过系统审批操作", kycRequest.getId());
                }
            }
        } catch (Exception e) {
            log.error("查询pagcor用户黑名单异常", e);
            //发送lark预警
            sendErrorToLark(kycRequest.getLoginName(), e.getMessage());
        } finally {
            int update = kycRequestDao.update(RiskKycRequest.builder().kycRequest(updateBean).processLogType(wsKycRequestProcessLog.getType())
                    .processLogRemark(wsKycRequestProcessLog.getRemark()).build());
            if (update > 0) {
                kycRequestProcessLogService.insert(wsKycRequestProcessLog);
            }
            redisUtil.unLock(lockKey);
        }

    }

    private static final String[] words = new String[]{"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};

    private final static String WORD_KEY = "RISK:SEARCH:PBC:WORD";

    public void generateWordList() {
        int i, j, k;
        for (i = 0; i < words.length; i++) {
            for (j = 0; j < words.length; j++) {
                redisUtil.addZSet(WORD_KEY, String.format("%s%s", words[i], words[j]), System.currentTimeMillis());
            }
        }
    }

    @XxlJob("pullPagcorDateToDb")
    public void pullPagcorDateToDb() {
        if (!redisUtil.exists(WORD_KEY)) {
            generateWordList();
        }
        Optional<ZSetOperations.TypedTuple<Object>> zSetOperation = Optional.ofNullable(redisUtil.zSetPopMin(WORD_KEY));
        if (!zSetOperation.isPresent()) {
            log.info("pullPagcorDateToDb 没有从redis中获取到 要查询pbc的值");
            return;
        }
        String name = String.valueOf(zSetOperation.get().getValue());
        // 爬虫自动获取入参  LookUp=1，SelectedDB=5
        pullPagcorDataToDbByFullName(name, "", "1", "5");
    }

    /**
     * 根据名字查询pagcor数据，并写入pbc爬虫数据表.
     * 执行逆向 匹配新老kyc 命中黑名单逻辑.
     *
     * @param name 名字
     * @return 返回匹配的爬虫数据列表
     */
    public List<TPbcCrawlerResultNew> pullPagcorDataToDbByFullName(String name, String currentUsername, String lookUp, String selectedDB) {
        log.info("pullPagcorDataToDb 开始爬取 名字包含：{} 的数据", name);
        try {
            String cookie = getPagcorCookie();
            if (StringUtils.isNotBlank(cookie)) {
                //查询pagcor黑名单,只查询政府官员名单
                RequestBody formBody = new FormBody.Builder()
                        .add("SearchString", name)
                        .add("LookUp", lookUp)
                        .add("SelectedDB", selectedDB)
                        .build();
                List<PagcorRecord> recordList = searchPagcorRecord(cookie, formBody);
                log.info("pullPagcorDataToDb 爬取 名字包含:{} 的数据,查询结果{}条, 查询结果的第一条数据:{}", name, recordList.size(), this.objectMapper.writeValueAsString(JinqStream.from(recordList).limit(1).toList()));
                if (!CollectionUtils.isEmpty(recordList)) {
                    // 新增的
                    var newPbcCrawlerList = new ArrayList<TPbcCrawlerResultNew>();
                    // 在数据库中并且有改变的
                    var dbChangedPbcCrawlerList = new ArrayList<TPbcCrawlerResultNew>();
                    // 在数据库中并且没有改变的
                    var dbNoChangedPbcCrawlerList = new ArrayList<TPbcCrawlerResultNew>();
                    List<String> guestExtIdList = recordList
                            .stream()
                            .map(record -> StringUtils.isNotBlank(record.getGuestExtId()) ? record.getGuestExtId().trim() : Strings.EMPTY)
                            .filter(StringUtils::isNotBlank)
                            .toList();

                    // 根据guestExtId批量查询数据库
                    var dbBeanExistsList = Lists.partition(guestExtIdList, 1000)
                            .stream()
                            .flatMap(queryGuestExtIdList -> {
                                var lambdaQueryWrapper = new LambdaQueryWrapper<TPbcCrawlerResultNew>()
                                        .in(TPbcCrawlerResultNew::getGuestExtId, queryGuestExtIdList);
                                return pbcCrawlerResultNewService.list(lambdaQueryWrapper).stream();
                            }).toList();

                    recordList.forEach(sneaky(r -> {
                        TPbcCrawlerResultNew bean = new TPbcCrawlerResultNew();
                        bean.setCreateDate(DateUtils.getCurrentDateTime());
                        bean.setUpdateDate(DateUtils.getCurrentDateTime());
                        bean.setCreateBy(StringUtils.isNotBlank(currentUsername) ? currentUsername : MODIFY_DEFAULT_SYSTEM);
                        bean.setUpdateBy(StringUtils.isNotBlank(currentUsername) ? currentUsername : MODIFY_DEFAULT_SYSTEM);
                        setBirthDateOfPbc(bean, r.getBirthDate());
                        bean.setFirstName(StringUtils.isNotBlank(r.getFirstName()) ? r.getFirstName().trim() : Strings.EMPTY);
                        bean.setMiddleName(StringUtils.isNotBlank(r.getMiddleName()) ? r.getMiddleName().trim() : Strings.EMPTY);
                        bean.setLastName(StringUtils.isNotBlank(r.getLastName()) ? r.getLastName().trim() : Strings.EMPTY);
                        bean.setGuestExtId(StringUtils.isNotBlank(r.getGuestExtId()) ? r.getGuestExtId().trim() : Strings.EMPTY);
                        bean.setIsBanned("true".equalsIgnoreCase(r.getIsBanned()) ? PbcBannedEnum.DISABLE.getId() : PbcBannedEnum.RELEASE.getId());//禁用状态（0解除；1禁用）
                        bean.setSource(Arrays.stream(PbcSourceEnum.values()).filter(s -> StringUtils.isNotBlank(r.getSource()) && s.getName().toLowerCase().equals(r.getSource().trim().toLowerCase())).map(s -> s.getName()).findFirst().orElse(Strings.EMPTY));
                        if (r.getDateCreated().contains("PM")) {
                            bean.setDateCreated(DateUtils.dateToDateTime(DateUtil.addHours(DateUtil.parse(r.getDateCreated(), "M/d/yyyy hh:mm:ss"), 12)));
                        } else {
                            bean.setDateCreated(DateUtils.dateToDateTime(DateUtil.parse(r.getDateCreated(), "M/d/yyyy hh:mm:ss")));
                        }

                        var dbBean = dbBeanExistsList
                                .stream()
                                .filter(s -> s.getGuestExtId().equals(bean.getGuestExtId()))
                                .findFirst()
                                .orElse(null);

                        if (Objects.isNull(dbBean)) {
                            // 数据库中不存在这条数据
                            newPbcCrawlerList.add(bean);
                            return;
                        }
                        var hasChange = dbBean.getIsBanned() != (int) bean.getIsBanned();
                        dbBean.setFirstName(bean.getFirstName());
                        dbBean.setMiddleName(bean.getMiddleName());
                        dbBean.setLastName(bean.getLastName());
                        dbBean.setBirthDate(bean.getBirthDate());
                        dbBean.setSource(bean.getSource());
                        dbBean.setIsBanned(bean.getIsBanned());
                        dbBean.setUpdateBy(bean.getUpdateBy());
                        dbBean.setUpdateDate(DateUtils.getCurrentDateTime());
                        if (hasChange) {
                            log.info("pullPagcorDataToDb isBanned有变更的数据:{}, 名字包含:{}", this.objectMapper.writeValueAsString(bean), name);
                            // 数据库中存在这条数据, 并且is_banned有变更
                            dbChangedPbcCrawlerList.add(dbBean);
                        } else {
                            // 数据库存在这条数据, 并且没有变更
                            dbNoChangedPbcCrawlerList.add(dbBean);
                        }
                    }));

                    for (var pbcCrawlerResultNew : Stream.of(newPbcCrawlerList, dbChangedPbcCrawlerList).flatMap(List::stream).toList()) {
                        var loginNameList = pbcCrawlerResultNewService.insertOrUpdatePbcCrawler(pbcCrawlerResultNew);
                        clearCache(loginNameList);
                    }
                    log.info("pullPagcorDataToDb 爬取成功, 名字:{}, 新增的条数:{}, 已经存在且is_banned有变更的条数:{}, 已经存在但is_banned没有变更的条数:{}", name, newPbcCrawlerList.size(), dbChangedPbcCrawlerList.size(), dbNoChangedPbcCrawlerList.size());
                    return Stream.of(newPbcCrawlerList, dbChangedPbcCrawlerList, dbNoChangedPbcCrawlerList).flatMap(List::stream).toList();
                }
            }
        } catch (Exception e) {
            log.error("pullPagcorDataToDb crawler name:{} pagcor error ", name, e);
        }
        return List.of();
    }

    /**
     * 设置生日
     *
     * @param pbcCrawlerResultNew
     * @param birthDate
     */
    private void setBirthDateOfPbc(TPbcCrawlerResultNew pbcCrawlerResultNew, Date birthDate) {
        if (birthDate != null) {
            pbcCrawlerResultNew.setBirthDate(DateUtils.format(birthDate, "yyyy-MM-dd"));
        }
        if (StringUtils.isBlank(pbcCrawlerResultNew.getBirthDate())) {
            pbcCrawlerResultNew.setBirthDate("1900-01-01");
        }
    }

    public String getPagcorCookie() {
        Object cookieRedis = redisUtil.get(PAGCOR_COOKIE);
        if (!Objects.isNull(cookieRedis)) {
            return String.valueOf(cookieRedis);
        }
        String cookie = StringUtils.EMPTY;
        RequestBody formBody = new FormBody.Builder()
                .add("txtUID", pagcorUsername)  // 替换成实际用户名
                .add("txtPASS", pagcorPassword)  // 替换成实际密码
                .build();
        // 创建请求
        Request request = new Request.Builder()
                .url(pagcorUrl + "/wfLoginPageProcess.aspx")  // 替换成目标网站的URL
                .headers(Headers.of(header))
                .post(formBody)
                .build();

        // 发送请求并处理响应
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new BusinessException("Unexpected code " + response, 9999);
            }
            String body = response.body().string();
            if (StringUtils.isNotBlank(body) && body.indexOf("wfLoginPage") > 0) {
                throw new BusinessException("Login failed, unable to obtain cookies" + response, 9999);
            }
            Headers headers = response.headers();
            List<String> cookieList = headers.values("Set-Cookie");
            log.info("cookieList:{}", JSONObject.toJSONString(cookieList));
            if (CollectionUtils.isEmpty(cookieList) || cookieList.size() < 2) {
                throw new BusinessException("cookieList size < 2", 9999);
            }
            Optional<String> sessionId = cookieList.stream().filter(c -> c.startsWith("ASP.NET_SessionId")).findFirst();
            Optional<String> cf_bm = cookieList.stream().filter(c -> c.startsWith("__cf_bm")).findFirst();
            if (!sessionId.isPresent() || !cf_bm.isPresent()) {
                throw new BusinessException("解析cookie heard 缺失", 9999);
            }
            cookie = String.format("%s; %s", StringUtils.split(sessionId.get(), Constant.SPLIT_SYMBOL)[0], StringUtils.split(cf_bm.get(), Constant.SPLIT_SYMBOL)[0]);
            redisUtil.set(PAGCOR_COOKIE, cookie, 10 * 60L);//10分钟缓存
        } catch (Exception e) {
            log.error("获取pagcor网址 cookie失败 ", e);
        }
        return cookie;
    }

    /**
     * 查询pagcor黑名单列表
     *
     * @param cookie
     * @param formBody
     * @return
     * @throws Exception
     */
    public List<PagcorRecord> searchPagcorRecord(String cookie, RequestBody formBody) throws Exception {
        // 创建请求
        Request request = new Request.Builder()
                .url(pagcorUrl + "/User/wfSearchRecord_Table.aspx")  // 查询黑名单接口
                .headers(Headers.of(header))
                .header("Cookie", cookie)
                .post(formBody)
                .build();

        // 发送请求并处理响应
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new BusinessException("Unexpected code " + response, 9999);
            }
            String body = response.body().string();
            if (body.contains("User Authentication")) {
                log.error("获取pagcor网址 cookie失效 移除redis缓存");
                redisUtil.remove(PAGCOR_COOKIE);
            }
            if (StringUtils.isNotBlank(body)) {
                return JSONArray.parseArray(body, PagcorRecord.class);
            }
        } catch (Exception e) {
            throw e;
        }
        return Lists.newArrayList();
    }

    /**
     * 发送lark预警
     *
     * @return
     * @throws Exception
     */
    public void sendErrorToLark(String loginName, String errorMsg) {
        if (StringUtils.isBlank(larkBotUrl)) {
            return;
        }
        //发送lark预警
        JSONObject larkContent = new JSONObject();
        JSONObject msgContent = new JSONObject();
        larkContent.put("text", "loginName:" + loginName + " 查询pagcor异常" + errorMsg);
        msgContent.put("content", larkContent.toJSONString());
        msgContent.put("msg_type", "text");
        String result = HttpUtil.post(larkBotUrl, msgContent.toJSONString());
        log.info("PBC发送lark消息结果：{}", result);
    }

    /**
     * 操作完成删除缓存*
     *
     * @param loginNameList
     */
    private void clearCache(List<String> loginNameList) {
        for (var loginName : loginNameList) {
            String cacheKey = String.format(RISK_IS_BLACK_KEY, loginName);
            log.info("ekyc(kyc)转移黑名单，开始删除缓存key {}", cacheKey);
            redisUtil.remove(cacheKey);
            log.info("ekyc(kyc)转移黑名单，结束删除缓存key {}", cacheKey);
        }
    }

}
