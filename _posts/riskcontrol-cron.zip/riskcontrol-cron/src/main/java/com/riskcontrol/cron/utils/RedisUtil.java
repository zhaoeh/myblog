package com.riskcontrol.cron.utils;

import com.riskcontrol.cron.constants.CronConstant;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * @author Barnett.D
 */
@Slf4j
@Component
public class RedisUtil {


    @Autowired
    private RedisTemplate<Serializable, Object> redisTemplate;

    @Autowired
    private RedissonClient redissonClient;

    /**
     * 删除对应的value
     */
    public void remove(final String key) {
        if (exists(key)) {
            redisTemplate.delete(key);
        }
    }

    /**
     * 判断缓存中是否有对应的value
     */
    public boolean exists(final String key) {
        try {
            return redisTemplate.hasKey(key);
        } catch (Exception e) {
            log.error("使用 exist 判断 Redis key 是否存在发生错误, key为: {}, 异常为 : {}", key, e.getMessage(), e);
            return false;
        }
    }

    /**
     * 读取缓存
     */
    public Object get(final String key) {
        try {
            ValueOperations<Serializable, Object> operations = redisTemplate.opsForValue();
            Object result = operations.get(key);

            return result;
        } catch (Exception e) {
            log.error("使用 get 获取 Redis 缓存失败, key为: {}, 异常为 : {}", key, e.getMessage(), e);
            return null;
        }
    }

    /**
     * 读取缓存
     *
     * @param key redis key
     * @param cls 从 redis 缓存中取出要转成的型别
     * @return
     */
    public <T> T get(final String key, Class<T> cls) {
        try {
            ValueOperations<Serializable, Object> operations = redisTemplate.opsForValue();
            Object result = operations.get(key);

            return cls.cast(result);
        } catch (Exception e) {
            log.error("使用 get 获取 Redis 缓存失败, key为: {}, 异常为 : {}", key, e.getMessage(), e);
            return null;
        }
    }

    /**
     * 写入缓存
     */
    public boolean set(final String key, Object value) {
        boolean result = false;
        try {
            ValueOperations<Serializable, Object> operations = redisTemplate.opsForValue();
            operations.set(key, value);
            result = true;
        } catch (Exception e) {
            log.error("Redis写入异常,msg为{},异常为{},key为{}", e.getMessage(), e, key);
        }
        return result;
    }

    /**
     * 写入缓存
     */
    public boolean set(final String key, Object value, Long expireTime) {
        boolean result = false;
        try {
            ValueOperations<Serializable, Object> operations = redisTemplate.opsForValue();
            operations.set(key, value);
            redisTemplate.expire(key, expireTime, TimeUnit.SECONDS);
            result = true;
        } catch (Exception e) {
            log.error("Redis设置过期写入异常{}", e.getMessage(), e);
        }
        return result;
    }


    /**
     * 判断hash结构中是否有对应的value
     */
    public boolean hashexist(String hash, String key) {
        try {
            return redisTemplate.opsForHash().hasKey(hash, key);
        } catch (Exception e) {
            log.error("Redis 模板异常, msg为{}, key为{}", e.getMessage(), hash + key, e);
        }
        return false;
    }

    /**
     * 获取 hash 结构中对应的 value
     *
     * @param hash
     * @param hashKey
     * @param cls     从 redis 缓存中取出要转成的型别
     * @return
     */
    public <T> T getHash(String hash, String hashKey, Class<T> cls) {
        try {
            HashOperations<Serializable, Object, Object> hashOperations = redisTemplate.opsForHash();
            Object result = hashOperations.get(hash, hashKey);

            return cls.cast(result);
        } catch (Exception e) {
            log.error("Redis hash 取值异常, msg为 {}, key为 {}", e.getMessage(), hash + hashKey, e);
            return null;
        }
    }

    public boolean setHash(String hash, String hashKey, Object hashValue) {
        boolean result = false;
        try {
            //log.info(String.format("Write data %s,%s in redis.",hash,hashKey));
            HashOperations<Serializable, Object, Object> hashOperations = redisTemplate.opsForHash();
            hashOperations.put(hash, hashKey, hashValue);
            result = true;
        } catch (Exception e) {
            log.error("Redis hash 写入异常,msg为{},异常为{},key为{}", e.getMessage(), e, hash + hashKey);
        }
        return result;
    }


    public static String genRedisGroupKey(String productId, String key) {
        return productId + CronConstant.SEPARATOR_REDIS_GROUP_KEY + key;
    }

    public static String genRedisKey(String productId, String type, String key) {
        StringBuilder sb = new StringBuilder(productId);
        if (StringUtils.isNotBlank(type)) {
            sb.append(CronConstant.SEPARATOR3);
            sb.append(type);
        }
        if (StringUtils.isNotBlank(key)) {
            sb.append(CronConstant.SEPARATOR3);
            sb.append(key);
        }
        return sb.toString();
    }

    public static String genRedisKey(String... keys) {
        return String.join(CronConstant.SEPARATOR_REDIS_GROUP_KEY, keys);
    }

    /**
     * 取得目前 redis 缓存模式
     * false: 旧的缓存模式，使用hash，没有expire time
     * true: 新的缓存模式，使用一般的value，有expire time
     *
     * @return false: old, true: new
     */
    public boolean isNewCacheMode(String productId) {
        return true;
    }

    public boolean tryLock(String key, long expiration, long waitTime, TimeUnit timeUnit){
        try {
            return redissonClient.getFairLock(key).tryLock(waitTime, expiration, timeUnit);
        } catch (Exception e) {
            log.error("tryLock failed, key:{}", key, e);
            return false;
        }
    }

    public boolean unLock(String key){
        try {
            redissonClient.getFairLock(key).unlock();
        } catch (Exception e) {
            log.error("unLock failed",e);
            return false;
        }
        return true;
    }

    /**
     * 向redis中设置hash k-v
     *
     * @param key     redis键
     * @param hashKey redis键对应的hash中的Key
     * @param value   redis键对应的hash中的Value
     */
    public void putForHash(String key, String hashKey, Object value) {
        redisTemplate.opsForHash().put(key, hashKey, value);
    }

    /**
     * 获取redis中指定key对应的hash对象
     *
     * @param key redis中的键
     * @return redis中指定key对应的hash对象
     */
    public Map entries(String key) {
        Map hash = redisTemplate.opsForHash().entries(key);
        return hash;
    }

    /**
     *  zset add
     * @param key
     * @param value
     * @param score
     * @return
     */
    public boolean addZSet(String key,Object value,long score) {
        return redisTemplate.opsForZSet().add(key,value,score);
    }
    /**
     *  zset popMin
     * @param key
     * @return
     */
    public ZSetOperations.TypedTuple<Object> zSetPopMin(String key) {
        return redisTemplate.opsForZSet().popMin(key);
    }

}
