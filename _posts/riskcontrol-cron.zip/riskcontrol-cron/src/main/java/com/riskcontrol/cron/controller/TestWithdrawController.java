package com.riskcontrol.cron.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.kyc.RiskQueryKycRequestResponse;
import com.riskcontrol.cron.constants.CronConstant;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @description: 测试withdraw
 * @author: ErHu.Zhao
 * @create: 2024-09-19
 **/
@RestController
@RequestMapping("/test/withdraw")
@Api("KYC相关接口")
@Slf4j
public class TestWithdrawController {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @ResponseBody
    @PostMapping("/push")
    public Response<RiskQueryKycRequestResponse> testWithdraw(@Valid @RequestBody TestWithDrawVO vo) throws Exception {
        String exchange = StringUtils.isNotBlank(vo.getExchange()) ? vo.getExchange() : CronConstant.MqConstants.RETRY_EXCHANGE;
        String routingKey = StringUtils.isNotBlank(vo.getRoutingKey()) ? vo.getRoutingKey() : CronConstant.MqConstants.RETRY_ROUTING_KEY;
        String[] requestIds = vo.getRequestIds().split(",");
        for (int i = 0; i < requestIds.length; i++) {
            log.info("开始向交换机{}推送消息，routingKey：{}，request:{}", exchange, routingKey, JSONObject.toJSONString(vo));
            JSONObject messageJson = new JSONObject();
            messageJson.put("productId", StringUtils.isNotBlank(vo.getProductId()) ? vo.getProductId() : Constant.C66_PRODUCT_ID);
            messageJson.put("requestId", requestIds[i]);
            JSONObject newMsg = new JSONObject();
            newMsg.put("msgContent", messageJson);
            newMsg.put("routingKey", routingKey);
            String jsonString = JSON.toJSONString(newMsg);
            Message message = MessageBuilder.withBody(jsonString.getBytes())
                    .setContentType(MessageProperties.CONTENT_TYPE_JSON)
                    .build();
            rabbitTemplate.convertAndSend(exchange, routingKey, message);
            log.info("向交换机{}推送消息完成，routingKey：{}，message:{}", exchange, routingKey, JSONObject.toJSONString(message));
        }
        return Response.body(null);
    }


}
