package com.riskcontrol.cron.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.riskcontrol.cron.entity.TLogRecord;
import com.riskcontrol.cron.mapper.TLogRecordMapper;
import com.riskcontrol.cron.service.LogRecordService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 日志记录表 服务实现类
 * </p>
 *
 * @author Colson
 * @date 2023-10-19
 */
@Service
public class LogRecordServiceImpl extends ServiceImpl<TLogRecordMapper, TLogRecord> implements LogRecordService {

}
