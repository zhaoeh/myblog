//package com.riskcontrol.cron.config;
//
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.jdbc.core.JdbcTemplate;
//
//import javax.sql.DataSource;
//
///**
// * @program: riskcontrol-cron
// * @description:
// * @author: Erhu.Zhao
// * @create: 2023-10-11 16:36
// **/
//@Configuration
//public class JdbcConfig {
//
//    @Bean
//    public JdbcTemplate jdbcTemplate(@Qualifier("dataSource") DataSource dataSource) {
//        return new JdbcTemplate(dataSource);
//    }
//}
