package com.riskcontrol.cron.controller;

import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.cron.service.LocalCacheService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;

/**
 * @program: riskcontrol-cron
 * @description:对外暴露cron工程的本地缓存数据
 * @author: Erhu.Zhao
 * @create: 2023-10-19 15:21
 **/
@RestController
@RequestMapping("/local/cache")
@Api("cron本地缓存数据相关接口")
@Slf4j
public class LocalCacheController {

    @Autowired
    private LocalCacheService localCacheService;

    @RequestMapping(method = RequestMethod.POST, value = "/loadLocalCacheInfoByKeyFromCron")
    @ResponseBody
    public Response<Object> loadLocalCacheInfoByKeyFromCron(@RequestPayload @RequestBody String cacheKey) throws Exception {
        return Response.body(localCacheService.loadLocalCacheInfo(cacheKey));
    }
}
