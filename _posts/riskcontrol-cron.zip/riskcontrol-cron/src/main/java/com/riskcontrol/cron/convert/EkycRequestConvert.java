package com.riskcontrol.cron.convert;

import com.riskcontrol.common.entity.pojo.EkycRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycExtendRequest;
import com.riskcontrol.cron.convert.component.MappingConditions;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.factory.Mappers;

@Mapper(uses = MappingConditions.class, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface EkycRequestConvert {

    EkycRequestConvert INSTANT = Mappers.getMapper(EkycRequestConvert.class);

    void copyValidatedProperties(EkycExtendRequest source, @MappingTarget EkycRequest target);

}
