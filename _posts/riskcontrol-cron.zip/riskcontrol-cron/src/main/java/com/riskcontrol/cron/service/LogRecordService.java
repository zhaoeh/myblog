package com.riskcontrol.cron.service;

import com.riskcontrol.cron.entity.TLogRecord;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 日志记录表 服务类
 * </p>
 *
 * @author Colson
 * @since 2023-10-19
 */
public interface LogRecordService extends IService<TLogRecord> {

}
