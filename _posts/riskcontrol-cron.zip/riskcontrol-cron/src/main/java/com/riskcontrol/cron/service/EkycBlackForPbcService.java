package com.riskcontrol.cron.service;

import com.riskcontrol.cron.entity.TPbcCrawlerResultNew;

import java.util.List;

public interface EkycBlackForPbcService {

    /**
     * 处理pbc黑名单*
     *
     * @param loginName 登录用户
     * @param isOldKyc  是否是老kyc请求 true:是 false：否 null：不做区分，优先查询ekyc，不存在则其次查询老kyc
     */
    void handleEkycBlackForPbc(String loginName, Boolean isOldKyc);

    /**
     * 根据PBC黑名单同步改变用户黑名单的状态
     * @param pbcCrawlerResultNew
     * @return loginNameList
     */
    List<String> changeTRiskBlackStatusFromPBC(TPbcCrawlerResultNew pbcCrawlerResultNew);
}
