package com.riskcontrol.cron.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.creditlogs.QueryDepositTransWithCheckRequest;
import com.cn.schema.creditlogs.QueryDepositTransWithCheckResponse;
import com.cn.schema.creditlogs.WSQueryDepositTrans;
import com.cn.schema.request.*;
import com.gw.datacenter.vo.order.OrderReq;
import com.gw.datacenter.vo.order.OrderSummaryNew;
import com.gw.datacenter.vo.pagainate.QueryResult;
import com.gw.datacenter.vo.pagainate.QueryResultWrapper;
import com.riskcontrol.common.client.DBbaDateApiFeign;
import com.riskcontrol.common.client.IntegralFeign;
import com.riskcontrol.common.client.WSFeign;
import com.riskcontrol.common.config.WsCommonConfig;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.service.GdApiFeignTemplate;
import com.riskcontrol.cron.service.RequestService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * @Overview:提案service处理类
 * @History:【WS,OFFICE】:新增存款，取款，洗码，优惠，修正额度，额度记录分组报表功能
 */
@Service
public class RequestServiceImpl implements RequestService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    @Resource
    private WsCommonConfig wsCommonConfig;

    @Resource
    private WSFeign wsFeign;

    @Resource
    private GdApiFeignTemplate gdApiFeignTemplate;

    @Resource
    private IntegralFeign integralFeign;
    @Resource
    private DBbaDateApiFeign dBbaDateApiFeign;

    /**
     * 批准提案
     *
     * @param wsRequestsApprove
     * @return
     */
    @Override
    public WSResponseApprove requestApprove(WSRequestsApprove wsRequestsApprove) {
        wsRequestsApprove.setRequestType("02");
        wsRequestsApprove.setUserType("S");
        wsRequestsApprove.setApproveBy("system");
        wsRequestsApprove.setRemarks("riskApprove");
        wsRequestsApprove.setIpAddress("127.0.0.1");
        wsRequestsApprove.setDeductAmount("0");
        wsRequestsApprove.setNewflag("1");
        RequestApproveRequest request = new RequestApproveRequest();
        request.setInfProductId(wsCommonConfig.getWsProductId());
        request.setInfPwd(wsCommonConfig.getWsProductPwd());
        request.setWSRequestsApprove(wsRequestsApprove);
        wsRequestsApprove.setIsbatch(false);
        request.setRequestUUID(MDC.get(Constant.MDC_UUID_KEY));
        logger.info("批准提案 requestApprove request={}", JSONObject.toJSONString(request));
        RequestApproveResponse response = wsFeign.requestApprove(request);
        List<WSResponseApprove> list = response.getWSResponseApprove();
        WSResponseApprove result = list.get(0);
        return result;
    }

    /**
     * 修改取款风控原因
     *
     * @param wsWithdrawalRequests
     * @return
     */
    @Override
    public boolean modifyExceptionPrompt(WSWithdrawalRequests wsWithdrawalRequests) {
        ModifyWithdrawalExceptionPromptRequest request = new ModifyWithdrawalExceptionPromptRequest();
        request.setInfProductId(wsCommonConfig.getWsProductId());
        request.setInfPwd(wsCommonConfig.getWsProductPwd());
        request.setWSWithdrawalRequests(wsWithdrawalRequests);
        ModifyWithdrawalExceptionPromptResponse response = wsFeign.modifyExceptionPrompt(request);
        return response.isResult();

    }


    /**
     * 【WS,OFFICE】:新增存款，取款，洗码，优惠，修正额度，额度记录分组报表功能
     *
     * @param query
     * @return
     */
    @Override
    public WSQueryCountPAmount getCountReportPromotion(WSQueryPromotionRequests query) {
        QueryCountReportPromotionRequest request = new QueryCountReportPromotionRequest();
        request.setInfProductId(wsCommonConfig.getWsProductId());
        request.setInfPwd(wsCommonConfig.getWsProductPwd());
        request.setTerminal(wsCommonConfig.getWsTerminal());
        request.setWSQueryPromotionRequests(query);
        request.setRequestUUID(MDC.get(Constant.MDC_UUID_KEY));
        QueryCountReportPromotionResponse response = integralFeign.getCountReportPromotion(request);
        return response.getWSQueryCountPAmount();
    }


    @Override
    public QueryDepositTransWithCheckResponse queryDepositTransRecord(WSQueryDepositTrans query) {
        QueryDepositTransWithCheckRequest request = new QueryDepositTransWithCheckRequest();
        request.setInfProductId(wsCommonConfig.getWsProductId());
        request.setInfPwd(wsCommonConfig.getWsProductPwd());
        request.setWsQueryDepositTrans(query);
        request.setRequestUUID(MDC.get(Constant.MDC_UUID_KEY));
        //查询接口标识0:查询数量和金额,以及列表，1查询数量和金额,2只查询列表;
        request.setQueryFlag(1);
        QueryDepositTransWithCheckResponse response = wsFeign.queryDepositTransRecord(request);
        return response;
    }

    /**
     * 查询取款提案信息
     *
     * @param wsQueryWithdrawalRequest
     * @return
     */
    @Override
    public WSQueryCountAmount queryCountWithdrawRequest(WSQueryWithdrawalRequests wsQueryWithdrawalRequest) {
        QueryCountWithdrawalRequestsRequest request = new QueryCountWithdrawalRequestsRequest();
        request.setInfProductId(wsCommonConfig.getWsProductId());
        request.setInfPwd(wsCommonConfig.getWsProductPwd());
        request.setWSQueryWithdrawalRequests(wsQueryWithdrawalRequest);
        QueryCountWithdrawalRequestsResponse response = wsFeign.queryCountWithdrawRequest(request);
        return response.getWSQueryCountAmount();
    }


    /**
     * 查询取款提案(有限字段，只查提案表，没有联表查询)
     *QueryWithdrawalRequestsRequest
     * @param query
     * @return
     */
    @Override
    public QueryWithdrawalRequestsResponse queryWithdrawalRequestDesc(JSONObject query) {
        JSONObject request = new JSONObject();
        request.put("requestUUID",MDC.get(Constant.MDC_UUID_KEY));
        request.put("infProductId",wsCommonConfig.getWsProductId());
        request.put("infPwd",wsCommonConfig.getWsProductPwd());
        request.put("wsQueryWithdrawalRequests",query);
        QueryWithdrawalRequestsResponse response = wsFeign.queryWithdrawalRequestDesc(request);

        return response;
    }

    /**
     *  获取投注额和盈利金额
     * @param startTime
     * @param endTime
     * @param productId
     * @param loginName
     * @return
     */
    //代码迁移，应mock原因，相同bean内支持分别调用真实方法和mock方法
    @Override
    public BigDecimal[] getValidAccountAndWinOrLostAmount(String startTime, String endTime, String productId, String loginName) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDate start = LocalDate.parse(startTime, dateTimeFormatter);
        LocalDate end = LocalDate.parse(endTime, dateTimeFormatter);
        BigDecimal validAccount = BigDecimal.ZERO;
        BigDecimal winOrLostAmount = BigDecimal.ZERO;

        if (end.toEpochDay() - start.toEpochDay() > 3) {
            String startToday = LocalDateTime.of(start, LocalTime.MAX).format(dateTimeFormatter);
            String endToday = LocalDateTime.of(end.minusDays(1), LocalTime.MIN).format(dateTimeFormatter);


            OrderReq orderReq = new OrderReq();
            orderReq.setProductId(productId);
            orderReq.setLoginName(new String[]{loginName});
            orderReq.setBeginReckonTime(startTime);
            orderReq.setEndReckonTime(startToday);
            QueryResultWrapper result = gdApiFeignTemplate.getCountTotalStrRecordAndSummaryV2(orderReq);
            if (result != null && result.getUtilArray() != null) {
                String[] utilArray = result.getUtilArray();
                winOrLostAmount = winOrLostAmount.add(new BigDecimal(utilArray[3]));
                validAccount = validAccount.add(new BigDecimal(utilArray[2]));
            }

            orderReq.setBeginReckonTime(endToday);
            orderReq.setEndReckonTime(endTime);
            QueryResultWrapper result1 = gdApiFeignTemplate.getCountTotalStrRecordAndSummaryV2(orderReq);
            if (result != null && result1.getUtilArray() != null) {
                String[] utilArray = result1.getUtilArray();
                winOrLostAmount = winOrLostAmount.add(new BigDecimal(utilArray[3]));
                validAccount = validAccount.add(new BigDecimal(utilArray[2]));
            }
            QueryResult<OrderSummaryNew> summaryNewByLoginName = gdApiFeignTemplate.getSummaryNewByLoginName(productId,loginName,
                    LocalDateTime.of(start.plusDays(1), LocalTime.MIN).format(dateTimeFormatter),
                    LocalDateTime.of(end.minusDays(2), LocalTime.MIN).format(dateTimeFormatter));
            logger.info("summaryNewByLoginName： loginName={}  winOrLostAmount={},validAccount={}", loginName, winOrLostAmount, validAccount);

            if (summaryNewByLoginName != null
                    && summaryNewByLoginName.getTotalResult() != null
                    && summaryNewByLoginName.getTotalResult().getTotalWinLostAmount() != null
                    && summaryNewByLoginName.getTotalResult().getTotalValidAmount() != null) {
                winOrLostAmount = winOrLostAmount.add(summaryNewByLoginName.getTotalResult().getTotalWinLostAmount());
                validAccount = validAccount.add(summaryNewByLoginName.getTotalResult().getTotalValidAmount());
            }

        } else {
            OrderReq orderReq = new OrderReq();
            orderReq.setProductId(productId);
            orderReq.setLoginName(new String[]{loginName});
            orderReq.setBeginReckonTime(startTime);
            orderReq.setEndReckonTime(endTime);
            QueryResultWrapper result = gdApiFeignTemplate.getCountTotalStrRecordAndSummaryV2(orderReq);
            if (result != null && result.getUtilArray() != null) {
                String[] utilArray = result.getUtilArray();
                winOrLostAmount = winOrLostAmount.add(new BigDecimal(utilArray[3]));
                validAccount = validAccount.add(new BigDecimal(utilArray[2]));
            }
        }
        return new BigDecimal[]{validAccount, winOrLostAmount};
    }

    @Override
    public BigDecimal getPlayerTotalDeposit(String startTime, String endTime, String loginName) {
        JSONObject req = new JSONObject();
        req.put("beginTime", startTime);
        req.put("endTime", endTime);
        req.put("loginName", loginName);
        try {
            logger.info("调用数据中心 req:{}", req.toJSONString());
            JSONObject res = dBbaDateApiFeign.getPlayerTotalDeposit(req);
            logger.info("调用数据中心 rep:{}", res.toJSONString());
            return res.getJSONObject("data").getBigDecimal("totalDeposit");
        } catch (Exception e) {
            logger.info("调用数据中心，获取用户存款异常", e);
        }
        return BigDecimal.ZERO;
    }
}
