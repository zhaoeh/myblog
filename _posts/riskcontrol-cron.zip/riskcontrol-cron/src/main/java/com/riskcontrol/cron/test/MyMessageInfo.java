package com.riskcontrol.cron.test;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-09-17
 **/
public class MyMessageInfo {

    private String name;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
