package com.riskcontrol.cron.service.impl;

import cn.hutool.extra.spring.SpringUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.riskcontrol.common.entity.pojo.TRiskActionAllow;
import com.riskcontrol.common.entity.pojo.TRiskActionLogin;
import com.riskcontrol.common.entity.pojo.TRiskActionRules;
import com.riskcontrol.common.entity.request.api.PhoneNumberBlacklistGetOneRequest;
import com.riskcontrol.common.entity.request.device.LoginCheckRequest;
import com.riskcontrol.common.entity.response.device.LoginCheckDetailResponse;
import com.riskcontrol.common.entity.response.device.LoginCheckResponse;
import com.riskcontrol.common.enums.*;
import com.riskcontrol.cron.kafka.KafkaTopic;
import com.riskcontrol.cron.mapper.TRiskActionLoginMapper;
import com.riskcontrol.cron.mapper.TRiskActionRulesMapper;
import com.riskcontrol.cron.po.KafkaDeviceInfo;
import com.riskcontrol.cron.mapper.TRiskActionAllowMapper;
import com.riskcontrol.cron.service.PhoneNumberBlacklistService;
import com.riskcontrol.cron.service.RiskBlackService;
import com.riskcontrol.cron.service.TRiskActionLoginService;
import com.riskcontrol.cron.utils.KafkaProductUtils;
import com.riskcontrol.cron.utils.RedisUtil;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.lang3.time.FastDateFormat;
import org.jinq.orm.stream.JinqStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

import static com.riskcontrol.common.constants.Constant.RISK_DEVICE_KEY;
import static com.riskcontrol.common.constants.CronConstant.MODIFY_DEFAULT_SYSTEM;
import static com.riskcontrol.cron.utils.DateUtil.FMT_YYYY_MM_DD;

@Service
public class TRiskActionLoginServiceImpl extends ServiceImpl<TRiskActionLoginMapper, TRiskActionLogin> implements TRiskActionLoginService {

    @Autowired
    private TRiskActionAllowMapper riskActionAllowMapper;

    @Autowired
    private TRiskActionRulesMapper riskActionRulesMapper;

    @Autowired
    private KafkaProductUtils kafkaProductUtils;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private RedisUtil redisUtil;

    @Override
    @SneakyThrows
    public LoginCheckResponse loginCheck(LoginCheckRequest loginCheckRequest) {
        // 初始化LoginCheckResponse和KafkaDeviceInfo
        var loginCheckResponse = new LoginCheckResponse()
                .setIsBlack(false)
                .setDetails(new LoginCheckDetailResponse()
                        .setIsDeviceBlack(false)
                        .setIsIpBlack(false)
                );
        var kafkaDeviceInfo = new KafkaDeviceInfo()
                .setDeviceInfo(loginCheckRequest.getDeviceInfo())
                .setLoginCheckRequest(loginCheckRequest);

        // 检查设备指纹黑名单
        if (!loginCheckResponse.getIsBlack()) {
            var isDeviceBlack = isDeviceBlack(loginCheckRequest.getDeviceFingerprint(), loginCheckRequest.getLoginIp(), loginCheckRequest.getLoginName(), loginCheckRequest.getTenant(), RiskActionTypeEnum.LOGIN);
            if (isDeviceBlack) {
                loginCheckResponse.getDetails().setIsDeviceBlack(true);
                loginCheckResponse.setIsBlack(true);

                kafkaDeviceInfo.setInterceptTypeOfLoginCheckRequest(RiskActionInterceptTypeEnum.DEVICE_BLOCK.getId());
            }
        }

        // 检查ip黑名单
        if (!loginCheckResponse.getIsBlack()) {
            var isIpBlack = isIpBlack(loginCheckRequest.getDeviceFingerprint(), loginCheckRequest.getLoginIp(), loginCheckRequest.getLoginName(), loginCheckRequest.getTenant(), RiskActionTypeEnum.LOGIN);
            if (isIpBlack) {
                loginCheckResponse.getDetails().setIsIpBlack(true);
                loginCheckResponse.setIsBlack(true);

                kafkaDeviceInfo.setInterceptTypeOfLoginCheckRequest(RiskActionInterceptTypeEnum.IP_BLOCK.getId());
            }
        }

        // 检查设备指纹和ip的组合黑名单
        if (!loginCheckResponse.getIsBlack()) {
            var isDeviceAndIpBlack = isDeviceAndIpBlack(loginCheckRequest.getDeviceFingerprint(), loginCheckRequest.getLoginIp(), loginCheckRequest.getLoginName(), loginCheckRequest.getTenant(), RiskActionTypeEnum.LOGIN);
            if (isDeviceAndIpBlack) {
                loginCheckResponse.getDetails()
                        .setIsDeviceBlack(true)
                        .setIsIpBlack(true);
                loginCheckResponse.setIsBlack(true);

                kafkaDeviceInfo.setInterceptTypeOfLoginCheckRequest(RiskActionInterceptTypeEnum.IP_DEVICE_BLOCK.getId());
            }
        }

        // 设置登陆明细的拦截类型
        if (!loginCheckResponse.getIsBlack() && (StringUtils.isBlank(loginCheckRequest.getLoginIp()) || StringUtils.isBlank(loginCheckRequest.getDeviceFingerprint()))) {
            kafkaDeviceInfo.setInterceptTypeOfLoginCheckRequest(RiskActionInterceptTypeEnum.DEVICE_ABNORMAL_THROUGH.getId());
        } else if (!loginCheckResponse.getIsBlack()) {
            kafkaDeviceInfo.setInterceptTypeOfLoginCheckRequest(RiskActionInterceptTypeEnum.PASS_THROUGH.getId());
        }

        // push设备信息, 登陆风控明细到kafka
        kafkaProductUtils.pushKafkaMsg(KafkaTopic.DEVICE_KYC_TOPIC_SELF, this.objectMapper.writeValueAsString(kafkaDeviceInfo));

        return loginCheckResponse;
    }

    @Override
    public boolean isPhoneBlack(String phoneNumber) {
        if (StringUtils.isBlank(phoneNumber)) {
            return false;
        }
        var phoneNumberBlacklistGetOneRequest = new PhoneNumberBlacklistGetOneRequest();
        phoneNumberBlacklistGetOneRequest.setPhoneMd5(phoneNumber);
        var phoneNumberBlacklistRsp = SpringUtil.getBean(PhoneNumberBlacklistService.class).getPhoneNumberBlacklist(phoneNumberBlacklistGetOneRequest);
        if (phoneNumberBlacklistRsp != null) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isDeviceBlack(String deviceFingerprint, String ipAddress, String loginName, String tenant, RiskActionTypeEnum ruleAction) {
        if (StringUtils.isBlank(deviceFingerprint) || StringUtils.isBlank(ipAddress)) {
            return false;
        }

        var riskActionAllowList = this.riskActionAllowMapper.selectList(new LambdaQueryWrapper<TRiskActionAllow>()
                .eq(TRiskActionAllow::getAllowRecord, deviceFingerprint)
                .eq(TRiskActionAllow::getIsEnable, RiskActionEnableEnum.ENABLE.getId())
                .eq(TRiskActionAllow::getAllowType, RiskActionAllowTypeEnum.DEVICE.getId()));
        // 是否是设备指纹黑名单
        if (JinqStream.from(riskActionAllowList).where(s -> s.getAllowRule() == RiskActionAllowRuleEnum.BLACKLIST.getId()).exists()) {
            return true;
        }
        // 是否是设备指纹白名单
        if (JinqStream.from(riskActionAllowList).where(s -> s.getAllowRule() == RiskActionAllowRuleEnum.WHITELIST.getId()).exists()) {
            return false;
        }

        return isDeviceOrIpBlackForRuleList(deviceFingerprint, "", loginName, tenant, ruleAction, RiskActionRuleTypeEnum.DEVICE);
    }

    @Override
    public boolean isIpBlack(String deviceFingerprint, String ipAddress, String loginName, String tenant, RiskActionTypeEnum ruleAction) {
        if (StringUtils.isBlank(deviceFingerprint) || StringUtils.isBlank(ipAddress)) {
            return false;
        }

        var riskActionAllowList = this.riskActionAllowMapper.selectList(new LambdaQueryWrapper<TRiskActionAllow>()
                .eq(TRiskActionAllow::getAllowRecord, ipAddress)
                .eq(TRiskActionAllow::getIsEnable, RiskActionEnableEnum.ENABLE.getId())
                .eq(TRiskActionAllow::getAllowType, RiskActionAllowTypeEnum.IP.getId()));
        // 是否是IP黑名单
        if (JinqStream.from(riskActionAllowList).where(s -> s.getAllowRule() == RiskActionAllowRuleEnum.BLACKLIST.getId()).exists()) {
            return true;
        }
        // 是否是IP白名单
        if (JinqStream.from(riskActionAllowList).where(s -> s.getAllowRule() == RiskActionAllowRuleEnum.WHITELIST.getId()).exists()) {
            return false;
        }

        return isDeviceOrIpBlackForRuleList("", ipAddress, loginName, tenant, ruleAction, RiskActionRuleTypeEnum.IP);
    }

    @Override
    public boolean isDeviceAndIpBlack(String deviceFingerprint, String ipAddress, String loginName, String tenant, RiskActionTypeEnum ruleAction) {
        if (StringUtils.isBlank(deviceFingerprint) || StringUtils.isBlank(ipAddress)) {
            return false;
        }

        var riskActionAllowList = this.riskActionAllowMapper.selectList(new LambdaQueryWrapper<TRiskActionAllow>()
                .in(TRiskActionAllow::getAllowRecord, List.of(deviceFingerprint, ipAddress))
                .eq(TRiskActionAllow::getIsEnable, RiskActionEnableEnum.ENABLE.getId()));

        // 是否是设备指纹黑名单或IP黑名单
        if (JinqStream.from(riskActionAllowList).where(s -> s.getAllowRule() == RiskActionAllowRuleEnum.BLACKLIST.getId())
                .where(s -> s.getAllowType() == RiskActionAllowTypeEnum.DEVICE.getId())
                .where(s -> s.getAllowRecord().equals(deviceFingerprint))
                .exists() ||
                JinqStream.from(riskActionAllowList).where(s -> s.getAllowRule() == RiskActionAllowRuleEnum.BLACKLIST.getId())
                        .where(s -> s.getAllowType() == RiskActionAllowTypeEnum.IP.getId())
                        .where(s -> s.getAllowRecord().equals(ipAddress))
                        .exists()) {
            return true;
        }

        // 是否是设备指纹白名单且IP白名单
        if (JinqStream.from(riskActionAllowList).where(s -> s.getAllowRule() == RiskActionAllowRuleEnum.WHITELIST.getId())
                .where(s -> s.getAllowType() == RiskActionAllowTypeEnum.DEVICE.getId())
                .where(s -> s.getAllowRecord().equals(deviceFingerprint))
                .exists() &&
                JinqStream.from(riskActionAllowList).where(s -> s.getAllowRule() == RiskActionAllowRuleEnum.WHITELIST.getId())
                        .where(s -> s.getAllowType() == RiskActionAllowTypeEnum.IP.getId())
                        .where(s -> s.getAllowRecord().equals(ipAddress))
                        .exists()) {
            return false;
        }

        return isDeviceOrIpBlackForRuleList(deviceFingerprint, ipAddress, loginName, tenant, ruleAction, RiskActionRuleTypeEnum.COMPOSE_IP_AND_DEVICE);
    }

    @Override
    public boolean isUserBlack(String loginName) {
        if (StringUtils.isBlank(loginName)) {
            return false;
        }

        return SpringUtil.getBean(RiskBlackService.class).getBlackStatus(loginName);
    }

    /**
     * 保存登陆风控明细
     */
    @Override
    public void saveRiskActionLogin(LoginCheckRequest loginCheckRequest, int interceptType) {
        var riskActionLogin = new TRiskActionLogin();
        riskActionLogin.setDeviceFingerprintToken(Optional.ofNullable(loginCheckRequest.getDeviceFingerprintToken()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionLogin.setDeviceFingerprint(Optional.ofNullable(loginCheckRequest.getDeviceFingerprint()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionLogin.setLoginIp(Optional.ofNullable(loginCheckRequest.getLoginIp()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionLogin.setPhoneNumber(Optional.ofNullable(loginCheckRequest.getPhoneNumber()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionLogin.setProductId(Optional.ofNullable(loginCheckRequest.getProductId()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionLogin.setLoginName(Optional.ofNullable(loginCheckRequest.getLoginName()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionLogin.setTenant(Optional.ofNullable(loginCheckRequest.getTenant()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionLogin.setChannel(Optional.ofNullable(loginCheckRequest.getChannel()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionLogin.setDomainName(Optional.ofNullable(loginCheckRequest.getDomainName()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionLogin.setCreateBy(MODIFY_DEFAULT_SYSTEM);
        riskActionLogin.setUpdateBy(MODIFY_DEFAULT_SYSTEM);
        this.save(riskActionLogin);
    }

    private boolean isDeviceOrIpBlackForRuleList(String deviceFingerprint, String ipAddress, String loginName, String tenant, RiskActionTypeEnum ruleAction, RiskActionRuleTypeEnum ruleType) {
        var ruleList = riskActionRulesMapper.selectList(new LambdaQueryWrapper<TRiskActionRules>()
                .eq(TRiskActionRules::getTenant, tenant)
                .eq(TRiskActionRules::getRulesType, ruleType.getId())
                .eq(TRiskActionRules::getRulesAction, ruleAction.getId())
                .eq(TRiskActionRules::getIsEnable, RiskActionEnableEnum.ENABLE.getId())
        );

        var today = new Date();
        for (var rule : ruleList) {
            var loginNameList = IntStream.range(0, rule.getRulesCheckDay())
                    .mapToObj(s -> DateUtils.addDays(today, -s))
                    .map(s -> FastDateFormat.getInstance(FMT_YYYY_MM_DD).format(s))
                    .map(dateAt -> getLoginNamesFromRedis(ipAddress, deviceFingerprint, dateAt, tenant, ruleAction))
                    .flatMap(Collection::stream)
                    .toList();
            // 近几天登陆/注册人数小于限制数, 放行
            if (loginNameList.size() < rule.getRulesAccountMax()) {
                continue;
            }
            // 注册行为且注册人数大于或等于限制数, 拦截
            if (ruleAction == RiskActionTypeEnum.REGISTER) {
                return true;
            }
            var loginNameListOfToday = getLoginNamesFromRedis(ipAddress, deviceFingerprint, FastDateFormat.getInstance(FMT_YYYY_MM_DD).format(today), tenant, ruleAction);
            // loginName在今天已经登陆过, 放行
            if (loginNameListOfToday.contains(loginName)) {
                continue;
            }
            // loginName近几天登陆过, 且今日人数小于限制数, 放行
            if (loginNameList.contains(loginName) && loginNameListOfToday.size() < rule.getRulesAccountMax()) {
                continue;
            }
            // 拦截
            return true;
        }

        return false;
    }

    /**
     * 从redis缓存中获取dateAt登陆的人数
     *
     * @param ipAddress
     * @param deviceFingerprint
     * @param dateAt            example: 2024-11-05
     * @return
     */
    private List<String> getLoginNamesFromRedis(String ipAddress, String deviceFingerprint, String dateAt, String tenant, RiskActionTypeEnum actionType) {
        var redisKey = String.format(RISK_DEVICE_KEY, StringUtils.joinWith(":", dateAt, deviceFingerprint, ipAddress));
        var loginNameListJsonString = redisUtil.get(redisKey);
        return List.of();
    }

    /**
     * @param ipAddress
     * @param deviceFingerprint
     * @param dateAt            example: 2024-11-05
     * @return
     */
    private void setLoginNamesToRedis(String ipAddress, String deviceFingerprint, String dateAt, String tenant, RiskActionTypeEnum actionType) {
        var redisKey = String.format(RISK_DEVICE_KEY, StringUtils.joinWith(":", dateAt, deviceFingerprint, ipAddress));
        redisUtil.get(redisKey);
    }

}
