package com.riskcontrol.cron.operations;

/**
 * @program: riskcontrol-cron
 * @description: Operations 常量
 * @author: Erhu.Zhao
 * @create: 2023-11-17 12:28
 */
public class OperationsConstant {

    public static final String DELETE = "delete";
    public static final String SET = "set";
    public static final String GET = "get";
    public static final String PUT = "put";
    public static final String ENTRIES = "entries";
    public static final String ADD = "add";
    public static final String POP = "pop";
    public static final String INDEX = "index";
    public static final String RANDOMMEMBER = "randomMember";
    public static final String RESULT = "result";

}