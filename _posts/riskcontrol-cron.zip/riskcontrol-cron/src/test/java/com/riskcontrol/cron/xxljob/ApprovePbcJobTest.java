package com.riskcontrol.cron.xxljob;

import com.riskcontrol.cron.service.WithdrawService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import javax.annotation.Resource;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/6/5 11:26
 */
@ActiveProfiles("test")
@SpringBootTest
public class ApprovePbcJobTest {
    @Resource ApprovePbcJob approvePbcJob;
    @Resource
    WithdrawService withdrawService;
    @Test
    public void testJob(){
//        approvePbcJob.approvePbcJob();
        String res = withdrawService.queryWithdrawalInfo("1829404522012819456", "C66");
        System.out.println("===============res===================="+res);
    }



}
