package com.riskcontrol.cron;//package com.riskcontrol.cron;
//
//import lombok.extern.slf4j.Slf4j;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.http.MediaType;
//import org.springframework.test.context.junit4.SpringRunner;
//import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
//import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
//
//import javax.annotation.Resource;
//
//import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
//
///**
// * @program: riskcontrol-cron
// * @description: 手机号黑名单 前端控制器
// * @author: Colson
// * @create: 2023-09-26 14:19
// */
//@SpringBootTest(classes = RiskcontrolCronApplication.class)
//@Slf4j
//@AutoConfigureMockMvc
//@RunWith(SpringRunner.class)
//public class PhoneNumberBlacklistTest {
//
//    @Resource
//    private MockMvc mockMvc;
//
//    private static final String URL_PREFIX = "/phoneNumberBlacklist";
//
//    @Test
//    public void testPage() throws Exception {
//        String contentJson = "{\n" +
//                "  \"dataModifier\": \"\",\n" +
//                "  \"history\": \"\",\n" +
//                "  \"isAsc\": false,\n" +
//                "  \"isPage\": false,\n" +
//                "  \"pageNum\": 1,\n" +
//                "  \"pageSize\": 2,\n" +
//                "  \"phone\": \"\",\n" +
//                "  \"sortName\": \"createTime\",\n" +
//                "  \"status\": 0\n" +
//                "}";
//        mockMvc.perform(MockMvcRequestBuilders.post(URL_PREFIX + "/page")
//                        .content(contentJson)
//                        .accept(MediaType.APPLICATION_JSON)
//                        .contentType(MediaType.APPLICATION_JSON))
//                .andExpect(MockMvcResultMatchers.status().isOk())
//                .andDo(print());
//
//    }
//
//    @Test
//    public void testList() throws Exception {
//        String contentJson = "{\n" +
//                "  \"dataModifier\": \"\",\n" +
//                "  \"history\": \"\",\n" +
//                "  \"phone\": \"\",\n" +
//                "  \"status\": 0\n" +
//                "}";
//        mockMvc.perform(MockMvcRequestBuilders.post(URL_PREFIX + "/list")
//                        .content(contentJson)
//                        .accept(MediaType.APPLICATION_JSON)
//                        .contentType(MediaType.APPLICATION_JSON))
//                .andExpect(MockMvcResultMatchers.status().isOk())
//                .andDo(print());
//
//    }
//
//
//    @Test
//    public void testOne() throws Exception {
//        String contentJson = "{\n" +
//                "  \"phone\": \"123456789\"\n" +
//                "}";
//        mockMvc.perform(MockMvcRequestBuilders.post(URL_PREFIX + "/one")
//                        .content(contentJson)
//                        .accept(MediaType.APPLICATION_JSON)
//                        .contentType(MediaType.APPLICATION_JSON))
//                .andExpect(MockMvcResultMatchers.status().isOk())
//                .andDo(print());
//
//    }
//
//    @Test
//    public void testCreate() throws Exception {
//        String contentJson = "{\n" +
//                "  \"dataModifier\": \"c1\",\n" +
//                "  \"history\": \"001\",\n" +
//                "  \"phone\": \"1234567890\"\n" +
//                "}";
//        mockMvc.perform(MockMvcRequestBuilders.post(URL_PREFIX + "/create")
//                        .content(contentJson)
//                        .accept(MediaType.APPLICATION_JSON)
//                        .contentType(MediaType.APPLICATION_JSON))
//                .andExpect(MockMvcResultMatchers.status().isOk())
//                .andDo(print());
//
//    }
//
//    @Test
//    public void testUpdateHistory() throws Exception {
//        String contentJson = "{\n" +
//                "  \"dataModifier\": \"bbb2131\",\n" +
//                "  \"history\": \"123123\",\n" +
//                "  \"phone\": \"1234567890\"\n" +
//                "}";
//        mockMvc.perform(MockMvcRequestBuilders.post(URL_PREFIX + "/updateHistory")
//                        .content(contentJson)
//                        .accept(MediaType.APPLICATION_JSON)
//                        .contentType(MediaType.APPLICATION_JSON))
//                .andExpect(MockMvcResultMatchers.status().isOk())
//                .andDo(print());
//
//    }
//
//    @Test
//    public void testUpdateStatus() throws Exception {
//        String contentJson = "{\n" +
//                "  \"dataModifier\": \"\",\n" +
//                "  \"status\":23,\n" +
//                "  \"phone\": \"\"\n" +
//                "}";
//        mockMvc.perform(MockMvcRequestBuilders.post(URL_PREFIX + "/updateStatus")
//                        .content(contentJson)
//                        .accept(MediaType.APPLICATION_JSON)
//                        .contentType(MediaType.APPLICATION_JSON))
//                .andExpect(MockMvcResultMatchers.status().isOk())
//                .andDo(print());
//
//    }
//
//
//}
