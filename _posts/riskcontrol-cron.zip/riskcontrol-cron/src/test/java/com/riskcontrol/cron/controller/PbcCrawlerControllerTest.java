package com.riskcontrol.cron.controller;

import cn.hutool.core.util.IdUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.riskcontrol.common.entity.request.PbcCrawlerUpdateStatusReq;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.enums.PbcSourceEnum;
import com.riskcontrol.cron.entity.PagcorRecord;
import com.riskcontrol.cron.entity.TPbcCrawlerResultNew;
import com.riskcontrol.cron.utils.DateUtil;
import com.riskcontrol.cron.xxljob.ApprovePbcJob;
import okhttp3.RequestBody;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.hc.core5.net.URIBuilder;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;

import java.math.BigInteger;
import java.net.URISyntaxException;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class PbcCrawlerControllerTest extends BaseControllerTest {

    @Autowired
    private TestRestTemplate testRestTemplate;

    @SpyBean
    private ApprovePbcJob approvePbcJob;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void pullPagcorDataToDbByFullName() throws Exception {
        Mockito.doReturn("InvalidCookie").when(approvePbcJob).getPagcorCookie();
        var pbcPagcorRecord = new PagcorRecord();
        pbcPagcorRecord.setSource(PbcSourceEnum.GOVT.getName());
        pbcPagcorRecord.setFirstName("WILMIE");
        pbcPagcorRecord.setMiddleName("RATON");
        pbcPagcorRecord.setBirthDate(DateUtils.addYears(new Date(), -30));
        pbcPagcorRecord.setLastName("AGTANG");
        pbcPagcorRecord.setIsBanned("true");
        pbcPagcorRecord.setDateCreated(DateUtil.format(new Date(), "M/d/yyyy hh:mm:ss"));
        pbcPagcorRecord.setGuestExtId(DigestUtils.md5Hex(this.objectMapper.writeValueAsString(List.of(
                pbcPagcorRecord.getFirstName(),
                pbcPagcorRecord.getMiddleName(),
                pbcPagcorRecord.getLastName()
        ))));
        Mockito.doReturn(List.of(
                pbcPagcorRecord
        )).when(approvePbcJob).searchPagcorRecord(Mockito.anyString(), Mockito.any(RequestBody.class));
        var url = new URIBuilder("/pbcCrawler/pullPagcorDataToDb/byFullName")
                .setParameter("fullName", "WILMIE RATON AGTANG")
                .setParameter("currentUsername", "Tom")
                .build();
        var response = this.testRestTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(null), new ParameterizedTypeReference<Response<List<TPbcCrawlerResultNew>>>() {
        });
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().success());
    }

    @Test
    public void pullPagcorDataToDbByFullNameExtraSpace() throws URISyntaxException {
        var pbcCrawlerResultNewDataOne = new TPbcCrawlerResultNew();
        pbcCrawlerResultNewDataOne.setId(BigInteger.valueOf(IdUtil.getSnowflakeNextId()));
        pbcCrawlerResultNewDataOne.setFirstName("  Thomas  ");
        pbcCrawlerResultNewDataOne.setMiddleName("");
        pbcCrawlerResultNewDataOne.setLastName("hancock");
        var pbcCrawlerResultNewDataTwo = new TPbcCrawlerResultNew();
        pbcCrawlerResultNewDataTwo.setId(BigInteger.valueOf(IdUtil.getSnowflakeNextId()));
        pbcCrawlerResultNewDataTwo.setFirstName("Thomas");
        pbcCrawlerResultNewDataTwo.setMiddleName("Robert");
        pbcCrawlerResultNewDataOne.setLastName("Hancock");
        Mockito.doReturn(List.of(
                pbcCrawlerResultNewDataOne,
                pbcCrawlerResultNewDataTwo
        )).when(approvePbcJob).pullPagcorDataToDbByFullName(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
        var url = new URIBuilder("/pbcCrawler/pullPagcorDataToDb/byFullName")
                .setParameter("fullName", "Thomas Hancock")
                .setParameter("currentUsername", "Tom")
                .build();
        var response = this.testRestTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(null), new ParameterizedTypeReference<Response<List<TPbcCrawlerResultNew>>>() {
        });
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().success());
//        assertEquals(1, response.getBody().getBody().size());
//        var result = response.getBody().getBody().get(0);
//        assertNotNull(result.getId());
//        assertEquals("Thomas", result.getFirstName().trim());
//        assertEquals("", result.getMiddleName().trim());
//        assertEquals("Hancock", result.getLastName().trim());
    }

    @Test
    public void updateStatus() throws Exception {
        // 根据全名手动创建PBC
        BigInteger id;
        {
            Mockito.doReturn("InvalidCookie").when(approvePbcJob).getPagcorCookie();
            var pbcPagcorRecord = new PagcorRecord();
            pbcPagcorRecord.setSource(PbcSourceEnum.GOVT.getName());
            pbcPagcorRecord.setFirstName("WILMIE");
            pbcPagcorRecord.setMiddleName("RATON");
            pbcPagcorRecord.setBirthDate(DateUtils.addYears(new Date(), -30));
            pbcPagcorRecord.setLastName("AGTANG");
            pbcPagcorRecord.setIsBanned("true");
            pbcPagcorRecord.setDateCreated(DateUtil.format(new Date(), "M/d/yyyy hh:mm:ss"));
            pbcPagcorRecord.setGuestExtId(DigestUtils.md5Hex(this.objectMapper.writeValueAsString(List.of(
                    pbcPagcorRecord.getFirstName(),
                    pbcPagcorRecord.getMiddleName(),
                    pbcPagcorRecord.getLastName()
            ))));
            Mockito.doReturn(List.of(
                    pbcPagcorRecord
            )).when(approvePbcJob).searchPagcorRecord(Mockito.anyString(), Mockito.any(RequestBody.class));
            var url = new URIBuilder("/pbcCrawler/pullPagcorDataToDb/byFullName")
                    .setParameter("fullName", "WILMIE RATON AGTANG")
                    .setParameter("currentUsername", "Tom")
                    .build();
            var response = this.testRestTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(null), new ParameterizedTypeReference<Response<List<TPbcCrawlerResultNew>>>() {
            });
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertTrue(response.getBody().success());
            id = response.getBody().getBody().get(0).getId();
        }
        // 更新状态
        {
            var url = new URIBuilder("/pbcCrawler/updateStatus").build();
            var pbcCrawlerUpdateStatusReq = new PbcCrawlerUpdateStatusReq();
            pbcCrawlerUpdateStatusReq.setId(id);
            pbcCrawlerUpdateStatusReq.setIsBanned(0);
            var response = this.testRestTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(pbcCrawlerUpdateStatusReq), new ParameterizedTypeReference<Response<Boolean>>() {
            });
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertTrue(response.getBody().success());
        }
    }

}
