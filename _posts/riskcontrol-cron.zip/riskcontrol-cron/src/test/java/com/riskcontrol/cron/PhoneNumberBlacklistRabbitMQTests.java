package com.riskcontrol.cron;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.cron.constants.CronConstant;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.junit.RabbitAvailable;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import javax.annotation.Resource;

@ActiveProfiles("test")
@SpringBootTest
@RabbitAvailable
public class PhoneNumberBlacklistRabbitMQTests {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private AmqpTemplate rabbitTemplate;

    @Test
    void contextLoads() {
    }

    @Test
    public void updatePhoneNumberBlacklistMessage() {
        String msgBody = "{\n" +
                "    \"msgContent\": {\n" +
                "        \"flag\": \"17\",\n" +
                "        \"oldValue\": \"\",\n" +
                "        \"newValue\": \"\",\n" +
                "        \"productId\": \"C66\",\n" +
                "        \"uuid\": \"23fae9c1-20db-4de1-a00b-faf3bf1c6f0e\",\n" +
                "        \"customer\": {\n" +
                "            \"currency\": \"PHP\",\n" +
                "            \"customerId\": \"919213830913916929\",\n" +
                "            \"domainName\": \"bingoplusandroid1.com\",\n" +
                "            \"ipAddress\": \"110.54.171.81\",\n" +
                "            \"lastUpdatedBy\": \"C66Admin\",\n" +
                "            \"loginName\": \"bingoplus2uly2m\",\n" +
                "            \"phone\": \"9534011746\",\n" +
                "            \"phoneMd5\": \"74ae97c7fe00bf0638596b17a364c15e\",\n" +
                "            \"phoneValidateStatus\": 0,\n" +
                "            \"productId\": \"C66\",\n" +
                "            \"registerFromType\": 0,\n" +
                "            \"siteId\": 0\n" +
                "        }\n" +
                "    },\n" +
                "    \"routingKey\": \"update_customer_info\"\n" +
                "}";
        String flagStr = "flag";
        JSONObject jsonObject = JSONObject.parseObject(msgBody);
        if (!jsonObject.getString(flagStr).equals(CronConstant.MESSAGE_FLAG_MODIFY_PHONE)) {
            // 非手机号更新消息，不处理
            return;
        }
        Message message = MessageBuilder.withBody(msgBody.getBytes())
                .setContentType(MessageProperties.CONTENT_TYPE_JSON)
                .build();

        logger.info("============ 发送手机号码编辑消息 ============ ");
        logger.info("消息内容：{}", msgBody);
        rabbitTemplate.convertAndSend("exchange_update_customer_info_risktest", "C66.update_customer_info_risktest", message);
    }

}
