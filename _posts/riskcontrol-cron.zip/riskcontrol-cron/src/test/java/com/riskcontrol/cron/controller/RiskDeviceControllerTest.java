package com.riskcontrol.cron.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.riskcontrol.common.entity.request.device.RegisterSaveRequest;
import com.riskcontrol.common.entity.response.Response;
import org.apache.hc.core5.net.URIBuilder;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import java.net.URISyntaxException;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class RiskDeviceControllerTest extends BaseControllerTest {

    @Autowired
    private TestRestTemplate testRestTemplate;

    @Test
    public void registerSave() throws URISyntaxException {
        var url = new URIBuilder("/risk/check/registerSave")
                .build();
        var body = new RegisterSaveRequest();
        body.setRegisterIp("127.0.0.1");
        body.setChannel("91");
        body.setDeviceFingerprintToken("1eUf2RuJVrJ8jo6WlNH4TEJ4jtUaklg5IIkaNiyOfcLlhF2v5EiS8NF7OS3AaZou");
        body.setDeviceFingerprint("67355236L5Ro2DymdHapZuRIdtIq8tD9Yc1pQWY1");
        body.setLoginName("bingoplusu2tnyn");
        body.setPhoneNumber("");
        body.setTenant("BP");
        body.setProductId("C66");
        body.setDomainName("https://www.dingxiang-inc.com");
        var response = this.testRestTemplate.exchange(url, HttpMethod.POST, new HttpEntity<>(body), new ParameterizedTypeReference<Response<Boolean>>() {
        });
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }
}
