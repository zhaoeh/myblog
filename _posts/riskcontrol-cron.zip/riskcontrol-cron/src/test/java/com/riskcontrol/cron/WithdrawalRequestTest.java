package com.riskcontrol.cron;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.request.QueryWithdrawalRequestsResponse;
import com.cn.schema.request.WSQueryWithdrawalRequests;
import com.cn.schema.request.WSWithdrawalRequests;
import com.riskcontrol.cron.service.RequestService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/7/4 9:39
 */
@ActiveProfiles("test")
@SpringBootTest
@AutoConfigureMockMvc
public class WithdrawalRequestTest {
    @Resource
    private RequestService requestService;

    @Test
    public void test() throws Exception {
        BigDecimal totalDeposit = requestService.getPlayerTotalDeposit("2024-09-08 08:38:50", "2024-10-10 08:38:50", "bingoplusm90z7g");
        System.out.println(totalDeposit);
//        WSQueryWithdrawalRequests queryWithdrawalRequests = new WSQueryWithdrawalRequests();
//        queryWithdrawalRequests.setProductId("C66");
//        queryWithdrawalRequests.setLoginName("bingoplusx1m78a");
//
//        queryWithdrawalRequests.setCatalog("0;11;12;13;14;15");
//        queryWithdrawalRequests.setPageSize(100);
//        JSONObject query = JSONObject.parseObject(JSONObject.toJSONString(queryWithdrawalRequests));
//        QueryWithdrawalRequestsResponse response = requestService.queryWithdrawalRequestDesc(query);
//        List<WSWithdrawalRequests> withdrawalRequestsList = response.getWSWithdrawalRequests();
//
//        BigDecimal todayLimit = BigDecimal.ZERO;
//        BigDecimal totalPassedAmount = BigDecimal.ZERO;
//        if (!withdrawalRequestsList.isEmpty()) {
//            BigDecimal withdrawalAmount = BigDecimal.ZERO;
//            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
//            List<WSWithdrawalRequests> collect = withdrawalRequestsList.stream().filter(Objects::nonNull).filter(w -> LocalDate.parse(w.getCreatedDate(), dateTimeFormatter).equals(LocalDate.now()) && ("1".equals(w.getFlag()) || "2".equals(w.getFlag()))).collect(Collectors.toList());
//            if (!collect.isEmpty()) {
//                double sum = collect.stream().mapToDouble(w -> new BigDecimal(w.getAmount()).doubleValue()).sum();
//                if (sum > 0) {
//                    withdrawalAmount = BigDecimal.valueOf(sum);
//                }
//            }
//            System.out.println("TodayPass:"+collect.size());
//            todayLimit = todayLimit.add(withdrawalAmount);
//
//            List<WSWithdrawalRequests> collected = withdrawalRequestsList.stream().filter(Objects::nonNull).filter(w -> !"0".equals(w.getFlag())).collect(Collectors.toList());
//
//            if (!collected.isEmpty()) {
//                List<WSWithdrawalRequests> sortedWithdrawal = collected.stream().filter(Objects::nonNull).sorted(Comparator.comparing(WSWithdrawalRequests::getCreatedDate).reversed()).collect(Collectors.toList());
//                List<WSWithdrawalRequests> passedList = new ArrayList<>();
//
//                for (WSWithdrawalRequests withdrawalRequests : sortedWithdrawal) {
//                    if ("0".equals(withdrawalRequests.getExceptionPromptType())) {
//                        passedList.add(withdrawalRequests);
//                    } else {
//                        break;
//                    }
//                }
//                System.out.println("TotalPassedCount:"+passedList.size());
//
//                totalPassedAmount = BigDecimal.valueOf(passedList.stream().mapToDouble(w -> Double.parseDouble(w.getAmount())).sum());
//            }
//        }
//        System.out.println("todayLimit:"+todayLimit);
//        System.out.println("TotalPassedAmount:"+totalPassedAmount);
    }
}
