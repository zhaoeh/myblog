package com.riskcontrol.cron.controller;

import com.riskcontrol.cron.BaseTest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.context.ActiveProfiles;

/**
 * @author sanji
 */
@AutoConfigureMockMvc
@ActiveProfiles("test")
public class BaseControllerTest extends BaseTest {
    @Value("${ws.product.pwd}")
    public String infPwd;
    @Value("${ws.product.id}")
    public String productId;
}
