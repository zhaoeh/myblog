package com.riskcontrol.cron.controller;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.request.kyc.RiskUpdateKycRequestRequest;
import com.riskcontrol.cron.utils.RedisUtil;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import javax.annotation.Resource;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/3/21 10:55
 */
public class KycRequestControllerTest extends BaseControllerTest{
    @Resource
    private MockMvc mockMvc;


    @Test
    @DisplayName("测试autoApproveKycAndPbc接口")
    void autoApproveKycAndPbc() throws Exception {
        RiskUpdateKycRequestRequest request = new RiskUpdateKycRequestRequest();

        request.setInfProductId(productId);
        request.setInfPwd(infPwd);
        request.setRequestUUID(UUID.randomUUID().toString());
        String requestStr = "{\"address\":\"Purok uno barangay cadulawan minglanilla cebu\",\"approvedBy\":\"c66\"," +
                "\"approvedDate\":\"2024-03-21 11:02:32\",\"assigneeBy\":\"c66\",\"assigneeTime\":\"2024-03-21 11:02:32\"" +
                ",\"birthPlace\":\"Cebu city\",\"birthday\":\"1983-11-30\",\"channel\":\"99\",\"country\":\"Philippines\"," +
                "\"createdBy\":\"system\",\"createdDate\":\"2024-03-21 11:02:32\",\"customerId\":\"973495539297419265\",\"dispatchStatus\":2," +
                "\"employerName\":\"Quadj\",\"firstName\":\"JUNIPER\",\"idNo\":\"G09-11-001355\",\"idScan\":\"58dc6b40-c563-48a8-b5bd-170d54070a49\"" +
                ",\"idType\":\"4\",\"imgUrl\":\"5063bc04-e3db-4841-81f7-bda3a8634548\",\"lastName\":\"ABALAYAN\",\"loginName\":\"bingoplusgmpls5\"" +
                ",\"middleName\":\"CILOTE\",\"nationality\":\"Filipino \",\"natureOfWork\":\"Field \"," +
                "\"presentAddress\":\"Purok uno barangay cadulawan minglanilla cebu\",\"product\":\"BP\",\"productId\":\"C66\"," +
                "\"sex\":\"M\",\"sourceOfIncome\":\"Employee \",\"status\":\"1\",\"tenant\":\"BP\",\"updateBy\":\"system\"," +
                "\"updateDate\":\"2024-03-21 11:02:32\"}";
        KycRequest wsKycRequest = JSONObject.parseObject(requestStr,KycRequest.class);
        request.setWsKycRequest(wsKycRequest);

        mockMvc.perform(MockMvcRequestBuilders
                        .post("/customers/kyc_request/autoApproveKycAndPbc")
                        .content(JSONObject.toJSONString(request))
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                )
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.jsonPath( "head.errCode", Matchers.equalTo("0000")))
                .andReturn();
    }
}
