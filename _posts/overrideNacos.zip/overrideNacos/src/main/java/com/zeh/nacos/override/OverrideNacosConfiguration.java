package com.zeh.nacos.override;

import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.Ordered;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.util.Objects;
import java.util.Properties;

/**
 * @program: paycenter-office
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-11-09 18:15
 */
public class OverrideNacosConfiguration implements ApplicationContextInitializer, Ordered {
    private final Properties properties = new Properties();
    private final YamlPropertiesFactoryBean yamlPropertiesFactoryBean = new YamlPropertiesFactoryBean();
    private String[] profiles = {
            "override-nacos.properties",
            "override-nacos.yml",
            "override-nacos.yaml",
    };

    @Override
    public void initialize(ConfigurableApplicationContext applicationContext) {
        ConfigurableEnvironment environment = applicationContext.getEnvironment();
        for (String profile : profiles) {
            Resource resource = new ClassPathResource(profile);
            if (resource.isReadable()) {
                try {
                    if (Objects.nonNull(profile) && profile.endsWith(".properties")) {
                        properties.load(resource.getInputStream());
                        environment.getPropertySources().addFirst(new PropertiesPropertySource(resource.getFilename(), properties));
                    } else if (Objects.nonNull(profile) && (profile.endsWith(".yml") || profile.endsWith(".yaml"))) {
                        yamlPropertiesFactoryBean.setResources(resource);
                        Properties properties = yamlPropertiesFactoryBean.getObject();
                        environment.getPropertySources().addFirst(new PropertiesPropertySource(resource.getFilename(), properties));
                    }

                } catch (IOException e) {
                }
            }

        }
    }

    @Override
    public int getOrder() {
        return -298;
    }
}