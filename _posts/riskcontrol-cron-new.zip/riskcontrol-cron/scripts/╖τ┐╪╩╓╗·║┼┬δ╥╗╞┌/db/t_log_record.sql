-- risk_control_cron.t_log_record definition

CREATE TABLE `t_log_record` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `module_name` varchar(100) NOT NULL COMMENT '系统模块名称',
    `location` varchar(100)  NOT NULL COMMENT '日志记录位置描述，例：类名+方法名等关键字用于快速定位',
    `type` varchar(10)  DEFAULT NULL COMMENT '日志类型：ERROR，INFO...',
    `log_message` text  COMMENT '日志信息',
    `request_url` varchar(100) DEFAULT NULL COMMENT '请求url',
    `request_param` varchar(1000)  DEFAULT NULL COMMENT '请求参数',
    `receive_param` text  COMMENT '接收参数',
    `remark` varchar(1000) DEFAULT NULL COMMENT '备注',
    `create_by` varchar(255)  DEFAULT NULL COMMENT '创建人',
    `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_by` varchar(255)  DEFAULT NULL COMMENT '更新人',
    `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
    PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4  ROW_FORMAT=DYNAMIC COMMENT='日志记录表';