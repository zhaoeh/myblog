-- risk_control_cron.t_odd_numbers_gen definition

CREATE TABLE `t_odd_numbers_gen` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `serial_type` varchar(3)  DEFAULT NULL,
    `request_type` varchar(3)  DEFAULT NULL,
    `product_id` varchar(5)  DEFAULT NULL,
    `time_str` varchar(12)  DEFAULT NULL,
    `special_str` varchar(3)  DEFAULT NULL,
    `serial_number` varchar(10)  DEFAULT NULL,
    `last_updated_date` datetime DEFAULT NULL,
    `created_date` datetime DEFAULT NULL,
    `remarks` varchar(200)  DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4  COMMENT='t_odd_numbers_gen';

ALTER TABLE t_odd_numbers_gen MODIFY COLUMN id bigint auto_increment NOT NULL COMMENT '主键';
ALTER TABLE t_odd_numbers_gen MODIFY COLUMN serial_type varchar(3)  NULL COMMENT '单号类型：1=提案类单号；2=转账类单号';
ALTER TABLE t_odd_numbers_gen MODIFY COLUMN request_type varchar(3)  NULL COMMENT '请求类型:01、02';
ALTER TABLE t_odd_numbers_gen MODIFY COLUMN product_id varchar(5)  NULL COMMENT '产品ID：A01';
ALTER TABLE t_odd_numbers_gen MODIFY COLUMN time_str varchar(12)  NULL COMMENT '时间串：201901011223、1901211233';
ALTER TABLE t_odd_numbers_gen MODIFY COLUMN special_str varchar(3)  NULL COMMENT '特殊指定位：A-Z/65-90';
ALTER TABLE t_odd_numbers_gen MODIFY COLUMN serial_number varchar(10)  NULL COMMENT '流水编号：A001、65001';
ALTER TABLE t_odd_numbers_gen MODIFY COLUMN last_updated_date datetime NULL COMMENT '最后更新时间';
ALTER TABLE t_odd_numbers_gen MODIFY COLUMN created_date datetime NULL COMMENT '创建时间';
ALTER TABLE t_odd_numbers_gen MODIFY COLUMN remarks varchar(200)  NULL COMMENT '备注';