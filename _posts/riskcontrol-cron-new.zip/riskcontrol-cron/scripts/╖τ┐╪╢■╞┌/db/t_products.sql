-- risk_control_cron.t_products definition

CREATE TABLE `t_products` (
    `created_by` varchar(20)  NOT NULL COMMENT 'User who created this record',
    `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Creation date',
    `effectivity_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Effectivity Date',
    `expiry_date` datetime NOT NULL DEFAULT '3000-12-31 23:59:59' COMMENT 'Expiration Date',
    `last_update` datetime DEFAULT NULL COMMENT 'Last update of this request',
    `last_updated_by` varchar(20)  DEFAULT NULL COMMENT 'User who modifies the request',
    `product_desc` varchar(200)  DEFAULT NULL COMMENT 'Product Description',
    `product_id` varchar(10)  NOT NULL COMMENT 'Primary Key',
    `product_name` varchar(30)  NOT NULL COMMENT 'Product Name',
    UNIQUE KEY `uk_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4  COMMENT='Products Table';