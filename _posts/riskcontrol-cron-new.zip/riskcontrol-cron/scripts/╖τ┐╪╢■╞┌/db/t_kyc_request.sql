-- risk_control_cron.t_kyc_request definition

CREATE TABLE `t_kyc_request`
(
    `id`                 bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `customer_id`        bigint                                                          NOT NULL,
    `login_name`         varchar(30)  NOT NULL,
    `product_id`         varchar(3)   NOT NULL,
    `first_name`         varchar(64)   DEFAULT NULL,
    `middle_name`        varchar(64)   DEFAULT NULL,
    `last_name`          varchar(64)   DEFAULT NULL,
    `birthday`           varchar(100)  DEFAULT NULL,
    `sex`                varchar(1)    DEFAULT NULL,
    `repetation`         varchar(20)   DEFAULT NULL,
    `doubtful`           varchar(20)   DEFAULT NULL,
    `id_scan`            varchar(100)  DEFAULT NULL,
    `id_type`            bigint                                                           DEFAULT NULL,
    `remark`             varchar(500)  DEFAULT NULL,
    `id_no`              varchar(64)   DEFAULT NULL,
    `status`             bigint                                                          NOT NULL,
    `created_date`       datetime                                                         DEFAULT NULL COMMENT '创建时间',
    `created_by`         varchar(64)   DEFAULT NULL,
    `update_date`        datetime                                                         DEFAULT NULL COMMENT '更新时间',
    `update_by`          varchar(64)   DEFAULT NULL,
    `address`            varchar(256)  DEFAULT NULL,
    `country`            varchar(64)   DEFAULT NULL,
    `open_date`          datetime                                                         DEFAULT NULL COMMENT '开放时间',
    `approved_date`      datetime                                                         DEFAULT NULL COMMENT '审批时间',
    `approved_by`        varchar(30)   DEFAULT NULL,
    `dispatch_status`    bigint                                                           DEFAULT '0',
    `assignee_time`      datetime                                                         DEFAULT NULL COMMENT '通过时间',
    `assignee_by`        varchar(20)   DEFAULT NULL,
    `pbc_status`         bigint                                                           DEFAULT '0',
    `bill_no`            varchar(100)  DEFAULT NULL,
    `product`            varchar(10)   DEFAULT NULL,
    `channel`            varchar(2)    DEFAULT NULL,
    `pbc_approved_by`    varchar(30)   DEFAULT NULL,
    `pbc_approved_date`  datetime                                                         DEFAULT NULL COMMENT '同意时间',
    `sign_id`            varchar(100)  DEFAULT NULL,
    `process_log_type`   varchar(100)     DEFAULT NULL,
    `process_log_remark` varchar(100)                                                     DEFAULT NULL,
    `site_id`            bigint                                                           DEFAULT NULL,
    `employer_name`      varchar(300)     DEFAULT NULL COMMENT '企业名称',
    `birth_place`        varchar(300)     DEFAULT NULL COMMENT '出生地',
    PRIMARY KEY (`id`) USING BTREE,
    UNIQUE KEY `PK_KYC_REQ_ID` (`id`),
    KEY                  `I_KYC_REQ_LN_PID` (`login_name`,`product_id`),
    KEY                  `I_KYC_REQ_CDATE` (`created_date`),
    KEY                  `T_KYC_REQUEST_FIRST_NAME_IDX` (`first_name`,`middle_name`,`last_name`,`birthday`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4  COMMENT='KYC请求表';

ALTER TABLE t_kyc_request MODIFY COLUMN process_log_type varchar(100)  NULL COMMENT '处理日志类型,关联T_KYC_REQUEST_PROCESS_LOG(kyc_request_id 最近得一条记录)';
ALTER TABLE t_kyc_request MODIFY COLUMN process_log_remark varchar(100)  NULL COMMENT '处理日志remark.关联T_KYC_REQUEST_PROCESS_LOG(kyc_request_id 最近得一条记录)';
ALTER TABLE t_kyc_request MODIFY COLUMN site_id bigint NULL COMMENT '站点ID';
ALTER TABLE t_kyc_request MODIFY COLUMN status tinyint NOT NULL COMMENT 'KYC审批状态0 待审核，1 已审核，2 自动拒绝，3手动拒绝';
ALTER TABLE t_kyc_request MODIFY COLUMN sex varchar(1)  NULL COMMENT 'M=Male, F=Female';
ALTER TABLE t_kyc_request MODIFY COLUMN open_date datetime NULL COMMENT 'kyc 后台点开审核时间';
ALTER TABLE t_kyc_request MODIFY COLUMN pbc_approved_by varchar(30)  NULL COMMENT 'pbc审核人';
ALTER TABLE t_kyc_request MODIFY COLUMN pbc_approved_date datetime NULL COMMENT 'pbc审核时间';
ALTER TABLE t_kyc_request MODIFY COLUMN dispatch_status tinyint DEFAULT 0 NULL COMMENT '派单状态,0 未分配，1已分配，2已接受，3未响应';
ALTER TABLE t_kyc_request MODIFY COLUMN customer_id bigint NOT NULL COMMENT '用户ID';
ALTER TABLE t_kyc_request MODIFY COLUMN login_name varchar(30)  NOT NULL COMMENT '用户名';
ALTER TABLE t_kyc_request MODIFY COLUMN product_id varchar(3)  NOT NULL COMMENT '产品ID';
ALTER TABLE t_kyc_request MODIFY COLUMN repetation varchar(20)  NULL COMMENT '手动或自动审核kyc通过时根据first_name, middle_name, last_name, birthday, sex, product, status=1，查询出大于0条数据时标记为1';
ALTER TABLE t_kyc_request MODIFY COLUMN doubtful varchar(20)  NULL COMMENT '大于100岁时标记为1';
ALTER TABLE t_kyc_request MODIFY COLUMN id_type tinyint NULL COMMENT '证件类型';
ALTER TABLE t_kyc_request MODIFY COLUMN id_no varchar(64)  NULL COMMENT 'id编号';
ALTER TABLE t_kyc_request MODIFY COLUMN created_by varchar(64)  NULL COMMENT '创建人';
ALTER TABLE t_kyc_request MODIFY COLUMN update_by varchar(64)  NULL COMMENT '更新人';
ALTER TABLE t_kyc_request MODIFY COLUMN approved_by varchar(30)  NULL COMMENT '审核人';
ALTER TABLE t_kyc_request MODIFY COLUMN assignee_by varchar(20)  NULL COMMENT '分配审核的人';
ALTER TABLE t_kyc_request MODIFY COLUMN bill_no varchar(100)  NULL COMMENT '业务编号（随机生成唯一号）';
ALTER TABLE t_kyc_request MODIFY COLUMN product varchar(10)  NULL COMMENT '血缘标记（BP、AP、 GP）';
ALTER TABLE t_kyc_request MODIFY COLUMN channel varchar(2)  NULL COMMENT '渠道';
