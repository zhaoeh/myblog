package com.riskcontrol.cron.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDateTime;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import lombok.experimental.Accessors;

/**
 * <p>
 * 用户标签绑定关系表
 * </p>
 *
 * @author Yannis
 * @since 2024-01-11
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@TableName("t_risk_label_relationship")
@ApiModel(value = "TRiskLabelRelationship对象", description = "用户标签绑定关系表")
public class TRiskLabelRelationship extends BasePersonFullEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("所属产品")
    private String productId;

    @ApiModelProperty("用户ID")
    private Long customerId;

    @ApiModelProperty("标签ID")
    private BigInteger riskLabelId;

    @ApiModelProperty("风控标签名称")
    private String riskLabelName;

    @ApiModelProperty("风控标签Key")
    private String riskLabelKey;

    @ApiModelProperty("用户登录名")
    private String loginName;

    @ApiModelProperty("备注")
    private String remark;

}
