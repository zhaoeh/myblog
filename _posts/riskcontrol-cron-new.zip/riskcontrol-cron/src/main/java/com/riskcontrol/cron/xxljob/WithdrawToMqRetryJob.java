package com.riskcontrol.cron.xxljob;

import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.riskcontrol.common.annotation.LogUUID;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.enums.RiskFilterStatusEnum;
import com.riskcontrol.common.enums.RiskFilterTypeEnum;
import com.riskcontrol.cron.entity.RiskFilterLog;
import com.riskcontrol.cron.mapper.RiskFilterLogMapper;
import com.riskcontrol.cron.service.WithdrawService;
import com.xxl.job.core.context.XxlJobHelper;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/8/15 15:10
 */
@Component
@Slf4j
public class WithdrawToMqRetryJob {
    @Autowired
    private RiskFilterLogMapper riskFilterLogMapper;
    @Resource
    private WithdrawService withdrawService;
    /**
     * 定时抓取定时抓取拦截日志中被拦截的取款记录，重试
     */
    @XxlJob("withdrawToMqRetryJob")
    @LogUUID
    public void withdrawToMqRetryJob() {
        log.info("WithdrawToKafkaRetryJob start");
        String param = XxlJobHelper.getJobParam();
        int beforeMinute = 5;
        if(StringUtils.isNotBlank(param)){
            beforeMinute = Integer.getInteger(param);
        }
        Date date = new Date();
        Date endDate = DateUtils.addMinutes(date, -beforeMinute);//5分钟前
        Date beginDate = DateUtils.addHours(date, -2);//1分钟前
        LambdaQueryWrapper<RiskFilterLog> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(RiskFilterLog::getFilterType, RiskFilterTypeEnum.WITHDRAW_RISK.getCode());
        queryWrapper.eq(RiskFilterLog::getRetryNum,0);
        queryWrapper.ne(RiskFilterLog::getStatus, RiskFilterStatusEnum.RELEASED.getCode());
        queryWrapper.ge(RiskFilterLog::getCreateTime, DateUtil.formatDateTime(beginDate));
        queryWrapper.le(RiskFilterLog::getCreateTime, DateUtil.formatDateTime(endDate));
        queryWrapper.eq(RiskFilterLog::getNotifyStatus,0);
        List<RiskFilterLog> riskFilterLogs = riskFilterLogMapper.selectList(queryWrapper);
        if(CollectionUtils.isEmpty(riskFilterLogs)){
            return;
        }
        riskFilterLogs.forEach(withdraw->{
            log.info("WithdrawToKafkaRetryJob 循环遍历需重审的数据:{}", JSONObject.toJSONString(withdraw));
            try {
                    withdrawService.sendWithToRiskMq(withdraw.getRequestId(), Constant.C66_PRODUCT_ID);
                    RiskFilterLog update = new RiskFilterLog();
                    update.setNotifyStatus(1);
                    update.setId(withdraw.getId());
                    riskFilterLogMapper.updateById(update);
            } catch (Exception e) {
                log.error("WithdrawToKafkaRetryJob error", e);
            }
        });
        log.info("WithdrawToKafkaRetryJob end");
    }
}
