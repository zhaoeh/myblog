package com.riskcontrol.cron.config;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.core.env.EnumerablePropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * 产品常量配置类
 *
 * @program: riskcontrol-cron
 * @description: product constants config
 * @author: Erhu.Zhao
 * @create: 2023-10-11 17:13
 **/
@Component
@RefreshScope // 动态刷新
public class BusinessConfig {

    private final Map<String, String> configs = new HashMap<>();


    public BusinessConfig(Environment environment) {
        ((AbstractEnvironment) environment).getPropertySources().stream().forEach(propertySource -> {
            if (EnumerablePropertySource.class.isInstance(propertySource)) {
                initConfigs(environment, (EnumerablePropertySource) propertySource);
            }
        });

    }

    /**
     * 初始化configs
     *
     * @param environment    environment
     * @param propertySource propertySource
     */
    private void initConfigs(Environment environment, EnumerablePropertySource propertySource) {
        Arrays.stream(propertySource.getPropertyNames()).forEach(propertyName -> {
            if (StringUtils.isNotBlank(propertyName)) {
                configs.put(propertyName, environment.getProperty(propertyName));
            }
        });
    }

    /**
     * 根据key从环境中获取k-v集合（这个key可能不是全量key）
     *
     * @param defectiveKey defective key
     * @return key对应的属性集
     */
    public Map<String, String> getPropertiesByKey(String defectiveKey) {
        Map<String, String> targetProperties = new HashMap<>(12);
        if (MapUtils.isNotEmpty(configs) && StringUtils.isNotBlank(defectiveKey)) {
            configs.forEach((k, v) -> {
                if (StringUtils.isNotBlank(k) && k.indexOf(defectiveKey) > -1) {
                    targetProperties.put(k, v);
                }
            });
        }
        return targetProperties;
    }

    /**
     * 根据完整的key从环境中获取value值
     *
     * @param wholeKey 完整的key
     * @return 对应的value
     */
    public String getPropertyByKey(String wholeKey) {
        String value = "";
        if (MapUtils.isNotEmpty(configs) && StringUtils.isNotBlank(wholeKey)) {
            value = configs.getOrDefault(wholeKey, "");
        }
        return Optional.ofNullable(value).orElse("");
    }
}
