package com.riskcontrol.cron.service.impl;

import com.cn.schema.request.WSDispatchRecord;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.cron.mapper.DispatchRecordDao;
import com.riskcontrol.cron.service.DispatchRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DispatchRecordServiceImpl implements DispatchRecordService {

    @Autowired
    private DispatchRecordDao dispatchRecordDao;

    @Override
    public int create(WSDispatchRecord bean) throws BusinessException {
        return dispatchRecordDao.insert(bean);
    }

    @Override
    public int create(List<WSDispatchRecord> beans) throws BusinessException {
        return dispatchRecordDao.batchCreate(beans);
    }

    @Override
    public int confirm(String orderStyle, String loginName, List<String> serNumber) {
        int count = 0;
        for (String ser : serNumber) {
            count = dispatchRecordDao.modifyStatus(orderStyle,loginName,ser) + count;
        }
        return count;
    }

    @Override
    public int getPendingRequest(String loginName){
        return  dispatchRecordDao.queryPendingCount(loginName) ;
    }
}
