package com.riskcontrol.cron;


import com.digiplus.auto.transfer.annotation.EnableAutoSyncMqQueues;
import com.digiplus.common.annotation.EnableDefaultKafkaConsumerConfig;
import com.digiplus.common.annotation.EnableDefaultKafkaProducerConfig;
import com.riskcontrol.common.annotation.EnableRiskCommon;
import lombok.extern.slf4j.Slf4j;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableScheduling;

@Slf4j
@SpringBootApplication(scanBasePackages = {"com.riskcontrol.cron.*","com.riskcontrol.common.*"},
    exclude = {DataSourceAutoConfiguration.class})
@EnableFeignClients(basePackages = {"com.riskcontrol.*.client"})
//@EnableSwagger2
@MapperScan(basePackages ="com.riskcontrol.cron.mapper")
@EnableScheduling
@EnableRiskCommon
@EnableConfigurationProperties
@EnableAutoSyncMqQueues
@EnableDefaultKafkaProducerConfig
@EnableDefaultKafkaConsumerConfig
public class RiskcontrolCronApplication {

    public static void main(String[] args)  {

        ConfigurableApplicationContext context = SpringApplication.run(RiskcontrolCronApplication.class, args);

        Environment environment = context.getBean(Environment.class);
        String port = environment.getProperty("local.server.port");
        log.info("[riskcontrol-cron服务启动！ port:{} ]",port);
    }
}