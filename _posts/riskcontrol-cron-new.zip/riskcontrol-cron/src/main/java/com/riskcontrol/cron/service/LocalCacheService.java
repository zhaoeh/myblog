package com.riskcontrol.cron.service;

/**
 * local cache service
 *
 * @program: riskcontrol-cron
 * @description: 本地缓存服务接口
 * @author: Erhu.Zhao
 * @create: 2023-10-19 15:22
 **/

public interface LocalCacheService {

    /**
     * 根据key获取local cache中的数据
     *
     * @param cacheKey cache key
     * @return cache data
     */
    Object loadLocalCacheInfo(String cacheKey);
}
