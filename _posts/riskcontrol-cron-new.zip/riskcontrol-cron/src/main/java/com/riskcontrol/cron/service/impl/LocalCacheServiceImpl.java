package com.riskcontrol.cron.service.impl;

import com.riskcontrol.common.cache.LocalCacheHelper;
import com.riskcontrol.cron.service.LocalCacheService;
import org.springframework.stereotype.Service;

/**
 * local cache service impl
 *
 * @program: riskcontrol-cron
 * @description: 本地缓存服务实现
 * @author: Erhu.Zhao
 * @create: 2023-10-19 15:39
 **/
@Service
public class LocalCacheServiceImpl implements LocalCacheService {
    @Override
    public Object loadLocalCacheInfo(String cacheKey) {
        return LocalCacheHelper.getData(cacheKey);
    }
}
