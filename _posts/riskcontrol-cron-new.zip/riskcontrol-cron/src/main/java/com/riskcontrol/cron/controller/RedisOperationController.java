package com.riskcontrol.cron.controller;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.cron.service.RedisOperationService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;

/**
 * @program: riskcontrol-cron
 * @description: 基于redis常见操作的控制器
 * @author: Erhu.Zhao
 * @create: 2023-11-17 11:13
 */
@RestController
@RequestMapping("/redis/operation")
@Api("Resis缓存同步接口")
@Slf4j
public class RedisOperationController {

    @Autowired
    private RedisOperationService redisOperationService;

    /**
     * 操作redis
     *
     * @param request 操作redis请求
     * @return 操作redis响应
     */
    @RequestMapping(method = RequestMethod.POST, value = "/doOperationForRedis")
    @ResponseBody
    public Response<JSONObject> doOperationForRedis(@RequestPayload @RequestBody JSONObject request) {
        return Response.body(redisOperationService.processRedisAction(request));
    }
}