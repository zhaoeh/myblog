package com.riskcontrol.cron.controller;

import cn.hutool.core.util.ReUtil;
import com.riskcontrol.common.entity.request.PbcCrawlerUpdateStatusReq;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.cron.entity.TPbcCrawlerResultNew;
import com.riskcontrol.cron.service.PbcCrawlerResultNewService;
import com.riskcontrol.cron.xxljob.ApprovePbcJob;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;
import java.util.List;

/***
 *  @program: riskcontrol-office
 ** @description: PBC爬虫Controller
 ** @author: sanji
 ** @create: 2024-10-30 17:03
 **/
@RestController
@RequestMapping("/pbcCrawler")
@Tag(name = "PBC数据")
public class PbcCrawlerController {

    @Autowired
    private ApprovePbcJob approvePbcJob;

    @Autowired
    private PbcCrawlerResultNewService pbcCrawlerResultNewService;

    /**
     * 根据全名查询pagcor数据，并写入pbc爬虫数据表.
     * 执行逆向 匹配新老kyc 命中黑名单逻辑.
     *
     * @param fullName
     * @return
     */
    @PostMapping(value = "/pullPagcorDataToDb/byFullName")
    @ResponseBody
    public Response<List<TPbcCrawlerResultNew>> pullPagcorDataToDbByFullName(@RequestParam @Validated @NotBlank String fullName, @RequestParam String currentUsername) {
        //todo office调用 根据名称查询pagcor数据，并写入pbc爬虫数据表,执行逆向 匹配新老kyc 命中黑名单逻辑 人工添加入参 LookUp=X，SelectedDB=4；
        var pbcCrawlerDataList = approvePbcJob.pullPagcorDataToDbByFullName(fullName, currentUsername,"X","4");
        // 精确匹配全名是否相同
//        pbcCrawlerDataList = pbcCrawlerDataList.stream().filter((s) -> {
//            var fullNameOne = StringUtils.join(StringUtils.split(ReUtil.replaceAll(fullName, "\\s+", " "), " "), " ");
//            var fullNameTwo = StringUtils.join(StringUtils.split(ReUtil.replaceAll(StringUtils.join(s.getFirstName(), s.getMiddleName(), s.getLastName()," "), "\\s+", " "), " "), " ");
//            return fullNameOne.toLowerCase().equals(fullNameTwo.toLowerCase());
//        }).toList();
        if (pbcCrawlerDataList.isEmpty()) {
            throw new BusinessException("Name does not exist, failed to add", ResultEnum.BAD_REQUEST.getCode());
        }
        return Response.body(pbcCrawlerDataList);
    }

    @PostMapping("updateStatus")
    @Operation(tags ="PBC数据", summary = "解除/禁用PBC接口")
    public Response<Boolean> updateStatus(@Validated @RequestBody PbcCrawlerUpdateStatusReq req) {
        return Response.body(pbcCrawlerResultNewService.updateStatus(req));
    }

}
