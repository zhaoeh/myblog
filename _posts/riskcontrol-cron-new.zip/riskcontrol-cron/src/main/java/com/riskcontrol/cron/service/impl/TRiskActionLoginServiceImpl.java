package com.riskcontrol.cron.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.riskcontrol.common.entity.pojo.*;
import com.riskcontrol.common.entity.request.device.LoginCheckRequest;
import com.riskcontrol.common.entity.request.device.RegisterSaveRequest;
import com.riskcontrol.common.entity.response.device.LoginCheckDetailResponse;
import com.riskcontrol.common.entity.response.device.LoginCheckResponse;
import com.riskcontrol.common.enums.*;
import com.riskcontrol.cron.datasource.DBSourceCheck;
import com.riskcontrol.cron.datasource.DataSourceType;
import com.riskcontrol.cron.kafka.KafkaTopic;
import com.riskcontrol.cron.mapper.*;
import com.riskcontrol.cron.po.KafkaDeviceInfo;
import com.riskcontrol.cron.po.RiskDeviceTenantCacheInfo;
import com.riskcontrol.cron.service.TRiskActionLoginService;
import com.riskcontrol.cron.utils.KafkaProductUtils;
import com.riskcontrol.cron.utils.RedisUtil;
import lombok.SneakyThrows;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.lang3.time.FastDateFormat;
import org.jinq.orm.stream.JinqStream;
import org.jinq.tuples.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.util.*;
import java.util.stream.IntStream;

import static com.riskcontrol.common.constants.Constant.RISK_DEVICE_KEY;
import static com.riskcontrol.common.constants.Constant.RISK_REGISTER_LOGIN_NAME_KEY;
import static com.riskcontrol.common.constants.CronConstant.MODIFY_DEFAULT_SYSTEM;
import static com.riskcontrol.cron.utils.DateUtil.FMT_YYYY_MM_DD;
import static eu.ciechanowiec.sneakyfun.SneakyFunction.sneaky;

@Service
public class TRiskActionLoginServiceImpl extends ServiceImpl<TRiskActionLoginMapper, TRiskActionLogin> implements TRiskActionLoginService {

    @Autowired
    private TRiskActionAllowMapper riskActionAllowMapper;

    @Autowired
    private TRiskActionRulesMapper riskActionRulesMapper;

    @Autowired
    private KafkaProductUtils kafkaProductUtils;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private TRiskActionLoginSumMapper riskActionLoginSumMapper;

    @Autowired
    private TRiskActionRegistrationSumMapper riskActionRegistrationSumMapper;

    @Autowired
    private TRiskActionRegistrationMapper riskActionRegistrationMapper;

    @Override
    @SneakyThrows
    @DBSourceCheck(DataSourceType.SLAVE)
    public LoginCheckResponse loginCheck(LoginCheckRequest loginCheckRequest) {
        // 初始化LoginCheckResponse和KafkaDeviceInfo
        var loginCheckResponse = new LoginCheckResponse()
                .setIsBlack(false)
                .setDetails(new LoginCheckDetailResponse()
                        .setIsDeviceBlack(false)
                        .setIsIpBlack(false)
                )
                .setDeviceFingerprint(loginCheckRequest.getDeviceFingerprint());
        var kafkaDeviceInfo = new KafkaDeviceInfo()
                .setDeviceInfo(loginCheckRequest.getDeviceInfo())
                .setLoginCheckRequest(loginCheckRequest);

        // 检查设备指纹黑名单
        if (!loginCheckResponse.getIsBlack()) {
            var isDeviceBlack = isDeviceBlack(loginCheckRequest.getDeviceFingerprint(), loginCheckRequest.getLoginIp(), loginCheckRequest.getLoginName(), loginCheckRequest.getTenant(), RiskActionTypeEnum.LOGIN);
            if (isDeviceBlack) {
                loginCheckResponse.getDetails().setIsDeviceBlack(true);
                loginCheckResponse.setIsBlack(true);

                kafkaDeviceInfo.setInterceptTypeOfLoginCheckRequest(RiskActionInterceptTypeEnum.DEVICE_BLOCK.getId());
            }
        }

        // 检查ip黑名单
        if (!loginCheckResponse.getIsBlack()) {
            var isIpBlack = isIpBlack(loginCheckRequest.getDeviceFingerprint(), loginCheckRequest.getLoginIp(), loginCheckRequest.getLoginName(), loginCheckRequest.getTenant(), RiskActionTypeEnum.LOGIN);
            if (isIpBlack) {
                loginCheckResponse.getDetails().setIsIpBlack(true);
                loginCheckResponse.setIsBlack(true);

                kafkaDeviceInfo.setInterceptTypeOfLoginCheckRequest(RiskActionInterceptTypeEnum.IP_BLOCK.getId());
            }
        }

        // 检查设备指纹和ip的组合黑名单
        if (!loginCheckResponse.getIsBlack()) {
            var isDeviceAndIpBlack = isDeviceAndIpBlack(loginCheckRequest.getDeviceFingerprint(), loginCheckRequest.getLoginIp(), loginCheckRequest.getLoginName(), loginCheckRequest.getTenant(), RiskActionTypeEnum.LOGIN);
            if (isDeviceAndIpBlack) {
                loginCheckResponse.getDetails()
                        .setIsDeviceBlack(true)
                        .setIsIpBlack(true);
                loginCheckResponse.setIsBlack(true);

                kafkaDeviceInfo.setInterceptTypeOfLoginCheckRequest(RiskActionInterceptTypeEnum.IP_DEVICE_BLOCK.getId());
            }
        }

        // 设置登陆明细的拦截类型
        if (!loginCheckResponse.getIsBlack() && (StringUtils.isBlank(loginCheckRequest.getLoginIp()) || StringUtils.isBlank(loginCheckRequest.getDeviceFingerprint()))) {
            kafkaDeviceInfo.setInterceptTypeOfLoginCheckRequest(RiskActionInterceptTypeEnum.DEVICE_ABNORMAL_THROUGH.getId());
        } else if (!loginCheckResponse.getIsBlack()) {
            kafkaDeviceInfo.setInterceptTypeOfLoginCheckRequest(RiskActionInterceptTypeEnum.PASS_THROUGH.getId());
        }

        // push设备信息, 登陆风控明细到kafka
        kafkaProductUtils.pushKafkaMsg(KafkaTopic.DEVICE_KYC_TOPIC_SELF, this.objectMapper.writeValueAsString(kafkaDeviceInfo));

        return loginCheckResponse;
    }

    @Override
    @DBSourceCheck(DataSourceType.SLAVE)
    public boolean isDeviceBlack(String deviceFingerprint, String ipAddress, String loginName, String tenant, RiskActionTypeEnum ruleAction) {
        if (StringUtils.isBlank(deviceFingerprint) || StringUtils.isBlank(ipAddress)) {
            return false;
        }

        var riskActionAllowList = this.riskActionAllowMapper.selectList(new LambdaQueryWrapper<TRiskActionAllow>()
                .eq(TRiskActionAllow::getAllowRecord, deviceFingerprint)
                .eq(TRiskActionAllow::getIsEnable, RiskActionEnableEnum.ENABLE.getId())
                .eq(TRiskActionAllow::getAllowType, RiskActionAllowTypeEnum.DEVICE.getId()));
        // 是否是设备指纹黑名单
        if (JinqStream.from(riskActionAllowList).where(s -> s.getAllowRule() == RiskActionAllowRuleEnum.BLACKLIST.getId()).exists()) {
            return true;
        }
        // 是否是设备指纹白名单
        if (JinqStream.from(riskActionAllowList).where(s -> s.getAllowRule() == RiskActionAllowRuleEnum.WHITELIST.getId()).exists()) {
            return false;
        }

        // 设备指纹风控规则检查
        return isDeviceOrIpBlackForRuleList(deviceFingerprint, "", loginName, tenant, ruleAction, RiskActionRuleTypeEnum.DEVICE);
    }

    @Override
    @DBSourceCheck(DataSourceType.SLAVE)
    public boolean isIpBlack(String deviceFingerprint, String ipAddress, String loginName, String tenant, RiskActionTypeEnum ruleAction) {
        if (StringUtils.isBlank(deviceFingerprint) || StringUtils.isBlank(ipAddress)) {
            return false;
        }

        var riskActionAllowList = this.riskActionAllowMapper.selectList(new LambdaQueryWrapper<TRiskActionAllow>()
                .eq(TRiskActionAllow::getAllowRecord, ipAddress)
                .eq(TRiskActionAllow::getIsEnable, RiskActionEnableEnum.ENABLE.getId())
                .eq(TRiskActionAllow::getAllowType, RiskActionAllowTypeEnum.IP.getId()));
        // 是否是IP黑名单
        if (JinqStream.from(riskActionAllowList).where(s -> s.getAllowRule() == RiskActionAllowRuleEnum.BLACKLIST.getId()).exists()) {
            return true;
        }
        // 是否是IP白名单
        if (JinqStream.from(riskActionAllowList).where(s -> s.getAllowRule() == RiskActionAllowRuleEnum.WHITELIST.getId()).exists()) {
            return false;
        }

        // ip风控规则检查
        return isDeviceOrIpBlackForRuleList("", ipAddress, loginName, tenant, ruleAction, RiskActionRuleTypeEnum.IP);
    }

    @Override
    @DBSourceCheck(DataSourceType.SLAVE)
    public boolean isDeviceAndIpBlack(String deviceFingerprint, String ipAddress, String loginName, String tenant, RiskActionTypeEnum ruleAction) {
        if (StringUtils.isBlank(deviceFingerprint) || StringUtils.isBlank(ipAddress)) {
            return false;
        }

        var riskActionAllowList = this.riskActionAllowMapper.selectList(new LambdaQueryWrapper<TRiskActionAllow>()
                .in(TRiskActionAllow::getAllowRecord, List.of(deviceFingerprint, ipAddress))
                .eq(TRiskActionAllow::getIsEnable, RiskActionEnableEnum.ENABLE.getId()));

        // 是否是设备指纹黑名单或IP黑名单
        if (JinqStream.from(riskActionAllowList).where(s -> s.getAllowRule() == RiskActionAllowRuleEnum.BLACKLIST.getId())
                .where(s -> s.getAllowType() == RiskActionAllowTypeEnum.DEVICE.getId())
                .where(s -> s.getAllowRecord().equals(deviceFingerprint))
                .exists() ||
                JinqStream.from(riskActionAllowList).where(s -> s.getAllowRule() == RiskActionAllowRuleEnum.BLACKLIST.getId())
                        .where(s -> s.getAllowType() == RiskActionAllowTypeEnum.IP.getId())
                        .where(s -> s.getAllowRecord().equals(ipAddress))
                        .exists()) {
            return true;
        }

        // 是否是设备指纹白名单且IP白名单
        if (JinqStream.from(riskActionAllowList).where(s -> s.getAllowRule() == RiskActionAllowRuleEnum.WHITELIST.getId())
                .where(s -> s.getAllowType() == RiskActionAllowTypeEnum.DEVICE.getId())
                .where(s -> s.getAllowRecord().equals(deviceFingerprint))
                .exists() &&
                JinqStream.from(riskActionAllowList).where(s -> s.getAllowRule() == RiskActionAllowRuleEnum.WHITELIST.getId())
                        .where(s -> s.getAllowType() == RiskActionAllowTypeEnum.IP.getId())
                        .where(s -> s.getAllowRecord().equals(ipAddress))
                        .exists()) {
            return false;
        }

        // ip+设备指纹组合风控规则检查
        return isDeviceOrIpBlackForRuleList(deviceFingerprint, ipAddress, loginName, tenant, ruleAction, RiskActionRuleTypeEnum.COMPOSE_IP_AND_DEVICE);
    }

    /**
     * 保存登陆风控明细
     */
    @Override
    @Transactional(rollbackFor = Throwable.class)
    public void saveRiskActionLogin(LoginCheckRequest loginCheckRequest, int interceptType) {
        var riskActionLogin = new TRiskActionLogin();
        riskActionLogin.setDeviceFingerprintToken(Optional.ofNullable(loginCheckRequest.getDeviceFingerprintToken()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionLogin.setDeviceFingerprint(Optional.ofNullable(loginCheckRequest.getDeviceFingerprint()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionLogin.setLoginIp(Optional.ofNullable(loginCheckRequest.getLoginIp()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionLogin.setProductId(Optional.ofNullable(loginCheckRequest.getProductId()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionLogin.setLoginName(Optional.ofNullable(loginCheckRequest.getLoginName()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionLogin.setTenant(Optional.ofNullable(loginCheckRequest.getTenant()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionLogin.setChannel(Optional.ofNullable(loginCheckRequest.getChannel()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionLogin.setDomainName(Optional.ofNullable(loginCheckRequest.getDomainName()).filter(StringUtils::isNotBlank).orElse(""));
        riskActionLogin.setCreateBy(MODIFY_DEFAULT_SYSTEM);
        riskActionLogin.setUpdateBy(MODIFY_DEFAULT_SYSTEM);
        setRegisterIpAndRegistDeviceFingerprint(riskActionLogin);
        this.save(riskActionLogin);

        // 登陆校验通过, 写登陆汇总表
        if (interceptType == RiskActionInterceptTypeEnum.PASS_THROUGH.getId()) {
            this.writeLoginNameToRedisAndDatabase(riskActionLogin.getLoginIp(), riskActionLogin.getDeviceFingerprint(), FastDateFormat.getInstance(FMT_YYYY_MM_DD).format(new Date()), riskActionLogin.getLoginName(), riskActionLogin.getTenant(), RiskActionTypeEnum.LOGIN);
        }
    }

    /**
     * 设置注册ip和注册设备指纹
     *
     * @param riskActionLogin
     */
    @SneakyThrows
    private void setRegisterIpAndRegistDeviceFingerprint(TRiskActionLogin riskActionLogin) {
        riskActionLogin.setRegisterIp("");
        riskActionLogin.setRegistDeviceFingerprint("");
        var registerSaveRequestJsonString = redisUtil.get(String.format(RISK_REGISTER_LOGIN_NAME_KEY, riskActionLogin.getLoginName()), String.class);
        if (StringUtils.isNotBlank(registerSaveRequestJsonString)) {
            // 从redis中读取ip和设备指纹缓存
            var registerSaveRequest = this.objectMapper.readValue(registerSaveRequestJsonString, RegisterSaveRequest.class);
            if (StringUtils.isNotBlank(registerSaveRequest.getRegisterIp())) {
                riskActionLogin.setRegisterIp(registerSaveRequest.getRegisterIp());
            }
            if (StringUtils.isNotBlank(registerSaveRequest.getDeviceFingerprint())) {
                riskActionLogin.setRegistDeviceFingerprint(registerSaveRequest.getDeviceFingerprint());
            }
        } else {
            // 从数据库中读取ip和设备指纹缓存
            var page = new Page<TRiskActionRegistration>(1, 1);
            page.setOrders(List.of(new OrderItem("create_date", true)));
            var riskActionRegistrationList = this.riskActionRegistrationMapper.selectPage(page, new LambdaQueryWrapper<TRiskActionRegistration>()
                    .eq(TRiskActionRegistration::getLoginName, riskActionLogin.getLoginName())
            ).getRecords();
            if (!riskActionRegistrationList.isEmpty()) {
                var riskActionRegistration = JinqStream.from(riskActionRegistrationList).findFirst().get();
                if (StringUtils.isNotBlank(riskActionRegistration.getRegisterIp())) {
                    riskActionLogin.setRegisterIp(riskActionRegistration.getRegisterIp());
                }
                if (StringUtils.isNotBlank(riskActionRegistration.getDeviceFingerprint())) {
                    riskActionLogin.setRegistDeviceFingerprint(riskActionRegistration.getDeviceFingerprint());
                }
            }
        }
    }

    /**
     * 保存登陆和注册用户名到汇总表和redis
     */
    @Override
    @SneakyThrows
    public void writeLoginNameToRedisAndDatabase(String ipAddress, String deviceFingerprint, String dateAt, String loginName, String tenent, RiskActionTypeEnum ruleAction) {
        if (StringUtils.isBlank(ipAddress) || StringUtils.isBlank(deviceFingerprint) || StringUtils.isBlank(dateAt) || StringUtils.isBlank(loginName) || StringUtils.isBlank(tenent)) {
            return;
        }

        {
            // 写入(ip+设备指纹)登陆/注册汇总到redis
            var riskDeviceTenantCacheInfoList = getLoginNamesFromRedis(ipAddress, deviceFingerprint, dateAt);
            // loginName在redis缓存中不存在, 则保存
            if (!riskDeviceTenantCacheInfoList.stream().anyMatch(s -> s.getLoginNameList().stream().anyMatch(m -> m.equals(loginName) && s.getTenant().equals(tenent)))) {
                riskDeviceTenantCacheInfoList.add(new RiskDeviceTenantCacheInfo()
                        .setActionType(ruleAction.getId())
                        .setTenant(tenent)
                        .setLoginNameList(List.of(loginName))
                );
                redisUtil.set(getRedisKeyOfRiskDeviceTenantCacheInfo(ipAddress, deviceFingerprint, dateAt), this.objectMapper.writeValueAsString(JinqStream.from(riskDeviceTenantCacheInfoList)
                        .group(s -> new Pair<>(s.getActionType(), s.getTenant()), (s, t) -> new RiskDeviceTenantCacheInfo()
                                .setActionType(s.getOne())
                                .setTenant(s.getTwo())
                                .setLoginNameList(t.selectAllList(m -> m.getLoginNameList()).distinct().toList())
                        ).toList()), Duration.ofDays(10).toSeconds());
            }
        }

        {
            // 写入(设备指纹)登陆/注册汇总到redis
            var riskDeviceTenantCacheInfoList = getLoginNamesFromRedis("", deviceFingerprint, dateAt);
            // loginName在redis缓存中不存在, 则保存
            if (!riskDeviceTenantCacheInfoList.stream().anyMatch(s -> s.getLoginNameList().stream().anyMatch(m -> m.equals(loginName) && s.getTenant().equals(tenent)))) {
                riskDeviceTenantCacheInfoList.add(new RiskDeviceTenantCacheInfo()
                        .setActionType(ruleAction.getId())
                        .setTenant(tenent)
                        .setLoginNameList(List.of(loginName))
                );
                redisUtil.set(getRedisKeyOfRiskDeviceTenantCacheInfo("", deviceFingerprint, dateAt), this.objectMapper.writeValueAsString(JinqStream.from(riskDeviceTenantCacheInfoList)
                        .group(s -> new Pair<>(s.getActionType(), s.getTenant()), (s, t) -> new RiskDeviceTenantCacheInfo()
                                .setActionType(s.getOne())
                                .setTenant(s.getTwo())
                                .setLoginNameList(t.selectAllList(m -> m.getLoginNameList()).distinct().toList())
                        ).toList()), Duration.ofDays(10).toSeconds());
            }
        }

        {
            // 写入(ip)登陆/注册汇总到redis
            var riskDeviceTenantCacheInfoList = getLoginNamesFromRedis(ipAddress, "", dateAt);
            // loginName在redis缓存中不存在, 则保存
            if (!riskDeviceTenantCacheInfoList.stream().anyMatch(s -> s.getLoginNameList().stream().anyMatch(m -> m.equals(loginName) && s.getTenant().equals(tenent)))) {
                riskDeviceTenantCacheInfoList.add(new RiskDeviceTenantCacheInfo()
                        .setActionType(ruleAction.getId())
                        .setTenant(tenent)
                        .setLoginNameList(List.of(loginName))
                );
                redisUtil.set(getRedisKeyOfRiskDeviceTenantCacheInfo(ipAddress, "", dateAt), this.objectMapper.writeValueAsString(JinqStream.from(riskDeviceTenantCacheInfoList)
                        .group(s -> new Pair<>(s.getActionType(), s.getTenant()), (s, t) -> new RiskDeviceTenantCacheInfo()
                                .setActionType(s.getOne())
                                .setTenant(s.getTwo())
                                .setLoginNameList(t.selectAllList(m -> m.getLoginNameList()).distinct().toList())
                        ).toList()), Duration.ofDays(10).toSeconds());
            }
        }

        if (ruleAction == RiskActionTypeEnum.LOGIN) {
            // 写入登陆汇总到database
            var riskActionLoginSumList = riskActionLoginSumMapper.selectList(new LambdaQueryWrapper<TRiskActionLoginSum>()
                    .eq(TRiskActionLoginSum::getDateAt, dateAt)
                    .eq(TRiskActionLoginSum::getDeviceFingerprint, deviceFingerprint)
                    .eq(TRiskActionLoginSum::getIpAddress, ipAddress));
            var riskDeviceTenantCacheInfoList = new ArrayList<RiskDeviceTenantCacheInfo>();
            riskDeviceTenantCacheInfoList.addAll(riskActionLoginSumList
                    .stream()
                    .filter(s -> StringUtils.isNotBlank(s.getLoginNames()))
                    .map(sneaky(s -> {
                        try {
                            return this.objectMapper.readValue(s.getLoginNames(), new TypeReference<HashMap<String, String>>() {
                            });
                        } catch (Exception e) {
                            return new HashMap<String, String>();
                        }
                    }))
                    .map(s -> s.entrySet()
                            .stream()
                            .map(m -> new RiskDeviceTenantCacheInfo()
                                    .setActionType(RiskActionTypeEnum.LOGIN.getId())
                                    .setTenant(m.getKey())
                                    .setLoginNameList(Arrays.asList(StringUtils.split(m.getValue(), ",")))
                            ).toList()
                    )
                    .flatMap(s -> s.stream())
                    .toList());
            // loginName在数据库不存在, 则保存
            if (!riskDeviceTenantCacheInfoList.stream().anyMatch(s -> s.getLoginNameList().stream().anyMatch(m -> m.equals(loginName) && s.getTenant().equals(tenent)))) {
                riskDeviceTenantCacheInfoList.add(new RiskDeviceTenantCacheInfo()
                        .setActionType(ruleAction.getId())
                        .setTenant(tenent)
                        .setLoginNameList(List.of(loginName))
                );
                var loginNameMap = Optional.of(JinqStream.from(riskDeviceTenantCacheInfoList)
                                .group(s -> s.getTenant(), (s, t) -> t.selectAllList(m -> m.getLoginNameList())
                                        .distinct()
                                        .toList()
                                )
                                .select(s -> new RiskDeviceTenantCacheInfo()
                                        .setTenant(s.getOne())
                                        .setLoginNameList(s.getTwo())
                                )
                                .toList())
                        .map(s -> {
                            var map = new HashMap<String, String>();
                            for (var riskDeviceTenantCacheInfo : s) {
                                map.put(riskDeviceTenantCacheInfo.getTenant(), StringUtils.join(riskDeviceTenantCacheInfo.getLoginNameList(), ","));
                            }
                            return map;
                        })
                        .get();
                var riskActionLoginSum = JinqStream.from(riskActionLoginSumList)
                        .sortedBy(s -> s.getCreateDate())
                        .findFirst()
                        .orElse(null);
                if (riskActionLoginSum == null) {
                    riskActionLoginSum = new TRiskActionLoginSum();
                    riskActionLoginSum.setLoginNames(this.objectMapper.writeValueAsString(loginNameMap));
                    riskActionLoginSum.setDeviceFingerprint(deviceFingerprint);
                    riskActionLoginSum.setIpAddress(ipAddress);
                    riskActionLoginSum.setDateAt(dateAt);
                    this.riskActionLoginSumMapper.insert(riskActionLoginSum);
                } else {
                    riskActionLoginSum.setLoginNames(this.objectMapper.writeValueAsString(loginNameMap));
                    this.riskActionLoginSumMapper.updateById(riskActionLoginSum);
                }
            }
        } else if (ruleAction == RiskActionTypeEnum.REGISTER) {
            // 写入注册汇总到database
            var riskActionRegistrationSumList = riskActionRegistrationSumMapper.selectList(new LambdaQueryWrapper<TRiskActionRegistrationSum>()
                    .eq(TRiskActionRegistrationSum::getDateAt, dateAt)
                    .eq(StringUtils.isNotBlank(deviceFingerprint), TRiskActionRegistrationSum::getDeviceFingerprint, deviceFingerprint)
                    .eq(StringUtils.isNotBlank(ipAddress), TRiskActionRegistrationSum::getIpAddress, ipAddress));
            var riskDeviceTenantCacheInfoList = new ArrayList<RiskDeviceTenantCacheInfo>();
            riskDeviceTenantCacheInfoList.addAll(riskActionRegistrationSumList
                    .stream()
                    .filter(s -> StringUtils.isNotBlank(s.getLoginNames()))
                    .map(sneaky(s -> {
                        try {
                            return this.objectMapper.readValue(s.getLoginNames(), new TypeReference<HashMap<String, String>>() {
                            });
                        } catch (Exception e) {
                            return new HashMap<String, String>();
                        }
                    }))
                    .map(s -> s.entrySet()
                            .stream()
                            .map(m -> new RiskDeviceTenantCacheInfo()
                                    .setActionType(RiskActionTypeEnum.REGISTER.getId())
                                    .setTenant(m.getKey())
                                    .setLoginNameList(Arrays.asList(StringUtils.split(m.getValue(), ",")))
                            ).toList()
                    )
                    .flatMap(s -> s.stream())
                    .toList());
            // loginName在数据库不存在, 则保存
            if (!riskDeviceTenantCacheInfoList.stream().anyMatch(s -> s.getLoginNameList().stream().anyMatch(m -> m.equals(loginName) && s.getTenant().equals(tenent)))) {
                riskDeviceTenantCacheInfoList.add(new RiskDeviceTenantCacheInfo()
                        .setActionType(ruleAction.getId())
                        .setTenant(tenent)
                        .setLoginNameList(List.of(loginName))
                );
                var loginNameMap = Optional.of(JinqStream.from(riskDeviceTenantCacheInfoList)
                                .group(s -> s.getTenant(), (s, t) -> t.selectAllList(m -> m.getLoginNameList())
                                        .distinct()
                                        .toList()
                                )
                                .select(s -> new RiskDeviceTenantCacheInfo()
                                        .setTenant(s.getOne())
                                        .setLoginNameList(s.getTwo())
                                )
                                .toList())
                        .map(s -> {
                            var map = new HashMap<String, String>();
                            for (var riskDeviceTenantCacheInfo : s) {
                                map.put(riskDeviceTenantCacheInfo.getTenant(), StringUtils.join(riskDeviceTenantCacheInfo.getLoginNameList(), ","));
                            }
                            return map;
                        })
                        .get();

                var riskActionRegistrationSum = JinqStream.from(riskActionRegistrationSumList)
                        .sortedBy(s -> s.getCreateDate())
                        .findFirst()
                        .orElse(null);
                if (riskActionRegistrationSum == null) {
                    riskActionRegistrationSum = new TRiskActionRegistrationSum();
                    riskActionRegistrationSum.setLoginNames(this.objectMapper.writeValueAsString(loginNameMap));
                    riskActionRegistrationSum.setDeviceFingerprint(deviceFingerprint);
                    riskActionRegistrationSum.setIpAddress(ipAddress);
                    riskActionRegistrationSum.setDateAt(dateAt);
                    this.riskActionRegistrationSumMapper.insert(riskActionRegistrationSum);
                } else {
                    riskActionRegistrationSum.setLoginNames(this.objectMapper.writeValueAsString(loginNameMap));
                    this.riskActionRegistrationSumMapper.updateById(riskActionRegistrationSum);
                }
            }
        }
    }

    private boolean isDeviceOrIpBlackForRuleList(String deviceFingerprint, String ipAddress, String loginName, String tenant, RiskActionTypeEnum ruleAction, RiskActionRuleTypeEnum ruleType) {
        var ruleList = riskActionRulesMapper.selectList(new LambdaQueryWrapper<TRiskActionRules>()
                .eq(TRiskActionRules::getTenant, tenant)
                .eq(TRiskActionRules::getRulesType, ruleType.getId())
                .eq(TRiskActionRules::getRulesAction, ruleAction.getId())
                .eq(TRiskActionRules::getIsEnable, RiskActionEnableEnum.ENABLE.getId())
        );

        var today = new Date();
        for (var rule : ruleList) {
            // 规则天数不合法, 放行
            if (rule.getRulesCheckDay() < 1) {
                continue;
            }
            // 查询近几天内登陆/注册的用户列表
            var loginNameList = IntStream.range(0, rule.getRulesCheckDay())
                    .mapToObj(s -> DateUtils.addDays(today, -s))
                    .map(s -> FastDateFormat.getInstance(FMT_YYYY_MM_DD).format(s))
                    .map(dateAt -> getLoginNamesFromRedis(ipAddress, deviceFingerprint, dateAt))
                    .flatMap(Collection::stream)
                    .filter(s -> tenant.equals(s.getTenant()))
                    .filter(s -> s.getActionType() == ruleAction.getId())
                    .flatMap(s -> s.getLoginNameList().stream())
                    .distinct()
                    .toList();
            // 近几天登陆/注册人数小于限制数, 放行
            if (loginNameList.size() < rule.getRulesAccountMax()) {
                continue;
            }
            // 注册行为且注册人数已经大于或等于限制数, 拦截
            if (ruleAction == RiskActionTypeEnum.REGISTER) {
                return true;
            }
            var loginNameListOfToday = getLoginNamesFromRedis(ipAddress, deviceFingerprint, FastDateFormat.getInstance(FMT_YYYY_MM_DD).format(today))
                    .stream()
                    .filter(s -> tenant.equals(s.getTenant()))
                    .filter(s -> s.getActionType() == ruleAction.getId())
                    .distinct()
                    .toList();
            // loginName在今天已经登陆过, 放行
            if (loginNameListOfToday.contains(loginName)) {
                continue;
            }
            // loginName近几天登陆过, 且今日人数小于限制数, 放行
            if (loginNameList.contains(loginName) && loginNameListOfToday.size() < rule.getRulesAccountMax()) {
                continue;
            }
            // 拦截
            return true;
        }

        return false;
    }

    /**
     * 从redis缓存中获取dateAt登陆/注册的用户列表
     *
     * @param ipAddress
     * @param deviceFingerprint
     * @param dateAt            example: 2024-11-05
     * @return
     */
    @SneakyThrows
    private List<RiskDeviceTenantCacheInfo> getLoginNamesFromRedis(String ipAddress, String deviceFingerprint, String dateAt) {
        // 从redis读取登陆/注册的用户列表
        var redisKey = getRedisKeyOfRiskDeviceTenantCacheInfo(ipAddress, deviceFingerprint, dateAt);
        var riskDeviceTenantCacheInfoJsonString = redisUtil.get(redisKey, String.class);
        List<RiskDeviceTenantCacheInfo> riskDeviceTenantCacheInfoList = new ArrayList<>();
        if (StringUtils.isNotBlank(riskDeviceTenantCacheInfoJsonString)) {
            try {
                riskDeviceTenantCacheInfoList.addAll(this.objectMapper.readValue(riskDeviceTenantCacheInfoJsonString, new TypeReference<List<RiskDeviceTenantCacheInfo>>() {
                }));
            } catch (Exception e) {
                // do noting
            }
        } else {
            {
                // 查询登陆的用户列表
                riskDeviceTenantCacheInfoList.addAll(riskActionLoginSumMapper.selectList(new LambdaQueryWrapper<TRiskActionLoginSum>()
                                .eq(TRiskActionLoginSum::getDateAt, dateAt)
                                .eq(StringUtils.isNotBlank(deviceFingerprint), TRiskActionLoginSum::getDeviceFingerprint, deviceFingerprint)
                                .eq(StringUtils.isNotBlank(ipAddress), TRiskActionLoginSum::getIpAddress, ipAddress))
                        .stream()
                        .filter(s -> StringUtils.isNotBlank(s.getLoginNames()))
                        .map(sneaky(s -> {
                            try {
                                return this.objectMapper.readValue(s.getLoginNames(), new TypeReference<HashMap<String, String>>() {
                                });
                            } catch (Exception e) {
                                return new HashMap<String, String>();
                            }
                        }))
                        .map(s -> s.entrySet()
                                .stream()
                                .map(m -> new RiskDeviceTenantCacheInfo()
                                        .setActionType(RiskActionTypeEnum.LOGIN.getId())
                                        .setTenant(m.getKey())
                                        .setLoginNameList(Arrays.asList(StringUtils.split(m.getValue(), ",")))
                                ).toList()
                        )
                        .flatMap(s -> s.stream())
                        .toList());
            }
            {
                // 查询注册的用户列表
                riskDeviceTenantCacheInfoList.addAll(riskActionRegistrationSumMapper.selectList(new LambdaQueryWrapper<TRiskActionRegistrationSum>()
                                .eq(TRiskActionRegistrationSum::getDateAt, dateAt)
                                .eq(StringUtils.isNotBlank(deviceFingerprint), TRiskActionRegistrationSum::getDeviceFingerprint, deviceFingerprint)
                                .eq(StringUtils.isNotBlank(ipAddress), TRiskActionRegistrationSum::getIpAddress, ipAddress))
                        .stream()
                        .filter(s -> StringUtils.isNotBlank(s.getLoginNames()))
                        .map(sneaky(s -> {
                            try {
                                return this.objectMapper.readValue(s.getLoginNames(), new TypeReference<HashMap<String, String>>() {
                                });
                            } catch (Exception e) {
                                return new HashMap<String, String>();
                            }
                        }))
                        .map(s -> s.entrySet()
                                .stream()
                                .map(m -> new RiskDeviceTenantCacheInfo()
                                        .setActionType(RiskActionTypeEnum.REGISTER.getId())
                                        .setTenant(m.getKey())
                                        .setLoginNameList(Arrays.asList(StringUtils.split(m.getValue(), ",")))
                                ).toList()
                        )
                        .flatMap(s -> s.stream())
                        .toList());
            }
            redisUtil.set(redisKey, this.objectMapper.writeValueAsString(riskDeviceTenantCacheInfoList), Duration.ofDays(10).toSeconds());
        }
        return riskDeviceTenantCacheInfoList;
    }

    private String getRedisKeyOfRiskDeviceTenantCacheInfo(String ipAddress, String deviceFingerprint, String dateAt) {
        var redisKey = String.format(RISK_DEVICE_KEY, StringUtils.joinWith(":", dateAt, deviceFingerprint, ipAddress));
        return redisKey;
    }

}
