package com.riskcontrol.cron.service.impl;

import com.cn.schema.products.WSProductConstants;
import com.cn.schema.products.WSQueryProductConstants;
import com.riskcontrol.cron.config.BusinessConfig;
import com.riskcontrol.cron.service.ProductConsQueryService;
import com.riskcontrol.cron.utils.ProductConstantHelper;
import com.riskcontrol.cron.utils.RedisUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * 产品常量服务实现，基于配置
 *
 * @program: riskcontrol-cron
 * @description: 产品常量服务实现类
 * @author: Erhu.Zhao
 * @create: 2023-10-25 18:32
 **/
@Service
@Primary
public class ProductConsQueryOfConfigServiceImpl implements ProductConsQueryService {

    private BusinessConfig constantsConfig;
    @Resource
    private RedisUtil redisUtil;

    public ProductConsQueryOfConfigServiceImpl(BusinessConfig constantsConfig) {
        this.constantsConfig = constantsConfig;
    }

    @Override
    public Stream<WSProductConstants> obtainProductConstants(WSQueryProductConstants request) {
        String key = ProductConstantHelper.buildProductConstantKey(request.getProductId(), request.getType(), request.getKey());
        return generateReturn(constantsConfig.getPropertiesByKey(key)).stream();
    }

    /**
     * 根据常量配置结果构建常量返回集
     *
     * @param result 常量配置结果
     * @return 产品常量配置结果集
     */
    private List<WSProductConstants> generateReturn(Map<String, String> result) {
        final List<WSProductConstants> targetList = new ArrayList<>();
        if (MapUtils.isNotEmpty(result)) {

            result.forEach((k, v) -> {
                WSProductConstants productConstants = new WSProductConstants();
                productConstants.setValue(v);
                productConstants.setProductId(obtainOriginalProductId(k));
                productConstants.setKey(obtainOriginalKey(k));
                productConstants.setType(obtainOriginalType(k));
                targetList.add(productConstants);
            });
        }
        if (CollectionUtils.isEmpty(targetList)) {
            targetList.add(new WSProductConstants());
        }
        return targetList;
    }


    private String obtainOriginalProductId(String configKey) {
        return ProductConstantHelper.obtainOriginalFieldByIndex(configKey, 0);
    }

    private String obtainOriginalType(String configKey) {
        return ProductConstantHelper.obtainOriginalFieldByIndex(configKey, 1);
    }

    private String obtainOriginalKey(String configKey) {
        return ProductConstantHelper.obtainOriginalFieldByIndex(configKey, 2);
    }

    @Override
    public List<WSProductConstants> obtainProductConstantsRedis(WSQueryProductConstants request) {
        String typeHash = "r-" + request.getType();
        Map<String, String> constMap = redisUtil.entries(typeHash);
        List<WSProductConstants> productConstantsList = new ArrayList<>();
        if (MapUtils.isNotEmpty(constMap)) {
            if (StringUtils.isNotEmpty(request.getKey())&&!constMap.containsKey(replaceCenterLineUnderlineLower(request.getKey()))) {
                return productConstantsList;
            }
            if (StringUtils.isNotEmpty(request.getKey())&&constMap.containsKey(replaceCenterLineUnderlineLower(request.getKey()))) {
                WSProductConstants productConstants = new WSProductConstants();
                productConstants.setValue(constMap.get(replaceCenterLineUnderlineLower(request.getKey())));
                productConstants.setProductId(request.getProductId());
                productConstants.setKey(request.getKey());
                productConstants.setType(typeHash);
                productConstantsList.add(productConstants);
                return productConstantsList;
            }
            constMap.forEach((k, v) -> {
                WSProductConstants productConstants = new WSProductConstants();
                productConstants.setValue(v);
                productConstants.setProductId(request.getProductId());
                productConstants.setKey(replaceCenterLine2Underline(k));
                productConstants.setType(typeHash);
                productConstantsList.add(productConstants);
            });
        }
        return productConstantsList;
    }

    private static String replaceCenterLine2Underline(String source) {
        return source.replace("-", "_").toUpperCase();
    }

    private static String replaceCenterLineUnderlineLower(String source) {
        return source.replace("_","-").toLowerCase();
    }
}
