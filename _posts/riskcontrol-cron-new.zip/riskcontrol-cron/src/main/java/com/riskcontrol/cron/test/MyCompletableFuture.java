package com.riskcontrol.cron.test;

import java.util.concurrent.*;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-09-17
 **/
public class MyCompletableFuture {

    private static ThreadPoolExecutor taskPool = new ThreadPoolExecutor(4, 50, 0, TimeUnit.MILLISECONDS,
            new LinkedBlockingQueue<>(300), new ThreadPoolExecutor.CallerRunsPolicy());
    private static ThreadPoolExecutor monitorPool = new ThreadPoolExecutor(4, 50, 0, TimeUnit.MILLISECONDS,
            new LinkedBlockingQueue<>(300), new ThreadPoolExecutor.CallerRunsPolicy());

    public static void main(String[] args) {

        for (int i = 0; i < 1000; i++) {
            MyMessageInfo myMessageInfo = new MyMessageInfo();
            myMessageInfo.setName(String.valueOf(i));
            CompletableFuture future = CompletableFuture.supplyAsync(() -> runTask(myMessageInfo), taskPool);
            future.orTimeout(5, TimeUnit.SECONDS).exceptionallyAsync(e -> {
                if (e instanceof TimeoutException) {
                    boolean isCanceled = future.cancel(true);

                    // 处理5s超时，执行熔断流程
//                    e.printStackTrace();
//                    taskPool.getQueue().poll();
                    System.out.println("isCanceled? " + isCanceled + ";超时线程处理" + Thread.currentThread().getName() + " run,name is :" + myMessageInfo.getName() + ";e is " + e);

                    long taskCount = taskPool.getTaskCount();
                    long completedTaskCount = taskPool.getCompletedTaskCount();
                    int waitTask = taskPool.getQueue().size();
                    System.out.println("ddddd 提交的任务总数是，" + taskCount);
                    System.out.println("ddddd 已经完成的任务总数是，" + completedTaskCount);
                    System.out.println("ddddd 阻塞队列上等待的任务总数是：" + waitTask);


                }
                return null;
            }, monitorPool).whenComplete((r, e) -> {
                long taskCount = taskPool.getTaskCount();
                long completedTaskCount = taskPool.getCompletedTaskCount();
                int waitTask = taskPool.getQueue().size();
                System.out.println("提交的任务总数是，" + taskCount);
                System.out.println("已经完成的任务总数是，" + completedTaskCount);
                System.out.println("阻塞队列上等待的任务总数是：" + waitTask);
            });
        }

        try {
            Thread.sleep(10000);
            long taskCount = taskPool.getTaskCount();
            long completedTaskCount = taskPool.getCompletedTaskCount();
            int waitTask = taskPool.getQueue().size();
            System.out.println("vvvv 提交的任务总数是，" + taskCount);
            System.out.println("vvvv 已经完成的任务总数是，" + completedTaskCount);
            System.out.println("vvvv 阻塞队列上等待的任务总数是：" + waitTask);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }


    public static String runTask(MyMessageInfo info) {
        System.out.println(Thread.currentThread().getName() + " begin run,name is :" + info.getName());
        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
//        if ("10".equals(info.getName()) || "100".equals(info.getName()) || "500".equals(info.getName())) {
//            try {
//                Thread.sleep(300000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
        System.out.println(Thread.currentThread().getName() + " end run,name is :" + info.getName());


        long taskCount = taskPool.getTaskCount();
        long completedTaskCount = taskPool.getCompletedTaskCount();
        int waitTask = taskPool.getQueue().size();
        System.out.println("ssss 提交的任务总数是，" + taskCount);
        System.out.println("ssss 已经完成的任务总数是，" + completedTaskCount);
        System.out.println("ssss 阻塞队列上等待的任务总数是：" + waitTask);
        return info.getName();
    }
}
