package com.riskcontrol.cron.rabbit;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.common.annotation.LogUUID;
import com.riskcontrol.common.utils.LogUtils;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.constants.ProjectConstant;
import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.enums.MQExchangeEnum;
import com.riskcontrol.cron.service.WithdrawService;
import com.riskcontrol.cron.support.WithdrawServiceDelegate;
import com.riskcontrol.cron.utils.ProductConstantsLoader;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @Description: 取款风控rabbit消费
 * @Auther: yannis
 * @create: 2023-09-07
 */
@RefreshScope
@Component
@Slf4j
public class WithdrawApplyListener {
    @Resource(name = "withdrawExecutorService")
    private ThreadPoolExecutor executorService;
    @Resource
    private WithdrawService withdrawService;
    @Resource
    private WithdrawServiceDelegate withdrawServiceDelegate;

    @RabbitListener(
            bindings = @QueueBinding(
                    value = @Queue(value = "${productid}.officeapp.customer.withdraw.apply.risk", durable = "true", autoDelete = "false"),
                    exchange = @Exchange(value = "exchange_withdraw_apply", type = "topic"),
                    key = "#{'${routing.key.customer.withdraw.apply}'.split(';')}"),
            concurrency = "${mq.concurrency.low}"
    )
    @LogUUID
    public void withdrawApplyListener(Message msg) throws Exception {
        if (msg == null) {
            log.info("取款申请message消息为空");
            return;
        }
        String data = new String(msg.getBody());
        log.info("riskcontrol 处理取款申请rabbit消息：{}", data);
        if (StringUtils.isNotBlank(data)) {
            try {
                JSONObject messageJson = JSONObject.parseObject(data);
                JSONObject messageData = messageJson.getJSONObject("msgContent");
                if (messageData == null) {
                    log.info("处理取款申请rabbit消息,消息对象为空, 消息内容:{}.", messageJson);
                    return;
                }
                String routingKey = messageJson.getString("routingKey");
                if (StringUtils.isEmpty(routingKey) || !MQExchangeEnum.WITHDRAW_APPLY.getRoutingKey().equals(routingKey)) {
                    log.info("不属于取款申请 routingKey={}， 消息丢弃", routingKey);
                    return;
                }
                String requestId = messageData.getString("requestId");
                String productId = messageData.getString("productId");
                OriWithdrawReq req = new OriWithdrawReq();
                req.setRequestId(requestId);
                req.setProductId(productId);
                //风控功能开关
                String withdrawRiskKey = ProductConstantsLoader.obtainProductConstantRedis(productId, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0014, ProjectConstant.JMS_WITHDRAW_RISK);
                String withdrawListenerAsyncKey = ProductConstantsLoader.obtainProductConstantRedis(productId, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0014, ProjectConstant.JMS_WITHDRAW_RISK_LISTENER_ASYNC);
                log.info("取款风控JMS_WITHDRAW_RISK开关:{};取款风控WITHDRAW_RISK_LISTENER_ASYNC开关:{}", withdrawRiskKey, withdrawListenerAsyncKey);
                if (CronConstant.ENABLED.equals(withdrawRiskKey)) {
                    if(CronConstant.ENABLED.equals(withdrawListenerAsyncKey)){
                        withdrawServiceDelegate.handleWithdraw(req);
                    }else{
                        Map<String, String> mdcContextMap = LogUtils.getMDCContextMap();
                        executorService.submit(() -> {
                            try {
                                LogUtils.setMDCContextMap(mdcContextMap);
                                withdrawService.withdrawRisk(req, true,false);
                            } catch (Exception e) {
                                log.error("withdrawRisk error", e);
                                throw new RuntimeException(e.getMessage());
                            }
                        });
                    }
                } else {
                    withdrawService.withdrawRisk(req, false,false);
                    log.info("取款风控JMS_WITHDRAW_RISK开关:{}，消息丢弃 ", withdrawRiskKey);
                }

            } catch (Exception e) {
                log.error(e.getLocalizedMessage(), e);
            }
        }

    }


    @RabbitListener(
            bindings = @QueueBinding(
                    value = @Queue(value = CronConstant.MqConstants.RETRY_QUEUE, durable = "true", autoDelete = "false"),
                    exchange = @Exchange(value = CronConstant.MqConstants.RETRY_EXCHANGE, type = "topic"),
                    key = CronConstant.MqConstants.RETRY_ROUTING_KEY),
            concurrency = "${mq.concurrency.low}"
    )
    @LogUUID
    public void withdrawApplyListenerRetry(Message message) throws Exception {
        if (message == null) {
            log.info("取款申请message消息为空");
            return;
        }
        String data = new String(message.getBody());
        log.info("riskcontrol 重试处理取款申请rabbit消息：{}", data);
        if (StringUtils.isNotBlank(data)) {
            try {
                String withdrawRiskKeyRetry = ProductConstantsLoader.obtainProductConstantRedis(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0014, ProjectConstant.JMS_WITHDRAW_RISK_RETRY);
                log.info("取款风控JMS_WITHDRAW_RISK_RETRY 重审开关:{}", withdrawRiskKeyRetry);
                if (!CronConstant.ENABLED.equals(withdrawRiskKeyRetry)) {
                    log.info("取款风控JMS_WITHDRAW_RISK_RETRY 重审开关:{}，消息丢弃", withdrawRiskKeyRetry);
                    return;
                }
                JSONObject messageJson = JSONObject.parseObject(data);
                JSONObject messageData = messageJson.getJSONObject("msgContent");
                if (messageData == null) {
                    log.info("处理取款申请rabbit消息,消息对象为空, 消息内容:{}.", messageJson);
                    return;
                }
                String routingKey = messageJson.getString("routingKey");
                if (StringUtils.isEmpty(routingKey) || !MQExchangeEnum.WITHDRAW_APPLY.getRoutingKey().equals(routingKey)) {
                    log.info("不属于取款申请 routingKey={}， 消息丢弃", routingKey);
                    return;
                }
                String requestId = messageData.getString("requestId");
                String productId = messageData.getString("productId");
                OriWithdrawReq req = new OriWithdrawReq();
                req.setRequestId(requestId);
                req.setProductId(productId);
                //风控功能开关
                String withdrawRiskKey = ProductConstantsLoader.obtainProductConstantRedis(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0014, ProjectConstant.JMS_WITHDRAW_RISK);
                String withdrawListenerAsyncKey = ProductConstantsLoader.obtainProductConstantRedis(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0014, ProjectConstant.JMS_WITHDRAW_RISK_LISTENER_ASYNC);
                log.info("取款风控JMS_WITHDRAW_RISK开关:{};取款风控WITHDRAW_RISK_LISTENER_ASYNC开关:{}", withdrawRiskKey, withdrawListenerAsyncKey);
                if (CronConstant.ENABLED.equals(withdrawRiskKey)) {
                    if (CronConstant.ENABLED.equals(withdrawListenerAsyncKey)) {
                        withdrawServiceDelegate.handleWithdraw(req);
                    } else {
                        Map<String, String> mdcContextMap = LogUtils.getMDCContextMap();
                        executorService.submit(() -> {
                            try {
                                LogUtils.setMDCContextMap(mdcContextMap);
                                withdrawService.withdrawRisk(req, true, true);
                            } catch (Exception e) {
                                log.error("withdrawRisk error", e);
                            }
                        });
                    }
                } else {
                    withdrawService.withdrawRisk(req, false,true);
                    log.info("取款风控JMS_WITHDRAW_RISK开关:{}，消息丢弃", withdrawRiskKey);
                }

            } catch (Exception e) {
                log.error(e.getLocalizedMessage(), e);
            }
        }
    }


}
