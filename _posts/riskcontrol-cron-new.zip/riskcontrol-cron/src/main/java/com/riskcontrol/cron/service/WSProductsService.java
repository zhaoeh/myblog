///**
// * @Overview:产品信息处理相关接口
// * @author sky.x
// * @History: 2013-02-12 重新整理代码
// */
//package com.riskcontrol.cron.service;
//
//import com.cn.schema.products.WSProductConstants;
//import com.cn.schema.products.WSQueryProductConstants;
//import com.riskcontrol.cron.dao.BaseDao;
//
//import java.util.List;
//
///**
// * 产品信息处理相关接口
// * */
//public interface WSProductsService {
//
//
//    /**
//     * 查询产品常量
//     *
//     * @author Spark.W
//     * @param dao (数据源DAO)
//     * @param query (查询对象)
//     * @return List<WSProductConstants>
//     */
//    List<WSProductConstants> queryProductConstants(BaseDao dao, WSQueryProductConstants query) throws Exception;
//
//
//}
