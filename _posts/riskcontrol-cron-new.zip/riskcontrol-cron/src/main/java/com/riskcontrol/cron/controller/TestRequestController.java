//package com.riskcontrol.cron.controller;
//
//import cn.hutool.core.thread.ThreadUtil;
//import com.riskcontrol.common.entity.response.Response;
//import com.riskcontrol.common.entity.response.kyc.RiskQueryKycRequestResponse;
//import com.riskcontrol.cron.engine.OriWithdrawReq;
//import com.riskcontrol.cron.support.WithdrawServiceDelegate;
//import io.swagger.annotations.Api;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
///**
// * @program: riskcontrol-cron
// * @description: kyc controller
// * @author: Erhu.Zhao
// * @create: 2023-10-04 15:42
// **/
//@RestController
//@RequestMapping("/customers/run")
//@Api("KYC相关接口")
//@Slf4j
//public class TestRequestController {
//
//
//    @Autowired
//    private WithdrawServiceDelegate withdrawServiceDelegate;
//
//    @ResponseBody
//    @GetMapping("/task")
//    public Response<RiskQueryKycRequestResponse> queryPage() throws Exception {
//        for(int i = 0;i < 10;i++){
//            OriWithdrawReq req = new OriWithdrawReq();
//            req.setLoginName("erhu");
//            req.setRequestId("zhaotest"+i);
//            withdrawServiceDelegate.handleWithdraw(req);
//        }
//        return Response.body(null);
//    }
//
//
//    public static void main(String[] args) {
//        WithdrawServiceDelegate withdrawServiceDelegate =  new WithdrawServiceDelegate();
//        withdrawServiceDelegate.init();
//        for(int i = 0;i < 100;i++){
//            OriWithdrawReq req = new OriWithdrawReq();
//            req.setLoginName("erhu");
//            req.setRequestId("zhaotest"+i);
//            withdrawServiceDelegate.handleWithdraw(req);
//        }
//
//        ThreadUtil.sleep(Integer.MAX_VALUE);
//    }
//}
