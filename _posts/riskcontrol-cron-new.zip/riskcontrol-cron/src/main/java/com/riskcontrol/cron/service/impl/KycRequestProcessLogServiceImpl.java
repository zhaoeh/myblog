package com.riskcontrol.cron.service.impl;

import com.cn.schema.customers.WSKycRequestProcessLog;
import com.riskcontrol.common.annotation.InterceptDoWant;
import com.riskcontrol.common.entity.response.kyc.RiskKycRequestProcessLogResponse;
import com.riskcontrol.cron.aop.SynProcessLogToRequest;
import com.riskcontrol.cron.mapper.KycRequestProcessLogDao;
import com.riskcontrol.cron.service.KycRequestProcessLogService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * @author ：zeus
 * @description：TODO
 * @date ：2023/04/03 11:24
 */
@Service
public class KycRequestProcessLogServiceImpl implements KycRequestProcessLogService {

    @Resource
    private KycRequestProcessLogDao kycRequestProcessLogDao;

    @Override
    @InterceptDoWant(SynProcessLogToRequest.class)
    public int insert(WSKycRequestProcessLog wsKycRequestProcessLog) {
        wsKycRequestProcessLog.setLastStauts(0);
        wsKycRequestProcessLog.setCreateTime(new Date());
        if (wsKycRequestProcessLog.getKycRequestId() != null) {//更新上一条记录状态
            kycRequestProcessLogDao.updateStatusByKycId(wsKycRequestProcessLog.getKycRequestId());
        }
        int result = kycRequestProcessLogDao.insert(wsKycRequestProcessLog);
        return result;
    }

    @Override
    public List<WSKycRequestProcessLog> queryPageByKycRequestId(String id) {
        return kycRequestProcessLogDao.queryPageByKycRequestId(id);

    }

    @Override
    public List<RiskKycRequestProcessLogResponse> riskQueryPageByKycRequestId(String id) {
        return kycRequestProcessLogDao.riskQueryPageByKycRequestId(id);
    }

}
