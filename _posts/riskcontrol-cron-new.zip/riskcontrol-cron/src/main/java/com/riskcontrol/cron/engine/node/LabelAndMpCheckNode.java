package com.riskcontrol.cron.engine.node;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.constants.ProjectConstant;
import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.engine.WithdrawContext;
import com.riskcontrol.cron.entity.TRiskLabelRelationship;
import com.riskcontrol.cron.enums.WithdrawFilterEnum;
import com.riskcontrol.cron.service.TRiskLabelRelationshipService;
import com.riskcontrol.cron.utils.ProductConstantsLoader;
import com.yomahub.liteflow.annotation.LiteflowComponent;
import com.yomahub.liteflow.core.NodeIfComponent;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 校验标签和小程序
 *
 * @author yueds
 */
@LiteflowComponent("labelAndMpCheckNode")
@Slf4j
public class LabelAndMpCheckNode extends NodeIfComponent {
    //高风险标签判断开关
    @Value("${risk.high.enable:false}")
    private boolean riskHighEnable;
    @Resource
    private TRiskLabelRelationshipService labelRelationshipService;

    @Override
    public boolean processIf() throws Exception {
        WithdrawContext context = this.getFirstContextBean();
        OriWithdrawReq req = context.getReq();
        String requestId = req.getRequestId();
        // 判断 黑名单、关注用户、套利客 , 走人工逻辑
        List<TRiskLabelRelationship> labelRelationships = labelRelationshipService.queryByCustomerId(req.getCustomerId());
        List<String> labelKeyList = labelRelationships.stream().map(TRiskLabelRelationship::getRiskLabelKey).toList();

        //标签非普通用户、白名单用户，不直接通过
        if(!riskHighEnable){
            labelKeyList  = labelKeyList.stream().filter(l->!l.equals(CronConstant.LabelKey.RISK_ACCOUNT_MEDIUM)
                    && !l.equals(CronConstant.LabelKey.RISK_ACCOUNT_HIGH)).collect(Collectors.toList());
        }
        String manualType = ProductConstantsLoader.obtainProductConstantRedis(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0016, ProjectConstant.MANUAL_TYPE);
        List<String> manualTypeList = new ArrayList<>();
        if(StringUtils.isNotBlank(manualType)){
            manualTypeList = StrUtil.split(manualType, Constant.COMMA_SYMBOL);
        }
        boolean passLabel = CollectionUtils.isEmpty(labelKeyList) || labelKeyList.contains(CronConstant.LabelKey.RISK_REGULAR) || labelKeyList.contains(CronConstant.LabelKey.RISK_WHITE_LIST);
        log.info("判断标签是否通过：requestId:{} ,passLabel={} , loginName={}, labelKey={}", requestId,passLabel,req.getLoginName(), JSONObject.toJSONString(labelKeyList));
        if (!passLabel && manualTypeList.contains(WithdrawFilterEnum.HIT_LABEL.getType())) {
            log.info("标签规则命中，并开启拦截该规则，requestId：{}，labelKey：{}", requestId , JSONObject.toJSONString(labelKeyList));
            // 规则引擎参数处理
            context.setExceptionPromptType(WithdrawFilterEnum.HIT_LABEL.getType());
            context.setExceptionPrompt(String.format(WithdrawFilterEnum.HIT_LABEL.getFilterMsg(), labelKeyList));
            // 更新命中规则
            context.filter.put(WithdrawFilterEnum.HIT_LABEL.getType(), String.format(WithdrawFilterEnum.HIT_LABEL.getFilterMsg(), labelKeyList));
            return false;
        }else if (context.isGlifeDomain()) {
            // 小程序的处理逻辑-中断后续规则节点
            log.info("取款风控 glife取款自动通过, requestId:{}，", requestId);
            // 规则引擎参数处理
            context.setAutoApprove(true);
            return false;
        }
        // 非glife小程序放行
        return true;
    }
}
