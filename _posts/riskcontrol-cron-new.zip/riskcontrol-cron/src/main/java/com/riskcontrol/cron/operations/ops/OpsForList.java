package com.riskcontrol.cron.operations.ops;

import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * @program: riskcontrol-cron
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-11-17 11:33
 */
@Component
public class OpsForList extends OpsFor implements Ops {

    @Override
    public String operation() {
        return "opsForList";
    }

    public void set(Serializable key, long index, Object value) {
        this.redisTemplate.opsForList().set(key, index, value);
    }

    public Object index(Serializable key, long index) {
        return this.redisTemplate.opsForList().index(key, index);
    }

}