/**
 * @Overview:公共Service处理类
 * @author sky.x
 * @History:
 * 2013-02-12 重新整理代码
 */
package com.riskcontrol.cron.service;

import com.riskcontrol.cron.utils.RedisUtil;

import javax.annotation.Resource;

/**
 * 公共Service处理类
 * */
public abstract class BaseServiceImpl {

    @Resource
    protected RedisUtil redisUtil;

    /**
     * 校验传入的字符串是否为空(为空:false,不为空:true)
     *
     * @author sky.x
     * @param temp (校验对象)
     * @return boolean
     */
    public boolean checkIsEmpty(String temp) {
        return null != temp && !"".equals(temp.trim());
    }
}
