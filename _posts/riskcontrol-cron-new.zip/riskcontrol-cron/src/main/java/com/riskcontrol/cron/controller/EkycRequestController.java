package com.riskcontrol.cron.controller;

import com.riskcontrol.common.entity.pojo.Ekyc;
import com.riskcontrol.common.entity.pojo.EkycRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycCreateRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycUpdateRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycExtendRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycZolozErrorRequest;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.cron.service.EkycRequestService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;

/**
 * @program: riskcontrol-cron
 * @description: ekyc controller
 * @author: Erhu.Zhao
 * @create: 2023-10-04 15:42
 **/
@RestController
@RequestMapping("/ekyc")
@Api("EKYC相关接口")
@Slf4j
public class EkycRequestController {

    @Autowired
    private EkycRequestService ekycRequestService;

    /**
     * 查询用户的ekyc状态*
     *
     * @param loginName
     * @return
     */
    @GetMapping(value = "/queryStatus/{loginName}")
    @ResponseBody
    public Response<Ekyc> queryStatus(@PathVariable @Validated @NotEmpty String loginName) {
        return Response.body(ekycRequestService.queryEkycStatus(loginName));
    }

    /**
     * 查询最近一笔kyc*
     *
     * @param loginName
     * @return
     */
    @GetMapping(value = "/queryCurrentKyc/{loginName}")
    @ResponseBody
    public Response<EkycRequest> queryCurrentKycRequest(@PathVariable @Validated @NotEmpty String loginName) {
        return Response.body(ekycRequestService.queryCurrentKycRequest(loginName));
    }

    /**
     * 查询ekyc提案*
     *
     * @param id
     * @return
     */
    @GetMapping(value = "/queryEkycRequest/{id}")
    @ResponseBody
    public Response<EkycRequest> queryEkycRequest(@PathVariable @Validated @NotNull BigInteger id) {
        return Response.body(ekycRequestService.queryEkycRequest(id));
    }

    /**
     * 完善ekyc扩展信息*
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/modifyEkycRequest")
    @ResponseBody
    public Response<Boolean> modifyEkycRequest(@RequestBody @Validated EkycExtendRequest request) {
        return Response.body(ekycRequestService.modifyEkycRequest(request));
    }

    @ApiOperation(value = "ekyc创建提案接口")
    @PostMapping(value = "/createEkycRequest")
    public Response<Boolean> createEkycRequest(@RequestBody @Validated EkycCreateRequest request) {
        return Response.body(ekycRequestService.createEkycRequest(request));
    }

    @ApiOperation(value = "ekyc保存第三方成功认证信息")
    @PostMapping(value = "/saveVerificationInfo")
    public Response<Boolean> saveVerificationInfo(@RequestBody @Validated EkycUpdateRequest request) {
        return Response.body(ekycRequestService.saveVerificationInfo(request));
    }
    @ApiOperation(value = "第三方认证失败之后更新ekyc")
    @PostMapping(value = "/updateEkycStatus")
    public Response<Boolean> updateEkycStatus(@RequestBody @Validated EkycZolozErrorRequest request) {
        return Response.body(ekycRequestService.updateEkycStatus(request));
    }

}
