package com.riskcontrol.cron.config;

import com.riskcontrol.cron.utils.SSLUtils;
import okhttp3.*;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.concurrent.TimeUnit;


@Configuration
public class OkHttpConfig {

    @Value("${okhttp.connect-timeout:60}")
    private Integer connectTimeout;

    @Value("${okhttp.read-timeout:60}")
    private Integer readTimeout;

    @Value("${okhttp.write-timeout:60}")
    private Integer writeTimeout;

    @Value("${okhttp.max-idle-connections:30}")
    private Integer maxIdleConnections;

    @Value("${okhttp.keep-alive-duration:5}")
    private Long keepAliveDuration;

    @Value("${kdl.host}")
    private String kdlHost;
    @Value("${kdl.port}")
    private Integer kdlPort;
    @Value("${kdl.username}")
    private String kdlUsername;
    @Value("${kdl.password}")
    private String kdlPassword;
    @Bean
    public X509TrustManager x509TrustManager() {
        return new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
            }
            @Override
            public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
            }
            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }
        };
    }

    @Bean
    public SSLSocketFactory sslSocketFactory() {
        try {
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, new TrustManager[]{x509TrustManager()}, new SecureRandom());
            return sslContext.getSocketFactory();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Create a new connection pool with tuning parameters appropriate for a single-user application.
     * The tuning parameters in this pool are subject to change in future OkHttp releases. Currently
     */
    @Bean
    public ConnectionPool pool() {
        return new ConnectionPool(maxIdleConnections, keepAliveDuration, TimeUnit.MINUTES);
    }

    @Bean("kdlOkHttpClient")
    public OkHttpClient kdlOkHttpClient() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        if(!StringUtils.isAllBlank(kdlHost,kdlUsername,kdlPassword) && null != kdlPort){//设置代理
            builder.proxy(new Proxy(Proxy.Type.HTTP,new InetSocketAddress(kdlHost,kdlPort)))
                    .proxyAuthenticator(new Authenticator() {
                        @Nullable
                        @Override
                        public Request authenticate(@Nullable Route route, @NotNull Response response) throws IOException {
                            String credential = Credentials.basic(kdlUsername, kdlPassword);
                            return response.request().newBuilder().header("Proxy-Authorization",credential).build();
                        }
                    });
        }
        //设置绕过TLS
        return builder.sslSocketFactory(sslSocketFactory(), (X509TrustManager) SSLUtils.getTrustManager()[0])
                .hostnameVerifier((hostname, session) -> true)
                .connectionPool(pool())// 连接池
                .connectTimeout(connectTimeout, TimeUnit.SECONDS)
                .readTimeout(readTimeout, TimeUnit.SECONDS)
                .readTimeout(writeTimeout, TimeUnit.SECONDS)
                .build();
    }
}