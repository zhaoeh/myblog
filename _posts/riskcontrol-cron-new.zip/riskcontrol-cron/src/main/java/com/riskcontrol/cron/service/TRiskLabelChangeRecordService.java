package com.riskcontrol.cron.service;

import com.riskcontrol.cron.entity.TRiskLabelChangeRecord;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户标签绑定关系表 服务类
 * </p>
 *
 * @author Yannis
 * @since 2024-01-11
 */
public interface TRiskLabelChangeRecordService extends IService<TRiskLabelChangeRecord> {

}
