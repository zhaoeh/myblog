package com.riskcontrol.cron.service.impl;

import cn.hutool.core.util.IdUtil;
import com.cn.schema.request.WSOddNumbersGen;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.constants.ProjectConstant;
import com.riskcontrol.cron.enums.ErrCodeEnum;
import com.riskcontrol.cron.mapper.OddNumbersGenDao;
import com.riskcontrol.cron.service.AbstractService;
import com.riskcontrol.cron.service.OddNumbersGenService;
import com.riskcontrol.cron.service.ProductConsQueryService;
import com.riskcontrol.cron.utils.CacheUtil;
import com.riskcontrol.cron.utils.ProductConstantsLoader;
import com.riskcontrol.cron.utils.ValidationUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * 单号生成服务层实现类
 *
 * @author wade
 * @date 2019-02-22 14:24:01.
 */
@Service
public class OddNumbersGenServiceImpl extends AbstractService implements OddNumbersGenService {

    @Autowired
    private OddNumbersGenDao oddNumbersGenDao;

    @Autowired
    private ProductConsQueryService productConsQueryService;

    /**
     * 根据主键查询信息
     *
     * @param id 主键
     * @return WSOddNumbersGen
     * @throws BusinessException
     */
    @Override
    public WSOddNumbersGen loadOddNumbersGenById(String id) throws BusinessException {
        ValidationUtils.checkIsNotEmpty(id, ErrCodeEnum.MSG_500018);
        return oddNumbersGenDao.loadOddNumbersGenById(id);
    }

    /**
     * 创建信息
     *
     * @param bean 需要创建的信息
     * @return WSOddNumbersGen 创建后结果
     * @throws BusinessException
     */
    @Override
    public WSOddNumbersGen createOddNumbersGen(WSOddNumbersGen bean) throws BusinessException {
        ValidationUtils.checkIsNull(bean, ErrCodeEnum.MSG_500018);
        oddNumbersGenDao.createOddNumbersGen(bean);
        return loadOddNumbersGenById(bean.getId());
    }


    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public String singleGenRequestId(String productId, String requestType) throws BusinessException {
//        String snowFlakeIdSwitch = productConstantService.loadValueByKey(productId, Constant.PRODUCT_CONSTANTS_TYPE_0004, Constant.SNOW_FLAKE_ID_SWITCH);
//        String snowFlakeIdSwitch = productConstantsConfig.getPropertyByParams(productId, CronConstant.PRODUCT_CONSTANTS_TYPE_0004, CronConstant.SNOW_FLAKE_ID_SWITCH);
        String snowFlakeIdSwitch = ProductConstantsLoader.obtainProductConstantRedis(productId, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0004, ProjectConstant.SNOW_FLAKE_ID_SWITCH);
        if (StringUtils.isNotBlank(snowFlakeIdSwitch) && CronConstant.ONE.equalsIgnoreCase(snowFlakeIdSwitch)) {
            WSOddNumbersGen loadOdd = lockOddNumbersBeforeGen(productId, requestType, "1");
            String finalBillNo = doGenerateRequestId(productId, requestType, loadOdd);
            oddNumbersGenDao.modifyOddNumbersGen(loadOdd);
            return finalBillNo;
        } else {
            try {
                logger.info("snowFlakeId generate workId:{}, dateCenterId:{}", CacheUtil.getWorkId(), CacheUtil.getDateCenterId());
                return IdUtil.getSnowflake(CacheUtil.getWorkId(), CacheUtil.getDateCenterId()).nextIdStr();
            } catch (Exception e) {
                logger.error("snowFlakeId generate fail! ", e);
                WSOddNumbersGen loadOdd = lockOddNumbersBeforeGen(productId, requestType, "1");
                String finalBillNo = doGenerateRequestId(productId, requestType, loadOdd);
                oddNumbersGenDao.modifyOddNumbersGen(loadOdd);
                return finalBillNo;
            }
        }
    }

    /**
     * 创建并锁定记录：productId+requestType+serialType为唯一键，无则创建并锁行，有则直接锁行
     *
     * @param productId
     * @param requestType 业务类型：01/02/03(提案类)|1/2(纯数字单号)
     * @param serialType  生成规则类型：1=提案类单号；2=转账单号(纯数字单号)
     * @return
     * @throws BusinessException
     */
    private WSOddNumbersGen lockOddNumbersBeforeGen(String productId, String requestType, String serialType) throws BusinessException {
        // 锁住记录
        WSOddNumbersGen loadOdd = oddNumbersGenDao.loadOddNumbersGenByType(productId, requestType, serialType);
        // 查出单号生成记录，不存在则创建一条
        if (loadOdd == null) {
            String timeStr = new SimpleDateFormat("yyMMddHHmm").format(Calendar.getInstance().getTime());
            String serialNumber = "";
            String specialStr = "";
            if (StringUtils.equals(serialType, "1")) {
                serialNumber = (int) (serial_start) + getNumberTwo(num_start);
                specialStr = String.valueOf(serial_start);
            } else if (StringUtils.equals(serialType, "2")) {
                serialNumber = getNumberThree(num_start);
                specialStr = String.valueOf((int) serial_start);
            } else if (StringUtils.equals(serialType, "3")) {
                serialNumber = getNumberThree(num_start);
                specialStr = String.valueOf(serial_start);
            } else {
                ValidationUtils.exceptionMsg(ErrCodeEnum.MSG_500539);
            }
            WSOddNumbersGen createNewOdd = new WSOddNumbersGen();
            createNewOdd.setProductId(productId);
            createNewOdd.setRequestType(requestType);
            createNewOdd.setSerialNumber(serialNumber);
            createNewOdd.setSerialType(serialType);
            createNewOdd.setSpecialStr(specialStr);
            createNewOdd.setTimeStr(timeStr);
            createOddNumbersGen(createNewOdd);
        }
        // 锁住记录
        loadOdd = oddNumbersGenDao.lockAndLoadOddNumbersGenByType(productId, requestType, serialType);
        return loadOdd;
    }

    /**
     * 生成提案类的单号：A03021902221148AA01(A03 02 1902221148 A A 01)
     * A03(产品ID) + 02(业务类型requestType) + 1902221148(当前时间串yyMMddHHmm) + A(特殊位) + A(流水字母位) + 01(数字流水)
     *
     * @param productId
     * @param requestType
     * @param loadOdd
     * @return
     * @throws BusinessException
     */
    private String doGenerateRequestId(String productId, String requestType, WSOddNumbersGen loadOdd) throws BusinessException {
        String finalBillNo = "";
        // 对比时间串，如果不一致，则按初始值生成
        String timeStr = new SimpleDateFormat("yyMMddHHmm").format(Calendar.getInstance().getTime());
        if (!StringUtils.equals(timeStr, loadOdd.getTimeStr())) {
            // 如果时间串一致则拿当前流水号生成单号，
            finalBillNo = genRequestId(productId, requestType, timeStr, String.valueOf(serial_start), String.valueOf(serial_start), getNumberTwo(num_start));
        } else {
            char oldSpecialChar = loadOdd.getSpecialStr().charAt(0);
            char serialChar = loadOdd.getSerialNumber().substring(0, 1).charAt(0);
            String serialNum = loadOdd.getSerialNumber().substring(1);
            int intSerialNum = Integer.parseInt(serialNum);
            if (intSerialNum + 1 > requestid_num_end) {
                // 如果超出最大数字流水，则字母流水+1，流水用起始值
                if ((int) serialChar + 1 > (int) serial_end) {
                    // 如果超出字母最大流水号，特殊字母位+1，数字流水、字母流水位用起始值
                    if ((int) oldSpecialChar + 1 > (int) serial_end) {
                        // 如果特殊位流水也超过字母最大流水号，则异常
                        ValidationUtils.exceptionMsg(ErrCodeEnum.MSG_500540);
                    } else {
                        finalBillNo = genRequestId(productId, requestType, timeStr, String.valueOf((char) ((int) oldSpecialChar + 1)), String.valueOf(serial_start), getNumberTwo(num_start));
                    }
                } else {
                    finalBillNo = genRequestId(productId, requestType, timeStr, String.valueOf(oldSpecialChar), String.valueOf((char) ((int) serialChar + 1)), getNumberTwo(num_start));
                }
            } else {
                finalBillNo = genRequestId(productId, requestType, timeStr, String.valueOf(oldSpecialChar), String.valueOf(serialChar), String.valueOf(getNumberTwo(intSerialNum + 1)));
            }
        }

        // 更新单号生成记录，返回单号
        loadOdd.setTimeStr(timeStr);
        loadOdd.setSpecialStr(finalBillNo.substring(finalBillNo.length() - 4, finalBillNo.length() - 3));
        loadOdd.setSerialNumber(finalBillNo.substring(finalBillNo.length() - 3));
        return finalBillNo;
    }

    private String genRequestId(String productId, String requestType, String timeStr, String specialStr, String serialStr, String numStr) {
        return productId + requestType + timeStr + specialStr + serialStr + numStr;
    }

    private String getNumberTwo(int num) {
        return num >= 10 ? String.valueOf(num) : "0" + String.valueOf(num);
    }

    private String genReferenceId(String productId, String requestType, String timeStr, String specialStr, String numStr) {
        String temp = String.valueOf(productId.substring(0, 1).hashCode());
        productId = temp.substring(1, temp.length()) + productId.substring(1, productId.length());
        return productId + requestType + timeStr + specialStr + numStr;
    }

    private String getNumberThree(int num) {
        if (num < 10) {
            return "00" + String.valueOf(num);
        } else if (num < 100) {
            return "0" + String.valueOf(num);
        } else {
            return String.valueOf(num);
        }
    }
}
