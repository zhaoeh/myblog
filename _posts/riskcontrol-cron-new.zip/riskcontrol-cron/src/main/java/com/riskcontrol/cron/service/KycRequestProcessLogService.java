package com.riskcontrol.cron.service;

import com.cn.schema.customers.WSKycRequestProcessLog;
import com.riskcontrol.common.entity.response.kyc.RiskKycRequestProcessLogResponse;

import java.util.List;

public interface KycRequestProcessLogService {

    int insert(WSKycRequestProcessLog wsKycRequestProcessLog);

    List<WSKycRequestProcessLog> queryPageByKycRequestId(String id);

    List<RiskKycRequestProcessLogResponse> riskQueryPageByKycRequestId(String id);
}
