package com.riskcontrol.cron.mapper;

import com.riskcontrol.cron.entity.TRiskLabelChangeRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 用户标签绑定关系表 Mapper 接口
 * </p>
 *
 * @author Yannis
 * @since 2024-01-11
 */
public interface TRiskLabelChangeRecordMapper extends BaseMapper<TRiskLabelChangeRecord> {

}
