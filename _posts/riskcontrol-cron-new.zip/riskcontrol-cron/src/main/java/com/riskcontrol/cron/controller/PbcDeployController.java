package com.riskcontrol.cron.controller;

import com.riskcontrol.common.entity.request.api.PBCDeployDisableRequest;
import com.riskcontrol.common.entity.request.api.PBCDeployUpdateRequest;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.api.PBCDeployRsp;
import com.riskcontrol.cron.service.TPBCDeployService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/*** @program: riskcontrol-cron
 ** @description: PBC配置文件Controller
 ** @author: hongwei
 ** @create: 2023-11-13 15:03
 **/
@RestController
@RequestMapping("/pbc")
@Api("PBC配置文件相关接口")
public class PbcDeployController {


    @Resource
    private TPBCDeployService tpbcDeployService;

    @PostMapping("deploy")
    @ApiOperation(value = "查询pbc配置接口")
    @ResponseBody
    public Response<List<PBCDeployRsp>> getDeployList() {
        Response<List<PBCDeployRsp>> response = new Response<>();
        response.setBody(tpbcDeployService.getPBCDeployList());
        return response;
    }

    @PostMapping("updateDeploy")
    @ApiOperation(value = "修改pbc配置接口")
    public Response updateDeploy(@Valid @RequestBody PBCDeployUpdateRequest deployUpdateRequest) {
        Response<Boolean> response = tpbcDeployService.updateDeploy(deployUpdateRequest);
        return response;
    }

    @PostMapping("deleteDeploy")
    @ApiOperation(value = "停止pbc抓包配置接口")
    public Response deleteDeploy(@Valid @RequestBody PBCDeployDisableRequest deployDisableRequest) {
        Response<Boolean> response = tpbcDeployService.disableDeploy(deployDisableRequest);
        return response;
    }
}
