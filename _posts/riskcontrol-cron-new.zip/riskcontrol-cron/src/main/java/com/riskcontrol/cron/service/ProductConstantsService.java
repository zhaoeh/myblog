//package com.riskcontrol.cron.service;
//
//import com.cn.schema.products.WSProductConstants;
//import com.cn.schema.products.WSQueryProductConstants;
//import com.riskcontrol.common.exception.BusinessException;
//
//import java.util.List;
//import java.util.Map;
//
///**
// * 产品常量服务
// *
// * @program: riskcontrol-cron
// * @description: 产品常量服务接口
// * @author: Erhu.Zhao
// * @create: 2023-10-26 18:30
// **/
//public interface ProductConstantsService {
//    /**
//     * 根据参数查询产品常量
//     *
//     * @param pType     pType
//     * @param pKey      pKey
//     * @param productId productId
//     * @return pValue
//     */
//    String getValueByKey(String pType, String pKey, String productId);
//
//    /**
//     * 根据productId和pKey查询产品常量的value
//     *
//     * @param productId productId
//     * @param pKey      pKey
//     * @return pValue
//     * @throws BusinessException BusinessException
//     */
//    String loadValueOnlyByKey(String productId, String pKey) throws BusinessException;
//
//    /**
//     * 查询指定范围内的pType对应的产品常量集合
//     *
//     * @param map 入参
//     * @return 符合条件的产品常量集合
//     */
//    List<WSProductConstants> getAgLineAndRate(Map map);
//
//    /**
//     * 新增产品产量
//     *
//     * @param bean 入参
//     * @return 新增条数
//     */
//    Integer create(WSProductConstants bean);
//
//    /**
//     * 修改产品常量
//     *
//     * @param bean 入参
//     * @return 修改条数
//     */
//    Integer modify(WSProductConstants bean);
//
//    /**
//     * 根据主键删除产品常量
//     *
//     * @param primaryKey 主键id
//     * @return 删除条数
//     */
//    Integer delete(String primaryKey);
//
//    /**
//     * 根据条件查询产品常量
//     *
//     * @return 符合条件的产品常量集合
//     */
//    List<WSProductConstants> queryByCondition(WSQueryProductConstants request);
//}
