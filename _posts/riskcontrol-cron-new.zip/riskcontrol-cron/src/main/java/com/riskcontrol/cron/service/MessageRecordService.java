package com.riskcontrol.cron.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.cron.entity.TMessageRecord;

/**
 * <p>
 * 消息记录表 服务类
 * </p>
 *
 * @author Colson
 * @since 2023-10-16
 */
public interface MessageRecordService extends IService<TMessageRecord> {

    /**
     * 根据消息uuid获取消息揭露*
     *
     * @param uuid 消息uuid
     * @return -
     */
    TMessageRecord getMessageRecordByUUID(String uuid);


    /**
     * 根据加密手机号和flag = 17统计手机号更新次数
     *
     * @param phoneMd5 -
     * @return -
     */
    Long countByPhoneMd5AndFlag17(String phoneMd5);


    /**
     * 保存消息记录，外层判断uuid是否重复，避免重复添加数据 *
     *
     * @param msgBody -
     */
    void saveMessageRecord(String msgBody);

    /**
     * 检查该手机号是否需要加入黑名单 *
     *
     * @param msgBody -
     * @return -
     */
    void checkMessageRecord(String msgBody);


    /**
     * 根据消息uuid更新消费状态*
     *
     * @param uuid   uuid
     * @param status
     */
    void updateStatusByUUID(String uuid, Integer status);


    /**
     * 根据oldPhoneMd5查询flag=17的最后更新时间
     *
     * @param oldPhoneMd5 -
     * @return -
     */
    TMessageRecord getFlag17AndLatestByOldPhoneMd5(String oldPhoneMd5);

}
