package com.riskcontrol.cron.mapper;

import com.riskcontrol.common.entity.pojo.Ekyc;
import com.riskcontrol.cron.wrapper.LambdaQueryWrapperX;

import java.util.List;

public interface EkycMapper extends BaseMapperX<Ekyc> {

    /**
     * 根据用户名称查询ekyc主表信息
     *
     * @param loginName 账号
     * @return ekyc信息集
     */
    default List<Ekyc> queryListWithLoginName(String loginName) {
        return selectList(new LambdaQueryWrapperX<Ekyc>().eqIfHasText(Ekyc::getLoginName, loginName));
    }
}
