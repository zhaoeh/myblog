package com.riskcontrol.cron.mapper;

import com.riskcontrol.cron.entity.TMessageRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 消息记录表 Mapper 接口
 * </p>
 *
 * @author Colson
 * @since 2023-10-16
 */
public interface MessageRecordMapper extends BaseMapper<TMessageRecord> {

}
