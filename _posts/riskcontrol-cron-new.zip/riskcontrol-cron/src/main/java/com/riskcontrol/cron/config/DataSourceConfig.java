//package com.riskcontrol.cron.config;
//
//import com.intech.dbcryptor.Cryptor;
//import com.zaxxer.hikari.HikariDataSource;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.jdbc.DataSourceBuilder;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.core.annotation.Order;
//
//import javax.sql.DataSource;
//
//@Configuration
//@Order(1)
//public class DataSourceConfig {
//
//    private static final Logger logger = LoggerFactory.getLogger(DataSourceConfig.class);
//    @Value("${spring.datasource.url}")
//    private String url;
//    @Value("${spring.datasource.username}")
//    private String userName;
//    @Value("${spring.datasource.password}")
//    private String password;
//
//    @Value("${spring.datasource.driver-class-name}")
//    private String driverClassName;
//
//    @Value("${spring.datasource.hikari.idle-timeout:600000}")
//    private long idleTimeout;
//
//    @Value("${spring.datasource.hikari.connection-timeout:30000}")
//    private long connectionTimeout;
//
//    @Value("${spring.datasource.hikari.validation-timeout:5000}")
//    private long validationimeout;
//
//    @Value("${spring.datasource.hikari.connection-test-query:}")
//    private String connectionTestQuery;
//
//    @Value("${spring.datasource.hikari.max-lifetime:1765000}")
//    private long maxLifetime;
//
//    @Value("${spring.datasource.hikari.maximum-pool-size:10}")
//    private int maximumPoolSize;
//
//    @Value("${spring.datasource.hikari.minimum-idle:5}")
//    private int minimumIdle;
//
//    @Bean
//    public DataSource dataSource() {
//        String originalUsername = userName;
//        String originalPassword = password;
//        try {
//            originalUsername = Cryptor.decryptContent(originalUsername);
//        } catch (Exception e) {
//            logger.error("数据库用户名解密失败.", e);
//        }
//        try {
//            originalPassword = Cryptor.decryptContent(originalPassword);
//        } catch (Exception e) {
//            logger.error("数据库密码解密失败.", e);
//        }
//        HikariDataSource hikariDataSource = DataSourceBuilder.create().type(HikariDataSource.class)
//                .driverClassName(driverClassName)
//                .url(url).username(originalUsername).password(originalPassword).build();
//        hikariDataSource.setMaximumPoolSize(maximumPoolSize);
//        hikariDataSource.setMinimumIdle(minimumIdle);
//        hikariDataSource.setIdleTimeout(idleTimeout);
//        hikariDataSource.setConnectionTimeout(connectionTimeout);
//        hikariDataSource.setConnectionTestQuery(connectionTestQuery);
//        hikariDataSource.setMaxLifetime(maxLifetime);
//        hikariDataSource.setValidationTimeout(validationimeout);
//        return hikariDataSource;
//    }
//
//}
