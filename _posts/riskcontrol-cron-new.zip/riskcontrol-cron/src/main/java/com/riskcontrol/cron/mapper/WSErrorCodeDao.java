package com.riskcontrol.cron.mapper;

import com.cn.schema.other.WSErrorCode;
import com.cn.schema.other.WSQueryErrorCode;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;


/**
 * 错误码数据访问层
 *
 * @author Clide.L
 * @date 2018-11-08 15:42:01.
 */
@Repository
public interface WSErrorCodeDao {

    /**
     * 查询符合条件的数量
     *
     * @param query 查询条件
     * @return Integer 符合条件的数量
     * @throws Exception
     */
    Integer countByCondition(WSQueryErrorCode query);


    /**
     * 查询符合条件的信息分页
     *
     * @param query 查询条件
     * @return List<WSErrorCode> 错误码列表
     * @throws Exception
     */
    List<WSErrorCode> queryPageByCondition(WSQueryErrorCode query);


    /**
     * 根据ID查询信息
     *
     * @param primaryKeys 主键
     * @return WSErrorCode
     * @throws Exception
     */
    WSErrorCode loadById(Map<String, Object> primaryKeys);


    /**
     * 修改信息.返回操作结果
     *
     * @param bean 错误码
     * @return Integer
     * @throws Exception
     */
    Integer modify(WSErrorCode bean);


    /**
     * 新增信息.返回操作结果
     *
     * @param bean 错误码
     * @return Integer
     * @throws Exception
     */
    Integer create(WSErrorCode bean);


    /**
     * 删除信息.返回操作结果
     *
     * @param id
     * @return Integer
     * @throws Exception
     */
    Integer delete(String id);

    /**
     * 根据code查询
     *
     * @param errorCode
     * @return
     */
    WSErrorCode selectByCode(@Param("errorCode") String errorCode);

}