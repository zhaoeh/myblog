package com.riskcontrol.cron.utils;

import cn.hutool.core.util.StrUtil;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 负责产品常量key的转换
 *
 * @program: riskcontrol-cron
 * @description: 产品常量配置key转换器
 * @author: Erhu.Zhao
 * @create: 2023-10-26 09:55
 **/

public class ProductConstantHelper {

    /**
     * 风控产品常量key统一前缀
     */
    private static final String PRODUCT_CONSTANT_PREFIX = "r-";

    public static String buildProductConstantKey(String... params) {
        if (Objects.isNull(params)) {
            return null;
        }
        String beforeKey = packagePropertyKey(params);
        return toLowerCase(formatProductKey(beforeKey));
    }

    public static List<String> rollbackProductConstantKey(String configKey) {
        if (StringUtils.isBlank(configKey)) {
            return Collections.emptyList();
        }
        return Arrays.asList(configKey.split("\\.")).stream().
                map(ProductConstantHelper::removePrefixIfNeed).
                map(ProductConstantHelper::rollbackFormatProductKey).
                collect(Collectors.toList());
    }

    public static String obtainOriginalFieldByIndex(String configKey, int index) {
        List<String> originalFields = rollbackProductConstantKey(configKey);
        if (originalFields.size() > index) {
            return originalFields.get(index);
        }
        return null;
    }


    /**
     * 根据动态参数拼接key
     *
     * @param params 动态参数
     * @return key
     */
    private static String packagePropertyKey(String... params) {
        StringBuilder builder = new StringBuilder();
        Arrays.asList(params).stream().forEach(d -> {
            if (StringUtils.isBlank(d)) {
                return;
            }
            builder.append(appendPrefixIfNeed(StringUtils.trim(d))).append(".");
        });
        return builder.deleteCharAt(builder.length() - 1).toString();
    }

    public static String formatProductKey(String beforeKey) {
        return underline2CenterLineCase(camel2UnderlineCase(beforeKey));
    }

    public static String rollbackFormatProductKey(String afterKey) {
        return toUpperCase(centerLine2UnderlineCase(afterKey));
    }

    /**
     * 将字符串转为小写
     *
     * @param str 原始字符串
     * @return 转换后的字符串
     */
    public static String toLowerCase(String str) {
        if (StringUtils.isBlank(str)) {
            return str;
        }
        return str.toLowerCase();
    }

    /**
     * 将字符串转为大写
     *
     * @param str 原始字符串
     * @return 转换后的字符串
     */
    public static String toUpperCase(String str) {
        if (StringUtils.isBlank(str)) {
            return str;
        }
        return str.toUpperCase();
    }

    /**
     * 驼峰字符串转下划线
     *
     * @param camelCase 驼峰字符串
     * @return 下划线字符串
     */
    public static String camel2UnderlineCase(String camelCase) {
        return StrUtil.toUnderlineCase(camelCase);
    }

    /**
     * 下划线字符串转驼峰
     *
     * @param underlineCase 下划线字符串
     * @return 驼峰字符串
     */
    public static String underline2CamelCase(String underlineCase) {
        return StrUtil.toCamelCase(underlineCase);
    }

    /**
     * 替换原始字符串中的下划线为中划线
     *
     * @param underlineCase 原始字符串
     * @return 替换后的字符串
     */
    public static String underline2CenterLineCase(String underlineCase) {
        return Optional.ofNullable(underlineCase).map(ProductConstantHelper::replaceUnderline2CenterLine).orElse(underlineCase);
    }

    /**
     * 替换原始字符串中的中划线为下划线
     *
     * @param centerLineCase 原始字符串
     * @return 替换后的字符串
     */
    public static String centerLine2UnderlineCase(String centerLineCase) {
        return Optional.ofNullable(centerLineCase).map(ProductConstantHelper::replaceCenterLine2Underline).orElse(centerLineCase);
    }

    /**
     * 替换原始字符串中的下划线为中划线
     *
     * @param source 原始字符串
     * @return 替换后的字符串
     */
    private static String replaceUnderline2CenterLine(String source) {
        return source.replace("_", "-");
    }

    /**
     * 替换原始字符串中的中划线为下划线
     *
     * @param source
     * @return
     */
    private static String replaceCenterLine2Underline(String source) {
        return source.replace("-", "_");
    }

    /**
     * 根据条件向字符串添加前缀r_
     *
     * @param param 原始字符串
     * @return 处理后的字符串
     */
    private static String appendPrefixIfNeed(String param) {
        if (StringUtils.isNotBlank(param) && Character.isDigit(param.charAt(0))) {
            return PRODUCT_CONSTANT_PREFIX + param;
        }
        return param;
    }

    /**
     * 根据条件去除字符串前缀r_
     *
     * @param param 原始字符串
     * @return 处理后的字符串
     */
    private static String removePrefixIfNeed(String param) {
        if (StringUtils.isNotBlank(param) && param.contains(PRODUCT_CONSTANT_PREFIX) && Character.isDigit(param.charAt(PRODUCT_CONSTANT_PREFIX.length()))) {
            return param.substring(PRODUCT_CONSTANT_PREFIX.length());
        }
        return param;
    }
}
