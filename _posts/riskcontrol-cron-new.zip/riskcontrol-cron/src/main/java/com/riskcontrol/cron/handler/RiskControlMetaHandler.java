package com.riskcontrol.cron.handler;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import com.riskcontrol.common.utils.DateUtils;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Objects;

/**
 * @program: riskcontrol-cron
 * @description: mybatis-plus 自动填充
 * @author: Colson
 * @create: 2023-09-27 15:14
 */
@Component
public class RiskControlMetaHandler implements MetaObjectHandler {

    @Override
    public void insertFill(MetaObject metaObject) {
        null2Empty(metaObject);
        // 插入操作时，自动填充字段的值
        this.setFieldValByName("createTime", DateUtils.getCurrentDateTime(), metaObject);
        this.setFieldValByName("updateTime", DateUtils.getCurrentDateTime(), metaObject);
        this.setFieldValByName("lastUpdateTime", DateUtils.getCurrentDateTime(), metaObject);
        fillDate(metaObject, "createDate");
        fillDate(metaObject, "updateDate");
    }

    @Override
    public void updateFill(MetaObject metaObject) {
        // 更新操作时，自动填充字段的值
        this.setFieldValByName("updateTime", DateUtils.getCurrentDateTime(), metaObject);
        this.setFieldValByName("lastUpdateTime", DateUtils.getCurrentDateTime(), metaObject);
    }

    /**
     * 填充日期类型*
     *
     * @param metaObject
     * @param fieldName
     */
    private void fillDate(MetaObject metaObject, String fieldName) {
        if (metaObject.hasGetter(fieldName) && metaObject.getGetterType(fieldName) == Date.class) {
            this.setFieldValByName(fieldName, new Date(), metaObject);
        }
    }

    /**
     * null值转空串*
     *
     * @param metaObject
     */
    private void null2Empty(MetaObject metaObject) {
        for (String fieldName : metaObject.getGetterNames()) {
            Object value = this.getFieldValByName(fieldName, metaObject);
            if (Objects.isNull(value) && metaObject.hasSetter(fieldName) && metaObject.getGetterType(fieldName) == String.class) {
                this.setFieldValByName(fieldName, "", metaObject);
            }
        }
    }
}
