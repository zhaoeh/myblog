//package com.riskcontrol.cron.service;
//
//
//import com.cn.schema.products.WSProductConstants;
//import com.cn.schema.products.WSQueryProductConstants;
//import java.util.List;
//
//
///**
// * @Overview:其他功能的service接口
// */
//public interface OthersService {
//
//    /**
//     * 查询产品常量
//     *
//     * @param wsQueryProductConstants
//     * @return
//     */
//    List<WSProductConstants> getProductConstants(WSQueryProductConstants wsQueryProductConstants);
//
//    /**
//     * 查询产品常量
//     *
//     * @param type
//     * @return
//     */
//    List<WSProductConstants> getProductConstants(String type);
//
//    String getProductConstant(String type, String key);
//
//
//}
