package com.riskcontrol.cron.service.impl;

import com.cn.schema.other.WSErrorCode;
import com.cn.schema.other.WSQueryErrorCode;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.response.ErrResponse;
import com.riskcontrol.cron.mapper.WSErrorCodeDao;
import com.riskcontrol.cron.service.ErrService;
import com.riskcontrol.cron.utils.CommonLogic;
import com.riskcontrol.cron.utils.MultiProductUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ErrService实现
 *
 * @program: riskcontrol-cron
 * @description: 提供系统中全量的error info和国际化信息
 * @author: Erhu.Zhao
 * @create: 2023-10-17 18:26
 **/
@Service
@Slf4j
public class ErrServiceImpl implements ErrService {

    @Autowired
    WSErrorCodeDao wsErrorCodeDao;

    /**
     * 从T_ERROR表中加载错误码和对应的国际化信息
     *
     * @return 全量的error信息
     */
    @Override
    public Map<String, ErrResponse> provideErrInfo() {
        Map<String, ErrResponse> errMap = new HashMap<>();
        WSQueryErrorCode query = new WSQueryErrorCode();
        // 每一页大小
        int pageSize = 10000;
        // 第一页
        query.setPageNum(1);
        query.setPageSize(pageSize);
        query.setOrder("id");
        query.setProductId(MultiProductUtil.getDefaultProductId());
        loopToQueryError(query, errMap, pageSize);
        return errMap;
    }

    /**
     * 循环查询T_ERR表操作，直到读取数据末尾，将最终数据集加载到local cache中
     *
     * @param query    查询条件
     * @param errMap   错误信息收集器
     * @param pageSize 每页大小
     */
    private void loopToQueryError(WSQueryErrorCode query, Map<String, ErrResponse> errMap, int pageSize) {
        while (true) {
            if (doQueryError(query, errMap, pageSize)) {
                return;
            }
        }
    }

    /**
     * 查询T_ERR表数据
     *
     * @param query    查询条件
     * @param errMap   错误信息收集器
     * @param pageSize 每页大小
     * @return 当前pageNum指定的分页结果集
     */
    private boolean doQueryError(WSQueryErrorCode query, Map<String, ErrResponse> errMap, int pageSize) {
        boolean stopLoop = false;
        int pageNumSource = query.getPageNum();
        query.setPageNum(CommonLogic.buildFirstPageParamOfMySql(query.getPageNum(), query.getPageSize()));
        List<WSErrorCode> wsErrorCodeList = wsErrorCodeDao.queryPageByCondition(query);
        collectToErrMap(wsErrorCodeList, errMap);
        if (wsErrorCodeList.size() < pageSize) {
            stopLoop = true;
        }
        query.setPageNum(pageNumSource + 1);
        return stopLoop;
    }

    /**
     * 从wsErrorCodeList中遍历收集数据到errMap容器
     *
     * @param wsErrorCodeList wsErrorCodeList
     * @param errMap          errMap容器
     */
    private void collectToErrMap(List<WSErrorCode> wsErrorCodeList, Map<String, ErrResponse> errMap) {
        if (CollectionUtils.isNotEmpty(wsErrorCodeList)) {
            for (WSErrorCode errorCode : wsErrorCodeList) {
                ErrResponse errResponse = buildErrResponse(errorCode);
                errMap.put(Constant.ERR_CODE_MARK_PREFIX + errorCode.getErrorCode(), errResponse);
            }
        }
    }


    /**
     * 根据errorCode实体构建ErrResponse
     *
     * @param errorCode errorCode
     * @return ErrResponse instance
     */
    private ErrResponse buildErrResponse(WSErrorCode errorCode) {
        ErrResponse errResponse = new ErrResponse();
        errResponse.setErrCode(errorCode.getErrorCode());
        errResponse.setCn(errorCode.getMessageCn());
        errResponse.setEn(errorCode.getMessageEn());
        errResponse.setTh(errorCode.getMessageTh());
        errResponse.setVi(errorCode.getMessageVi());
        errResponse.setJa(errorCode.getMessageJa());
        return errResponse;
    }

}
