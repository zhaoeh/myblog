package com.riskcontrol.cron.service;

import com.cn.schema.creditlogs.*;

import java.util.List;

/**

 * @Overview:额度记录相关接口
 */
public interface CreditLogService {
    List<WSCreditLogs> getCreditLogs(WSQueryCreditLogs query);



}
