package com.riskcontrol.cron.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.request.label.RiskLabelBindingRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelByCustomerIdRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelListRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelRemoveBindingRequest;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelRsp;
import com.riskcontrol.cron.entity.TRiskLabelRelationship;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * <p>
 * 用户标签绑定关系表 服务类
 * </p>
 *
 * @author Yannis
 * @since 2024-01-11
 */
public interface TRiskLabelRelationshipService extends IService<TRiskLabelRelationship> {

    /**
     * 批量查询用户标签信息 *
     * @param request -
     * @return -
     */
    List<CustomerRiskLabelRsp> listCustomerRiskLabel(RiskLabelListRequest request);

    /**
     * 绑定用户风控标签 *
     * @param request -
     * @return -
     */
    Boolean bindingCustomerRiskLabel(RiskLabelBindingRequest request);

    /**
     * 获取用户风控标签详情 *
     * @param request
     * @return
     */
    CustomerRiskLabelRsp getRiskLabelDetail(RiskLabelByCustomerIdRequest request);

    /**
     * 根据用户名称查询风控标签
     * @param customerId
     * @return
     */
    List<TRiskLabelRelationship> queryByCustomerId(String customerId);

    /**
     * 根据用户id获取优先级最高的标签绑定的规则集合
     * @param customerId
     * @return
     */
    List<String> getCustomerLabelRules(@NotNull Long customerId);

    /**
     * 解除用户风控标签
     * @return
     */
    boolean removeLabel(RiskLabelRemoveBindingRequest request);
}
