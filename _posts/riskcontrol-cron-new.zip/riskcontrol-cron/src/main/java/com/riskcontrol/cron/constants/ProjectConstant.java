package com.riskcontrol.cron.constants;

/**
 * @Description: 产品常量key
 * @Auther: yannis
 * @create: 2023-10-28
 */
public class ProjectConstant {
    public static final String PRODUCT_CONSTANTS_C66 = "C66";
    public static final String PRODUCT_CONSTANTS_TYPE_0014 = "0014";
    public static final String PRODUCT_CONSTANTS_TYPE_0016 = "0016";
    public static final String PRODUCT_CONSTANTS_TYPE_0004 = "0004";
    public static final String PRODUCT_CONSTANTS_TYPE_0018 = "0018";
    public static final String PRODUCT_CONSTANTS_TYPE_0019 = "0019";

    /**
     * 0101：风控标签-常量类型*
     */
    public static final String PRODUCT_CONSTANTS_TYPE_RISK_LABEL_0101 = "0101";

    /**
     * 0102：风控ekyc标签类型*
     */
    public static final String PRODUCT_CONSTANTS_TYPE_RISK_LABEL_0102 = "0102";

    public static final String MESSAGE_PUSH_SWITCH = "MESSAGE_PUSH_SWITCH";

    public static final String MESSAGE_APPROVE_KYC_SWITCH = "MESSAGE_APPROVE_KYC_SWITCH";
//
//    public static final String DEPOSIT_COMPLETE_SWITCH = "DEPOSIT_COMPLETE_SWITCH";
//
//    public static final String DATE_AFTER_SMS_DECRYPTION = "DATE_AFTER_SMS_DECRYPTION";

    //PAY-27
    public static final String KYC_REQUEST_DONE = ":KYC_REQUEST_DONE:";
//
    public static final String SNOW_FLAKE_ID_SWITCH = "SNOW_FLAKE_ID_SWITCH";

    //    public static final String BRANCH_PERFORMANCE_CODE = "BRANCH_PERFORMANCE_CODE";

    public static final String DISPATCH_WEIGHT_MAXIMUM_ORDER_PER_SESSION = "MAXIMUM_ORDER_PER_SESSION";
    //首次取款的权重
//    public static final String DISPATCH_WEIGHT_FIRST_WITHDRAWAL = "THE_WEIGHT_OF_FIRST_WITHDRAWAL";
    // 门店取款的权重
//    public static final String DISPATCH_WEIGHT_BRANCH_WITHDRAW = "THE_WEIGHT_OF_BRANCH_WITHDRAW";
//
//    public static final String DISPATCH_WEIGHT_LARGE_WITHDRAWA = "THE_WEIGHT_OF_LARGE_WITHDRAWA";
//
//    public static final String THE_AMOUNT_OF_LARGE_WITHDRAWAL = "THE_AMOUNT_OF_LARGE_WITHDRAWAL";
//
//    public static final String DISPATCH_WEIGHT_RE_ASSINGMENT = "THE_WEIGHT_OF_RE_ASSINGMENT";
    // 超时几分钟的订单权重
//    public static final String DISPATCH_WEIGHT_ORDERS_EXCEED_MINUTES = "WEIGHT_ORDERS_EXCEED_MINUTES";
    //风控功能开关
    public static final String JMS_WITHDRAW_RISK ="JMS_WITHDRAW_RISK";
    //风控异步监听线程开关
    public static final String JMS_WITHDRAW_RISK_LISTENER_ASYNC ="WITHDRAW_RISK_LISTENER_ASYNC";
    //风控异步监听线程超时时间，单位：秒
    public static final String JMS_WITHDRAW_RISK_LISTENER_TIMEOUT ="WITHDRAW_RISK_LISTENER_OUT";
    //风控自动通过glife开关（0:关闭；1:开启）
    public static final String WITHDRAW_RISK_GLIFE_AUTO ="WITHDRAW_RISK_GLIFE_AUTO";
    //风控重审开关
    public static final String JMS_WITHDRAW_RISK_RETRY ="JMS_WITHDRAW_RISK_RETRY";
    //风控重审队列（0:kafka; 1:rabbitmq）
    public static final String JMS_WITHDRAW_RISK_RETRY_MQ ="JMS_WITHDRAW_RISK_RETRY_MQ";
    //风控系统切换开关
    public static final String WITHDRAW_RISK_CONTROL_SWITCH ="WITHDRAW_RISK_CONTROL_SWITCH";
    //会员有优惠且未投注时，取款转人工开关
    public static final String UNUSED_PROMOTION_ENABLED ="UNUSED_PROMOTION_ENABLED";
    //会员无优惠且未投注时，取款转人工 金额阈值
    public static final String MAX_UNUSED_PROMOTION_AMOUNT ="MAX_UNUSED_PROMOTION_AMOUNT";
    //系统连续通过的笔数或金额条件达到设定的值时，取款转人工 开关
    public static final String CONSECUTIVE_PASSES_ENABLED ="CONSECUTIVE_PASSES_ENABLED";
    //设置连续通过的笔数阈值
    public static final String MAX_CONSECUTIVE_PASSES ="MAX_CONSECUTIVE_PASSES";
    //设置通过的总金额阈值
    public static final String MAXIMUM_TOTAL_PASSED_AMOUNT ="MAXIMUM_TOTAL_PASSED_AMOUNT";
    //风控自动审批的开关，1是打开 0是关闭
    public static final String RISK_AUTO_APPROVE ="RISK_AUTO_APPROVE";
    //自动审批的最大限额，超过该值后即便满足条件也不会被审批
    public static final String RISK_AUTO_APPROVE_MAX_AMOUNT ="RISK_AUTO_APPROVE_MAX_AMOUNT";
    // 存取差(piso)
    public static final String DIFFERENCE ="difference";
    //盈利率(%)
    public static final String PROFIT ="profit";
    //盈利差额
    public static final String PROFIT_DIFFERENCE ="PROFIT_DIFFERENCE";
    //投注比(%)
    public static final String BET_RATE ="betRate";
    //取款限款(piso)
    public static final String TODAY_LIMIT ="todayLimit";
    //首次取款自动通过最大金额
    public static final String FIRST_WITHDRAWAL_CHECK_AMOUNT ="FIRST_WITHDRAWAL_CHECK_AMOUNT";
    public static final String MAX_CONSECUTIVE_MANUAL="MAX_CONSECUTIVE_MANUAL";  // 连续通过取款数量转人工阈值
    public static final String WD_MANUAL_MIN_NUM="WD_MANUAL_MIN_NUM";  // 单日取款次数超过x转人工
    public static final String WD_MANUAL_MIN_AMOUNT="WD_MANUAL_MIN_AMOUNT";  // 单日取款次数超过x转人工最小金额
    public static final String MANUAL_TYPE="MANUAL_TYPE";  // 转人工规则，多个','分割exceptionPromptType
    public static final String QUERY_BET_ENABLED="QUERY_BET_ENABLED";
    public static final String MAX_QUERY_DEPOSIT_DAYS= "MAX_QUERY_DEPOSIT_DAYS";//最大查询存款天数
    public static final String DEPOSIT_WITHDRAWAL_RATIO= "DEPOSIT_WITHDRAWAL_RATIO";//存取款倍率

    // Ekyc开关配置
    // zoloz结果为pedding时是否转人工（1:拒绝；2：转人工）证件和人脸通过，风控控制不通过转人工
    public static final String EKYC_PENDING_MANUAL = "EKYC_PENDING_MANUAL";
    // 证件重复转人工开关（1：开启；其他关闭）
    public static final String EKYC_ID_DUPLICATE = "EKYC_ID_DUPLICATE";
    // 证件重复转人工开关开启下，允许证件重复的最大限制，默认为1
    public static final String EKYC_ID_DUPLICATE_COUNT = "EKYC_ID_DUPLICATE_COUNT";

    // EKYC Extend扩展信息拒绝提示语key
    public static final String EKYC_REFUSE_AUTO_REASON = "EKYC_REFUSE_AUTO_REASON";
    // ekyc 证件重复 拒绝原因kcy
    public static final String EKYC_SAME_ID= "SAME_ID";
    // ekyc 年龄不符
    public static final String AGE_DOES_NOT_MATCH= "AGE_DOES_NOT_MATCH";
    //OTP消息发送开关（0:不发送,1:kafka; 2:rabbitmq）
    public static final String OTP_MQ_FLAG ="OTP_MQ_FLAG";
}
