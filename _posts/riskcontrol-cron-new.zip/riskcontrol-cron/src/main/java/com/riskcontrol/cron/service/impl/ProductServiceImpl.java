//package com.riskcontrol.cron.service.impl;
//
//import cn.hutool.core.date.DateUtil;
//import cn.hutool.core.date.TimeInterval;
//import com.riskcontrol.cron.constants.CronConstant;
//import com.riskcontrol.cron.constants.ProjectConstant;
//import com.riskcontrol.cron.mapper.ProductDao;
//import com.riskcontrol.cron.service.ProductService;
//import com.riskcontrol.cron.utils.RedisUtil;
//import org.apache.commons.collections4.CollectionUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
///**
// * 产品定义服务层实现类
// *
// * @author Wason.H
// * @date 2018-02-24 16:17:48.
// */
//@Service
//public class ProductServiceImpl implements ProductService {
//
//    protected final Logger logger = LoggerFactory.getLogger("webservice_api_logger");
//
//    @Autowired
//    private ProductDao productDao;
//    @Autowired
//    private RedisUtil redisUtil;
//
//
//    @Override
//    public List<String> getProductIds(String productId) {
//        logger.info("ProductServiceImpl getProductIds  productId={} start...", productId);
//        TimeInterval timer = DateUtil.timer();
//        // Redis主分组key
//        String redisGroupKey = RedisUtil.genRedisGroupKey(productId, CronConstant.WSRedisHash.PRODUCT_CONSTANTS);
//        String redisKey = RedisUtil.genRedisKey(productId, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0004, CronConstant.PRODUCT_PRODUCT_IDS);
//        List<String> result = null;
//
//        //判断是否使用新的 redis 缓存模式
////        boolean isNewCacheMode = redisUtil.isNewCacheMode(productId);
//        String newRedisKey = RedisUtil.genRedisKey(redisGroupKey, redisKey);
//
//        //首先从redis取值
////        if (isNewCacheMode && redisUtil.exists(newRedisKey)) {
//        result = redisUtil.get(newRedisKey, new ArrayList<String>().getClass());
//        logger.debug("Getting products value from redis,Key={}", redisKey);
////        } else if (redisUtil.hashexist(redisGroupKey, redisKey)) {
////            result = redisUtil.getHash(redisGroupKey, redisKey, new ArrayList<String>().getClass());
////            logger.debug("Getting products value from redis,Key={}",redisKey);
////        }
//
//        //如果redis没有取到值，从数据库取值
//        if (CollectionUtils.isEmpty(result)) {
//            logger.debug("Getting products value from db.t_products.");
//            result = productDao.queryAllProductId();
//
//            redisUtil.set(newRedisKey, result, CronConstant.WSRedisExpireTime.PRODUCT_CONSTANTS);
//        }
//        logger.info("ProductServiceImpl getProductIds  productId={} time={} end...", productId, timer.interval());
//        return Optional.ofNullable(result).orElse(new ArrayList<String>());
//    }
//
//}
