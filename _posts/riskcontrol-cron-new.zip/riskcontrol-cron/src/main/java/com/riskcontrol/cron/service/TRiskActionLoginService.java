package com.riskcontrol.cron.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.pojo.TRiskActionLogin;
import com.riskcontrol.common.entity.request.device.LoginCheckRequest;
import com.riskcontrol.common.entity.response.device.LoginCheckResponse;
import com.riskcontrol.common.enums.RiskActionTypeEnum;

public interface TRiskActionLoginService extends IService<TRiskActionLogin> {

    /**
     * 登陆风控检查
     */
    LoginCheckResponse loginCheck(LoginCheckRequest loginCheckRequest);

    /**
     * 设备指纹黑名单
     */
    boolean isDeviceBlack(String deviceFingerprint, String ipAddress, String loginName, String tenant, RiskActionTypeEnum ruleAction);

    /**
     * ip黑名单
     */
    boolean isIpBlack(String deviceFingerprint, String ipAddress, String loginName, String tenant, RiskActionTypeEnum ruleAction);

    /**
     * 设备指纹和ip的组合黑名单
     *
     */
    boolean isDeviceAndIpBlack(String deviceFingerprint, String ipAddress, String loginName, String tenant, RiskActionTypeEnum ruleAction);

    /**
     * 保存登陆风控明细和汇总
     */
    void saveRiskActionLogin(LoginCheckRequest loginCheckRequest, int interceptType);

    /**
     * 保存登陆和注册用户名到汇总表
     */
    void writeLoginNameToRedisAndDatabase(String ipAddress, String deviceFingerprint, String dateAt, String loginName, String tenent, RiskActionTypeEnum ruleAction);
}
