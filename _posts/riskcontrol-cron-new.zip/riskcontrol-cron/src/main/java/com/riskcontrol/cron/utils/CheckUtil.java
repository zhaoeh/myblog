//package com.riskcontrol.cron.utils;
//
//import com.google.common.base.Splitter;
//import com.riskcontrol.cron.config.BusinessConfig;
//import com.riskcontrol.cron.constants.CronConstant;
//import com.riskcontrol.cron.constants.ProjectConstant;
//import com.riskcontrol.cron.dao.BaseDao;
//import com.riskcontrol.cron.service.*;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.DependsOn;
//import org.springframework.stereotype.Component;
//import org.springframework.util.Assert;
//
//import javax.annotation.PostConstruct;
//import java.io.File;
//import java.net.InetAddress;
//import java.net.UnknownHostException;
//import java.util.List;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//
//@Component
//public class CheckUtil {
//    @Autowired
//    private BaseDao baseDAO;
//    private static List<String> pwdList = null;
//    @Autowired
//    protected WSProductsService wsproductsService;
//    @Autowired
//    protected WSOthersService wsOthersService;
//    private static List<String> siteLimitWebsList = null;
//
//    public static boolean checkDateRange(String temp) {
//        if (!isNotEmpty(temp)) {
//            return false;
//        }
//        if ("999".equals(temp)) {
//            return true;
//        }
//        String regex = "^[1-9][d,w,m,y,D,W,M,Y]$";
//
//        return match(regex, temp);
//    }
//    @Autowired
//    private ProductService productService;
//    private Boolean modeStrict = null;
//    @Value("${pwd:''}")
//    private String pwd;
//    @Value("${pwd1:}")
//    private String pwd1;
//    @Value("${pwd2:}")
//    private String pwd2;
//    @Value("${pwd3:}")
//    private String pwd3;
//    @Value("${pwd4:}")
//    private String pwd4;
//    @Value("${pwd5:}")
//    private String pwd5;
//
//    @Autowired
//    private BusinessConfig businessConfig;
//
//    private static final Logger logger = LoggerFactory.getLogger("webservice_api_logger");
//
//    /**
//     * 校验传入的字符串是否为空
//     *
//     * @param temp
//     * @return boolean 为空返回false,不为空返回true
//     */
//    public static boolean isNotEmpty(String temp) {
//        return null != temp && !"".equals(temp.trim());
//    }
//
//    public static boolean isEmpty(String temp) {
//        return null == temp || "".equals(temp.trim());
//    }
//
//
//    /**
//     * 正则表达式验证格式
//     *
//     * @param regex
//     * @param temp
//     * @return
//     */
//    public static boolean match(String regex, String temp) {
//        Pattern pattern = Pattern.compile(regex);
//        Matcher matcher = pattern.matcher(temp);
//        return matcher.matches();
//    }
//
//    @PostConstruct
//    public void init() {
//        //初始化密码组，暂时使用分开的方式，后期优化
//        StringBuilder allPwd = new StringBuilder();
//        allPwd.append(pwd);
//        appendIfNeed(allPwd, pwd1);
//        appendIfNeed(allPwd, pwd2);
//        appendIfNeed(allPwd, pwd3);
//        appendIfNeed(allPwd, pwd4);
//        appendIfNeed(allPwd, pwd5);
//        pwdList = Splitter.on(",").trimResults().splitToList(allPwd.toString());
//    }
//
//    /**
//     * 拼接密码
//     *
//     * @param source source
//     * @param appendStr 需要拼接的字串
//     */
//    private void appendIfNeed(StringBuilder source, String appendStr) {
//        if (org.apache.commons.lang3.StringUtils.isNotBlank(appendStr)) {
//            source.append(",").append(appendStr);
//        }
//    }
//
//
//    /**
//     * 验证用户传入的用户名密码是否匹配
//     *
//     * @param infProductId
//     * @param infPwd
//     * @param invokeClass  接口的class
//     */
//    public boolean checkPidAndPwd(String infProductId, String infPwd, Class invokeClass) {
//
//        Assert.notNull(infPwd, "Pwd can't be null");
//        Assert.notNull(infProductId, "ProductID can't be null");
//        // 产品ID必须存在T_PRODUCTS 中
//        String tempProductId = infProductId.contains(";") ? MultiProductUtil.getDefaultProductId() : infProductId;
//        List<String> productIds = productService.getProductIds(tempProductId);
//        if (!productIds.contains(tempProductId)) {
//            return false;
//        }
//        boolean strict = getPwdMode(tempProductId);
//        boolean canAccess = true;
//        String pakage = invokeClass.getPackage().getName();
//        try {
//            // 需要限制访问的来源应用
//            if (siteLimitWebsList != null) {
//                // 先解密， 判断来源
//                String mi = PrincipalEncryption.decrypt(infPwd, PrincipalEncryption.ENCRYPTION_KEY);
//                String sourceWeb = mi.split("!")[0];
//                // sport_website
//                for (String web : siteLimitWebsList) {
//                    // 限制访问的端，只能访问com.cm.endpoint.site下的接口
//                    if (!"".equals(web) && web.equals(sourceWeb) && !CronConstant.SITE_ACCESS_PAKAGE.equals(pakage)) {
//                        canAccess = false;
//                        break;
//                    }
//                }
//            }
//            if (!canAccess) {
//                return false;
//            }
//
//            if (!strict) {
//                return true;
//            }
//            if (null != pwdList) {
//                return pwdList.contains(infPwd);
//            }
//
//        } catch (Exception e) {
//            // 非严格校验下，只匹对密码本身
//            if (!strict) {
//                return true;
//            }
//            if (null != pwdList) {
//                return pwdList.contains(infPwd);
//            }
//        }
//        return false;
//    }
//
//
//    /*********************************** 身份证验证开始 ****************************************/
//    /**
//     * 身份证号码验证 1、号码的结构 公民身份号码是特征组合码,由十七位数字本体码和一位校验码组成.排列顺序从左至右依次为:六位数字地址码,
//     * 八位数字出生日期码,三位数字顺序码和一位数字校验码. 2、地址码(前六位数）
//     * 表示编码对象常住户口所在县(市、旗、区)的行政区划代码,按GB/T2260的规定执行. 3、出生日期码（第七位至十四位）
//     * 表示编码对象出生的年、月、日,按GB/T7408的规定执行,年、月、日代码之间不用分隔符. 4、顺序码（第十五位至十七位）
//     * 表示在同一地址码所标识的区域范围内,对同年、同月、同日出生的人编定的顺序号, 顺序码的奇数分配给男性,偶数分配给女性. 5、校验码（第十八位数）
//     * （1）十七位数字本体码加权求和公式 S = Sum(Ai * Wi), i = 0, , 16 ,先对前17位数字的权求和
//     * Ai:表示第i位置上的身份证号码数字值 Wi:表示第i位置上的加权因子 Wi: 7 9 10 5 8 4 2 1 6 3 7 9 10 5 8 4
//     * 2 （2）计算模 Y = mod(S, 11) （3）通过模得到对应的校验码 Y: 0 1 2 3 4 5 6 7 8 9 10 校验码: 1 0
//     * X 9 8 7 6 5 4 3 2
//     */
//
//    // 产品常量是否需要查表，等待确定，先使用nacos配置的方式将常量配置进去
////    private boolean getPwdMode(String productId) {
////        String val = "";
////        try {
////            WSQueryProductConstants query = new WSQueryProductConstants();
////            query.setAllData(true);
////            query.setType(Constant.PRODUCT_CONSTANTS_TYPE_0004);
////            query.setKey("WS_APPLICATION_STRICT");
////            query.setProductId(productId);
////            List<WSProductConstants> list = wsproductsService.queryProductConstants(baseDAO, query);
////            if (list != null && !list.isEmpty()) {
////                val = list.get(0).getValue();
////            }
////        } catch (Exception e) {
////        }
////        modeStrict = "1".equals(val);
////
////        return modeStrict;
////    }
//    private boolean getPwdMode(String productId) {
////        String propertyKey = StringUtils.trim(productId) + "." + CronConstant.PRODUCT_CONSTANTS_TYPE_0004.trim() + "." + CronConstant.WS_APPLICATION_STRICT.trim();
////        String val = productConstantsConfig.getPropertyByKey(propertyKey);
//        String val = ProductConstantsLoader.obtainProductConstant(productId, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0004, CronConstant.WS_APPLICATION_STRICT);
//        modeStrict = "1".equals(val);
//        return modeStrict;
//    }
//
//    /**
//     * 校验hostName是否为容器启动：true=是容器启动；false=不是容器启动。如下规则：
//     * ws-679b959c75-x4h9v
//     * ws-55799b6975-9kbll
//     *
//     * @return
//     */
//    public static boolean checkIsContainerBootingByHostName() {
//        boolean isK8SHost = false;
//        boolean isJarRun = false;
//        try {
//            InetAddress localhost = InetAddress.getLocalHost();
//            logger.info("current boot server hostName:{}", localhost.getHostName());
//            logger.info("current boot server hostAddress:{}", localhost.getHostAddress());
//            String regex = "^.{1,}-[A-Za-z0-9]{3,15}-[a-z0-9]{5}$";
//            isK8SHost = CheckUtil.match(regex, localhost.getHostName());
//        } catch (UnknownHostException e) {
//            logger.error("Can not load system host name, shut down the application.");
//            System.exit(0);
//        }
//        if (isK8SHost) {
//            logger.info("check current boot server is running by k8s container.");
//        }
//        String path = new File(CheckUtil.class.getResource("/").getPath()).getPath();
//        if (path.indexOf("!") != -1) {
//            logger.info("check current boot server is running by jar.");
//            isJarRun = true;
//        }
//        return isK8SHost || isJarRun;
//    }
//
//
//}
