package com.riskcontrol.cron.template;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.nacos.common.utils.StringUtils;
import com.cn.schema.customers.WSCustomers;
import com.cn.schema.customers.WSCustomersBank;
import com.cn.schema.customers.WSQueryCustomers;
import com.cn.schema.customers.WSQueryCustomersBank;
import com.riskcontrol.common.config.UserCenterSwitch;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.request.ApiQueryCustomersRequest;
import com.riskcontrol.common.entity.request.kyc.RiskUpdateKycRequestRequest;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.service.UserCenterTemplate;
import com.riskcontrol.common.service.WsFeignTemplate;
import com.riskcontrol.common.utils.LogUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;


@Slf4j
@Component
public class WsApiFeignTemplate {

    @Resource
    private UserCenterTemplate userCenterTemplate;
    @Resource
    private WsFeignTemplate wsFeignTemplate;
    public WsApiFeignTemplate() {
    }

    /**
     * 获取customers
     *
     * @param updateKycRequestRequest 请求
     * @return 响应
     */
    public List<WSCustomers> loadCustomers(RiskUpdateKycRequestRequest updateKycRequestRequest) {
        KycRequest kycRequest = updateKycRequestRequest.getWsKycRequest();
        try {
            ApiQueryCustomersRequest request = ApiQueryCustomersRequest.builder().
                    requestUUID(StringUtils.isBlank(updateKycRequestRequest.getRequestUUID()) ? LogUtils.generatedThreadUUID() : updateKycRequestRequest.getRequestUUID()).
                    customerId(kycRequest.getCustomerId()).infProductId(updateKycRequestRequest.getInfProductId()).
                    infPwd(updateKycRequestRequest.getInfPwd()).wsQueryCustomers(buildWSQueryCustomers(kycRequest)).build();
            log.info("[loadCustomers method] loadCustomers request={}", JSONObject.toJSONString(request));
            return loadCustomers(request);
        } catch (Exception ex) {
            if (BusinessException.class.isInstance(ex)) {
                log.error("[loadCustomers method] loadCustomers userCenter response error! error is :", ex);
                return Collections.emptyList();
            }
            log.error("[loadCustomers method] 调用RiskControl-API接口异常，loadCustomers错误", ex);
            throw new BusinessException(ResultEnum.RISK_API_EXCEPTION);
        }
    }

    private WSQueryCustomers buildWSQueryCustomers(KycRequest kycRequest) {
        WSQueryCustomers wsQueryCustomers = new WSQueryCustomers();
        wsQueryCustomers.setProductId(kycRequest.getProductId());
        wsQueryCustomers.setLoginName(kycRequest.getLoginName());
        return wsQueryCustomers;
    }

    public List<WSCustomers> loadCustomers(ApiQueryCustomersRequest req) {
        return Optional.ofNullable(UserCenterSwitch.getSwitch()).filter(Boolean::booleanValue).map(e -> {
            log.info("[loadCustomers] begin to call userCenterTemplate to load customers.");
            List<WSCustomers> result = new ArrayList<>();
            result.add(userCenterTemplate.queryCustomersBySingle(req));
            return result;
        }).orElseGet(() -> {
            log.info("[loadCustomers] begin to call wsFeignTemplate to load customers.");
            return wsFeignTemplate.queryCustomersBySingle(req);
        });
    }
    public WSCustomers getSimpleCustomerByLoginName(String productId, String loginName){
        return Optional.ofNullable(UserCenterSwitch.getSwitch()).filter(Boolean::booleanValue).
                map(e -> userCenterTemplate.getSimpleCustomerByLoginName(productId, loginName)).
                orElseGet(() -> wsFeignTemplate.getCustomerByLoginName(productId, loginName));
    }

    public List<WSCustomersBank> getSimpleCustomerByBank(String loginName) {
        WSQueryCustomersBank wsQueryCustomersBank = new WSQueryCustomersBank();
        wsQueryCustomersBank.setFlag("0;1;9");
        wsQueryCustomersBank.setLoginName(loginName);
        wsQueryCustomersBank.setProductId(Constant.C66_PRODUCT_ID);
        wsQueryCustomersBank.setDeleteFlag("0");
        return wsFeignTemplate.queryCustomerBanks(wsQueryCustomersBank);
    }

}
