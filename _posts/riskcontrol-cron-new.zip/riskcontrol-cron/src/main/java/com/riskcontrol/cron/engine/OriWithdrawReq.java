package com.riskcontrol.cron.engine;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class OriWithdrawReq {
    private String lastWithDrawalDate;
    private String productId;
    private String loginName;
    private String createdDate;
    private BigDecimal amount;
    private String requestId;
    private String flag;
    private String catalog;
    private String firstWithdrawal;
    private String parent;//查询用户信息获取
    private BigDecimal lastWithDrawalBalance;
    private String customerId;
    private String cardFirstWithdrawFlag;
    private String siteId;
    private String currency;
    private String customerType;
    private String endPointType;
    private String exceptionPromptType;
    private String exceptionPrompt;
    private OriWithdrawReqContext context = new OriWithdrawReqContext();

}
