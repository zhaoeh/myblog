package com.riskcontrol.cron.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.riskcontrol.common.entity.pojo.TRiskActionRegistration;
import com.riskcontrol.common.entity.request.device.RegisterCheckRequest;
import com.riskcontrol.common.entity.request.device.RegisterSaveRequest;
import com.riskcontrol.common.entity.response.device.RegisterCheckResponse;

public interface TRiskActionRegistrationService extends IService<TRiskActionRegistration> {

    /**
     * 注册风控检查
     */
    RegisterCheckResponse registerCheck(RegisterCheckRequest registerCheckRequest);

    /**
     * 保存注册明细和汇总
     */
    boolean registerSave(RegisterSaveRequest registerSaveRequest, int interceptType);

}