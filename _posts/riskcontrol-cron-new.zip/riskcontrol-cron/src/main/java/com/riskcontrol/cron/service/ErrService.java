package com.riskcontrol.cron.service;

import com.riskcontrol.common.entity.response.ErrResponse;

import java.util.Map;

public interface ErrService {

    /**
     * 提供error info
     *
     * @return 系统中全量的error info 和 国际化信息
     */
    Map<String, ErrResponse> provideErrInfo();
}
