package com.riskcontrol.cron.kafka;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.common.annotation.LogUUID;
import com.riskcontrol.cron.service.EkycBlackForPbcService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

/**
 * @author: sanji
 * @desc: 新老kyc通过监听判断是否在pbc黑名单（队列与优惠消息一致）
 * @date: 2024/8/14 17:31
 */
@Component
@Slf4j
public class KycApproveListener {

    @Autowired
    private EkycBlackForPbcService pbcService;

    @KafkaListener(topics = {KafkaTopic.APPROVE_KYC_TOPIC_SELF},groupId = "group_risk_kyc_self",
            containerFactory = "batchFactory",  errorHandler = "myConsumerAwareErrorHandler")
    @LogUUID
    public void kycApproveListener(JSONObject msg, Acknowledgment ack) {
        try {
            String loginName = msg.getString("loginName");
            boolean isOldKyc = msg.getBoolean("isOldKyc");
            //todo 校验kyc通过的账号是否在黑名单
            pbcService.handleEkycBlackForPbc(loginName, isOldKyc);
        } catch (Exception e) {
            log.info("kycApproveListener 校验黑名单异常，msg：{}", JSONObject.toJSONString(msg), e);
        }finally {
            ack.acknowledge();
        }
    }

}
