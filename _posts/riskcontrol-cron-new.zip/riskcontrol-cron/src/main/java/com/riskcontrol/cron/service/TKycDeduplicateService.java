package com.riskcontrol.cron.service;

import com.riskcontrol.cron.entity.TKycDeduplicate;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author dante
* @description 针对表【t_kyc_deduplicate(kyc证件去重表)】的数据库操作Service
* @createDate 2024-06-11 09:51:40
*/
public interface TKycDeduplicateService extends IService<TKycDeduplicate> {

}
