package com.riskcontrol.cron.service;

import com.riskcontrol.common.entity.zoloz.EkycContext;

/**
 * @description: ekyc完善扩展信息接口
 * @author: ErHu.Zhao
 * @create: 2024-10-09
 **/
public interface EkycExtendService {

    /**
     * 执行审核通过策略*
     *
     * @param context
     * @return
     */
    Boolean doActionOfEkycApproval(EkycContext context);

    /**
     * 执行拒绝策略*
     *
     * @param context
     * @return
     */
    Boolean doActionOfEkycReject(EkycContext context);

    /**
     * 执行转人工策略*
     *
     * @param context
     * @return
     */
    Boolean doActionOfEkycManual(EkycContext context);
}
