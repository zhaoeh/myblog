package com.riskcontrol.cron.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.cm.util.common.Constants;
import com.cn.schema.common.RabbitMQMessage;
import com.cn.schema.customers.WSCustomers;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.pojo.Ekyc;
import com.riskcontrol.common.entity.pojo.EkycDeduplicate;
import com.riskcontrol.common.entity.pojo.EkycRequest;
import com.riskcontrol.common.entity.request.ekyc.*;
import com.riskcontrol.common.entity.zoloz.EkycContext;
import com.riskcontrol.common.entity.zoloz.ResultStatusStr;
import com.riskcontrol.common.enums.EkycApprovalStrategy;
import com.riskcontrol.common.enums.EkycChannelEnum;
import com.riskcontrol.common.enums.EkycStatusEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.utils.CommonUtil;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.common.utils.MapUtil;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.constants.ProjectConstant;
import com.riskcontrol.cron.kafka.KafkaTopic;
import com.riskcontrol.cron.mapper.EkycDeduplicateMapper;
import com.riskcontrol.cron.mapper.EkycMapper;
import com.riskcontrol.cron.mapper.EkycRequestMapper;
import com.riskcontrol.cron.service.EkycExtendService;
import com.riskcontrol.cron.service.EkycRequestService;
import com.riskcontrol.cron.template.WsApiFeignTemplate;
import com.riskcontrol.cron.utils.KafkaProductUtils;
import com.riskcontrol.cron.utils.ProductConstantsLoader;
import com.riskcontrol.cron.utils.RabbitMQUtils;
import com.riskcontrol.cron.utils.RedisUtil;
import com.riskcontrol.cron.wrapper.LambdaQueryWrapperX;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Function;

import static com.riskcontrol.common.constants.Constant.RISK_EKYC_STATUS_KEY;
import static com.riskcontrol.common.enums.EkycApprovalStrategy.STRATEGY_APPROVAL;
import static com.riskcontrol.common.enums.ResultEnum.*;

/**
 * @description: 查询ekyc用户状态信息实现
 * @author: ErHu.Zhao
 * @create: 2024-10-07
 **/
@Service
@Slf4j
public class EkycRequestServiceImpl implements EkycRequestService {

    /**
     * ekyc完善信息请求操作策略容器*
     */
    private Map<EkycApprovalStrategy, Function<EkycContext, Boolean>> strategyWithEkyc;

    @Autowired
    private RedisUtil redisUtil;

    @Resource
    private EkycMapper ekycMapper;

    @Resource
    private EkycRequestMapper ekycRequestMapper;

    @Resource
    private EkycDeduplicateMapper ekycDeduplicateMapper;

    @Autowired
    private EkycExtendService extendService;

    @Resource
    private WsApiFeignTemplate wsApiFeignTemplate;

    @Resource
    private KafkaProductUtils kafkaProductUtils;

    /**
     * 初始化执行策略*
     */
    @PostConstruct
    public void init() {
        strategyWithEkyc = Map.of(STRATEGY_APPROVAL, extendService::doActionOfEkycApproval,
                EkycApprovalStrategy.STRATEGY_REJECT, extendService::doActionOfEkycReject,
                EkycApprovalStrategy.STRATEGY_MANUAL, extendService::doActionOfEkycManual);
    }

    @Override
    public Ekyc queryEkycStatus(String loginName) {
        return ekycMapper.queryListWithLoginName(loginName).stream().findFirst().orElse(null);
    }

    @Override
    public EkycRequest queryCurrentKycRequest(String loginName) {
        EkycQueryRequest param = new EkycQueryRequest();
        param.setAccount(loginName);
        param.setChannelId(EkycChannelEnum.MANUAL.getChannelId());
        return ekycRequestMapper.queryCurrentKycRequest(param);
    }

    @Override
    public EkycRequest queryEkycRequest(BigInteger id) {
        return ekycRequestMapper.selectById(id);
    }

    @Override
    public Boolean modifyEkycRequest(EkycExtendRequest request) {
        EkycRequest ekycRequest = Optional.ofNullable(queryEkycRequest(new BigInteger(request.getRequestId()))).map(exists -> {
            request.setLoginName(exists.getLoginName());
            return exists;
        }).orElseThrow(() -> {
            throw new BusinessException(EKYC_REQUEST_NOT_EXIST);
        });

        // 校验DB中的状态
        this.checkStatus(ekycRequest.getStatus());
        // 校验请求中的年龄
        Boolean checkAge = checkAge(request.getBirthday(), (logInfo, format) ->
                log.info("ekyc校验年龄，当前用户：{}，requestId是：{}，billNo是：{}，日志对象为：{}", ekycRequest.getLoginName(), request.getRequestId(), ekycRequest.getBillNo(), format));

        // ekyc是否通过
        Boolean isApprovalWithThirdPart = isApproval(ekycRequest.getEkycResult(), (logInfo, format) ->
                log.info("ekyc判断三方系统是否审核通过，当前用户：{}，requestId是：{}，billNo是：{}，日志对象为：{}", ekycRequest.getLoginName(), request.getRequestId(), ekycRequest.getBillNo(), format));
        Boolean isPending = null;
        Boolean isReject = null;
        if (BooleanUtils.isFalse(isApprovalWithThirdPart)) {
            // 是否被拒绝
            isReject = isReject(ekycRequest.getEkycResult(), (logInfo, format) ->
                    log.info("ekyc判断三方系统是否审核拒绝，当前用户：{}，requestId是：{}，billNo是：{}，日志对象为：{}", ekycRequest.getLoginName(), request.getRequestId(), ekycRequest.getBillNo(), format));
            // 没成功也没拒绝，进行isPending查询
            if (BooleanUtils.isFalse(isReject)) {
                // 直接拒绝还是转人工
                isPending = isPending(ekycRequest.getEkycResult(), (logInfo, format) ->
                        log.info("ekyc判断三方系统是否需要转人工，当前用户：{}，requestId是：{}，billNo是：{}，日志对象为：{}", ekycRequest.getLoginName(), request.getRequestId(), ekycRequest.getBillNo(), format));
            }
        }

        // 关键信息是否被修改
        Boolean isModified = isModifiedOfEkyc(request, ekycRequest);
        // 当前请求中的证件号是否达到重复使用次数
        Boolean isDeduplicateLimit = isDeduplicateLimit(request.getIdNo(), ekycRequest.getIdType(), (logInfo, format) ->
                log.info("eky校验证件重复使用次数，当前用户：{}的idNo为：{}，idType为：{}，requestId是：{}，billNo是：{}，日志对象为：{}", ekycRequest.getLoginName(), request.getIdNo(), ekycRequest.getIdType(), request.getRequestId(), ekycRequest.getBillNo(), format));

        // 构建上下文
        EkycContext context = new EkycContext();
        context.setValidateAge(checkAge).setApprovalWithThirdPart(isApprovalWithThirdPart).setReject(isReject).
                setPending(isPending).setModified(isModified).setDeduplicateLimit(isDeduplicateLimit).
                setEkycRequest(ekycRequest).setEkycExtendRequest(request);
        EkycApprovalStrategy strategy = EkycApprovalStrategy.switchStrategy(context, this::switchStrategy);
        return Optional.ofNullable(strategyWithEkyc.get(strategy)).map(v -> {
            log.info("ekyc完善扩展信息，当前用户：{}，requestId是：{}，billNo是：{}，执行策略：{}", ekycRequest.getLoginName(), request.getRequestId(), ekycRequest.getBillNo(), strategy);
            boolean result = v.apply(context);
            if (STRATEGY_APPROVAL.equals(strategy) && result) {
                // 审核通过发送消息 todo:待确认使用kafka还是继续使用rabbit?
                this.pushApprovalMessage(context.getUpWsCustomers(), Objects.toString(EkycStatusEnum.APPROVAL.getEkycStatus()));
            }
            return result;
        }).orElseThrow(() -> {
            throw new BusinessException(EKYC_STRATEGY_ERROR);
        });
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean createEkycRequest(EkycCreateRequest request) {
        EkycRequest ekycRequest = new EkycRequest();
        ekycRequest.setLoginName(request.getLoginName());
        ekycRequest.setCustomerId(request.getCustomerId());
        ekycRequest.setChannel(request.getChannel());
        ekycRequest.setTenant(request.getTenant());
        ekycRequest.setEkycTransactionId(request.getTransactionId());
        ekycRequest.setIdType(request.getIdType());
        ekycRequest.setStatus(EkycStatusEnum.INIT_0.getEKycReqStatus());
        ekycRequest.setBillNo(request.getBillNo());
        ekycRequest.setCreateBy(request.getLoginName());
        ekycRequestMapper.insert(ekycRequest);

        // 用户第一次创建提案且ekyc主表无记录，则新增一条主表信息
        Ekyc ekycEntity = ekycMapper.selectOne(Ekyc::getLoginName, request.getLoginName());
        Ekyc ekyc = new Ekyc();
        ekyc.setStatus(EkycStatusEnum.INIT_1.getEkycStatus());
        String loginName = request.getLoginName();
        if (Objects.isNull(ekycEntity)) {
            ekyc.setLoginName(request.getLoginName());
            ekyc.setCustomerId(request.getCustomerId());
            ekyc.setChannel(request.getChannel());
            ekyc.setTenant(request.getTenant());
            ekyc.setCreateBy(loginName);
            ekycMapper.insert(ekyc);
        } else {
            ekyc.setId(ekycEntity.getId());
            ekyc.setUpdateBy(loginName);
            ekycMapper.updateById(ekyc);
        }
        return true;
    }

    @Override
    public Boolean saveVerificationInfo(EkycUpdateRequest request) {
        String loginName = request.getLoginName();
        EkycRequest ekycRequest = new EkycRequest();
        BeanUtil.copyProperties(request, ekycRequest);
        ekycRequest.setUpdateBy(loginName);
        ekycRequest.setStatus(EkycStatusEnum.INIT_1.getEKycReqStatus());
        ekycRequestMapper.updateById(ekycRequest);
        return true;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean updateEkycStatus(EkycZolozErrorRequest request) {
        EkycRequest ekycRequest = new EkycRequest();
        ekycRequest.setId(request.getRequestId());
        ekycRequest.setUpdateBy(request.getLoginName());
        ekycRequest.setStatus(EkycStatusEnum.FAILURE.getEKycReqStatus());
        ekycRequest.setEkycResultDate(request.getEkycResultDate());
        ekycRequest.setEkycResult(request.getEkycResult());
        ekycRequestMapper.updateById(ekycRequest);
        LambdaUpdateWrapper<Ekyc> updateWrapper = new LambdaUpdateWrapper<>();
        updateWrapper.set(Ekyc::getStatus, EkycStatusEnum.FAILURE.getEkycStatus())
                .set(Ekyc::getUpdateBy, request.getLoginName())
                .eq(Ekyc::getLoginName, request.getLoginName())
                .ne(Ekyc::getStatus, EkycStatusEnum.APPROVAL.getEkycStatus());
        ekycMapper.update(null, updateWrapper);
        redisUtil.remove(String.format(RISK_EKYC_STATUS_KEY, request.getLoginName()));
        return true;
    }

    /**
     * 校验ekyc提案状态是否为待完善*
     *
     * @param status
     * @return
     */
    private EkycRequestServiceImpl checkStatus(Integer status) {
        if (!Objects.equals(status, EkycStatusEnum.INIT_1.getEKycReqStatus())) {
            throw new BusinessException(EKYC_REQUEST_INVALIDATED_STATUS);
        }
        return this;
    }

    /**
     * 校验用户年龄*
     *
     * @param birthday 生日
     * @param action   动作器
     * @return 是否合法 true：年龄合法 false：年龄非法
     */
    private Boolean checkAge(String birthday, @Nullable BiConsumer<Map<String, Object>, String> action) {
        Boolean validAge = Boolean.FALSE;
        Integer age = DateUtils.calcAgeByBirthday(birthday);
        if (Objects.nonNull(age)) {
            // 校验用户年龄是否超过21岁 1.生日有效 2.年龄大于等于21 两者同时满足，认为年龄符合规则
            if (age >= Constant.VALIDATE_AGE) {
                validAge = Boolean.TRUE;
            }
        }
        return CommonUtil.doAction(validAge, action, MapUtil.of("birthday", birthday, "age", age, "validAge", validAge));
    }

    /**
     * 判断ekyc三方系统是否审核通过*
     *
     * @param ekycResult
     * @return true:审核通过 false：其他状态
     */
    private Boolean isApproval(String ekycResult, @Nullable BiConsumer<Map<String, Object>, String> action) {
        Boolean isApproval = ResultStatusStr.SUCCESS.equals(ekycResult) || ResultStatusStr.RISK_SAME_FACE_OR_ID.equals(ekycResult);
        return CommonUtil.doAction(isApproval, action, MapUtil.of("isApproval", isApproval, "ekycResult", ekycResult));
    }

    /**
     * 判断ekyc三方系统是否审核拒绝*
     *
     * @param ekycResult
     * @param action     操作器
     * @return true：审核拒绝 false：其他状态
     */
    private Boolean isReject(String ekycResult, @Nullable BiConsumer<Map<String, Object>, String> action) {
        Boolean isReject = ResultStatusStr.FAILURE.equals(ekycResult) || ResultStatusStr.PENDING.equals(ekycResult);
        return CommonUtil.doAction(isReject, action, MapUtil.of("isReject", isReject, "ekycResult", ekycResult));
    }

    /**
     * 需要转人工还是拒绝*
     *
     * @param ekycResult
     * @return true：转人工  false：拒绝 null：忽略
     */
    private Boolean isPending(String ekycResult, @Nullable BiConsumer<Map<String, Object>, String> action) {
        Boolean isRiskPending = null;
        String switchOfPending = null;
        if (ResultStatusStr.RISK_PENDING.equals(ekycResult)) {
            switchOfPending = ProductConstantsLoader.obtainProductConstantRedis(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0018, ProjectConstant.EKYC_PENDING_MANUAL);
            // 开关打开，直接拒绝；开关关闭，走人工
            isRiskPending = CronConstant.ENABLED.equals(switchOfPending) ? Boolean.FALSE : Boolean.TRUE;
        }
        return CommonUtil.doAction(isRiskPending, action, MapUtil.of("isRiskPending", isRiskPending, "switchOfPending", switchOfPending, "ekycResult", ekycResult));
    }

    /**
     * ekyc提案信息是否被修改
     *
     * @param request
     * @param ekycRequest
     * @return true：被修改  false：未修改
     */
    private Boolean isModifiedOfEkyc(EkycExtendRequest request, EkycRequest ekycRequest) {
        String sourceFirstName = StringUtils.trim(request.getFirstName());
        String sourceMiddleName = StringUtils.trim(request.getMiddleName());
        String sourceLastName = StringUtils.trim(request.getLastName());
        String sourceBirthday = StringUtils.trim(request.getBirthday());
        String sourceIdNo = StringUtils.trim(request.getIdNo());

        String targetFirstName = StringUtils.trim(ekycRequest.getFirstName());
        String targetMiddleName = StringUtils.trim(ekycRequest.getMiddleName());
        String targetLastName = StringUtils.trim(ekycRequest.getLastName());
        String targetBirthday = StringUtils.trim(ekycRequest.getBirthday());
        String targetIdNo = StringUtils.trim(ekycRequest.getIdNo());

        boolean firstNameChange = !StringUtils.equalsIgnoreCase(sourceFirstName, targetFirstName);
        boolean middleNameChange = !StringUtils.equalsIgnoreCase(sourceMiddleName, targetMiddleName);
        boolean lastNameChange = !StringUtils.equalsIgnoreCase(sourceLastName, targetLastName);
        boolean birthdayChange = !StringUtils.equals(sourceBirthday, targetBirthday);
        boolean idNoChange = !StringUtils.equals(sourceIdNo, targetIdNo);
        // 关键信息被修改
        Boolean isModified = firstNameChange || middleNameChange || lastNameChange || birthdayChange || idNoChange;

        log.info("ekyc完善扩展信息，当前用户{}入参中关键信息为：{}，requestId是：{}，billNo是：{}，DB中的关键信息为：{}，是否被修改：{}",
                request.getLoginName(), JSONObject.toJSONString(request), request.getRequestId(), ekycRequest.getBillNo(), JSONObject.toJSONString(ekycRequest), isModified);
        return isModified;
    }

    /**
     * 判断当前证件号是否达到使用重复上限*
     *
     * @param idNo
     * @return
     */
    private Boolean isDeduplicateLimit(String idNo, Integer idType, @Nullable BiConsumer<Map<String, Object>, String> action) {
        // 账号是否到达重复使用上限
        Boolean isDeduplicateLimit = Boolean.FALSE;
        // 校验证件号重复使用开关
        String switchOfLimit = ProductConstantsLoader.obtainProductConstantRedis(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0018, ProjectConstant.EKYC_ID_DUPLICATE);
        Long limitCount = null;
        EkycDeduplicate deduplicate = null;
        Long usedUserCount = null;
        if (CronConstant.ENABLED.equals(switchOfLimit)) {
            limitCount = obtainLimitCount();
            // 开关打开，获取证件号重复上限次数
            deduplicate = ekycDeduplicateMapper.selectOne(new LambdaQueryWrapperX<EkycDeduplicate>().
                    eqIfHasText(EkycDeduplicate::getIdNo, idNo).eqIfPresent(EkycDeduplicate::getIdType, idType));
            // 获取使用该账号的用户个数（去重复）
            usedUserCount = Optional.ofNullable(deduplicate).map(EkycDeduplicate::getLoginName).map(s -> Arrays.stream(s.split(";")).distinct().count()).orElse(0L);
            isDeduplicateLimit = usedUserCount > limitCount;
        }
        // 开关关闭，则不限制重复使用
        return CommonUtil.doAction(isDeduplicateLimit, action, MapUtil.of("isDeduplicateLimit", isDeduplicateLimit, "switchOfLimit", switchOfLimit, "limitCount", limitCount, "usedUserCount", usedUserCount, "deduplicate", deduplicate));
    }

    /**
     * 获取证件号重复上限次数*
     *
     * @return
     */
    private long obtainLimitCount() {
        long count = 0;
        String limitCount = ProductConstantsLoader.obtainProductConstantRedis(ProjectConstant.PRODUCT_CONSTANTS_C66, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0018, ProjectConstant.EKYC_ID_DUPLICATE_COUNT);
        try {
            count = Integer.valueOf(limitCount);
        } catch (Exception e) {
            log.info("获取EKYC_ID_DUPLICATE_COUNT失败，取默认值 {}", count);
            return count;
        } finally {
            if (count < 0) {
                count = 0;
            }
        }
        return count;
    }

    /**
     * 获取ws客户信息*
     *
     * @param context ekyc上下文
     * @return ws客户信息
     */
    private WSCustomers obtainWSCustomers(EkycContext context) {
        String loginName = context.getLoginName();
        log.info("ekyc从ws获取客户信息，productId是：{}，loginName是：{}，requestId是：{}，billNo是：{}", Constants.C66, loginName, context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo());
        WSCustomers wsCustomers = wsApiFeignTemplate.getSimpleCustomerByLoginName(Constants.C66, loginName);
        return Optional.ofNullable(wsCustomers).map(ws -> {
            log.info("ekyc从ws获取客户信息，productId是：{}，loginName是：{}，requestId是：{}，billNo是：{},ws返回为：{}", Constants.C66, loginName, context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo(), JSONObject.toJSONString(ws));
            context.setOriWsCustomers(ws);
            return ws;
        }).orElseThrow(() -> {
            log.error("ekyc补充信息报错，ws不存在用户，当前用户：{}，requestId是：{}，billNo是：{},WSCustomers:{}", context.getLoginName(), context.getEkycExtendRequest().getRequestId(), context.getEkycRequest().getBillNo(), JSONObject.toJSONString(wsCustomers));
            throw new BusinessException(EKYC_USER_NOT_EXISTS_ERROR);
        });
    }

    /**
     * 根据上下文选择策略*
     *
     * @param context 上下文
     * @return 策略对象
     */
    private EkycApprovalStrategy switchStrategy(EkycContext context) {
        // 1.年龄非法 2.ekyc三方拒绝 3.证件号码重复使用达到上限 4.risk_pending 是拒绝  走拒绝策略
        if (BooleanUtils.isFalse(context.getValidateAge()) || BooleanUtils.isTrue(context.getReject()) ||
                BooleanUtils.isTrue(context.getDeduplicateLimit()) || BooleanUtils.isFalse(context.getPending())) {
            return EkycApprovalStrategy.STRATEGY_REJECT.then(() -> obtainWSCustomers(context));
        }
        // 1.ekyc三方审核通过  2.核心字段无修改 3.证件号码重复使用没有达到上限     走通过策略
        if (BooleanUtils.isTrue(context.getApprovalWithThirdPart()) && BooleanUtils.isFalse(context.getModified()) &&
                BooleanUtils.isFalse(context.getDeduplicateLimit())) {
            return STRATEGY_APPROVAL.then(() -> obtainWSCustomers(context));
        }
        // 1.isPending打开  2.核心字段被修改  3.兜底 走转人工策略
        return EkycApprovalStrategy.STRATEGY_MANUAL;
    }

    /**
     * 审核通过推送消息*
     *
     * @param wsCustomers
     * @param kycStatus
     */
    private void pushApprovalMessage(WSCustomers wsCustomers, String kycStatus) {
        JSONObject request = RabbitMQUtils.buildCustomerKycStatusParams(wsCustomers, kycStatus);
        log.info("ekyc补充信息审核通过，推送Message，request : {}", request);
        String mqSwitch = ProductConstantsLoader.obtainProductConstantRedis(Constant.C66_PRODUCT_ID, ProjectConstant.PRODUCT_CONSTANTS_TYPE_0004, ProjectConstant.MESSAGE_APPROVE_KYC_SWITCH);
        if("1".equals(mqSwitch)){
            RabbitMQUtils.sendCustomerUpdateKyc(request);
        }else if("2".equals(mqSwitch)){
            RabbitMQMessage<JSONObject> message = new RabbitMQMessage<>(RabbitMQUtils.EXCHANGE_ENUM.CUSTOMER_UPDATE_KYC.getRoutingKey(), request);
            kafkaProductUtils.pushKafkaMsg(KafkaTopic.APPROVE_KYC_TOPIC,JSONObject.toJSONString(message));
        }else{
            log.info("sendCustomerUpdateKyc MESSAGE_PUSH_APPROVE_KYC_SWITCH is close");
        }
        //单独尝试一条风控自己消费的消息
        JSONObject selfObject = new JSONObject();
        selfObject.put("loginName",wsCustomers.getLoginName());
        selfObject.put("productId",wsCustomers.getProductId());
        selfObject.put("isOldKyc",false);//用来判断是否老kyc
        kafkaProductUtils.pushKafkaMsg(KafkaTopic.APPROVE_KYC_TOPIC_SELF,selfObject.toJSONString());
    }

}
