package com.riskcontrol.cron.po;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.util.List;

@Getter
@Setter
@Accessors(chain = true)
public class RiskDeviceTenantCacheInfo {

    /**
     * 产品标识(BP, AP, GP, PG, SP)
     */
    private String tenant;

    /**
     * 分产品记录登录的用户
     */
    private List<String> loginNameList;

    /**
     * 规则限制行为(0:登录, 1:注册)
     */
    private Integer actionType;

//    /**
//     * 设备指纹
//     */
//    private String deviceFingerprint;
//
//    /**
//     * IP地址
//     */
//    private String ipAddress;
//
//    /**
//     * 汇总日期(精度: 天)
//     */
//    private String dateAt;
}
