package com.riskcontrol.cron.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;

import com.riskcontrol.common.annotation.Query;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;

/**
 * <p>
 * 风控常量表
 * </p>
 *
 * @author Yannis
 * @since 2024-01-11
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("t_risk_constants")
@ApiModel(value = "TRiskConstants对象", description = "风控常量表")
public class TRiskConstants extends BasePersonFullEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("所属产品")
    private String productId;

    @ApiModelProperty("常量key")
    private String pKey;

    @ApiModelProperty("常量Type")
    private String pType;

    @ApiModelProperty("常量值")
    private String pValue;

    @ApiModelProperty("描述")
    private String remarks;

    @ApiModelProperty("ip地址")
    private String ipAddress;

    @ApiModelProperty("标志:0-未启用；1-已启用")
    private Integer isEnable;

    @ApiModelProperty("是否删除：0-否 ；1-是")
    private Integer isDeleted;

}
