package com.riskcontrol.cron.service;

import com.alibaba.fastjson.JSONObject;

/**
 * @program: riskcontrol-cron
 * @description: redis常用操作服务
 * @author: Erhu.Zhao
 * @create: 2023-11-17 11:15
 */
public interface RedisOperationService {
    /**
     * 操作redis
     *
     * @param request redis请求
     * @return 操作完毕后响应
     */
    JSONObject processRedisAction(JSONObject request);
}