package com.riskcontrol.cron.config;

import cn.hutool.core.thread.BlockPolicy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Async;

import java.util.concurrent.*;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/8/14 17:51
 */
@Configuration
@Async
@Slf4j
public class WithdrawAsyncConfig {

    @Autowired
    private WithdrawPropertiesConfig config;

    /**
     * 取款任务线程池，负责执行取款任务，指定阻塞队列300，指定自定义饱和策略
     *
     * @return
     */
    @Bean("withdrawExecutorService")
    public ThreadPoolExecutor init() {
        log.info("创建取款风控线程池 withdrawBlockQueueSize={}， withdrawCorePoolSize={} ，withdrawMaximumPoolSize={}", config.getWithdrawBlockQueueSize(), config.getWithdrawCorePoolSize(), config.getWithdrawMaximumPoolSize());
        return buildThreadPoolExecutor(config.getWithdrawBlockQueueSize());
    }

    /**
     * 取款异步超时任务线程池，负责执行任务线程池中超时的任务，指定阻塞队列为300，指定自定义饱和策略
     *
     * @return
     */
    @Bean("withdrawExecutorTimeOutService")
    public ThreadPoolExecutor initTimeOutThreadPool() {
        log.info("创建取款风控监听器线程池 withdrawBlockQueueSize={}，withdrawCorePoolSize={} ，withdrawMaximumPoolSize={}", config.getWithdrawBlockQueueSize(), config.getWithdrawCorePoolSize(), config.getWithdrawMaximumPoolSize());
        return buildThreadPoolExecutor(config.getWithdrawBlockQueueSize());
    }


    /**
     * 构建取款线程池
     *
     * @param capacity 阻塞队列容量大小
     * @return 线程池
     */
    private ThreadPoolExecutor buildThreadPoolExecutor(int capacity) {
        return new ThreadPoolExecutor(config.getWithdrawCorePoolSize(), config.getWithdrawMaximumPoolSize(),
                0L, TimeUnit.MILLISECONDS,
                capacity < 1 ? new LinkedBlockingQueue<>() : new LinkedBlockingQueue<>(capacity),
                new BlockPolicy());
    }

}
