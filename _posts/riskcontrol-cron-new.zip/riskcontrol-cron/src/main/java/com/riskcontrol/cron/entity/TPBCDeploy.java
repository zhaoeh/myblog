package com.riskcontrol.cron.entity;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotNull;
import java.math.BigInteger;

/*** @program: riskcontrol-cron
 ** @description: PBC配置文件
 ** @author: hongwei
 ** @create: 2023-11-13 14:47
 **/

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@TableName("t_pbc_deploy")
@ApiModel(value = "TPBCDeploy对象", description = "PBC配置文件")
public class TPBCDeploy {

    @ApiModelProperty("id")
    @NotNull(message = "id cannot be null")
    protected BigInteger id;

    @ApiModelProperty("抓取系统id")
    @NotNull(message = "systemId cannot be null")
    protected String systemId;

    @ApiModelProperty("抓取系统名称")
    protected String systemName;

    @ApiModelProperty("域名地址")
    protected String mainAddress;
    @ApiModelProperty("二级域名地址")
    protected String subAddress;
    @ApiModelProperty("用户名")
    protected String userName;
    @ApiModelProperty("密码")
    protected String password;
    @ApiModelProperty("开始时间")
    @NotNull(message = "start time cannot be null")
    protected String startTime;
    @ApiModelProperty("停止时间")
    @NotNull(message = "end time cannot be null")
    protected String endTime;
    @ApiModelProperty("抓取频率")
    @NotNull(message = "frequency cannot be null")
    protected String frequency;
    @ApiModelProperty("配置状态 1 enable  2 disable")
    protected String status;
    @ApiModelProperty("创建时间")
    protected String createDate;
    @ApiModelProperty("创建修改人")
    protected String createBy;
    @ApiModelProperty("修改时间")
    protected String updateDate;
    @ApiModelProperty("最后修改人")
    protected String updateBy;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("修改时间")
    protected String deleteDate;
    @ApiModelProperty("删除人")
    protected String deleteBy;
    @ApiModelProperty("是否有效Y 有效 N无效")
    protected String isValid;


}
