package com.riskcontrol.cron.service;


import com.riskcontrol.common.entity.request.api.PBCDeployDisableRequest;
import com.riskcontrol.common.entity.request.api.PBCDeployUpdateRequest;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.api.PBCDeployRsp;

import java.util.List;

public interface TPBCDeployService{


    /**
     * 查询配置文件列表
     *
     * @return
     */
    List<PBCDeployRsp> getPBCDeployList();

    /**
     * 修该配置文件
     * @param deployUpdateRequest
     * @return
     */
    Response<Boolean> updateDeploy(PBCDeployUpdateRequest deployUpdateRequest);

    /**
     * 停止PBC爬虫配置文件
     * @param deployUpdateRequest
     * @return
     */
    Response<Boolean> disableDeploy(PBCDeployDisableRequest deployUpdateRequest);

}
