package com.riskcontrol.cron.service.impl;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.riskcontrol.common.entity.request.api.PBCDeployDisableRequest;
import com.riskcontrol.common.entity.request.api.PBCDeployUpdateRequest;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.api.PBCDeployRsp;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.utils.DateUtils;
import com.riskcontrol.cron.datasource.DBSourceCheck;
import com.riskcontrol.cron.datasource.DataSourceType;
import com.riskcontrol.cron.entity.TPBCDeploy;
import com.riskcontrol.cron.mapper.TPBCDeployMapper;
import com.riskcontrol.cron.service.TPBCDeployService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/*** @program: riskcontrol-cron
 ** @description: 查询配置文件
 ** @author: hongwei
 ** @create: 2023-11-13 15:20
 **/
@Service
@Slf4j
public class TPBCDeployServiceImpl implements TPBCDeployService {

    @Resource
    private TPBCDeployMapper tpbcDeployMapper;
    @DBSourceCheck(DataSourceType.SLAVE)
    @Override
    public List<PBCDeployRsp> getPBCDeployList() {
        List<TPBCDeploy> deployList = tpbcDeployMapper.selectLists();
        List<PBCDeployRsp> deployRsps = new ArrayList<>();
        for (TPBCDeploy deploy : deployList) {
            PBCDeployRsp deployRsp = new PBCDeployRsp();
            deployRsp.setId(deploy.getId());
            deployRsp.setSystemId(deploy.getSystemId());
            deployRsp.setSystemName(deploy.getSystemName());
            deployRsp.setMainAddress(deploy.getMainAddress());
            deployRsp.setSubAddress(deploy.getSubAddress());
            deployRsp.setUserName(deploy.getUserName());
            deployRsp.setPassword(deploy.getPassword());
            deployRsp.setStartTime(deploy.getStartTime());
            deployRsp.setEndTime(deploy.getEndTime());
            deployRsp.setFrequency(deploy.getFrequency());
            deployRsp.setStatus(deploy.getStatus());
            deployRsp.setCreateDate(deploy.getCreateDate());
            deployRsp.setCreateBy(deploy.getCreateBy());
            deployRsp.setUpdateBy(deploy.getUpdateBy());
            deployRsp.setUpdateDate(deploy.getUpdateDate());
            deployRsp.setDeleteBy(deploy.getDeleteBy());
            deployRsp.setDeleteDate(deploy.getDeleteDate());
            deployRsps.add(deployRsp);
        }
        return deployRsps;
    }

    @Override
    public Response<Boolean> updateDeploy(PBCDeployUpdateRequest tpbcDeploy) {
        Response<Boolean> response = new Response<>();
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        LocalTime startTime = LocalTime.parse(tpbcDeploy.getStartTime(), dateTimeFormatter);
        LocalTime endTime = LocalTime.parse(tpbcDeploy.getEndTime(), dateTimeFormatter);
        if (Integer.valueOf(tpbcDeploy.getFrequency()) < 15 || Integer.valueOf(tpbcDeploy.getFrequency()) > 60) {
            log.error("参数校验错误！原因是：{}", ResultEnum.BAD_REQUEST.getMessage(new Object[0]));
            response.setHead(ResultEnum.BAD_REQUEST.getCode(new Object[0]).toString(), "Query frequency between 15 and 60");
            response.setBody(Boolean.FALSE);
        } else if (!startTime.isBefore(endTime)) {
            log.error("参数校验错误！原因是：{}", ResultEnum.BAD_REQUEST.getMessage(new Object[0]));
            response.setHead(ResultEnum.BAD_REQUEST.getCode(new Object[0]).toString(), "Start time before end time");
            response.setBody(Boolean.FALSE);
        } else if (tpbcDeploy.getUserName() == null || tpbcDeploy.getUserName().isEmpty() || tpbcDeploy.getUserName().length() > 20) {
            log.error("参数校验错误！原因是：{}", ResultEnum.BAD_REQUEST.getMessage(new Object[0]));
            response.setHead(ResultEnum.BAD_REQUEST.getCode(new Object[0]).toString(), "Username cannot empty or exceed 20 characters");
            response.setBody(Boolean.FALSE);
        } else if (tpbcDeploy.getPassword() == null || tpbcDeploy.getPassword().isEmpty()) {
            log.error("参数校验错误！原因是：{}", ResultEnum.BAD_REQUEST.getMessage(new Object[0]));
            response.setHead(ResultEnum.BAD_REQUEST.getCode(new Object[0]).toString(), "Password cannot empty");
            response.setBody(Boolean.FALSE);
        } else if (tpbcDeploy.getUpdateBy() == null || tpbcDeploy.getUpdateBy().isEmpty()) {
            log.error("参数校验错误！原因是：{}", ResultEnum.BAD_REQUEST.getMessage(new Object[0]));
            response.setHead(ResultEnum.BAD_REQUEST.getCode(new Object[0]).toString(), "Update user cannot empty");
            response.setBody(Boolean.FALSE);
        } else if (tpbcDeploy.getId() == null || tpbcDeploy.getSystemId() == null || tpbcDeploy.getSystemId().isEmpty()) {
            log.error("参数校验错误！原因是：{}", ResultEnum.BAD_REQUEST.getMessage(new Object[0]));
            response.setHead(ResultEnum.BAD_REQUEST.getCode(new Object[0]).toString(), ResultEnum.BAD_REQUEST.getMessage());
            response.setBody(Boolean.FALSE);
        } else {
            UpdateWrapper<TPBCDeploy> updateWrapper = new UpdateWrapper<>();
            updateWrapper.eq("id", tpbcDeploy.getId()).eq("system_id", tpbcDeploy.getSystemId()).set("delete_date", null);
            TPBCDeploy updateDeploy = TPBCDeploy.builder()
                    .userName(tpbcDeploy.getUserName())
                    .password(tpbcDeploy.getPassword())
                    .startTime(tpbcDeploy.getStartTime())
                    .endTime(tpbcDeploy.getEndTime())
                    .frequency(tpbcDeploy.getFrequency())
                    .status("1")
                    .updateBy(tpbcDeploy.getUpdateBy())
                    .updateDate(DateUtils.getCurrentDateTime(DateUtils.DATE_TIME_FORMAT))
                    .deleteBy("")
                    .build();
            if (tpbcDeployMapper.update(updateDeploy, updateWrapper) < 1) {
                response.setHead(ResultEnum.BAD_REQUEST.getCode(), "modify false");
            }
        }
        return response;
    }

    @Override
    public Response<Boolean> disableDeploy(PBCDeployDisableRequest tpbcDeploy) {
        Response<Boolean> response = new Response<>();
        UpdateWrapper<TPBCDeploy> updateWrapper = new UpdateWrapper<>();

        if (tpbcDeploy.getId() == null || tpbcDeploy.getSystemId() == null || tpbcDeploy.getSystemId().isEmpty()) {
            log.error("参数校验错误！原因是：{}", ResultEnum.BAD_REQUEST.getMessage(new Object[0]));
            response.setHead(ResultEnum.BAD_REQUEST.getCode(new Object[0]).toString(), ResultEnum.BAD_REQUEST.getMessage());
            response.setBody(Boolean.FALSE);
        } else if (tpbcDeploy.getDeleteBy() == null || tpbcDeploy.getDeleteBy().isEmpty()) {
            log.error("参数校验错误！原因是：{}", ResultEnum.BAD_REQUEST.getMessage(new Object[0]));
            response.setHead(ResultEnum.BAD_REQUEST.getCode(new Object[0]).toString(), "Delete user cannot empty");
            response.setBody(Boolean.FALSE);
        } else {
            updateWrapper.eq("id", tpbcDeploy.getId())
                    .eq("system_id", tpbcDeploy.getSystemId()).set("start_time", null).set("end_time", null);
            TPBCDeploy updateDeploy = TPBCDeploy.builder()
                    .userName("")
                    .password("")
                    .status("0")
                    .frequency("15")
                    .deleteBy(tpbcDeploy.getDeleteBy())
                    .deleteDate(DateUtils.getCurrentDateTime(DateUtils.DATE_TIME_FORMAT))
                    .build();
            if (tpbcDeployMapper.update(updateDeploy, updateWrapper) < 1) {
                response.setHead(ResultEnum.BAD_REQUEST.getCode(), "modify false");
            }
        }
        return response;
    }


}
