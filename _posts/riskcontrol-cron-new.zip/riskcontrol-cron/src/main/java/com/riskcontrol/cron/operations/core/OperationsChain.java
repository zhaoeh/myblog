package com.riskcontrol.cron.operations.core;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.cron.operations.ops.Ops;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @program: riskcontrol-cron
 * @description: Operations链式
 * @author: Erhu.Zhao
 * @create: 2023-11-17 12:19
 */
@Component
public class OperationsChain {

    private static OperationsAdaptor operationsAdaptor;

    @Autowired
    public OperationsChain(OperationsAdaptor operationsAdaptor) {
        OperationsChain.operationsAdaptor = operationsAdaptor;
    }

    public static ParserConfigurer opsMap(Map<String, Ops> opsMap) {
        return new ParserConfigurer(opsMap);
    }

    public static class ParserConfigurer {
        private Map<String, Ops> opsMap;

        public ParserConfigurer(Map<String, Ops> opsMap) {
            this.opsMap = opsMap;
        }

        public Processor parser(OperationParser operationParser) {
            return new Processor(operationParser, this.opsMap);
        }
    }

    public static class Processor {
        private OperationParser operationParser;
        private Map<String, Ops> opsMap;

        public Processor(OperationParser operationParser, Map<String, Ops> opsMap) {
            this.operationParser = operationParser;
            this.opsMap = opsMap;
        }

        public ClearDo process(JSONObject operation) {
            return OperationsChain.operationsAdaptor.process(this.opsMap, this.operationParser, operation);
        }
    }

    public static class ClearDo {
        private OperationParser operationParser;
        private JSONObject result;

        public ClearDo(OperationParser operationParser, JSONObject result) {
            this.operationParser = operationParser;
            this.result = result;
        }

        public ResultBuilder clear() {
            this.operationParser.clearCache();
            return new ResultBuilder(result);
        }
    }

    public static class ResultBuilder {
        private JSONObject result;

        public ResultBuilder(JSONObject result) {
            this.result = result;
        }

        public JSONObject result() {
            return this.result;
        }
    }


}