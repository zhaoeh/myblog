package com.riskcontrol.cron.operations.ops;

import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * @program: riskcontrol-cron
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-11-17 11:33
 */
@Component
public class OpsForSet extends OpsFor implements Ops {

    @Override
    public String operation() {
        return "opsForSet";
    }

    public long add(Serializable key, Object[] args) {
        return this.redisTemplate.opsForSet().add(key, args);
    }

    public Object pop(Serializable key) {
        return this.redisTemplate.opsForSet().pop(key);
    }
}