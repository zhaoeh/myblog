package com.riskcontrol.cron;

import cn.hutool.core.lang.UUID;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cn.schema.creditlogs.QueryDepositTransWithCheckResponse;
import com.cn.schema.creditlogs.WSCreditLogs;
import com.cn.schema.creditlogs.WSQueryCreditLogs;
import com.cn.schema.customers.WSCustomers;
import com.cn.schema.request.QueryWithdrawalRequestsResponse;
import com.cn.schema.request.WSQueryCountPAmount;
import com.cn.schema.request.WSResponseApprove;
import com.cn.schema.request.WSWithdrawalRequests;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.constants.ProjectConstant;
import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.entity.TRiskLabelRelationship;
import com.riskcontrol.cron.rabbit.WithdrawApplyListener;
import com.riskcontrol.cron.service.CreditLogService;
import com.riskcontrol.cron.service.RequestService;
import com.riskcontrol.cron.service.TRiskLabelRelationshipService;
import com.riskcontrol.cron.service.WithdrawService;
import com.riskcontrol.cron.support.WithdrawServiceDelegate;
import com.riskcontrol.cron.template.WsApiFeignTemplate;
import com.riskcontrol.cron.utils.ProductConstantsLoader;
import com.riskcontrol.cron.utils.RedisUtil;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.platform.commons.util.StringUtils;
import org.mockito.ArgumentMatcher;
import org.mockito.InjectMocks;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.doReturn;

@ActiveProfiles("test")
@SpringBootTest
@AutoConfigureMockMvc
class RiskcontrolCronApplicationTests {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Resource
    private AmqpTemplate rabbitTemplate;
    @MockBean
    private RedisUtil redisUtil;
    @Test
    void contextLoads() {
        Map<String,String> conMap = redisUtil.entries("r-" + ProjectConstant.PRODUCT_CONSTANTS_TYPE_0016);
        System.out.printf("conMap========"+conMap);
    }

    @Resource
    private MockMvc mockMvc;
    @MockBean
    private RequestService requestService;

    @MockBean
    private WsApiFeignTemplate wsApiFeignTemplate;

    @MockBean
    private CreditLogService creditLogService;
    @Resource
    @InjectMocks
    private WithdrawApplyListener withdrawApplyListener;
    @Resource
    private WithdrawService withdrawService;

    @MockBean
    private TRiskLabelRelationshipService labelRelationshipService;

    @Test
    public void withdrawRiskSend() throws Exception {
        JSONObject messageContent = new JSONObject();
        messageContent.put("amount", "10");
        messageContent.put("flag", "0");
        messageContent.put("productId", "C66");
        messageContent.put("lastWithDrawalBalance", "406");
        messageContent.put("catalog", "12");
        messageContent.put("majorLoginName", "bingoplus4k7cz8");
        messageContent.put("endPointType", "2");
        messageContent.put("lastWithDrawalDate", "2023-09-06 18:59:34");
        messageContent.put("customerType", "1");
        messageContent.put("createdDate", "2023-09-07 16:57:48");
        messageContent.put("cardFirstWithdrawFlag", "0");
        messageContent.put("requestId", "1699708536406626304");
        messageContent.put("loginName", "bingoplus4k7cz8");
        messageContent.put("customerId", "1022500720");
        messageContent.put("currency", "PHP");
        messageContent.put("firstWithdrawal", "0");

        JSONObject messageJson = new JSONObject();
        messageJson.put("msgContent", messageContent);
        messageJson.put("routingKey", "customer.withdraw.apply");

        String jsonString = JSON.toJSONString(messageJson);
        Message message = MessageBuilder.withBody(jsonString.getBytes())
//                .setContentType("text/json")
                .setContentType(MessageProperties.CONTENT_TYPE_JSON)//todo
                .build();

        logger.info("============ 发送取款申请消息 ============");
        logger.info("消息内容：{}", jsonString);
//        rabbitTemplate.convertAndSend("exchange_withdraw_apply", "C66.customer.withdraw.apply", message);
//        rabbitTemplate.convertAndSend("exchange_withdraw_apply_test", "C66.customer.withdraw.apply.test", message);
//        FlowBus.getNode("globleCheckNode").isAccess(0);

//        Thread.sleep(1000000l);
    }
    @Test
    public void withdrawRisk() throws Exception {
        MDC.put("uuid", UUID.randomUUID().toString());
        //取款消息内容
        OriWithdrawReq req = new OriWithdrawReq();
        req.setRequestId("12423434");
        req.setProductId("C66");
        //模拟查询存款
        QueryDepositTransWithCheckResponse depositRes = new QueryDepositTransWithCheckResponse();
        depositRes.setAmount("3000");
        doReturn(depositRes).when(requestService).queryDepositTransRecord(any());
        //模拟查询剩余额度
        List<WSCreditLogs> dstAmountList = new ArrayList<>();
        WSCreditLogs dstAmount = new WSCreditLogs();
        dstAmount.setDstAmount("5.875");
        dstAmount.setTransCode("2");
        dstAmountList.add(dstAmount);
        doReturn(dstAmountList).when(creditLogService).getCreditLogs(argThat(new ArgumentMatcher<WSQueryCreditLogs>() {
            @Override
            public boolean matches(WSQueryCreditLogs argument) {
                return StringUtils.isNotBlank(argument.getReferenceId());
            }
        }));
        //模拟查询修正额度
        List<WSCreditLogs> fixAmountList = new ArrayList<>();
        WSCreditLogs fixAmount = new WSCreditLogs();
        fixAmount.setAmount("0");
        fixAmount.setTransCode("2");
        fixAmountList.add(fixAmount);
        doReturn(fixAmountList).when(creditLogService).getCreditLogs(argThat(new ArgumentMatcher<WSQueryCreditLogs>() {
            @Override
            public boolean matches(WSQueryCreditLogs argument) {
                return StringUtils.isNotBlank(argument.getTransCode());
            }
        }));
        //模拟查询优惠金额
        WSQueryCountPAmount wsQueryCountPAmount = new WSQueryCountPAmount();
        wsQueryCountPAmount.setSumAmount("0");
        doReturn(wsQueryCountPAmount).when(requestService).getCountReportPromotion(any());

        //模拟查询投注汇总
        doReturn(new BigDecimal[]{new BigDecimal("0"),new BigDecimal("0")})
                .when(requestService).getValidAccountAndWinOrLostAmount(any(),any(),any(),any());
        //模拟查询取款记录
        QueryWithdrawalRequestsResponse mockWithDrawRes = new QueryWithdrawalRequestsResponse();
        List<WSWithdrawalRequests> withdrawalRequestsList = new ArrayList<>();
        WSWithdrawalRequests wsWithdrawal = new WSWithdrawalRequests();
        wsWithdrawal.setExceptionPromptType("0");//自动通过
        wsWithdrawal.setCreatedDate("2024-05-07 08:57:40");
        wsWithdrawal.setAmount("3000");
        wsWithdrawal.setFlag("1");
        withdrawalRequestsList.add(wsWithdrawal);
        wsWithdrawal = new WSWithdrawalRequests();
        wsWithdrawal.setExceptionPromptType("1");//非自动通过
        wsWithdrawal.setCreatedDate("2024-05-07 08:57:40");
        wsWithdrawal.setAmount("10000");
        wsWithdrawal.setFlag("1");
        withdrawalRequestsList.add(wsWithdrawal);
        mockWithDrawRes.setWsWithdrawalRequests(withdrawalRequestsList);
        doReturn(mockWithDrawRes).when(requestService).queryWithdrawalRequestDesc(any());
        //mock修改调用修改ws接口
        doReturn(true).when(requestService).modifyExceptionPrompt(any());
        doReturn(new WSResponseApprove()).when(requestService).requestApprove(any());
        //验证是否通过拦截

        Assert.assertEquals(true,withdrawService.withdrawRisk(req, true,false));
    }

    /**
     * 针对新增的LabelAndMpCheckNode节点的测试
     */
    @Test
    void withdrawRiskLabel() throws Exception {
        MDC.put("uuid", UUID.randomUUID().toString());
        //取款消息内容
        OriWithdrawReq req = new OriWithdrawReq();
        req.setRequestId("1234512345");
        req.setProductId("C66");
        req.setCustomerId("933777706254860289");
        //模拟查询存款
        QueryDepositTransWithCheckResponse depositRes = new QueryDepositTransWithCheckResponse();
        depositRes.setAmount("3000");
        doReturn(depositRes).when(requestService).queryDepositTransRecord(any());
        //模拟查询剩余额度
        List<WSCreditLogs> dstAmountList = new ArrayList<>();
        WSCreditLogs dstAmount = new WSCreditLogs();
        dstAmount.setDstAmount("5.875");
        dstAmount.setTransCode("2");
        dstAmountList.add(dstAmount);
        doReturn(dstAmountList).when(creditLogService).getCreditLogs(argThat(new ArgumentMatcher<WSQueryCreditLogs>() {
            @Override
            public boolean matches(WSQueryCreditLogs argument) {
                return StringUtils.isNotBlank(argument.getReferenceId());
            }
        }));
        //模拟查询修正额度
        List<WSCreditLogs> fixAmountList = new ArrayList<>();
        WSCreditLogs fixAmount = new WSCreditLogs();
        fixAmount.setAmount("0");
        fixAmount.setTransCode("2");
        fixAmountList.add(fixAmount);
        doReturn(fixAmountList).when(creditLogService).getCreditLogs(argThat(new ArgumentMatcher<WSQueryCreditLogs>() {
            @Override
            public boolean matches(WSQueryCreditLogs argument) {
                return StringUtils.isNotBlank(argument.getTransCode());
            }
        }));
        //模拟查询优惠金额
        WSQueryCountPAmount wsQueryCountPAmount = new WSQueryCountPAmount();
        wsQueryCountPAmount.setSumAmount("0");
        doReturn(wsQueryCountPAmount).when(requestService).getCountReportPromotion(any());
        //模拟查询投注汇总
        doReturn(new BigDecimal[]{new BigDecimal("0"), new BigDecimal("0")})
                .when(requestService).getValidAccountAndWinOrLostAmount(any(), any(), any(), any());
        //模拟查询取款记录
        QueryWithdrawalRequestsResponse mockWithDrawRes = new QueryWithdrawalRequestsResponse();
        List<WSWithdrawalRequests> withdrawalRequestsList = new ArrayList<>();
        WSWithdrawalRequests wsWithdrawal = new WSWithdrawalRequests();
        wsWithdrawal.setExceptionPromptType("0");//自动通过
        wsWithdrawal.setCreatedDate("2024-05-07 08:57:40");
        wsWithdrawal.setAmount("3000");
        wsWithdrawal.setFlag("0");
        wsWithdrawal.setCatalog("13");
        // 本地测试可以不mock labelRelationshipService，验证数据库查询标签逻辑。
        wsWithdrawal.setCustomerId("985229403090845691");

        withdrawalRequestsList.add(wsWithdrawal);
        wsWithdrawal = new WSWithdrawalRequests();
        wsWithdrawal.setExceptionPromptType("1");
        wsWithdrawal.setCreatedDate("2024-05-07 08:57:40");
        wsWithdrawal.setAmount("10000");
        wsWithdrawal.setFlag("0");
        wsWithdrawal.setCatalog("13");
        withdrawalRequestsList.add(wsWithdrawal);
        mockWithDrawRes.setWsWithdrawalRequests(withdrawalRequestsList);
        doReturn(mockWithDrawRes).when(requestService).queryWithdrawalRequestDesc(any());

        WSCustomers wsCustomers = new WSCustomers();
        wsCustomers.setParentLoginName("parentLoginName");
        wsCustomers.setDomainName("glife");
        doReturn(wsCustomers).when(wsApiFeignTemplate).getSimpleCustomerByLoginName(any(), any());
        Map<String, String> constMap = new HashMap<>();
        constMap.put("withdraw-risk-glife-auto", "1");
        doReturn(constMap).when(redisUtil).entries(any());

        // 小程序拦截
        List<TRiskLabelRelationship> labelRelationships = new ArrayList<>();
        TRiskLabelRelationship labelRelationship = new TRiskLabelRelationship();
        labelRelationship.setRiskLabelKey(CronConstant.LabelKey.RISK_ARBITRAGE_USERS);

        labelRelationships.add(labelRelationship);
        doReturn(labelRelationships).when(labelRelationshipService).queryByCustomerId(any());


        doReturn(true).when(redisUtil).tryLock(anyString(),anyLong(),anyLong(),any());
        doReturn(mockWithDrawRes).when(requestService).queryWithdrawalRequestDesc(any());



        doReturn(true).when(requestService).modifyExceptionPrompt(any());
        doReturn(new WSResponseApprove()).when(requestService).requestApprove(any());
        Assert.assertEquals(false, withdrawService.withdrawRisk(req, true, false));
    }

    /**
     * 测试重构后的规则引擎
     */
    @Test
    void withdrawRiskLift() throws Exception {
        MDC.put("uuid", UUID.randomUUID().toString());
        //取款消息内容
        OriWithdrawReq req = new OriWithdrawReq();
        req.setRequestId("1234512345");
        req.setProductId("C66");
        req.setCustomerId("933777706254860289");

        //模拟查询存款
        QueryDepositTransWithCheckResponse depositRes = new QueryDepositTransWithCheckResponse();
        depositRes.setAmount("3000");
        doReturn(depositRes).when(requestService).queryDepositTransRecord(any());
        //模拟查询剩余额度
        List<WSCreditLogs> dstAmountList = new ArrayList<>();
        WSCreditLogs dstAmount = new WSCreditLogs();
        dstAmount.setDstAmount("5.875");
        dstAmount.setTransCode("2");
        dstAmountList.add(dstAmount);
        doReturn(dstAmountList).when(creditLogService).getCreditLogs(argThat(new ArgumentMatcher<WSQueryCreditLogs>() {
            @Override
            public boolean matches(WSQueryCreditLogs argument) {
                return StringUtils.isNotBlank(argument.getReferenceId());
            }
        }));
        //模拟查询修正额度
        List<WSCreditLogs> fixAmountList = new ArrayList<>();
        WSCreditLogs fixAmount = new WSCreditLogs();
        fixAmount.setAmount("0");
        fixAmount.setTransCode("2");
        fixAmountList.add(fixAmount);
        doReturn(fixAmountList).when(creditLogService).getCreditLogs(argThat(new ArgumentMatcher<WSQueryCreditLogs>() {
            @Override
            public boolean matches(WSQueryCreditLogs argument) {
                return StringUtils.isNotBlank(argument.getTransCode());
            }
        }));
        //模拟查询优惠金额
        WSQueryCountPAmount wsQueryCountPAmount = new WSQueryCountPAmount();
        wsQueryCountPAmount.setSumAmount("0");
        doReturn(wsQueryCountPAmount).when(requestService).getCountReportPromotion(any());
        //模拟查询投注汇总
        doReturn(new BigDecimal[]{new BigDecimal("0"), new BigDecimal("0")})
                .when(requestService).getValidAccountAndWinOrLostAmount(any(), any(), any(), any());
        //模拟查询取款记录
        QueryWithdrawalRequestsResponse mockWithDrawRes = new QueryWithdrawalRequestsResponse();
        List<WSWithdrawalRequests> withdrawalRequestsList = new ArrayList<>();
        WSWithdrawalRequests wsWithdrawal = new WSWithdrawalRequests();
        wsWithdrawal.setExceptionPromptType("0");//自动通过
        /*
         * 这里修改可以测试 GlobalCheckNode
         */
        wsWithdrawal.setLastWithDrawalDate("2023-09-18 00:00:00");
        wsWithdrawal.setCreatedDate("2024-09-19 00:00:00");
        wsWithdrawal.setAmount("3000");
        wsWithdrawal.setFlag("0");
        wsWithdrawal.setCatalog("13");
        // 本地测试可以不mock labelRelationshipService，验证数据库查询标签逻辑。
        wsWithdrawal.setCustomerId("985229403090845691");

        wsWithdrawal.setLastWithDrawalBalance("1");

        withdrawalRequestsList.add(wsWithdrawal);
        wsWithdrawal = new WSWithdrawalRequests();
        wsWithdrawal.setExceptionPromptType("1");
        wsWithdrawal.setCreatedDate("2024-05-07 08:57:40");
        wsWithdrawal.setAmount("10000");
        wsWithdrawal.setFlag("0");
        wsWithdrawal.setCatalog("13");
        withdrawalRequestsList.add(wsWithdrawal);
        mockWithDrawRes.setWsWithdrawalRequests(withdrawalRequestsList);
        doReturn(mockWithDrawRes).when(requestService).queryWithdrawalRequestDesc(any());

        WSCustomers wsCustomers = new WSCustomers();
        wsCustomers.setParentLoginName("parentLoginName");
        wsCustomers.setDomainName("xxx");
        doReturn(wsCustomers).when(wsApiFeignTemplate).getSimpleCustomerByLoginName(any(), any());

        Map<String, String> constMap = new HashMap<>();
        constMap.put("withdraw-risk-glife-auto", "1");
        constMap.put("MANUAL_TYPE", "5,10");
        doReturn(constMap).when(redisUtil).entries(any());

        doReturn(true).when(redisUtil).tryLock(anyString(),anyLong(),anyLong(),any());
        doReturn(mockWithDrawRes).when(requestService).queryWithdrawalRequestDesc(any());

        doReturn(true).when(requestService).modifyExceptionPrompt(any());
        doReturn(new WSResponseApprove()).when(requestService).requestApprove(any());
        // 测试被拦截的请求
        Assertions.assertFalse(withdrawService.withdrawRisk(req, true, false));
    }

    @Resource
    private WithdrawServiceDelegate withdrawServiceDelegate;
    /**
     * 测试重构后的规则引擎
     */
    @Test
    void withdrawServiceDelegate() throws Exception {
        MDC.put("uuid", UUID.randomUUID().toString());
        //取款消息内容
        OriWithdrawReq req = new OriWithdrawReq();
        req.setRequestId("1234512345");
        req.setProductId("C66");
        req.setCustomerId("933777706254860289");
        req.setLoginName("loginName");

        //模拟查询存款
        QueryDepositTransWithCheckResponse depositRes = new QueryDepositTransWithCheckResponse();
        depositRes.setAmount("3000");
        doReturn(depositRes).when(requestService).queryDepositTransRecord(any());
        //模拟查询剩余额度
        List<WSCreditLogs> dstAmountList = new ArrayList<>();
        WSCreditLogs dstAmount = new WSCreditLogs();
        dstAmount.setDstAmount("5.875");
        dstAmount.setTransCode("2");
        dstAmountList.add(dstAmount);
        doReturn(dstAmountList).when(creditLogService).getCreditLogs(argThat(new ArgumentMatcher<WSQueryCreditLogs>() {
            @Override
            public boolean matches(WSQueryCreditLogs argument) {
                return StringUtils.isNotBlank(argument.getReferenceId());
            }
        }));
        //模拟查询修正额度
        List<WSCreditLogs> fixAmountList = new ArrayList<>();
        WSCreditLogs fixAmount = new WSCreditLogs();
        fixAmount.setAmount("0");
        fixAmount.setTransCode("2");
        fixAmountList.add(fixAmount);
        doReturn(fixAmountList).when(creditLogService).getCreditLogs(argThat(new ArgumentMatcher<WSQueryCreditLogs>() {
            @Override
            public boolean matches(WSQueryCreditLogs argument) {
                return StringUtils.isNotBlank(argument.getTransCode());
            }
        }));
        //模拟查询优惠金额
        WSQueryCountPAmount wsQueryCountPAmount = new WSQueryCountPAmount();
        wsQueryCountPAmount.setSumAmount("0");
        doReturn(wsQueryCountPAmount).when(requestService).getCountReportPromotion(any());
        //模拟查询投注汇总
        doReturn(new BigDecimal[]{new BigDecimal("0"), new BigDecimal("0")})
                .when(requestService).getValidAccountAndWinOrLostAmount(any(), any(), any(), any());
        //模拟查询取款记录
        QueryWithdrawalRequestsResponse mockWithDrawRes = new QueryWithdrawalRequestsResponse();
        List<WSWithdrawalRequests> withdrawalRequestsList = new ArrayList<>();
        WSWithdrawalRequests wsWithdrawal = new WSWithdrawalRequests();
        wsWithdrawal.setExceptionPromptType("0");//自动通过
        /*
         * 这里修改可以测试 GlobalCheckNode
         */
        wsWithdrawal.setLastWithDrawalDate("2024-09-17 00:00:00");
        wsWithdrawal.setCreatedDate("2024-09-19 00:00:00");
        wsWithdrawal.setAmount("3000");
        wsWithdrawal.setFlag("0");
        wsWithdrawal.setCatalog("13");
        // 本地测试可以不mock labelRelationshipService，验证数据库查询标签逻辑。
        wsWithdrawal.setCustomerId("985229403090845691");

        wsWithdrawal.setLastWithDrawalBalance("1");

        withdrawalRequestsList.add(wsWithdrawal);
        wsWithdrawal = new WSWithdrawalRequests();
        wsWithdrawal.setExceptionPromptType("1");
        wsWithdrawal.setCreatedDate("2024-05-07 08:57:40");
        wsWithdrawal.setAmount("10000");
        wsWithdrawal.setFlag("0");
        wsWithdrawal.setCatalog("13");
        withdrawalRequestsList.add(wsWithdrawal);
        mockWithDrawRes.setWsWithdrawalRequests(withdrawalRequestsList);
        doReturn(mockWithDrawRes).when(requestService).queryWithdrawalRequestDesc(any());

        WSCustomers wsCustomers = new WSCustomers();
        wsCustomers.setParentLoginName("parentLoginName");
        wsCustomers.setDomainName("xxx");
        doReturn(wsCustomers).when(wsApiFeignTemplate).getSimpleCustomerByLoginName(any(), any());

        Map<String, String> constMap = new HashMap<>();
        constMap.put("withdraw-risk-glife-auto", "1");
        constMap.put("MANUAL_TYPE", "5,10");
        doReturn(constMap).when(redisUtil).entries(any());

        doReturn(true).when(redisUtil).tryLock(anyString(),anyLong(),anyLong(),any());

        doReturn(true).when(requestService).modifyExceptionPrompt(any());
        doReturn(new WSResponseApprove()).when(requestService).requestApprove(any());
        withdrawServiceDelegate.handleWithdraw(req);
//        // 测试被拦截的请求
//        for (int i = 0;i<=1000;i++){
//            withdrawServiceDelegate.handleWithdraw(req);
//        }
    }
}
