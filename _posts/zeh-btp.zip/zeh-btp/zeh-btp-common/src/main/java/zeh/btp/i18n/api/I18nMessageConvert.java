package zeh.btp.i18n.api;

/**
 * @description: i18n 消息转换器
 * @author: ErHu.Zhao
 * @create: 2024-08-14
 **/
@FunctionalInterface
public interface I18nMessageConvert {

    /**
     * 将message进行国际化转换，钩子接口只指定规则，具体的实现由客户端负责
     *
     * @param message 原始message
     * @return 国际化转换后的message
     */
    String convertMessage(String message);
}
