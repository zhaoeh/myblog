/**
 * i18n国际化组件通用工具和实体
 */
package zeh.btp.i18n;
