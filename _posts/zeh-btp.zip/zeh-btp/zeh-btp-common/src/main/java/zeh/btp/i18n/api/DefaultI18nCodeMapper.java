package zeh.btp.i18n.api;

import zeh.btp.i18n.info.I18nMessages;

import java.util.Map;

/**
 * @description: 默认的i18n code映射器实现
 * @author: ErHu.Zhao
 * @create: 2024-08-14
 **/
public class DefaultI18nCodeMapper implements I18nCodeMapper {

    /**
     * 实现钩子接口的抽象方法，实际上底层调用的是钩子接口提供的默认方法实现*
     *
     * @param messages i18n messages
     * @return
     */
    @Override
    public Map<String, String> provideI18nCodeMapper(I18nMessages messages) {
        return defaultCodeMapper(messages, null);
    }
}
