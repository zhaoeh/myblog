package zeh.btp.enums;

public enum LogRecordTypeEnum {

    // ERROR
    ERROR("ERROR", "错误日志"),
    // WARN
    WARN("WARN", "警告日志"),
    // INFO
    INFO("INFO", "普通日志"),
    ;

    String text;
    String value;

    LogRecordTypeEnum(String value, String text) {
        this.value = value;
        this.text = text;
    }

    public String getValue() {
        return value;
    }
}
