package zeh.btp.utils;

/**
 * 默认回调方法*
 *
 * @param <S>
 * @param <T>
 */
public interface BeanCopyUtilCallBack<S, T> {
    void callBack(S s, T t);
}