package zeh.btp.utils;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

import java.beans.PropertyDescriptor;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Supplier;

/**
 * @ClassName BeanCopyUtil
 * @Description list<Bean>拷贝工具类
 * @Author TJSAustin
 * @Date 2023/5/20 10:00
 * @Version 1.0
 **/
public class BeanCopyUtil extends BeanUtils {

    public static <S, T> T copyProperties(S sources, Supplier<T> target) {
        T t = target.get();
        copyProperties(sources, t);
        return t;
    }

    public static <S, T> T copyProperties(S sources, Supplier<T> target, BeanCopyUtilCallBack<S, T> callBack) {
        T t = target.get();
        copyProperties(sources, t);
        if (callBack != null) {
            callBack.callBack(sources, t);
        }
        return t;
    }

    public static <S, T> T copyNotEmptyProperties(S sources, T target) {
        copyProperties(sources, target, getNullPropertyNames(sources));
        return target;
    }

    public static <S, T> T copyNotEmptyProperties(S sources, T target, BeanCopyUtilCallBack<S, T> callBack) {
        copyProperties(sources, target, getNullPropertyNames(sources));
        if (callBack != null) {
            callBack.callBack(sources, target);
        }
        return target;
    }


    public static <S, T> List<T> copyListProperties(List<S> sources, Supplier<T> target) {
        return copyListProperties(sources, target, null);
    }

    public static <S, T> List<T> copyListProperties(List<S> sources, Supplier<T> target, BeanCopyUtilCallBack<S, T> callBack) {
        List<T> list = new ArrayList<>(sources.size());
        for (S source : sources) {
            T t = target.get();
            copyProperties(source, t);
            list.add(t);
            if (callBack != null) {
                callBack.callBack(source, t);
            }
        }
        return list;
    }

    private static String[] getNullPropertyNames(Object source) {
        BeanWrapper src = new BeanWrapperImpl(source);
        PropertyDescriptor[] pds = src.getPropertyDescriptors();
        Set<String> emptyNames = new HashSet<>();
        for (PropertyDescriptor pd : pds) {
            Object srcValue = src.getPropertyValue(pd.getName());
            if (srcValue == null)
                emptyNames.add(pd.getName());
        }
        return emptyNames.toArray(new String[emptyNames.size()]);
    }
}
