package zeh.btp.i18n.api;

/**
 * @description: 定义一个钩子接口，用于指定 i18n 处理器规范
 * @author: ErHu.Zhao
 * @create: 2024-08-14
 **/
@FunctionalInterface
public interface I18nHandler {

    /**
     * 定义一个抽象方法，约束客户端处理国际化的行为，具体的实现交给客户端。如何对响应结果进行国际化处理，由客户端具体实现
     *
     * @param result  返回值
     * @param convert 国际化消息转转换器
     */
    void handleResult(Object result, I18nMessageConvert convert);

}
