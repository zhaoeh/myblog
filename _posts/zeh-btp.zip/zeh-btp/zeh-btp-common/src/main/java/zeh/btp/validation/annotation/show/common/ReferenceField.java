package zeh.btp.validation.annotation.show.common;

import java.lang.annotation.*;

/**
 * @description: 依赖字段注解
 * 该注解被约束不能标注在任何目标上，因此它只能作为其他注解的成员来使用，从而形成注解嵌套*
 * @author: ErHu.Zhao
 * @create: 2024-07-02
 **/
@Target({})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
public @interface ReferenceField {

    /**
     * 依赖的字段名称
     *
     * @return
     */
    String name();

    /**
     * 依赖的字段取值
     *
     * @return
     */
    String when();
}
