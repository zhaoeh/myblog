package zeh.btp.operations;
/**
 * 对于多个微服务之间的跨服务传递redis命令，比如A服务操作了A服务对应的redis集群，然后B服务需要同步A服务对应的redis命令来操作B服务的redis集群 *
 * 因此，本包默认就是支持从某个endPoint端接收一个redis命令描述符，然后操作对应的redis集群*
 * 通过本包可以学习链式编程原理*
 */