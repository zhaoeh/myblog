package zeh.btp.i18n.core;

import zeh.btp.i18n.api.I18nCodeMapper;
import zeh.btp.i18n.api.I18nHandler;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.*;

/**
 * @description: 国际化配置查找器，根据message查找code，根据class查找message-code mapping，根据class查找I18nHandler实例
 * @author: ErHu.Zhao
 * @create: 2024-08-14
 **/
public class I18nConfigFinder {

    private final Map<Class<? extends I18nCodeMapper>, Map<String, String>> codeMapperContainer = new HashMap<>();

    private final List<I18nHandler> handlers;

    private final List<I18nCodeMapper> codeMappers;

    private final I18nMessagesLoader i18nMessagesLoader;

    public I18nConfigFinder(List<I18nCodeMapper> codeMappers,
                            I18nMessagesLoader i18nMessagesLoader,
                            List<I18nHandler> handlers) {
        this.i18nMessagesLoader = i18nMessagesLoader;
        this.codeMappers = codeMappers;
        this.handlers = handlers;
        refreshCodeMapperContainer();
    }

    /**
     * 刷新资源
     */
    public void refreshCodeMapperContainer() {
        if (!CollectionUtils.isEmpty(codeMappers)) {
            codeMappers.stream().forEach(mapper -> codeMapperContainer.put(mapper.getClass(), mapper.provideI18nCodeMapper(i18nMessagesLoader.obtainI18nMessages())));
        }
    }

    /**
     * 根据message查找code
     *
     * @param clazz   message-code映射器的class
     * @param message 原始消息
     * @return 原始消息对应的国际化code
     */
    public String findCode(Class<? extends I18nCodeMapper> clazz, String message) {
        // 传入message-code映射器的class，查询出对应的message-code映射容器
        Map<String, String> container = findCodeMapping(clazz);
        // 如果对应的message-code映射器为空，则直接返回null
        if (CollectionUtils.isEmpty(container)) {
            return null;
        }
        // 传入message，从message-code映射器容器中获取到message对应的国际化code
        String code = container.get(message);
        if (StringUtils.hasText(code)) {
            // 如果message对应的code不为空串，则直接返回对应的code
            return code;
        }
        // 兜底返回null值
        return null;
    }

    /**
     * 返回目标配置类对应的 message-code 映射容器
     *
     * @param clazz
     * @return
     */
    public Map<String, String> findCodeMapping(Class<? extends I18nCodeMapper> clazz) {
        Assert.isTrue(codeMapperContainer.containsKey(clazz), "cannot find I18nCodeMapper instance in spring container");
        Map<String, String> container = codeMapperContainer.get(clazz);
        if (CollectionUtils.isEmpty(container)) {
            return Collections.emptyMap();
        }
        return container;
    }

    /**
     * 查找 I18nHandler 实例
     *
     * @param clazz I18nHandler处理器 class 实例
     * @return 指定class类型的国际化处理器对象
     */
    public I18nHandler findHandler(Class<? extends I18nHandler> clazz) {
        if (Objects.nonNull(clazz) && Objects.nonNull(handlers)) {
            return handlers.stream().filter(e -> clazz.isInstance(e)).findFirst().orElse(null);
        }
        return null;
    }
}
