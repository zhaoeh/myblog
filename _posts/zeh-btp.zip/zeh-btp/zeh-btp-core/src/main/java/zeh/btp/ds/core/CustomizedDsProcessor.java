package zeh.btp.ds.core;

import com.baomidou.dynamic.datasource.processor.DsProcessor;
import org.aopalliance.intercept.MethodInvocation;

import java.util.Objects;

/**
 * @description: 自定义DS处理器
 * @author: ErHu.Zhao
 * @create: 2024-01-15
 **/
public class CustomizedDsProcessor extends DsProcessor {

    /**
     * 判断当前@DS注解的value值是否匹配，匹配到将执行 doDetermineDatasource 方法，否则直接放行
     *
     * @param key @DS注解中的value值
     * @return 是否匹配 true：匹配  false：不匹配
     */
    @Override
    public boolean matches(String key) {
        return Objects.nonNull(key) && key.startsWith(DataSourceConstants.NICO_PREFIX);
    }

    /**
     * 返回动态匹配到的DataSource名称
     *
     * @param methodInvocation MethodInvocation
     * @param s                @DS注解中的value值
     * @return 需要动态切换的DataSource名称
     */
    @Override
    public String doDetermineDatasource(MethodInvocation methodInvocation, String s) {
        return DSValueHolder.get();
    }
}
