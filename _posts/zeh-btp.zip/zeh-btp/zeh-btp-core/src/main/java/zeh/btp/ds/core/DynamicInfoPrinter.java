package zeh.btp.ds.core;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

/**
 * @description: 容器中动态数据源打印器
 * @author: ErHu.Zhao
 * @create: 2024-01-22
 **/
@Component
@Slf4j
public class DynamicInfoPrinter implements SmartInitializingSingleton {

    @Override
    public void afterSingletonsInstantiated() {
        if (CollectionUtils.isEmpty(CustomizedBeanPostProcessor.dataSourceMap)) {
            return;
        }
        log.info("begin to print dynamicDataSource");
        CustomizedBeanPostProcessor.dataSourceMap.forEach((k, v) -> {
            log.info("dataSource name is {},is primary {}", k, v.isPrimary());
        });
        log.info("end to print dynamicDataSource");
    }
}
