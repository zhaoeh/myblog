package zeh.btp.operations.core;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import zeh.btp.operations.OperationsConstant;
import zeh.btp.operations.ops.*;

import java.util.Map;
import java.util.Optional;

/**
 * @description: Operations适配器
 * @author: Erhu.Zhao
 * @create: 2023-11-17 16:12
 */
@Component
public class OperationsAdaptor {

    public OperationsChain.ClearDo process(Map<String, Ops> opsMap, OperationParser operationParser, JSONObject operation) {
        JSONObject result = new JSONObject();
        String ope = operationParser.obtainOperation(operation);
        String type = operationParser.obtainType(operation);
        String action = operationParser.obtainAction(operation);
        String key = operationParser.obtainKey(operation);

        Ops ops = Optional.ofNullable(opsMap.get(ope)).orElseThrow(() -> new IllegalArgumentException("doOperationForRedis 入参错误"));
        if (OperationsConstant.DELETE.equalsIgnoreCase(action)) {
            return new OperationsChain.ClearDo(operationParser, result.fluentPut(OperationsConstant.RESULT, ops.delete(key)));
        } else {
            Object value;
            try {
                value = convertToJavaClass(type, operationParser.obtainValue(operation));
            } catch (ClassNotFoundException e) {
                throw new IllegalArgumentException("doOperationForRedis can not found class of the type param");
            }
            if (OpsForValue.class.isInstance(ops)) {
                OpsForValue opsForValue = (OpsForValue) ops;
                if (OperationsConstant.SET.equalsIgnoreCase(action)) {
                    opsForValue.set(key, value);
                    return new OperationsChain.ClearDo(operationParser, result);
                }
                if (OperationsConstant.GET.equalsIgnoreCase(action)) {
                    return new OperationsChain.ClearDo(operationParser, result.fluentPut(OperationsConstant.RESULT, opsForValue.get(key)));
                }

            }
            if (OpsForHash.class.isInstance(ops)) {
                OpsForHash opsForHash = (OpsForHash) ops;
                String hashKey = operationParser.obtainHashKey(operation);
                if (OperationsConstant.PUT.equalsIgnoreCase(action)) {
                    opsForHash.put(key, hashKey, value);
                    return new OperationsChain.ClearDo(operationParser, result);
                }
                if (OperationsConstant.GET.equalsIgnoreCase(action)) {
                    return new OperationsChain.ClearDo(operationParser, result.fluentPut(OperationsConstant.RESULT, opsForHash.get(key, hashKey)));
                }
                if (OperationsConstant.ENTRIES.equalsIgnoreCase(action)) {
                    return new OperationsChain.ClearDo(operationParser, result.fluentPut(OperationsConstant.RESULT, opsForHash.entries(key)));
                }
            }
            if (OpsForSet.class.isInstance(ops)) {
                OpsForSet opsForSet = (OpsForSet) ops;
                if (OperationsConstant.ADD.equalsIgnoreCase(action)) {
                    return new OperationsChain.ClearDo(operationParser, result.fluentPut(OperationsConstant.RESULT, opsForSet.add(key, new Object[]{value})));
                }
                if (OperationsConstant.POP.equalsIgnoreCase(action)) {
                    return new OperationsChain.ClearDo(operationParser, result.fluentPut(OperationsConstant.RESULT, opsForSet.pop(key)));
                }
            }
            if (OpsForList.class.isInstance(ops)) {
                OpsForList opsForList = (OpsForList) ops;
                if (OperationsConstant.SET.equalsIgnoreCase(action)) {
                    Long index = operationParser.obtainIndex(operation);
                    opsForList.set(key, index, value);
                    return new OperationsChain.ClearDo(operationParser, result);
                }
                if (OperationsConstant.INDEX.equalsIgnoreCase(action)) {
                    Long index = operationParser.obtainIndex(operation);
                    return new OperationsChain.ClearDo(operationParser, result.fluentPut(OperationsConstant.RESULT, opsForList.index(key, index)));
                }
            }
            if (OpsForZSet.class.isInstance(ops)) {
                OpsForZSet opsForZSet = (OpsForZSet) ops;
                if (OperationsConstant.ADD.equalsIgnoreCase(action)) {
                    Double score = operationParser.obtainScore(operation);
                    return new OperationsChain.ClearDo(operationParser, result.fluentPut(OperationsConstant.RESULT, opsForZSet.add(key, value, score)));
                }
                if (OperationsConstant.RANDOMMEMBER.equalsIgnoreCase(action)) {
                    return new OperationsChain.ClearDo(operationParser, result.fluentPut(OperationsConstant.RESULT, opsForZSet.randomMember(key)));
                }
            }
        }

        return new OperationsChain.ClearDo(operationParser, result);
    }

    public Object convertToJavaClass(String className, Object value) throws ClassNotFoundException {
        if (StringUtils.isNotBlank(className)) {
            Class<?> targetClass = Class.forName(className);
            return JSONObject.parseObject(JSONObject.toJSONString(value), targetClass);
        }
        return value;
    }
}