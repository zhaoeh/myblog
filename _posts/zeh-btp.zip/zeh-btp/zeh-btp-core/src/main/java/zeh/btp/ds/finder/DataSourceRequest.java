package zeh.btp.ds.finder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-01-18
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DataSourceRequest {

    private DataSourceType dataSourceType;

    private Object[] newRequest;
}
