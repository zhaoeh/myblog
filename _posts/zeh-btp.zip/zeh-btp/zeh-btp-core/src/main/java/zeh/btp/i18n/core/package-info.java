/**
 * i18n国际化核心组件
 */
package zeh.btp.i18n.core;
