package zeh.btp.ds.finder;

import zeh.btp.ds.core.DataSourceConstants;

/**
 * @description: 数据源类型，目前只支持clickHouse和byteHouse两种数据源
 * @author: ErHu.Zhao
 * @create: 2024-01-18
 **/
public enum DataSourceType {

    ClickHouse(DataSourceConstants.CLICK_HOUSE_DATASOURCE), ByteHouse(DataSourceConstants.BYTE_HOUSE_DATASOURCE);
    private String dataSourceName;

    DataSourceType(String dataSourceName) {
        this.dataSourceName = dataSourceName;
    }

    public String getDataSourceName() {
        return dataSourceName;
    }

    public void setDataSourceName(String dataSourceName) {
        this.dataSourceName = dataSourceName;
    }
}
