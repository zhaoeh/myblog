package zeh.btp.validation.validator;

import zeh.btp.validation.annotation.NotDuplicate;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.util.HashSet;
import java.util.List;

/**
 * @description: 对入参是List类型的参数进行重复判断，如果存在重复元素，则进行拦截
 * @author: ErHu.Zhao
 * @create: 2024-09-24
 **/
public class NotDuplicateValidator implements ConstraintValidator<NotDuplicate, List<?>> {

    private NotDuplicate enumValid;

    @Override
    public void initialize(NotDuplicate constraintAnnotation) {
        enumValid = constraintAnnotation;
    }

    @Override
    public boolean isValid(List<?> objects, ConstraintValidatorContext context) {
        // 空list认为合法
        if (CollectionUtils.isEmpty(objects)) {
            return true;
        }
        // 通过hashSet去重复，这里要注意，如果入参List中的元素是java对象，则默认是认为不同的对象，不是重复的。如果需要自定义重复规则，需要自己覆盖对象中的hashCode和equals方法才行。
        HashSet<Object> set = new HashSet<>(objects);
        if (set.size() != objects.size()) {
            String message = StringUtils.isNotBlank(enumValid.message()) ? enumValid.message() : "current collection not allowed duplicate";
            // 禁用默认message
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate(message).addConstraintViolation();
            return false;
        }
        return true;
    }

}
