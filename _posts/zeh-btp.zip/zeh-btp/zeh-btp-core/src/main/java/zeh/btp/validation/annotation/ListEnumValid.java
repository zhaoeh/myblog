package zeh.btp.validation.annotation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import zeh.btp.validation.validator.ListEnumsValidator;

import java.lang.annotation.*;

/**
 * @description: 枚举值校验注解
 * @author: ErHu.Zhao
 * @create: 2024-09-24
 **/
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {ListEnumsValidator.class})
@Documented
public @interface ListEnumValid {
    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    Class<? extends Enum> enumClass();

    String enumField();

    // 枚举字段期望索引
    int[] enumIndexes() default {};

    boolean deduplicateEnumField() default false;

    String message() default "必须为指定值";
}
