package zeh.btp.ds;
/**
 * 本包基于mybatisPlus的动态数据源做改造，对@DS注解做二次封装，支持根据api请求中携带的header灵活的进行数据源的切换，即动态数据源的切换和具体的请求参数相关 *
 * 业界实现动态数据源无非就是两种方式：
 * 1.基于spring框架提供的org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource抽象类，自己集成该抽象类并覆盖数据源路由算法，结合AOP等机制手动实现数据源的动态切换*
 * 2.使用mybatisPlus提供的动态数据源，com.baomidou.dynamic.datasource.ds.AbstractRoutingDataSource，其内部原理和自己实现spring的方式类似，也是基于AOP和内部的@DS注解等实现 *
 * 请注意：二者名称都是AbstractRoutingDataSource，且都实现了spring的org.springframework.jdbc.datasource.AbstractDataSource*
 * 从侧面可以说明，mybatisPlus实现实现了抽象层次更高的org.springframework.jdbc.datasource.AbstractDataSource，来实现动态数据源的切换功能；
 * 而spring封装的org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource抽象类，内部抽象了一些方法，常用于开发者手动实现动态数据源 *
 */