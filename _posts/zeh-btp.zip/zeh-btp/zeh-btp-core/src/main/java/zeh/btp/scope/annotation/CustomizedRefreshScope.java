package zeh.btp.scope.annotation;

import zeh.btp.scope.hook.BeanScopeManager;
import zeh.btp.scope.scope.CustomizedRefreshScopeProcessor;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;

import java.lang.annotation.*;

/**
 * @description: 自定义的bean作用域注解
 * @author: ErHu.Zhao
 * @create: 2024-08-20
 **/
@Documented
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
// 为标注该注解作用域的bean创建一个代理，一个注解通过标注另外一个注解，当spring解析当前CustomizedRefreshScope注解时，就可以间接的解析到该注解上的Scope注解
@Scope(value = CustomizedRefreshScopeProcessor.CUSTOMIZED_REFRESH_SCOPE, proxyMode = ScopedProxyMode.TARGET_CLASS)
public @interface CustomizedRefreshScope {

    /**
     * 惰性异步刷新周期，单位为 minutes
     *
     * @return 必须大于0，小于0表示不进行刷新
     */
    long lazyAsyncRefreshPeriodMinutes() default 0;

    /**
     * 自定义的bean作用域管理器
     *
     * @return
     */
    Class<? extends BeanScopeManager> manager();
}
