package zeh.btp.mfa.config;

import zeh.btp.mfa.MfaProcess;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

/**
 * @description: 条件配置类，当spring容器中存在MfaProcess类型的bean定义时，当前配置类将被自动解析
 * 当前配置类实际上是一个springboot自动配置类，通过SPI的方式进行自动配置*
 * 内部没有做任何组件的注册，只是通过@Import注解导入了一个外部的配置，核心注册逻辑都是在外部配置类MfaScanConfig中实现的*
 * 实际上自动配置类更好的实践应该是在配置类中做具体的bean注册，一般通过@Bean手动注册某些需要的bean定义，而不是通过@Import注解等进行全量的导入*
 * @author: ErHu.Zhao
 * @create: 2024-05-21
 **/
@Configuration
@ConditionalOnBean(MfaProcess.class)
@Import(MfaScanConfig.class)
@Slf4j
public class ConditionalConfig {
    public ConditionalConfig() {
        log.info("ConditionalConfig instant");
    }
}
