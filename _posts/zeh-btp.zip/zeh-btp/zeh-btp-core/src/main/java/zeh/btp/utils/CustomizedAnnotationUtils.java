package zeh.btp.utils;

import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RestController;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

/**
 * @description: 注解工具类
 * @author: ErHu.Zhao
 * @create: 2024-08-19
 **/
public class CustomizedAnnotationUtils {

    /**
     * 判断一个class对象是否是Controller*
     *
     * @param targetClass 目标class对象
     * @return 是否是controller true：是 false：不是
     */
    public static boolean isController(Class<?> targetClass) {
        Assert.notNull(targetClass, "targetClass cannot be null");
        // 如果目标class对象描述的类上标注有Controller注解或者标注有RestController注解，则认为目标class描述的是一个Controller
        return targetClass.isAnnotationPresent(Controller.class) || targetClass.isAnnotationPresent(RestController.class);
    }

    /**
     * 判断目标注解annotationClass是否被应用于目标method上*
     *
     * @param method          目标Method实例
     * @param annotationClass 目标注解class
     * @return
     */
    public static boolean isApplyOnMethod(Method method, Class<? extends Annotation> annotationClass) {
        Assert.notNull(method, "method cannot be null");
        Assert.notNull(annotationClass, "annotationClass cannot be null");
        // 判断目标method上是否标注有目标注解
        return method.isAnnotationPresent(annotationClass);
    }

    /**
     * 判断目标注解是否被标注在目标method上，但目标class又不是controller *
     * 换言之，即校验目标注解是否被标注在非Controller的方法上，如果是，则直接抛出异常*
     *
     * @param targetClass     目标class
     * @param method          目标method
     * @param annotationClass 目标注解
     */
    public static void withOutOnController(Class<?> targetClass, Method method, Class<? extends Annotation> annotationClass) {
        if (isApplyOnMethod(method, annotationClass) && !isController(targetClass)) {
            throw new IllegalStateException(annotationClass.getName() + " can only annotated on method in controller");
        }
    }

}
