package zeh.btp.ds.core;

/**
 * @description: ds value值线程容器
 * @author: ErHu.Zhao
 * @create: 2024-01-18
 **/
public class DSValueHolder {

    private static final ThreadLocal<String> dsValueContainer = ThreadLocal.withInitial(() -> "");

    private static final ThreadLocal<String> dsAnnotationContainer = ThreadLocal.withInitial(() -> "");

    private static final ThreadLocal<Integer> dsCountContainer = ThreadLocal.withInitial(() -> 0);

    public static String get() {
        return dsValueContainer.get();
    }


    public static void set(String value) {
        dsValueContainer.set(value);
    }

    public static void clear() {
        dsValueContainer.remove();
        dsAnnotationContainer.remove();
        dsCountContainer.remove();
    }

    public static String getDs() {
        return dsAnnotationContainer.get();
    }

    public static void setDs(String value) {
        dsAnnotationContainer.set(value);
    }

    /**
     * 设置当前线程持有的数据源个数
     *
     * @param dsCount
     */
    public static void setDsCount(Integer dsCount) {
        dsCountContainer.set(dsCount);
    }

    /**
     * 获取当前线程持有的数据源个数
     *
     * @return
     */
    public static Integer getDsCount() {
        return dsCountContainer.get();
    }

}
