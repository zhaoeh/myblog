package zeh.btp.common;

import zeh.btp.utils.CustomizedAnnotationUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.Objects;

/**
 * @description: 注解标注位置校验器
 * 该处理器主要负责校验其所持有的注解是否标注在规定的位置上*
 * @author: ErHu.Zhao
 * @create: 2024-08-19
 **/
public class AnnotatedBeanPostProcessor implements BeanPostProcessor {

    /**
     * 当前处理器持有的注解class*
     */
    private final Class<? extends Annotation> annotationClass;

    /**
     * 通过构造器向当前processor注入指定的注解class*
     *
     * @param annotationClass 指定的注解class
     */
    public AnnotatedBeanPostProcessor(Class<? extends Annotation> annotationClass) {
        this.annotationClass = annotationClass;
    }

    /**
     * 容器中每个bean在出初始化方法执行之后都会回调执行当前方法*
     *
     * @param bean     当前bean实例
     * @param beanName 当前bean名称
     * @return 当前bean实例，可能被篡改
     * @throws BeansException 异常
     */
    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        if (Objects.isNull(bean)) {
            return bean;
        }
        // 获取当前bean的class对象
        Class<?> beanClass = bean.getClass();
        // 判断当前bean class是否是一个Controller
        boolean isController = CustomizedAnnotationUtils.isController(beanClass);
        Arrays.stream(beanClass.getDeclaredMethods()).forEach(method -> {
            if (CustomizedAnnotationUtils.isApplyOnMethod(method, annotationClass) && !isController) {
                throw new IllegalStateException(annotationClass.getName() + " can only annotated on method in controller");
            }
        });
        return bean;
    }

}
