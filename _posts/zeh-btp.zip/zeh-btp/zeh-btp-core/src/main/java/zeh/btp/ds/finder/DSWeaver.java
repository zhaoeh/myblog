package zeh.btp.ds.finder;

import java.lang.annotation.*;


/**
 * @description: ds 织入器注解
 * @author: ErHu.Zhao
 * @create: 2024-01-18
 **/
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface DSWeaver {

    /**
     * 指定ds多数据源处理器
     *
     * @return
     */
    Class<? extends DataSourceHandler> dsHandler();
}
