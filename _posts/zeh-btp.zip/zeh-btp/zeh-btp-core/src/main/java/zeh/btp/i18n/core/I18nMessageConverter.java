package zeh.btp.i18n.core;

import zeh.btp.i18n.api.I18nCodeMapper;
import zeh.btp.i18n.api.I18nMessageConvert;
import org.springframework.util.StringUtils;

/**
 * @description: i18n消息转换器
 * @author: ErHu.Zhao
 * @create: 2024-08-15
 **/
public class I18nMessageConverter implements I18nMessageConvert {

    private final I18nConfigFinder configFinder;

    private final I18nMessageWrapper i18nMessageWrapper;

    private final Class<? extends I18nCodeMapper> mapperConfigure;

    /**
     * 构造器，构建一个国际化消息转换器实例*
     *
     * @param configFinder       国际化配置查找器实例
     * @param i18nMessageWrapper 国际化消息包装器
     * @param mapperConfigure    国际化message-code映射器的class实例
     */
    public I18nMessageConverter(I18nConfigFinder configFinder,
                                I18nMessageWrapper i18nMessageWrapper,
                                Class<? extends I18nCodeMapper> mapperConfigure) {
        this.configFinder = configFinder;
        this.i18nMessageWrapper = i18nMessageWrapper;
        this.mapperConfigure = mapperConfigure;
    }

    /**
     * 根据国际化配置转换message
     *
     * @param message 原始message
     * @return 国际化后的message
     */
    @Override
    public String convertMessage(String message) {
        String convert = null;
        // 传入message-code映射器的class和原始消息，得到对应的国际化code
        String i18nCode = configFinder.findCode(mapperConfigure, message);
        // 如果原始message存在对应的国际化code，则调用国际化消息包装器，传入对一个的code，获取到该code对应的国际化消息（根据配置获取，即根据locale获取指定语言对应的国际化消息）
        if (StringUtils.hasText(i18nCode)) {
            convert = i18nMessageWrapper.getMessage(i18nCode);
        }
        // 如果获取到的国际化消息有值，则返回
        if (StringUtils.hasText(convert)) {
            return convert;
        }
        // 兜底返回原始消息
        return message;
    }
}
