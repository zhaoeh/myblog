package zeh.btp.operations.core;

import com.alibaba.fastjson.JSONObject;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ConcurrentReferenceHashMap;

import java.util.Map;
import java.util.Objects;

/**
 * @description: Operation解析器
 * @author: Erhu.Zhao
 * @create: 2023-11-17 14:29
 */
@Component
public class OperationParser {

    private Map<JSONObject, JSONObject> cache = new ConcurrentReferenceHashMap<>();

    public String obtainOperation(JSONObject operation) {
        return operation.getString("operation");
    }

    public String obtainType(JSONObject operation) {
        return operation.getString("type");
    }

    public String obtainAction(JSONObject operation) {
        return operation.getString("action");
    }

    public JSONObject obtainParams(JSONObject operation) {
        JSONObject params = cache.get(operation);
        if (CollectionUtils.isEmpty(params)) {
            params = operation.getJSONObject("params");
            cache.put(operation, params);
        }
        return params;
    }

    public String obtainKey(JSONObject operation) {
        return obtainParams(operation).getString("key");
    }

    public Object obtainValue(JSONObject operation) {
        return obtainParams(operation).get("value");
    }

    public String obtainHashKey(JSONObject operation) {
        return obtainParams(operation).getString("hashKey");
    }

    public Long obtainIndex(JSONObject operation) {
        return obtainParams(operation).getLong("index");
    }

    public Double obtainScore(JSONObject operation) {
        return obtainParams(operation).getDouble("score");
    }

    public void clearCache() {
        if (Objects.nonNull(cache)) {
            cache.clear();
        }
    }
}