package zeh.btp.operations.main;

import com.alibaba.fastjson.JSONObject;
import zeh.btp.operations.core.OperationParser;
import zeh.btp.operations.core.OperationsChain;
import zeh.btp.operations.ops.Ops;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.Map;

/**
 * @description: Operation处理器
 * @author: Erhu.Zhao
 * @create: 2023-11-17 15:38
 */
@Component
public class OperationProcessor {

    @Autowired
    private OperationParser operationParser;

    private final Map<String, Ops> opsMap = new HashMap<>();

    public OperationProcessor(ObjectProvider<Map<String, Ops>> objectProvider) {
        Map<String, Ops> opsMap = objectProvider.getIfAvailable();
        if (!CollectionUtils.isEmpty(opsMap)) {
            opsMap.forEach((k, v) -> this.opsMap.put(v.operation(), v));
        }
    }

    /**
     * 处理redis命令表达式*
     *
     * @param operation
     * @return
     */
    public JSONObject processOperation(JSONObject operation) {
        return OperationsChain.opsMap(this.opsMap).parser(this.operationParser).process(operation).clear().result();
    }
}