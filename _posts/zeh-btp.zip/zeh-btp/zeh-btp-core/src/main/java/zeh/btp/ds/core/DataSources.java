package zeh.btp.ds.core;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.sql.DataSource;

/**
 * @description: 动态数据源持有器
 * @author: ErHu.Zhao
 * @create: 2024-01-22
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DataSources {

    private DataSource dataSource;

    private boolean isPrimary;

}
