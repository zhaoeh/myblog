package zeh.btp.ds.finder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @description: 多数据源统一响应对象
 * @author: ErHu.Zhao
 * @create: 2024-01-18
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DataSourceResponse {

    /**
     * 数据源类型，目前只支持byteHouse和clickHouse*
     */
    private DataSourceType dataSourceType;

    /**
     * 响应对象，针对当前的数据源返回的响应；如果当前数据源是clickHouse，则响应是clickHouse的数据响应；如果当前数据源是byteHouse，则响应是byteHouse的数据响应*
     */
    private Object newResponse;
}
