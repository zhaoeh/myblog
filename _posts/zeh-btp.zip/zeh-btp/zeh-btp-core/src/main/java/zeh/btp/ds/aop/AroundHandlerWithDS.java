package zeh.btp.ds.aop;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DynamicDataSourceProperties;
import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DynamicDatasourceAopProperties;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import zeh.btp.ds.core.DSValueHolder;
import zeh.btp.ds.core.DataSourceConstants;
import zeh.btp.ds.core.DynamicDataSourceChecker;
import zeh.btp.ds.finder.*;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

/**
 * @description: 动态处理DS处理器，环绕业务织入动态数据源切换逻辑
 * @author: ErHu.Zhao
 * @create: 2024-01-18
 **/
@Slf4j
@Component
@Aspect
public class AroundHandlerWithDS implements Ordered {

    private final DynamicDataSourceProperties properties;

    private final List<DataSourceHandler> dataSourceHandlers;

    /**
     * 通过构造器方式注入mybatisPlus的动态数据源配置属性文件，和容器中所有的数据源处理器集合*
     *
     * @param properties         动态数据源配置项
     * @param dataSourceHandlers 容器中存在的所有数据源处理器集合
     */
    public AroundHandlerWithDS(DynamicDataSourceProperties properties, List<DataSourceHandler> dataSourceHandlers) {
        this.properties = properties;
        this.dataSourceHandlers = dataSourceHandlers;
    }

    /**
     * 定义切点，拦截标注了DSWeaver注解的方法*
     *
     * @param dsWeaver 注解对象
     */
    @Pointcut("@annotation(dsWeaver)")
    public void dsPoint(DSWeaver dsWeaver) {
    }

    @Around("dsPoint(dsWeaver)")
    public Object doDS(ProceedingJoinPoint proceedingJoinPoint, DSWeaver dsWeaver) throws Throwable {
        // 查找dataSourceFinder
        DataSourceHandler dataSourceHandler = lookUpDataSourceFinder(dsWeaver.dsHandler());
        if (Objects.nonNull(dataSourceHandler)) {
            checkDs(proceedingJoinPoint);
            return handleBusinessWithDataSourceHandler(dsWeaver, dataSourceHandler, proceedingJoinPoint);
        }
        return proceedingJoinPoint.proceed();
    }

    @Override
    public int getOrder() {
        DynamicDatasourceAopProperties aopProperties = this.properties.getAop();
        return aopProperties.getOrder() + 10;
    }

    /**
     * 校验
     *
     * @param proceedingJoinPoint
     * @throws NoSuchMethodException
     */
    private void checkDs(ProceedingJoinPoint proceedingJoinPoint) throws NoSuchMethodException {
        String targetMethodName = proceedingJoinPoint.getSignature().getName();
        Class[] targetParameterTypes = ((MethodSignature) proceedingJoinPoint.getSignature()).getParameterTypes();
        Method targetMethod = proceedingJoinPoint.getTarget().getClass().getMethod(targetMethodName, targetParameterTypes);
        DS ds = AnnotationUtils.findAnnotation(targetMethod, DS.class);
        if (Objects.isNull(ds) || !DataSourceConstants.NICO_PREFIX.equals(ds.value())) {
            throw new IllegalArgumentException("DSWeaver annotation must be used together with annotation DS(" + DataSourceConstants.NICO_PREFIX + ")");
        }

        // 校验 @DSWeaver 注解是否在当前线程中嵌套
        if (StringUtils.isNotBlank(DSValueHolder.getDs())) {
            throw new IllegalArgumentException("DSWeaver annotation does not support nested use");
        }
    }

    /**
     * 根据自定义DataSourceHandler处理当前业务
     *
     * @param dataSourceHandler   自定义dataSourceHandler
     * @param proceedingJoinPoint proceedingJoinPoint
     * @return 返回值
     * @throws Throwable 异常
     */
    private Object handleBusinessWithDataSourceHandler(DSWeaver dsWeaver, DataSourceHandler dataSourceHandler, ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        List<DataSourceRequest> dataSourceRequests = dataSourceHandler.handleRequestWithDataSource(proceedingJoinPoint.getArgs());

        if (!CollectionUtils.isEmpty(dataSourceRequests)) {
            DynamicDataSourceChecker.checkDuplicateDS(dataSourceHandler, dataSourceRequests);
            List<DataSourceResponse> results = new ArrayList<>();
            Object result;
            Iterator<DataSourceRequest> iterator = dataSourceRequests.listIterator();
            try {
                DSValueHolder.setDs(dsWeaver.getClass().getSimpleName());
                DSValueHolder.setDsCount(dataSourceRequests.size());
                // 在aop中根据请求切割出来的分段范围，循环迭代去执行真实目标方法调用
                while (iterator.hasNext()) {
                    DataSourceRequest dataSourceRequest = iterator.next();
                    DataSourceType dataSourceType = dataSourceRequest.getDataSourceType();
                    String dataSourceName = dataSourceType.getDataSourceName();
                    DSValueHolder.set(dataSourceName);
                    log.info("begin to handle current business with {}", dataSourceName);

                    // 新的请求参数
                    Object[] newRequests = dataSourceRequest.getNewRequest();
                    result = proceedingJoinPoint.proceed(newRequests);
                    // 针对新的请求参数返回新的响应体
                    DataSourceResponse newResponse = DataSourceResponse.builder().dataSourceType(dataSourceType).newResponse(result).build();
                    results.add(newResponse);
                    log.info("end to handle current business with {}", dataSourceName);
                }
                return dataSourceHandler.handleResponseWithDataSource(results);
            } finally {
                DSValueHolder.clear();
            }
        }
        return proceedingJoinPoint.proceed();
    }

    /**
     * 根据clazz查询 DataSourceHandler
     *
     * @param clazz DataSourceHandler目标类型
     * @return 匹配到的目标类型
     */
    private DataSourceHandler lookUpDataSourceFinder(Class<?> clazz) {
        if (Objects.nonNull(clazz) && Objects.nonNull(dataSourceHandlers)) {
            return dataSourceHandlers.stream().filter(e -> clazz.isInstance(e)).findFirst().orElse(null);
        }
        return null;
    }
}
