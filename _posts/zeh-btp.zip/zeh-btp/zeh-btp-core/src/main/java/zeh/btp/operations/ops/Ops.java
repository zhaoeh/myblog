package zeh.btp.operations.ops;

import java.io.Serializable;

/**
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-11-17 11:52
 */
public interface Ops {
    String operation();

    Boolean delete(Serializable key);
}