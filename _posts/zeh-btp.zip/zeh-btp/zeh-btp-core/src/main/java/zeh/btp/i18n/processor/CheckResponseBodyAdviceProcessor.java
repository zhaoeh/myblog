package zeh.btp.i18n.processor;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.SmartInitializingSingleton;

import java.util.Objects;

/**
 * @description: 自定义SmartInitializingSingleton的实现，目的是当spring容器中的所有非懒加载的单例bean都实例化、属性填充、初始化完毕之后。执行一段自定义的回调逻辑
 * @author: ErHu.Zhao
 * @create: 2024-08-08
 **/
public class CheckResponseBodyAdviceProcessor implements SmartInitializingSingleton {

    /**
     * 定义一个内置的DefaultResponseAdvice，作为ResponseBodyAdvice的一个默认实现
     * 此处之所以提供一个默认的ResponseBodyAdvice实现，是因为有的业务侧自身会注册ResponseBodyAdvice实例，有的业务侧不会，因此提供一个默认的实现作为兜底*
     */
    private final DefaultResponseAdvice responseAdvice;

    /**
     * 是否支持默认的ResponseBodyAdvice实现，默认是true，即默认情况下使用本框架内部提供的DefaultResponseAdvice*
     */
    private static boolean DEFAULT_SUPPORTS = true;

    /**
     * 通过构造器注入默认的DefaultResponseAdvice*
     *
     * @param defaultResponseAdvice
     */
    public CheckResponseBodyAdviceProcessor(ObjectProvider<DefaultResponseAdvice> defaultResponseAdvice) {
        this.responseAdvice = defaultResponseAdvice.getIfAvailable();
    }

    @Override
    public void afterSingletonsInstantiated() {
        // 如果提供了DefaultResponseAdvice实例，则设置使用默认的DefaultResponseAdvice
        // 请注意，该方法的回调，实在容器中的所有单例bean都初始化完毕之后才触发的，它的生命周期靠后
        // 因此，它的回调远远晚于ResponseBodyAdviceBeanPostProcessor的执行，从而可以保证，优先使用业务侧提供的ResponseBodyAdvice实例，而DefaultResponseAdvice永远只作为兜底
        if (Objects.nonNull(responseAdvice)) {
            responseAdvice.setSupports(DEFAULT_SUPPORTS);
        }
    }

    /**
     * 是否支持默认advice
     *
     * @param defaultSupports
     */
    public static void supportsDefaultAdvice(boolean defaultSupports) {
        DEFAULT_SUPPORTS = defaultSupports;
    }
}
