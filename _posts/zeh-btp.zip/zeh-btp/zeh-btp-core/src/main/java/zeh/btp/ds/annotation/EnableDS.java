package zeh.btp.ds.annotation;

import zeh.btp.ds.config.DSConfig;
import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

/**
 * @program: mkt-agent
 * @description: 启用common动态数据源
 * @author: Erhu.Zhao
 * @create: 2023-12-06 16:34
 */
@Target({ElementType.TYPE, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
@Import(DSConfig.class)
public @interface EnableDS {
}
