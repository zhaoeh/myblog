package zeh.btp.validation.annotation;

import zeh.btp.validation.annotation.show.common.ReferenceField;
import org.hibernate.validator.constraints.Range;

import java.lang.annotation.*;

/**
 * @description: 依赖校验管理注解
 * 该注解被约束只能标注在class上*
 * @author: ErHu.Zhao
 * @create: 2024-07-02
 **/
@Target({ElementType.TYPE, ElementType.FIELD, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
public @interface ReferenceRange {

    ReferenceField referenceField();

    Range range();
}
