package zeh.btp.cache;
/**
 * 提供公共的缓存策略 *
 */