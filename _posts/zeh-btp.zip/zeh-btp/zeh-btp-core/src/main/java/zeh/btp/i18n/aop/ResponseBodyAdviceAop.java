package zeh.btp.i18n.aop;

import zeh.btp.i18n.annotation.EnableI18nWeavingForResponse;
import zeh.btp.i18n.api.DefaultI18nCodeMapper;
import zeh.btp.i18n.processor.I18nProcessor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.MethodParameter;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import java.util.Objects;

/**
 * @description: ResponseBodyAdvice拦截器，用于拦截spring容器中的 ResponseBodyAdvice
 * @author: ErHu.Zhao
 * @create: 2024-08-07
 **/
@Aspect
@Slf4j
public class ResponseBodyAdviceAop {

    private final I18nProcessor i18nProcessor;

    public ResponseBodyAdviceAop(I18nProcessor i18nProcessor) {
        this.i18nProcessor = i18nProcessor;
    }

    /**
     * aop拦截容器中所有 ResponseBodyAdvice 的  beforeBodyWrite 方法
     * 请注意，源码中的ResponseBodyAdvice本身是一个接口，通过target的方式可以拦截其所有的实现类，从而代理所有的实现类对象*
     *
     * @param joinPoint 织入点
     * @return 响应值
     * @throws Throwable 异常
     */
    @Around("target(org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice)")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        // 定义方法参数对象，从该对象中可以获取到目标方法参数相关的信息，比如方法参数类型、方法返回值类型等
        MethodParameter methodParameter;
        // 定义响应体
        Object responseBody;
        // 判断是否需要拦截处理：目标实例是ResponseBodyAdvice类型并且目标方法名称为beforeBodyWrite，才需要进一步处理
        boolean needProcess = ResponseBodyAdvice.class.isAssignableFrom(joinPoint.getTarget().getClass()) &&
                joinPoint.getSignature().getName().equals("beforeBodyWrite");
        if (needProcess) {
            // 获取beforeBodyWrite方法入参中的第一个参数，第一个参数就是拦截到的原始响应对象
            responseBody = joinPoint.getArgs()[0];
            // 当i18n处理器对象存在并且原始响应对象不为null时，进一步进行处理
            if (Objects.nonNull(i18nProcessor) && Objects.nonNull(responseBody)) {
                // 获取beforeBodyWrite方法入参中的第二个参数，其类型本身就是methodParameter，用于描述方法参数信息
                methodParameter = (MethodParameter) joinPoint.getArgs()[1];
                // 通过methodParameter对象，获取到其描述的方法，进一步获取目标方法上的 EnableI18nWeavingForResponse 注解，目标方法可能存在该注解，也可能不存在
                EnableI18nWeavingForResponse weaving = methodParameter.getMethod().getAnnotation(EnableI18nWeavingForResponse.class);

                // 将原始响应体和注解对象传递给i18n处理器进行处理，先调用processI18nResult方法处理响应体，再调用processI18nField进一步处理响应体对象中的注定字段的国际化
                i18nProcessor.processI18nResult(responseBody, weaving);
                i18nProcessor.processI18nField(responseBody, Objects.isNull(weaving) ? DefaultI18nCodeMapper.class :
                        weaving.mapperConfigure());
            }
        }

        // 放行
        return joinPoint.proceed();
    }
}
