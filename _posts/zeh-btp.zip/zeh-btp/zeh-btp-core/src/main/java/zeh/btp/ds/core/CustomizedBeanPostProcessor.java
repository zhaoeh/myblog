package zeh.btp.ds.core;

import com.baomidou.dynamic.datasource.ds.AbstractRoutingDataSource;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;
import org.springframework.util.ConcurrentReferenceHashMap;

import javax.sql.DataSource;
import java.util.Map;

/**
 * @description: 自定义 BeanPostProcessor ，在spring容器中每个bean初始化完成之后自动调用，主要用来检测当前bean是不是期望的动态数据源
 * @author: ErHu.Zhao
 * @create: 2024-01-19
 **/
@Component
public class CustomizedBeanPostProcessor implements BeanPostProcessor, Ordered {

    protected static final Map<String, DataSources> dataSourceMap = new ConcurrentReferenceHashMap<>();

    /**
     * 容器中每个业务bean在初始化完成之后自动回调该方法*
     *
     * @param bean     当前bean实例
     * @param beanName 当前bean名称（可能是自动生成的名称，也可能是通过注解或者xml配置指定的bean名称）
     * @return 当前bean实例，有可能被篡改
     * @throws BeansException
     */
    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        collectDynamicDataSources(bean, beanName);
        return bean;
    }

    /**
     * 聚合容器中所有的动态数据源实例
     *
     * @param bean     容器中初始化完毕的bean实例
     * @param beanName 该bean的bean name
     */
    private void collectDynamicDataSources(Object bean, String beanName) {
        // 首先当前bean必须是数据源实例对象
        if (bean instanceof DataSource) {

            // 当前bean如果是mp中的AbstractRoutingDataSource实例，或者是spring中提供的动态数据源接口AbstractRoutingDataSource的实例，则直接终止
            // 此处的逻辑，目的是为了聚合那些按照我们自定义规则实现的那些动态数据源对象，如果一个数据源对象已经是mybatisPlus或者是spring方式实现的动态数据源了，那么该组件就自动跳过了，不做任何处理
            if (bean instanceof AbstractRoutingDataSource || bean instanceof org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource) {
                return;
            }

            // 如果bean名称是“dynamicDataSource”，则终止，不做任何处理
            if (DataSourceConstants.DYNAMIC_DATA_SOURCE_NAME.equals(beanName)) {
                return;
            }

            // 如果bean名称以自定义的字符串"dynamic_"开头，则开始聚合逻辑
            if (beanName.startsWith(DataSourceConstants.DYNAMIC_DATA_SOURCE_PREFIX)) {
                // 构建一个自定义的数据源实例
                DataSources dataSources = new DataSources();
                // 将当前容器中的数据源实例封装进去
                dataSources.setDataSource((DataSource) bean);

                // 如果bean name 去除 “dynamic_” 后，以“master”开头，则是主数据源
                if (beanName.startsWith(DataSourceConstants.MASTER, DataSourceConstants.DYNAMIC_DATA_SOURCE_PREFIX.length())) {
                    // 主数据源
                    dataSources.setPrimary(Boolean.TRUE);
                    beanName = beanName.replace(DataSourceConstants.MASTER, "");
                }
                dataSourceMap.put(beanName, dataSources);
            }
        }
    }

    @Override
    public int getOrder() {
        return Integer.MIN_VALUE;
    }
}
