package zeh.btp.mfa.annotation;

import java.lang.annotation.*;

/**
 * @description: mfa 二次认证注解
 * 约束该注解只允许标注在目标方法上，用于标识目标方法是否开启mfa二次认证*
 * @author: ErHu.Zhao
 * @create: 2024-02-28
 **/
@Documented
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface MfaAuth {
}
