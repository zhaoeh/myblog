package zeh.btp.i18n.aop;

import zeh.btp.i18n.annotation.EnableI18nFunctionForMethod;
import zeh.btp.i18n.processor.I18nProcessor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

import java.util.Objects;

/**
 * @description: EnableI18nFunctionForMethod 注解拦截器
 * @author: ErHu.Zhao
 * @create: 2024-08-07
 **/
@Aspect
@Slf4j
public class EnableI18nMethodResultAop {

    private final I18nProcessor i18nProcessor;

    /**
     * 构造器注入 i18nProcessor*
     *
     * @param i18nProcessor 国际化处理器
     */
    public EnableI18nMethodResultAop(I18nProcessor i18nProcessor) {
        this.i18nProcessor = i18nProcessor;
    }

    /**
     * 指定aop拦截切点*
     *
     * @param method EnableI18nFunctionForMethod 注解实例
     */
    @Pointcut("@annotation(method)")
    public void methodResult(EnableI18nFunctionForMethod method) {
    }

    /**
     * aop拦截容器中所有标注了 EnableI18nFunctionForMethod 的公共方法
     * 使用aop请注意aop的使用规范，确保aop生效。比如自调用、非public的方法等都不会被aop进行动态代理，因此一定确保符合aop的规范才能正确使用aop*
     *
     * @param joinPoint 织入点
     * @return 返回值
     * @throws Throwable 异常
     */
    @Around("methodResult(method)")
    public Object around(ProceedingJoinPoint joinPoint, EnableI18nFunctionForMethod method) throws Throwable {
        Object result = joinPoint.proceed();
        if (Objects.nonNull(i18nProcessor) && Objects.nonNull(result)) {
            i18nProcessor.processI18nField(result, method.mapperConfigure());
        }
        return result;
    }
}
