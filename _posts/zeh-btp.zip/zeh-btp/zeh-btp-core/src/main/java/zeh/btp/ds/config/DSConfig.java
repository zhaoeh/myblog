package zeh.btp.ds.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * 公共配置类
 *
 * @description: 公共配置类，提供当前jar包中的bean扫描配置
 * @author: Erhu.Zhao
 * @create: 2023-10-18 15:28
 **/
@Configuration
@ComponentScan(basePackages = {"ft.btp.ds"})
public class DSConfig {
}
