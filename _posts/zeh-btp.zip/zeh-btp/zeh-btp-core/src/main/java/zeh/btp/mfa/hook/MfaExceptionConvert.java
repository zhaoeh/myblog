package zeh.btp.mfa.hook;

/**
 * @description: 异常转换钩子
 * @author: ErHu.Zhao
 * @create: 2024-05-30
 **/
@FunctionalInterface
public interface MfaExceptionConvert {

    /**
     * 提供转换异常的逻辑*
     *
     * @param e 原始异常，只支持运行时异常
     * @return 转换后的异常，只支持运行时异常
     */
    RuntimeException convertMfaException(RuntimeException e);

}
