package zeh.btp.scope.constants;

/**
 * @description: 常量类
 * @author: ErHu.Zhao
 * @create: 2024-08-27
 **/
public class ScopeConstants {

    public static final String CACHE_TRIGGER_BEAN_NAME = "cacheTrigger";
}
