package zeh.btp.i18n.processor;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import java.util.Objects;

/**
 * @description: 针对ResponseBodyAdvice的BeanPostProcessor
 * 由于某些业务侧通过@Bean的方式注册ResponseBodyAdvice，导致条件注解失效（@Bean返回值类型不是父类型）
 * 条件注解只能根据容器中是否存在指定的类型来判断，即只能判断容器中是否存在ResponseBodyAdvice类型的bean定义，而有的业务侧通过@Bean的方式注册ResponseBodyAdvice，其返回值类型不是ResponseBodyAdvice
 * 而是具体的子类型，因此会导致条件注解检测失效 *
 * @author: ErHu.Zhao
 * @create: 2024-08-08
 **/
public class ResponseBodyAdviceBeanPostProcessor implements BeanPostProcessor {

    /**
     * 当一个bean在实例化，填充属性之后，初始化方法调度之前会回调该方法*
     *
     * @param bean     当前bean实例
     * @param beanName 当前bean名称
     * @return 当前bean实例，可能被篡改
     * @throws BeansException 异常
     */
    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        // 如果当前bean实例不为null，且当前bean实例的class是ResponseBodyAdvice类型，则继续执行
        if (Objects.nonNull(bean) && ResponseBodyAdvice.class.isAssignableFrom(bean.getClass())) {
            // 如果当前bean实例的class不是DefaultResponseAdvice，则表示当前bean是业务侧自己注册的ResponseBodyAdvice；
            // 因此需要向CheckResponseBodyAdviceProcessor中设置DEFAULT_SUPPORTS为false，即表示不使用默认的DefaultResponseAdvice
            if (bean.getClass() != DefaultResponseAdvice.class) {
                CheckResponseBodyAdviceProcessor.supportsDefaultAdvice(false);
            }
        }
        return bean;
    }

}
