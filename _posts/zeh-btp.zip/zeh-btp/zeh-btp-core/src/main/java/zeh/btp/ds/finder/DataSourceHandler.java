package zeh.btp.ds.finder;

import java.util.List;

/**
 * @description: 查找数据源
 * @author: ErHu.Zhao
 * @create: 2024-01-18
 **/
public interface DataSourceHandler {

    /**
     * 根据参数查找数据源类型集合（目前只支持ClickHouse和ByteHouse）
     *
     * @param args 参数
     * @return 目标数据源类型集合
     */
    List<DataSourceRequest> handleRequestWithDataSource(Object[] args);

    /**
     * 处理响应
     *
     * @param dataSourceResponses 多数据源通用响应集合，每个对象对应各自数据源的类型以及对应的响应
     * @return
     */
    Object handleResponseWithDataSource(List<DataSourceResponse> dataSourceResponses);
}
