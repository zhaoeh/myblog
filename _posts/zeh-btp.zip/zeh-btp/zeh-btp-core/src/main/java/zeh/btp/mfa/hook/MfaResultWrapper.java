package zeh.btp.mfa.hook;

import zeh.btp.mfa.show.MfaResult;

/**
 * @description: 响应包装钩子
 * @author: ErHu.Zhao
 * @create: 2024-05-30
 **/
@FunctionalInterface
public interface MfaResultWrapper {

    /**
     * mfa响应包装策略*
     *
     * @param mfaResult mfa响应体
     * @return 包装后的响应体，因为不知道业务侧需要的响应体结构，因此统一返回一个Object对象，具体的包装逻辑交由客户端进行定制
     */
    Object wrapMfaResult(MfaResult mfaResult);
}
