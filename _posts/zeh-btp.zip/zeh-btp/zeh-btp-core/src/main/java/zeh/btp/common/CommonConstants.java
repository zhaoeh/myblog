package zeh.btp.common;

/**
 * @description: 公共常量类
 * @author: ErHu.Zhao
 * @create: 2024-09-04
 **/
public class CommonConstants {

    /**
     * caffeine cache namespace*
     */
    public static final String CAFFEINE_CACHE_NAME = "DEFAULT";

    /**
     * caffeine cache namespace中存储的key*
     */
    public static final String ERROR_CODE_CACHE = "errCode";
}
