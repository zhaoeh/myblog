package zeh.btp.mfa.show;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @description: mfa实体类
 * @author: ErHu.Zhao
 * @create: 2024-06-04
 **/
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MfaInfo<T> {

    /**
     * mfa响应码*
     */
    private Integer mfaStatus;

    /**
     * mfa响应体，通过泛型指定*
     */
    private T mfaInfo;

}
