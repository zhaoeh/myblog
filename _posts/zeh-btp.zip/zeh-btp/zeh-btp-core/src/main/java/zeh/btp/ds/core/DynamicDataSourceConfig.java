package zeh.btp.ds.core;

import com.baomidou.dynamic.datasource.DynamicRoutingDataSource;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.dynamic.datasource.aop.DynamicDataSourceAnnotationAdvisor;
import com.baomidou.dynamic.datasource.aop.DynamicDataSourceAnnotationInterceptor;
import com.baomidou.dynamic.datasource.processor.DsHeaderProcessor;
import com.baomidou.dynamic.datasource.processor.DsProcessor;
import com.baomidou.dynamic.datasource.processor.DsSessionProcessor;
import com.baomidou.dynamic.datasource.processor.DsSpelExpressionProcessor;
import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DynamicDataSourceProperties;
import com.baomidou.dynamic.datasource.spring.boot.autoconfigure.DynamicDatasourceAopProperties;
import org.springframework.aop.Advisor;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Role;
import org.springframework.context.expression.BeanFactoryResolver;
import org.springframework.util.CollectionUtils;

import javax.sql.DataSource;

/**
 * @description: 自定义的动态数据源配置类
 * @author: ErHu.Zhao
 * @create: 2024-01-16
 **/
@Configuration
public class DynamicDataSourceConfig {

    private final DynamicDataSourceProperties properties;

    /**
     * 通过构造器自动注入mp中的动态数据源配置文件，默认配置项前缀是：spring.datasource.dynamic*
     *
     * @param properties
     */
    public DynamicDataSourceConfig(DynamicDataSourceProperties properties) {
        this.properties = properties;
    }

    /**
     * 注册自定义动态数据源对象到spring容器中
     *
     * @return
     */
    @Bean(DataSourceConstants.DYNAMIC_DATA_SOURCE_NAME)
    public DataSource dataSource() {
        // 创建一个mp中的动态数据源对象
        DynamicRoutingDataSource dataSource = new DynamicRoutingDataSource();

        if (!CollectionUtils.isEmpty(CustomizedBeanPostProcessor.dataSourceMap)) {
            DynamicDataSourceChecker.checkPrimaryDataSource();

            CustomizedBeanPostProcessor.dataSourceMap.forEach((k, v) -> {
                if (v.isPrimary()) {
                    dataSource.setPrimary(k);
                }
                dataSource.addDataSource(k, v.getDataSource());
            });
        }
        dataSource.setStrict(this.properties.getStrict());
        dataSource.setStrategy(this.properties.getStrategy());
        dataSource.setP6spy(this.properties.getP6spy());
        dataSource.setSeata(this.properties.getSeata());
        return dataSource;
    }

    /**
     * 自定义DS处理器配置
     *
     * @param beanFactory bean factory
     * @return DsProcessor instance
     */
    @Bean
    public DsProcessor dsProcessor(BeanFactory beanFactory) {
        CustomizedDsProcessor customizedDsProcessor = new CustomizedDsProcessor();
        DsHeaderProcessor headerProcessor = new DsHeaderProcessor();
        DsSessionProcessor sessionProcessor = new DsSessionProcessor();
        DsSpelExpressionProcessor spelExpressionProcessor = new DsSpelExpressionProcessor();
        spelExpressionProcessor.setBeanResolver(new BeanFactoryResolver(beanFactory));
        customizedDsProcessor.setNextProcessor(headerProcessor);
        headerProcessor.setNextProcessor(sessionProcessor);
        sessionProcessor.setNextProcessor(spelExpressionProcessor);
        return customizedDsProcessor;
    }

    /**
     * 自定义动态数据源AOP，对其order进行降级，使之在自定义aop之后运行
     *
     * @param dsProcessor
     * @return
     */
    @Role(2)
    @Bean
    @ConditionalOnProperty(
            prefix = "spring.datasource.dynamic.aop",
            name = {"enabled"},
            havingValue = "true",
            matchIfMissing = true
    )
    public Advisor customizedDynamicDatasourceAnnotationAdvisor(DsProcessor dsProcessor) {
        DynamicDatasourceAopProperties aopProperties = this.properties.getAop();
        DynamicDataSourceAnnotationInterceptor interceptor = new DynamicDataSourceAnnotationInterceptor(aopProperties.getAllowedPublicOnly(), dsProcessor);
        DynamicDataSourceAnnotationAdvisor advisor = new DynamicDataSourceAnnotationAdvisor(interceptor, DS.class);
        advisor.setOrder(aopProperties.getOrder() + 100);
        return advisor;
    }


}
