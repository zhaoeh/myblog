package zeh.btp.ds.core;

import zeh.btp.ds.finder.DataSourceHandler;
import zeh.btp.ds.finder.DataSourceRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * @description: 动态数据源校验器
 * @author: ErHu.Zhao
 * @create: 2024-01-22
 **/
@Component
public class DynamicDataSourceChecker {

    /**
     * 校验主数据源
     */
    public static void checkPrimaryDataSource() {
        if (CollectionUtils.isEmpty(CustomizedBeanPostProcessor.dataSourceMap)) {
            return;
        }
        long primaryDataSource = primaryDataSourceCount();
        if (primaryDataSource == 0) {
            throw new IllegalStateException("A primary data source must be set up in the dynamic data sources");
        }
        if (primaryDataSource > 1) {
            throw new IllegalStateException("Only one primary data source is allowed to be set in the dynamic data sources");
        }
    }

    /**
     * 检查DataSourceHandler是否设置了重复的数据源
     *
     * @param dataSourceHandler  dataSourceHandler
     * @param dataSourceRequests dataSourceRequests
     */
    public static void checkDuplicateDS(DataSourceHandler dataSourceHandler, List<DataSourceRequest> dataSourceRequests) {
        // DataSourceType 去重复之后的个数
        long distinctDSType = dataSourceRequests.stream().map(e -> e.getDataSourceType()).distinct().count();
        if (distinctDSType < dataSourceRequests.size()) {
            throw new IllegalArgumentException("There are duplicate dataSourceTypes in DataSourceHandler, please check [" + dataSourceHandler.getClass().getName() + "]");
        }

    }


    /**
     * 获取动态数据源中主数据源的个数
     *
     * @return
     */
    private static long primaryDataSourceCount() {
        return CustomizedBeanPostProcessor.dataSourceMap.values().stream().filter(DataSources::isPrimary).count();
    }
}
