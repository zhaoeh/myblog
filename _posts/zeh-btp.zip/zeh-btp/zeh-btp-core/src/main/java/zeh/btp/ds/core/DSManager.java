package zeh.btp.ds.core;

/**
 * @description: DS管理器
 * @author: ErHu.Zhao
 * @create: 2024-01-24
 **/
public class DSManager {

    /**
     * 获取动态数据源的个数
     *
     * @return
     */
    public static int obtainDsCount() {
        return DSValueHolder.getDsCount();
    }

    /**
     * 当前线程是否持有单个数据源
     *
     * @return 当前线程是否持有单个数据源 true:是 false：否
     */
    public static boolean isSingletonDs() {
        return obtainDsCount() == 1;
    }
}
