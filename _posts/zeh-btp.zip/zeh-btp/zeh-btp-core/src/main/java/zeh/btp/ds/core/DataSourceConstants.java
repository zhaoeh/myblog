package zeh.btp.ds.core;

/**
 * @description: 数据源配置key
 * @author: ErHu.Zhao
 * @create: 2024-01-15
 **/
public class DataSourceConstants {
    public static final String NICO_PREFIX = "#nico";
    protected static final String DYNAMIC_DATA_SOURCE_PREFIX = "dynamic_";
    protected static final String MASTER = "master";

    /**
     * 支持的动态数据源名称
     */
    public static final String CLICK_HOUSE_DATASOURCE = DYNAMIC_DATA_SOURCE_PREFIX + "clickHouseDataSource";
    public static final String MYSQL_HOUSE_DATASOURCE = DYNAMIC_DATA_SOURCE_PREFIX + "mysqlDataSource";
    public static final String ORACLE_HOUSE_DATASOURCE = DYNAMIC_DATA_SOURCE_PREFIX + "oracleDataSource";
    public static final String DB2_HOUSE_DATASOURCE = DYNAMIC_DATA_SOURCE_PREFIX + "db2DataSource";
    public static final String SQLSERVER_HOUSE_DATASOURCE = DYNAMIC_DATA_SOURCE_PREFIX + "sqlServerDataSource";
    public static final String HSQL_HOUSE_DATASOURCE = DYNAMIC_DATA_SOURCE_PREFIX + "hsqlDataSource";
    public static final String INFORMIX_HOUSE_DATASOURCE = DYNAMIC_DATA_SOURCE_PREFIX + "informixDataSource";
    public static final String BYTE_HOUSE_DATASOURCE = DYNAMIC_DATA_SOURCE_PREFIX + "byteHouseDataSource";

    /**
     * 支持的动态主数据源名称
     */
    public static final String MASTER_CLICK_HOUSE_DATASOURCE = DYNAMIC_DATA_SOURCE_PREFIX + MASTER + "clickHouseDataSource";
    public static final String MASTER_MYSQL_HOUSE_DATASOURCE = DYNAMIC_DATA_SOURCE_PREFIX + MASTER + "mysqlDataSource";
    public static final String MASTER_ORACLE_HOUSE_DATASOURCE = DYNAMIC_DATA_SOURCE_PREFIX + MASTER + "oracleDataSource";
    public static final String MASTER_DB2_HOUSE_DATASOURCE = DYNAMIC_DATA_SOURCE_PREFIX + MASTER + "db2DataSource";
    public static final String MASTER_SQLSERVER_HOUSE_DATASOURCE = DYNAMIC_DATA_SOURCE_PREFIX + MASTER + "sqlServerDataSource";
    public static final String MASTER_HSQL_HOUSE_DATASOURCE = DYNAMIC_DATA_SOURCE_PREFIX + MASTER + "hsqlDataSource";
    public static final String MASTER_INFORMIX_HOUSE_DATASOURCE = DYNAMIC_DATA_SOURCE_PREFIX + MASTER + "informixDataSource";
    public static final String MASTER_BYTE_HOUSE_DATASOURCE = DYNAMIC_DATA_SOURCE_PREFIX + MASTER + "byteHouseDataSource";

    /**
     * 动态数据源名称
     */
    public static final String DYNAMIC_DATA_SOURCE_NAME = "dynamicDataSource";
}
