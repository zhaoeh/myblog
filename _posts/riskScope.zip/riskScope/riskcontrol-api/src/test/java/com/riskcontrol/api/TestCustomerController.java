package com.riskcontrol.api;

import com.riskcontrol.api.service.CustomerApiService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import javax.annotation.Resource;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

/**
 * @program: riskcontrol-api
 * @description: test sms
 * @author: Colson
 * @create: 2023-09-12 11:06
 */
@SpringBootTest(classes = RiskControlApiApplication.class)
@RunWith(SpringRunner.class)
@Slf4j
@AutoConfigureMockMvc
public class TestCustomerController {
    @Resource
    CustomerApiService customerApiService;

    @Resource
    private MockMvc mockMvc;


    @Test
    public void testImproveUserProfile() throws Exception {
        String contentJson = "{\n" +
                "    \"birthday\": \"1980-03-26 00:00:00\",\n" +
                "    \"firstName\": \"ADONIS\",\n" +
                "    \"middleName\": \"BOYSILLO\",\n" +
                "    \"lastName\": \"RAGASI\",\n" +
                "    \"gender\": \"M\",\n" +
                "    \"customerName\": \"bingoplus3qul5j\",\n" +
                "    \"firstIdScan\": \"9cec7fa7-a669-43c6-8fa2-7f1f43e4bc0d\",\n" +
                "    \"identifyId\": \"14221\",\n" +
                "    \"firstIdType\": \"4\",\n" +
                "    \"loginName\": \"bingoplus3qul5j\",\n" +
                "    \"customerId\": \"1005738135\",\n" +
                "    \"productId\": \"C66\"\n" +
                "}";
        mockMvc.perform(MockMvcRequestBuilders.post("/customer/improveUserProfile")
                        .content(contentJson)
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("qid", "7ba9bb1d31c6d42e411788c3dd62d10b")
                        .header("appId", "C66PC01")
                        .header("v", "1.0.0")
                        .header("sign", "4bca7194842bb7ed73848488e36a7655"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(print());

    }

    @Test
    public void testOcrIdentify() throws Exception {
        String contentJson = "{\n" +
                "    \"idScan\": \"\",\n" +
                "    \"customerId\": \"\",\n" +
                "    \"idType\": \"4\",\n" +
                "}";
        mockMvc.perform(MockMvcRequestBuilders.post("/customer/ocrIdentify")
                        .content(contentJson)
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("qid", "7ba9bb1d31c6d42e411788c3dd62d10b")
                        .header("appId", "C66PC01")
                        .header("v", "1.0.0")
                        .header("sign", "4bca7194842bb7ed73848488e36a7655"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(print());

    }

    @Test
    public void testApproveKYCInfo() throws Exception {
        String bodyJson = "{\n" +
                "  \"id\": \"232034\",\n" +
                "  \"operator\": \"haisong01\",\n" +
                "  \"status\": 3,\n" +
                "  \"customerId\": \"905392059756576768\",\n" +
                "  \"birthday\": \"1975-11-13\",\n" +
                "  \"loginName\": \"bingoplusz1xtvr\",\n" +
                "  \"firstName\": \"ARCADIA\",\n" +
                "  \"middleName\": \"ANURAN\",\n" +
                "  \"sex\": \"F\",\n" +
                "  \"lastName\": \"BRAZA\",\n" +
                "  \"remark\": \"dsa\",\n" +
                "  \"productId\": \"C66\"\n" +
                "}";
        mockMvc.perform(MockMvcRequestBuilders
                        .post("/customer/approveKYCInfo")
                        .content(bodyJson)
                        .accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON)
                        .header("qid", "7ba9bb1d31c6d42e411788c3dd62d10b")
                        .header("appId", "C66PC01")
                        .header("v", "1.0.0")
                        .header("sign", "4bca7194842bb7ed73848488e36a7655")
                ).andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(print());
    }



}
