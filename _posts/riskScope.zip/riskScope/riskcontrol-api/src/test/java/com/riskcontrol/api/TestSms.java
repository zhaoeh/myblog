package com.riskcontrol.api;

import com.riskcontrol.api.service.CustomerApiService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

/**
 * @program: riskcontrol-api
 * @description: test sms
 * @author: Colson
 * @create: 2023-09-12 11:06
 */
@SpringBootTest(classes = RiskControlApiApplication.class)
@RunWith(SpringRunner.class)
@Slf4j
public class TestSms {
    @Resource
    CustomerApiService customerApiService;


    @Test
    public void testSms(){

    }


}
