package com.riskcontrol.api.exception;

import com.riskcontrol.api.constants.exception.ApiResultBaseEnum;
import lombok.Getter;

/**
 * @ClassName BusinessException
 * @Description 自定义业务异常
 * @Author TJSAlex
 * @Date 2023/5/19 12:11
 * @Version 1.0
 **/
@Getter
public class ApiBusinessException extends RuntimeException {
    /**
     * 异常码
     */
    protected String code;


    public ApiBusinessException() {
        super();
    }

    public ApiBusinessException(String message) {
        super(message);
    }

    public ApiBusinessException(String message, String code) {
        super(message);
        this.code = code;
    }

    public ApiBusinessException(ApiResultBaseEnum resultEnum) {
        super(resultEnum.getMessage());
        this.code = resultEnum.getCode();
    }

    public ApiBusinessException(String message, Throwable cause) {
        super(message, cause);
    }
}
