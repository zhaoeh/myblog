package com.riskcontrol.api.controller;

import com.riskcontrol.api.service.RiskDevice;
import com.riskcontrol.common.entity.request.device.LoginCheckRequest;
import com.riskcontrol.common.entity.request.device.RegisterCheckRequest;
import com.riskcontrol.common.entity.request.device.RegisterSaveRequest;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.device.LoginCheckResponse;
import com.riskcontrol.common.entity.response.device.RegisterCheckResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @author Heng.zhang
 */
@RestController
@Api("风控行为规则")
@RequestMapping("/risk/check")
@Slf4j
public class RiskDeviceController {

    @Autowired
    private RiskDevice riskDevice;

    @PostMapping(value = "/registerCheck")
    @ApiOperation(value = "注册风控校验")
    @ResponseBody
    public Response<RegisterCheckResponse> registerCheck(@RequestBody @Validated RegisterCheckRequest registerCheckRequest) {
        return Response.body(riskDevice.registerCheck(registerCheckRequest));
    }

    @PostMapping(value = "/registerSave")
    @ApiOperation(value = "注册风控信息写入")
    @ResponseBody
    public Response<Boolean> registerSave(@RequestBody @Validated RegisterSaveRequest registerSaveRequest) {
        return Response.body(riskDevice.registerSave(registerSaveRequest));
    }

    @PostMapping(value = "/loginCheck")
    @ApiOperation(value = "登录风控校验")
    @ResponseBody
    public Response<LoginCheckResponse> loginCheck(@RequestBody @Validated LoginCheckRequest loginCheckRequest) {
        return Response.body(riskDevice.loginCheck(loginCheckRequest));
    }

}
