package com.riskcontrol.api.service.impl;

import com.alibaba.cloud.commons.lang.StringUtils;
import com.google.common.io.ByteStreams;
import com.riskcontrol.api.config.OssProperties;
import com.riskcontrol.api.service.OssService;
import com.riskcontrol.api.utils.MyFileType;
import io.minio.*;
import io.minio.http.Method;
import lombok.extern.slf4j.Slf4j;
import net.coobird.thumbnailator.Thumbnails;
import okhttp3.OkHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.MimeTypeUtils;

import java.io.*;

/**
 * minIo 主要用于测试环境开发
 */
//@Service
@Slf4j
public class MinioServiceImpl implements OssService {

    protected static Logger logger = LoggerFactory.getLogger("MinioServiceImpl");

    private static final String suffix = ".jpg";

    @Value("${aws.s3.bucketName}")
    private String bucketName;

    /**
     * minioClient
     */
    private MinioClient minioClient;


    public MinioServiceImpl(OssProperties ossProperties) {
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.dispatcher().setMaxRequestsPerHost(64);
        this.minioClient = MinioClient.builder()
                .endpoint(ossProperties.getUrl(), ossProperties.getPort(), false)
                .credentials(ossProperties.getAccessKeyId(), ossProperties.getSecretAccessKey())
                .httpClient(okHttpClient)
                .build();

    }


    @Override
    public String uploadFile(String bucketName, InputStream stream, String contentType, String fileName) throws Exception {
        // 上传文件路径
        try {
            // 上传文件
            PutObjectArgs putObjectArgs = PutObjectArgs.builder().bucket(bucketName)
                    .object(fileName)
                    .contentType(contentType)
                    .stream(stream, stream.available(), -1).build();
            minioClient.putObject(putObjectArgs);
            return fileName;
        } catch (Exception e) {
            logger.error("{}文件上传失败", fileName);
            return "";
        }
    }

    @Override
    public InputStream getFile(String bucketName, String objectName) {
        try {
            // 文件是否存在
            StatObjectArgs statObjectArgs = StatObjectArgs.builder().bucket(bucketName).object(objectName).build();
            minioClient.statObject(statObjectArgs);
            // 获取文件
            GetObjectArgs getObjectArgs = GetObjectArgs.builder().bucket(bucketName).object(objectName).build();
            return minioClient.getObject(getObjectArgs);
        } catch (Exception e) {
            logger.error("{}文件获取失败", objectName);
            return null;
        }
    }

    @Override
    public String getFileUrl(String bucketName, String objectName) {
        return getFileUrl(bucketName, objectName, suffix);
    }

    @Override
    public String getFileTxtUrl(String bucketName, String objectName) {
        try {
            GetPresignedObjectUrlArgs getPresignedObjectUrlArgs = GetPresignedObjectUrlArgs.builder().bucket(bucketName).object(objectName).method(Method.GET).build();
            return minioClient.getPresignedObjectUrl(getPresignedObjectUrlArgs);
        } catch (Exception e) {
            logger.error("{}文件获取失败", objectName);
            return "";
        }
    }

    @Override
    public String getFileUrl(String bucketName, String objectName, String suffix) {
        try {
            objectName = objectName + suffix;
            GetPresignedObjectUrlArgs getPresignedObjectUrlArgs = GetPresignedObjectUrlArgs.builder().bucket(bucketName).object(objectName).method(Method.GET).build();
            return minioClient.getPresignedObjectUrl(getPresignedObjectUrlArgs);
        } catch (Exception e) {
            logger.error("{}文件获取失败", objectName);
            return "";
        }
    }

    @Override
    public String getFileBase64(String bucketName, String objectName) {
        try {
            objectName = objectName + suffix;
            InputStream inputStream = getFile(bucketName, objectName);
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            Thumbnails.of(inputStream).scale(1f).toOutputStream(outputStream);

            return java.util.Base64.getEncoder().encodeToString(outputStream.toByteArray());
        } catch (IOException e) {
            logger.error("minio getFileBase64读取失败", e);
            return "";
        }
    }

    @Override
    public byte[] getFileByte(String bucketName, String objectName) {
        try {
            objectName = objectName.contains(".") ? objectName : objectName + suffix;
            // objectName = objectName + suffix;
            InputStream inputStream = getFile(bucketName, objectName);

            return ByteStreams.toByteArray(inputStream);
        } catch (IOException e) {
            logger.error("minio getFileByte读取失败", e);
            return null;
        }
    }

    @Override
    public void putObject(String bucketName, String base64Img, String key) {
        try (ByteArrayInputStream bais = new ByteArrayInputStream(base64Img.getBytes())) {
            uploadFile(bucketName, bais, MimeTypeUtils.IMAGE_JPEG.toString(), key + suffix);
        } catch (Exception e) {
            logger.error("{}文件上传失败", key);
        }
    }

    @Override
    public String putObject(String bucketName, File file, String key, boolean isPublic) throws FileNotFoundException {
        try (FileInputStream bais = new FileInputStream(file)) {
            uploadFile(bucketName, bais, MimeTypeUtils.IMAGE_JPEG.toString(), key + suffix);
            return key;
        } catch (Exception e) {
            logger.error("{}文件上传失败", key);
            return "";
        }
    }

    @Override
    public void putObject(String bucketName, byte[] base64Img, String key) {
        try (ByteArrayInputStream bais = new ByteArrayInputStream(base64Img)) {
            uploadFile(bucketName, bais, MimeTypeUtils.IMAGE_JPEG.toString(), key + suffix);
        } catch (Exception e) {
            logger.error("{}文件上传失败", key);
        }
    }

    @Override
    public String putObject(String bucketName, File base64Img, String key, String suffix, boolean isPublic) {
        String mime = StringUtils.isBlank(MyFileType.getMIMEBySuffix(suffix)) ? "image/jpeg" : MyFileType.getMIMEBySuffix(suffix);
        try (FileInputStream bais = new FileInputStream(base64Img)) {
            uploadFile(bucketName, bais, mime, key + suffix);
            return key;
        } catch (Exception e) {
            logger.error("{}文件上传失败", key);
            return "";
        }
    }

    @Override
    public String getPublicUrl(String key) {
        return getFileUrl(bucketName, key, suffix);
    }
}

