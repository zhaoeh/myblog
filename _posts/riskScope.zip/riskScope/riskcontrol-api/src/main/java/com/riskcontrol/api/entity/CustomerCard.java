package com.riskcontrol.api.entity;

import lombok.Data;

import java.util.Date;

/**
 * @Auther: yannis
 * @Date: 2023/3/31 16:57
 * @Description: 用户证件里信息
 */
@Data
public class CustomerCard {
    /**
     * 名
     */
    private String firstName;
    /**
     * 中间名
     */
    private String middleName;
    /**
     * 姓
     */
    private String lastName;
    /**
     * 性别
     */
    private String gender;
    /**
     * 出生日期
     */
    private Date birthday;
    /**
     * 地址
     */
    private String address;
    /**
     * 证件照类型
     */
    private String idType;
    /**
     * 证件照号码
     */
    private String idNo;
}
