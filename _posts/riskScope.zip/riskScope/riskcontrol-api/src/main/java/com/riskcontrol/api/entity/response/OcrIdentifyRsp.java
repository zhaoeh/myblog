package com.riskcontrol.api.entity.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @Auther: yannis
 * @Date: 2023/3/31 14:38
 * @Description: ocr证件识别返回识别信息
 */
@Data
public class OcrIdentifyRsp implements Serializable {
    @ApiModelProperty(value = "名")
    private String firstName;

    @ApiModelProperty(value = "中间名")
    private String middleName;

    @ApiModelProperty(value = "姓")
    private String lastName;

    @ApiModelProperty("性别")
    private String gender;

    @ApiModelProperty("出生日期")
    private Date birthday;

    @ApiModelProperty("地址")
    private String address;

    @ApiModelProperty("证件照类型")
    private String idType;
    @ApiModelProperty("证件照号码")
    private String idNo;

    @ApiModelProperty("年龄")
    private String age;

    @ApiModelProperty("识别表id")
    private String identifyId;


}
