package com.riskcontrol.api.service;

import com.riskcontrol.api.entity.request.RiskLabelHighDowngradeRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelByCustomerIdRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelListRequest;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelRsp;
import org.springframework.web.bind.annotation.RequestBody;

import javax.validation.Valid;
import java.util.List;

/**
 * @program: riskcontrol-api
 * @description: 风控标签
 * @author: Colson
 * @create: 2024-01-15 18:16
 */
public interface RiskLabelService {


    /**
     * 批量查询用户标签信息 *
     * @param request -
     * @return -
     */
    List<CustomerRiskLabelRsp> listCustomerRiskLabel(RiskLabelListRequest request);

    /**
     * 获取用户风控标签详情 *
     * @param request
     * @return
     */
    CustomerRiskLabelRsp getRiskLabelDetail(RiskLabelByCustomerIdRequest request);

    /**
     * 解除用户风控标签
     * @param request
     * @return
     */
    Boolean removeLabel(@Valid @RequestBody RiskLabelHighDowngradeRequest request);

}
