package com.riskcontrol.api.template;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cn.schema.customers.BatchModifyPbcRequestResponse;
import com.cn.schema.customers.BatchUpdateKycRequestRequest;
import com.cn.schema.customers.CreateKycRequestResponse;
import com.cn.schema.customers.ModifyKycRequestResponse;
import com.cn.schema.customers.QueryKycRequestProcessLogResponse;
import com.cn.schema.customers.QueryKycSheetListRequestResponse;
import com.cn.schema.customers.UpdateKycRequestRequest;
import com.cn.schema.customers.WSKycRequest;
import com.cn.schema.customers.WSKycSheetRequest;
import com.cn.schema.request.KycDispatchConfirmRequest;
import com.cn.schema.request.KycDispatchConfirmResponse;
import com.cn.schema.request.QueryCountResponse;
import com.cn.schema.request.WSDispatchRecord;
import com.riskcontrol.api.constants.exception.ApiResultBaseEnum;
import com.riskcontrol.api.entity.request.KycDispatchConfirmReq;
import com.riskcontrol.api.entity.request.QueryPageByKycRequestId;
import com.riskcontrol.common.client.CronFeign;
import com.riskcontrol.common.config.WsCommonConfig;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.request.BaseReq;
import com.riskcontrol.common.entity.request.api.QueryRiskConstants;
import com.riskcontrol.common.entity.request.device.LoginCheckRequest;
import com.riskcontrol.common.entity.request.device.RegisterCheckRequest;
import com.riskcontrol.common.entity.request.device.RegisterSaveRequest;
import com.riskcontrol.common.entity.request.kyc.RiskCreateKycRequestRequest;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequest;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequestRequest;
import com.riskcontrol.common.entity.request.kyc.RiskUpdateKycRequestRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelByCustomerIdRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelListRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelRemoveBindingRequest;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.api.RiskConstantsRsp;
import com.riskcontrol.common.entity.response.device.LoginCheckResponse;
import com.riskcontrol.common.entity.response.device.RegisterCheckResponse;
import com.riskcontrol.common.entity.response.kyc.RiskQueryKycRequestResponse;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelRsp;
import com.riskcontrol.common.helper.ResponseHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * feign template of cron project
 *
 * @program: riskcontrol-api
 * @description: feign template of riskControlCron
 * @author: Erhu.Zhao
 * @create: 2023-10-04 15:20
 **/
@Slf4j
@Component
public class CronFeignTemplate {

    @Resource
    private CronFeign cronFeign;

    @Resource
    private WsCommonConfig wsCommonConfig;

    public RiskQueryKycRequestResponse queryKycRequest(RiskQueryKycRequest query) {
        return queryKycRequest(buildQueryKycRequestRequest(query));
    }

    public RiskQueryKycRequestResponse queryKycRequest(RiskQueryKycRequestRequest query) {
        try {
            log.info("请求风控系统queryKycRequest request={}", JSON.toJSONString(query));
            return ResponseHelper.pullData(cronFeign.queryKycRequest(query));
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，QueryKycRequest 错误", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    /**
     * 构建QueryKycRequestRequest
     *
     * @param query query
     * @return QueryKycRequestRequest
     */
    private RiskQueryKycRequestRequest buildQueryKycRequestRequest(RiskQueryKycRequest query) {
        RiskQueryKycRequestRequest request = new RiskQueryKycRequestRequest();
        request.setInfProductId(wsCommonConfig.getWsProductId());
        request.setInfPwd(wsCommonConfig.getWsProductPwd());
        request.setParams(query);
        request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
        return request;
    }

    /**
     * 新增kyc
     *
     * @param cid       cid
     * @param productId productId
     * @return CreateKycRequestResponse
     */
    public CreateKycRequestResponse addKycRequest(KycRequest cid, String productId) {
        try {
            return ResponseHelper.pullData(cronFeign.addKycRequest(buildCreateKycRequestRequest(cid, productId)));
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，CreateKycRequest 错误", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    public CreateKycRequestResponse addKycRequestCron(RiskCreateKycRequestRequest request) {
        try {
            return ResponseHelper.pullData(cronFeign.addKycRequest(request));
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，CreateKycRequest 错误", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    /**
     * 构建CreateKycRequestRequest
     *
     * @param cid       cid
     * @param productId productId
     * @return CreateKycRequestRequest
     */
    private RiskCreateKycRequestRequest buildCreateKycRequestRequest(KycRequest cid, String productId) {
        RiskCreateKycRequestRequest request = new RiskCreateKycRequestRequest();
        request.setInfProductId(productId);
        request.setInfPwd(wsCommonConfig.getWsProductPwd());
        request.setWsKycRequest(cid);
        request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
        return request;
    }

    /**
     * 更新kyc
     *
     * @param cid       cid
     * @param productId productId
     * @return ModifyKycRequestResponse
     */
    public ModifyKycRequestResponse updateKycRequest(KycRequest cid, String productId) {
        return updateKycRequest(buildUpdateKycRequestRequest(cid, productId));
    }

    public ModifyKycRequestResponse updateKycRequest(RiskUpdateKycRequestRequest req) {
        try {
            return ResponseHelper.pullData(cronFeign.updateKycRequest(req));
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，updateKycRequestCron 错误", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    /**
     * 构建UpdateKycRequestRequest
     *
     * @param cid       cid
     * @param productId productId
     * @return 构建UpdateKycRequestRequest
     */
    private RiskUpdateKycRequestRequest buildUpdateKycRequestRequest(KycRequest cid, String productId) {
        RiskUpdateKycRequestRequest request = new RiskUpdateKycRequestRequest();
        request.setInfProductId(productId);
        request.setInfPwd(wsCommonConfig.getWsProductPwd());
        request.setWsKycRequest(cid);
        request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
        return request;
    }

    /**
     * 查询符合条件的kyc数量
     *
     * @param query     WSQueryKycRequest
     * @param productId productId
     * @return 符合条件的kyc数量
     */
    public int countKycRequest(RiskQueryKycRequest query, String productId) {
        try {
            RiskQueryKycRequestRequest request = buildQueryKycRequestRequest(query, productId);
            log.info("countKycRequest request={}", JSON.toJSONString(request));
            int count = ResponseHelper.pullData(cronFeign.countKycRequest(request)).getCount();
            log.info("countKycRequest response={}", count);
            return count;
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，QueryKycRequest 错误", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }
    /**
     * 查询符合条件的kyc数量
     *
     * @param query     WSQueryKycRequest
     * @return 符合条件的kyc数量
     */
    public List<Integer> queryKycStatusByCustomerId(RiskQueryKycRequest query) {
        try {
            log.info("queryKycStatusByCustomerId request={}", JSON.toJSONString(query));
            List<Integer> statusList = ResponseHelper.pullData(cronFeign.queryKycStatusByCustomerId(query));
            log.info("queryKycStatusByCustomerId response={}", JSONObject.toJSONString(statusList));
            return statusList;
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，QueryKycRequest 错误", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }
    /**
     * 构建kyc数量查询条件对象
     *
     * @param query     WSQueryKycRequest
     * @param productId productId
     * @return kyc查询条件对象
     */
    private RiskQueryKycRequestRequest buildQueryKycRequestRequest(RiskQueryKycRequest query, String productId) {
        RiskQueryKycRequestRequest request = new RiskQueryKycRequestRequest();
        request.setInfProductId(productId);
        request.setInfPwd(wsCommonConfig.getWsProductPwd());
        request.setParams(query);
        request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
        return request;
    }

    public ModifyKycRequestResponse pbcDispatch(KycRequest cid, String productId) {
        try {
            RiskUpdateKycRequestRequest request = buildUpdateKycRequestRequest(cid, productId);
            log.info("pbcDispatch request={}", JSON.toJSONString(request));
            ModifyKycRequestResponse response = ResponseHelper.pullData(cronFeign.pbcDispatch(request));
            log.info("pbcDispatch response={}", JSON.toJSONString(response));
            return response;
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，pbcDispatch 错误", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    public RiskQueryKycRequestResponse queryKycPbcRequest(RiskQueryKycRequest query, String productId) {
        try {
            RiskQueryKycRequestRequest request = new RiskQueryKycRequestRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setParams(query);
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));

            RiskQueryKycRequestResponse response = ResponseHelper.pullData(cronFeign.queryKycPbcRequest(request));
            return response;
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，queryKycPbcRequest 错误", ApiResultBaseEnum.CRON_EXCEPTION);
        }

    }

    /**
     * pbc修改状态*
     * @param wsKycRequest -
     * @param productId -
     * @return
     */
    public ModifyKycRequestResponse pbcModifyStatus(KycRequest wsKycRequest, String productId) {
        RiskUpdateKycRequestRequest request = new RiskUpdateKycRequestRequest();
        request.setInfProductId(productId);
        request.setInfPwd(wsCommonConfig.getWsProductPwd());
        request.setWsKycRequest(wsKycRequest);
        request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
        return pbcModifyStatus(request);
    }

    /**
     * pbc修改状态 *
     * @param req -
     * @return -
     */
    public ModifyKycRequestResponse pbcModifyStatus(RiskUpdateKycRequestRequest req) {
        try {
            return ResponseHelper.pullData(cronFeign.pbcModifyStatus(req));
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，pbcModifyStatusCron 错误", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    public QueryKycSheetListRequestResponse queryKycSheetRequest(RiskQueryKycRequest query) {
        try {

            RiskQueryKycRequestRequest request = new RiskQueryKycRequestRequest();
            request.setInfProductId(query.getProductId());
            request.setParams(query);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));

            return ResponseHelper.pullData(cronFeign.queryKycSheetRequest(request));

        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，/customers/kyc_request/queryKycSheetList 错误", ApiResultBaseEnum.CRON_EXCEPTION);
        }

    }

    public int countKycPbcRequest(RiskQueryKycRequest query, String productId) {
        try {

            RiskQueryKycRequestRequest request = new RiskQueryKycRequestRequest();
            request.setInfProductId(query.getProductId());
            request.setParams(query);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));

            return ResponseHelper.pullData(cronFeign.countKycPbcRequest(request)).getCount();

        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，/customers/kyc_request/countKycPbcRequest 错误", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    public BatchModifyPbcRequestResponse bactchModifyPbcStatus(List<WSKycSheetRequest> kycSheetList, String productId, String operator) {
        try {
            BatchUpdateKycRequestRequest request = new BatchUpdateKycRequestRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWsKycSheetRequestList(kycSheetList);
            request.setOperator(operator);
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
            return ResponseHelper.pullData(cronFeign.bactchModifyPbcStatus(request));

        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，pbcModifyStatus 错误", ApiResultBaseEnum.CRON_EXCEPTION);
        }

    }

    public QueryKycRequestProcessLogResponse queryPageByKycRequestId(QueryPageByKycRequestId req) {
        try {

            UpdateKycRequestRequest request = new UpdateKycRequestRequest();
            request.setInfProductId(req.getProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            WSKycRequest wsKycRequest = new WSKycRequest();
            wsKycRequest.setId(req.getId());
            request.setWsKycRequest(wsKycRequest);
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));

            return ResponseHelper.pullData(cronFeign.queryPageByKycRequestId(request));

        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，queryPageByKycRequestId 错误", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    public Boolean checkDispatchConfirm(KycDispatchConfirmReq req) {

        KycDispatchConfirmRequest kycRequest = new KycDispatchConfirmRequest();
        kycRequest.setLoginName(req.getLoginName());
        kycRequest.setIds(req.getIds());

        KycDispatchConfirmResponse response = ResponseHelper.pullData(cronFeign.checkDispatchConfirm(kycRequest));
        //
        return response.getResult();
    }


    public Boolean dispatchKycRequestConfirm(KycDispatchConfirmReq request) {

        KycDispatchConfirmRequest kycRequest = new KycDispatchConfirmRequest();
        kycRequest.setLoginName(request.getLoginName());
        kycRequest.setIds(request.getIds());

        KycDispatchConfirmResponse response = ResponseHelper.pullData(cronFeign.dispatchKycRequestConfirm(kycRequest));
        return response.getResult();

    }


    /**
     * 查询等待审核的订单数
     *
     * @param request -
     * @return
     */
    public QueryCountResponse queryKycRequestPendingCount(BaseReq request) {
        KycRequest kycRequest = new KycRequest();
        kycRequest.setLoginName(request.getLoginName());
        return queryKycRequestPendingCount(kycRequest);
    }

    /**
     * 查询等待审核的订单数
     *
     * @param request -
     * @return
     */
    public QueryCountResponse queryKycRequestPendingCount(KycRequest request) {
        try {
            log.info("查询riskcontrol系统 kyc信息，queryKycRequestPendingCount 入参 {}", JSONObject.toJSONString(request));
            Response<QueryCountResponse> response = cronFeign.queryWaitPendingCount(request);
            log.info("[queryKycRequestPendingCount method] response is {}", JSONObject.toJSONString(response));
            return ResponseHelper.pullData(response);
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，queryKycRequestPendingCount", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    /**
     * 派单
     *
     * @param request 派单请求
     * @return 派单结果
     */
    public List<KycRequest> dispatchKycRequest(BaseReq request) {
        try {
            KycRequest kycRequest = new KycRequest();
            kycRequest.setLoginName(request.getLoginName());
            return Optional.ofNullable(ResponseHelper.pullData(cronFeign.dispatch(kycRequest))).map(response -> response.getData()).orElse(Collections.emptyList());
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，dispatchKycRequest", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    /**
     * 从cron服务本地缓存中获取指定缓存key对应的数据
     *
     * @param cacheKey 缓存key
     * @return 缓存key对应的数据
     */
    public Response<Object> loadLocalCacheInfoByKeyFromCron(String cacheKey) {
        try {
            return Optional.ofNullable(cronFeign.loadLocalCacheInfoByKeyFromCron(cacheKey)).orElse(new Response<>());
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，loadLocalCacheInfoByKeyFromCron", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    /**
     * 取消派单
     *
     * @param request 取消派单请求
     * @return 取消派单结果
     */
    public Boolean dispatchKycRequestCancel(BaseReq request) {
        try {
            KycRequest kycRequest = new KycRequest();
            kycRequest.setLoginName(request.getLoginName());
            return Optional.ofNullable(ResponseHelper.pullData(cronFeign.dispatchCancel(kycRequest))).map(response -> response.getResult()).orElse(false);
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，dispatchKycRequestCancel", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    /**
     * 修改派单用户配置
     *
     * @param request 派单配置请求
     * @return 派单配置修改后结果
     */
    public JSONObject modifyCustomConfiguration(JSONObject request) {
        try {
            return ResponseHelper.pullData(cronFeign.modifyCustomConfiguration(request));
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，modifyCustomConfiguration", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    /**
     * 跨服务操作redis
     *
     * @param request 派单配置请求
     * @return 派单配置修改后结果
     */
    public JSONObject doOperationForRedis(JSONObject request) {
        try {
            return ResponseHelper.pullData(cronFeign.doOperationForRedis(request));
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，doOperationForRedis", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }


    /**
     * 自动审核kyc和pbc
     *
     * @param request -
     * @return -
     */
    public Response<ModifyKycRequestResponse> autoApproveKycAndPbc(RiskUpdateKycRequestRequest request) {
        try {
            return Optional.ofNullable(cronFeign.autoApproveKycAndPbc(request)).orElse(new Response<>());
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，autoApproveKycAndPbc", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    /**
     * 获取审核中的订单数量
     *
     * @param request 请求
     * @return 响应
     */
    public Integer dispatchRequestPendingCount(BaseReq request) {
        try {
            WSDispatchRecord record = new WSDispatchRecord();
            record.setUserLoginName(request.getLoginName());
            return Optional.ofNullable(ResponseHelper.pullData(cronFeign.pendingCount(record))).map(result -> result.getCount()).orElse(0);
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，dispatchRequestPendingCount", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    /**
     * 根据条件查询风控常量
     * @param request
     * @return
     */
    public List<RiskConstantsRsp> queryRiskConstantsList(QueryRiskConstants request) {
        try {
            Response<List<RiskConstantsRsp>> response = cronFeign.queryRiskConstantsList(request);
            log.info("[queryRiskConstantsList method] response is {}", JSONObject.toJSONString(response));
            return ResponseHelper.pullData(response);
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，autoApproveKycAndPbc", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    /**
     * 批量查询用户标签信息
     * @param request -
     * @return
     */
    public List<CustomerRiskLabelRsp> listCustomerRiskLabel(RiskLabelListRequest request) {
        try {
            Response<List<CustomerRiskLabelRsp>> response = cronFeign.listCustomerRiskLabel(request);
            log.info("[riskLabelCustomerList method] response is {}", JSONObject.toJSONString(response));
            return ResponseHelper.pullData(response);
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，listCustomerRiskLabel", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    /**
     * 批量查询用户标签信息
     * @param request -
     * @return
     */
    public CustomerRiskLabelRsp getRiskLabelDetail(RiskLabelByCustomerIdRequest request) {
        try {
            Response<CustomerRiskLabelRsp> response = cronFeign.getRiskLabelDetail(request);
            log.info("[getRiskLabelDetail method] response is {}", JSONObject.toJSONString(response));
            return ResponseHelper.pullData(response);
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，getRiskLabelDetail", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    /**
     * 批量查询用户标签信息
     * @param request -
     * @return
     */
    public Boolean removeLabel(RiskLabelRemoveBindingRequest request) {
        try {
            Response<Boolean> response = cronFeign.removeLabel(request);
            log.info("[removeLabel method] response is {}", JSONObject.toJSONString(response));
            return ResponseHelper.pullData(response);
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，removeLabel", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    /**
     *
     * @param idType
     * @param idNo
     * @return
     */
    public Boolean validKycIdAndType(Integer idType,String idNo) {
        try {
            log.info("[validKycIdAndType method] param is idType:{},idNo:{}", idType,idNo);
            Response<Boolean> response = cronFeign.validKycIdAndType(idType,idNo);
            log.info("[validKycIdAndType method] response is {}", JSONObject.toJSONString(response));
            return ResponseHelper.pullData(response);
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，validKycIdAndType", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }

    public KycRequest queryKycByLoginNameOrderOne(RiskQueryKycRequest query) {
        try {
            log.info("[queryKycByLoginNameOrderOne method] param is {}", JSONObject.toJSONString(query));
            Response<KycRequest> response = cronFeign.queryKycByLoginNameOrderOne(query);
            log.info("[queryKycByLoginNameOrderOne method] response is {}", JSONObject.toJSONString(response));
            return ResponseHelper.pullData(response);
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，queryKycByLoginNameOrderOne", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }


    public RegisterCheckResponse registerCheck(RegisterCheckRequest request) {
        try {
            log.info("[registerCheck method] param is {}", JSONObject.toJSONString(request));
            Response<RegisterCheckResponse> response = cronFeign.registerCheck(request);
            log.info("[registerCheck method] response is {}", JSONObject.toJSONString(response));
            return ResponseHelper.pullData(response);
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，registerCheck", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }


    public Boolean registerSave(RegisterSaveRequest request) {
        try {
            log.info("[registerSave method] param is {}", JSONObject.toJSONString(request));
            Response<Boolean> response = cronFeign.registerSave(request);
            log.info("[registerSave method] response is {}", JSONObject.toJSONString(response));
            return ResponseHelper.pullData(response);
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，registerSave", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }


    public LoginCheckResponse loginCheck(LoginCheckRequest request) {
        try {
            log.info("[loginCheck method] param is {}", JSONObject.toJSONString(request));
            Response<LoginCheckResponse> response = cronFeign.loginCheck(request);
            log.info("[loginCheck method] response is {}", JSONObject.toJSONString(response));
            return ResponseHelper.pullData(response);
        } catch (Exception ex) {
            throw ResponseHelper.businessException(ex, "调用riskControl-cron接口异常，loginCheck", ApiResultBaseEnum.CRON_EXCEPTION);
        }
    }


}
