package com.riskcontrol.api.service;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

/**
 * @description: 顶象服务
 * @author: ErHu.Zhao
 * @create: 2024-11-13
 **/
public interface DingXiangService {

    /**
     * 根据token获取设备指纹信息*
     *
     * @param token
     * @return
     * @throws Exception
     */
    Map<String, String> getDeviceInfo(String token) throws Exception;

    /**
     * 根据token获取设备指纹信息*
     *
     * @param cacheCondition 是否需要使用缓存
     * @param token
     * @return
     * @throws Exception
     */
    Map<String, String> getDeviceInfo(Predicate<String> cacheCondition, String token) throws Exception;

    /**
     * 根据token获取设备指纹信息，指定cache失效时间*
     *
     * @param token
     * @param expireTime
     * @param unit
     * @return
     * @throws Exception
     */
    Map<String, String> getDeviceInfo(String token, Integer expireTime, TimeUnit unit) throws Exception;
}
