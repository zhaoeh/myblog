package com.riskcontrol.api.utils;

import com.alibaba.nacos.common.utils.CollectionUtils;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.*;
import org.springframework.data.redis.support.atomic.RedisAtomicLong;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Slf4j
@Component
public class RedisUtil {


    @Resource
    RedisTemplate<Serializable, Object> redisTemplate;

    @Resource
    StringRedisTemplate stringRedisTemplate;

    @Autowired
    private RedissonClient redissonClient;

    public static RedisUtil redisUtil;

    @PostConstruct
    public void init() {
        redisUtil = this;
    }

    /**
     * 批量删除对应的value
     */
    public void remove(final String... keys) {
        for (String key : keys) {
            remove(key);
        }
    }

    /**
     * 批量删除key
     */
    public void removePattern(final String pattern) {
        Set<Serializable> keys = redisTemplate.keys(pattern);
        if (CollectionUtils.isNotEmpty(keys)) {
            redisTemplate.delete(keys);
        }
    }

    /**
     * 删除对应的value
     */
    public void remove(final String key) {
        if (exists(key)) {
            redisTemplate.delete(key);
        }
    }

    public void removeWithoutException(final String key) {
        try {
            if (exists(key)) {
                redisTemplate.delete(key);
            }
        } catch (Exception e) {
            log.error("remove redis key failed", e);
        }
    }


    /**
     * 判断缓存中是否有对应的value
     */
    public boolean exists(final String key) {
        Boolean result = redisTemplate.hasKey(key);
        if (null == result) {
            return false;
        }
        return result;
    }

    /**
     * 读取缓存
     */
    public <V> V get(final String key) {
        ValueOperations operations = redisTemplate.opsForValue();
        Object obj = operations.get(key);
        if (Objects.isNull(obj)) {
            return null;
        } else {
            return (V) obj;
        }
    }

    /**
     * 读取缓存
     */
    public String getString(final String key) {
        Object obj = redisTemplate.opsForValue().get(key);
        if (Objects.isNull(obj)) {
            return null;
        } else {
            return obj.toString();
        }
    }

    /**
     * key模糊查询
     */
    public <V> List<V> fuzzyGet(final String pattern) {
        Set<Serializable> keys = redisTemplate.keys(pattern);
        List<V> result = null;
        if (CollectionUtils.isNotEmpty(keys)) {
            result = new ArrayList<>();
            for (Serializable key : keys) {
                result.add((V) redisTemplate.opsForValue().get(key));
            }
        }
        return result;
    }

    /**
     * 写入缓存
     */
    public boolean set(final String key, Object value) {
        boolean result = false;
        try {
            ValueOperations<Serializable, Object> operations = redisTemplate.opsForValue();
            operations.set(key, value);
            result = true;
        } catch (Exception e) {
            log.error("Redis写入异常{}", e.getMessage(), e);
        }
        return result;
    }

    /**
     * 写入缓存
     */
    public boolean set(final String key, Object value, Integer expireTime,TimeUnit unit) {
        boolean result = false;
        try {
            if (unit == null){
                unit =TimeUnit.SECONDS;
            }
            ValueOperations<Serializable, Object> operations = redisTemplate.opsForValue();
            operations.set(key, value, expireTime, unit);
            result = true;
        } catch (Exception e) {
            log.error("Redis设置过期写入异常{}", e.getMessage(), e);
        }
        return result;
    }


    /**
     * 创建缓存key
     */
    public String getCacheKey(String targetName, String methodName, Object[] arguments) {
        StringBuilder sbu = new StringBuilder();
        sbu.append(targetName).append("_").append(methodName);
        if (arguments != null) {
            for (Object argument : arguments) {
                sbu.append("_").append(argument);
            }
        }
        return sbu.toString();
    }

    /**
     * 判断hash结构中是否有对应的value
     */
    public boolean hashexist(String hash, String key) {
        boolean flag = false;
        try {
            flag = redisTemplate.opsForHash().hasKey(hash, key);
            return flag;
        } catch (Exception e) {
            log.error("Redis 模板异常{}", e.getMessage(), e);
        }
        return flag;
    }

    public Object getHash(String hash, String hashKey) {
        Object object = null;
        try {
            HashOperations<Serializable, Object, Object> hashOperations = redisTemplate.opsForHash();
            object = hashOperations.get(hash, hashKey);
        } catch (Exception e) {
            log.error("Redis hash 取值异常{}", e.getMessage(), e);
        }
        return object;
    }

    public String getHashString(String hash, String hashKey) {
        try {
            HashOperations<Serializable, Object, Object> hashOperations = redisTemplate.opsForHash();
            Object obj = hashOperations.get(hash, hashKey);
            if (Objects.isNull(obj)) {
                return null;
            } else {
                return obj.toString();
            }
        } catch (Exception e) {
            log.error("Redis hash 取值异常{}", e.getMessage(), e);
        }
        return null;
    }

    public boolean setHash(String hash, String hashKey, Object hashValue) {
        boolean result = false;
        try {
            HashOperations<Serializable, Object, Object> hashOperations = redisTemplate.opsForHash();
            hashOperations.put(hash, hashKey, hashValue);
            result = true;
        } catch (Exception e) {
            log.error("Redis hash 写入异常{}", e.getMessage(), e);
        }
        return result;
    }

    public Long ttp(final String key) {
        Long second = 0L;
        try {
            second = redisTemplate.getExpire(key, TimeUnit.SECONDS);
        } catch (Exception e) {
            log.error("Redis获取过期时间异常{}", e.getMessage(), e);
        }
        return second;
    }

    public boolean removeHash(String hash, String key) {
        boolean result = false;
        if (hashexist(hash, key)) {
            try {
                HashOperations<Serializable, Object, Object> hashOperations = redisTemplate.opsForHash();
                hashOperations.delete(hash, key);
                result = true;
            } catch (Exception e) {
                log.error("Redis hash 删除异常{}", e.getMessage(), e);
            }
            return result;
        }
        return true;
    }

    /**
     * 设置过期时间
     */
    public Boolean expire(String key, int time, TimeUnit unit) {
        try {
            if (unit == null) {
                unit = TimeUnit.SECONDS;
            }
            return redisTemplate.expire(key, time, unit);
        } catch (Exception e) {
            log.error("设置过期时间异常{}", e);
            return false;
        }
    }

    /**
     * 获取过期时间
     */
    public Long getExpire(String key) {
        try {
            return redisTemplate.getExpire(key, TimeUnit.SECONDS);
        } catch (Exception e) {
            log.error("获取过期时间异常{}", e);
            return 0L;
        }
    }

    /**
     * 增加有序集合
     */
    public Boolean addZset(String key, Object value, double score) {
        try {
            return redisTemplate.opsForZSet().add(key, value, score);
        } catch (Exception e) {
            log.error("增加有序集合异常{}", e);
            return false;
        }
    }

    /**
     * 获取zset集合数量
     */
    public Long countZset(String key) {
        try {
            return redisTemplate.opsForZSet().size(key);
        } catch (Exception e) {
            log.error("获取zset集合数量异常{}", key, e);
            return 0L;
        }
    }

    /**
     * 获取zset指定范围内的集合
     */
    public Set<Object> rangeZset(String key, long start, long end) {
        try {
            return redisTemplate.opsForZSet().range(key, start, end);
        } catch (Exception e) {
            log.error("获取zset指定范围内的集合异常{}", key, start, end, e);
            return null;
        }
    }

    /**
     * 根据key和value 移除指定元素
     */
    public Long removeZset(String key, Object value) {
        return redisTemplate.opsForZSet().remove(key, value);

    }


    /**
     * 获取对应key和value的score
     */
    public Double score(String key, Object value) {
        return redisTemplate.opsForZSet().score(key, value);
    }

    /**
     * 指定范围内元素排序
     */
    public Set<Object> rangeByScore(String key, double v1, double v2) {
        return redisTemplate.opsForZSet().rangeByScore(key, v1, v2);
    }

    /**
     * 指定范围顺序值和score
     */
    public Set<ZSetOperations.TypedTuple<Object>> rangeWithScores(String key, int v1, int v2) {
        return redisTemplate.opsForZSet().rangeWithScores(key, v1, v2);
    }

    public Set<ZSetOperations.TypedTuple<String>> rangeWithScoresToString(String key, int v1, int v2) {
        return stringRedisTemplate.opsForZSet().rangeWithScores(key, v1, v2);
    }

    /**
     * 指定范围顺序值和score
     */
    public Set<ZSetOperations.TypedTuple<Object>> rangeByScoreWithScores(String key, int v1, int v2) {
        return redisTemplate.opsForZSet().rangeByScoreWithScores(key, v1, v2);
    }


    /**
     * score的增加or减少 zincrby
     */
    public Object incrScore(String key, Object obj, double score) {
        return redisTemplate.opsForZSet().incrementScore(key, obj, score);
    }

    /**
     * 排名
     */
    public Object rank(String key, Object obj) {
        return redisTemplate.opsForZSet().rank(key, obj);
    }


    /**
     * Redis List set
     */
    public Object listSet(String key, Object obj) {

        return redisTemplate.opsForList().leftPush(key, obj);
    }

    /**
     * Redis List Rpush
     */
    public Object listRightPush(String key, Object obj) {

        return redisTemplate.opsForList().rightPush(key, obj);
    }

    /**
     * Redis List RightRange
     */
    public Object listRightRange(String key) {

        return redisTemplate.opsForList().leftPop(key);
    }

    /**
     * Redis List RightRange
     */
    public Object listRemove(String key, long count, Object obj) {

        return redisTemplate.opsForList().remove(key, count, obj);
    }


    /**
     * Redis List 判断
     */
    public Object listRange(String key, int index, int next) {

        List<Object> list = redisTemplate.opsForList().range(key, index, next);
        return list;
    }

    /**
     * Redis Set set
     */
    public Object setSet(String key, Object obj) {

        return redisTemplate.opsForSet().add(key, obj);
    }

    /**
     * Redis Set printSet
     */
    public Object printSet(String key) {

        return redisTemplate.opsForSet().members(key);
    }


    public String getId() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String formatDate = sdf.format(new Date());
        String key = "key" + formatDate;
        Long incr = getIncr(key, getCurrent2TodayEndMillisTime());
        if (incr == 0) {
            incr = getIncr(key, getCurrent2TodayEndMillisTime());//从000001开始
        }
        DecimalFormat df = new DecimalFormat("000000");//6位序列号
        return formatDate + df.format(incr);
    }

    public Long getIncr(String key, long liveTime) {
        RedisAtomicLong entityIdCounter = new RedisAtomicLong(key, redisTemplate.getConnectionFactory());
        Long increment = entityIdCounter.getAndIncrement();

        if ((null == increment || increment.longValue() == 0) && liveTime > 0) {//初始设置过期时间
            entityIdCounter.expire(liveTime, TimeUnit.MILLISECONDS);//单位毫秒
        }
        return increment;
    }


    //现在到今天结束的毫秒数
    public Long getCurrent2TodayEndMillisTime() {
        Calendar todayEnd = Calendar.getInstance();
        // Calendar.HOUR 12小时制
        // HOUR_OF_DAY 24小时制
        todayEnd.set(Calendar.HOUR_OF_DAY, 23);
        todayEnd.set(Calendar.MINUTE, 59);
        todayEnd.set(Calendar.SECOND, 59);
        todayEnd.set(Calendar.MILLISECOND, 999);
        return todayEnd.getTimeInMillis() - new Date().getTime();
    }

    public Boolean setIfAbsent(String key, String value, Duration timeout) {
        return redisUtil.redisTemplate.opsForValue().setIfAbsent(key, value, timeout);
    }

    public List<String> getZsetValueByMinAndMax(String zKey, Long min, Long max) {
        Set<Object> objects = redisTemplate.opsForZSet().rangeByScore(zKey, min.doubleValue(), max.doubleValue());
        if (CollectionUtils.isEmpty(objects)) {
            return new ArrayList<>();
        }
        return objects.stream().filter(Objects::nonNull).map(Objects::toString).collect(Collectors.toList());
    }


    public List<String> rangeByScoreWithScores(String key) {
        long page = 1;
        long pageSize = 70;
        boolean hasMoreElement = true;
        List<String> list = new ArrayList<>();
        Long size = redisTemplate.opsForZSet().size(key);
        while (hasMoreElement) {
            long startIndex = (page - 1) * pageSize;
            long endIndex = startIndex + pageSize - 1;

            Set<Object> range = Optional.ofNullable(redisTemplate.opsForZSet().range(key, startIndex, endIndex)).orElse(new HashSet<>());
            hasMoreElement = range.size() == pageSize;

            List<String> collect = range.stream().filter(Objects::nonNull).map(Objects::toString).collect(Collectors.toList());
            log.info("rangeByScoreWithScores- origin size:{}, filter size:{}, zset size:{}", range.size(), collect.size(), size);
            list.addAll(collect);
            page++;
        }
        return list;
    }

    public boolean tryLock(String key, long expiration, long waitTime, TimeUnit timeUnit) {
        try {
            return redissonClient.getFairLock(key).tryLock(waitTime, expiration, timeUnit);
        } catch (Exception e) {
            log.error("tryLock failed, key:{}", key, e);
            return false;
        }
    }

    public boolean unLock(String key) {
        try {
            redissonClient.getFairLock(key).unlock();
        } catch (Exception e) {
            log.error("unLock failed", e);
            return false;
        }
        return true;
    }

    /**
     * 获取redis中指定key对应的hash对象
     *
     * @param key redis中的键
     * @return redis中指定key对应的hash对象
     */
    public Map entries(String key) {
        Map hash = redisTemplate.opsForHash().entries(key);
        return hash;
    }
}
