package com.riskcontrol.api.controller;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.riskcontrol.api.utils.RedisUtil;
import com.riskcontrol.common.client.PhoneNumberBlacklistFeign;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.request.api.*;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.api.PhoneCoolingDownPeriodRsp;
import com.riskcontrol.common.entity.response.api.PhoneNumberBlacklistRsp;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * @program: riskcontrol-api
 * @description: 手机号黑名单 前端控制器
 * @author: Colson
 * @create: 2023-09-26 14:19
 */
@RestController
@RequestMapping("/phoneNumberBlacklist")
public class PhoneNumberBlacklistController {

    @Resource
    private PhoneNumberBlacklistFeign phoneNumberBlacklistFeign;
    @Resource
    private RedisUtil redisUtil;

    @PostMapping("page")
    @ApiOperation(value = "手机号码黑名单分页列表")
    public Response<PageModel<PhoneNumberBlacklistRsp>> getPage(@RequestBody PhoneNumberBlacklistPageRequest request) {
        return phoneNumberBlacklistFeign.getPage(request);
    }

    @PostMapping("list")
    @ApiOperation(value = "手机号码黑名单列表")
    public Response<List<PhoneNumberBlacklistRsp>> getList(@RequestBody PhoneNumberBlacklistRequest request) {
        return phoneNumberBlacklistFeign.getList(request);
    }

    @PostMapping("one")
    @ApiOperation(value = "根据手机号码查询黑名单（单条查询）")
    @SentinelResource(value = "get_one_phone_number_black", blockHandler = "blockHandler")
    public Response<PhoneNumberBlacklistRsp> getOne(@RequestBody PhoneNumberBlacklistGetOneRequest request) {
        String key = String.format(Constant.PHONE_BLACK_LIST_KEY, request.getPhoneMd5());
        Response<PhoneNumberBlacklistRsp>  blacklistFeignOne = redisUtil.get(key);
        if (Objects.isNull(blacklistFeignOne)){
            blacklistFeignOne = phoneNumberBlacklistFeign.getOne(request);
            if (ObjectUtils.isNotEmpty(blacklistFeignOne.getBody())) {
                redisUtil.set(key, blacklistFeignOne,2,TimeUnit.HOURS);
            }
        }
        return blacklistFeignOne;
    }

    @PostMapping("create")
    @ApiOperation(value = "创建手机号码黑名单")
    public Response<Boolean> create(@Valid @RequestBody PhoneNumberBlacklistCreateRequest request) {
        return phoneNumberBlacklistFeign.create(request);
    }


    @PostMapping("updateHistory")
    @ApiOperation(value = "更新手机号码黑名单绑定用户ID")
    public Response<Boolean> updateHistory(@Valid @RequestBody PhoneNumberBlacklistUpdateHistoryRequest request) {
        return phoneNumberBlacklistFeign.updateHistory(request);
    }


    @PostMapping("updateStatus")
    @ApiOperation(value = "更新手机号码黑名单状态")
    public Response<Boolean> updateStatus(@Valid @RequestBody PhoneNumberBlacklistUpdateStatusRequest request) {
        return phoneNumberBlacklistFeign.updateStatus(request);
    }

    @PostMapping("coolingDownPeriod")
    @ApiOperation(value = "查询手机号码冷却期")
    public Response<PhoneCoolingDownPeriodRsp> coolingDownPeriod(@RequestBody PhoneCoolingDownPeriodRequest request) {
        return phoneNumberBlacklistFeign.coolingDownPeriod(request);
    }


}
