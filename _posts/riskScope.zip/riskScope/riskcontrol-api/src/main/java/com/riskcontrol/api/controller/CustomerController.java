package com.riskcontrol.api.controller;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.alibaba.fastjson.JSONObject;
import com.cn.schema.customers.CreateKycRequestResponse;
import com.cn.schema.customers.ModifyKycRequestResponse;
import com.cn.schema.customers.WSCustomers;
import com.cn.schema.customers.WSKycSheetRequest;
import com.cn.schema.request.QueryCountResponse;
import com.github.xiaoymin.knife4j.annotations.Ignore;
import com.gw.datacenter.vo.pagainate.PageModel;
import com.riskcontrol.api.entity.request.KycDispatchConfirmReq;
import com.riskcontrol.api.entity.request.*;
import com.riskcontrol.api.entity.response.OcrIdentifyRsp;
import com.riskcontrol.api.entity.response.PageModelExt;
import com.riskcontrol.api.service.CustomerApiService;
import com.riskcontrol.api.utils.RedisUtil;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.request.ApiQueryCustomersRequest;
import com.riskcontrol.common.entity.request.BaseReq;
import com.riskcontrol.common.entity.request.kyc.*;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.kyc.RiskQueryKycRequestResponse;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import static com.riskcontrol.common.enums.ResultEnum.BAD_REQUEST;

@Slf4j
@RestController
@RequestMapping(value = "customer", method = RequestMethod.POST)
public class CustomerController {
    private final String KYC_CREATE_LOCK = "kyc:create:lock:";
    private final String KYC_PBC_APPROVE_LOCK = "kyc&pbc:approve:lock:";

    @Autowired
    private CustomerApiService customerService;

    @Autowired
    private RedisUtil redisUtil;

    @ApiOperation(value = "完善用户信息", notes = "完善用户信息", httpMethod = "POST")
    @RequestMapping(value = "improveUserProfile")
    @ResponseBody
    @SentinelResource(value = "create_web_kyc", blockHandler = "blockHandler")
    public Response<Boolean> improveUserProfile(@RequestBody ImproveCustomerProfileReq optionReq) {
        Response<Boolean> response = new Response<>();
        String lockKey = KYC_CREATE_LOCK+optionReq.getCustomerName();
        boolean lockd =false;
        try{
            lockd = redisUtil.tryLock(lockKey, 30, -1, TimeUnit.SECONDS);
            if(lockd){
                response.setBody(customerService.improveUserProfile(optionReq));
            }else{
                response.setHead(ResultEnum.FAIL.getCode(), "Do not repeat the request");
            }
        }finally {
            if(lockd){
                redisUtil.unLock(lockKey);
            }
        }
        return response;
    }

    @ApiOperation(value = "OCR图片识别", notes = "OCR图片识别", httpMethod = "POST")
    @RequestMapping(value = "ocrIdentify")
    @ResponseBody
    public Response<OcrIdentifyRsp> ocrIdentify(@RequestBody OcrIdentifyReq req) {
        log.info("ocrIdentify start");
        Response<OcrIdentifyRsp> response = new Response<>();
        response.setBody(customerService.ocrIdentify(req));
        return response;
    }

    @ApiOperation(value = "审批玩家KYC信息", notes = "审批玩家KYC信息", httpMethod = "POST")
    @PostMapping(value = "approveKYCInfo")
    @ResponseBody
    public Response<Boolean> approveKYCInfo(@RequestBody UpdateKycRequestReq req) {
        log.info("approveKYCInfo 进来了---------------------      ");
        Response<Boolean> response = new Response<>();
        String lockKey = KYC_PBC_APPROVE_LOCK+req.getLoginName();
        boolean lockd =false;
        try{
            lockd =redisUtil.tryLock(lockKey,30,-1, TimeUnit.SECONDS);
            if(lockd){
                response.setBody(customerService.updateKycRequest(req));
            }else{
                response.setHead(ResultEnum.FAIL.getCode(), "Do not repeat the request");
            }
        }finally {
            if(lockd){
                redisUtil.unLock(lockKey);
            }
        }
        return response;
    }

    @ApiOperation(value = "审批玩家PBC信息", notes = "审批玩家PBC信息", httpMethod = "POST")
    @PostMapping(value = "approvePBCInfo")
    @ResponseBody
    public Response<Boolean> approvePBCInfo(@RequestBody UpdateKycRequestReq req) throws Exception {
        Response<Boolean> response = new Response<>();
        String lockKey = KYC_PBC_APPROVE_LOCK+req.getLoginName();
        boolean lockd =false;
        try{
            lockd =redisUtil.tryLock(lockKey,30,-1, TimeUnit.SECONDS);
            if(lockd){
                response.setBody(customerService.updatePbcRequest(req));
            }else{
                response.setHead(ResultEnum.FAIL.getCode(), "Do not repeat the request");
            }
        }finally {
            if(lockd){
                redisUtil.unLock(lockKey);
            }
        }
        return response;
    }

    @ApiOperation(value = "查询(导出)玩家KYC表单信息", notes = "查询(导出)玩家KYC表单信息", httpMethod = "POST")
    @PostMapping(value = "queryKycSheetRequests")
    @ResponseBody
    public Response<PageModel<WSKycSheetRequest>> queryKycSheetList(@RequestBody QueryKycRequestReq req) throws Exception {
        return customerService.queryKycSheetRequests(req);
    }

    @ApiOperation(value = "批量审核PBC", httpMethod = "POST")
    @PostMapping("/uploadPBCInfoBatch")
    @Ignore
    @ApiImplicitParams({@ApiImplicitParam(paramType = "form", required = true, name = "file", value = "上传Excel模板文件", allowMultiple = true, dataType = "MultipartFile")})
    // @ApiResponses({@ApiResponse(code = 200,message = "ResponseResult =>'body':[{\"body\":\"1,2,3,4,5,6,7,8,9,10\",\"head\":{\"cost\":0,\"errCode\":\"0000\",\"errMsg\":\"successful operation\"}}]")})
    //@Secure(responseLog = false)
    public Response uploadPBCInfoBatchNew(HttpServletRequest request,
                                          @RequestParam(value = "file") MultipartFile files) throws Exception {
        Response resp = new Response<>();

        try {
            if (Objects.nonNull(files)) {
                resp = customerService.uploadPBCInfoBatchNew(files, request);
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error("{}  批量审核PBC(uploadPBCInfoBatch) 出异常了，异常信息：{}", new Date(), e.getMessage());
        } finally {
            log.info("uploadPBCInfoBatchNew resp {}", JSONObject.toJSONString(resp));
            return resp;
        }
    }

    @ApiOperation(value = "请求KYC审核派单", notes = "请求KYC审核派单", httpMethod = "POST")
    @PostMapping(value = "kycDispatch")
    @ResponseBody
    public Response<PageModelExt<KycRequest>> kycDispatch(@RequestBody BaseReq req) {
        Response response = new Response();
        response.setBody(customerService.kycDispatch(req));
        return response;
    }

    @ApiOperation(value = "confirm 接受KYC审核派单", notes = "confirm 接受KYC审核派单", httpMethod = "POST")
    @PostMapping(value = "kycDispatchConfirm")
    @ResponseBody
    public Response kycDispatchConfirm(@RequestBody KycDispatchConfirmReq req) throws Exception {
        Response response = new Response();
        response.setBody(customerService.kycDispatchConfirm(req));
        return response;
    }



    @ApiOperation(value = "查询玩家KYC信息", notes = "查询玩家KYC信息", httpMethod = "POST")
    @PostMapping(value = "queryKycRequests")
    @ResponseBody
    public Response<PageModel<WSKycRequestGw>> queryKycRequestsNew(@RequestBody QueryKycRequestReq req) throws Exception {
        log.info("CustomerController queryKycRequests start --------------------------------------------------------------------------- {}", new Date());
        return customerService.queryKycRequestsNew(req);
    }



    @ApiOperation(value = "kycLog查询", notes = "kycLog查询", httpMethod = "POST")
    @PostMapping(value = "queryPageByKycRequestId")
    @ResponseBody
    public Response queryPageByKycRequestId(@RequestBody QueryPageByKycRequestId req) throws Exception {
        return customerService.queryPageByKycRequestId(req);
    }

    @ApiOperation(value = "kyc请求查询", notes = "kyc请求查询", httpMethod = "POST")
    @PostMapping(value = "query")
    @ResponseBody
    @SentinelResource(value = "query_customer_kyc", blockHandler = "blockHandler")
    public Response<RiskQueryKycRequestResponse> queryKycRequest(@RequestBody RiskQueryKycRequestRequest req) throws Exception {
        return customerService.queryKycRequest(req);
    }
    @ApiOperation(value = "查询用户kyc状态（1>0>-1）", notes = "查询用户kyc状态(1:通过；0未审批；-1未通过)", httpMethod = "POST")
    @PostMapping(value = "queryKycRequestFlag")
    @ResponseBody
    public Response<Integer> queryKycRequestFlag(@RequestBody RiskQueryKycRequest req) throws Exception {
        return customerService.queryKycRequestFlag(req);
    }
    @ApiOperation(value = "修改派单用户配置", notes = "修改派单用户配置", httpMethod = "POST")
    @PostMapping(value = "modifyCustomConfiguration")
    @ResponseBody
    public Response<JSONObject> modifyCustomConfiguration(@RequestBody JSONObject req) {
        Response response = new Response();
        response.setBody(customerService.modifyCustomConfiguration(req));
        return response;
    }

    @ApiOperation(value = "查询客户信息", notes = "查询客户信息", httpMethod = "POST")
    @PostMapping(value = "loadCustomers")
    @ResponseBody
    public Response<List<WSCustomers>> loadCustomers(@RequestBody ApiQueryCustomersRequest req) {
        log.info("CustomerController loadCustomers req={}", req);
        Response response = new Response();
        response.setBody(customerService.loadCustomers(req));
        return response;
    }

    @ApiOperation(value = "自动通过KYC和PBC", notes = "自动通过KYC和PBC", httpMethod = "POST")
    @PostMapping(value = "autoApproveKycAndPbc")
    @ResponseBody
    public Response<ModifyKycRequestResponse> autoApproveKycAndPbc(@RequestBody RiskUpdateKycRequestRequest req) {
        String lockKey = KYC_CREATE_LOCK+req.getWsKycRequest().getLoginName();
        boolean lockd = false;
        try{
            lockd = redisUtil.tryLock(lockKey,30,-1, TimeUnit.SECONDS);
            if(lockd){
                return customerService.autoApproveKycAndPbc(req);
            }else{
                return new Response<>(ResultEnum.FAIL.getCode(), "Do not repeat the request");
            }
        }finally {
            if(lockd){
                redisUtil.unLock(lockKey);
            }
        }
    }

    @ApiOperation(value = "创建KYC", notes = "创建KYC", httpMethod = "POST")
    @PostMapping(value = "addKycRequest")
    @ResponseBody
    public Response<CreateKycRequestResponse> addKycRequest(@RequestBody RiskCreateKycRequestRequest req) {
        String lockKey = KYC_CREATE_LOCK+req.getWsKycRequest().getLoginName();
        boolean lockd = false;
        try{
            lockd = redisUtil.tryLock(lockKey,30,-1, TimeUnit.SECONDS);
            if(lockd){
                return customerService.addKycRequest(req);
            }else{
                return new Response<>(ResultEnum.FAIL.getCode(), "Do not repeat the request");
            }
        }finally {
            if(lockd){
                redisUtil.unLock(lockKey);
            }
        }
    }

    @ApiOperation(value = "更新KYC", notes = "更新KYC", httpMethod = "POST")
    @PostMapping(value = "update")
    @ResponseBody
    public Response<ModifyKycRequestResponse> updateKycRequest(@RequestBody RiskUpdateKycRequestRequest req) {
        return customerService.updateKycRequest(req);
    }

    @ApiOperation(value = "PBC修改状态", notes = "PBC修改状态", httpMethod = "POST")
    @PostMapping(value = "pbcModifyStatus")
    @ResponseBody
    public Response<ModifyKycRequestResponse> pbcModifyStatus(@RequestBody RiskUpdateKycRequestRequest req) {
        return customerService.pbcModifyStatus(req);
    }

    @ApiOperation(value = "PBC修改状态", notes = "PBC修改状态", httpMethod = "POST")
    @PostMapping(value = "queryWaitPendingCount")
    @ResponseBody
    public Response<QueryCountResponse> queryWaitPendingCount(@RequestBody KycRequest req) {
        return customerService.queryWaitPendingCount(req);
    }

    @ApiOperation(value = "验证KYC证件信息是否存在", notes = "验证KYC证件信息是否存在", httpMethod = "POST")
    @PostMapping(value = "queryKycIdAndTypeExists")
    @ResponseBody
    public Response<Boolean> queryKycIdAndTypeExists(@RequestBody @Validated ValidKycIdReq req) {
        return Response.body(customerService.validKycIdAndType(req));
    }
    @ApiOperation(value = "查询指定用户kyc信息，最有效的一条 （已审批>待审批>拒绝>未提交）", notes = "查询指定用户kyc信息，最有效的一条 （已审批>待审批>拒绝>未提交）", httpMethod = "POST")
    @PostMapping(value = "queryKycByLoginNameOrderOne")
    @ResponseBody
    public Response<KycRequest> queryKycByLoginNameOrderOne(@RequestBody RiskQueryKycRequest req) {
        if(StringUtils.isBlank(req.getCustomerId())){
            throw new BusinessException("customerId can't blank",BAD_REQUEST.getCode());
        }
        return customerService.queryKycByLoginNameOrderOne(req);
    }
    @ApiOperation(value = "更新kyc扩展信息", notes = "更新kyc扩展信息", httpMethod = "POST")
    @PostMapping(value = "updateKycExt")
    @ResponseBody
    public Response<ModifyKycRequestResponse> updateKycExt(@RequestBody @Validated KycExtUpdateReq req) {
        return customerService.updateKycExt(req);
    }


}
