package com.riskcontrol.api.ocr;


import com.google.api.gax.core.FixedCredentialsProvider;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.vision.v1.*;
import com.google.protobuf.ByteString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.threeten.bp.Duration;

import javax.annotation.PreDestroy;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * @Auther: yannis
 * @Date: 2023/4/3 11:39
 * @Description:
 */
@Component
public class OcrClient {
    private static final Logger logger = LoggerFactory.getLogger(OcrClient.class);

    @Value("${google.service.account.key}")
    private String keyContent;

    public OcrClient() {
    }

    private static ImageAnnotatorClient client;

    public synchronized ImageAnnotatorClient getImageAnnotatorClient() throws IOException {
        long startTime = System.currentTimeMillis();
        logger.info("创建ocr客户端 start....");
        if (client != null && !client.isShutdown() && !client.isTerminated()) {
            return client;
        }
        InputStream keyStream = new ByteArrayInputStream(keyContent.getBytes(StandardCharsets.UTF_8));
        // 创建认证凭据对象
        GoogleCredentials credential = GoogleCredentials.fromStream(keyStream);
//        GoogleCredentials credential = GoogleCredentials.getApplicationDefault(); //获取默认凭证，是通过环境变量获取到配置文件地址
        ImageAnnotatorSettings.Builder imageAnnotatorSettingsBuilder = ImageAnnotatorSettings.newBuilder();
        imageAnnotatorSettingsBuilder.batchAnnotateImagesSettings()
                .setRetrySettings(
                        imageAnnotatorSettingsBuilder
                                .batchAnnotateImagesSettings()
                                .getRetrySettings()
                                .toBuilder()
                                .setLogicalTimeout(Duration.ofSeconds(10))
                                .build());
        ImageAnnotatorSettings settings = imageAnnotatorSettingsBuilder.setCredentialsProvider(FixedCredentialsProvider.create(credential)).build();

        //创建ocr 客户端
        ImageAnnotatorClient imageAnnotatorClient = ImageAnnotatorClient.create(settings);
        client = imageAnnotatorClient;
        long endTime = System.currentTimeMillis();
        logger.info("创建ocr客户端 耗时：{}", endTime - startTime);
        return imageAnnotatorClient;
    }

    /**
     * 从图像中提取文本并将结果作为字符串返回
     *
     * @param filePath
     * @return
     * @throws IOException
     */
    public AnnotateImageResponse analyzeImage(String filePath) throws IOException {
        return analyzeImage(filePath, Feature.Type.TEXT_DETECTION);
    }

    /**
     * 从图像中提取文本并将结果作为字符串返回
     *
     * @param imageUrl
     * @param type
     * @return
     * @throws IOException
     */
    public AnnotateImageResponse analyzeImage(String imageUrl, Feature.Type type) throws IOException {
        long startTime = System.currentTimeMillis();

        if (client == null || client.isShutdown() || client.isTerminated()) {
            client = getImageAnnotatorClient();
        }
        logger.info("调用ocr接口读取数据 start....");
        List<AnnotateImageRequest> requests = new ArrayList<>();
        logger.info("调用ocr接口读取数据 imageUrl={}", imageUrl);
        URL url = new URL(imageUrl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(2 * 1000);
        ByteString imgBytes = ByteString.readFrom(conn.getInputStream());
        Image img = Image.newBuilder().setContent(imgBytes).build();
        logger.info("调用ocr接口读取数据 读取图片 Image={}", img.hasSource());

        Feature feat = Feature.newBuilder().setType(type).build();
        AnnotateImageRequest request = AnnotateImageRequest.newBuilder().addFeatures(feat).setImage(img).build();
        requests.add(request);

        BatchAnnotateImagesResponse response = client.batchAnnotateImages(requests);

        AnnotateImageResponse imageResponse = response.getResponses(0);
        long endTime = System.currentTimeMillis();
        logger.info("调用google ocr识别文字 耗时：{}", endTime - startTime);
        return imageResponse;
    }

    /**
     * 从本地图像中提取文本并将结果作为字符串返回
     *
     * @param filePath
     * @param type
     * @return
     * @throws IOException
     */
    public AnnotateImageResponse analyzeLocalImage(String filePath, Feature.Type type) throws IOException {
        if (client == null) {
            client = getImageAnnotatorClient();
        }
        List<AnnotateImageRequest> requests = new ArrayList<>();
        ByteString imgBytes = ByteString.readFrom(new FileInputStream(filePath));

        Image img = Image.newBuilder().setContent(imgBytes).build();
        Feature feat = Feature.newBuilder().setType(type).build();
        AnnotateImageRequest request = AnnotateImageRequest.newBuilder().addFeatures(feat).setImage(img).build();
        requests.add(request);

        BatchAnnotateImagesResponse response = client.batchAnnotateImages(requests);

        AnnotateImageResponse imageResponse = response.getResponses(0);
        return imageResponse;
    }

    @PreDestroy
    public void cleanUp() {
        if (client != null) {
            client.close();
        }
    }
}
