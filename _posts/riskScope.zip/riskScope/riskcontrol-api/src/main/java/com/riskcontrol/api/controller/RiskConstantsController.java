package com.riskcontrol.api.controller;

import com.riskcontrol.api.service.RiskConstantsService;
import com.riskcontrol.common.entity.request.api.QueryRiskConstants;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.api.RiskConstantsRsp;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Description: 风控字典数据 前端控制器
 * @Auther: yannis
 * @create: 2024-01-12
 */
@RestController
@RequestMapping("/riskConstants")
public class RiskConstantsController {

    @Autowired
    private RiskConstantsService riskConstantsService;

    @PostMapping(value = "/queryLabelList")
    @ApiOperation(value = "查询用户标签列表")
    public Response<List<RiskConstantsRsp>> queryLabelList(@RequestBody QueryRiskConstants request) {
        Response<List<RiskConstantsRsp>> response = new Response<>();
        response.setBody(riskConstantsService.queryLabelList(request));
        return response;
    }
}
