package com.riskcontrol.api.service;


/**
 * @author sanji
 */
public interface RiskBlackService{


    /**
     *
     * @param loginName
     * @return
     */
    boolean getBlackStatus(String loginName);

}
