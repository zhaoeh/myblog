//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.riskcontrol.api.template;

import com.alibaba.fastjson.JSON;
import com.dingxianginc.ctu.client.CtuClient;
import com.dingxianginc.ctu.client.CtuConstidClient;
import com.dingxianginc.ctu.client.model.CtuRequest;
import com.dingxianginc.ctu.client.model.CtuResponse;
import com.dingxianginc.ctu.client.model.RiskLevel;
import java.util.HashMap;
import java.util.Map;

public class Demo {
    public static final String url = "http://sec.dingxiang-inc.com/ctu/event.do";
    public static final String appId = "d86cb2a29fxxxxxxxxx";
    public static final String appSecret = "f6e7fea43fxxxxxxxxxxx";

    public Demo() {
    }

    public static void main(String[] param) throws Exception {

        CtuConstidClient ctuConstidClient = new CtuConstidClient("http://1.94.96.102:7776/","4133f94f7cae3772b172caf0baf514e4","3ab6a118d66a6beea9a299cf28f733f8");
        String result = ctuConstidClient.getDeviceInfo("67340997L8qpA0DEBL03iqRKsOFEx9BII8xya8x1");
        System.out.println("#3161#");
//        Map<String, Object> data = new HashMap();
//        data.put("const_id", "N4RG6TtsY6ILK5ePY6HVtjj12pu5Yi5wnjnbaUI41");
//        data.put("user_id", "12345");
//        data.put("phone_number", "17800000000");
//        data.put("ip", "125.121.232.219");
//        CtuRequest request = new CtuRequest();
//        request.setEventCode("default_test_event");
//        request.setData(data);
//        request.setFlag("test1");
//        CtuClient client = new CtuClient("http://1.94.96.102:7776/ctu/event.do", "4e64081b1c2b3dbe7e389590ffe8b5bd", "320980eeecfa42afd056fb3937bb35cd");
//        CtuResponse response = client.checkRisk(request);
//        if (RiskLevel.ACCEPT.equals(response.getResult().getRiskLevel())) {
//            System.out.println(JSON.toJSONString(response));
//        } else if (RiskLevel.REVIEW.equals(response.getResult().getRiskLevel())) {
//            System.out.println(JSON.toJSONString(response));
//        } else if (RiskLevel.REJECT.equals(response.getResult().getRiskLevel())) {
//            System.out.println(JSON.toJSONString(response));
//        }

    }
}
