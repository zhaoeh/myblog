package com.riskcontrol.api.entity.request;

import com.riskcontrol.common.entity.request.BaseReq;
import com.riskcontrol.common.entity.zoloz.InitRealIDBean;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/10/2 14:00
 */
@AllArgsConstructor
@NoArgsConstructor
@ApiModel("初始化id+人脸接口")
@Data
public class InitRealIDReq extends InitRealIDBean {

    @ApiModelProperty(required = true, value = "执行步骤1:执行初始化,2:执行完善信息" )
    private String step;
    @ApiModelProperty(required = true, value = "用户名" )
    @NotBlank(message = "login name can't blank")
    private String loginName;
    @ApiModelProperty(required = true, value = "用户id" )
    @NotBlank(message = "customerId can't blank")
    private String customerId;
    @ApiModelProperty(required = true, value = "血缘标识：BP、GP" )
    @NotBlank(message = "tenant can't blank")
    private String tenant;
    @ApiModelProperty(required = true, value = "渠道(3:GLIFE,4:GPO,5:LAZADA,6:MAYA,7:PERYAGAME,99WEBSITE,98:人工" )
    @NotBlank(message = "channel can't blank")
    private String channel;


    /**
     * BaseReq 对象
     */
    @ApiModelProperty(required = true, value = "产品编号[必填]", example = "A03", position = 0)
    private String productId;

    @ApiModelProperty(hidden = true, required = true, value = "应用编号[必填]", example = "A03H501")
    private String appId;

    @ApiModelProperty(hidden = true, required = false, value = "版本号[app必填, web端不传]", example = "1.0.0")
    private String v;

    @ApiModelProperty(hidden = true, required = true, value = "请求编号[必填]", example = "76e8bc82e91cf74b97a0722b4616f1f8")
    private String qid;

    @ApiModelProperty(hidden = true, required = true, value = "请求签名[必填]", example = "f2a748bbeee74f2b8de2a3c23d22ac93")
    private String sign;

    @ApiModelProperty(hidden = true, required = false, value = "请求域名[app必填, web端不传]", example = "www.hygame03.com")
    private String domainName;

    @ApiModelProperty(hidden = true, required = false, value = "会话token", example = "e8dab5c23407946dbaa528325cf1a07a")
    private String token;

    @ApiModelProperty(hidden = true, required = false, value = "渠道编号或域名", example = "100001/www.a03.com")
    private String parentId;

    @ApiModelProperty(hidden = true, required = false, value = "设备编号", example = "100001")
    private String deviceId;

    @ApiModelProperty(hidden = true, required = false, value = "IP地址[不传]", example = "127.0.0.1")
    private String ipAddress;

    @ApiModelProperty(hidden = true, value = "传递应用编号", example = "A03DS01")
    private String srcAppId;

    @ApiModelProperty(hidden = true, value = "传递应用版本号", example = "2.1.0")
    private String srcV;

    @ApiModelProperty(hidden = true)
    private String postBody;

    @ApiModelProperty(hidden = true, value = "请求域名", example = "www.ag88220.com")
    private String host;

    @ApiModelProperty(hidden = true, value = "WEB端(H5&APP)请求URI协议名", example = "https")
    private String uriScheme;

    @ApiModelProperty(hidden = true, value = "操作员", example = "")
    private String operator;

    @ApiModelProperty(hidden = true, value = "语言参数[默认en]", example = "en")
    private String lang = "en";

    @ApiModelProperty(hidden = true, value = "mac地址(针对桌面端)", example = "08:00:20:0A:8C:6D")
    private String mac;
}
