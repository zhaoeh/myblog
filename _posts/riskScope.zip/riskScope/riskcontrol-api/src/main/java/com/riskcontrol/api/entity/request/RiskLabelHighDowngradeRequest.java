package com.riskcontrol.api.entity.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @program: riskcontrol-api
 * @description: 临时对象-风险用户降级
 * @author: Colson
 * @create: 2024-01-11 18:14
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Accessors(chain = true)
public class RiskLabelHighDowngradeRequest {

    @ApiModelProperty(value = "用户ID", required = true)
    @NotNull(message = "customer id cannot be empty")
    private Long customerId;

    @ApiModelProperty(value = "用户名", required = true)
    @NotNull(message = "loginName id cannot be empty")
    private String loginName;

    @ApiModelProperty(value = "产品ID")
    private String productId;

    @ApiModelProperty(value = "操作人", required = true)
    @NotBlank(message = "operator cannot be empty")
    private String operator;

    @ApiModelProperty(value = "备注", required = true)
    @NotBlank(message = "remarks cannot be empty")
    private String remarks;


}
