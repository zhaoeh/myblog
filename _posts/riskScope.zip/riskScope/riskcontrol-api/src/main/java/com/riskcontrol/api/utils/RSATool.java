package com.riskcontrol.api.utils;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Objects;

public class RSATool {

	private static final int KEY_SIZE = 1024;

	private static final String algorithm = "RSA";// jdk实际上是RSA/ECB/PKCS1Padding

	private static final Logger logger = LoggerFactory.getLogger(RSATool.class);
	
	private static BouncyCastleProvider bouncyCastleProvider = null;// 默认RSA/None/NoPadding

	/**
	 * 加密公钥，后端传给前端数据需要加密 时使用
	 */
	public static String publicKeyBase64 = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC8OIF8Z0mCekFBdltIsvlbAZGnddb6lheGZWjdY+qyl4hThuPej3+1Id57Y0KWb5PCSpWo7bM5xtVV8GC+vGPwNTwEzrReRQ1SkL+qxw/5BGYKNfhGAfAQBxBJdWafksdlhzgbCzcr7ySE6qxRrqzfS8qNCeTHVmijLA5Jca3q6QIDAQAB";

	public static synchronized BouncyCastleProvider getBouncyCastleInstance() {
		if (bouncyCastleProvider == null) {
			bouncyCastleProvider = new BouncyCastleProvider();
		}
		return bouncyCastleProvider;
	}

	public static String encrypt(String data){
		return encrypt(data,null);
	}

	public static String encrypt(String data, String publicKey) {
		return encrypt(data,publicKey,0);
	}

    public static String encrypt(String data, String inputPublicKey, int type) {
		String publicKey = inputPublicKey;
		if(StringUtils.isBlank(publicKey)){
			publicKey = publicKeyBase64;
		}
        try {
            X509EncodedKeySpec pubX509 = new X509EncodedKeySpec(Base64.decodeBase64(publicKey.getBytes()));
            KeyFactory keyf = KeyFactory.getInstance(algorithm);
            Cipher cipher;
            if (1 == type) {
                // android解密方式需要指定bouncyCastleProvider
                cipher = Cipher.getInstance(algorithm, getBouncyCastleInstance());
            } else {
                cipher = Cipher.getInstance(algorithm);
            }
            cipher.init(Cipher.ENCRYPT_MODE, keyf.generatePublic(pubX509));
            byte[] resultBytes;
            byte[] srcBytes = data.getBytes();
            int segmentSize = KEY_SIZE / 8 - 11;
			resultBytes = cipherDoFinal(cipher, srcBytes, segmentSize); // 分段加密
			return Base64.encodeBase64String(resultBytes);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

	public static String decrypt(String data, String privateKey) {
		try {
			PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec(Base64.decodeBase64(privateKey.getBytes()));
			KeyFactory keyf = KeyFactory.getInstance(algorithm);
			PrivateKey privKey = keyf.generatePrivate(priPKCS8);
			Cipher cipher = Cipher.getInstance(algorithm);
			cipher.init(Cipher.DECRYPT_MODE, privKey);
			int segmentSize = KEY_SIZE / 8;
			byte[] srcBytes = Base64.decodeBase64(data);
			byte[] decBytes;
			decBytes = cipherDoFinal(cipher, srcBytes, segmentSize);
			if(Objects.nonNull(decBytes)){
				return new String(decBytes, StandardCharsets.UTF_8);
			}
		} catch (Exception e) {
			logger.error("解密失败:{}",e.getMessage(), e);
		}
		return null;
	}

	public static String decrypt(String data, String privateKey, int type) {
		try {
			PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec(Base64.decodeBase64(privateKey.getBytes()));
			KeyFactory keyf = KeyFactory.getInstance(algorithm);
			PrivateKey privKey = keyf.generatePrivate(priPKCS8);
			Cipher cipher;
			if (1 == type) {
				// android解密方式需要指定bouncyCastleProvider
				cipher = Cipher.getInstance(algorithm, getBouncyCastleInstance());
			} else {
				cipher = Cipher.getInstance(algorithm);
			}
			cipher.init(Cipher.DECRYPT_MODE, privKey);
			int segmentSize = KEY_SIZE / 8;
			byte[] srcBytes = Base64.decodeBase64(data);
			byte[] decBytes;
			decBytes = cipherDoFinal(cipher, srcBytes, segmentSize);
			return new String(decBytes, StandardCharsets.UTF_8);
		} catch (Exception e) {
			logger.error("解密失败", e);
		}
		return null;
	}

	public static void createKeyPairs() {
		try {
			KeyPairGenerator generator = KeyPairGenerator.getInstance(algorithm);
			generator.initialize(KEY_SIZE, new SecureRandom());
			KeyPair pair = generator.generateKeyPair();
			PublicKey pubKey = pair.getPublic();
			PrivateKey privKey = pair.getPrivate();
			byte[] pk = pubKey.getEncoded();
			byte[] privk = privKey.getEncoded();
			String strpk = new String(Base64.encodeBase64(pk));
			String strprivk = new String(Base64.encodeBase64(privk));
			System.out.println("公钥Base64编码:" + strpk);
			System.out.println("私钥Base64编码:" + strprivk);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static byte[] cipherDoFinal(Cipher cipher, byte[] srcBytes, int segmentSize) {
		try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			int len = srcBytes.length;
			int offSet = 0;
			byte[] x;
			int i = 0;
			while (len - offSet > 0) {
				if (len - offSet > segmentSize) {
					x = cipher.doFinal(srcBytes, offSet, segmentSize);
				} else {
					x = cipher.doFinal(srcBytes, offSet, len - offSet);
				}
				out.write(x, 0, x.length);
				i++;
				offSet = i * segmentSize;
			}
			return out.toByteArray();
		} catch (Exception ex) {
			logger.error("加密失败", ex);
		}
		return null;
	}

}