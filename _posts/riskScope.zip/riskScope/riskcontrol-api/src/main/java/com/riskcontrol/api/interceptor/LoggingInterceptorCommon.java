package com.riskcontrol.api.interceptor;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by Wason.H on 2018/4/14.
 */
public class LoggingInterceptorCommon {



    private final static Logger logger = LoggerFactory.getLogger(LoggingInterceptorCommon.class);
    public final static String[] confidentialKeys ={"bank","bankNO","bank_no","pass","phone","email","realname","realName","real_name","account_no","pwd","send_to","sendTo","newPwd","bond_context","matchContent","ip","alias","phoneTwo","openId","withdrawalPassword",
            "match_content","bond_old_context","bondOldContext","bondContext","bond_context","old_pwd","oldPwd","online_messenger","online_messenger2","address","onlineMessenger","onlineMessenger2","PHONE","branch_name","oldRealName","oldBankAccountName","oldBankName","oldBankAccountNo","oldBranchName",
            "branchName","bankName","bank_name","deposit_by","depositBy", "checkValue", "bankAccountNo","bankAccountName","accountName","accountNo", "merchantNo", "bankCardNo", "toEmails", "toEmail","matchValue","match_value","DEFAULT_PASSWORD","key","value","bank_account_name","bank_account_no","account_no","account_name"};

    public final static String encoding = "UTF-8";

    /**
     *  遮盖敏感信息
     * @param args
     * @return
     */
    public static String hideParam(Object args) {
        String argsStr = null;
        try {
            //参数敏感信息用*号替换
            argsStr = JSONObject.toJSONString(args);
            for (String confidentialKey : LoggingInterceptorCommon.confidentialKeys) {
                if (StringUtils.isNotBlank(argsStr)) {
                    argsStr = argsStr.replaceAll(" ", "").replaceAll("\"" + confidentialKey + "\":\".*?\"", "\"" + confidentialKey + "\":\"********\"");
                }
            }
            logger.info("ArgsStr: {}", argsStr);
        } catch (Exception e) {
            logger.error("遮盖敏感信息失败!", e);
        }
        return argsStr;
    }
}
