package com.riskcontrol.api.service.impl;


import com.alibaba.nacos.common.utils.CollectionUtils;
import com.riskcontrol.common.enums.CardTypeEnum;
import com.riskcontrol.api.entity.CustomerCard;
import com.riskcontrol.api.service.AnalyzeCardService;
import com.riskcontrol.api.utils.DateUtil;
import com.riskcontrol.api.utils.OCRDataProcessUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @Auther: yannis
 * @Date: 2023/3/31 17:40
 * @Description: Passport
 */
@Service("passportService")
public class AnalyzePassportServiceImpl implements AnalyzeCardService {
    private static final Logger logger = LoggerFactory.getLogger(AnalyzePassportServiceImpl.class);

    static final List<String> titleList = Arrays.asList("PASSPORT", "Pasaporte big/Passport no", "Apelyido/Surname",
            "Pangalan/Given names", "Panggitnang apelyido/Middle name", "Panggitnang apelyido/Middle nome");
    public static final String SURNAME = "Surname";// Apelyido
    public static final String GIVEN_NAMES = "Given";
    public static final String MIDDLE_NAME = "Middle";// Panggitnang apelyido
    public static final String SEX = "Sex";
    public static final String BIRTH_DATE = "birth";

    private final String PASSPORT_NO = "Passport no";

    @Override
    public CustomerCard getRecognitionData(List<String> textList, CardTypeEnum cardTypeEnum) {
        logger.info("Passport start parsing.....");
        if (CollectionUtils.isEmpty(textList)) {
            return null;
        }
        CustomerCard card = new CustomerCard();
        card.setIdType(cardTypeEnum.getCode());
        int sexTitleIndex = -1;
        int birthTitleIndex = -1;
        int noTitleIndex = -1;
        int lastNameTitleIndex = -1;
        int firstNameTitleIndex = -1;
        int middleNameTitleIndex = -1;

        List<String> valueList = new ArrayList<>();
        for (int i = 0; i < textList.size(); i++) {
            String text = textList.get(i);
            //姓名
            OCRDataProcessUtils.ConvertEntity lastNameEntity = OCRDataProcessUtils.convertByCategory(text, SURNAME, lastNameTitleIndex, i, null, titleList, valueList, true);
            if (lastNameEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(lastNameEntity.getText())) {
                    card.setLastName(lastNameEntity.getText().toUpperCase());
                }
                lastNameTitleIndex = lastNameEntity.getTitalIndex();
            }

            OCRDataProcessUtils.ConvertEntity firstNameEntity = OCRDataProcessUtils.convertByCategory(text, GIVEN_NAMES, firstNameTitleIndex, i, null, titleList, valueList, true);
            if (firstNameEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(firstNameEntity.getText())) {
                    card.setFirstName(firstNameEntity.getText().toUpperCase());
                }
                firstNameTitleIndex = firstNameEntity.getTitalIndex();
            }
            //中间名
            OCRDataProcessUtils.ConvertEntity middleNameEntity = OCRDataProcessUtils.convertByCategory(text, MIDDLE_NAME, middleNameTitleIndex, i, null, titleList, valueList, true);
            if (middleNameEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(middleNameEntity.getText())) {
                    card.setMiddleName(middleNameEntity.getText().toUpperCase());
                }
                middleNameTitleIndex = middleNameEntity.getTitalIndex();
            }
            //性别
            OCRDataProcessUtils.ConvertEntity sexEntity = OCRDataProcessUtils.convertByCategory(text, SEX, sexTitleIndex, i, OCRDataProcessUtils.REGEX_SEX, titleList, valueList);
            if (sexEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(sexEntity.getText())) {
                    String sex = OCRDataProcessUtils.convertBySex(sexEntity.getText());
                    card.setGender(sex);
                }
                sexTitleIndex = sexEntity.getTitalIndex();
            }
            //生日
            OCRDataProcessUtils.ConvertEntity birthEntity = OCRDataProcessUtils.categoryConvertByDate(text, BIRTH_DATE, birthTitleIndex, i, valueList);
            if (birthEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(birthEntity.getText())) {
                    Date brithDate = DateUtil.getDateFromString(birthEntity.getText(), birthEntity.getDateFormat(), Locale.ENGLISH);
                    card.setBirthday(brithDate);
                }
                birthTitleIndex = birthEntity.getTitalIndex();
            }
            //号码
            OCRDataProcessUtils.ConvertEntity noEntity = OCRDataProcessUtils.convertByCategory(text, PASSPORT_NO, noTitleIndex, i, "[A-Z]\\d{7}[A-Z]", titleList, valueList);
            if (noEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(noEntity.getText())) {
                    card.setIdNo(noEntity.getText());
                }
                noTitleIndex = noEntity.getTitalIndex();
            }
        }

        return card;
    }


}
