package com.riskcontrol.api.entity.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.Size;
import java.util.Date;

@Data
@ApiModel("请求参数")
public class ImproveCustomerProfileReq extends BaseReq {
    @ApiModelProperty("性别")
    private String gender;
    @ApiModelProperty("门店端")
    private String branchCode;

    @ApiModelProperty(required = true, value = "出生日期, Format:yyyy-MM-dd  HH:mm:ss", example = "1990-01-01  HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date birthday;

    @ApiModelProperty("地址")
    private String address;

    @ApiModelProperty("会员邮箱账户名[公钥加密]")
    private String email;

    @ApiModelProperty(value ="名")
    private String firstName;

    @ApiModelProperty(value ="中間名")
    private String middleName;

    @ApiModelProperty(value ="姓")
    private String lastName;

    @ApiModelProperty("职业")
    private String occupation;

    @ApiModelProperty("收入来源")
    private String sourceOfIncome;
    @ApiModelProperty(value = "Province")
    private String province;
    @ApiModelProperty(value = "City")
    private String city;
    @ApiModelProperty(value = "Postal Code")
    private String postalCode;
    @ApiModelProperty("证件照1类型")
    private String firstIdType;
    @ApiModelProperty("证件照1号码")
    private  String firstIdNo;
    @ApiModelProperty("证件照1id")
    private  String firstIdScan;
    @ApiModelProperty("证件照2类型")
    private  String secondIdType;
    @ApiModelProperty("证件照2号码")
    private  String secondIdNo;
    @ApiModelProperty("证件照2id")
    private  String secondIdScan;

    @ApiModelProperty("人脸照数据")
    private  String faceId;
    @Size(max = 255, message = "The length must be 255 digits")
    @ApiModelProperty(value = "Messenger")
    private String messenger;

    @Size(max = 255, message = "The length must be 255 digits")
    @ApiModelProperty(value = "Viber")
    private String viber;

    @ApiModelProperty(required = true, value = "Account, to lower case")
    private String customerName;

    @ApiModelProperty(value = "nick name")
    private String nickName;

    @ApiModelProperty(value = "bio")
    private String bio;

    @ApiModelProperty("识别表id")
    private  String identifyId;

    @ApiModelProperty("产品")
    private String tenant;

    @ApiModelProperty("站点id")
    private Integer siteId;

    @ApiModelProperty(value = "employerName")
    private String employerName;

    @ApiModelProperty(value = "出生地")
    private String birthPlace;

    @ApiModelProperty(value = "现居地址")
    private String presentAddress;

    @ApiModelProperty(value = "国籍")
    private String nationality;

    @ApiModelProperty(value = "工作性质")
    private String natureOfWork;

    @ApiModelProperty(value = "自拍照")
    private String imgUrl;

}
