package com.riskcontrol.api.entity.request;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

public class KycDispatchConfirmReq extends BalanceReq {
    @ApiModelProperty(required = true, value = "KYC ID列表， KYC ID list", example = "")
    private List<String> ids;

    public List<String> getIds() {
        return ids;
    }

    public void setIds(List<String> ids) {
        this.ids = ids;
    }
}
