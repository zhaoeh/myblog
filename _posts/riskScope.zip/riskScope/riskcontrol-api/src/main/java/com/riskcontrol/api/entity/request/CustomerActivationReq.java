package com.riskcontrol.api.entity.request;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Size;

@ApiModel
@Data
public class CustomerActivationReq extends BaseReq {

    @ApiModelProperty(required = true, value = "門店代碼", example = "000102", position = 11)
    private String branchCode;

    @ApiModelProperty(value = "职业")
    private String occupation;

    @ApiModelProperty(value = "收入来源")
    private String sourceOfIncome;

    @ApiModelProperty(value = "国籍")
    private String nationality;

    @ApiModelProperty(value = "玩家账号")
    private String customerName;

    @ApiModelProperty(value = "省")
    protected String province;

    @ApiModelProperty(value = "城市")
    protected String city;

    @ApiModelProperty(value = "邮政编码")
    protected String postalCode;

    @ApiModelProperty(value = "通讯账号")
    @Size(max = 255, message = "The length must be 255 digits")
    protected String messager;

    @ApiModelProperty(value = "通讯账号")
    @Size(max = 255, message = "The length must be 255 digits")
    protected String viber;

    // 選填
    @ApiModelProperty(value = "要修改的 address", example = "Ayala Center, Makati, 1226 Metro Manila")
    private String address;

    @ApiModelProperty(value = "要修改的生日.格式:yyyy-MM-dd HH:mm:ss", example = "2016-11-13 00:00:00", position = 1)
    private String birthDate;

    @ApiModelProperty(value = "要修改的客户性别,M-男,F-女,默认为M",example="M", position = 3)
    private String sex;

    @ApiModelProperty(value = "要修改的 phone",example="", position = 3)
    private String phone;

    @ApiModelProperty(value = "要修改的 email",example="kgdtajewcm@gmail.com", position = 3)
    private String email;

    @ApiModelProperty(value = "要修改的 firstName", example = "John" )
    private String firstName;

    @ApiModelProperty(value = "要修改的 middleName", example = "Gomez")
    private String middleName;

    @ApiModelProperty(value = "要修改的 lastName", example = "Gonzales")
    private String lastName;

    // 選填- 證件
    @ApiModelProperty(value = "要修改的 证件1类型",example="1")
    private String firstIdType;

    @ApiModelProperty(value = "要修改的 证件1编号",example="9874685213498AE9875")
    private String firstNoType;

    @ApiModelProperty(value = "要修改的 证件1照片ID",example="2749a1257c354e7bae424f3e3eea7f89")
    private String firstIdScan;

    @ApiModelProperty(value = "要修改的 证件2类型",example="2")
    private String secondIdType;

    @ApiModelProperty(value = "要修改的 证件2编号",example="9874685213498AE9875")
    private String secondNoType;

    @ApiModelProperty(value = "要修改的 证件2照片ID",example="2749a1257c354e7bae424f3e3eea7f89")
    private String secondIdScan;

    @ApiModelProperty(value = "要修改的 domainName",example="OFFICE")
    private String domainName;

    @ApiModelProperty(value = "要修改的 currency",example="PHP")
    private String currency;

    @ApiModelProperty(value = "要修改的 phonePrefix",example="0063")
    private String phonePrefix;

    @ApiModelProperty(value = "要修改的 ipAddress",example="127.0.0.1")
    private String ipAddress;

    @ApiModelProperty(value = "激活状态：1是 0否",example="1")
    private String activation;

    @ApiModelProperty(value = "截图")
    private String screenshot;

    @ApiModelProperty(value = "截图备注")
    private String screenshotRemarks;

    @ApiModelProperty(value = "faceId 图片key",example = "6b8f64df-29e5-4710-bcb4-aa349a1ef6e1")
    private String faceId;
}
