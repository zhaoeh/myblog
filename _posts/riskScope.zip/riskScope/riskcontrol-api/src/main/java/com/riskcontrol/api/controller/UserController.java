package com.riskcontrol.api.controller;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.urf.UserWorkingStatusChangeLog;
import com.riskcontrol.api.entity.request.UserWorkingStatusChangeReq;
import com.riskcontrol.api.service.UserWorkingStatusChangeLogService;
import com.riskcontrol.common.entity.response.Response;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * @program: riskcontrol-api
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-11-29 10:37
 */
@Slf4j
@RestController
@RequestMapping(value = "user", method = RequestMethod.POST)
public class UserController {

    @Resource
    private UserWorkingStatusChangeLogService userWorkingStatusChangeLogService;

    @ApiOperation(value = "查询工作状态", notes = "查询工作状态", httpMethod = "POST")
    @PostMapping(value = "getWorkingStatus")
    @ResponseBody
    public Response getWorkingStatus(@RequestBody UserWorkingStatusChangeReq userWorkingStatusChangeReq) {
        Response<JSONObject> rsp = new Response<>();
        UserWorkingStatusChangeLog userWorkingStatusChangeLogCatch = userWorkingStatusChangeLogService.getLastWorkingStatus(userWorkingStatusChangeReq);
        rsp.setBody(new JSONObject().fluentPut("data", userWorkingStatusChangeLogCatch));
        return rsp;
    }

    @ApiOperation(value = "修改工作状态", notes = "修改工作状态", httpMethod = "POST")
    @PostMapping(value = "modifyWorkingStatus")
    @ResponseBody
    public Response modifyWorkingStatus(HttpServletRequest request, @RequestBody UserWorkingStatusChangeReq userWorkingStatusChangeReq) {
        Response<JSONObject> response = new Response<>();
        response.setBody(userWorkingStatusChangeLogService.modifyWorkingStatus(userWorkingStatusChangeReq));
        return response;
    }
}