package com.riskcontrol.api.constants;


/**
 * @Description: 风控字典常量
 * @Auther: yannis
 * @create: 2024-01-12
 */
public class RiskDisConstants {
    /**
     * 字典类型
     */
    // 会员标签
    public static final String TYPE_LABLE = "0101";

}
