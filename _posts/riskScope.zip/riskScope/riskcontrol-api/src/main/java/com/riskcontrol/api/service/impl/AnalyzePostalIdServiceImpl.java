package com.riskcontrol.api.service.impl;


import com.alibaba.nacos.common.utils.CollectionUtils;
import com.riskcontrol.common.enums.CardTypeEnum;
import com.riskcontrol.api.entity.CustomerCard;
import com.riskcontrol.api.service.AnalyzeCardService;
import com.riskcontrol.api.utils.DateUtil;
import com.riskcontrol.api.utils.OCRDataProcessUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @Auther: yannis
 * @Date: 2023/3/31 17:40
 * @Description: Postal ID
 */
@Service("postalIdService")
public class AnalyzePostalIdServiceImpl implements AnalyzeCardService {
    private static final Logger logger = LoggerFactory.getLogger(AnalyzePostalIdServiceImpl.class);

    static final List<String> titleList = Arrays.asList("REPUBLIC OF THE PHURRNES", "ALIEN CERTIFICATE OF REGISTRATION", "POSTAL IDENTITY CARD", "REPUBLIC OF THE PHILIPPINES",
            "Philippine Postal Corporation");


    private final String PASSPORT_NO = "PRN";

    @Override
    public CustomerCard getRecognitionData(List<String> textList, CardTypeEnum cardTypeEnum) {
        logger.info("Postal ID start parsing.....");
        if (CollectionUtils.isEmpty(textList)) {
            return null;
        }
        CustomerCard card = new CustomerCard();
        card.setIdType(cardTypeEnum.getCode());
        int noTitleIndex = -1;
        int nameTitleIndex = 1;


        List<String> valueList = new ArrayList<>();
        for (int i = 0; i < textList.size(); i++) {
            String text = textList.get(i);
            //姓名
            OCRDataProcessUtils.ConvertEntity nameEntity = OCRDataProcessUtils.convertByNoCategory(text, nameTitleIndex, "\\w+\\s+\\w+(?:\\s+\\w+)?(?:\\s+\\w+)?", titleList, valueList);
            if (null != nameEntity && nameEntity.isMatchText()) {
                nameTitleIndex = nameEntity.getTitalIndex();
                String names = nameEntity.getText().toUpperCase();

                OCRDataProcessUtils.ConvertEntity namesConvert = OCRDataProcessUtils.getNamesConvert(names);
                card.setFirstName(namesConvert.getFirstName());
                card.setMiddleName(namesConvert.getMiddleName());
                card.setLastName(namesConvert.getLastName());
            }

            //生日
            OCRDataProcessUtils.ConvertEntity birthEntity = OCRDataProcessUtils.convertByRegex(text, OCRDataProcessUtils.ENDLISH_DATE_REGEX, titleList, valueList);
            if (null != birthEntity && birthEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(birthEntity.getText())) {
                    Date brithDate = DateUtil.getDateFromString(birthEntity.getText(), DateUtil.FORMAT_DD_MMM_YYYY, Locale.ENGLISH);
                    card.setBirthday(brithDate);
                }
            }
            //号码
            OCRDataProcessUtils.ConvertEntity noEntity = OCRDataProcessUtils.convertByCategory(text, PASSPORT_NO, noTitleIndex, i, "\\d{12}", titleList, valueList);
            if (noEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(noEntity.getText())) {
                    card.setIdNo(noEntity.getText());
                }
                noTitleIndex = noEntity.getTitalIndex();
            }

        }

        return card;
    }


}
