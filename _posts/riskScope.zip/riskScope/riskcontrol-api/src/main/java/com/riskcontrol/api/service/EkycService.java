package com.riskcontrol.api.service;

import com.riskcontrol.api.entity.request.EkcyQueryReq;
import com.riskcontrol.api.entity.request.InitRealIDReq;
import com.riskcontrol.api.entity.response.EkycStatusRsp;
import com.riskcontrol.api.entity.response.InitEKycRsp;
import com.riskcontrol.common.entity.request.ekyc.EkycExtendRequest;
import com.riskcontrol.common.entity.response.Response;

public interface EkycService {

    Response<EkycStatusRsp> queryStatus(EkcyQueryReq req);

    Response<InitEKycRsp> h5RealIdInit(InitRealIDReq req);

    Response<Boolean> modifyEkycRequest(EkycExtendRequest req);
}
