package com.riskcontrol.api.utils;

import com.riskcontrol.api.constants.Constants;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.WeekFields;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import static com.riskcontrol.api.constants.Constants.DATE_TIME_FORMATTER;


public class DateUtil {


    private static final String YYMMDD_hhmmss= "yyyy-MM-dd HH:mm:ss";
    public static final String YYMMDD= "yyyy-MM-dd";
    private static final String YYYYMMDD= "yyyy/MM/dd";
    public static final String FORMAT_YYMMDD_HHMMSS = "yyyy-MM-dd HH:mm:ss";
    public static final String FORMAT_yyyy_MM_dd_T_HHmmss_08_00 = "yyyy-MM-dd'T'HH:mm:ss'+08:00'";

    public static final String FORMAT_MMM_DD_YYYY = "MMM dd,yyyy";
    public static final String FORMAT_DD_MMM_YYYY = "dd MMM yyyy";
    private static final Logger logger= LoggerFactory.getLogger(DateUtil.class);
    /**
     * 获取当前时间字符串
     * @param isFromFirstDay 是否初始化时间为当月第一日
     * @return DateString
     */
    public static String getYYYYMMDD(boolean isFromFirstDay) {
        Calendar date = Calendar.getInstance();
        int year = date.get(Calendar.YEAR);
        int month = date.get(Calendar.MONTH) + 1;
        String monthStr;
        if(month < 10){
            monthStr = "0" + month;
        }else{
            monthStr = month + "";
        }

        int day = date.get(Calendar.DAY_OF_MONTH);
        String dayStr;
        if(isFromFirstDay) {
            date.set(Calendar.DAY_OF_MONTH,1);
            day = date.get(Calendar.DAY_OF_MONTH);
        }

        if (day < 10) {
            dayStr = "0" + day;
        }else {
            dayStr = day + "";
        }
        return year + "-" + monthStr + "-" + dayStr;
    }


    /**
     * 获取当前时间字符串
     * @return
     */
    public static String getCurrentDate() {
        SimpleDateFormat dfm = new SimpleDateFormat(YYMMDD_hhmmss);
        return dfm.format(new Date());
    }

    /**
     * 获取当前时间字符串
     * @return
     */
    public static String getDateString(Date now,String formatString) {
        SimpleDateFormat dfm = new SimpleDateFormat(formatString);
        return dfm.format(new Date());
    }

    public static Date getConversionTime(String dateTimeStr){
        Date date ;
        try{
            SimpleDateFormat dfm = new SimpleDateFormat(YYMMDD_hhmmss);
            date = dfm.parse(dateTimeStr);
        }catch (Exception e){
            logger.error("{}时间格式解析异常 {}",dateTimeStr,e.getMessage());
            return null;
        }
        return date;
    }

    /**
     * 获取当前时间字符串
     * @param dateFormat
     * @return
     */
    public static String getCurrentDateString(String dateFormat) {
        SimpleDateFormat dfm = new SimpleDateFormat(dateFormat);
        return dfm.format(new Date());
    }

    public static String getCurrentDateString(Date time,String dateFormat) {
        SimpleDateFormat dfm = new SimpleDateFormat(dateFormat);
        return dfm.format(time);
    }
    public static Date getDateFromYYMMDD_hhmmssString(String dateTimeStr){
        SimpleDateFormat dfm = new SimpleDateFormat(YYMMDD_hhmmss);
        Date date ;
        try{
            date = dfm.parse(dateTimeStr);
        }catch (Exception e){
            logger.error("{}时间格式解析异常 {}",dateTimeStr,e.getMessage());
            return null;
        }
        return date;
    }
    public static Date getDateFromYYMMDDString(String dateTimeStr){
        SimpleDateFormat dfm = new SimpleDateFormat(YYMMDD);
        Date date ;
        try{
            date = dfm.parse(dateTimeStr);
        }catch (Exception e){
            logger.error("{}时间格式解析异常 {}",dateTimeStr,e.getMessage());
            return null;
        }
        return date;
    }
    public static Date getDateFromYYYYMMddString(String dateTimeStr){
        SimpleDateFormat dfm = new SimpleDateFormat(YYYYMMDD);
        Date date ;
        try{
            date = dfm.parse(dateTimeStr);
        }catch (Exception e){
            logger.error("{}时间格式解析异常 {}",dateTimeStr,e.getMessage());
            return null;
        }
        return date;
    }

    /**
     * 字符串按照格式转日期
     * @param dateTimeStr
     * @param dateFormat
     * @return
     */
    public static Date getDateFromString(String dateTimeStr,String dateFormat){
        SimpleDateFormat dfm = new SimpleDateFormat(dateFormat);
        Date date ;
        try{
            date = dfm.parse(dateTimeStr);
        }catch (Exception e){
            logger.error("{}时间格式解析异常 {}",dateTimeStr,e.getMessage());
            return null;
        }
        return date;
    }
    /**
     * 字符串按照格式转日期
     * @param dateTimeStr
     * @param dateFormat
     * @return
     */
    public static Date getDateFromString(String dateTimeStr, String dateFormat, Locale locale){
        SimpleDateFormat dfm = new SimpleDateFormat(dateFormat,locale);
        Date date ;
        try{
            date = dfm.parse(dateTimeStr);
        }catch (Exception e){
            logger.error("{}时间格式解析异常 {}",dateTimeStr,e.getMessage());
            return null;
        }
        return date;
    }

    /**
     * 字符串转换成日期
     * @param str
     * @return date
     */
    public static Date StrToDate(String str) {

     SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
     Date date = null;
        try {
            date = format.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

    /**
     * 获取指定的时间字符串
     *  注意：isFromFirstDay和isLastDay只能一个为true,若两个都为true,则返回月份的最后一天
     * @param isFromFirstDay 是否初始化时间为当月第一天
     * @param isLastDay 是否初始化时间为月的最后一天
     * @param monthSummand 月的加数（正为加，负为减）
     * @return
     */
    public static String getYYYY_MM_DD(boolean isFromFirstDay, boolean isLastDay, int monthSummand){
        Calendar date = Calendar.getInstance();
        if((monthSummand > 0 || monthSummand < 0)){
            date.add(Calendar.MONTH,monthSummand);
        }

        if(isFromFirstDay){
            date.set(Calendar.DAY_OF_MONTH,1);
        }

        if(isLastDay){
            date.set(Calendar.DAY_OF_MONTH,date.getActualMaximum(Calendar.DAY_OF_MONTH));
        }

        int year = date.get(Calendar.YEAR);

        int month = date.get(Calendar.MONTH) + 1;
        String monthStr;
        if(month < 10){
            monthStr = "0" + month;
        }else{
            monthStr = month + "";
        }

        int day = date.get(Calendar.DAY_OF_MONTH);
        String dayStr;

        if (day < 10) {
            dayStr = "0" + day;
        }else {
            dayStr = day + "";
        }

        return year + "-" + monthStr + "-" + dayStr;
    }

   //获取本周开始时间
    public static Date getBeginDayofThisWeek(){
        Date date = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int dayofweek = cal.get(Calendar.DAY_OF_WEEK);
        if (dayofweek == 1) {
            dayofweek += 7;
        }
        cal.add(Calendar.DATE, 2 - dayofweek);
        return getDayStartTime(cal.getTime());
    }

    // 获取本周的结束时间
    public static Date getEndDayOfThisWeek() {
        Calendar cal = Calendar.getInstance();
        cal.setTime(getBeginDayOfWeek());
        cal.add(Calendar.DAY_OF_WEEK, 6);
        Date weekEndSta = cal.getTime();
        return getDayEndTime(weekEndSta);
    }



    // 获取上周的开始时间
    private static Date getBeginDayOfLastWeek() {
        Date date = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int dayofweek = cal.get(Calendar.DAY_OF_WEEK);
        if (dayofweek == 1) {
            dayofweek += 7;
        }
        cal.add(Calendar.DATE, 2 - dayofweek - 7);
        return getDayStartTime(cal.getTime());
    }

    // 获取上周的结束时间
    public static Date getEndDayOfLastWeek() {
        Calendar cal = Calendar.getInstance();
        cal.setTime(getBeginDayOfLastWeek());
        cal.add(Calendar.DAY_OF_WEEK, 6);
        Date weekEndSta = cal.getTime();
        return getDayEndTime(weekEndSta);
    }
    // 获取某个日期的开始时间
    private static Timestamp getDayStartTime(Date d) {
        Calendar calendar = Calendar.getInstance();
        if (null != d)
            calendar.setTime(d);
        calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH), 0, 0, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return new Timestamp(calendar.getTimeInMillis());
    }

    // 获取某个日期的结束时间
    private static Timestamp getDayEndTime(Date d) {
        Calendar calendar = Calendar.getInstance();
        if (null != d)
            calendar.setTime(d);
        calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH), 23, 59, 59);
        calendar.set(Calendar.MILLISECOND, 999);
        return new Timestamp(calendar.getTimeInMillis());
    }

    //获取当前日期的年份
    public static Integer getDateYear() {
        Calendar date = Calendar.getInstance();
        return date.get(Calendar.YEAR);
    }

    //获取当前日期的自然周
    public static Integer getDateWeek() {
        LocalDate localDate = LocalDate.now();
        WeekFields weekFields = WeekFields.of(DayOfWeek.MONDAY, 4);
        return localDate.get(weekFields.weekOfWeekBasedYear());
    }

    //获取每自然周的开始时间
    public static String getStartDayOfWeekNo(int year, int weekNo) {
        Calendar cal = getCalendarFormYear(year);
        cal.set(Calendar.WEEK_OF_YEAR, weekNo);
        return cal.get(Calendar.YEAR) + "-" + ((cal.get(Calendar.MONTH) + 1) < 10 ? "0" + (cal.get(Calendar.MONTH) + 1) : (cal.get(Calendar.MONTH) + 1)) + "-" +
                (((cal.get(Calendar.DAY_OF_MONTH)) >= 10) ? (cal.get(Calendar.DAY_OF_MONTH)) + "" : "0" + (cal.get(Calendar.DAY_OF_MONTH))) + "" + " 00:00:00";
    }

    //获取每自然周的结束时间
    public static String getEndDayOfWeekNo(int year, int weekNo) {
        Calendar cal = getCalendarFormYear(year);
        cal.set(Calendar.WEEK_OF_YEAR, weekNo);
        cal.add(Calendar.DAY_OF_WEEK, 6);
        return cal.get(Calendar.YEAR) + "-" + (((cal.get(Calendar.MONTH) + 1) < 10) ? "0" + (cal.get(Calendar.MONTH) + 1) : (cal.get(Calendar.MONTH) + 1)) + "-" +
                (((cal.get(Calendar.DAY_OF_MONTH)) >= 10) ? (cal.get(Calendar.DAY_OF_MONTH)) + "" : "0" + (cal.get(Calendar.DAY_OF_MONTH))) + "" + " 23:59:59";
    }

    //获取当前年的周期设置
    private static Calendar getCalendarFormYear(int year) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        cal.set(Calendar.YEAR, year);
        return cal;
    }

    //获取本周的开始时间
    public static Date getBeginDayOfWeek() {
        Date date = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int dayofweek = cal.get(Calendar.DAY_OF_WEEK);
        if (dayofweek == 1) {
            dayofweek += 7;
        }
        cal.add(Calendar.DATE, 2 - dayofweek);
        return getDayStartTime(cal.getTime());
    }

    //获取本周的结束时间
    public static Date getEndDayOfWeek(){
        Calendar cal = Calendar.getInstance();
        cal.setTime(getBeginDayOfWeek());
        cal.add(Calendar.DAY_OF_WEEK, 6);
        Date weekEndSta = cal.getTime();
        return getDayEndTime(weekEndSta);
    }

    //获取当前时间的前几天
    public static String getCurrentDateStr(int days, Date date, String dateFormat){
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DAY_OF_MONTH, days);
        date = cal.getTime();
        SimpleDateFormat dfm = new SimpleDateFormat(dateFormat);
        return dfm.format(date);
    }
    //获取当前时间的前几个小时
    public static String getBeforeOneHourStr(int hours, Date date, String dateFormat){
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, cal.get(Calendar.HOUR_OF_DAY) - hours);
        date = cal.getTime();
        SimpleDateFormat dfm = new SimpleDateFormat(dateFormat);
        return dfm.format(date);
    }
    //获取当前时间的前几分钟
    public static String getBeforeOneMinuteStr(int minute, Date date, String dateFormat){
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.MINUTE, minute);
        date = cal.getTime();
        SimpleDateFormat dfm = new SimpleDateFormat(StringUtils.isBlank(dateFormat)?YYMMDD_hhmmss:dateFormat);
        return dfm.format(date);
    }
    public static Date parseDateString(String date,String format) {
        try {
            if(StringUtils.isEmpty(format)){
                return new SimpleDateFormat(YYMMDD_hhmmss).parse(date);
            }else{
                return new SimpleDateFormat(format).parse(date);
            }

        } catch (Exception e) {
            return null;
        }
    }
    /**
     *
     * @param format
     * @param datetime
     * @param sourceZoneId
     * @param targetZoneId
     * @return
     */
    public static String parseDateTime(String format, String datetime, String sourceZoneId, String targetZoneId) {
        DateTimeFormatter dateTimeFormatter = getDateTimeFormatter(format);
        if (null == dateTimeFormatter) {
            throw new NullPointerException("format: " + format + " , 沒有對應的DateTimeFormatter");
        }
        // 1. 將字串轉換成LocalDateTime, 若錯誤則忽略, 最少要有小時
        LocalDateTime localDateTime = LocalDateTime.parse(datetime, dateTimeFormatter);
        // 2. 設置來源時區
        ZonedDateTime zonedDateTime = localDateTime.atZone(ZoneId.of(sourceZoneId));
        // 3. 轉換指定時區
        zonedDateTime = zonedDateTime.withZoneSameInstant(ZoneId.of(targetZoneId));
        return dateTimeFormatter.format(zonedDateTime);
    }

    public static ZonedDateTime parseDateTime(LocalDateTime localDateTime, String sourceZoneId, String targetZoneId) {
        // 1. 設置來源時區
        ZonedDateTime zonedDateTime = localDateTime.atZone(ZoneId.of(sourceZoneId));
        // 2. 轉換指定時區
        zonedDateTime = zonedDateTime.withZoneSameInstant(ZoneId.of(targetZoneId));
        return zonedDateTime;
    }

    /**
     * 時間轉換(數字)
     * @param format
     * @param datetimeNumeric
     * @param sourceZoneId
     * @param targetZoneId
     * @return
     */
    private static String parseDateTimeByNumeric(String format, String datetimeNumeric, String sourceZoneId, String targetZoneId) {
        DateTimeFormatter dateTimeFormatter = getDateTimeFormatter(format);
        if (null == dateTimeFormatter) {
            throw new NullPointerException("format: " + format + " , 沒有對應的DateTimeFormatter");
        }
        boolean isInt = false;
        long time = Long.parseLong(datetimeNumeric);
        if (Integer.MAX_VALUE >= time) {
            // 秒數
            time = time * 1000l;
            isInt = true;
        }
        String datetime = new SimpleDateFormat(format).format(time);
        // 1. 將字串轉換成LocalDateTime, 若錯誤則忽略, 最少要有小時
        LocalDateTime localDateTime = LocalDateTime.parse(datetime, dateTimeFormatter);
        // 2. 設置來源時區
        ZonedDateTime zonedDateTime = localDateTime.atZone(ZoneId.of(sourceZoneId));
        // 3. 轉換指定時區
        zonedDateTime = zonedDateTime.withZoneSameInstant(ZoneId.of(targetZoneId));
        time = Date.from(zonedDateTime.toInstant()).getTime();
        if (isInt) {
            time = time / 1000l;
        }
        return String.valueOf(time);
    }

    /**
     *
     * @param format
     * @param datetime
     * @param clientZoneId
     * @param serverZoneId
     * @return
     */
    public static String parseToServerDateTime(String format, String datetime, String clientZoneId, String serverZoneId) {
        return parseDateTime(format, datetime, clientZoneId, serverZoneId);
    }

    /**
     * 轉換
     * @param format
     * @param datetime
     * @param clientZoneId
     * @param serverZoneId
     * @return
     */
    public static String parseToClientDateTime(String format, String datetime, String clientZoneId, String serverZoneId) {
        if (StringUtils.isNumeric(datetime)) {
            return parseDateTimeByNumeric(format, datetime, serverZoneId, clientZoneId);
        }
        return parseDateTime(format, datetime, serverZoneId, clientZoneId);
    }

    public static DateTimeFormatter getDateTimeFormatter(String format) {
        switch (format) {
            case "yyyy-MM-dd":
                return Constants.DATE_FORMATTER;
            case "yyyy-MM-dd HH:mm:ss":
                return DATE_TIME_FORMATTER;
            case "M/d/yyyy h:mm:ss a":
                return Constants.DATE_TIME_FORMATTER2;
            default:
                return null;
        }
    }
    public static boolean isDateTimeFormatParam(String paramKey){

        return true;
    }

    public static String formatTodayEndTime(String dateStr){
        SimpleDateFormat sdf = new SimpleDateFormat(YYMMDD_hhmmss);
        try {
            Date date = sdf.parse(dateStr);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.set(Calendar.DAY_OF_MONTH,calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
            calendar.set(Calendar.HOUR,23);
            calendar.set(Calendar.MINUTE,59);
            calendar.set(Calendar.SECOND,59);
            return sdf.format(calendar.getTime());
        } catch (ParseException e) {
            logger.error("{}formatTodayBeginTime异常 {}",dateStr,e.getMessage());
            return null;
        }
    }

    /**
     * 计算某个时间与当前系统时间差/单位秒
     * @param dateStr
     * @return
     */
    public static Long dateBetweenSeconds(String dateStr) {
        Date date = getDateFromYYMMDD_hhmmssString(dateStr);
        Instant instant = date.toInstant();
        ZoneId zoneId = ZoneId.systemDefault();
        LocalDateTime transferDate = instant.atZone(zoneId).toLocalDateTime();
        Duration duration = Duration.between(transferDate, LocalDateTime.now());
        Long result = duration.getSeconds();
        if (result > 0) {
            result = 0L;
        }
        return result;
    }


    public static Long dateBetweenSeconds2(String dateStr) {
        Date date = getDateFromYYMMDD_hhmmssString(dateStr);
        Instant instant = date.toInstant();
        ZoneId zoneId = ZoneId.systemDefault();
        LocalDateTime transferDate = instant.atZone(zoneId).toLocalDateTime();
        Duration duration = Duration.between(transferDate, LocalDateTime.now());

        return duration.getSeconds();
    }

    public static int getWeek(String dates){
        Calendar cal=Calendar.getInstance();
        SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd");
        Date d=null;
        try{
            d=f.parse(dates);
        }catch (ParseException e){
            e.printStackTrace();
        }
        cal.setTime(d);
        int w=cal.get(Calendar.DAY_OF_WEEK)-1;
        if(w==0) w=7;
        return w;
    }

    public static long getDateTimestamp(int plusDays, LocalTime time) {
        String format = LocalDateTime.of(LocalDate.now().plusDays(plusDays), time).format(DATE_TIME_FORMATTER);
        return getDateFromYYMMDD_hhmmssString(format).getTime();
    }

    public static String getLocalDateTimeString(int plusDays, LocalTime time) {
        return LocalDateTime.of(LocalDate.now().plusDays(plusDays), time).format(DATE_TIME_FORMATTER);
    }

    public static void main(String[] args) {
        System.out.println(dateBetweenSeconds("2022-09-26 17:18:00"));
    }

    public static String getDateString2(Date time, String s) {
        SimpleDateFormat dfm = new SimpleDateFormat(s);
        return dfm.format(time);
    }

    /**
     * 格式化日期 String -> String 例如：yyyy-MM-dd HH:mm:ss -> yyyy-MM-dd
     * @return
     */
    public static String formatStringToString(String date, String format) {
        SimpleDateFormat dfm = new SimpleDateFormat(format);
        return dfm.format(getConversionTime(date));
    }
}

