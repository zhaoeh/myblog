package com.riskcontrol.api.service.impl;


import com.alibaba.nacos.common.utils.CollectionUtils;
import com.riskcontrol.common.enums.CardTypeEnum;
import com.riskcontrol.api.entity.CustomerCard;
import com.riskcontrol.api.service.AnalyzeCardService;
import com.riskcontrol.api.utils.DateUtil;
import com.riskcontrol.api.utils.OCRDataProcessUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @Auther: yannis
 * @Date: 2023/3/31 17:40
 * @Description: 武器执照 Firearms License
 */
@Service("firearmsLicenseService")
public class AnalyzeFirearmsLicenseServiceImpl implements AnalyzeCardService {
    private static final Logger logger = LoggerFactory.getLogger(AnalyzeFirearmsLicenseServiceImpl.class);

    static final List<String> titleList = Arrays.asList("FIREARMS LICENCE/ PERMIS D'ARMES A FEU", "POSSESSION- ACQUISITION", "Name / Nom",
            "Gender / Sexe", "Number / Numéro");
    public static final String NAMES = "Name";
    public static final String SEX = "Gender";
    public static final String BIRTH_DATE = "Date of Birth";
    private final String CARD_NO = "Number";

    @Override
    public CustomerCard getRecognitionData(List<String> textList, CardTypeEnum cardTypeEnum) {
        logger.info("Firearms License start parsing.....");
        if (CollectionUtils.isEmpty(textList)) {
            return null;
        }
        CustomerCard card = new CustomerCard();
        card.setIdType(cardTypeEnum.getCode());
        int sexTitleIndex = -1;
        int birthTitleIndex = -1;
        int noTitleIndex = -1;
        int nameTitleIndex = -1;


        List<String> valueList = new ArrayList<>();
        for (int i = 0; i < textList.size(); i++) {
            String text = textList.get(i);
            //姓名
            OCRDataProcessUtils.ConvertEntity nameEntity = OCRDataProcessUtils.convertByCategory(text, NAMES, nameTitleIndex, i, "\\w+\\s+\\w+(?:\\s+\\w+)?(?:\\s+\\w+)?", titleList, valueList);
            if (nameEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(nameEntity.getText())) {
                    String names = nameEntity.getText().toUpperCase();
                    OCRDataProcessUtils.ConvertEntity namesConvert = OCRDataProcessUtils.namesConvertLFM(names);
                    card.setFirstName(namesConvert.getFirstName());
                    card.setMiddleName(namesConvert.getMiddleName());
                    card.setLastName(namesConvert.getLastName());
                }
                nameTitleIndex = nameEntity.getTitalIndex();
            }
            //性别
            OCRDataProcessUtils.ConvertEntity sexEntity = OCRDataProcessUtils.convertByCategory(text, SEX, sexTitleIndex, i, OCRDataProcessUtils.REGEX_SEX, titleList, valueList);
            if (sexEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(sexEntity.getText())) {
                    String sex = OCRDataProcessUtils.convertBySex(sexEntity.getText());
                    card.setGender(sex);
                }
                sexTitleIndex = sexEntity.getTitalIndex();
            }
            //生日
            OCRDataProcessUtils.ConvertEntity birthEntity = OCRDataProcessUtils.categoryConvertByDate(text, BIRTH_DATE, birthTitleIndex, i, valueList);
            if (birthEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(birthEntity.getText())) {
                    Date brithDate = DateUtil.getDateFromString(birthEntity.getText(), birthEntity.getDateFormat(), Locale.ENGLISH);
                    card.setBirthday(brithDate);
                }
                birthTitleIndex = birthEntity.getTitalIndex();
            }
            //号码
            OCRDataProcessUtils.ConvertEntity noEntity = OCRDataProcessUtils.convertByCategory(text, CARD_NO, noTitleIndex, i, "\\d+(?:\\.\\d+)?", titleList, valueList);
            if (noEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(noEntity.getText())) {
                    card.setIdNo(noEntity.getText());
                }
                noTitleIndex = noEntity.getTitalIndex();
            }
        }

        return card;
    }


}
