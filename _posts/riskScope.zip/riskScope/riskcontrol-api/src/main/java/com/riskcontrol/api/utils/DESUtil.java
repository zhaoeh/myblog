package com.riskcontrol.api.utils;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import java.security.SecureRandom;

public class DESUtil {

	private static final String DES = "DES";

	private static final String PADDING = "DES/ECB/PKCS5Padding";

	private static final String DEFAULT_INCODING = "utf-8";

	private static final Logger logger = LoggerFactory.getLogger(DESUtil.class);



	public static String decrypt(String data, String key) {
		try {
			return new String(decrypt(Base64.decodeBase64(data), key.getBytes(DEFAULT_INCODING)), DEFAULT_INCODING);
		} catch (Exception ex) {
			logger.error("解密失败", ex);
		}
		return null;
	}

	private static byte[] decrypt(byte[] src, byte[] key) throws Exception {
		SecureRandom sr = new SecureRandom();
		DESKeySpec dks = new DESKeySpec(key);
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(DES);
		SecretKey sectetKey = keyFactory.generateSecret(dks);
		Cipher cipher = Cipher.getInstance(PADDING);
		cipher.init(Cipher.DECRYPT_MODE, sectetKey, sr);
		return cipher.doFinal(src);
	}


}