package com.riskcontrol.api.template;

import com.alibaba.fastjson.JSONObject;
import com.dingxianginc.ctu.client.CtuConstidClient;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiConsumer;
import java.util.function.Function;

/**
 * @description: 顶象服务模板
 * @author: ErHu.Zhao
 * @create: 2024-11-13
 **/
@Component
@RefreshScope
@Slf4j
public class DingXiangTemplate {

    public static final String DEVICE_CACHE_KEY = "deviceCache";
    public static final String DEVICE_INFO_KEY = "deviceInfo";
    public static final String BUSINESS_EXCEPTION_KEY = "exception";

    @Value("${risk.dingxiang.url}")
    private String url;

    @Value("${risk.dingxiang.appKey}")
    private String appKey;

    @Value("${risk.dingxiang.appSecret}")
    private String appSecret;

    private CtuConstidClient ctuConstidClient;

    @PostConstruct
    public void init() {
        ctuConstidClient = new CtuConstidClient(url, appKey, appSecret);
    }

    /**
     * 根据token获取设备信息*
     *
     * @param token
     * @return
     * @throws IOException
     */
    public String obtainDeviceInfo(String token) throws IOException {
        Assert.isTrue(StringUtils.isNotBlank(token), "device token cannot be blank");
        return ctuConstidClient.getDeviceInfo(token);
    }

    /**
     * 根据token获取设备信息，以JSONObject返回*
     *
     * @param token
     * @return
     * @throws IOException
     */
    public JSONObject obtainDeviceInfoWithObj(String token) throws IOException {
        Assert.isTrue(StringUtils.isNotBlank(token), "device token cannot be blank");
        return JSONObject.parseObject(obtainDeviceInfo(token));
    }

    /**
     * 根据token获取设备信息*
     *
     * @param token
     * @return
     * @throws IOException
     */
    public Map<String, String> obtainDeviceInfoIgnoreCache(String token) throws IOException {
        return obtainDeviceInfoWithCache(token, null, null, null);
    }

    /**
     * 根据token获取设备信息，带缓存操作*
     *
     * @param token
     * @param keyMapper
     * @param queryMapper
     * @param saveMapper
     * @return
     * @throws IOException
     */
    public Map<String, String> obtainDeviceInfoWithCache(String token,
                                                         Function<String, String> keyMapper,
                                                         Function<String, Object> queryMapper,
                                                         BiConsumer<String, String> saveMapper) throws IOException {
        Assert.isTrue(StringUtils.isNotBlank(token), "device token cannot be blank");
        Map<String, String> map = new HashMap<>(2);
        String deviceInfo;
        String deviceCache = null;
        if (Objects.nonNull(queryMapper)) {
            String key = Objects.isNull(keyMapper) ? token : keyMapper.apply(token);
            Object cacheValue = queryMapper.apply(key);
            log.info("查询缓存，key：{}，入参token为：{}，返回信息cacheValue为：{}", key, token, cacheValue);
            deviceCache = Objects.isNull(cacheValue) ? null : Objects.toString(cacheValue);
        }
        if (StringUtils.isNotBlank(deviceCache)) {
            map.put(DEVICE_CACHE_KEY, deviceCache);
            return map;
        }
        try {
            log.info("调用顶象服务开始，入参token为：{}", token);
            deviceInfo = obtainDeviceInfo(token);
            log.info("调用顶象服务结束，入参token为：{}，返回信息deviceInfo为：{}", token, deviceInfo);
        } catch (Exception e) {
            log.error("调用顶象服务异常，请检查", e);
            throw e;
        }

        if (StringUtils.isNotBlank(deviceInfo)) {
            JSONObject response = JSONObject.parseObject(deviceInfo);
            Integer stateCode = response.getInteger("stateCode");
            Integer success = 200;
            if (!Objects.equals(success, stateCode)) {
                // 顶象业务异常，组装参数直接返回
                map.put(BUSINESS_EXCEPTION_KEY, deviceInfo);
                return map;
            }
            JSONObject data = response.getJSONObject("data");
            Assert.isTrue(Objects.nonNull(data), "dingxiang service return data is null");
            deviceCache = data.getString("constId");
            if (StringUtils.isNotBlank(deviceCache)) {
                // 设备指纹不为空，且缓存器存在，做缓存
                if (Objects.nonNull(saveMapper)) {
                    String key = Objects.isNull(keyMapper) ? token : keyMapper.apply(token);
                    log.info("缓存设备指纹，key：{}，token：{}，value：{}", key, token, deviceCache);
                    saveMapper.accept(key, deviceCache);
                }
                // 组装响应
                map.put(DEVICE_CACHE_KEY, deviceCache);
                map.put(DEVICE_INFO_KEY, deviceInfo);
            }
        }
        return map;
    }

}
