package com.riskcontrol.api.utils;



import java.util.HashMap;
import java.util.Map;

public class MyFileType {

	public static final String JPG = "JPG";

	private static final Map<String, String> MIME_MAP = new HashMap<String, String>(){{
        put(".flv","video/x-flv");
        put(".mp4","video/mp4");
        put(".m3u8","application/x-mpegURL");
        put(".ts","video/MP2T");
        put(".3gp","video/3gpp");
        put(".mov","video/quicktime");
        put(".avi","video/x-msvideo");
        put(".wmv","video/x-ms-wmv");
        put(".json","application/json");
        put(".xml","application/xml");
        put(".gif","image/gif");
        put(".jpeg","image/jpeg");
        put(".png","image/png");
        put(".html","text/html");
        put(".plain","text/plain");
        put(".xls","application/vnd.ms-excel");
        put(".xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
	}};

	private static final Map<String, String> types = new HashMap<String, String>(){{

		put( MyFileType.JPG, ".jpg" );
		put("flv", ".flv");
		put("mp4", ".mp4");
		put("m3u8",".m3u8");
		put("ts", ".ts");
		put("3gp", ".3gp");
		put("mov", ".mov");
		put("avi", ".avi");
		put("wmv", ".wmv");

	}};

	public static String getSuffix ( String key ) {
		return MyFileType.types.get( key );
	}

	/**
	 * 根据给定的文件名,获取其后缀信息
	 * @param filename
	 * @return
	 */
	public static String getSuffixByFilename ( String filename ) {

		return filename.substring( filename.lastIndexOf( "." ) ).toLowerCase();

	}

	public static String getMIMEBySuffix(String suffix){
		return MIME_MAP.get(suffix);
	}

}
