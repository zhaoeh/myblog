package com.riskcontrol.api.constants;

import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Optional;

/**
 * 小程序或网站渠道
 */
public enum ChannelEnum {
    GLIFE("3", "GLIFE"),
    GPO("4", "GPO"),
    LAZADA("5", "LAZADA"),
    MAYA("6", "MAYA"),
    PERYAGAME("7", "PERYAGAME"),
    WEBSITE("99", "WEBSITE"),
    UNKNOWN("999", "UNKNOWN")
    ;

    public static ChannelEnum getNameByType(String type) {
        Optional<ChannelEnum> first = Arrays.stream(ChannelEnum.values()).filter(t -> StringUtils.equals(t.type, type)).findFirst();
        if (first.isPresent()) {
            return first.get();
        }
        return null;
    }

    private String type;
    private String name;

    ChannelEnum(String type, String name) {
        this.type = type;
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
