package com.riskcontrol.api.entity.request;

import com.google.common.base.MoreObjects;
import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.annotations.ApiModelProperty;

public class BaseQueryReq extends BaseReq {

    @ApiModelProperty(value = "页码[若不传，则默认1]", example = "1")
    private Integer pageNo = 1;

    @ApiModelProperty(value = "每页显示条数[若不传，则默认20]", example = "10")
    private Integer pageSize = 20;

    @ApiModelProperty(value = "是否只查询总数[0:否; 1:是]", example = "1")
    private Boolean onlyCount;
    
    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Boolean isOnlyCount() {
        return onlyCount ;
    }

    public void setOnlyCount(Boolean onlyCount) {
        this.onlyCount = onlyCount;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper("")
                .add("pageNo", pageNo)
                .add("pageSize", pageSize)
                .add("onlyCount", onlyCount)
                .addValue(super.toString())
                .omitNullValues()
                .toString();
    }
}
