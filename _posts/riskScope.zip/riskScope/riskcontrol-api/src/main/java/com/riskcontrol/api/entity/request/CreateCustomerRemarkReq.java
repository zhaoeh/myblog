package com.riskcontrol.api.entity.request;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
public class CreateCustomerRemarkReq extends BaseReq {


    @ApiModelProperty(required = true, value = "用户登录名")
    private String customerName;

    @ApiModelProperty(required = true, value = "备注")
    private String remarks;

    @ApiModelProperty(required = true, value = "备注截图")
    private String screenshot;


}
