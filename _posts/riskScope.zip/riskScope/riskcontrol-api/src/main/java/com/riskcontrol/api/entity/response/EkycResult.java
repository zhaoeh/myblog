package com.riskcontrol.api.entity.response;

import lombok.Data;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/10/7 17:41
 */
@Data
public class EkycResult {
    private String requestId;
    private String firstName;
    private String middleName;
    private String lastName;
    private String birthday;
    private String sex;
    private String idNo;
    private Integer idType;
    private String result;
}