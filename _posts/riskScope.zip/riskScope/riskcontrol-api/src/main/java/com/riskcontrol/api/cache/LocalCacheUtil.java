package com.riskcontrol.api.cache;

import com.riskcontrol.common.cache.LocalCacheHelper;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.response.ErrResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Optional;

/**
 * local cache tool class
 *
 * @program: riskcontrol-cron
 * @description: 本地缓存工具类
 * @author: Erhu.Zhao
 * @create: 2023-10-17 18:39
 **/
@Slf4j
@Component
public class LocalCacheUtil {

    private static ErrCodeLocalCacheLoader errCodeLocalCacheLoader;

    @Autowired
    public void setErrCodeLocalCacheLoader(ErrCodeLocalCacheLoader errCodeLocalCacheLoader) {
        LocalCacheUtil.errCodeLocalCacheLoader = errCodeLocalCacheLoader;
    }

    /**
     * 从名称为“DEFAULT”的caffeine cache中，获取key为“errCode”的value，并从value中获取指定key的错误码信息
     *
     * @param key error code
     * @return 对应的错误码信息
     */
    public static ErrResponse getErrResponse(String key) {
        return Optional.ofNullable(getErrorMap()).map(err -> err.get(key)).orElse(new ErrResponse(key.replace(Constant.ERR_CODE_MARK_PREFIX, "")));
    }

    /**
     * 从名称为“DEFAULT”的caffeine cache中，获取key为“errCode”的value
     *
     * @return errCode对应的缓存内容集
     */
    public static Map<String, ErrResponse> getErrorMap() {
        return LocalCacheHelper.getData(errCodeLocalCacheLoader.getDataCategory());
    }
}
