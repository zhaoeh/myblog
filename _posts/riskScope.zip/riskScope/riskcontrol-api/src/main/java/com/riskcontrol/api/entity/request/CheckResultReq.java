package com.riskcontrol.api.entity.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.Hidden;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.math.BigInteger;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/10/2 16:55
 */
@ApiModel("获取id+活体检测结果")
@Data
public class CheckResultReq {
    @Hidden
    private String bizId;
    @ApiModelProperty(required = true, value = "上一次请求的链接返回的transactionId" )
    @NotBlank(message = "transactionId can't blank")
    private String transactionId;
    @Hidden
    private String isReturnImage="Y";
    @Hidden
    private BigInteger requestId;
    @Hidden
    private String loginName;
}
