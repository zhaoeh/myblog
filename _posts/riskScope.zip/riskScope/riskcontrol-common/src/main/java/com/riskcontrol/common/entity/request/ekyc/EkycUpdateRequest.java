package com.riskcontrol.common.entity.request.ekyc;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.riskcontrol.common.annotation.StringValuesValid;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.math.BigInteger;
import java.util.Date;

/**
 * @description: ekyc, 第三方认证之后信息回写
 **/
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class EkycUpdateRequest {

    @ApiModelProperty(required = true, value = "提案主键")
    @NotNull(message = "id cannot be null")
    private BigInteger id;

    @ApiModelProperty(required = true, value = "用户登录名" )
    @NotBlank(message = "loginName cannot be empty")
    private String loginName;

    @ApiModelProperty(value = "首名")
    private String firstName;

    @ApiModelProperty(value = "中间名")
    private String middleName;

    @ApiModelProperty(value = "尾名")
    private String lastName;

    @ApiModelProperty(value = "生日")
    @Pattern(regexp = "^\s*$|^\\d{4}-\\d{2}-\\d{2}$", message = "birthday format error")
    private String birthday;

    @ApiModelProperty(value = "性别")
    @StringValuesValid(values = {"M", "F"}, message = "sex must be {target}")
    private String sex;

    @ApiModelProperty(value = "证件证明照")
    private String idFrontImg;

    @ApiModelProperty(value = "证件背面照")
    private String idBackImg;

    @ApiModelProperty( value = "证件类型")
    private Integer idType;

    @ApiModelProperty(value = "证件号")
    private String idNo;

    @ApiModelProperty(value = "自拍照")
    private String faceImg;

    @ApiModelProperty(required = true, value = "第三方获取结果时间")
    @NotNull(message = "ekycResultDate cannot be null")
    @JsonFormat(timezone = "GMT+8")
    private Date ekycResultDate;

    @ApiModelProperty(required = true, value = "第三方返回结果")
    @NotBlank(message = "ekycResult cannot be empty")
    private String ekycResult;
}
