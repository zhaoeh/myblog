package com.riskcontrol.common.annotation;

import com.riskcontrol.common.validation.EnumsValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

/**
 * @description: 枚举值校验注解
 * @author: ErHu.Zhao
 * @create: 2024-09-24
 **/
@Target({ElementType.FIELD, ElementType.METHOD, ElementType.ANNOTATION_TYPE, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {EnumsValidator.class})
@Documented
public @interface EnumValid {
    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    Class<? extends Enum> enumClass() default Enum.class;

    Class<? extends EnumsValidator.EnumFieldsSupplier> enumSupplier() default EnumsValidator.EnumFieldsSupplier.class;

    String enumField() default "";

    // 枚举字段期望索引
    int[] enumIndexes() default {};

    boolean deduplicateEnumField() default false;

    String message() default "必须为指定值";
}
