package com.riskcontrol.common.entity.request.api;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigInteger;

/*** @program: riskcontrol-common
 ** @description: 风控PBC返回接口
 ** @author: hongwei
 ** @create: 2023-11-14 14:35
 **/
@ApiModel(value = "风控PBC disable-请求对象", description = "风控PBC disable-请求对象")
@Data
public class PBCDeployDisableRequest {

    @ApiModelProperty("id")
    protected BigInteger id;
    @ApiModelProperty("抓取系统id")
    protected String systemId;
    @ApiModelProperty("删除时间")
    protected String deleteDate;
    @ApiModelProperty("删除人")
    protected String deleteBy;
}
