package com.riskcontrol.common.annotation;

import com.riskcontrol.common.config.CommonConfig;
import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

@Target({ElementType.TYPE, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
@Import(CommonConfig.class)
public @interface EnableRiskCommon {
}
