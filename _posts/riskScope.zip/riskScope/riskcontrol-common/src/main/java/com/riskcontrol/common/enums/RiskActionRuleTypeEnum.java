package com.riskcontrol.common.enums;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

/**
 * 规则校验类型
 * @author Heng.zhang
 */
@AllArgsConstructor
@Getter
public enum RiskActionRuleTypeEnum {
    //白名单类型（0:ip ; 1:设备指纹）
    IP(0, "ip"),
    DEVICE(1, "device"),
    COMPOSE_IP_AND_DEVICE(2, "ip+设备指纹"),
    ;
    private final int id;
    private final String name;

    /**
     * 获取所有的来源
     */
    public static List<RuleType> getAllowType(){
        return Arrays.stream(RiskActionRuleTypeEnum.values()).map(x-> new RiskActionRuleTypeEnum.RuleType(x.id,x.name)).toList();
    }

    /**
     * 渠道返回对象
     */
    @AllArgsConstructor
    @Data
    public static class RuleType implements Serializable {
        private static final long serialVersionUID = 1L;
        private final int id;
        private final String name;
    }
}
