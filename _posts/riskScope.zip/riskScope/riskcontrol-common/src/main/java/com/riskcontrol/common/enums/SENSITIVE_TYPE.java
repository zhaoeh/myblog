package com.riskcontrol.common.enums;

import com.riskcontrol.common.constants.Constant;

/**
 * 敏感信息类型枚举
 * Created by WADE on 2017/9/12 .
 */
public enum SENSITIVE_TYPE {

    /** 真实姓名 */
    REAL_NAME("1", "HIDE_REALNAME_TYPE", Constant.HIDE_PLACEHOLDER+Constant.HIDE_CHAR,"01"),

    /** 电话号码 */
    PHONE_NO("2", "HIDE_PHONENO_TYPE", Constant.HIDE_PLACEHOLDER+Constant.HIDE_PLACEHOLDER+Constant.HIDE_PLACEHOLDER+Constant.HIDE_CHAR+Constant.HIDE_PLACEHOLDER,"03"),
    /** 银行卡号 */
    BANK_NO("3", "HIDE_BANKNO_TYPE", Constant.HIDE_PLACEHOLDER+Constant.HIDE_CHAR+Constant.HIDE_PLACEHOLDER,"07"),

    /** 银行帐号*/
    BANK_ACCOUNT_NAME("6", "HIDE_BANKACCOUNTNAME_TYPE", Constant.HIDE_PLACEHOLDER+Constant.HIDE_CHAR+Constant.HIDE_PLACEHOLDER,"06"),
    
    /** 邮箱 */
    EMAIL("4", "HIDE_EMAIL_TYPE", Constant.HIDE_PLACEHOLDER+Constant.HIDE_CHAR+Constant.HIDE_PLACEHOLDER,"04"),

    /** 地址*/
    ADDRESS("5","HIDE_ADDRESS_TYPE",Constant.HIDE_PLACEHOLDER+Constant.HIDE_PLACEHOLDER+Constant.HIDE_PLACEHOLDER,"02"),
    /**  网路联系方式*/
    ONLINE_MESSENGER("6","HIDE_ONLINE_TYPE",Constant.HIDE_PLACEHOLDER+Constant.HIDE_PLACEHOLDER+Constant.HIDE_CHAR,"05"),

    /** 身份证 */
    CERT_ID("9", "HIDE_CERT_TYPE", Constant.HIDE_PLACEHOLDER+Constant.HIDE_CHAR,"09");

    /** 枚举类型代码 */
    private String code;
    private String ConstantName;
    private String defaultHideType;
    private String encryptCode;

    SENSITIVE_TYPE(String code, String ConstantName, String defaultHideType, String encryptCode) {
        this.code = code;
        this.ConstantName = ConstantName;
        this.defaultHideType = defaultHideType;
        this.encryptCode = encryptCode;
    }

    public String getCode(){
        return this.code;
    }

    public String getConstantName() {
        return ConstantName;
    }

    public String getDefaultHideType() {
        return defaultHideType;
    }

    public String getEncryptCode() {
        return encryptCode;
    }

    public static SENSITIVE_TYPE getConstantNameByCode(String code){
        for (SENSITIVE_TYPE sensitive_type : SENSITIVE_TYPE.values()) {
            if(sensitive_type.getCode().equals(code)){
                return sensitive_type;
            }
        }
        return null;
    }
}
