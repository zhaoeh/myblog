package com.riskcontrol.common.entity.request.api;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;

/**
 * @author Colson
 * @program riskcontrol-common
 * @description 更新手机号黑名单参数
 * @date 2023/10/17 15:30
 **/
@Data
@ApiModel(value = "更新手机号黑名单请求对象", description = "更新手机号黑名单参数")
public class PhoneNumberBlacklistUpdateRequest {

    @ApiModelProperty("ID")
    private BigInteger id;

    @ApiModelProperty("所有历史绑定的用户ID，逗号分隔，按照时间顺序增加")
    private String history;

    @ApiModelProperty("手机号码")
    private String phone;

    @ApiModelProperty("手机号码MD5")
    private String phoneMd5;

    @ApiModelProperty("状态：0-失效，1-生效中")
    private Integer status;

    @ApiModelProperty("最后一次最后修改的account")
    private String dataModifier;

    @ApiModelProperty("所属产品，默认C66")
    private String productId;

    @ApiModelProperty("备注")
    private String remarks;

}
