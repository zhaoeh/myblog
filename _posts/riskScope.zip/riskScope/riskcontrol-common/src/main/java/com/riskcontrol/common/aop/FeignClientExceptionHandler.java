package com.riskcontrol.common.aop;

import com.digiplus.apm.annotation.Monitor;
import com.riskcontrol.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.lang.reflect.Method;

/**
 * feignClient请求异常捕获
 * @author dante
 */
@Slf4j
@Aspect
@Component
public class FeignClientExceptionHandler {

    @Around("execution(* com.riskcontrol.common.client.*.*(..))")
    public Object handleFeignClientExceptions(ProceedingJoinPoint joinPoint) throws Throwable {
        String methodName = joinPoint.getSignature().getName();
        // 获取目标类（Feign 代理类）
        Class<?> targetClass = joinPoint.getTarget().getClass();
        // 获取 FeignClient 的 name 和 url
        String feignClientName = getFeignClientName(targetClass);
        // 获取方法上的请求地址
        String methodRequestUrl = getFeignMethodRequestUrl(joinPoint);
        // 拼接完整的请求 URL（服务 URL + 方法 URL）
        String fullRequestUrl = combineFullRequestUrl(targetClass, methodRequestUrl);

        log.info("FeignClient serviceName={},url={},fullRequestUrl={},methodName={} ", feignClientName, methodRequestUrl,fullRequestUrl, methodName);
        try {
            return joinPoint.proceed();
        } catch (Exception ex) {
            // 在这里捕获异常并记录日志
            recordFeignError(feignClientName, methodRequestUrl, methodName);
            // 可以根据需要重新抛出异常
            throw new BusinessException("Error occurred in FeignClient methodRequestUrl="+methodRequestUrl , 505);
        }
    }

//    @Monitor(name = "risk_feign_error", product = "feignClientName",channel = "methodRequestUrl", tag1 = "methodName", condition = "result = null")
    private void recordFeignError(String feignClientName, String methodRequestUrl, String methodName) {
        log.error("FeignClient error serviceName={},url={},methodName={} ", feignClientName, methodRequestUrl, methodName);
    }


    // 获取 FeignClient 的 name
    private String getFeignClientName(Class<?> clazz) {
        Class<?> originalClass = getOriginalFeignClientClass(clazz);
        if (originalClass != null) {
            FeignClient feignClient = originalClass.getAnnotation(FeignClient.class);
            if (feignClient != null) {
                return feignClient.name();
            }
        }
        return "Unknown Service";
    }

    private String getFeignMethodRequestUrl(ProceedingJoinPoint joinPoint) {
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        Method method = methodSignature.getMethod();

        // 获取 @GetMapping/@PostMapping 等注解的值
        if (method.isAnnotationPresent(GetMapping.class)) {
            return String.join(",", method.getAnnotation(GetMapping.class).value());
        } else if (method.isAnnotationPresent(PostMapping.class)) {
            return String.join(",", method.getAnnotation(PostMapping.class).value());
        } else if (method.isAnnotationPresent(RequestMapping.class)) {
            return String.join(",", method.getAnnotation(RequestMapping.class).value());
        }
        return "/";
    }

    // 拼接完整的请求 URL（服务 URL + 方法 URL）
    private String combineFullRequestUrl(Class<?> proxyClass, String methodRequestUrl) {
        String baseUrl = getFeignClientUrl(proxyClass);
        if (baseUrl.endsWith("/") && methodRequestUrl.startsWith("/")) {
            return baseUrl + methodRequestUrl.substring(1);
        } else if (!baseUrl.endsWith("/") && !methodRequestUrl.startsWith("/")) {
            return baseUrl + "/" + methodRequestUrl;
        }
        return baseUrl + methodRequestUrl;
    }

    // 获取 FeignClient 的 url
    private String getFeignClientUrl(Class<?> clazz) {
        Class<?> originalClass = getOriginalFeignClientClass(clazz);
        if (originalClass != null) {
            FeignClient feignClient = originalClass.getAnnotation(FeignClient.class);
            if (feignClient != null) {
                return feignClient.url();
            }
        }
        return "Unknown URL";
    }

    // 获取 FeignClient 原始接口类
    private Class<?> getOriginalFeignClientClass(Class<?> proxyClass) {
        // 如果是代理类，获取实际的接口
        Class<?>[] interfaces = proxyClass.getInterfaces();
        for (Class<?> iface : interfaces) {
            if (iface.isAnnotationPresent(FeignClient.class)) {
                return iface;
            }
        }
        return null;
    }
}
