package com.riskcontrol.common.entity.zoloz;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/10/2 17:02
 */
@Data
public class Result {

    @ApiModelProperty(required = true, value = "S API调用成功" )
    private String resultStatus;
    /**
     * HIGH_RISK 检测到高风险。用户账号被风险引擎冻结。
     * ACCOUNT_SERVICE_SUSPEND 用户账号被风险引擎列入黑名单。
     * DEVICE_NOT_SUPPORT 不支持当前的设备类型。
     * OS_NOT_SUPPORT 不支持当前设备的操作系统。
     * SDKVERSION_NOT_SUPPORT 不支持ZOLOZ SDK当前的版本。
     * INVALID_ARGUMENT 输入参数无效。关于无效参数的详细信息，请查看返回的resultMessage。
     * SYSTEM_ERROR 其他内部错误。有关错误详情，请查看返回的resultMessage。
     */
    @ApiModelProperty(required = true, value = "结果码" )
    private String resultCode;
    @ApiModelProperty(required = true, value = "客户端配置信息，包括SDK连接和行为参数。当result.resultStatus的值为S时，才返回该字段" )
    private String resultMessage;
}