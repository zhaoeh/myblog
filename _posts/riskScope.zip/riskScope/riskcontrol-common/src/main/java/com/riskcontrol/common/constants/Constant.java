package com.riskcontrol.common.constants;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * @Auther: yannis
 * @Date: 2023/8/31 14:19
 * @Description:
 */
public class  Constant {
    /**
     * yyyy-MM-dd HH:mm:ss
     */
    public static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    /**
     * M/d/yyyy h:mm:ss a
     */
    public static final DateTimeFormatter DATE_TIME_FORMATTER2 = new DateTimeFormatterBuilder().appendPattern("M/d/yyyy h:mm:ss a").parseCaseInsensitive().toFormatter(Locale.US);
    /**
     * yyyy-MM-dd
     */
    public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static final String WS_RESPONSE_SUCCESS = "SUCCESS";
    public static final String PHONE_BLACK_LIST_KEY = "phone:blackList:%s";

    public static final String RISK_KYC_FLAG_KEY = "riskQueryKycFlag:%s";

    public static final String RISK_KYC_LATEST_KEY = "risk:kyc:latest:%s";

    public static final String TRACE_KEY = "ticket";
    public static final String MDC_UUID_KEY = "uuid";
    public static final String LOGIN_NAME_PREFIX = "exists";
    public static final String ZERO = "0";
    public static final String ONE = "1";
    public static final String ZERO_STR = "0";
    public static final String ONE_STR = "1";
    public static final String TWO_STR = "2";
    public static final String THREE_STR = "3";
    public static final String FOUR_STR = "4";
    public static final String FIVE_STR = "5";
    public static final String SIX_STR = "6";

    public static final Integer ONE_INT = 1;
    public static final Integer TWO_INT = 2;
    public static final Integer SIX_INT = 6;

    //状态-否
    public static final Integer FLAG_NO = 0;
    //状态-是
    public static final Integer FLAG_YES = 1;
    public static final String COMMA_SYMBOL = ",";

    public static final String C66_PRODUCT_ID = "C66";

    public static final String MONTH_APPEND_DAY = "01";

    // caffeine cache namespace
    public static final String CAFFEINE_CACHE_NAME = "DEFAULT";
    // caffeine cache namespace中存储的key
    public static final String ERROR_CODE_CACHE = "errCode";
    //错误码前缀
    public static final String ERR_CODE_MARK_PREFIX = "MSG_";
    //未知异常信息
    public static final String UNKNOW_EXCEPTION = "UNKNOW_EXCEPTION";

    /**
     * EKYC审核通过短信模板key后缀*
     */
    public static final String EKYC_SUCCESS_SMS_SUFFIX = "-SMS-EKYC-SUCESS";

    /**
     * EKYC审核拒绝短信模板key后缀*
     */
    public static final String EKYC_REJECT_SMS_SUFFIX = "-SMS-EKYC-ERROR";

    /**
     * EKYC审核通过推送模板key后缀*
     */
    public static final String EKYC_SUCCESS_PUSH_SUFFIX = "-PUSH-EKYC-SUCESS";

    /**
     * EKYC审核拒绝推送模板key后缀*
     */
    public static final String EKYC_REJECT_PUSH_SUFFIX = "-PUSH-EKYC-ERROR";


    /**
     * 三方系统响应code字段名称
     */
    public static final String CODE = "code";

    /**
     * 三方系统响应message字段名称
     */
    public static final String MESSAGE = "message";

    /**
     * 三方系统响应业务userInfo字段名称
     */
    public static final String USERINFO = "userInfo";
    /**
     * 是否批量 1是0否
     */
    public static final int IS_BATCH = 1;
    public static final int IS_NOT_BATCH = 0;
    public static final String SPLIT_SYMBOL = ";";
    public static final String SPECIAL_SYMBOL = "#";
    //错误码语言标识
    public static final String CURRENT_LOCALE_MARK = "currentLocale";
    public static final List<String> SINGLE_LANGUAGE_CALLER = Arrays.asList("gateway", "csoffice");
    // 敏感信息遮蔽的字符
    public static final String HIDE_CHAR = "*";
    // 敏感信息遮蔽的占位符
    public static final String HIDE_PLACEHOLDER = "A";
    public static final String REGEX_EMAIL = "^(\\w+([-+.]\\w+)*)(@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*)$";

    public static final String USER_CENTER_CALL_SWITCH = "USER_CENTER_CALL_SWITCH";

    public static final String USER_CENTER_SERVER_NODE = "USER_CENTER_SERVER_NODE";

    public static final String SPORTS_DOMAIN_NAME = "SPORTS_DOMAIN_NAME";
    public static final String CREATE_REAL_CUSTOMER_CHECK_EMAIL = "CREATE_REAL_CUSTOMER_CHECK_EMAIL";
    public static final String X2_KEY = "X2_KEY";
    public static final String X3_KEY = "X3_KEY";
    public static final String CURRENT_ENVIRONMENT = "CURRENT_ENVIRONMENT";
    public static final String GAMEPLUS_DOMAIN_NAME = "GAMEPLUS_DOMAIN_NAME";
    public static final String PRODUCT_TYPE_01 = "01";
    public static final String PRODUCT_TYPE_02 = "02";
    public static final String PRODUCT_TYPE_03 = "03";
    public static final String PRODUCT_TYPE_04 = "04";
    public static final String PRODUCT_TYPE_05 = "05";
    public static final String PRODUCT_TYPE_06 = "06";
    public static final String PRODUCT_TYPE_07 = "07";
    public static final String PRODUCT_TYPE_08 = "08";
    public static final Integer KYC_FLAG_AGE_100 = 100;
    public static final String[] OCCUPATION_ARRAY = new String[]{"Accounting/Finance", "dmin/Human Resources", "Sales/Marketing", "Arts/Media/Communications", "Services", "Hotel/Restaurant", "Education/Training", "Computer/Information Technology",
            "Engineering", "Building/Construction", "Healthcare", "Others"};
    public static final String[] SOURCE_OF_INCOME_ARRAY = new String[]{"Salary/Wages", "Business", "Retirement", "Rent/Royalty/Licensing", "Capital Gain", "Non-Capital Asset", "Others"};
    public static final String[] ANNUAL_INCOME_ARRAY = new String[]{"Below 15W", "15W-20W", "15W-20W", "20W-25W", "25W-30W", "30W-35W", "35W+"};
    public static final JSONObject CITY_POSTAL_CODE_JSON = JSON.parseObject("{\"Cavite\":{\"Imus\":\"4103\",\"Amadeo\":\"4119\",\"Kawit\":\"4104\",\"General Mariano Alvarez\":\"4117\",\"Alfonso\":\"4123\",\"Carmona\":\"4116\",\"Naic\":\"4110\",\"Bacoor\":\"4102\",\"General Trias\":\"4107\",\"Cavite City\":\"4100\",\"General Emilio Aguinaldo\":\"4124\",\"Indang\":\"4122\",\"Silang\":\"4118\",\"Maragondon\":\"4112\",\"Ternate\":\"4111\",\"Noveleta\":\"4105\"},\"Laguna\":{\"Pakil\":\"4017\",\"Cabuyao\":\"4025\",\"Luisiana\":\"4032\",\"Majayjay\":\"4005\",\"Pangil\":\"4018\",\"Cavinti\":\"4013\",\"Famy\":\"4021\",\"Mabitac\":\"4020\",\"Calauan\":\"4012\",\"Pila\":\"4010\",\"Magdalena\":\"4007\",\"San Pedro\":\"4023\",\"Nagcarlan\":\"4002\",\"Paete\":\"4016\",\"Pagsanjan\":\"4008\",\"Bay\":\"4033\",\"Liliw\":\"4004\",\"Siniloan\":\"4019\",\"Calamba\":\"7210\",\"Santa Rosa\":\"3101\",\"Lumban\":\"4014\"},\"Eastern Samar\":{\"Maydolong\":\"6802\",\"San Julian\":\"6814\",\"San Policarpo\":\"6821\",\"Llorente\":\"6803\",\"Borongan\":\"6800\",\"Balangiga\":\"6812\",\"Guiuan\":\"6809\",\"Giporlos\":\"6811\",\"Quinapondan\":\"6810\",\"Oras\":\"6818\",\"Arteche\":\"6822\",\"Jipapad\":\"6819\",\"Lawaan\":\"6813\",\"Maslog\":\"6820\",\"Sulat\":\"6815\",\"Hernani\":\"6804\",\"Taft\":\"6816\",\"Balangkayan\":\"6801\"},\"Lanao del Sur\":{\"Calanogas\":\"9319\",\"Mulondo\":\"9702\",\"Wao\":\"9716\",\"Madalum\":\"9315\",\"Bubong\":\"9708\",\"Bayang\":\"9309\",\"Balabagan\":\"9302\",\"Marantao\":\"9711\",\"Marogong\":\"9303\",\"Pualas\":\"9313\",\"Ganassi\":\"9311\",\"Malabang\":\"9300\",\"Piagapo\":\"9710\",\"Butig\":\"9305\",\"Maguing\":\"9715\",\"Saguiaran\":\"9701\",\"Kapai\":\"9709\",\"Kapatagan\":\"9214\",\"Binidayan\":\"9310\",\"Madamba\":\"9314\",\"Taraka\":\"9712\",\"Tamparan\":\"9704\",\"Lumbayanague\":\"9306\",\"Tubaran\":\"9304\",\"Tugaya\":\"9317\",\"Lumbatan\":\"9307\"},\"Bulacan\":{\"Paombong\":\"3001\",\"Angat\":\"3012\",\"Obando\":\"3021\",\"Pulilan\":\"3005\",\"Calumpit\":\"3003\",\"Bocaue\":\"3018\",\"Norzagaray\":\"3013\",\"Marilao\":\"3019\",\"Pandi\":\"3014\",\"Baliuag\":\"3006\",\"Guiguinto\":\"3015\",\"Bustos\":\"3007\"},\"Tarlac\":{\"Moncada\":\"2334\",\"Gerona\":\"2302\",\"Anao\":\"2310\",\"Tarlac City\":\"2300\",\"Santa Ignacia\":\"2303\",\"Bamban\":\"2317\",\"Mayantoc\":\"2304\",\"Pura\":\"2312\",\"Ramos\":\"2311\",\"Camiling\":\"2306\",\"Capas\":\"2333\",\"San Clemente\":\"2305\"},\"Zamboanga del Sur\":{\"Kumalarang\":\"7005\",\"Josefina\":\"7027\",\"Lapuyan\":\"7037\",\"Tigbao\":\"7043\",\"Midsalip\":\"7021\",\"Guipos\":\"7042\",\"Molave\":\"7023\",\"Tabina\":\"7034\",\"Dumalinao\":\"7015\",\"Bayog\":\"7011\",\"Labangan\":\"7017\",\"Dumingag\":\"7028\",\"Margosatubig\":\"7035\",\"Tambulig\":\"7025\",\"Lakewood\":\"7014\",\"Zamboanga City\":\"7000\",\"Dinas\":\"7030\",\"Dimataling\":\"7032\",\"Vincenzo A. Sagun\":\"7036\",\"Tukuran\":\"7019\",\"Mahayag\":\"7026\"},\"Camarines Sur\":{\"Tigaon\":\"4420\",\"Ragay\":\"4410\",\"Caramoan\":\"4429\",\"Sipocot\":\"4408\",\"Nabua\":\"4434\",\"Lagonoy\":\"4425\",\"Lupi\":\"4409\",\"Garchitorena\":\"4428\",\"Canaman\":\"4402\",\"Milaor\":\"4413\",\"Balatan\":\"4436\",\"Magarao\":\"4403\",\"Camaligan\":\"4401\",\"Bombon\":\"4404\",\"Baao\":\"4432\",\"Siruma\":\"4427\",\"Cabusao\":\"4406\",\"Goa\":\"4422\",\"Del Gallego\":\"4411\",\"Calabanga\":\"4405\",\"Minalabac\":\"4414\",\"Pasacao\":\"4417\",\"Buhi\":\"4433\",\"Tinambac\":\"4426\",\"Ocampo\":\"4419\",\"Libmanan\":\"4407\",\"Pili\":\"4418\",\"Gainza\":\"4412\",\"Bula\":\"4430\"},\"Camiguin\":{\"Mahinog\":\"9101\",\"Guinsiliban\":\"9102\",\"Mambajao\":\"9100\",\"Sagay\":\"9103\"},\"Romblon\":{\"Ferrol\":\"5506\",\"Corcuera\":\"5514\",\"Odiongan\":\"5505\",\"Romblon\":\"5500\",\"Cajidiocan\":\"5512\",\"Magdiwang\":\"5511\"},\"Occidental Mindoro\":{\"Calintaan\":\"5102\",\"Sablayan\":\"5104\",\"Mamburao\":\"5106\",\"Paluan\":\"5107\",\"Lubang\":\"5109\"},\"Samar\":{\"Talalora\":\"6719\",\"Santa Margarita\":\"6709\",\"Hinabangan\":\"6713\",\"Marabut\":\"6721\",\"Almagro\":\"6724\",\"Daram\":\"6722\",\"Pagsanghan\":\"6705\",\"Tarangnan\":\"6704\",\"Jiabong\":\"6701\",\"Pinabacdao\":\"6716\",\"San Sebastian\":\"6714\",\"Villareal\":\"6717\",\"Matuguinao\":\"6708\",\"Catbalogan\":\"6700\",\"Basey\":\"6720\",\"Calbiga\":\"6715\",\"Motiong\":\"6702\",\"San Jorge\":\"6707\",\"Gandara\":\"6706\"},\"Aurora\":{\"Dipaculao\":\"3203\",\"Baler\":\"3200\",\"Dinalungan\":\"3206\",\"Dingalan\":\"3207\",\"Dilasag\":\"3205\",\"Maria Aurora\":\"3202\"},\"Sorsogon\":{\"Barcelona\":\"4712\",\"Castilla\":\"4713\",\"Santa Magdalena\":\"4709\",\"Juban\":\"4703\",\"Bulusan\":\"4704\",\"Prieto Diaz\":\"4711\",\"Matnog\":\"4708\",\"Donsol\":\"4715\",\"Gubat\":\"4710\",\"Irosin\":\"4707\",\"Bulan\":\"4706\"},\"NCR, 2nd district\":{},\"Bataan\":{\"Abucay\":\"2114\",\"Samal\":\"2113\",\"Bagac\":\"2107\",\"Hermosa\":\"2111\",\"Orani\":\"2112\",\"Dinalupihan\":\"2110\",\"Limay\":\"2103\",\"Orion\":\"2102\"},\"Davao del Sur\":{\"Davao City\":\"8000\",\"Padada\":\"8007\",\"Sulop\":\"8009\",\"Kiblawan\":\"8008\",\"Malalag\":\"8010\",\"Bansalan\":\"8005\",\"Matanao\":\"8003\"},\"Iloilo\":{\"Lambunao\":\"5042\",\"Oton\":\"5020\",\"Calinog\":\"5040\",\"Leganes\":\"5003\",\"Carles\":\"5019\",\"Pavia\":\"5001\",\"Janiuay\":\"5034\",\"Bingawan\":\"5041\",\"Miagao\":\"5023\",\"Alimodian\":\"5028\",\"Mina\":\"5032\",\"Balasan\":\"5018\",\"Estancia\":\"5017\",\"Dingle\":\"5035\",\"Batad\":\"5016\",\"Leon\":\"5026\",\"Tubungan\":\"5027\",\"Iloilo City\":\"5000\",\"Dumangas\":\"5006\",\"Zarraga\":\"5004\",\"Guimbal\":\"5022\",\"Banate\":\"5010\",\"San Dionisio\":\"5015\",\"Ajuy\":\"5012\",\"Pototan\":\"5008\",\"Anilao\":\"5009\",\"Tigbauan\":\"5021\",\"Sara\":\"5014\",\"Igbaras\":\"5029\",\"New Lucena\":\"5005\",\"Badiangan\":\"5033\"},\"Misamis Oriental\":{\"Jasaan\":\"9003\",\"Binuangan\":\"9008\",\"Salay\":\"9007\",\"Lagonglong\":\"9006\",\"Initao\":\"9022\",\"Villanueva\":\"9002\",\"Medina\":\"9013\",\"El Salvador\":\"9017\",\"Talisayan\":\"9012\",\"Alubijid\":\"9018\",\"Gitagum\":\"9020\",\"Naawan\":\"9023\",\"Laguindingan\":\"9019\",\"Balingasag\":\"9005\",\"Opol\":\"9016\",\"Manticao\":\"9024\",\"Lugait\":\"9025\"},\"Tawi-Tawi\":{\"Languyan\":\"7509\",\"Sitangkai\":\"7506\",\"South Ubian\":\"7504\",\"Bongao\":\"7500\",\"Tandubas\":\"7502\",\"Sapa-Sapa\":\"7503\",\"Simunul\":\"7505\"},\"Ifugao\":{\"Aguinaldo\":\"3606\",\"Asipulo\":\"3610\",\"Hingyon\":\"3607\",\"Kiangan\":\"3604\",\"Banaue\":\"3601\",\"Hungduan\":\"3603\",\"Lagawe\":\"3600\",\"Lamut\":\"3605\",\"Tinoc\":\"3609\",\"Mayoyao\":\"3602\"},\"Davao Oriental\":{\"Tarragona\":\"8201\",\"Mati\":\"8200\"},\"Negros Oriental\":{\"Tayasan\":\"6211\",\"Jimalalud\":\"6212\",\"Manjuyod\":\"6208\",\"Mabinay\":\"6207\",\"Sibulan\":\"6201\",\"Siaton\":\"6219\",\"Bacong\":\"6216\",\"Santa Catalina\":\"2701\",\"Basay\":\"6222\",\"Ayungon\":\"6210\",\"Dauin\":\"6217\",\"Guihulngan\":\"6214\"},\"Pangasinan\":{\"Laoac\":\"2437\",\"Bani\":\"2407\",\"Mangatarem\":\"2413\",\"Binalonan\":\"2436\",\"Sual\":\"2403\",\"Pozorrubio\":\"2435\",\"Manaoag\":\"2430\",\"Bautista\":\"2424\",\"Asingan\":\"2439\",\"Villasis\":\"2427\",\"San Fabian\":\"2433\",\"Tayug\":\"2445\",\"Agno\":\"2408\",\"Mangaldan\":\"2432\",\"Aguilar\":\"2415\",\"Bolinao\":\"2406\",\"Binmaley\":\"2417\",\"Lingayen\":\"2401\",\"Bayambang\":\"2423\",\"Rosales\":\"2441\",\"Urdaneta\":\"2428\",\"Mapandan\":\"2429\",\"Urbiztondo\":\"2414\",\"Basista\":\"2422\",\"Labrador\":\"2402\",\"Malasiqui\":\"2421\",\"Calasiao\":\"2418\",\"Balungao\":\"2442\",\"Natividad\":\"2446\",\"Umingan\":\"2443\",\"Dasol\":\"2411\",\"Bugallon\":\"2416\"},\"Quirino\":{\"Maddela\":\"3404\",\"Cabarroguis\":\"3400\",\"Nagtipunan\":\"3405\",\"Saguday\":\"3402\",\"Aglipay\":\"3403\",\"Diffun\":\"3401\"},\"South Cotabato\":{\"Tampakan\":\"9507\",\"Polomolok\":\"9504\",\"Tantangan\":\"9510\",\"Surallah\":\"9512\",\"Tupi\":\"9505\",\"Norala\":\"9508\"},\"Agusan del Norte\":{\"Nasipit\":\"8602\",\"Remedios T. Romualdez\":\"8611\",\"Las Nieves\":\"8610\",\"Jabonga\":\"8607\",\"Kitcharao\":\"8609\",\"Tubay\":\"8606\"},\"Isabela\":{\"Gamu\":\"3301\",\"Echague\":\"3309\",\"Angadanan\":\"3307\",\"Jones\":\"3313\",\"Divilacan\":\"3335\",\"Maconacon\":\"3333\",\"Ilagan\":\"3300\",\"Ramon\":\"3319\",\"Tumauini\":\"3325\",\"Cabagan\":\"3328\",\"Benito Soliven\":\"3331\",\"San Mariano\":\"3332\",\"San Guillermo\":\"3308\",\"Reina Mercedes\":\"3303\",\"Cauayan\":\"6112\",\"Cordon\":\"3312\",\"Mallig\":\"3323\"},\"Albay\":{\"Tiwi\":\"4513\",\"Oas\":\"4505\",\"Libon\":\"4507\",\"Manito\":\"4514\",\"Polangui\":\"4506\",\"Pio Duran\":\"4516\",\"Guinobatan\":\"4503\",\"Jovellar\":\"4515\",\"Camalig\":\"4502\",\"Rapu-Rapu\":\"4517\",\"Bacacay\":\"0905\",\"Malilipot\":\"4510\"},\"Bukidnon\":{\"Sumilao\":\"8701\",\"Kadingilan\":\"8713\",\"Maramag\":\"8714\",\"Baungon\":\"8707\",\"Impasugong\":\"8702\",\"Lantapan\":\"8722\",\"Don Carlos\":\"8712\",\"Pangantucan\":\"8717\",\"Dangcagan\":\"8719\",\"Cabanglasan\":\"8723\",\"Manolo Fortich\":\"8703\",\"Kibawe\":\"8720\",\"Libona\":\"8706\",\"Kalilangan\":\"8718\",\"Damulog\":\"8721\",\"Kitaotao\":\"8716\",\"Talakag\":\"8708\"},\"Marinduque\":{\"Boac\":\"4900\",\"Gasan\":\"4905\",\"Mogpog\":\"4901\",\"Torrijos\":\"4903\"},\"Agusan del Sur\":{\"Bunawan\":\"8506\",\"Sibagat\":\"8503\",\"Veruela\":\"8509\",\"Santa Josefa\":\"8512\",\"Talacogon\":\"8510\",\"Trento\":\"8505\",\"Bayugan\":\"8502\"},\"Sulu\":{\"Talipao\":\"7403\",\"Siasi\":\"7412\",\"Jolo\":\"7400\",\"Patikul\":\"7401\",\"Indanan\":\"7407\",\"Maimbung\":\"7409\",\"Tapul\":\"7410\",\"Lugus\":\"7411\",\"Pata\":\"7405\",\"Luuk\":\"7404\"},\"Cagayan\":{\"Camalaniugan\":\"3510\",\"Baggao\":\"3506\",\"Solana\":\"3503\",\"Buguey\":\"3511\",\"Ballesteros\":\"3516\",\"Allacapan\":\"3523\",\"Sanchez-Mira\":\"3518\",\"Iguig\":\"3504\",\"Santa Praxedes\":\"3521\",\"Tuao\":\"3528\",\"Piat\":\"3527\",\"Gattaran\":\"3508\",\"Abulug\":\"3517\",\"Gonzaga\":\"3513\",\"Amulung\":\"3505\",\"Calayan\":\"3520\",\"Aparri\":\"3515\",\"Lasam\":\"3524\",\"Enrile\":\"3501\"},\"Abra\":{\"Tubo\":\"2814\",\"Tineg\":\"2822\",\"Luba\":\"2813\",\"Daguioman\":\"2816\",\"Villaviciosa\":\"2811\",\"Bucloc\":\"2817\",\"Bucay\":\"2805\",\"Boliney\":\"2815\",\"Lagangilang\":\"2802\",\"Sallapadan\":\"2818\",\"Manabo\":\"2810\",\"Bangued\":\"2800\",\"Danglas\":\"2825\",\"Pidigan\":\"2806\",\"Lacub\":\"2821\",\"Tayum\":\"2803\",\"Lagayan\":\"2824\",\"Langiden\":\"2807\",\"Malibcong\":\"2820\"},\"Leyte\":{\"Isabel\":\"6539\",\"Dagami\":\"6515\",\"Villaba\":\"6537\",\"Merida\":\"6540\",\"Hindang\":\"6523\",\"Tolosa\":\"6503\",\"Kananga\":\"6531\",\"Burauen\":\"6516\",\"Baybay\":\"6521\",\"Inopacan\":\"6522\",\"Alangalang\":\"6517\",\"Tunga\":\"6528\",\"Carigara\":\"6529\",\"Babatngon\":\"6520\",\"Matalom\":\"6526\",\"Hilongos\":\"6524\",\"Mayorga\":\"6507\",\"Palompon\":\"6538\",\"Capoocan\":\"6530\",\"Barugo\":\"6519\",\"Albuera\":\"6542\",\"Tabango\":\"6536\",\"Calubian\":\"6534\",\"Leyte\":\"6533\",\"Palo\":\"6501\",\"Tabontabon\":\"6504\",\"Dulag\":\"6505\",\"Mahaplag\":\"6512\",\"Jaro\":\"6527\",\"Abuyog\":\"6510\",\"Pastrana\":\"6514\",\"Julita\":\"6506\"},\"Oriental Mindoro\":{\"Calapan\":\"5200\",\"Gloria\":\"5209\",\"Pinamalayan\":\"5208\",\"San Teodoro\":\"5202\",\"Pola\":\"5206\",\"Naujan\":\"5204\",\"Mansalay\":\"5213\",\"Baco\":\"5201\",\"Bansud\":\"5210\",\"Puerto Galera\":\"5203\"},\"Zamboanga Sibugay\":{\"Payao\":\"7008\",\"Titay\":\"7003\",\"Ipil\":\"7001\",\"Siay\":\"7006\",\"Diplahan\":\"7039\",\"Talusan\":\"7012\",\"Olutanga\":\"7041\",\"Tungawan\":\"7018\",\"Malangas\":\"7038\",\"Mabuhay\":\"7010\",\"Buug\":\"7009\",\"Kabasalan\":\"7005\"},\"NCR, City of Manila, 1st district\":{},\"Siquijor\":{\"Lazi\":\"6228\",\"Enrique Villanueva\":\"6230\",\"Larena\":\"6226\",\"Maria\":\"6229\"},\"Capiz\":{\"Panay\":\"5801\",\"Roxas City\":\"5800\",\"Mambusao\":\"5807\",\"Ivisan\":\"5805\",\"Sigma\":\"5816\",\"Dumarao\":\"5812\",\"Panitan\":\"5815\",\"Tapaz\":\"5814\",\"Dumalag\":\"5813\",\"Dao\":\"5810\",\"Jamindan\":\"5808\",\"Sapian\":\"5806\",\"Cuartero\":\"5811\"},\"Davao del Norte\":{\"Samal\":\"2113\",\"New Corella\":\"8104\",\"Kapalong\":\"8113\"},\"Antique\":{\"Sebaste\":\"5709\",\"Culasi\":\"5708\",\"Tibiao\":\"5707\",\"Belison\":\"5701\",\"Barbaza\":\"5706\",\"Valderrama\":\"5703\",\"Patnongon\":\"5702\",\"Sibalom\":\"5713\",\"Caluya\":\"5711\",\"Bugasong\":\"5456\",\"Hamtic\":\"5715\"},\"Quezon\":{\"Lopez\":\"4316\",\"Sariaya\":\"4322\",\"Patnanungan\":\"4341\",\"Gumaca\":\"4307\",\"Catanauan\":\"4311\",\"Pagbilao\":\"4302\",\"Mulanay\":\"4312\",\"Agdangan\":\"4304\",\"Jomalig\":\"4342\",\"Alabat\":\"4333\",\"Tagkawayan\":\"4321\",\"Real\":\"4335\",\"Unisan\":\"4305\",\"Mauban\":\"4330\",\"Atimonan\":\"4331\",\"Perez\":\"4334\",\"Guinayangan\":\"4319\",\"Calauag\":\"4318\",\"Tiaong\":\"4325\",\"Burdeos\":\"4340\",\"Panukulan\":\"4337\",\"Tayabas\":\"4327\",\"Macalelon\":\"4309\",\"Lucban\":\"4328\",\"General Nakar\":\"4338\"},\"Ilocos Sur\":{\"San Emilio\":\"2722\",\"Caoayan\":\"2702\",\"Cabugao\":\"2732\",\"Sugpon\":\"2717\",\"Sinait\":\"2733\",\"Santa\":\"2703\",\"Alilem\":\"2716\",\"Nagbukel\":\"2725\",\"Tagudin\":\"2714\",\"Galimuyod\":\"2709\",\"Santa Catalina\":\"2701\",\"Cervantes\":\"2718\",\"Sigay\":\"2719\",\"Narvacan\":\"2704\",\"Magsingal\":\"2730\",\"Banayoyo\":\"2708\",\"Lidlidda\":\"2723\",\"San Esteban\":\"2706\",\"Bantay\":\"2727\",\"Suyo\":\"2715\"},\"Palawan\":{\"Coron\":\"5316\",\"Dumaran\":\"5310\",\"Cuyo\":\"5318\",\"Bataraza\":\"5306\",\"Araceli\":\"5311\",\"Balabac\":\"5307\",\"Aborlan\":\"5302\",\"Narra\":\"5303\",\"Culion\":\"5315\",\"Linapacan\":\"5314\",\"Puerto Princesa\":\"5300\",\"Agutaya\":\"5320\",\"Brooke's Point\":\"5305\",\"Busuanga\":\"5317\",\"Cagayancillo\":\"5321\"},\"Aklan\":{\"Altavas\":\"5616\",\"Kalibo\":\"5600\",\"Lezo\":\"5605\",\"Makato\":\"5611\",\"Libacao\":\"5602\",\"Batan\":\"5615\",\"Buruanga\":\"5609\",\"Tangalan\":\"5612\",\"Madalag\":\"5603\",\"Numancia\":\"5604\",\"Nabas\":\"5607\",\"Malay\":\"5608\",\"New Washington\":\"5610\",\"Ibajay\":\"5613\"},\"Pampanga\":{\"Mabalacat\":\"2010\",\"Lubao\":\"2005\",\"Arayat\":\"2012\",\"Guagua\":\"2003\",\"Apalit\":\"2016\",\"Candaba\":\"2013\",\"Sasmuan\":\"2004\",\"Minalin\":\"2019\",\"Bacolor\":\"2001\",\"Porac\":\"2008\",\"Macabebe\":\"2018\",\"Floridablanca\":\"2006\",\"Mexico\":\"2021\",\"San Simon\":\"2015\",\"Masantol\":\"2017\",\"Magalang\":\"2011\"},\"Cebu\":{\"Aloguinsan\":\"6088\",\"Tabogon\":\"6009\",\"Balamban\":\"6041\",\"Minglanilla\":\"6046\",\"Borbon\":\"6008\",\"Moalboal\":\"6032\",\"Cebu City\":\"6000\",\"Consolacion\":\"6001\",\"Samboan\":\"6027\",\"Alcoy\":\"2566\",\"Medellin\":\"6012\",\"Argao\":\"6099\",\"Ginatilan\":\"6028\",\"Oslob\":\"6025\",\"Danao\":\"6344\",\"Poro\":\"6049\",\"Dumanjug\":\"6035\",\"Bantayan\":\"6052\",\"Asturias\":\"6010\",\"Tabuelan\":\"6044\",\"Sibonga\":\"6020\",\"Ronda\":\"6034\",\"Dalaguete\":\"6022\",\"Boljoon\":\"6024\",\"Badian\":\"6011\",\"Catmon\":\"6006\",\"Madridejos\":\"6053\",\"Malabuyoc\":\"6029\",\"Santander\":\"6026\",\"Daanbantayan\":\"6013\",\"Cordova\":\"6017\",\"Barili\":\"6036\"},\"Cotabato\":{\"Magpet\":\"9404\",\"Matalam\":\"9406\",\"Pikit\":\"9409\",\"Aleosan\":\"9415\",\"Tulunan\":\"9403\",\"Alamada\":\"9413\",\"Libungan\":\"9411\",\"M'lang\":\"9402\",\"Kabacan\":\"9407\",\"Arakan\":\"9417\",\"Makilala\":\"9401\",\"Midsayap\":\"9410\",\"Antipas\":\"9414\",\"Banisilan\":\"9416\"},\"Sarangani\":{\"Malapatan\":\"9516\",\"Malungon\":\"9503\",\"Maasim\":\"9502\",\"Glan\":\"9517\",\"Alabel\":\"9501\",\"Kiamba\":\"9514\",\"Maitum\":\"9515\"},\"Davao de Oro\":{\"Montevista\":\"8107\",\"Monkayo\":\"8111\",\"Pantukan\":\"8117\",\"Maco\":\"8114\",\"New Bataan\":\"8110\",\"Mawab\":\"8108\",\"Nabunturan\":\"8106\"},\"Zambales\":{\"San Marcelino\":\"2207\",\"Iba\":\"2201\",\"Botolan\":\"2202\",\"San Felipe\":\"2204\",\"Subic\":\"2209\",\"Masinloc\":\"2211\",\"Cabangan\":\"2203\",\"Castillejos\":\"2208\"},\"Davao Occidental\":{\"Malita\":\"8012\",\"Don Marcelino\":\"8013\",\"Sarangani\":\"8015\"},\"Biliran\":{\"Biliran\":\"6549\",\"Kawayan\":\"6545\",\"Caibiran\":\"6548\",\"Maripipi\":\"6546\",\"Cabucgayan\":\"6550\",\"Naval\":\"6543\",\"Almeria\":\"6544\",\"Culaba\":\"6547\"},\"Guimaras\":{\"Sibunag\":\"5048\",\"Jordan\":\"5045\",\"San Lorenzo\":\"5047\",\"Nueva Valencia\":\"5046\"},\"Sultan Kudarat\":{\"Tacurong\":\"9800\",\"Lutayan\":\"9803\",\"Columbio\":\"9801\",\"Isulan\":\"9805\",\"Bagumbayan\":\"9810\",\"Palimbang\":\"9809\",\"Kalamansig\":\"9808\",\"Lebak\":\"9807\"},\"Nueva Ecija\":{\"Llanera\":\"3126\",\"Carranglan\":\"3123\",\"Laur\":\"3129\",\"Talavera\":\"3114\",\"Nampicuan\":\"3116\",\"Jaen\":\"3109\",\"Cuyapo\":\"3117\",\"San Leonardo\":\"3102\",\"Licab\":\"3112\",\"Cabiao\":\"3107\",\"Lupao\":\"3122\",\"Pantabangan\":\"3124\",\"Aliaga\":\"3111\",\"Zaragoza\":\"3110\",\"Guimba\":\"3115\",\"Santa Rosa\":\"3101\"},\"Rizal\":{\"Teresa\":\"1880\",\"Pililla\":\"1910\",\"Cainta\":\"1900\",\"Binangonan\":\"1940\",\"Cardona\":\"1950\",\"Tanay\":\"1980\",\"Angono\":\"1930\",\"Jalajala\":\"1900\"},\"Surigao del Sur\":{\"Lianga\":\"8307\",\"Bislig\":\"8311\",\"Barobo\":\"8309\",\"Hinatuan\":\"8310\",\"Tandag\":\"8300\",\"Carrascal\":\"8318\",\"Tago\":\"8302\",\"Marihatag\":\"8306\",\"Cagwait\":\"8304\",\"Bayabas\":\"8303\",\"Madrid\":\"8316\",\"Lanuza\":\"8314\",\"Cortes\":\"6341\",\"Tagbina\":\"8308\",\"Lingig\":\"8312\"},\"Negros Occidental\":{\"Sagay\":\"9103\",\"Valladolid\":\"6103\",\"Pulupandan\":\"6102\",\"Murcia\":\"6129\",\"Bacolod\":\"9205\",\"Manapla\":\"6120\",\"Toboso\":\"6125\",\"Isabela\":\"6128\",\"Candoni\":\"6110\",\"Ilog\":\"6109\",\"Cauayan\":\"6112\"},\"Dinagat Islands\":{\"Dinagat\":\"8412\",\"Tubajon\":\"8426\",\"Cagdianao\":\"8411\"},\"Batanes\":{\"Uyugan\":\"3903\",\"Mahatao\":\"3901\",\"Itbayat\":\"3905\",\"Sabtang\":\"3904\",\"Ivana\":\"3902\",\"Basco\":\"3900\"},\"Ilocos Norte\":{\"Pasuquin\":\"2917\",\"Paoay\":\"2902\",\"Carasi\":\"2911\",\"Adams\":\"2922\",\"Nueva Era\":\"2909\",\"Bangui\":\"2920\",\"Bacarra\":\"2916\",\"Pagudpud\":\"2919\",\"Solsona\":\"2910\",\"Currimao\":\"2903\",\"Piddig\":\"2912\",\"Sarrat\":\"2914\",\"Pinili\":\"2905\",\"Dingras\":\"2913\",\"Vintar\":\"2915\",\"Badoc\":\"2904\",\"Marcos\":\"2907\",\"Dumalneg\":\"2921\"},\"Mountain Province\":{\"Sabangan\":\"2622\",\"Tadian\":\"2620\",\"Bauko\":\"2621\",\"Sadanga\":\"2617\",\"Paracelis\":\"2625\",\"Natonin\":\"2624\",\"Barlig\":\"2623\",\"Sagada\":\"2619\",\"Besao\":\"2618\"},\"Basilan\":{\"Sumisip\":\"7305\",\"Lantawan\":\"7301\",\"Maluso\":\"7303\",\"Isabela City\":\"7300\",\"Tipo-Tipo\":\"7304\"},\"Masbate\":{\"Palanas\":\"5404\",\"Dimasalang\":\"5403\",\"Monreal\":\"5418\",\"Mobo\":\"5401\",\"Cataingan\":\"5405\",\"Baleno\":\"5413\",\"Balud\":\"5412\",\"Masbate City\":\"5400\",\"Mandaon\":\"5411\",\"Uson\":\"5402\",\"Aroroy\":\"5414\",\"Milagros\":\"5410\",\"Cawayan\":\"5409\"},\"Kalinga\":{\"Pasil\":\"3803\",\"Tinglayan\":\"3804\",\"Lubuagan\":\"3802\",\"Balbalan\":\"3801\",\"Tanudan\":\"3805\",\"Pinukpuk\":\"3806\"},\"Southern Leyte\":{\"Pintuyan\":\"6614\",\"Silago\":\"6607\",\"Anahawan\":\"6610\",\"Hinunangan\":\"6608\",\"Libagon\":\"6615\",\"Hinundayan\":\"6609\",\"Macrohon\":\"6601\",\"San Ricardo\":\"6617\",\"Tomas Oppus\":\"6605\"},\"Zamboanga del Norte\":{\"Sibutad\":\"7103\",\"Siayan\":\"7113\",\"Labason\":\"7117\",\"Kalawit\":\"7124\",\"Tampilisan\":\"7116\",\"Gutalac\":\"7118\",\"Baliguian\":\"7123\",\"Sibuco\":\"7122\",\"Salug\":\"7114\",\"Mutia\":\"7107\",\"Siocon\":\"7120\",\"Manukan\":\"7110\",\"Liloy\":\"7115\",\"Polanco\":\"7106\",\"Sindangan\":\"7112\"},\"Misamis Occidental\":{\"Baliangao\":\"7211\",\"Jimenez\":\"7204\",\"Aloran\":\"7206\",\"Bonifacio\":\"7215\",\"Panaon\":\"7205\",\"Sinacaban\":\"7203\",\"Lopez Jaena\":\"7208\",\"Sapang Dalaga\":\"7212\",\"Calamba\":\"7210\"},\"Bohol\":{\"Talibon\":\"6325\",\"Guindulman\":\"6310\",\"Bilar\":\"6317\",\"Baclayon\":\"6301\",\"Bien Unido\":\"6326\",\"Ubay\":\"6315\",\"Dauis\":\"6339\",\"Antequera\":\"6335\",\"Loboc\":\"6316\",\"Sikatuna\":\"6338\",\"Trinidad\":\"6324\",\"Tubigon\":\"6329\",\"Sierra Bullones\":\"6320\",\"Cortes\":\"6341\",\"Catigbian\":\"6343\",\"Candijay\":\"6312\",\"Dagohoy\":\"6322\",\"Jagna\":\"6308\",\"Garcia Hernandez\":\"6307\",\"Corella\":\"6337\",\"Duero\":\"6309\",\"Loon\":\"6327\",\"Panglao\":\"6340\",\"Dimiao\":\"6305\",\"Alburquerque\":\"6302\",\"Sevilla\":\"6347\",\"Danao\":\"6344\",\"Maribojoc\":\"6336\",\"Lila\":\"6304\",\"Calape\":\"6328\",\"Balilihan\":\"6342\",\"Loay\":\"6202\"},\"Northern Samar\":{\"Mondragon\":\"6417\",\"Catubig\":\"6418\",\"Biri\":\"6410\",\"Bobon\":\"6401\",\"Lapinig\":\"6423\",\"Mapanas\":\"6412\",\"Palapag\":\"6421\",\"Allen\":\"6405\",\"Las Navas\":\"6420\",\"Capul\":\"6408\",\"Lavezares\":\"6404\",\"Laoang\":\"6411\",\"Silvino Lobos\":\"6414\",\"Gamay\":\"6422\",\"Pambujan\":\"6413\"},\"Batangas\":{\"Malvar\":\"4233\",\"Calatagan\":\"4215\",\"Ibaan\":\"4230\",\"Calaca\":\"4212\",\"Nasugbu\":\"4231\",\"Balayan\":\"4213\",\"Lobo\":\"4229\",\"Padre Garcia\":\"4224\",\"Taal\":\"4208\",\"Agoncillo\":\"4211\",\"Laurel\":\"4221\",\"Cuenca\":\"4222\",\"Bauan\":\"4201\",\"Lian\":\"4216\",\"Taysan\":\"4228\",\"Tuy\":\"4214\",\"Alitagtag\":\"4205\",\"Batangas City\":\"4200\",\"Tingloy\":\"4203\"},\"NCR, 3rd district\":{\"Valenzuela\":\"1208\",\"Navotas\":\"1485\",\"Malabon\":\"1470\"},\"Apayao\":{\"Pudtol\":\"3812\",\"Calanasan\":\"3814\",\"Flora\":\"3810\",\"Santa Marcela\":\"3811\",\"Kabugao\":\"3809\",\"Conner\":\"3807\"},\"La Union\":{\"Bacnotan\":\"2515\",\"Caba\":\"2502\",\"Bangar\":\"2519\",\"San Gabriel\":\"2513\",\"Bagulin\":\"2512\",\"Bauang\":\"2501\",\"Balaoan\":\"2517\",\"Pugo\":\"2508\",\"Aringay\":\"2503\",\"Agoo\":\"2504\",\"Tubao\":\"2509\"},\"Camarines Norte\":{\"Labo\":\"4604\",\"Capalonga\":\"4607\",\"Basud\":\"4608\",\"Daet\":\"4600\",\"Vinzons\":\"4603\",\"Santa Elena\":\"4611\",\"Paracale\":\"4605\",\"Jose Panganiban\":\"4606\"},\"Nueva Vizcaya\":{\"Solano\":\"3709\",\"Kayapa\":\"3708\",\"Aritao\":\"3704\",\"Bambang\":\"3702\",\"Ambaguio\":\"3701\",\"Diadi\":\"3712\",\"Bagabag\":\"3711\",\"Kasibu\":\"3703\",\"Bayombong\":\"3700\"},\"Lanao del Norte\":{\"Pantar\":\"9218\",\"Baloi\":\"9217\",\"Salvador\":\"9212\",\"Lala\":\"9211\",\"Kapatagan\":\"9214\",\"Poona Piagapo\":\"9204\",\"Matungao\":\"9203\",\"Baroy\":\"9210\",\"Maigo\":\"9206\",\"Kauswagan\":\"9202\",\"Sapad\":\"9213\",\"Nunungan\":\"9216\",\"Munai\":\"9219\",\"Bacolod\":\"9205\",\"Pantao Ragat\":\"9208\",\"Linamon\":\"9201\"},\"Maguindanao\":{\"Buldon\":\"9615\",\"Matanog\":\"9613\",\"South Upi\":\"9603\",\"Barira\":\"9614\",\"Buluan\":\"9616\",\"Cotabato City\":\"9600\",\"Ampatuan\":\"9609\",\"Datu Paglas\":\"9617\",\"Pagalungan\":\"9610\"},\"Benguet\":{\"Sablan\":\"2614\",\"Bokod\":\"2605\",\"Itogon\":\"2604\",\"Bakun\":\"2610\",\"Mankayan\":\"2608\",\"Atok\":\"2612\",\"La Trinidad\":\"2601\",\"Kapangan\":\"2613\",\"Kibungan\":\"2611\",\"Tublay\":\"2615\",\"Kabayan\":\"2606\",\"Buguias\":\"2607\"},\"Catanduanes\":{\"Viga\":\"4805\",\"Gigmoto\":\"4804\",\"Bagamanoc\":\"4807\",\"Caramoran\":\"4808\",\"Virac\":\"4800\"},\"Surigao del Norte\":{\"Surigao City\":\"8400\",\"Mainit\":\"8407\",\"Dapa\":\"8417\",\"San Benito\":\"8423\",\"Bacuag\":\"8408\",\"Gigaquit\":\"8409\",\"Del Carmen\":\"8418\",\"Claver\":\"8410\"}}");
    public enum OperationType {
        DEPOSIT("存款"),
        WITHDRAW("取款"),
        XM("洗码"),
        GAME("进游戏");

        private String name;

        OperationType(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }
    }

    /**
     * ekyc 用户状态缓存key
     */
    public static final String RISK_EKYC_STATUS_KEY = "risk:ekyc:status:%s";
    //用户每日kyc尝试次数:loginName:dayNum
    public static final String RISK_EKYC_DAY_COUNT =  "risk:ekyc:day:count:%s:%s";
    /**
     * ekyc 用户初始化zoloz kyc  $loginName
     */
    //
    public static final String RISK_EKYC_INIT_KEY =  "risk:ekyc:init:%s";
    /**
     *  用户黑名单状态缓存key
     */
    public static final String RISK_IS_BLACK_KEY = "risk:black:%s";

    /**
     * 用户黑名单设备指纹key*
     */
    public static final String RISK_DEVICE_KEY = "risk:device:%s";

    /**
     * 用户注册的用户名key*, 值是ip+设备指纹
     */
    public static final String RISK_REGISTER_LOGIN_NAME_KEY = "risk:register:%s";

    /**
     * 合法用户年龄*
     */
    public static final int VALIDATE_AGE = 21;

}
