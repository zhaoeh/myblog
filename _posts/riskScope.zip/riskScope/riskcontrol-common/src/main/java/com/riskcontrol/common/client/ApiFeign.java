package com.riskcontrol.common.client;

import com.cn.schema.customers.WSCustomers;
import com.cn.schema.customers.WSKycSheetRequest;
import com.riskcontrol.common.config.CustomizedFeignConfiguration;
import com.riskcontrol.common.entity.request.ApiQueryCustomersRequest;
import com.riskcontrol.common.entity.request.QueryPageByKycRequestId;
import com.riskcontrol.common.entity.request.api.QueryKycRequestReq;
import com.riskcontrol.common.entity.request.api.UpdateKycRequestReq;
import com.riskcontrol.common.entity.request.kyc.WSKycRequestGw;
import com.riskcontrol.common.entity.response.PageModel;
import com.riskcontrol.common.entity.response.Response;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

/**
 * @program: riskcontrol-common
 * @description: risk api feign
 * @author: Erhu.Zhao
 * @create: 2023-11-21 16:33
 */
@FeignClient(name = "riskcontrol-api", contextId = "risk-api-api", configuration = CustomizedFeignConfiguration.class)
public interface ApiFeign {
    /**
     * 查询kyc
     *
     * @param request kyc request of query
     * @return query result
     */
    @PostMapping(value = "customer/loadCustomers")
    Response<List<WSCustomers>> loadCustomersFromRiskApi(ApiQueryCustomersRequest request);

    @PostMapping(value = "customer/uploadPBCInfoBatch", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    Response uploadPBCInfoBatchNew(@RequestParam Map<String, String> req, @RequestPart("file") MultipartFile file);

    @PostMapping(value = "customer/approveKYCInfo")
    Response approveKYCInfo(@RequestBody UpdateKycRequestReq req);

    @PostMapping(value = "customer/approvePBCInfo")
    Response approvePBCInfo(@RequestBody UpdateKycRequestReq req);

    @PostMapping(value = "customer/queryPageByKycRequestId")
    Response queryPageByKycRequestId(@RequestBody QueryPageByKycRequestId req);

    @PostMapping(value = "customer/queryKycRequests")
    Response<PageModel<WSKycRequestGw>> queryKycRequests(@RequestBody QueryKycRequestReq req);

    @PostMapping(value = "customer/queryKycSheetRequests")
    Response<PageModel<WSKycSheetRequest>> queryKycSheetRequests(@RequestBody QueryKycRequestReq req);

}