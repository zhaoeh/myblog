package com.riskcontrol.common.entity.device;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("t_risk_action_device_info")
public class RiskActionDeviceInfo {

    /**
     * 主键
     */
    @TableId
    private Long id;

    /**
     * 设备指纹
     */
    @TableField("token")
    private String token;

    /**
     * 设备指纹
     */
    @TableField("const_id")
    private String constId;

    /**
     * 设备类型
     */
    @TableField(value = "device_type", fill = FieldFill.INSERT)
    private String deviceType;

    /**
     * 是否禁用cookie
     */
    @TableField("is_cook_enable")
    private String isCookEnable;

    /**
     * 是否存在调试风险
     */
    @TableField("is_debug")
    private String isDebug;

    /**
     * 是否存在内存dump风险
     */
    @TableField("is_dump")
    private String isDump;

    /**
     * 模拟器运行
     */
    @TableField("is_emulator")
    private String isEmulator;

    /**
     * 是否有Janus漏洞
     */
    @TableField("is_flaw_janus")
    private String isFlawJanus;

    /**
     * 是否存在hook风险
     */
    @TableField("is_hook")
    private String isHook;

    /**
     * 是否存在注入风险
     */
    @TableField("is_inject")
    private String isInject;

    /**
     * 是否越狱
     */
    @TableField("is_jailbreak")
    private String isJailbreak;

    /**
     * 是否伪造浏览器
     */
    @TableField("is_lied_browser")
    private String isLiedBrowser;

    /**
     * 是否多开
     */
    @TableField("is_multirun")
    private String isMultirun;

    /**
     * 是否使用代理
     */
    @TableField("is_proxy")
    private String isProxy;

    /**
     * 是否root
     */
    @TableField("is_root")
    private String isRoot;

    /**
     * 是否篡改浏览器颜色深度
     */
    @TableField("is_tamper_cd")
    private String isTamperCd;

    /**
     * 是否篡改分辨率
     */
    @TableField("is_tamper_res")
    private String isTamperRes;

    /**
     * 是否篡改浏览器ua
     */
    @TableField("is_tamper_ua")
    private String isTamperUa;

    /**
     * 是否使用vpn
     */
    @TableField("is_vpn")
    private String isVpn;

    /**
     * mac地址
     */
    @TableField("mac_address")
    private String macAddress;

    /**
     * 操作系统
     */
    @TableField("os_type")
    private String osType;

    /**
     * 操作系统版本
     */
    @TableField("os_version")
    private String osVersion;

    /**
     * 生产厂商
     */
    @TableField("producter")
    private String producter;

    /**
     * 设备评分
     */
    @TableField("score")
    private String score;

    /**
     * 无线网名称
     */
    @TableField("wifi_ssid")
    private String wifiSsid;

    /**
     * 创建时间
     */
    @TableField("create_date")
    private String createDate;

    /**
     * 更新时间
     */
    @TableField("update_date")
    private String updateDate;
}
