package com.riskcontrol.common.entity.request.ekyc;

import com.riskcontrol.common.annotation.Query;
import com.riskcontrol.common.constants.SQLConstants;
import com.riskcontrol.common.entity.request.BasePageRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Heng.zhang
 */
@Data
@ApiModel(value = "Ekyc申请表分页查询", description = "Ekyc申请表分页查询")
public class EkycRequestQueryRequest extends BasePageRequest {
    @ApiModelProperty("createdDate Begin")
    @Query(field = "create_date", mt = SQLConstants.Query.GE)
    private String dateBegin;

    @ApiModelProperty("createdDate End")
    @Query(field = "create_date", mt = SQLConstants.Query.LE)
    private String dateEnd;

    @ApiModelProperty("status")
    private Integer status;

    @ApiModelProperty("账号")
    @Query(field = "loginName", mt = SQLConstants.Query.LIKE)
    private String account;

    @ApiModelProperty("产品")
    @Query
    private String tenant;

    @ApiModelProperty("账单号")
    @Query
    private String billNo;

    @ApiModelProperty("名字")
    @Query(mt = SQLConstants.Query.LIKE_RIGHT)
    private String firstName;

    @ApiModelProperty("中间名")
    @Query(mt = SQLConstants.Query.LIKE_RIGHT)
    private String middleName;

    @ApiModelProperty("姓")
    @Query(mt = SQLConstants.Query.LIKE_RIGHT)
    private String lastName;

    @ApiModelProperty("channelId")
    @Query
    private String channelId;

    @ApiModelProperty("拒绝原因")
    @Query
    private String rejectReason;

}
