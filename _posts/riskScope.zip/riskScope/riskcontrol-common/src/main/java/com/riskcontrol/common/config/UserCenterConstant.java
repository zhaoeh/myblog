package com.riskcontrol.common.config;

import cn.hutool.core.util.StrUtil;
import com.riskcontrol.common.constants.Constant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @program: riskcontrol-api
 * @description: 从user-center服务 获取常量
 * @author: Colson
 * @create: 2023-10-06 15:44
 */
@Component
@Slf4j
public class UserCenterConstant {

    @Resource
    private C66Config c66Config;



    public String getConstantValue(String key) {
        // 目前只是用nacos配置
        log.info("getConstantValue key={}", key);
        String value = getNacosConfigByKey(key);
        log.info("getConstantValue key={}, value={}", key, value);
        return value;
    }

    private String getNacosConfigByKey(String key) {
        String value = "";
        if (StrUtil.equals(Constant.USER_CENTER_CALL_SWITCH, key)) {
            value = c66Config.getUserCenterCallSwitch();
        } else if (StrUtil.equals(Constant.CREATE_REAL_CUSTOMER_CHECK_EMAIL, key)) {
            value = c66Config.getCreateRealCustomerCheckEmail();
        } else if (StrUtil.equals(Constant.X2_KEY, key)) {
            value = c66Config.getX2Key();
        } else if (StrUtil.equals(Constant.X3_KEY, key)) {
            value = c66Config.getX3Key();
        } else if (StrUtil.equals(Constant.CURRENT_ENVIRONMENT, key)) {
            value = c66Config.getCurrentEnvironment();
        } else if (StrUtil.equals(Constant.USER_CENTER_SERVER_NODE, key)) {
            value = c66Config.getUserCenterServerNode();
        } else if (StrUtil.equals(Constant.PRODUCT_TYPE_01, key) || StrUtil.equals(Constant.PRODUCT_TYPE_02, key)
                || StrUtil.equals(Constant.PRODUCT_TYPE_03, key) || StrUtil.equals(Constant.PRODUCT_TYPE_04, key)
                || StrUtil.equals(Constant.PRODUCT_TYPE_05, key) || StrUtil.equals(Constant.PRODUCT_TYPE_06, key)
                || StrUtil.equals(Constant.PRODUCT_TYPE_07, key) || StrUtil.equals(Constant.PRODUCT_TYPE_08, key)) {
            value = getProductTypeValue(key);
        }
        return value;
    }

    private String getProductTypeValue(String key) {
        Map<String, String> publicKeyMap = Arrays.stream(c66Config.getProductKey()
                        .split(Constant.COMMA_SYMBOL))
                .collect(Collectors.toMap(p -> p.split("-")[0], p -> p.split("-")[1]));
        log.info("getProductTypeValue publicKeyMap={}", publicKeyMap);
        return publicKeyMap.get(key);
    }

}
