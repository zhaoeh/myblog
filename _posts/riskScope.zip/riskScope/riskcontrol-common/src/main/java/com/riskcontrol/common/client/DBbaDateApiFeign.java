
package com.riskcontrol.common.client;

import com.alibaba.fastjson.JSONObject;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * @program: riskcontrol-common
 * @description: 大数据 api服务
 * @author: dante
 * @create: 2024-08-07 13:33
 */
@FeignClient(name = "bd-ba-data-api")
public interface DBbaDateApiFeign {
    /**
     * 根据时间、用户名查询 查询玩家总存款
     * @param req
     * @return
     */
    @PostMapping(value = "/risk_management/user_deposit")
    JSONObject getPlayerTotalDeposit(@RequestBody JSONObject req);
}