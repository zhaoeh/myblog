package com.riskcontrol.common.entity.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.math.BigInteger;

/**
 * @description: ekyc证件号码实体
 * @author: ErHu.Zhao
 * @create: 2024-10-08
 **/
@TableName(value = "t_ekyc_deduplicate")
@Data
public class EkycDeduplicate {

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private BigInteger id;

    /**
     * 证件类型*
     */
    private Integer idType;

    /**
     * 证件号码*
     */
    private String idNo;

    /**
     * 使用该证件的用户名，多个";"分隔）*
     */
    private String loginName;
}
