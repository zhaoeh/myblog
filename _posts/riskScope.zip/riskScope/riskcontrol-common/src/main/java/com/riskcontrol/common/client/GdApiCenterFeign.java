package com.riskcontrol.common.client;

import com.alibaba.fastjson.JSONObject;
import com.gw.datacenter.vo.order.OrderReq;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @Description: gd 数据中心使用feign调用
 * @Auther: sanji
 * @create: 2023-09-04
 */
@FeignClient(name = "c66-gd-api")
public interface GdApiCenterFeign {
    @PostMapping(value = "/dcApi/dataCenter/getOrderSummaryNewByLoginName")
    JSONObject getOrderSummaryNewByLoginName(@RequestBody JSONObject orderReq);

    @PostMapping(value = "/dcApi/dataCenter/getCountTotalStrRecordAndSummaryV2")
    JSONObject getCountTotalStrRecordAndSummaryV2(@RequestBody JSONObject orderReq);
}
