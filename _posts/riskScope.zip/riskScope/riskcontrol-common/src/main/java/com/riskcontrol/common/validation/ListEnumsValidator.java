package com.riskcontrol.common.validation;

import com.riskcontrol.common.annotation.ListEnumValid;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.util.PropertyPlaceholderHelper;
import org.springframework.util.ReflectionUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.lang.reflect.Field;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @description: 关联校验指定枚举
 * @author: ErHu.Zhao
 * @create: 2024-09-24
 **/
public class ListEnumsValidator implements ConstraintValidator<ListEnumValid, List<?>> {

    PropertyPlaceholderHelper placeholderHelper = new PropertyPlaceholderHelper("{", "}");

    private ListEnumValid enumValid;

    @Override
    public void initialize(ListEnumValid constraintAnnotation) {
        enumValid = constraintAnnotation;
    }

    @Override
    public boolean isValid(List<?> targets, ConstraintValidatorContext context) {
        // 空list认为合法
        if (Objects.isNull(targets)) {
            return true;
        }
        final List<MessagesPlace> result = new ArrayList<>();
        valid(targets, result);
        return isValid(context, result);
    }


    private MessagesPlace handleRangeMessage(ListEnumValid enums, List<String> enumsValues) {
        String message = StringUtils.isNotBlank(enums.message()) ? enums.message() : "current collection must belong to {target}";
        return MessagesPlace.builder().message(message).places(Map.of("target", enumsValues)).build();
    }


    private boolean isValid(ConstraintValidatorContext context, final List<MessagesPlace> result) {
        if (result.size() > 0) {
            MessagesPlace message = result.get(0);
            if (Objects.nonNull(message)) {
                // 禁用默认message
                context.disableDefaultConstraintViolation();
                context.buildConstraintViolationWithTemplate(placeholderHelper.replacePlaceholders(message.getMessage(),
                        s -> {
                            Map<Object, Object> places = message.getPlaces();
                            if (CollectionUtils.isEmpty(places)) {
                                return s;
                            } else {
                                return Objects.toString(places.get(s));
                            }
                        })).addConstraintViolation();
            }
            return false;
        }
        return true;
    }

    private void valid(List<?> targets, List<MessagesPlace> result) {
        isReject(targets, result, enumValid);
    }


    public void isReject(List<?> targets, List<MessagesPlace> result, ListEnumValid enums) {
        Optional.ofNullable(enums).ifPresent(ens -> {
            Class<?> enumClass = ens.enumClass();
            String enumFiled = ens.enumField();
            if (enumClass.isEnum()) {
                Field f = ReflectionUtils.findField(enumClass, enumFiled);
                ReflectionUtils.makeAccessible(f);
                // 获取所有枚举常量对象
                Object[] objects = enumClass.getEnumConstants();
                if (Objects.isNull(objects)) {
                    result.add(handleRangeMessage(enums, Collections.emptyList()));
                    return;
                }
                int[] indexes = ens.enumIndexes();
                List<Object> targetObjects = obtainExpects(Arrays.asList(objects), indexes);
                List<String> enumsValues = targetObjects.stream().map(ev -> Objects.toString(ReflectionUtils.getField(f, ev))).collect(Collectors.toList());
                List<String> targetEnumsValues = enumsValues.stream().distinct().collect(Collectors.toList());
                // 目标集合中的元素是否都包含在枚举中
                boolean isContains = targets.stream().map(Object::toString).allMatch(targetEnumsValues::contains);

                // 存在枚举之外的值，则校验失败
                if (!isContains) {
                    result.add(handleRangeMessage(enums, enums.deduplicateEnumField() ? targetEnumsValues : enumsValues));
                }
            }
        });
    }

    private List<Object> obtainExpects(List<Object> objects, int[] indexes) {
        if (Objects.nonNull(objects) && Objects.nonNull(indexes) && indexes.length > 0) {
            List<Object> targets = new ArrayList<>();
            for (int i = 0; i < indexes.length; i++) {
                targets.add(objects.get(indexes[i]));
            }
            return targets;
        }
        return objects;
    }
}
