package com.riskcontrol.common.enums;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

/**
 * 拦截类型(0:通过, 1:ip, 2:设备指纹, 3:ip+设备指纹, 4:调用顶象异常)
 * @author Heng.zhang
 */
@AllArgsConstructor
@Getter
public enum RiskActionInterceptTypeEnum {
    PASS_THROUGH(0, "通过"),
    IP_BLOCK(1, "IP拦截"),
    DEVICE_BLOCK(2, "设备指纹拦截"),
    IP_DEVICE_BLOCK(3, "IP+设备指纹拦截"),
    DEVICE_ABNORMAL_THROUGH(4, "顶象异常通过"),
    WHITE_LIST_THROUGH(5, "白名单放行"),
    BLACK_LIST_BLOCK(6, "黑名单拦截"),
    ;
    private final int id;
    private final String name;

    /**
     * 获取所有的来源
     */
    public static List<InterceptType> getInterceptType(){
        return Arrays.stream(RiskActionInterceptTypeEnum.values()).map(x-> new RiskActionInterceptTypeEnum.InterceptType(x.id,x.name)).toList();
    }

    /**
     * 渠道返回对象
     */
    @AllArgsConstructor
    @Data
    public static class InterceptType implements Serializable {
        private static final long serialVersionUID = 1L;
        private final int id;
        private final String name;
    }
}
