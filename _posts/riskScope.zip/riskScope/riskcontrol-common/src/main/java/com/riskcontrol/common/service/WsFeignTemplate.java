package com.riskcontrol.common.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.nacos.common.utils.CollectionUtils;
import com.cn.schema.agent.QueryAgentTransRequest;
import com.cn.schema.agent.QueryAgentTransResponse;
import com.cn.schema.agent.WSQueryAgentTrans;
import com.cn.schema.customers.*;
import com.cn.schema.products.*;
import com.cn.schema.request.*;
import com.cn.schema.urf.*;
import com.github.xiaoymin.knife4j.core.util.StrUtil;
import com.google.common.collect.Lists;
import com.riskcontrol.common.client.UserCenterFeign;
import com.riskcontrol.common.client.WSFeign;
import com.riskcontrol.common.config.UserCenterSwitch;
import com.riskcontrol.common.config.WsCommonConfig;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.request.ApiQueryCustomersRequest;
import com.riskcontrol.common.entity.request.BaseReq;
import com.riskcontrol.common.entity.request.QueryPageByKycRequestId;
import com.riskcontrol.common.entity.request.kyc.CustomerOcrCardReq;
import com.riskcontrol.common.entity.request.kyc.KycDispatchConfirmReq;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Stream;


@Slf4j
@Component
public class WsFeignTemplate {

    @Resource
    private WSFeign wsFeign;


    @Resource
    private WsCommonConfig wsCommonConfig;
    @Resource
    private UserCenterFeign usFeign;


    /**
     * C66 新增玩家人脸信息
     *
     * @param wsCustomerFace <pre>
     */
    public CreateCustomerFaceResponse createCustomerFace(WSCustomerFace wsCustomerFace) {
        try {
            CreateCustomerFaceRequest request = new CreateCustomerFaceRequest();
            request.setInfProductId(wsCommonConfig.getWsProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSCustomerFace(wsCustomerFace);
            log.info("createCustomerFace request={}", JSONObject.toJSONString(request));
            CreateCustomerFaceResponse response = feign().createCustomerFace(request);
            log.info("createCustomerFace response={}", JSONObject.toJSONString(response));
            return response;
        } catch (Exception ex) {
            log.error("调用WS接口异常，CreateCustomerFaceRequest错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public boolean bindMobileNoOrEmail(WSBond wsBond) {
        try {
            CreateBondRequest request = new CreateBondRequest();
            request.setInfProductId(wsCommonConfig.getWsProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSBond(wsBond);
            log.info("bindMobileNoOrEmail request={}", JSONObject.toJSONString(request));
            CreateBondResponse response = wsFeign.bondCreate(request);
            log.info("bindMobileNoOrEmail response={}", response);
            return Optional.ofNullable(response).map(r -> parseWSResponse(r.getResult())).orElse(false);
        } catch (Exception ex) {
            log.error("调用WS接口异常，CreateBondResponse错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    /**
     * 通过解析字符串类型WS返回结果，确定对WS的调用是否成功
     *
     * @param response WS返回的字符串类型的response; 如果成功，其格式统一为 <b>SUCCESS^中文描述信息^关键信息(如新建提案的提案号)</b>
     * @return 调用WS是否成功
     */
    private boolean parseWSResponse(String response) {
        if (StringUtils.isBlank(response)) {
            return false;
        }
        return response.startsWith(Constant.WS_RESPONSE_SUCCESS);
    }


    public QueryKycRequestResponse queryKycRequest(WSQueryKycRequest query, String productId) {
        try {
            QueryKycRequestRequest request = new QueryKycRequestRequest();
            request.setInfProductId(wsCommonConfig.getWsProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setParams(query);
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
            log.info("queryKycRequest request={}", JSON.toJSONString(request));
            QueryKycRequestResponse response = feign().queryKycRequest(request);
            log.info("queryKycRequest response={}", JSON.toJSONString(response));
            return response;
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryKycRequest 错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public CreateKycRequestResponse addKycRequest(WSKycRequest cid, String productId) {
        try {

            CreateKycRequestRequest request = new CreateKycRequestRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWsKycRequest(cid);
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
            log.info("addKycRequest request={}", JSONObject.toJSONString(request));
            CreateKycRequestResponse response = feign().addKycRequest(request);
            log.info("addKycRequest response={}", JSONObject.toJSONString(response));
            return response;
        } catch (Exception ex) {
            log.error("调用WS接口异常，CreateKycRequest 错误", ex);

            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }


    public WSCustomers getCustomerByLoginNameV2(String productId, String loginName) {
        try {
            QueryCustomersBasicByLoginNameRequestV2 request = new QueryCustomersBasicByLoginNameRequestV2();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setLoginName(loginName);
            request.setHideSensitiveInfo(true);//隐藏微信号

            log.info("getCustomerByLoginNameV2 request={}", JSONObject.toJSONString(request));
            QueryCustomersBasicByLoginNameResponseV2 response = feign().getCustomerByLoginNameV2(request);
            log.info("getCustomerByLoginNameV2 response={}", JSONObject.toJSONString(response));
            if (null == response || null == response.getWsCustomer()) {
                return null;
            } else {
                return response.getWsCustomer();
            }
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryCustomersBasicByLoginNameResponse错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }


    public QueryBranchResponse queryBranchList(String productId, WSQueryBranch query) {
        try {
            QueryBranchRequest request = new QueryBranchRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setParams(query);
            log.info("queryBranchList request={}", JSONObject.toJSONString(request));
            QueryBranchResponse response = wsFeign.queryBranchList(request);
            log.info("queryBranchList response={}", JSONObject.toJSONString(response));
            return response;
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryBranchRequest", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    //校验用户信息
    public WSCustomers checkCustomerV2(WSQueryCustomers wsQueryCustomers, String infFlag, String productId) {
        try {
            CheckCustomerInfoRequestV2 request = new CheckCustomerInfoRequestV2();
            request.setInfProductId(wsQueryCustomers.getProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setInfFlag(infFlag);
            request.setWSQueryCustomers(wsQueryCustomers);
            log.info("checkCustomerV2 request={}", JSONObject.toJSONString(request));
            CheckCustomerInfoResponseV2 r9 = feign().checkCustomerV2(request);
            log.info("checkCustomerV2 response={}", r9);

            if (Objects.isNull(r9) || Objects.isNull(r9.getWSCustomers())) {
                return null;
            }
            return r9.getWSCustomers();
        } catch (Exception ex) {
            log.error("调用WS接口异常，CheckCustomerInfoResponse错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }


    public int queryCountBondRequest(WSQueryBondRequests wsQueryBondRequest) {
        try {
            QueryCountBondRequest request = new QueryCountBondRequest();
            request.setInfProductId(wsQueryBondRequest.getProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSQueryBondRequests(wsQueryBondRequest);
            log.info("queryCountBondRequest request={}", JSONObject.toJSONString(request));
            QueryCountBondResponse response = wsFeign.queryCountBondRequest(request);
            log.info("queryCountBondRequest response={}", JSONObject.toJSONString(response));
            return response.getCount();
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryCountBondResponse错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public WSCustomers getCustomerById(String productId, String customerId) {
        try {
            QueryCustomersBasicByIdRequest request = new QueryCustomersBasicByIdRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setCustomerId(customerId);
            request.setHideSensitiveInfo(true);//隐藏敏感信息
            log.info("getCustomerById request={}", JSONObject.toJSONString(request));
            QueryCustomersBasicByLoginNameResponseV2 response = feign().getCustomerById(request);
            log.info("getCustomerById response={}", JSONObject.toJSONString(response));
            if (null == response || null == response.getWsCustomer()) {
                return null;
            } else {
                return response.getWsCustomer();
            }
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryCustomersBasicByLoginNameResponse错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public List<WSBond> queryBondRequest(WSQueryBondRequests wsQueryBondRequest) {
        try {
            QueryBondRequest request = new QueryBondRequest();
            //Todo WIN-6929此接口只查询单产品绑定情况
            request.setInfProductId(wsQueryBondRequest.getProductId());

            // 國際化項目改造, 此接口ws支持多產品查詢
//            if (StringUtils.isNotBlank(Product.getMultiProductConvertIds())) {
//                request.setInfProductId(Product.getMultiProductConvertIds().contains(wsQueryBondRequest.getProductId()) ? Product.getMultiProductConvertIds() : wsQueryBondRequest.getProductId());
//            } else {
//                request.setInfProductId(wsQueryBondRequest.getProductId());
//            }
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSQueryBondRequests(wsQueryBondRequest);
            log.info("queryBondRequest request={}", JSONObject.toJSONString(request));
            QueryBondResponse response = feign().queryBondRequest(request);
            log.info("queryBondRequest response={}", JSONObject.toJSONString(response));
            return response.getWSBond();
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryBondResponse错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public boolean checkOcrIdentify(CustomerOcrCardReq req) {
        try {
            CheckOcrIdentifyRequest request = new CheckOcrIdentifyRequest();
            request.setInfProductId(req.getProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            BeanUtils.copyProperties(req, request);
            log.info("checkOcrIdentify request={}", JSONObject.toJSONString(request));
            CheckOcrIdentifyResponse response = feign().checkOcrIdentify(request);
            log.info("checkOcrIdentify response={}", JSONObject.toJSONString(response));
            return response.isHashUnanimous();
        } catch (Exception ex) {
            log.error("调用WS接口异常，checkOcrIdentify 错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    /**
     * C68 完善玩家信息
     *
     * @param wsCustomer
     * @return
     */
    public WSCustomers completeCustomer(WSCustomers wsCustomer) {
        try {
            CompleteAccountRequest request = new CompleteAccountRequest();
            request.setInfProductId(wsCustomer.getProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSCustomers(wsCustomer);
            log.info("completeCustomer request={}", JSONObject.toJSONString(request));
            CompleteAccountResponse response = feign().completeCustomer(request);
            log.info("completeCustomer response={}", JSONObject.toJSONString(response));
            return response.getWSCustomers();
        } catch (Exception ex) {
            log.error("调用WS接口异常，CreateCustomerRequest错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public OcrIdentify saveOcrIdentify(CustomerOcrCardReq req) {
        try {
            CreateOcrIdentifyRequest request = new CreateOcrIdentifyRequest();
            request.setInfProductId(req.getProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            BeanUtils.copyProperties(req, request);
            log.info("saveOcrIdentify request={}", JSONObject.toJSONString(request));
            CreateOcrIdentifyResponse response = feign().saveOcrIdentify(request);
            log.info("saveOcrIdentify response={}", JSONObject.toJSONString(response));
            return response.getOcrIdentify();
        } catch (Exception ex) {
            log.error("调用WS接口异常，saveOcrIdentify错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }

    }


    public WSCustomers getCustomerByLoginName(String productId, String loginName) {
        try {
            QueryCustomersBasicByLoginNameRequest request = new QueryCustomersBasicByLoginNameRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setLoginName(loginName);
            request.setHideSensitiveInfo(true);//隐藏微信号
            log.info("getCustomerByLoginName request={}", JSONObject.toJSONString(request));
            QueryCustomersBasicByLoginNameResponse response = feign().getSimpleCustomerByLoginName(request);
            log.info("getCustomerByLoginName response={}", JSONObject.toJSONString(response));
            if (CollectionUtils.isEmpty(response.getWsCustomers())) {
                return null;
            } else {
                return response.getWsCustomers().get(0);
            }
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryCustomersBasicByLoginNameResponse错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }


    public WSCustomers getSimpleCustomer(QueryCustomersBasicByLoginNameRequestV3 request) {
        try {
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            log.info("getSimpleCustomer request={}", JSONObject.toJSONString(request));
            QueryCustomersBasicByLoginNameResponseV3 response = feign().getSimpleCustomerByLoginNameV3(request);
            log.info("getSimpleCustomer response={}", JSONObject.toJSONString(response));
            return response.getWsCustomer();
        } catch (Exception ex) {
            log.error("调用WS接口异常，getCustomerByLoginNameV3 错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public ModifyAccountResponse modifyAccount(WSCustomers wsCustomers, String infFlag) {
        String errorMessage = "";
        try {
            // 刷新有效门店
            refreshBranchCode(wsCustomers);
            ModifyAccountRequest request = new ModifyAccountRequest();
            request.setInfProductId(wsCustomers.getProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSCustomers(wsCustomers);
            request.setInfFlag(infFlag);
            log.info("modifyAccount request={}", JSONObject.toJSONString(request));
            ModifyAccountResponse response = wsFeign.modifyAccount(request);
            log.info("modifyAccount response={}", JSONObject.toJSONString(response));
            if (StringUtils.isNotBlank(response.getWsErrorMsg())) {
                errorMessage = response.getWsErrorMsg();
            }
            return response;
        } catch (Exception ex) {
            log.error("调用WS接口异常，ModifyAccountRequest错误", ex);
            if (StrUtil.isBlank(errorMessage)) {
                throw new BusinessException(ResultEnum.WS_EXCEPTION);
            } else {
                throw new BusinessException("49999",errorMessage);
            }
        }
    }


    public ModifyKycRequestResponse updateKycRequest(WSKycRequest cid, String productId) {
        try {
            UpdateKycRequestRequest request = new UpdateKycRequestRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWsKycRequest(cid);
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
            log.info("updateKycRequest request={}", JSON.toJSONString(request));
            ModifyKycRequestResponse response = feign().updateKycRequest(request);
            log.info("updateKycRequest response={}", JSON.toJSONString(response));
            return response;
        } catch (Exception ex) {
            log.error("调用WS接口异常，updateKycRequest 错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public BatchActivateSuspendResponse queryUserByFunction(WSQueryFunctions wsQueryFunctions, String productId) {
        try {
            QueryFunctionsRolesRequest request = new QueryFunctionsRolesRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setParams(wsQueryFunctions);
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
            log.info("queryUserByFunction request={}", JSONObject.toJSONString(request));
            BatchActivateSuspendResponse response = wsFeign.queryUserByFunction(request);
            log.info("queryUserByFunction response={}", JSONObject.toJSONString(response));
            return response;
        } catch (Exception ex) {
            log.error("调用WS接口异常，queryUserByFunction 错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public ModifyKycRequestResponse pbcDispatch(WSKycRequest cid, String productId) {
        try {

            UpdateKycRequestRequest request = new UpdateKycRequestRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWsKycRequest(cid);
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
            log.info("pbcDispatch request={}", JSONObject.toJSONString(request));
            ModifyKycRequestResponse response = feign().pbcDispatch(request);
            log.info("pbcDispatch response={}", JSONObject.toJSONString(response));
            return response;
        } catch (Exception ex) {
            log.error("调用WS接口异常，pbcDispatch 错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }


    public List<WSCustomers> queryCustomers(WSQueryCustomers wsQueryCustomer) {
        try {
            QueryCustomersRequest request = new QueryCustomersRequest();
            request.setInfProductId(wsQueryCustomer.getProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSQueryCustomers(wsQueryCustomer);
            log.info("queryCustomers request={}", JSONObject.toJSONString(request));
            QueryCustomersResponse response = feign().queryCustomers(request);
            if (CollectionUtils.isEmpty(response.getWSCustomers())) {
                return Lists.newArrayList();
            }
            return response.getWSCustomers();
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryCustomersResponse错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }


    public ModifyCustomerFaceResponse updateCustomerFace(WSCustomerFace wsCustomerFace) {
        try {
            ModifyCustomerFaceRequest request = new ModifyCustomerFaceRequest();
            request.setInfProductId(wsCustomerFace.getProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSCustomerFace(wsCustomerFace);
            log.info("updateCustomerFace request={}", JSONObject.toJSONString(request));
            ModifyCustomerFaceResponse response = feign().updateCustomerFace(request);
            log.info("updateCustomerFace response={}", JSONObject.toJSONString(response));
            return response;
        } catch (Exception ex) {
            log.error("调用WS接口异常，updateCustomerFace错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public WSCustomersRemarks createCustomerRemark(WSCustomersRemarks customerRemark) {
        try {
            CreateCustomersRemarksRequest request = new CreateCustomersRemarksRequest();
            request.setInfProductId(customerRemark.getProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSCustomersRemarks(customerRemark);
            log.info("createCustomerRemark request={}", JSONObject.toJSONString(request));
            CreateCustomersRemarksResponse response = feign().createCustomerRemark(request);
            log.info("createCustomerRemark response={}", JSONObject.toJSONString(response));
            return response.getWSCustomersRemarks();
        } catch (Exception ex) {
            log.error("调用WS接口异常，createCustomerRemark错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public int countKycRequest(WSQueryKycRequest query, String productId) {
        try {
            QueryKycRequestRequest request = new QueryKycRequestRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setParams(query);
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
            log.info("countKycRequest request={}", JSON.toJSONString(request));
            int count = feign().countKycRequest(request).getCount();
            log.info("countKycRequest response={}", count);
            return count;
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryKycRequest 错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    /**
     * 风控API WS开关*
     *
     * @return false:查询ws,true:查询风控系统
     */
//    public Boolean getRiskApiWsSwitch() {
//        WSProductConstants constants = getProductConstants(Constants.PRODUCT_ID, Constants.P_TYPE, Constants.APPROVE_KYC_RISK_CONTROL_SWITCH);
//        log.info("getRiskApiWsSwitch response={}", JSON.toJSONString(constants));
//        if (constants == null) {//如果数据库查询是null得话，默认走老得代码逻辑
//            return false;
//        }
//        if (StrUtil.equals(Constants.TWO_STR, constants.getValue())) {//常量值为Constants.TWO_STR得时候才走 风控系统逻辑，其他情况都默认走老的逻辑
//            return true;
//        } else {
//            return false;
//        }
//    }

    public QueryKycSheetListRequestResponse queryKycSheetRequest(WSQueryKycRequest query) {
        try {

            QueryKycRequestRequest request = new QueryKycRequestRequest();
            request.setInfProductId(query.getProductId());
            request.setParams(query);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));

            return feign().queryKycSheetRequest(request);

        } catch (Exception ex) {
            log.error("调用WS接口异常，/rest/customers/kyc_request/queryKycSheetList 错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }

    }

    public int countKycPbcRequest(WSQueryKycRequest query, String productId) {

        try {

            QueryKycRequestRequest request = new QueryKycRequestRequest();
            request.setInfProductId(query.getProductId());
            request.setParams(query);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));

            return feign().countKycPbcRequest(request).getCount();

        } catch (Exception ex) {
            log.error("调用WS接口异常，/rest/customers/kyc_request/queryKycSheetList 错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }


    public ModifyKycRequestResponse pbcModifyStatus(WSKycRequest wsKycRequest, String productId) {
        try {
            UpdateKycRequestRequest request = new UpdateKycRequestRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWsKycRequest(wsKycRequest);
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
            return feign().pbcModifyStatus(request);
        } catch (Exception ex) {
            log.error("调用WS接口异常，pbcModifyStatus 错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }


    public BatchModifyPbcRequestResponse bactchModifyPbcStatus(List<WSKycSheetRequest> kycSheetList, String productId, String operator) {
        try {
            BatchUpdateKycRequestRequest request = new BatchUpdateKycRequestRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWsKycSheetRequestList(kycSheetList);
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));
            return feign().bactchModifyPbcStatus(request);

        } catch (Exception ex) {
            log.error("调用WS接口异常，pbcModifyStatus 错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }

    }

    public QueryKycRequestProcessLogResponse queryPageByKycRequestId(QueryPageByKycRequestId req) {
        try {

            UpdateKycRequestRequest request = new UpdateKycRequestRequest();
            request.setInfProductId(req.getProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            WSKycRequest wsKycRequest = new WSKycRequest();
            wsKycRequest.setId(req.getId());
            request.setWsKycRequest(wsKycRequest);
            request.setRequestUUID(UUID.randomUUID().toString().replaceAll("-", ""));

            return feign().queryPageByKycRequestId(request);

        } catch (Exception ex) {
            log.error("调用WS接口异常，queryPageByKycRequestId 错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    /**
     * 查询等待审核的订单数
     *
     * @param request
     * @return
     */
    public QueryCountResponse queryKycRequestPendingCount(BaseReq request) {
        try {
            WSKycRequest kycRequest = new WSKycRequest();
            kycRequest.setLoginName(request.getLoginName());
            log.info("queryKycRequestPendingCount 查询ws系统 kyc信息，入参 {}", JSONObject.toJSONString(kycRequest));
            return feign().queryWaitPendingCount(kycRequest);
        } catch (Exception ex) {
            log.error("调用WS接口异常，queryKycRequestPendingCount", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public List<WSKycRequest> dispatchKycRequest(BaseReq request) {
        try {
            log.info("dispatchKycRequest 查询ws系统，入参 {}",JSONObject.toJSONString(request));
            WSKycRequest kycRequest = new WSKycRequest();
            kycRequest.setLoginName(request.getLoginName());
            return Optional.ofNullable(feign().dispatch(kycRequest)).map(response -> response.getData()).orElse(Collections.emptyList());
        } catch (Exception ex) {
            log.error("调用WS接口异常，dispatchKycRequest", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public QueryUserLastWorkingStatusResponse querLastWorkingStatus(QueryUserLastWorkingStatusRequest req) {
        try {
            req.setInfPwd(wsCommonConfig.getWsProductPwd());
            return wsFeign.querLastWorkingStatus(req);
        } catch (Exception ex) {
            log.error("调用WS接口异常，querLastWorkingStatus", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public Boolean dispatchWithdrawalCancel(BaseReq request) {
        try {
            WSWithdrawalRequests wsWithdrawalRequests = new WSWithdrawalRequests();
            wsWithdrawalRequests.setLoginName(request.getLoginName());
            return Optional.ofNullable(wsFeign.dispatchWithdrawalCancel(wsWithdrawalRequests)).map(re -> re.getResult()).orElse(false);
        } catch (Exception ex) {
            log.error("调用WS接口异常，dispatchWithdrawalCancel", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public Boolean dispatchKycRequestCancel(BaseReq request) {
        try {
            WSKycRequest kycRequest = new WSKycRequest();
            kycRequest.setLoginName(request.getLoginName());
            return Optional.ofNullable(feign().dispatchCancel(kycRequest)).map(response -> response.getResult()).orElse(false);
        } catch (Exception ex) {
            log.error("调用WS接口异常，dispatchKycRequestCancel", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public Integer dispatchRequestPendingCount(BaseReq request) {
        try {
            WSDispatchRecord record = new WSDispatchRecord();
            record.setUserLoginName(request.getLoginName());
            return Optional.ofNullable(wsFeign.pendingCount(record)).map(result -> result.getCount()).orElse(0);
        } catch (Exception ex) {
            log.error("调用WS接口异常，dispatchRequestPendingCount", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public UpdateUserWorkingStatusResponse updateWorkingStatus(UpdateUserWorkingStatusRequest req) {
        try {
            req.setInfPwd(wsCommonConfig.getWsProductPwd());
            return wsFeign.updateWorkingStatus(req);
        } catch (Exception ex) {
            log.error("调用WS接口异常，updateWorkingStatus", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public Boolean checkDispatchConfirm(KycDispatchConfirmReq request) {
        ///rest/customers/kyc_request/checkDispatchConfirm
        KycDispatchConfirmRequest kycRequest = new KycDispatchConfirmRequest();
        kycRequest.setLoginName(request.getLoginName());
        kycRequest.setIds(request.getIds());

        KycDispatchConfirmResponse response = feign().checkDispatchConfirm(kycRequest);
        //
        return response.getResult();

    }

    public Boolean dispatchKycRequestConfirm(KycDispatchConfirmReq request) {

        KycDispatchConfirmRequest kycRequest = new KycDispatchConfirmRequest();
        kycRequest.setLoginName(request.getLoginName());
        kycRequest.setIds(request.getIds());

        KycDispatchConfirmResponse response = feign().dispatchKycRequestConfirm(kycRequest);
        return response.getResult();

    }

    public List<WSUsers> queryUserList(WSQueryUsers wsQueryUsers) {

        try {
            String productId = wsQueryUsers.getProductId();
            QueryUsersRequest request = new QueryUsersRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSQueryUsers(wsQueryUsers);
            log.info(" wsFeign.queryUserList request: {}", JSONObject.toJSONString(request));
            QueryUsersResponse response = wsFeign.queryUserList(request);
            log.info(" wsFeign.queryUserList response: {}", JSONObject.toJSONString(response));

            return response.getWSUsers();
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryUsersRequest", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    /**
     * 查询ws门店信息
     *
     * @param wsCustomers
     * @return
     */
    public QueryBranchResponse queryWsBranchList(WSCustomers wsCustomers) {
        try {
            String productId = wsCustomers.getProductId();
            QueryBranchRequest request = new QueryBranchRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            log.info("[queryWsBranchList method] wsFeign.queryWsBranchList request: {}", JSONObject.toJSONString(request));
            QueryBranchResponse response = wsFeign.queryWsBranchList(request);
            log.info("[queryWsBranchList method] wsFeign.queryWsBranchList response: {}", JSONObject.toJSONString(response));
            return response;
        } catch (Exception ex) {
            log.error("调用WS接口异常，queryWsBranchList", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    /**
     * 获取feign template
     *
     * @return feign client
     */
    private WSFeign feign() {
        return wsFeign;
    }

    /**
     * 从ws获取客户信息
     *
     * @param wsQueryCustomer 获取客户信息请求
     * @return 客户信息
     */
    public List<WSCustomers> queryCustomersBySingle(ApiQueryCustomersRequest wsQueryCustomer) {
        try {
            QueryCustomersRequest request = new QueryCustomersRequest();
            request.setRequestUUID(wsQueryCustomer.getRequestUUID());
            request.setInfProductId(wsQueryCustomer.getInfProductId());
            request.setInfPwd(wsQueryCustomer.getInfPwd());
            request.setWSQueryCustomers(wsQueryCustomer.getWsQueryCustomers());
            log.info("[queryCustomersBySingle method] queryCustomersBySingle request={}", JSONObject.toJSONString(request));
            QueryCustomersResponse response = feign().queryCustomersBySingle(request);
            log.info("[queryCustomersBySingle method] queryCustomersBySingle response={}", JSONObject.toJSONString(response));
            return Optional.ofNullable(response).map(QueryCustomersResponse::getWSCustomers).filter(CollectionUtils::isNotEmpty).orElseGet(Lists::newArrayList);
        } catch (Exception ex) {
            log.error("[queryCustomersBySingle method] 调用WS接口异常，queryCustomersBySingle 错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public QueryCountResponse queryWithdrawalRequestPendingCount(BaseReq request) {
        try {
            WSWithdrawalRequests kycRequest = new WSWithdrawalRequests();
            kycRequest.setLoginName(request.getLoginName());
            log.info("queryKycRequestPendingCount 查询ws系统 kyc信息，入参 {}", JSONObject.toJSONString(kycRequest));
            return feign().queryWaitPendingCount(kycRequest);
        } catch (Exception ex) {
            log.error("调用WS接口异常，queryKycRequestPendingCount", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }
    /**
     * 刷新门店编号（从ws获取有效的门店编号刷新到请求中去，以跳过ws或者userCenter对门店编号的校验）
     *
     * @param wsCustomers
     */
    public void refreshBranchCode(WSCustomers wsCustomers) {
        log.info("[refreshBranchCode] begin to refresh branch code.");
        Optional<WSBranch> branch = Optional.ofNullable(queryWsBranchList(wsCustomers)).
                map(QueryBranchResponse::getData).filter(CollectionUtils::isNotEmpty).
                map(Collection::stream).flatMap(Stream::findFirst);
        branch.map(WSBranch::getBranchCode).filter(StringUtils::isNotBlank).
                ifPresentOrElse(code -> {
                    log.info("[refreshBranchCode] first branch code from ws is {}", code);
                    wsCustomers.setBranchCode(code);
                }, () -> log.error("[refreshBranchCode] query branch code is empty."));
        log.info("[refreshBranchCode] end to refresh branch code.");
    }


    /**
     * 根据登录名查询玩家（玩家详细信息查询）
     * C66
     *
     * @param wsQueryCustomer
     * @return
     */
    public WSCustomers queryCustomer(WSQueryCustomers wsQueryCustomer) {
        try {
            QueryCustomerByLoginNameRequest request = new QueryCustomerByLoginNameRequest();
            request.setInfProductId(wsQueryCustomer.getProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setLoginName(wsQueryCustomer.getLoginName());
            QueryCustomerByLoginNameResponse response = wsFeign.queryByLoginName(request);
            return response == null ? null : response.getWSCustomers();
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryCustomerByLoginNameRequest错误", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    public List<WSCustomersBank> queryCustomerBanks(WSQueryCustomersBank wsQueryCustomersBank) {
        if (UserCenterSwitch.getSwitch()) {
            QueryCustomersBankRequest request = new QueryCustomersBankRequest();
            request.setInfProductId(wsQueryCustomersBank.getProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSQueryCustomersBank(wsQueryCustomersBank);
            QueryCustomersBankResponse response = usFeign.queryCustomerBanks(request);
            return response == null ? new ArrayList<>() : response.getWSCustomersBank();
        } else {
            try {
                QueryCustomersBankRequest request = new QueryCustomersBankRequest();
                request.setInfProductId(wsQueryCustomersBank.getProductId());
                request.setInfPwd(wsCommonConfig.getWsProductPwd());
                request.setWSQueryCustomersBank(wsQueryCustomersBank);
                QueryCustomersBankResponse response = wsFeign.queryCustomerBanks(request);
                return response == null ? new ArrayList<>() : response.getWSCustomersBank();
            } catch (Exception ex) {
                log.error("调用WS接口异常，QueryCustomersBankResponse错误", ex);
                throw new BusinessException(ResultEnum.WS_EXCEPTION);
            }
        }
    }
    public List<WSWithdrawalRequests> queryWithdrawalList(WSQueryWithdrawalRequests wsQueryWithdrawalRequests) {
        try {
            String productId = wsQueryWithdrawalRequests.getProductId();
            QueryWithdrawalRequestsRequest request = new QueryWithdrawalRequestsRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSQueryWithdrawalRequests(wsQueryWithdrawalRequests);
            QueryWithdrawalRequestsResponse response = wsFeign.queryWithdrawalRequestsHide(request);
            return response.getWSWithdrawalRequests();
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryWithdrawalRequestsRequest", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }


    public List<WSResponseApprove> approveWithdrawal(String productId, WSRequestsApprove wSRequestsApprove) {
        try {
            RequestApproveRequest request = new RequestApproveRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWsRequestsApprove(wSRequestsApprove);
            RequestApproveResponse response = wsFeign.requestApprove(request);
            log.info("调用WS接口/rest/request/approve，approveWithdrawal req:{} resp:{}",JSONObject.toJSONString(request),JSONObject.toJSONString(response));
            List<WSResponseApprove> wsResponseApproves = response.getWSResponseApprove();
            if (!wsResponseApproves.isEmpty()) {
                WSResponseApprove responseApprove = wsResponseApproves.get(0);
                if (StringUtils.isNotEmpty(responseApprove.getErrorMsg())) {
                    log.error("调用WS接口error，RequestApproveRequest errMsg:{}", responseApprove.getErrorMsg());
                }
            }
            return wsResponseApproves;
        } catch (Exception ex) {
            log.error("调用WS接口异常，RequestApproveRequest", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }


    public WSQueryCountAmount queryWithdrawalCount(WSQueryWithdrawalRequests wSQueryWithdrawalRequests) {
        try {
            String productId = wSQueryWithdrawalRequests.getProductId();
            QueryCountWithdrawalRequestsRequest request = new QueryCountWithdrawalRequestsRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSQueryWithdrawalRequests(wSQueryWithdrawalRequests);
            QueryCountWithdrawalRequestsResponse response = wsFeign.queryCountWithdrawRequest(request);
            return response.getWSQueryCountAmount();
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryCountWithdrawalRequestsRequest", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    /**
     * 查询代理下级存取款的提案
     */
    public QueryAgentTransResponse queryAgentTrans(WSQueryAgentTrans query) {
        try {
            QueryAgentTransRequest request = new QueryAgentTransRequest();
            request.setInfProductId(query.getProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setRequestUUID(UUID.randomUUID().toString());
            request.setWsQueryAgentTrans(query);
            return wsFeign.queryAgentTrans(request);
        } catch (Exception ex) {
            log.error("调用WS接口异常, queryCustAgentTransaction", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }


    public Integer queryProductConstantsCount(String productId, WSQueryProductConstants query) {
        try {
            QueryCountProductConstantsRequest request = new QueryCountProductConstantsRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSQueryProductConstants(query);
            QueryCountProductConstantsResponse response = wsFeign.queryProductConstantsCount(request);
            return response.getCount();
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryCountProductConstantsRequest", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }


    public List<WSProductConstants> queryProductConstantsList(String productId, WSQueryProductConstants query) {
        try {
            QueryProductConstantsRequest request = new QueryProductConstantsRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSQueryProductConstants(query);
            QueryProductConstantsResponse result = wsFeign.getProductConstants(request);
            return result.getWSProductConstants();
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryProductConstantsRequest", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }



    public WSProductConstants getProductConstants(String productId, String type, String key) {
        // 优先从缓存获取常量
//        final String reidsGroupKey = productId.concat(":ws:product_constants");
//        final String reidsKey = productId + '_' + type + '_' + key;
//        Object productConstants = RedisUtils.get(String.join(":", reidsGroupKey, reidsKey));
//        if (productConstants != null) {
//            List<WSProductConstants> constants = (List<WSProductConstants>) productConstants;
//            return CollectionUtils.isEmpty(constants) ? null : constants.get(0);
//        }

        try {
            QueryProductConstantsRequest request = new QueryProductConstantsRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            WSQueryProductConstants wsQueryProductConstants = new WSQueryProductConstants();
            wsQueryProductConstants.setProductId(productId);
            wsQueryProductConstants.setType(type);
            wsQueryProductConstants.setKey(key);
            request.setWSQueryProductConstants(wsQueryProductConstants);
            QueryProductConstantsResponse response = wsFeign.getProductConstants(request);
            if (response.getWSProductConstants().isEmpty()) {
                return null;
            }
            return response.getWSProductConstants().get(0);
        } catch (Exception ex) {
            log.error("调用WS接口异常，QueryProductConstantsResponse错误", ex);
            throw ex;
        }
    }


    public WSUsers userOfficeLogin(WSUsers user, String operateType) {
        try {  //todo 1
            String productId = user.getProductId();
            LoginOfficeRequest request = new LoginOfficeRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setInfFlag(operateType);
            request.setWSUsers(user);
            request.setFunctionIsNew(2);
            LoginOfficeResponse response = wsFeign.userOfficeLogin(request);
            return response == null ? null : response.getWSUsers();
        } catch (Exception ex) {
            log.error("调用WS接口异常，LoginOfficeRequest", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

    /**
     * 查询修改账户状态提案
     */
    public List<WSModifyAccountRequests> queryModifyAccountRecord(WSQueryModifyAccountRequests wsQueryModifyAccountRequests, String productId) {
        try {
            QueryModifyAccountRequestsRequest request = new QueryModifyAccountRequestsRequest();
            request.setInfProductId(productId);
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSQueryModifyAccountRequests(wsQueryModifyAccountRequests);
            QueryModifyAccountRequestsResponse response = wsFeign.queryModifyAccountRecord(request);
            return response == null ? new ArrayList<>() : response.getWSModifyAccountRequests();
        } catch (Exception ex) {
            log.error("调用WS接口异常，queryModifyAccountRecord", ex);
            throw new BusinessException(ResultEnum.WS_EXCEPTION);
        }
    }

}
