package com.riskcontrol.common.config;

import com.riskcontrol.common.annotation.Null2Empty;
import org.apache.ibatis.executor.parameter.ParameterHandler;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.plugin.Intercepts;
import org.apache.ibatis.plugin.Invocation;
import org.apache.ibatis.plugin.Signature;

import java.lang.reflect.Field;
import java.sql.PreparedStatement;
import java.util.Objects;

/**
 * @description: null转空字符拦截器
 * @author: ErHu.Zhao
 * @create: 2024-10-07
 **/
@Intercepts({@Signature(type = ParameterHandler.class, method = "setParameters", args = PreparedStatement.class)})
public class Null2EmptyInterceptor implements Interceptor {

    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        Object target = invocation.getTarget();
        if (Objects.nonNull(target) && target instanceof ParameterHandler) {
            ParameterHandler parameterHandler = (ParameterHandler) invocation.getTarget();
            Object parameterObject = parameterHandler.getParameterObject();
            if (Objects.nonNull(parameterObject)) {
                for (Field field : parameterObject.getClass().getDeclaredFields()) {
                    if (field.getType() == String.class && field.isAnnotationPresent(Null2Empty.class)) {
                        field.setAccessible(true);
                        if (Objects.isNull(field.get(parameterObject))) {
                            field.set(parameterObject, "");
                        }
                    }
                }
            }
        }
        return invocation.proceed();
    }
}
