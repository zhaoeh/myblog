package com.riskcontrol.common.entity.request;

import com.google.common.base.MoreObjects;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

public class BaseReq implements Serializable {

    @ApiModelProperty(required = true, value = "产品编号[必填]", example = "A03", position = 0)
    private String productId;

    @ApiModelProperty(required = false, value = "登录名[登录态下或登录时必须传入]", example = "kslot777", position = 1)
    private String loginName;

    @ApiModelProperty(required = false, value = "登录名[登录态下或登录时必须传入]", example = "kslot777", position = 1)
    private String customerId;

    @ApiModelProperty(hidden = true, required = true, value = "应用编号[必填]", example = "A03H501")
    private String appId;

    @ApiModelProperty(hidden = true, required = false, value = "版本号[app必填, web端不传]", example = "1.0.0")
    private String v;

    @ApiModelProperty(hidden = true, required = true, value = "请求编号[必填]", example = "76e8bc82e91cf74b97a0722b4616f1f8")
    private String qid;

    @ApiModelProperty(hidden = true, required = true, value = "请求签名[必填]", example = "f2a748bbeee74f2b8de2a3c23d22ac93")
    private String sign;

    @ApiModelProperty(hidden = true, required = false, value = "请求域名[app必填, web端不传]", example = "www.hygame03.com")
    private String domainName;

    @ApiModelProperty(hidden = true, required = false, value = "会话token", example = "e8dab5c23407946dbaa528325cf1a07a")
    private String token;

    @ApiModelProperty(hidden = true, required = false, value = "渠道编号或域名", example = "100001/www.a03.com")
    private String parentId;

    @ApiModelProperty(hidden = true, required = false, value = "设备编号", example = "100001")
    private String deviceId;

    @ApiModelProperty(hidden = true, required = false, value = "IP地址[不传]", example = "127.0.0.1")
    private String ipAddress;

    @ApiModelProperty(hidden = true, value = "传递应用编号", example = "A03DS01")
    private String srcAppId;

    @ApiModelProperty(hidden = true, value = "传递应用版本号", example = "2.1.0")
    private String srcV;

    @ApiModelProperty(hidden = true)
    private String postBody;

    @ApiModelProperty(hidden = true, value = "请求域名", example = "www.ag88220.com")
    private String host;

    @ApiModelProperty(hidden = true, value = "WEB端(H5&APP)请求URI协议名", example = "https")
    private String uriScheme;

    @ApiModelProperty(hidden = true, value = "操作员", example = "")
    private String operator;

    @ApiModelProperty(hidden = true, value = "语言参数[默认en]", example = "en")
    private String lang = "en";

    @ApiModelProperty(hidden = true, value = "mac地址(针对桌面端)", example = "08:00:20:0A:8C:6D")
    private String mac;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getV() {
        return v;
    }

    public void setV(String v) {
        this.v = v;
    }

    public String getQid() {
        return qid;
    }

    public void setQid(String qid) {
        this.qid = qid;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getSrcAppId() {
        return srcAppId;
    }

    public void setSrcAppId(String srcAppId) {
        this.srcAppId = srcAppId;
    }

    public String getSrcV() {
        return srcV;
    }

    public void setSrcV(String srcV) {
        this.srcV = srcV;
    }

    public String getPostBody() {
        return postBody;
    }

    public void setPostBody(String postBody) {
        this.postBody = postBody;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getUriScheme() {
        return uriScheme;
    }

    public void setUriScheme(String uriScheme) {
        this.uriScheme = uriScheme;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getMac() {
        return mac;
    }

    public void setMac(String mac) {
        this.mac = mac;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper("")
                .add("productId", productId)
                .add("loginName", loginName)
                .add("customerId", customerId)
                .add("appId", appId)
                .add("v", v)
                .add("qid", qid)
                .add("sign", sign)
                .add("domainName", domainName)
                .add("token", token)
                .add("parentId", parentId)
                .add("deviceId", deviceId)
                .add("ipAddress", ipAddress)
                .add("srcAppId", srcAppId)
                .add("srcV", srcV)
                .add("postBody", postBody)
                .add("host", host)
                .add("uriScheme", uriScheme)
                .omitNullValues()
                .toString();
    }
}