package com.riskcontrol.common.enums;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

/**
 * 白名单类型枚举类
 * @author Heng.zhang
 */
@AllArgsConstructor
@Getter
public enum RiskActionAllowTypeEnum {
    //白名单类型（0:ip ; 1:设备指纹）
    IP(0, "ip"),
    DEVICE(1, "device"),
;
    private final int id;
    private final String name;

    /**
     * 获取所有的来源
     */
    public static List<AllowType> getAllowType(){
        return Arrays.stream(RiskActionAllowTypeEnum.values()).map(x-> new RiskActionAllowTypeEnum.AllowType(x.id,x.name)).toList();
    }

    /**
     * 渠道返回对象
     */
    @AllArgsConstructor
    @Data
    public static class AllowType implements Serializable {
        private static final long serialVersionUID = 1L;
        private final int id;
        private final String name;
    }
}
