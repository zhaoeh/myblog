package com.riskcontrol.common.entity.request.kyc;


import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class WSKycRequestGw {
    @Schema(description = "Id, primary Key")
    private String id;
    @Schema(description = "customerId")
    private String customerId;
    @Schema(description = "customer Login Name")
    private String loginName;
    @Schema(description = "productId")
    private String productId;
    @Schema(description = "created Date")
    private String createdDate;
    @Schema(description = "open Date")
    private String openDate;
    @Schema(description = "approved Date")
    private String approvedDate;
    @Schema(description = "pbc approved Date")
    private String pbcApprovedDate;
    @Schema(description = "repetation")
    private String repetation;
    @Schema(description = "doubtful")
    private String doubtful;
    @Schema(description = "created By")
    private String createdBy;
    @Schema(description = "update By")
    private String updateDate;
    @Schema(description = "type")
    private String type;
    @Schema(description = "update By")
    private String updateBy;
    @Schema(description = "approved By")
    private String approvedBy;
    @Schema(description = "pbc approved By")
    private String pbcApprovedBy;
    @Schema(description = "id Type")
    private String idType;
    @Schema(description = "id Number")
    private String idNo;
    @Schema(description = "firstName")
    private String firstName;
    @Schema(description = "middleName")
    private String middleName;
    @Schema(description = "lastName")
    private String lastName;

    @Schema(description = "employerName")
    private String employerName;

    @Schema(description = "birthPlace")
    private String birthPlace;
    @Schema(description = "id snapshot storage address")
    private String idScan;
    @Schema(description = "id snapshot storage address v2")
    private String idScanV2;
    @Schema(description = "id scan image key")
    private String idScanImagekey;
    @Schema(description = "id status")
    private String status;
    @Schema(description = "remark")
    private String remark;
    @Schema(description = "sex")
    private String sex;
    @Schema(description = "address")
    private String address;
    @Schema(description = "country")
    private String country;
    @Schema(description = "assigneeTime")
    private String assigneeTime;
    @Schema(description = "assigneeBy")
    private String assigneeBy;
    @Schema(description = "dispatchStatus")
    private Integer dispatchStatus;
    @Schema(description = "pbcStatus")
    private Integer pbcStatus;
    @Schema(description = "processLog")
    private String processLog;
    @Schema(description = "billNo")
    private String billNo;
    @Schema(description = "birthday")
    private String birthday;
    @Schema(description = "province")
    private String province;
    @Schema(description = "reserve2")
    private String reserve2;
    @Schema(description = "birthday")
    private String reserve4;
    @Schema(
            description = "product 产品名称",
            example = "BP,AP"
    )
    private String product;
    @Schema(
            description = "channel 渠道",
            example = "与网关对应：3-GLIFE, 4-GPO(占位), 5-LAZADA, 6-MAYA, 99-WEBSITE"
    )

    private String channel;
    @Schema(description = "收入来源")
    private String sourceOfIncome;
    @Schema(description = "现居地址")
    private String presentAddress;
    @Schema(description = "国籍")
    private String nationality;
    @Schema(description = "工作性质")
    private String natureOfWork;
    @Schema(description = "自拍照")
    private String imgUrl;

    @Override
    public String toString() {
        return "WSKycRequestGw{" +
                "id='" + id + '\'' +
                ", customerId='" + customerId + '\'' +
                ", loginName='" + loginName + '\'' +
                ", productId='" + productId + '\'' +
                ", createdDate='" + createdDate + '\'' +
                ", openDate='" + openDate + '\'' +
                ", approvedDate='" + approvedDate + '\'' +
                ", pbcApprovedDate='" + pbcApprovedDate + '\'' +
                ", repetation='" + repetation + '\'' +
                ", doubtful='" + doubtful + '\'' +
                ", createdBy='" + createdBy + '\'' +
                ", updateDate='" + updateDate + '\'' +
                ", type='" + type + '\'' +
                ", updateBy='" + updateBy + '\'' +
                ", approvedBy='" + approvedBy + '\'' +
                ", pbcApprovedBy='" + pbcApprovedBy + '\'' +
                ", idType='" + idType + '\'' +
                ", idNo='" + idNo + '\'' +
                ", firstName='" + firstName + '\'' +
                ", middleName='" + middleName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", idScan='" + idScan + '\'' +
                ", idScanV2='" + idScanV2 + '\'' +
                ", idScanImagekey='" + idScanImagekey + '\'' +
                ", status='" + status + '\'' +
                ", remark='" + remark + '\'' +
                ", sex='" + sex + '\'' +
                ", address='" + address + '\'' +
                ", country='" + country + '\'' +
                ", assigneeTime='" + assigneeTime + '\'' +
                ", assigneeBy='" + assigneeBy + '\'' +
                ", dispatchStatus=" + dispatchStatus +
                ", pbcStatus=" + pbcStatus +
                ", processLog='" + processLog + '\'' +
                ", billNo='" + billNo + '\'' +
                ", birthday='" + birthday + '\'' +
                ", province='" + province + '\'' +
                ", reserve2='" + reserve2 + '\'' +
                ", reserve4='" + reserve4 + '\'' +
                ", product='" + product + '\'' +
                ", channel='" + channel + '\'' +
                '}';
    }
}