package com.riskcontrol.common.config;


import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class UserCenterSwitch {
    private static final Logger logger = LoggerFactory.getLogger(UserCenterSwitch.class);
    /**
     * 服务节点
     */
    private static String serverNode;

    private static C66Config c66Config;

    private static UserCenterConstant userCenterConstant;


    private UserCenterSwitch(@Value("${server.model.name}") String envServerNode) {
        serverNode = envServerNode;
    }

    @Autowired
    public void setC66Config(C66Config c66Config) {
        UserCenterSwitch.c66Config = c66Config;
    }

    @Autowired
    public void setUserCenterConstant(UserCenterConstant userCenterConstant) {
        UserCenterSwitch.userCenterConstant = userCenterConstant;
    }

    public static String serverNode() {
        return serverNode;
    }

    /**
     * 是否启用用户中心接口调用
     *
     * @return
     */
    public static Boolean getSwitch() {
        Boolean returnFlag = false;
        try {
            //1、总开关是否开启
            if (StringUtils.equals(Constant.ONE_STR, userCenterConstant.getConstantValue(Constant.USER_CENTER_CALL_SWITCH))) {
                //2、服务节点是否开启,节点统一转小写，统一配置常量
                if (StringUtils.equalsAny(serverNode.toLowerCase(), StringUtils.split(userCenterConstant.getConstantValue(Constant.USER_CENTER_SERVER_NODE), ","))) {
                    returnFlag = true;
                }
            }
        } catch (Exception e) {
            logger.error("UserCenterSwitch.getSwitch 开关读取出错", e);
            throw new BusinessException(ResultEnum.SWITCH_READ_ERROR);
        }
        return returnFlag;
    }
}
