package com.riskcontrol.common.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @program: riskcontrol-api
 * @description: c66 config
 * @author: Colson
 * @create: 2023-09-14 15:54
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Component
@RefreshScope
public class C66Config {

    /**
     * pxoffice-api updateKycRequest*
     * 用户中心信息查询开关 0关闭1开启*
     */
    @Value("${C66.user-center-call-switch}")
    private String userCenterCallSwitch;

    /**
     * gateway-api improveUserProfile *
     */
    @Value("${C66.create-real-customer-check-email}")
    private String createRealCustomerCheckEmail;

    /**
     * pxoffice-api & gateway-api 共用*
     */
    @Value("${C66.x2-key}")
    private String x2Key;

    /**
     * pxoffice-api & gateway-api 共用*
     */
    @Value("${C66.x3-key}")
    private String x3Key;

    /**
     * pxoffice-api & gateway-api 共用*
     */
    @Value("${C66.current-environment}")
    private String currentEnvironment;

    /**
     * pxoffice-api & gateway-api 共用*
     */
    @Value("${C66.app-type}")
    private Integer appType;



    /**
     * pxoffice-api & gateway-api 共用*
     */
    @Value("${C66.product-key}")
    private String productKey;

    /**
     * gateway-api *
     */
    @Value("${C66.user-center-server-node}")
    private String userCenterServerNode;

    /**
     * gateway-api *
     */
    @Value("${C66.server-model-name}")
    private String serverModelName;

    /**
     * pxoffice-api & gateway-api 共用*
     */
    @Value("${C66.multi-product-convert}")
    private String multiProductConvert;

    /**
     * gateway-api improveUserProfile *
     */
    @Value("${C66.same-email-bind-times}")
    private String sameEmailBindTimes;

    /**
     * pxoffice-api updateKycRequest*
     */
    @Value("${C66.black-deposit-levels}")
    private String blackDepositLevels;

    /**
     * pxoffice-api updateKycRequest*
     */
    @Value("${C66.black-disallowed-ops}")
    private String blackDisallowedOps;


}
