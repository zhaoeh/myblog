package com.riskcontrol.common.entity.response.device;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * @Auther: Zhilin
 * @Date: 2024/11/13 18:23
 * @Description:
 */
@Getter
@Setter
@Accessors(chain = true)
public class RegisterCheckResponse {

    /**
     * 是否命中黑名单
     */
    @ApiModelProperty(value = "isBlack")
    private Boolean isBlack;

    /**
     * 规则明细
     */
    @ApiModelProperty(value = "details")
    private RegisterCheckDetailResponse details;

}
