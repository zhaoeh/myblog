package com.riskcontrol.common.entity.request.api;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.math.BigInteger;

/**
 * @author Colson
 * @program riskcontrol-common
 * @description 手机号码黑名单，部分字段名由DP指定，故不使用基类
 * @date 2023/9/26 10:30
 **/
@Data
@ApiModel(value = "手机号黑名单更新绑定用户请求对象", description = "手机号黑名单更新绑定用户参数")
public class PhoneNumberBlacklistUpdateHistoryRequest {

    @ApiModelProperty("ID")
    private BigInteger id;

    @ApiModelProperty("手机号码Md5")
    private String phoneMd5;

    @ApiModelProperty("所有历史绑定的用户ID，逗号分隔，按照时间顺序增加")
    @NotBlank(message = "history cannot be empty")
    private String history;

    @ApiModelProperty("最后一次最后修改的account")
    @NotBlank(message = "dataModifier cannot be empty")
    private String dataModifier;

    @ApiModelProperty("备注")
    private String remarks;
}
