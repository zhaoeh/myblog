package com.riskcontrol.common.entity.request;

import com.cn.schema.customers.WSCustomers;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * @description: customer/account/checkCustomerInfo
 * @author: Colson
 * @create: 2023-09-20 12:00
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class UserQueryCheckCustomerInfoRequest {

    private String requestUUID;

    private String infProductId;

    private String infPwd;

    private Integer infFlag;

    private WSCustomers wsCustomers;

}
