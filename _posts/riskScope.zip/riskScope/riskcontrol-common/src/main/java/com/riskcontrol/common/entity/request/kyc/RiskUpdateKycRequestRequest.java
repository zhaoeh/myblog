package com.riskcontrol.common.entity.request.kyc;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.riskcontrol.common.entity.pojo.KycRequest;
import io.swagger.annotations.ApiModelProperty;

public class RiskUpdateKycRequestRequest {
    @ApiModelProperty(value = "本次请求UUID标识")
    protected String requestUUID;
    protected String infProductId;
    protected String infPwd;
    @JSONField(name = "wsKycRequest")
    @JsonProperty("wsKycRequest")
    protected KycRequest wsKycRequest;

    public String getRequestUUID() {
        return requestUUID;
    }

    public void setRequestUUID(String requestUUID) {
        this.requestUUID = requestUUID;
    }

    public String getInfProductId() {
        return infProductId;
    }

    public void setInfProductId(String value) {
        this.infProductId = value;
    }

    public String getInfPwd() {
        return infPwd;
    }

    public void setInfPwd(String value) {
        this.infPwd = value;
    }

    public KycRequest getWsKycRequest() {
        return wsKycRequest;
    }

    public void setWsKycRequest(KycRequest wsKycRequest) {
        this.wsKycRequest = wsKycRequest;
    }
}