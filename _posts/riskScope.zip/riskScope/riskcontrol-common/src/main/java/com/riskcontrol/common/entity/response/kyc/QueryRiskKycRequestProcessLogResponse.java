package com.riskcontrol.common.entity.response.kyc;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

/**
 * @program: riskcontrol-api
 * @description:
 * @author: Colson
 * @create: 2023-12-15 16:24
 */
@ApiModel(value = "风险 Kyc 请求流程日志响应", description = "风险 Kyc 请求流程日志响应")
@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
public class QueryRiskKycRequestProcessLogResponse {

    @ApiModelProperty(
            required = true,
            value = "结果总数量"
    )
    protected int count;
    @ApiModelProperty(
            required = true,
            value = "当前页数据集合"
    )
    protected List<RiskKycRequestProcessLogResponse> data;

}
