package com.riskcontrol.common.entity.zoloz;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.Hidden;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/10/2 14:00
 */
@AllArgsConstructor
@NoArgsConstructor
@ApiModel("初始化id+人脸接口")
@Data
public class InitRealIDBean {
    @Hidden
    @ApiModelProperty(required = true, value = "业务ID，业务的唯一标识，用于追踪业务" )
    private String bizId;
    @ApiModelProperty(required = true, value = "SDK和用户设备的元信息,如果是H5接入模式，则设置为MOB_H5" )
    @NotBlank(message = "metaInfo can't blank")
    private String metaInfo;
    @ApiModelProperty(required = true, value = "用户id" )
    private String userId;
    @ApiModelProperty(required = true, value = "指定身份验证流的类型。取值如下：REALIDLITE_KYC：使用App SDK接入模式。 H5_REALIDLITE_KYC：使用H5接入模式" )
    @NotBlank(message = "flowType can't blank")
    private String flowType;
    @ApiModelProperty(required = true, value = "指定证件类型 参考CardTypeEnum枚举" )
    @NotBlank(message = "docType can't blank")
    private String docType;
    @Hidden
    @ApiModelProperty(required = false, value = "证件类型列表。docType和autoDocTypes不能同时传入，需选择其中一个传入。 目前护照不支持自动分类。" )
    private List<String> autoDocTypes;
    @ApiModelProperty(required = false, value = "人脸引导页的URL" )
    private PageConfig pageConfig;
    @ApiModelProperty(required = false, value = "flowType=H5_REALIDLITE_KYC 时必传" )
    private H5ModeConfig h5ModeConfig;
    /**
     * 场景码，用来为数据分析指定不同的业务场景。
     * 当需要区分不同业务场景中的数据表现时，建议根据业务用途为sceneCode字段设置不同的值，例如login、riskVerify、payment、changePassword。
     */
    @Hidden
    @ApiModelProperty(required = false, value = "场景码" )
    private String sceneCode;
    /**
     * 防伪检测和人脸活体检测的服务等级。取值如下：
     *
     * REALID0001：在身份验证进程中需要用户手动拍摄证件照片。ZOLOZ执行基本的防伪检测，以及使用眨眼检测方法进行基本的活体检测。
     * REALID0002：在身份验证进程中ZOLOZ SDK会自动扫描证件。ZOLOZ执行高等级的防伪检测，以及使用眨眼检测方法进行基本的活体检测。
     * 说明：当使用场景为Web SDK，且所扫描的证件为中国香港身份证第一版或第二版时，将采用多角度采集方式。
     * REALID0003：在身份验证进程中ZOLOZ SDK会自动扫描证件。ZOLOZ执行高等级的防伪检测，并使用多动作检测方法进行活体检测。这些动作从以下列表中随机选择两个：眨眼、张嘴、抬头、低头、左摇头、右摇头。
     * 说明：该服务等级仅支持在原生SDK模式下使用。
     * REALID0004：在身份验证进程中，即使身份证件处于倾斜角度，ZOLOZ SDK也会自动扫描证件。ZOLOZ执行基本的防伪检测，以及使用眨眼检测方法进行基本的活体检测。
     * REALID0009：在身份验证进程中ZOLOZ SDK会自动扫描证件。ZOLOZ执行高等级的防伪检测，以及使用眨眼检测方法进行活体检测。
     * 说明：该服务等级会额外采集一张闭眼的人脸图片，且该服务等级仅支持在原生SDK模式下使用。
     * REALID0011：在身份验证进程中ZOLOZ SDK会自动扫描证件。ZOLOZ执行高等级的防伪检测，以及使用眨眼检测方法进行活体检测。
     * 说明：
     * 该服务等级会额外采集一张闭眼的人脸图片，且该服务等级仅支持在Web SDK模式下使用。
     * 当使用场景为Web SDK，且所扫描的证件为中国香港身份证第一版或第二版时，将采用多角度采集方式。
     * REALID0012：在身份验证进程中ZOLOZ SDK会自动扫描证件。ZOLOZ执行基本的防伪检测，以及使用眨眼检测方法进行活体检测。
     * 说明：该服务等级仅支持在Web SDK模式下使用。
     */
    @Hidden
    @ApiModelProperty(required = false, value = "防伪检测和人脸活体检测的服务等级,默认 REALID0001 " )
    private String serviceLevel;

    @Data
    public static class H5ModeConfig{
        @ApiModelProperty(required = false, value = "完成时回调url：http://xxx" )
        private String completeCallbackUrl;
        @ApiModelProperty(required = false, value = "中断时回调url：http://xxx" )
        private String interruptCallbackUrl;
        @ApiModelProperty(required = false, value = "是否需要在iframe中打开网页，如果需要设置为Y，否则设置为N。" )
        private String isIframe;
    }
    @Data
    public static class PageConfig{
        @ApiModelProperty(required = false, value = "人脸引导页的URL" )
        private String urlFaceGuide;
    }
}
