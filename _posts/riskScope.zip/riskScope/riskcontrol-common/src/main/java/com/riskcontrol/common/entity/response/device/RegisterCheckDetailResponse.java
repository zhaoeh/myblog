package com.riskcontrol.common.entity.response.device;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * @Auther: Zhilin
 * @Date: 2024/11/13 18:23
 * @Description:
 */
@Getter
@Setter
@Accessors(chain = true)
public class RegisterCheckDetailResponse {

//    /**
//     * 是否命中手机号黑名单
//     */
//    @ApiModelProperty(value = "isPhoneBlack")
//    private Boolean isPhoneBlack;

    /**
     * 是否命中ip黑名单
     */
    @ApiModelProperty(value = "isIpBlack")
    private Boolean isIpBlack;

    /**
     * 是否命中设备指纹黑名单
     */
    @ApiModelProperty(value = "isDeviceBlack")
    private Boolean isDeviceBlack;

}
