package com.riskcontrol.common.cache;

import java.util.function.Supplier;

/**
 * 本地缓存加载器
 *
 * @param <T>
 */
public interface LocalCacheLoader<T> {

    /**
     * 获取数据类别
     */
    String getDataCategory();

    /**
     * 获取数据供应者
     */
    Supplier<T> getValueSupplier();
}
