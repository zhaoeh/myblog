package com.riskcontrol.common.enums;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

/**
 * 风控行为类型枚举类(与白名单通用)
 * @author Heng.zhang
 */
@AllArgsConstructor
@Getter
public enum RiskActionTypeEnum {
    //规则限制行为（0：登录：1：注册）
    LOGIN(0, "登录"),
    REGISTER(1, "注册"),
;
    private final int id;
    private final String name;

    /**
     * 获取所有的来源
     */
    public static List<ActionType> getAllowType(){
        return Arrays.stream(RiskActionTypeEnum.values()).map(x-> new RiskActionTypeEnum.ActionType(x.id,x.name)).toList();
    }

    /**
     * 渠道返回对象
     */
    @AllArgsConstructor
    @Data
    public static class ActionType implements Serializable {
        private static final long serialVersionUID = 1L;
        private final int id;
        private final String name;
    }
}
