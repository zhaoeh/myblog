package com.riskcontrol.common.enums;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

/**
 * 风控行为类型枚举类(与白名单通用)
 * @author Heng.zhang
 */
@AllArgsConstructor
@Getter
public enum RiskActionEnableEnum {
    //是否启用（0：启用；1：禁用）
    ENABLE(0, "启用"),
    DISABLE(1, "禁用"),
;
    private final int id;
    private final String name;

    /**
     * 获取所有的来源
     */
    public static List<ActionEnable> getActionEnable(){
        return Arrays.stream(RiskActionEnableEnum.values()).map(x-> new RiskActionEnableEnum.ActionEnable(x.id,x.name)).toList();
    }

    /**
     * 渠道返回对象
     */
    @AllArgsConstructor
    @Data
    public static class ActionEnable implements Serializable {
        private static final long serialVersionUID = 1L;
        private final int id;
        private final String name;
    }
}
