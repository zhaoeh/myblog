package com.riskcontrol.common.client;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.agent.QueryAgentTransRequest;
import com.cn.schema.agent.QueryAgentTransResponse;
import com.cn.schema.creditlogs.QueryCreditLogsRequest;
import com.cn.schema.creditlogs.QueryCreditLogsResponse;
import com.cn.schema.creditlogs.QueryDepositTransWithCheckRequest;
import com.cn.schema.creditlogs.QueryDepositTransWithCheckResponse;
import com.cn.schema.customers.*;
import com.cn.schema.products.QueryCountProductConstantsRequest;
import com.cn.schema.products.QueryCountProductConstantsResponse;
import com.cn.schema.products.QueryProductConstantsRequest;
import com.cn.schema.products.QueryProductConstantsResponse;
import com.cn.schema.request.*;
import com.cn.schema.urf.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


/**
 * @Description: ws接口使用feign调用
 * @Auther: yannis
 * @create: 2023-08-31
 */
@FeignClient(name = "c66-ws",url = "${c66-ws.url}")
public interface WSFeign {

    /**
     * 查询存款记录
     * @param wsQueryDepositTrans
     * @return
     */
    @PostMapping(value = "/rest/creditlogs/deposit_trans_withcheck/query_page_by_condition")
    QueryDepositTransWithCheckResponse queryDepositTransRecord(@RequestBody QueryDepositTransWithCheckRequest wsQueryDepositTrans);

    @PostMapping(value = "/rest/customers/query_customer_by_login_name_v2")
    QueryCustomerByLoginNameResponse queryByLoginName(QueryCustomerByLoginNameRequest request);

    @PostMapping(value = "/rest/customers/customer_bank/query")
    QueryCustomersBankResponse queryCustomerBanks(QueryCustomersBankRequest request);


    /**
     * 查询优惠申请报表
     * @param request
     * @return
     */
    @PostMapping(value = "/rest/request/promotion/query_report_count")
    QueryCountReportPromotionResponse getCountReportPromotion(QueryCountReportPromotionRequest request);

    /**
     * 查询取款提案信息
     * @param request
     * @return
     */
    @PostMapping(value ="/rest/request/query_count_withdrawal_requests")
    QueryCountWithdrawalRequestsResponse queryCountWithdrawRequest(QueryCountWithdrawalRequestsRequest request);

    /**
     * 查询取款提案
     * @param request
     * @return
     */
    @PostMapping(value ="/rest/request/query_withdrawal_requests")
    QueryWithdrawalRequestsResponse queryWithdrawalRequests(QueryWithdrawalRequestsRequest request);


    /**
     * 修改取款风控原因
     * @param request
     * @return
     */
    @PostMapping(value ="/rest/request/modifyExceptionPrompt")
    ModifyWithdrawalExceptionPromptResponse modifyExceptionPrompt(ModifyWithdrawalExceptionPromptRequest request);

    /**
     * 创建对应额度变化时本地和游戏厅额度快照
     * @param request
     */
    @PostMapping(value ="/rest/request/request_balance/create")
    void createRequestBalance(CreateRequestBalanceRequest request);

    /**
     * 批准提案
     * @param request
     * @return
     */
    @PostMapping(value ="/rest/request/approve")
    RequestApproveResponse requestApprove(RequestApproveRequest request);

    /**
     * 查询产品常量配置
     * @param request
     * @return
     */
    @PostMapping(value ="/rest/products/product_constants/query_product_constants")
    QueryProductConstantsResponse getProductConstants(QueryProductConstantsRequest request);

    /**
     * 查询额度记录
     * @param request
     * @return
     */
    @PostMapping(value ="/rest/creditlogs/credit_logs/query")
    QueryCreditLogsResponse getCreditLogs(QueryCreditLogsRequest request);


    /**
     * 根据用户ID查询用户信息*
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/rest/customers/query_basic_by_customer_Id")
    QueryCustomersBasicByLoginNameResponseV2 getCustomerById(QueryCustomersBasicByIdRequest request);
    /**
     * 根据用户名查询用户信息*
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/rest/customers/query_basic_by_login_nameV2")
    QueryCustomersBasicByLoginNameResponseV2 getCustomerByLoginNameV2(QueryCustomersBasicByLoginNameRequestV2 request);

    @PostMapping(value = "/rest/customers/check_customer_infoV2")
    CheckCustomerInfoResponseV2 checkCustomerV2(CheckCustomerInfoRequestV2 request);

    @PostMapping(value = "/rest/request/bond/count")
    QueryCountBondResponse queryCountBondRequest(QueryCountBondRequest request);

    @PostMapping(value = "/rest/request/bond/query_old")
    QueryBondResponse queryBondRequest(QueryBondRequest request);

    @PostMapping(value = "/rest/customers/kyc_request/query")
    QueryKycRequestResponse queryKycRequest(QueryKycRequestRequest request);

    @PostMapping(value = "/rest/customers/ocr_identify/checkOcrIdentify")
    CheckOcrIdentifyResponse checkOcrIdentify(CheckOcrIdentifyRequest request);

    @PostMapping(value = "/rest/urf/branch/query_branch_list")
    QueryBranchResponse queryBranchList(QueryBranchRequest request);

    @PostMapping(value = "/rest/customers/kyc_request/create")
    CreateKycRequestResponse addKycRequest(CreateKycRequestRequest request);

    @PostMapping(value = "/rest/customers/account/complete")
    CompleteAccountResponse completeCustomer(CompleteAccountRequest request);

    @PostMapping(value = "/rest/request/bond/create")
    CreateBondResponse bondCreate(CreateBondRequest request);

    @PostMapping(value = "/rest/customers/customer_face/create")
    CreateCustomerFaceResponse createCustomerFace(CreateCustomerFaceRequest request);

    @PostMapping(value = "/rest/customers/ocr_identify/create")
    CreateOcrIdentifyResponse saveOcrIdentify(CreateOcrIdentifyRequest request);


    @PostMapping(value = "/rest/customers/query_basic_by_login_name")
    QueryCustomersBasicByLoginNameResponse getSimpleCustomerByLoginName(QueryCustomersBasicByLoginNameRequest request);

    @PostMapping(value = "/rest/customers/query_basic_by_login_nameV3")
    QueryCustomersBasicByLoginNameResponseV3 getSimpleCustomerByLoginNameV3(QueryCustomersBasicByLoginNameRequestV3 request);

    @PostMapping(value = "/rest/customers/account/modify")
    ModifyAccountResponse modifyAccount(ModifyAccountRequest request);

    @PostMapping(value = "/rest/customers/kyc_request/update")
    ModifyKycRequestResponse updateKycRequest(UpdateKycRequestRequest request);

    @PostMapping(value = "/rest/urf/menu/queryUserByFunction")
    BatchActivateSuspendResponse queryUserByFunction(QueryFunctionsRolesRequest request);

    @PostMapping(value = "/rest/customers/kyc_request/pbcDispatch")
    ModifyKycRequestResponse pbcDispatch(UpdateKycRequestRequest request);

    @PostMapping(value = "/rest/customers/query_customers")
    QueryCustomersResponse queryCustomers(QueryCustomersRequest request);

    @PostMapping(value = "/rest/customers/customer_face/modify")
    ModifyCustomerFaceResponse updateCustomerFace(ModifyCustomerFaceRequest request);

    @PostMapping(value = "/rest/customers/remarks/create")
    CreateCustomersRemarksResponse createCustomerRemark(CreateCustomersRemarksRequest request);

    @PostMapping(value = "/rest/customers/kyc_request/count")
    QueryKycRequestResponse countKycRequest(QueryKycRequestRequest request);

    @PostMapping(value = "/rest/customers/kyc_request/pbcModifyStatus")
    ModifyKycRequestResponse pbcModifyStatus(UpdateKycRequestRequest request);


    /**
     * 新增 导出接口查询
     * @param request
     * @return
     */
    @PostMapping(value = "/rest/customers/kyc_request/queryKycSheetList")
    QueryKycSheetListRequestResponse queryKycSheetRequest(QueryKycRequestRequest request);




    @PostMapping(value = "/rest/customers/kyc_request/countKycPbc")
    QueryKycRequestResponse  countKycPbcRequest(QueryKycRequestRequest request);



    @PostMapping(value = "/rest/customers/kyc_request/bactchModifyPbcStatus")
    BatchModifyPbcRequestResponse  bactchModifyPbcStatus(BatchUpdateKycRequestRequest request);





    @PostMapping(value = "/rest/customers/kyc_request/queryPageByKycRequestId")
    QueryKycRequestProcessLogResponse  queryPageByKycRequestId(UpdateKycRequestRequest request);

    @PostMapping(value = "/rest/customers/kyc_request/queryWaitPendingCount")
    QueryCountResponse queryWaitPendingCount(WSKycRequest request);

    @PostMapping(value = "/rest/customers/kyc_request/dispatch")
    QueryKycRequestResponse dispatch(WSKycRequest request);

    @PostMapping(value = "/rest/urf/user/work/querLastWorkingStatus")
    QueryUserLastWorkingStatusResponse querLastWorkingStatus(QueryUserLastWorkingStatusRequest request);

    @PostMapping(value = "/rest/request/withdrawal_request_dispatch_cancel")
    WithdrawalDispatchConfirmResponse dispatchWithdrawalCancel(WSWithdrawalRequests request);

    @PostMapping(value = "/rest/customers/kyc_request/dispatchCancel")
    KycDispatchConfirmResponse dispatchCancel(WSKycRequest request);

    @PostMapping(value = "/rest/request/dispatch_request/pending_count")
    DispatchPendingCountResponse pendingCount(WSDispatchRecord request);

    @PostMapping(value = "/rest/urf/user/work/updateWorkingStatus")
    UpdateUserWorkingStatusResponse updateWorkingStatus(UpdateUserWorkingStatusRequest request);


    @PostMapping(value = "/rest/customers/kyc_request/checkDispatchConfirm")
    KycDispatchConfirmResponse checkDispatchConfirm(KycDispatchConfirmRequest request) ;

    @PostMapping(value = "/rest/customers/kyc_request/dispatchConfirm")
    KycDispatchConfirmResponse dispatchKycRequestConfirm(KycDispatchConfirmRequest request) ;



    @PostMapping(value = "/rest/urf/user/query_user_list")
    QueryUsersResponse queryUserList(QueryUsersRequest request);

    @PostMapping(value = "/rest/urf/branch/query_branch_list")
    QueryBranchResponse queryWsBranchList(QueryBranchRequest request);

    /**
     * 查询客户信息，基于单表查询
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/rest/customers/queryCustomers")
    QueryCustomersResponse queryCustomersBySingle(QueryCustomersRequest request);

    @PostMapping(value = "/rest/request/query_withdrawal_pending_count")
    QueryCountResponse queryWaitPendingCount(WSWithdrawalRequests request);

    @PostMapping(value = "/rest/urf/login/user_office_login")
    LoginOfficeResponse userOfficeLogin(LoginOfficeRequest request);

    @PostMapping(value = "/rest/agent_trans/query")
    QueryAgentTransResponse queryAgentTrans(QueryAgentTransRequest request);
    @PostMapping(value = "/rest/products/product_constants/query_count_product_constants")
    QueryCountProductConstantsResponse queryProductConstantsCount(QueryCountProductConstantsRequest request);

    /**
     * 查询取款提案(有限字段，只查提案表，没有联表查询)
     * @param request  QueryWithdrawalRequestsRequest
     * @return
     */
    @PostMapping(value ="/rest/request/query_withdrawal_requests/desc")
    QueryWithdrawalRequestsResponse queryWithdrawalRequestDesc(JSONObject request);

    /**
     * 查询取款提案(bankAccountNo 返回掩码)
     * @param request
     * @return
     */
    @PostMapping(value ="/rest/request/query_withdrawal_requests/hide")
    QueryWithdrawalRequestsResponse queryWithdrawalRequestsHide(QueryWithdrawalRequestsRequest request);
    @PostMapping(value ="/rest/request/account/query")
    QueryModifyAccountRequestsResponse queryModifyAccountRecord(QueryModifyAccountRequestsRequest request);

}
