package com.riskcontrol.common.annotation;

import java.lang.annotation.*;

/**
 * @Description: 注解主要用于创建用户mq消费消息时创建上下文uuid，或者没有创建上下文uuid时使用
 * @Auther: yannis
 * @create: 2023-10-27
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
public  @interface LogUUID {

}
