package com.riskcontrol.common.entity.response.api;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigInteger;

/*** @program: riskcontrol-common
 ** @description: 风控PBC返回接口
 ** @author: hongwei
 ** @create: 2023-11-14 14:25
 **/
@ApiModel(value = "风控PBC响应对象", description = "风控PBC响应对象")
@Data
public class PBCDeployRsp {

    @ApiModelProperty("id")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    protected BigInteger id;
    @ApiModelProperty("抓取系统id")
    protected String systemId;
    @ApiModelProperty("抓取系统名称")
    protected String systemName;
    @ApiModelProperty("域名地址")
    protected String mainAddress;
    @ApiModelProperty("二级域名地址")
    protected String subAddress;
    @ApiModelProperty("用户名")
    protected String userName;
    @ApiModelProperty("密码")
    protected String password;
    @ApiModelProperty("开始时间")
    protected String startTime;
    @ApiModelProperty("停止时间")
    protected String endTime;
    @ApiModelProperty("抓取频率")
    protected String frequency;
    @ApiModelProperty("配置状态 1 enable  2 disable")
    protected String status;
    @ApiModelProperty("创建时间")
    protected String createDate;
    @ApiModelProperty("创建修改人")
    protected String createBy;
    @ApiModelProperty("修改时间")
    protected String updateDate;
    @ApiModelProperty("最后修改人")
    protected String updateBy;
    @ApiModelProperty("修改时间")
    protected String deleteDate;
    @ApiModelProperty("删除人")
    protected String deleteBy;

}
