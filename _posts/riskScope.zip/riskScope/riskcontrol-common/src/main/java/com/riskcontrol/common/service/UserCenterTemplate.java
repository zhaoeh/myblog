package com.riskcontrol.common.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cn.schema.customers.ModifyAccountRequest;
import com.cn.schema.customers.ModifyAccountResponse;
import com.cn.schema.customers.QueryCustomersBasicByLoginNameResponseV3;
import com.cn.schema.customers.WSCustomers;
import com.cn.schema.request.*;
import com.github.xiaoymin.knife4j.core.util.StrUtil;
import com.riskcontrol.common.client.UserCenterFeign;
import com.riskcontrol.common.config.WsCommonConfig;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.request.*;
import com.riskcontrol.common.enums.CustomerFlagEnum;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Objects;

@Slf4j
@Component
public class UserCenterTemplate {


    @Resource
    private WsCommonConfig wsCommonConfig;
    @Resource
    private WsFeignTemplate wsFeignTemplate;
    @Resource
    private UserCenterFeign userCenterFeign;

    public WSCustomers getSimpleCustomerByLoginName(String productId, String loginName) {
        try {
            UserQueryCustomersBasicByLoginNameRequest request = new UserQueryCustomersBasicByLoginNameRequest();
            request.setRequestUUID(MDC.get("qid"))
                    .setInfProductId(productId)
                    .setLoginName(loginName)
                    .setInfPwd(wsCommonConfig.getWsProductPwd())
                    .setOnlyOpenUser(false);
            log.info("请求用户中心-getSimpleCustomerByLoginName，url:{} 入参：{}",  "/customer/account/getCustomerByLoginName", JSONObject.toJSONString(request));
            QueryCustomersBasicByLoginNameResponseV3 response = userCenterFeign.getSimpleCustomerByLoginName(request);
            log.info("请求用户中心-getSimpleCustomerByLoginName，入参：{}，响应：{}", JSONObject.toJSONString(request), JSONObject.toJSONString(response));
            return response.getWsCustomer();
        } catch (Exception ex) {
            log.error("调用用户中心接口异常，getSimpleCustomerByLoginName 错误", ex);
            throw new BusinessException(ResultEnum.UC_EXCEPTION);
        }
    }

    /**
     * C66 修改玩家详细信息（包括修改密码、状态等详细信息）
     *
     * @param wsCustomers <pre>
     */
    public ModifyAccountResponse modifyAccount(WSCustomers wsCustomers, String infFlag) {
        String errorMessage = "";
        try {
            //note：以防更新用户出错，需要先查用户信息，获取正确的用户id
            if (Objects.isNull(wsCustomers)) {
                throw new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST_ERROR);
            }
            //查询用户信息获取customerId
            if (StringUtils.isNotBlank(wsCustomers.getLoginName()) && StringUtils.isNotBlank(wsCustomers.getProductId())) {
                WSCustomers queryCustomers = this.getSimpleCustomerByLoginName(wsCustomers.getProductId(), wsCustomers.getLoginName());
                if (Objects.nonNull(queryCustomers)) {
                    wsCustomers.setCustomerId(queryCustomers.getCustomerId());
                }
            }
            // 刷新门店信息
            wsFeignTemplate.refreshBranchCode(wsCustomers);

            ModifyAccountRequest request = new ModifyAccountRequest();
            request.setInfProductId(wsCustomers.getProductId());
            request.setRequestUUID(MDC.get("qid"));
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSCustomers(wsCustomers);
            request.setInfFlag(infFlag);

            log.info("请求用户中心-modifyAccount，入参：{}", JSONObject.toJSONString(request));
            ModifyAccountResponse response = userCenterFeign.modifyAccount(request);
            log.info("请求用户中心-modifyAccount，response：{}", JSONObject.toJSONString(response));
            if (StringUtils.isNotBlank(response.getWsErrorMsg())) {
                log.error("调用用户中心接口错误，modifyAccount 错误：{}", response.getWsErrorMsg());
                errorMessage = response.getWsErrorMsg();
            }
            return response;
        } catch (Exception ex) {
            log.error("调用用户中心接口异常，modifyAccount 错误 :{}", errorMessage,ex);
            if (StrUtil.isBlank(errorMessage)) {
                throw new BusinessException(ResultEnum.UC_EXCEPTION);
            } else {
                throw new BusinessException("49999",errorMessage);
            }
        }
    }

    public WSCustomers getCustomerByCustomerId(String productId, String customerId) {
        try {
            UserQueryCustomersByCustomerIdRequest request = new UserQueryCustomersByCustomerIdRequest();
            request.setCustomerId(customerId)
                    .setInfPwd(wsCommonConfig.getWsProductPwd())
                    .setRequestUUID(MDC.get("qid"))
                    .setInfProductId(productId);
            JSONObject response = userCenterFeign.getCustomerByCustomerId(request);
            log.info("请求用户中心-getCustomerByCustomerId,入参：{}，响应：{}", JSONObject.toJSONString(request), JSONObject.toJSONString(response));
            if (response == null || response.isEmpty()) {
                return null;
            } else {
                String jsonString = JSON.toJSONString(response.get("userInfo"));
                WSCustomers userInfo = JSONObject.parseObject(jsonString, WSCustomers.class);
                return userInfo;
            }
        } catch (Exception ex) {
            log.error("调用用户中心接口异常，getCustomerByCustomerId 错误", ex);
            throw new BusinessException(ResultEnum.UC_EXCEPTION);
        }
    }

    public boolean checkCustomerInfo(String productId, Integer checkType, String checkValue) {
        try {
            WSCustomers wsCustomer = new WSCustomers();
            CustomerFlagEnum flagEnum = CustomerFlagEnum.findEnumByFlag(checkType);
            if (Objects.nonNull(flagEnum)) {
                String setField = flagEnum.getField();
                Field field = wsCustomer.getClass().getDeclaredField(setField);
                field.setAccessible(true);
                field.set(wsCustomer, checkValue);
            } else {
                return false;
            }
            UserQueryCheckCustomerInfoRequest request = new UserQueryCheckCustomerInfoRequest();
            request.setWsCustomers(wsCustomer)
                    .setInfFlag(checkType)
                    .setInfPwd(wsCommonConfig.getWsProductPwd())
                    .setRequestUUID(MDC.get("qid"))
                    .setInfProductId(productId);
            log.info("请求用户中心-checkCustomerInfo，入参：{}", JSONObject.toJSONString(request));
            JSONObject response = userCenterFeign.checkCustomerInfo(request);
            log.info("请求用户中心-checkCustomerInfo，响应：{}", JSONObject.toJSONString(response));
            return response.getBoolean("result");
        } catch (Exception ex) {
            log.error("调用用户中心接口异常，checkCustomerInfo 错误", ex);
            throw new BusinessException(ResultEnum.UC_EXCEPTION);
        }
    }

    public List<WSBond> queryBondRequest(WSQueryBondRequests wsQueryBondRequest) {
        try {
            QueryBondRequest request = new QueryBondRequest();
            request.setInfProductId(wsQueryBondRequest.getProductId());
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setRequestUUID(MDC.get("qid"));
            request.setWSQueryBondRequests(wsQueryBondRequest);
            log.info("请求用户中心-queryBondRequest，入参：{}", JSONObject.toJSONString(request));
            QueryBondResponse response = userCenterFeign.queryBondRequest(request);
            log.info("请求用户中心-queryBondRequest，响应：{}", JSONObject.toJSONString(response));
            return response.getWSBond();
        } catch (Exception ex) {
            log.error("调用用户中心接口异常，queryBondRequest 错误", ex);
            throw new BusinessException(ResultEnum.UC_EXCEPTION);
        }
    }

    public WSCustomers completeCustomer(WSCustomers wsCustomer) {
        try {
            UserCompleteCustomerRequest request = new UserCompleteCustomerRequest();
            request.setInfProductId(wsCustomer.getProductId())
                    .setInfPwd(wsCommonConfig.getWsProductPwd())
                    .setWsCustomers(wsCustomer);
            log.info("请求用户中心-completeCustomer，入参：{}", JSONObject.toJSONString(request));
            ModifyAccountResponse response = userCenterFeign.completeCustomer(request);
            log.info("请求用户中心-completeCustomer，响应：{}", JSONObject.toJSONString(response));
            return response.getWSCustomers();
        } catch (Exception ex) {
            log.error("调用用户中心接口异常，completeCustomer 错误", ex);
            throw new BusinessException(ResultEnum.UC_EXCEPTION);
        }
    }

    public boolean bindMobileNoOrEmail(WSBond wsBond) {
        try {
            CreateBondRequest request = new CreateBondRequest();
            request.setInfProductId(wsBond.getProductId());
            request.setRequestUUID(MDC.get("qid"));
            request.setInfPwd(wsCommonConfig.getWsProductPwd());
            request.setWSBond(wsBond);
            log.info("请求用户中心-bindMobileNoOrEmail，入参：{}", JSONObject.toJSONString(request));
            JSONObject response = userCenterFeign.bindMobileNoOrEmail(request);
            log.info("请求用户中心-bindMobileNoOrEmail，响应：{}", JSONObject.toJSONString(response));
            return response.getBoolean("result");
        } catch (Exception ex) {
            log.error("调用用户中心接口异常，bindMobileNoOrEmail 错误", ex);
            throw new BusinessException(ResultEnum.UC_EXCEPTION);
        }
    }

    public String constantQuery(String key) {
        log.info("UserCenterTemplate constantQuery key={}", key);
        try {
            JSONObject request = new JSONObject();
            request.put("key", key);
            request.put("productId", Constant.C66_PRODUCT_ID);
            log.info("UserCenterTemplate constantQuery req={}", JSONObject.toJSONString(request));
            JSONObject result = userCenterFeign.constantQuery(request);
            log.info("UserCenterTemplate constantQuery result={}", JSONObject.toJSONString(result));
            return request.getJSONObject("body").getString(key);
        } catch (Exception ex) {
            log.error("调用用户中心接口异常，constantQuery 错误", ex);
            throw new BusinessException(ResultEnum.UC_EXCEPTION);
        }
    }

    /**
     * 从userCenter获取客户信息
     *
     * @param request 获取客户信息请求
     * @return 客户信息
     */
    public WSCustomers queryCustomersBySingle(ApiQueryCustomersRequest request) {
        try {
            UserQueryCustomersByCustomerIdRequest userQueryCustomersByCustomerIdRequest = new UserQueryCustomersByCustomerIdRequest();
            userQueryCustomersByCustomerIdRequest.setCustomerId(request.getCustomerId())
                    .setInfPwd(StringUtils.isBlank(request.getInfPwd()) ? wsCommonConfig.getWsProductPwd() : request.getInfPwd())
                    .setRequestUUID(request.getRequestUUID())
                    .setInfProductId(request.getInfProductId());
            JSONObject response = userCenterFeign.getCustomerByCustomerId(userQueryCustomersByCustomerIdRequest);
            log.info("请求用户中心-queryCustomersBySingle,入参：{}，响应：{}", JSONObject.toJSONString(request), JSONObject.toJSONString(response));
            if (response == null || response.isEmpty()) {
                log.error("调用用户中心接口异常，queryCustomersBySingle 错误，响应为空.");
                throw new BusinessException("49999","queryCustomersBySingle接口请求用户中心响应为空.");
            }
            if (response.containsKey(Constant.CODE) && !response.getInteger(Constant.CODE).equals(HttpStatus.OK.value())) {
                String message = response.containsKey(Constant.MESSAGE) ? response.getString(Constant.MESSAGE) : Integer.toString(response.getInteger(Constant.CODE));
                log.error("调用用户中心接口异常，queryCustomersBySingle 错误：{}", message);
                throw new BusinessException("",message);
            }
            if (!response.containsKey(Constant.USERINFO)) {
                log.error("调用用户中心接口异常，queryCustomersBySingle 错误：响应不存在userInfo节点");
                throw new BusinessException("49999","queryCustomersBySingle接口，userCenter响应不存在userInfo节点");
            }
            String jsonString = JSON.toJSONString(response.get(Constant.USERINFO));
            WSCustomers userInfo = JSONObject.parseObject(jsonString, WSCustomers.class);
            return userInfo;
        } catch (Exception ex) {
            log.error("调用用户中心接口异常，getCustomerByCustomerId 错误", ex);
            throw new BusinessException(ResultEnum.UC_EXCEPTION);
        }
    }

}
