
package com.riskcontrol.common.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

/**
 * @program: riskcontrol-common
 * @description: risk api feign
 * @author: Erhu.Zhao
 * @create: 2023-11-21 16:33
 */
@FeignClient(name = "c66-three-agent-api")
public interface AgentApiFeign {
    /**
     * 根据代理请求返回业务报文体
     *
     * @param request （必须是AgentProxyReq）
     * @return query result
     */
    @PostMapping(value = "/webApi/queryAgentCustomers.do")
    String proxyAgent(@RequestParam Map<String, Object> request);

}