package com.riskcontrol.common.entity.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import java.math.BigInteger;

/**
 * 登陆风控汇总表
 */
@TableName(value = "t_risk_action_login_sum")
@Getter
@Setter
@Accessors(chain = true)
public class TRiskActionLoginSum {

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private BigInteger id;

    /**
     * 设备指纹
     */
    @TableField(value = "device_fingerprint")
    private String deviceFingerprint;

    /**
     * 登陆IP地址
     */
    @TableField(value = "ip_address")
    private String ipAddress;

    /**
     * 汇总日期(精度: 天)
     */
    @TableField(value = "date_at")
    private String dateAt;

    /**
     * 用户名用逗号拼串
     */
    @TableField(value = "login_names")
    private String loginNames;

    /**
     * 创建时间
     */
    @TableField(value = "create_date")
    private String createDate;

    /**
     * 更新时间
     */
    @TableField(value = "update_date")
    private String updateDate;
}
