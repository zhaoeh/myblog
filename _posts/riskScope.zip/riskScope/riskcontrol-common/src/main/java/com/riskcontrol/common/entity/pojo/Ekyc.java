package com.riskcontrol.common.entity.pojo;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.riskcontrol.common.annotation.Null2Empty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

/**
 * eKYC结果表
 */
@TableName(value = "t_ekyc")
@Data
public class Ekyc implements Serializable {
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private BigInteger id;

    /**
     * 用户ID
     */
    @TableField(value = "customer_id")
    private Long customerId;

    /**
     * 用户名
     */
    @TableField(value = "login_name")
    private String loginName;

    /**
     * 首名
     */
    @TableField(value = "first_name", fill = FieldFill.INSERT)
    @Null2Empty
    private String firstName;

    /**
     * 中间名
     */
    @TableField(value = "middle_name")
    private String middleName;

    /**
     * 尾名
     */
    @TableField(value = "last_name", fill = FieldFill.INSERT)
    @Null2Empty
    private String lastName;

    /**
     * 生日
     */
    @TableField(value = "birthday")
    private String birthday;

    /**
     * M=Male, F=Female
     */
    @TableField(value = "sex")
    private String sex;

    /**
     * 证件图片地址
     */
    @TableField(value = "id_front_img")
    private String idFrontImg;

    /**
     * 证件图片地址
     */
    @TableField(value = "id_back_img")
    private String idBackImg;

    /**
     * 证件类型
     */
    @TableField(value = "id_type")
    private Integer idType;

    /**
     * 证件号
     */
    @TableField(value = "id_no")
    private String idNo;

    /**
     * 自拍照
     */
    @TableField(value = "face_img")
    private String faceImg;

    /**
     * KYC状态 -1待提交 0 待审核，1 通过，2 拒绝，3手动拒绝
     */
    @TableField(value = "`status`")
    private Integer status;

    /**
     * 创建时间
     */
    @TableField(value = "create_date")
    private Date createDate;

    /**
     * 创建人
     */
    @TableField(value = "create_by")
    private String createBy;

    /**
     * 更新时间
     */
    @TableField(value = "update_date")
    private Date updateDate;

    /**
     * 更新人
     */
    @TableField(value = "update_by")
    private String updateBy;

    /**
     * 血缘标记（BP、AP、 GP、PG、SP）
     */
    @TableField(value = "tenant")
    private String tenant;

    /**
     * 渠道(3:GLIFE,4:GPO,5:LAZADA,6:MAYA,7:PERYAGAME,99WEBSITE,98:人工)
     */
    @TableField(value = "channel")
    private String channel;

    /**
     * 企业名称
     */
    @TableField(value = "employer_name")
    private String employerName;

    /**
     * 永久居住地
     */
    @TableField(value = "address")
    private String address;

    /**
     * 出生地
     */
    @TableField(value = "birth_place")
    private String birthPlace;

    /**
     * 现居地址
     */
    @TableField(value = "present_address")
    private String presentAddress;

    /**
     * 国籍
     */
    @TableField(value = "nationality")
    private String nationality;

    /**
     * 资金来源
     */
    @TableField(value = "source_of_income")
    private String sourceOfIncome;

    /**
     * 工作性质
     */
    @TableField(value = "nature_of_work")
    private String natureOfWork;

    /**
     * 备注
     */
    @TableField(value = "remark")
    private String remark;

    /**
     * 拒绝原因
     */
    @TableField(value = "reject_reason")
    private String rejectReason;

}