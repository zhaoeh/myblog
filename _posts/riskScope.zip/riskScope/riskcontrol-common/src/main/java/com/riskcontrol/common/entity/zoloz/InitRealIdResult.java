package com.riskcontrol.common.entity.zoloz;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/10/2 15:00
 */
@AllArgsConstructor
@NoArgsConstructor
@ApiModel("初始化id+人脸返回对象")
@Data
public class InitRealIdResult {
    @ApiModelProperty(required = true, value = "{\"resultStatus\": \"S\", \"resultCode\": \"SUCCESS\",  \"resultMessage\": \"Success\" }" )
    private Result result;
    @ApiModelProperty(required = true, value = "ZOLOZ服务器为身份验证生成的唯一事务ID。此ID将作为RealID checkresult API请求的输入参数。" )
    private String transactionId;
    @ApiModelProperty(required = true, value = "客户端配置信息，包括SDK连接和行为参数。当result.resultStatus的值为S时，才返回该字段" )
    private String clientCfg;


}
