package com.riskcontrol.common.validation;
import com.alibaba.excel.EasyExcel;
import com.riskcontrol.common.annotation.ExcelHeaderCheck;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ExcelHeaderValidator implements ConstraintValidator<ExcelHeaderCheck, MultipartFile> {

    private int type;

    @Override
    public void initialize(ExcelHeaderCheck constraintAnnotation) {
        // 读取注解中的 type 参数
        this.type = constraintAnnotation.type();
    }

    @Override
    public boolean isValid(MultipartFile file, ConstraintValidatorContext context) {
        // 如果文件为空，直接返回 false
        if (file == null || file.isEmpty()) {
            return false;
        }

        try {
            // 定义不同类型对应的列头
            List<String> expectedHeaders = new ArrayList<>();
            if (type == 0) {
                expectedHeaders = Arrays.asList("账号");
            } else if (type == 1) {
                expectedHeaders = Arrays.asList("First name", "Middle name", "Last name", "生日");
            }
            // 读取 Excel 文件的第一行
            List<String> actualHeaders = EasyExcel.read(file.getInputStream())
                    .headRowNumber(0) // 指定读取第一行作为列头
                    .sheet(0)
                    .doReadSync()
                    .stream()
                    .findFirst() // 只取第一行数据
                    .map(row -> (List<String>) row)
                    .orElse(null);

            // 如果读取不到列头，返回 false
            if (actualHeaders == null || actualHeaders.isEmpty()) {
                return false;
            }

            // 校验实际列头是否与预期列头一致
            return expectedHeaders.equals(actualHeaders);

        } catch (IOException e) {
            // 出现异常时返回 false
            return false;
        }
    }
}
