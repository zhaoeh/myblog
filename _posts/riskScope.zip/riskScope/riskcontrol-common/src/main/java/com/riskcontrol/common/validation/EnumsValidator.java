package com.riskcontrol.common.validation;

import com.riskcontrol.common.annotation.EnumValid;
import com.riskcontrol.common.client.CronFeign;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.util.PropertyPlaceholderHelper;
import org.springframework.util.ReflectionUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @description: 关联校验指定枚举
 * @author: ErHu.Zhao
 * @create: 2024-09-24
 **/
public class EnumsValidator implements ConstraintValidator<EnumValid, Object> {

    PropertyPlaceholderHelper placeholderHelper = new PropertyPlaceholderHelper("{", "}");

    private EnumValid enumValid;

    @Override
    public void initialize(EnumValid constraintAnnotation) {
        enumValid = constraintAnnotation;
    }

    @Override
    public boolean isValid(Object target, ConstraintValidatorContext context) {
        if (Objects.isNull(target)) {
            return true;
        }
        final List<MessagesPlace> result = new ArrayList<>();
        valid(target, result);
        return isValid(context, result);
    }


    private MessagesPlace handleRangeMessage(EnumValid enums, List<String> enumsValues) {
        String message = StringUtils.isNotBlank(enums.message()) ? enums.message() : "current value must be {target}";
        return MessagesPlace.builder().message(message).places(Map.of("target", enumsValues)).build();
    }


    private boolean isValid(ConstraintValidatorContext context, final List<MessagesPlace> result) {
        if (result.size() > 0) {
            MessagesPlace message = result.get(0);
            if (Objects.nonNull(message)) {
                // 禁用默认message
                context.disableDefaultConstraintViolation();
                context.buildConstraintViolationWithTemplate(placeholderHelper.replacePlaceholders(message.getMessage(),
                        s -> {
                            Map<Object, Object> places = message.getPlaces();
                            if (CollectionUtils.isEmpty(places)) {
                                return s;
                            } else {
                                return Objects.toString(places.get(s));
                            }
                        })).addConstraintViolation();
            }
            return false;
        }
        return true;
    }

    private void valid(Object target, List<MessagesPlace> result) {
        isReject(target, result, enumValid);
    }

    public void isReject(Object target, List<MessagesPlace> result, EnumValid enums) {
        Optional.ofNullable(enums).ifPresent(ens -> {
            List<String> expectEnums = null;
            try {
                expectEnums = obtainExpectsEnumString(ens);
            } catch (Exception e) {
                ;
            }
            if (Objects.isNull(expectEnums)) {
                result.add(handleRangeMessage(ens, Collections.emptyList()));
                return;
            }
            List<String> targetEnumValues = expectEnums.stream().distinct().collect(Collectors.toList());
            if (!targetEnumValues.contains(Objects.toString(target))) {
                result.add(handleRangeMessage(enums, enums.deduplicateEnumField() ? targetEnumValues : expectEnums));
            }
        });
    }

    private List<String> obtainExpectsEnumString(EnumValid ens) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        if(Objects.isNull(ens)){
            return null;
        }

        Class<? extends EnumsValidator.EnumFieldsSupplier> supplier = ens.enumSupplier();
        if (Objects.nonNull(supplier) && Objects.equals(EnumsValidator.EnumFieldsSupplier.class, supplier)) {
            Object target = ReflectionUtils.accessibleConstructor(supplier).newInstance();
            Method method = ReflectionUtils.findMethod(supplier, "supplyEnumFields");
            return (List<String>) ReflectionUtils.invokeMethod(method, target);
        }

        Class<?> enumClass = ens.enumClass();
        String enumFiled = ens.enumField();
        if (!Objects.equals(enumClass, Enum.class) && enumClass.isEnum() && StringUtils.isNotBlank(enumFiled)) {
            Field f = ReflectionUtils.findField(enumClass, enumFiled);
            ReflectionUtils.makeAccessible(f);
            // 获取所有枚举常量对象
            Object[] objects = enumClass.getEnumConstants();
            if (Objects.isNull(objects)) {
                return null;
            }
            int[] indexes = ens.enumIndexes();
            List<Object> targets = obtainExpects(Arrays.asList(objects), indexes);
            return targets.stream().map(ev -> Objects.toString(ReflectionUtils.getField(f, ev))).collect(Collectors.toList());
        }
        return null;
    }

    private List<Object> obtainExpects(List<Object> objects, int[] indexes) {
        if (Objects.nonNull(objects) && Objects.nonNull(indexes) && indexes.length > 0) {
            List<Object> targets = new ArrayList<>();
            for (int i = 0; i < indexes.length; i++) {
                targets.add(objects.get(indexes[i]));
            }
            return targets;
        }
        return objects;
    }

    /**
     * 枚举值供应器*
     */
    @FunctionalInterface
    public interface EnumFieldsSupplier {
        List<String> supplyEnumFields();
    }
}
