package com.riskcontrol.common.exception;

import com.riskcontrol.common.enums.ResultCode;
import lombok.Getter;

import java.util.Objects;

/**
 * 自定义公共业务异常，构建自定义异常规范
 *
 * @ClassName BusinessException
 * @Description Erhu.Zhao
 * @Author TJSAlex
 * @Date 2023/10/19 12:11
 * @Version 1.0
 **/
@Getter
public class BusinessException extends RuntimeException {
    private static final long serialVersionUID = 6230710265891436813L;

    private static final String ERROR_UNKNOWN_CODE = "GW_999999";
    private static final String ERROR_UNKNOWN_DESC = "系统繁忙, 请稍后再试";

    // 异常码
    protected String code;

    public BusinessException(String message, String code) {
        super(message);
        this.code = code;
    }

    public BusinessException(String message, Integer code) {
        super(message);
        this.code = Objects.toString(code);
    }

    public BusinessException(ResultCode resultCode) {
        super(resultCode.getMessage());
        this.code = resultCode.getCode();
    }

    public BusinessException(String message, Integer code, Throwable cause) {
        super(message, cause);
        this.code = Objects.toString(code);
    }

    public BusinessException(String message, String code, Throwable cause) {
        super(message, cause);
        this.code = code;
    }

    public String buildMessage() {
        return "BusinessException occurred, ErrorCode is [ " + this.code + " ],errorMessage is [ " + this.getMessage() + " ]";
    }
}
