package com.riskcontrol.common.entity.response;

import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.utils.ThreadLocalUtil;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.StringUtils;

/**
 * 错误响应
 */
public class ErrResponse {

    @ApiModelProperty(value = "错误码")
    private String errCode;
    @ApiModelProperty(value = "错误中文描述")
    private String cn;
    @ApiModelProperty(value = "错误英文描述")
    private String en;
    @ApiModelProperty(value = "错误越南文描述")
    private String vi;
    @ApiModelProperty(value = "错误泰文描述")
    private String th;
    @ApiModelProperty(value = "错误日文描述")
    private String ja;

    public ErrResponse() {
    }

    public ErrResponse(String errCode) {
        this.errCode = errCode;
    }

    public String getErrCode() {
        return errCode;
    }

    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }

    public String getCn() {
        return null == cn ? getEn() : cn;
    }

    public void setCn(String cn) {
        this.cn = cn;
    }

    public String getEn() {
        return null == en ? Constant.UNKNOW_EXCEPTION : en;
    }

    public void setEn(String en) {
        this.en = en;
    }

    public String getVi() {
        return null == vi ? getEn() : vi;
    }

    public void setVi(String vi) {
        this.vi = vi;
    }

    public String getTh() {
        return null == th ? getEn() : th;
    }

    public void setTh(String th) {
        this.th = th;
    }

    public String getJa() {
        return null == ja ? getEn() : ja;
    }

    public void setJa(String ja) {
        this.ja = ja;
    }

    public String getErrMsg() {
        //获取服务调用者
        String currentCaller = ThreadLocalUtil.getCurrentCaller();
        String currentLocale = ThreadLocalUtil.getCurrentLocale();
        //如果没有传服务调用者和语言，按原来逻辑返回错误码
        if (StringUtils.isNotBlank(currentCaller) && Constant.SINGLE_LANGUAGE_CALLER.contains(currentCaller)) {
            String language = null;
            //如果没有传，则取英文
            currentLocale = StringUtils.isBlank(currentLocale) ? "en" : currentLocale;
            language = getLanguage(currentLocale);
            return getErrCode() + "^" + language;
        } else {
            return getErrCode() + "^" + getEn() + "^" + getCn() + "^" + getTh() + "^" + getVi() + "^" + getJa();
        }

    }

    public String getLanguage(String propertyName) {
        String language = "";
        switch (propertyName) {
            case "zh":
            case "cn":
                language = getCn();
                break;
            case "en":
                language = getEn();
                break;
            case "vi":
                language = getVi();
                break;
            case "th":
                language = getTh();
                break;
            case "ja":
                language = getJa();
                break;
        }
        return language;
    }

}
