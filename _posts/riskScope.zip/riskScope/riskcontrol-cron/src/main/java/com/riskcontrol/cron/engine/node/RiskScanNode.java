package com.riskcontrol.cron.engine.node;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.constants.ProjectConstant;
import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.engine.WithdrawContext;
import com.riskcontrol.cron.entity.TRiskLabelRelationship;
import com.riskcontrol.cron.enums.WithdrawFilterEnum;
import com.riskcontrol.cron.service.RequestService;
import com.riskcontrol.cron.service.TRiskLabelRelationshipService;
import com.yomahub.liteflow.annotation.LiteflowComponent;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.stream.Collectors;

@LiteflowComponent("riskScanNode")
@Slf4j
public class RiskScanNode extends AbstractWhenNode {
    @Autowired
    private RequestService requestService;
    @Autowired
    private TRiskLabelRelationshipService labelRelationshipService;

    @Override
    public void processWhen() throws Exception {
        WithdrawContext context = this.getFirstContextBean();
        OriWithdrawReq req = context.getReq();
        BigDecimal finalTodayLimit = context.getTodayLimit();
        log.info("取款申请withdrawRisk loginName={},requestId={},上次取款后额度={},最后取款日期={},总存款额={},优惠金额={},输赢额={},有效投注额={},修正金额={},余额={},difference={},profit={},betRate={}"
                , req.getLoginName(), req.getRequestId(), req.getLastWithDrawalBalance(), req.getLastWithDrawalDate(), context.getSumAmount()
                ,context.getSumPromotionAmount(), context.getWinOrLostAmount(), context.getValidAccount(), context.getFixAmount(),context.getDstAmount()
                , context.getDifference(), context.getProfit(), context.getBetRate());

        //风控规则命中
        context.getProductConstantsList().forEach(constant -> {
            String key = constant.getKey();
            if (ProjectConstant.DIFFERENCE.equalsIgnoreCase(key)) {
                if (StringUtils.isNotBlank(constant.getValue())
                        && context.getDifference().compareTo(new BigDecimal(constant.getValue())) > 0) {
                    context.filter.put(WithdrawFilterEnum.DIFFERENCE.getType(),String.format(WithdrawFilterEnum.DIFFERENCE.getFilterMsg(),context.getDifference().toPlainString(),constant.getValue()));
                }
            } else if (ProjectConstant.PROFIT.equalsIgnoreCase(key)) {
                if (StringUtils.isNotBlank(constant.getValue()) && context.getProfit().compareTo(new BigDecimal(constant.getValue())) > 0) {
                    context.filter.put(WithdrawFilterEnum.PROFIT.getType(),String.format(WithdrawFilterEnum.PROFIT.getFilterMsg(), context.getProfit().toPlainString() , constant.getValue()));
                }

            } else if (ProjectConstant.FILTER_PROFIT_AMOUNT.equalsIgnoreCase(key)) {
                if (StringUtils.isNotBlank(constant.getValue())
                        && context.getWinOrLostAmount().compareTo(new BigDecimal(constant.getValue())) > 0 //盈利金额> 阈值
                        && context.getProfit().compareTo(new BigDecimal(context.FILTER_PROFIT_MULTIPLE)) > 0) { //盈利率 > 阈值
                    context.filter.put(WithdrawFilterEnum.PROFIT_AMOUNT.getType(),String.format(WithdrawFilterEnum.PROFIT_AMOUNT.getFilterMsg(), context.getProfit().toPlainString() , context.FILTER_PROFIT_MULTIPLE));
                }
            }else if (ProjectConstant.BET_RATE.equals(key) || "BET_RATE".equals(key)) {
                if (StringUtils.isNotBlank(constant.getValue()) && context.getBetRate().compareTo(new BigDecimal(constant.getValue())) > 0) {
                    context.filter.put(WithdrawFilterEnum.BET_RATE.getType(),String.format(WithdrawFilterEnum.BET_RATE.getFilterMsg(),context.getBetRate().toPlainString(),constant.getValue()));
                }

            } else if (ProjectConstant.TODAY_LIMIT.equals(key) || "TODAY_LIMIT".equals(key)) {
                if (StringUtils.isNotBlank(constant.getValue()) && finalTodayLimit.compareTo(new BigDecimal(constant.getValue())) > 0) {
                    context.filter.put(WithdrawFilterEnum.TODAY_LIMIT.getType(),String.format(WithdrawFilterEnum.TODAY_LIMIT.getFilterMsg(),finalTodayLimit.toPlainString(),constant.getValue()));
                }
            }else if (ProjectConstant.CONSECUTIVE_PASSES_ENABLED.equals(key)) {
                log.info("取款申请withdrawRisk CONSECUTIVE_PASSES_ENABLED loginName:{} CONSECUTIVE_PASSES_ENABLED={}," +
                                "MAX_CONSECUTIVE_PASSES={},MAXIMUM_TOTAL_PASSED_AMOUNT={},totalPassedAmount={}," +
                                "withdrawalRequestsAmount={} "
                        , req.getLoginName(), context.CONSECUTIVE_PASSES_ENABLED, context.MAX_CONSECUTIVE_PASSES, context.MAXIMUM_TOTAL_PASSED_AMOUNT,
                        context.getTotalPassedAmount(), context.getWithdrawalRequestsAmount());
                if ("1".equals(context.CONSECUTIVE_PASSES_ENABLED)
                        && StringUtils.isNotBlank(context.MAX_CONSECUTIVE_PASSES)
                        && StringUtils.isNotBlank(context.MAXIMUM_TOTAL_PASSED_AMOUNT)
                        && (context.getTotalPassedAmount().add(context.getWithdrawalRequestsAmount()).compareTo(new BigDecimal(context.MAXIMUM_TOTAL_PASSED_AMOUNT)) >= 0
                        && context.getTotalPassedCount() >= Integer.valueOf(context.MAX_CONSECUTIVE_PASSES))) {
                    context.filter.put(WithdrawFilterEnum.CONSECUTIVE_PASSES_AND_AMOUNT.getType(),String.format(WithdrawFilterEnum.CONSECUTIVE_PASSES_AND_AMOUNT.getFilterMsg(),context.getTotalPassedCount(),context.getTotalPassedAmount().toPlainString()));
                }
            } else if(ProjectConstant.PROFIT_DIFFERENCE.equalsIgnoreCase(key)){//盈利差额
                if (StringUtils.isNotBlank(constant.getValue()) && context.getWinOrLostAmount().compareTo(new BigDecimal(constant.getValue())) > 0) {
                    context.filter.put(WithdrawFilterEnum.PROFIT_DIFFERENCE.getType(),String.format(WithdrawFilterEnum.PROFIT_DIFFERENCE.getFilterMsg(),context.getWinOrLostAmount().toPlainString(),constant.getValue()));
                }
            }else if(ProjectConstant.MAX_CONSECUTIVE_MANUAL.equalsIgnoreCase(key)){//连续通过笔数>=x
                if (StringUtils.isNotBlank(constant.getValue()) && context.getTotalPassedCount() >= Integer.valueOf(constant.getValue())) {
                    context.filter.put(WithdrawFilterEnum.MAX_CONSECUTIVE_MANUAL.getType(),String.format(WithdrawFilterEnum.MAX_CONSECUTIVE_MANUAL.getFilterMsg(),constant.getValue()));
                }
            }else if (ProjectConstant.DEPOSIT_WITHDRAWAL_RATIO.equalsIgnoreCase(key)){
                //取款天数差大于等于xx天，XX天未取款，期间内有存款，并且本次取款金额小于等于指定期间内存款总金额的XX倍,则可以通过，否则转人工
                if (context.RISK_WITHDRAWAL_DIFFDAY >= Integer.parseInt(context.MAX_QUERY_DEPOSIT_DAYS) && StringUtils.isNotBlank(context.DEPOSIT_WITHDRAWAL_RATIO) && !Constant.ZERO.equals(context.DEPOSIT_WITHDRAWAL_RATIO) ){
                    if (context.getWithdrawalRequestsAmount().compareTo(context.getSumDpAmount().multiply(new BigDecimal(context.DEPOSIT_WITHDRAWAL_RATIO))) > 0){
                        context.filter.put(WithdrawFilterEnum.WITHDRAWAL_GREATER_DEPOSIT_RATIO_FAIL.getType(),String.format(WithdrawFilterEnum.WITHDRAWAL_GREATER_DEPOSIT_RATIO_FAIL.getFilterMsg(),constant.getValue()));
                    }
                }
            }
        });

        if(context.getProfit().compareTo(BigDecimal.ZERO) == 0) {
            if (StringUtils.isNotBlank(context.UNUSED_PROMOTION_ENABLED) && "1".equals(context.UNUSED_PROMOTION_ENABLED)) {
                if (context.getSumPromotionAmount().compareTo(BigDecimal.ZERO) > 0) {
                    context.filter.put(WithdrawFilterEnum.NO_BET.getType(),WithdrawFilterEnum.NO_BET.getFilterMsg());
                } else if (context.getSumPromotionAmount().compareTo(BigDecimal.ZERO) == 0
                        && StringUtils.isNotBlank(context.MAX_UNUSED_PROMOTION_AMOUNT)
                        && context.getWithdrawalRequestsAmount().compareTo(new BigDecimal(context.MAX_UNUSED_PROMOTION_AMOUNT)) > 0) {
                    context.filter.put(WithdrawFilterEnum.NO_BET.getType(),WithdrawFilterEnum.NO_BET.getFilterMsg());
                }
            } else {
                context.filter.put(WithdrawFilterEnum.NO_BET.getType(),WithdrawFilterEnum.NO_BET.getFilterMsg());
            }
        }
        //新增逻辑，首次取款，低于限额可自动通过
        if(("1".equals(req.getFirstWithdrawal()) && StringUtils.isNotBlank(context.FIRST_WITHDRAWAL_CHECK_AMOUNT)
                && context.getWithdrawalRequestsAmount().compareTo(new BigDecimal(context.FIRST_WITHDRAWAL_CHECK_AMOUNT)) > 0)){
            context.filter.put(WithdrawFilterEnum.FIRST_WITHDRAWAL.getType(),String.format(WithdrawFilterEnum.FIRST_WITHDRAWAL.getFilterMsg(),context.getWithdrawalRequestsAmount().toPlainString(),context.FIRST_WITHDRAWAL_CHECK_AMOUNT));
        }
        //自动审批
        if(StringUtils.isNotBlank(context.RISK_AUTO_APPROVE) &&"1".equals(context.RISK_AUTO_APPROVE)){
            //自动审批金额判断
            if (StringUtils.isNotBlank(context.RISK_AUTO_APPROVE_MAX_AMOUNT)
                    && context.getWithdrawalRequestsAmount().compareTo(new BigDecimal(context.RISK_AUTO_APPROVE_MAX_AMOUNT)) > 0){
                context.filter.put(WithdrawFilterEnum.AUTO_APPROVE_FAIL.getType(),String.format(WithdrawFilterEnum.AUTO_APPROVE_FAIL.getFilterMsg(),context.getWithdrawalRequestsAmount(),context.RISK_AUTO_APPROVE_MAX_AMOUNT));
            }
        }else{
            context.filter.put(WithdrawFilterEnum.AUTO_APPROVE_CLOSE.getType(),WithdrawFilterEnum.AUTO_APPROVE_CLOSE.getFilterMsg());
        }

        //当然取款次数>x,单笔取款>y
        if(StringUtils.isNotBlank(context.WD_MANUAL_MIN_NUM) && StringUtils.isNotBlank(context.WD_MANUAL_MIN_AMOUNT)){
            if (context.getTodayPass() >= Integer.valueOf(context.WD_MANUAL_MIN_NUM) && context.getWithdrawalRequestsAmount().compareTo(new BigDecimal(context.WD_MANUAL_MIN_AMOUNT)) >= 0 ) {
                context.filter.put(WithdrawFilterEnum.WD_MANUAL_MIN_NUM.getType(),String.format(WithdrawFilterEnum.WD_MANUAL_MIN_NUM.getFilterMsg(),context.WD_MANUAL_MIN_NUM,context.WD_MANUAL_MIN_AMOUNT));
            }
        }

        // 先设置为自动，判断命中的规则，被拦截走人工
        context.setAutoApprove(true);
        List<String> filterList = context.filter.keySet().stream().toList();
        if(StringUtils.isNotBlank(context.MANUAL_TYPE)) {
            List<String> manualTypeList = StrUtil.split(context.MANUAL_TYPE, Constant.COMMA_SYMBOL);
            for(String key : manualTypeList){
                if(filterList.contains(key)){
                    context.setExceptionPromptType(key);
                    context.setExceptionPrompt(context.filter.get(key));
                    context.setAutoApprove(false);
                    break;
                }
            }
        }
        log.info("规则引擎执行完成，requestid:{},是否走自动审核：{}，命中规则为：{}", req.getRequestId(), context.isAutoApprove(), filterList);
    }

}
