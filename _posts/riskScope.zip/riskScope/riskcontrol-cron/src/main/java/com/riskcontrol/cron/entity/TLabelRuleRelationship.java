package com.riskcontrol.cron.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigInteger;
import java.util.Date;

/**
    * 标签-规则绑定表
    */
@Schema(description="标签-规则绑定表")
@Data
@TableName(value = "t_label_rule_relationship")
public class TLabelRuleRelationship extends BaseEntity {

    /**
     * 风控决策
     */
    @TableField(value = "rule_action")
    @Schema(description="风控决策")
    private String ruleAction;

    /**
     * 标签id
     */
    @TableField(value = "label_id")
    @Schema(description="标签id")
    private BigInteger labelId;

    /**
     * 标签key
     */
    @TableField(value = "label_key")
    @Schema(description="标签key")
    private String labelKey;

    /**
     * 状态 0-未启用；1-已启用
     */
    @TableField(value = "`status`")
    @Schema(description="状态 0-未启用；1-已启用")
    private Integer status;

    /**
     * 描述
     */
    @TableField(value = "remark")
    @Schema(description="描述")
    private String remark;

    /**
     * 创建人
     */
    @TableField(value = "create_by")
    @Schema(description="创建人")
    private String createBy;

    /**
     * 最后修改人
     */
    @TableField(value = "update_by")
    @Schema(description="最后修改人")
    private String updateBy;

    /**
     * 最后修改时间
     */
    @TableField(value = "update_time")
    @Schema(description="最后修改时间")
    private Date updateTime;

    private static final long serialVersionUID = 1L;
}