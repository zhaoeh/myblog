package com.riskcontrol.cron.mapper;

import com.riskcontrol.common.entity.pojo.TRiskActionRegistrationSum;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

@Mapper
public interface TRiskActionRegistrationSumMapper extends BaseMapper<TRiskActionRegistrationSum> {
}
