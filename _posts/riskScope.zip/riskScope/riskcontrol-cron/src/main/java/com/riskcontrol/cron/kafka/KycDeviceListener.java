package com.riskcontrol.cron.kafka;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.common.annotation.LogUUID;
import com.riskcontrol.cron.po.KafkaDeviceInfo;
import com.riskcontrol.cron.service.RiskActionService;
import com.riskcontrol.cron.service.TRiskActionLoginService;
import com.riskcontrol.cron.service.TRiskActionRegistrationService;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;
import javax.annotation.PostConstruct;
import java.util.concurrent.*;

/**
 * @author: sanji
 * @desc: kafka设备指纹自消费
 * @date: 2024/8/14 17:31
 */
@Component
@Slf4j
public class KycDeviceListener {

    @Autowired
    private RiskActionService riskActionService;

    @Autowired
    private TRiskActionRegistrationService riskActionRegistrationService;

    @Autowired
    private TRiskActionLoginService riskActionLoginService;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @KafkaListener(topics = {KafkaTopic.DEVICE_KYC_TOPIC_SELF}, groupId = "group_risk_device_self",
            containerFactory = "batchFactory", errorHandler = "myConsumerAwareErrorHandler")
    @LogUUID
    public void riskDeviceListener(KafkaDeviceInfo kafkaDeviceInfo, Acknowledgment ack) throws ExecutionException, InterruptedException {
        CompletableFuture.runAsync(() -> {
            try {
                // 保存设备信息
                riskActionService.saveDeviceInfo(kafkaDeviceInfo.getDeviceInfo());

                // 保存注册风控明细和汇总
                if (kafkaDeviceInfo.getRegisterSaveRequest() != null && kafkaDeviceInfo.getInterceptTypeOfRegisterSaveRequest() != null) {
                    log.info("RiskDevice保存注册风控明细和汇总 用户名:{}, 拦截类型:{}, 设备指纹:{}, ipAddress:{}", kafkaDeviceInfo.getRegisterSaveRequest().getLoginName(), kafkaDeviceInfo.getInterceptTypeOfRegisterSaveRequest(), kafkaDeviceInfo.getRegisterSaveRequest().getDeviceFingerprint(), kafkaDeviceInfo.getRegisterSaveRequest().getRegisterIp());
                    riskActionRegistrationService.registerSave(kafkaDeviceInfo.getRegisterSaveRequest(), kafkaDeviceInfo.getInterceptTypeOfRegisterSaveRequest());
                }

                // 保存登陆风控明细和汇总
                if (kafkaDeviceInfo.getLoginCheckRequest() != null && kafkaDeviceInfo.getInterceptTypeOfLoginCheckRequest() != null) {
                    log.info("RiskDevice保存登陆风控明细和汇总 用户名:{}, 拦截类型:{}, 设备指纹:{}, ipAddress:{}", kafkaDeviceInfo.getLoginCheckRequest().getLoginName(), kafkaDeviceInfo.getInterceptTypeOfLoginCheckRequest(), kafkaDeviceInfo.getLoginCheckRequest().getDeviceFingerprint(), kafkaDeviceInfo.getLoginCheckRequest().getLoginIp());
                    riskActionLoginService.saveRiskActionLogin(kafkaDeviceInfo.getLoginCheckRequest(), kafkaDeviceInfo.getInterceptTypeOfLoginCheckRequest());
                }

            } catch (Exception e) {
                log.info("riskDeviceListener 异步消费风控设备指纹消息异常，msg：{}", JSONObject.toJSONString(kafkaDeviceInfo), e);
            } finally {
                ack.acknowledge();
            }
        }, executor).get();
    }

    /**
     * 添加优雅停止, 防止运行中程序关闭, 但锁未确认, 导致重复消费
     */
    @PostConstruct
    public void init(){
        Runtime.getRuntime().addShutdownHook(new Thread(){
            @Override
            @SneakyThrows
            public void run() {
                executor.shutdown();
                executor.awaitTermination(1, TimeUnit.MINUTES);
            }
        });
    }

}
