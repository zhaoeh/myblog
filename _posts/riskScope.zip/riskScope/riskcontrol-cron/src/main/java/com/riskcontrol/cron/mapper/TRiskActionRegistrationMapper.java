package com.riskcontrol.cron.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.riskcontrol.common.entity.pojo.TRiskActionRegistration;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TRiskActionRegistrationMapper extends BaseMapper<TRiskActionRegistration> {
}
