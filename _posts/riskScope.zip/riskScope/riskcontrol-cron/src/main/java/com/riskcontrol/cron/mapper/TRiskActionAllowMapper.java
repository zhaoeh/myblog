package com.riskcontrol.cron.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.riskcontrol.common.entity.pojo.TRiskActionAllow;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TRiskActionAllowMapper extends BaseMapper<TRiskActionAllow> {
}
