package com.riskcontrol.cron.engine.node;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.date.TimeInterval;
import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.engine.WithdrawContext;
import com.riskcontrol.cron.service.RequestService;
import com.yomahub.liteflow.annotation.LiteflowComponent;
import com.yomahub.liteflow.core.NodeComponent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

/**
 * 查询投注额和盈利率
 * @author dante
 */
@LiteflowComponent("calcValidProfitNode")
@Slf4j
public class CalcValidProfitNode extends AbstractWhenNode {
    @Autowired
    private RequestService requestService;
    @Override
    public void processWhen() throws Exception {
        WithdrawContext context = this.getFirstContextBean();
        if (!"1".equals(context.QUERY_BET_ENABLED)) {
            return;
        }
        OriWithdrawReq req = context.getReq();

        TimeInterval timer = DateUtil.timer();

        BigDecimal[] decimals = requestService.getValidAccountAndWinOrLostAmount(req.getLastWithDrawalDate(), req.getCreatedDate(), req.getProductId(), req.getLoginName());
        log.info("取款申请withdrawRisk loginName:{} getValidAccountAndWinOrLostAmount Timer {} ms", req.getLoginName(), timer.intervalRestart());
        //投注额
        BigDecimal validAccount = decimals[0];
        //盈利率
        BigDecimal winOrLostAmount = decimals[1];

        context.setWinOrLostAmount(winOrLostAmount);
        context.setValidAccount(validAccount);
    }
}
