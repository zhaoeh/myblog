package com.riskcontrol.cron.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.math.BigInteger;

/**
 * 结果
 */
@TableName(value = "t_pbc_crawler_result_new")
@Data
public class TPbcCrawlerResultNew {

    //指定主键生成策略使用雪花算法(默认策略)
    @TableId(value = "id", type = IdType.ASSIGN_ID)
    @ApiModelProperty(value = "id")
    @JsonFormat(shape = JsonFormat.Shape.STRING)// js丢失精度，转String
    private BigInteger id;

    /**
     * pogcor ID
     */
    @TableField(value = "guest_ext_id")
    private String guestExtId;

    /**
     * 名字
     */
    @TableField(value = "first_name")
    private String firstName;

    /**
     * 中间名
     */
    @TableField(value = "middle_name")
    private String middleName;

    /**
     * 姓
     */
    @TableField(value = "last_name")
    private String lastName;

    /**
     * 生日
     */
    @TableField(value = "birth_date")
    private String birthDate;

    /**
     * 禁用状态（0解除；1禁用）
     */
    @TableField(value = "is_banned")
    private Integer isBanned;

    /**
     * 创建时间
     */
    @TableField(value = "create_date")
    private String createDate;

    /**
     * 修改时间
     */
    @TableField(value = "update_date")
    private String updateDate;

    /**
     * pogcor 创建时间
     */
    @TableField(value = "date_created")
    private String dateCreated;

    /**
     * pogcor禁用来源
     */
    @TableField(value = "source")
    private String source;

    /**
     * 创建人
     */
    @TableField(value = "create_by")
    @Schema(description = "创建人")
    private String createBy;

    /**
     * 更新人
     */
    @TableField(value = "update_by")
    @Schema(description = "更新人")
    private String updateBy;

}