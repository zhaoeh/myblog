package com.riskcontrol.cron.controller;

import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.cron.datasource.DBSourceCheck;
import com.riskcontrol.cron.datasource.DataSourceType;
import com.riskcontrol.cron.service.RiskBlackService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.constraints.NotEmpty;

/**
 * @author Heng.zhang
 */
@RestController
@Api("风控黑名单")
@RequestMapping("/riskBlack")
@Slf4j
public class RiskBlackController {

    @Resource
    private RiskBlackService riskBlackService;

    @GetMapping(value = "/getBlackStatus/{loginName}")
    @ResponseBody
    @DBSourceCheck(DataSourceType.SLAVE)
    public Response<Boolean> getBlackStatus(@PathVariable @Validated @NotEmpty String loginName) {
        return Response.body(riskBlackService.getBlackStatus(loginName));
    }

}
