package com.riskcontrol.cron.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.riskcontrol.common.entity.pojo.TRiskActionLogin;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TRiskActionLoginMapper extends BaseMapper<TRiskActionLogin> {
}
