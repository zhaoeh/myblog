package com.riskcontrol.cron.localcache;

import com.riskcontrol.common.cache.LocalCacheLoader;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.response.ErrResponse;
import com.riskcontrol.cron.service.ErrService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.function.Supplier;

/**
 * 错误码本地缓存加载器
 */
@Component
@Slf4j
@Lazy
public class ErrCodeLocalCacheLoader implements LocalCacheLoader<Map<String, ErrResponse>> {


    private ErrService errServic;

    public ErrCodeLocalCacheLoader(ErrService errServic) {
        this.errServic = errServic;
    }

    @Override
    public String getDataCategory() {
        return Constant.ERROR_CODE_CACHE;
    }

    @Override
    public Supplier<Map<String, ErrResponse>> getValueSupplier() {
        return this::initErrMap;
    }

    /**
     * 初始化系统所用到的error信息
     *
     * @return 错误码信息映射
     */
    private Map<String, ErrResponse> initErrMap() {
        Map<String, ErrResponse> errMap = errServic.provideErrInfo();
        log.info(" 刷新当前缓存类别为 {} ,其数量为 {}", getDataCategory(), errMap.size());
        return errMap;
    }
}
