package com.riskcontrol.cron.entity;

import com.cn.schema.customers.WSKycRequest;
import com.riskcontrol.common.entity.pojo.KycRequest;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

/**
 * @program: riskcontrol-cron
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-10-20 11:55
 **/
@Data
@Builder
public class RiskKycRequest {

    @ApiModelProperty("wsKycRequest, wsKycRequest instance")
    private KycRequest kycRequest;

    @ApiModelProperty("processLogType, process log type")
    private String processLogType;

    @ApiModelProperty("processLogRemark, process log remark")
    private String processLogRemark;

}
