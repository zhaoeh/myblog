package com.riskcontrol.cron.config;


import com.riskcontrol.cron.constants.CronConstant;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

/**
 * @description:  被此Condition标注的类不加载 （目前如果是thirdpart产品部署的officeapp,不加载被此condition标注的类)
 **/

public class ConditonOnExcludeThirdpart implements Condition {

    @Override
    public boolean matches(ConditionContext conditionContext, AnnotatedTypeMetadata annotatedTypeMetadata) {

        return !StringUtils.equalsIgnoreCase(conditionContext.getEnvironment().getProperty("productId"), CronConstant.CHEKC_TIME_ZONE_EXCLUDE);
    }
}


    
