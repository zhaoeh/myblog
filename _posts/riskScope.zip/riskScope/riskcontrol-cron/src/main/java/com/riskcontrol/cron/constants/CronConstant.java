package com.riskcontrol.cron.constants;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @Auther: yannis
 * @Date: 2023/8/31 14:19
 * @Description:
 */
public class CronConstant {
    public static final String CHEKC_TIME_ZONE_EXCLUDE = "thirdpart";

    public static final String WITHDRAWAL_REVIEW_CACHE_KEY = "withdrawal_review_{0}_{1}";
    public static final String KYC_UPDATE_PBC_LOCK = "kyc:update:pbc:lock:%s";
    public static final String WAIT_PBC_KEY = "risk:wait:pbc";
    public static final String WITHDRAW_LOCK = "withdraw:update:lock:%s";
    public static final String WITHDRAW_MANUALLY_LOCK = "withdraw:update:manually:%s";
    public static final String WITHDRAW_ENTER_POOL_LOCK = "withdraw:update:enter:pool:%s";
    /**
     * 系统参数
     */

    // FLAGS
    public static final String ENABLED = "1";

    public static final String FLAG_STR_ONE = "1";

    public static final String DOMAIN_NAME = "RISKCONTROL_CRON";

    // 当前订单标识后缀
    public static final String CURRENT_ORDER = "current_order";

    // 上一笔订单标识后缀
    public static final String LAST_ORDER = "last_order";

    //取款风控系统开关（1-officeapp；2-独立风控）
    public static final String WITHDRAW_RISK_CONTROL_RISKCONTROL = "2";

    /**
     * 手机号码黑名单history字段最大长度 500，超出时移除前面的数据，先进先出*
     */
    public static final Integer PHONE_NUMBER_BLACKLIST_HISTORY_MAXLENGTH = 500;

    /**
     * 消息flag=17，修改手机号码消息 *
     */
    public static final String MESSAGE_FLAG_MODIFY_PHONE = "17";

    /**
     * 手机号码黑名单，非人为修改时的，默认修改用户 *
     */
    public static final String MODIFY_DEFAULT_SYSTEM = "system";

    //用户所有标签 redis key
    public static final String CUSTOMER_All_LABEL = "risk:customer:allLabel";

    public static final String ZERO = "0";
    public static final String ONE = "1";
    public static final String TWO = "2";
    public static final String THREE = "3";
    public static final String FOUR = "4";
    public static final String FIVE = "5";
    public static final String SEVEN = "7";
    public static final String EIGHT = "8";
    public static final String NINE = "9";
    public static final String TEN = "10";
    public static final String ELEVEN = "11";

    /**
     * default page size=30
     */
    public static final int PAGE_SIZE = 30;
    /**
     * default page num=0 of mysql
     */
    public static final int PAGE_NUM = 0;
    /**
     * default page size=1000
     */
    public static final int PAGE_MAX_SIZE = 5000;


    /** request id:request type */
    /**
     * REQUEST TYPE:01----DEPOSIT
     */
    public static final String REQUEST_TYPE_DEPOSIT = "01";

    /**
     * 验证码
     */
    public static final String SMS_VERDIFY_CODE = "60025";

    /**
     * 验证码-手机绑定
     */
    public static final String SMS_VERDIFY_CODE_1 = "60030";
    /**
     * 验证码-邮箱绑定
     */
    public static final String SMS_VERDIFY_CODE_2 = "60031";
    /**
     * 验证码-手机修改
     */
    public static final String SMS_VERDIFY_CODE_3 = "60032";
    /**
     * 验证码-邮箱修改
     */
    public static final String SMS_VERDIFY_CODE_4 = "60033";
    /**
     * 验证码-密码修改
     */
    public static final String SMS_VERDIFY_CODE_5 = "60034";
    /**
     * 验证码-帐号注册
     */
    public static final String SMS_VERDIFY_CODE_6 = "60035";
    /**
     * 验证码-资料修改
     */
    public static final String SMS_VERDIFY_CODE_7 = "60036";
    /**
     * 验证码-银行卡修改
     */
    public static final String SMS_VERDIFY_CODE_8 = "60037";
    /**
     * 验证码-找回密码
     */
    public static final String SMS_VERDIFY_CODE_9 = "60038";

    /**
     * 申请活动资格
     */
    public static final String SMS_VERDIFY_CODE_13 = "60039";

    /**
     * 语音验证  A04
     */
    public static final String SMS_VERDIFY_CODE_17 = "60057";


    // 角色查询时间控制
    public static final String ROLE_TIME_STATUS_MONTH = "1";
    public static final String ROLE_TIME_STATUS_HALFYEAR = "6";
    public static final String ROLE_TIME_STATUS_YEAR = "12";
    public static final String ROLE_TIME_STATUS_NOLIMIT = "0";
    public static final String ROLE_TIME_STATUS_15 = "15";
    public static final String ROLE_TIME_STATUS_7 = "7";
    public static final String ROLE_TIME_STATUS_90 = "90";
    public static final Map<String, String> roleTimeStatus = new LinkedHashMap<String, String>();

    static {
        roleTimeStatus.put(ROLE_TIME_STATUS_MONTH, "一月");
        roleTimeStatus.put(ROLE_TIME_STATUS_HALFYEAR, "半年");
        roleTimeStatus.put(ROLE_TIME_STATUS_YEAR, "一年");
        roleTimeStatus.put(ROLE_TIME_STATUS_NOLIMIT, "不限");
        roleTimeStatus.put(ROLE_TIME_STATUS_15, "15");
        roleTimeStatus.put(ROLE_TIME_STATUS_7, "7");
        roleTimeStatus.put(ROLE_TIME_STATUS_90, "90");
    }

    public static final String SMS_VERDIFY_TYPE_1 = "1";
    public static final String SMS_VERDIFY_TYPE_2 = "2";
    public static final String SMS_VERDIFY_TYPE_3 = "3";
    public static final String SMS_VERDIFY_TYPE_4 = "4";
    public static final String SMS_VERDIFY_TYPE_5 = "5";
    public static final String SMS_VERDIFY_TYPE_6 = "6";
    public static final String SMS_VERDIFY_TYPE_7 = "7";
    public static final String SMS_VERDIFY_TYPE_8 = "8";
    public static final String SMS_VERDIFY_TYPE_9 = "9";
    public static final String SMS_VERDIFY_TYPE_10 = "10";
    public static final String SMS_VERDIFY_TYPE_11 = "11";
    public static final String SMS_VERDIFY_TYPE_13 = "13";
    public static final String SMS_VERDIFY_TYPE_16 = "16";
    public static final String SMS_VERDIFY_TYPE_17 = "17";

    public static final Map<String, String> verdifyTypeName = new LinkedHashMap<String, String>();

    static {
        verdifyTypeName.put(SMS_VERDIFY_TYPE_1, "手机绑定");
        verdifyTypeName.put(SMS_VERDIFY_TYPE_2, "邮箱绑定");
        verdifyTypeName.put(SMS_VERDIFY_TYPE_3, "手机修改");
        verdifyTypeName.put(SMS_VERDIFY_TYPE_4, "邮箱修改");
        verdifyTypeName.put(SMS_VERDIFY_TYPE_5, "密码修改");
        verdifyTypeName.put(SMS_VERDIFY_TYPE_6, "账号注册");
        verdifyTypeName.put(SMS_VERDIFY_TYPE_7, "资料修改");
        verdifyTypeName.put(SMS_VERDIFY_TYPE_8, "银行卡修改");
        verdifyTypeName.put(SMS_VERDIFY_TYPE_9, "找回密码");
        verdifyTypeName.put(SMS_VERDIFY_TYPE_10, "登录");
        verdifyTypeName.put(SMS_VERDIFY_TYPE_11, "");
        verdifyTypeName.put(SMS_VERDIFY_TYPE_16, "账号找回");
        verdifyTypeName.put(SMS_VERDIFY_TYPE_17, "语音验证");
    }

    public static final Map<String, String> verdifyTypeSmsType = new LinkedHashMap<String, String>();

    static {
        verdifyTypeSmsType.put(SMS_VERDIFY_TYPE_1, SMS_VERDIFY_CODE_1);
        verdifyTypeSmsType.put(SMS_VERDIFY_TYPE_2, SMS_VERDIFY_CODE_2);
        verdifyTypeSmsType.put(SMS_VERDIFY_TYPE_3, SMS_VERDIFY_CODE_3);
        verdifyTypeSmsType.put(SMS_VERDIFY_TYPE_4, SMS_VERDIFY_CODE_4);
        verdifyTypeSmsType.put(SMS_VERDIFY_TYPE_5, SMS_VERDIFY_CODE_5);
        verdifyTypeSmsType.put(SMS_VERDIFY_TYPE_6, SMS_VERDIFY_CODE_6);
        verdifyTypeSmsType.put(SMS_VERDIFY_TYPE_7, SMS_VERDIFY_CODE_7);
        verdifyTypeSmsType.put(SMS_VERDIFY_TYPE_8, SMS_VERDIFY_CODE_8);
        verdifyTypeSmsType.put(SMS_VERDIFY_TYPE_9, SMS_VERDIFY_CODE_9);
        verdifyTypeSmsType.put(SMS_VERDIFY_TYPE_10, SMS_VERDIFY_CODE);
        verdifyTypeSmsType.put(SMS_VERDIFY_TYPE_11, SMS_VERDIFY_CODE);
        verdifyTypeSmsType.put(SMS_VERDIFY_TYPE_13, SMS_VERDIFY_CODE_13);
        verdifyTypeSmsType.put(SMS_VERDIFY_TYPE_16, SMS_VERDIFY_CODE);
        verdifyTypeSmsType.put(SMS_VERDIFY_TYPE_17, SMS_VERDIFY_CODE_17);
    }

    /**
     * 系统参数
     */
    public static final String WS_APPLICATION_STRICT = "WS_APPLICATION_STRICT";

    /**
     * 该产品 银行卡审批通  是否发送 消息去 验证 归属地
     */
    public static final String SEPARATOR3 = "_";

    /**
     * 限制接口访问的包路径
     */
    public static final String SITE_ACCESS_PAKAGE = "com.cm.endpoint.site";

    //操作类型
    public static final String CREATE = "create";
    public static final String UPDATE = "update";

    /**
     * 产品ID的RedisHash key
     */
    public static final String PRODUCT_PRODUCT_IDS = "PRODUCT_IDS";

    //标签-规则关系 redis key
    public static final String LABEL_RULE_KEY = "risk:label:rule";
    //用户标签 redis key
    public static final String CUSTOMER_LABEL_KEY = "risk:customer:label";
    // Redis Key 分隔符
    public static final String SEPARATOR_REDIS_GROUP_KEY = ":";
    public static final String[] EFFECT_PRODUCTS = {"C66"};

    // Redis 中 Hash 值
    public static class WSRedisHash {
        public static final String PRODUCT_CONSTANTS = "ws:product_constants";
        public static final String DICT_ITEM = "ws:dict_item";
        public static final String ENDPOINT_SUM = "ws:endpoint_sum";
        public static final String HEALTH = "ws:health";
        public static final String PRODUCT_CONSTANTS_ID = "ws:product_constants:id";
    }

    // Redis Expire Time, 单位: 秒
    public static class WSRedisExpireTime {
        public static final long SECOND = 1;
        public static final long MINUTE = 60;
        public static final long HOUR = MINUTE * 60;
        public static final long DAY = HOUR * 24;
        public static final long MONTH = DAY * 30;
        public static final long PRODUCT_CONSTANTS = MONTH * 1;
        public static final long PRODUCT_CONSTANTS_ID = DAY * 1;
        public static final long DICT_ITEM = DAY * 1;
        public static final long HEALTH = DAY * 1;
        public static final long FIVE_MINUTES = 5 * 60;
        public static final long SIX_MINUTES = 6 * 60;
    }


    /**
     * W365站添加
     **/
    public static final String MULTI_PRODUCT_CONVERT = "multi.product.convert";
    public static final String MULTI_PRODUCT_SETTING = "multi.product.setting";
    public static final String WS_PRODUCT_ID = "ws.product.id";

    // 更新读库SQL本地缓存TOPIC
    public static final String CACHE_NAME_PRODUCT_CONSTANTS = "pConstant";


    // 以分配
    public static final int DISPATCH_STATUS_ASSIGN = 1;
    // 以接受

    public static final String DISPATCH_ORDER_KYC = "KYC";


    public static final String DISPATCH_KYC_LOCK_SUFFIX = "dispatch_kyc_lock";
    /**
     * kyc校验结果
     */
    public static final String KYC_VALID_EXISTS = "kyc:valid:%s:%s";

    public static class LabelKey {
        //用户风控标签-白名单
        public static final String RISK_WHITE_LIST = "RISK_WHITE_LIST";
        //用户风控标签-普通用户
        public static final String RISK_REGULAR = "RISK_REGULAR";
        public static final String RISK_ACCOUNT_HIGH = "RISK_ACCOUNT_HIGH";
        public static final String RISK_ACCOUNT_MEDIUM = "RISK_ACCOUNT_MEDIUM";
        // 关注
        public static final String RISK_FOCUS = "RISK_FOCUS";
        // 套利客
        public static final String RISK_ARBITRAGE_USERS = "RISK_ARBITRAGE_USERS";
        // 黑名单
        public static final String RISK_BLACKLIST = "RISK_BLACKLIST";

    }

    public static class MqConstants{
        public static final String TRANSFER_EXCHANGE = "exchange_risk_withdraw_apply_transfer";
        public static final String TRANSFER_QUEUE = "queue.risk.withdraw.apply.transfer";

        public static final String DLX_EXCHANGE = "exchange_risk_withdraw_apply_dlx";
        public static final String DLX_QUEUE = "queue_risk_withdraw_apply_dlx";
        public static final String DLX_ROUTING_KEY = "routing.risk.withdraw.apply.dlx";
        public static final String RETRY_EXCHANGE = "exchange_risk_withdraw_apply_retry";
        public static final String RETRY_QUEUE = "queue_risk_withdraw_apply_retry";
        public static final String RETRY_ROUTING_KEY = "routing.risk.withdraw.apply.retry";
    }
}
