package com.riskcontrol.cron.mapper;

import com.cn.schema.other.WSMsgMqSendRecord;
import com.cn.schema.other.WSQueryMsgMqSendRecord;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;


/**
 * MQ消息发送记录表数据访问层
 *
 * @author wade
 * @date 2018-08-29 09:52:47.
 */
@Repository
public interface MsgMqDao {

    /**
     * 查询符合条件的信息分页
     *
     * @param query 查询条件
     * @return List<WSMsgMqSendRecord> MQ消息发送记录表列表
     */
    List<WSMsgMqSendRecord> queryPageMsgMqByCondition(WSQueryMsgMqSendRecord query);

    /**
     * 根据ID查询信息
     *
     * @param id 主键
     * @return WSMsgMqSendRecord
     */
    WSMsgMqSendRecord loadMsgMqById(@Param("id") String id);

    /**
     * 新增信息.返回操作结果
     *
     * @param bean MQ消息发送记录表
     * @return Integer
     */
    Integer createMsgMq(WSMsgMqSendRecord bean);

    /**
     * 删除
     *
     * @param map
     * @return
     */
    int deleteById(Map map);

}