package com.riskcontrol.cron.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.math.BigInteger;
import java.util.Date;

/**
 * 结果
 */
@TableName(value = "t_pbc_crawler_result")
public class TPbcCrawlerResult {
    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private BigInteger id;

    /**
     * 查询关键字主键
     */
    @TableField(value = "source_id")
    private String sourceId;

    /**
     * 地址
     */
    @TableField(value = "url")
    private String url;

    /**
     * 用户ID
     */
    @TableField(value = "user_id")
    private String userId;

    /**
     * 用户名
     */
    @TableField(value = "user_name")
    private String userName;

    /**
     * 生日
     */
    @TableField(value = "birth_date")
    private String birthDate;

    @TableField(value = "banned_lifted_by")
    private String bannedLiftedBy;

    @TableField(value = "registered_on")
    private String registeredOn;

    @TableField(value = "banned_lifted_on")
    private String bannedLiftedOn;

    /**
     * 创建时间
     */
    @TableField(value = "create_date")
    private Date createDate;

    /**
     * 修改时间时间
     */
    @TableField(value = "modify_date")
    private Date modifyDate;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public BigInteger getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(BigInteger id) {
        this.id = id;
    }

    /**
     * 获取查询关键字主键
     *
     * @return source_id - 查询关键字主键
     */
    public String getSourceId() {
        return sourceId;
    }

    /**
     * 设置查询关键字主键
     *
     * @param sourceId 查询关键字主键
     */
    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    /**
     * 获取地址
     *
     * @return url - 地址
     */
    public String getUrl() {
        return url;
    }

    /**
     * 设置地址
     *
     * @param url 地址
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * 获取用户ID
     *
     * @return user_id - 用户ID
     */
    public String getUserId() {
        return userId;
    }

    /**
     * 设置用户ID
     *
     * @param userId 用户ID
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * 获取用户名
     *
     * @return user_name - 用户名
     */
    public String getUserName() {
        return userName;
    }

    /**
     * 设置用户名
     *
     * @param userName 用户名
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * 获取生日
     *
     * @return birth_date - 生日
     */
    public String getBirthDate() {
        return birthDate;
    }

    /**
     * 设置生日
     *
     * @param birthDate 生日
     */
    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    /**
     * @return banned_lifted_by
     */
    public String getBannedLiftedBy() {
        return bannedLiftedBy;
    }

    /**
     * @param bannedLiftedBy
     */
    public void setBannedLiftedBy(String bannedLiftedBy) {
        this.bannedLiftedBy = bannedLiftedBy;
    }

    /**
     * @return registered_on
     */
    public String getRegisteredOn() {
        return registeredOn;
    }

    /**
     * @param registeredOn
     */
    public void setRegisteredOn(String registeredOn) {
        this.registeredOn = registeredOn;
    }

    /**
     * @return banned_lifted_on
     */
    public String getBannedLiftedOn() {
        return bannedLiftedOn;
    }

    /**
     * @param bannedLiftedOn
     */
    public void setBannedLiftedOn(String bannedLiftedOn) {
        this.bannedLiftedOn = bannedLiftedOn;
    }

    /**
     * 获取创建时间
     *
     * @return create_date - 创建时间
     */
    public Date getCreateDate() {
        return createDate;
    }

    /**
     * 设置创建时间
     *
     * @param createDate 创建时间
     */
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    /**
     * 获取修改时间时间
     *
     * @return modify_date - 修改时间时间
     */
    public Date getModifyDate() {
        return modifyDate;
    }

    /**
     * 设置修改时间时间
     *
     * @param modifyDate 修改时间时间
     */
    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }
}