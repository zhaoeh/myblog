package com.riskcontrol.cron.engine;

import com.cn.schema.request.WSWithdrawalRequests;
import com.riskcontrol.cron.entity.RiskFilterLog;
import com.riskcontrol.cron.support.FiConsumer;
import lombok.Data;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @description: 取款消息上下文
 * @author: ErHu.Zhao
 * @create: 2024-09-26
 **/
@Data
public class OriWithdrawReqContext {

    /**
     * 取款订单链 key:requestId value:订单实例
     */
    private Map<String, WSWithdrawalRequests> orderChain = new ConcurrentHashMap<>(4);
    /**
     * 日志记录器
     */
    private FiConsumer<Boolean, Boolean, String, RiskFilterLog> riskFilterLogger;
    /**
     * 是否忽略记录风控日志
     */
    private boolean ignoreLogger;
    /**
     * 当前任务是否被任务线程开始执行
     */
    private boolean isEnterTaskPool;

    /**
     * 当前任务是否已经被人工处理
     */
    private boolean isManuallyExecuted;
}
