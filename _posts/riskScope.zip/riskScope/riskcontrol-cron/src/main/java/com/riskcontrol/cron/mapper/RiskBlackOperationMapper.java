package com.riskcontrol.cron.mapper;


import com.riskcontrol.common.entity.request.ekyc.TRiskBlackOperation;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author Heng.zhang
 */
@Mapper
public interface RiskBlackOperationMapper extends BaseMapperX<TRiskBlackOperation> {

}
