package com.riskcontrol.cron.engine.node;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.date.TimeInterval;
import com.cn.schema.creditlogs.WSCreditLogs;
import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.engine.WithdrawContext;
import com.riskcontrol.cron.service.CreditLogService;
import com.yomahub.liteflow.annotation.LiteflowComponent;
import com.yomahub.liteflow.core.NodeComponent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.List;

/**
 * 查询取款金额
 * @author dante
 */
@LiteflowComponent("calcDstAmountNode")
@Slf4j
public class CalcDstAmountNode extends AbstractWhenNode {
    @Autowired
    private CreditLogService creditLogService;
    @Override
    public void processWhen() throws Exception {
        WithdrawContext context = this.getFirstContextBean();
        OriWithdrawReq req = context.getReq();

        TimeInterval timer = DateUtil.timer();
        BigDecimal dstAmount = BigDecimal.ZERO;
        BigDecimal withdrawalRequestsAmount = req.getAmount();

        com.cn.schema.creditlogs.WSQueryCreditLogs creditLogs = new com.cn.schema.creditlogs.WSQueryCreditLogs();
        creditLogs.setProductId(req.getProductId());
        creditLogs.setLoginName(req.getLoginName());
        creditLogs.setReferenceId(req.getRequestId());

        List<WSCreditLogs> creditLogsList = creditLogService.getCreditLogs(creditLogs);
        log.info("取款申请withdrawRisk loginName:{} getCreditLogs Timer {} ms", req.getLoginName(), timer.intervalRestart());
        if (creditLogsList != null && creditLogsList.size() == 1) {
            dstAmount = new BigDecimal(creditLogsList.get(0).getDstAmount());
        }

        context.setDstAmount(dstAmount);
        context.setWithdrawalRequestsAmount(withdrawalRequestsAmount);
    }
}
