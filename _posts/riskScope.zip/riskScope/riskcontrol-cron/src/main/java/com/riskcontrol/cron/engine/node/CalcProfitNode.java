package com.riskcontrol.cron.engine.node;

import com.riskcontrol.cron.engine.WithdrawContext;
import com.yomahub.liteflow.annotation.LiteflowComponent;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * 盈利率
 * @author dante
 */
@LiteflowComponent("calcProfitNode")
@Slf4j
public class CalcProfitNode extends AbstractWhenNode {
    @Override
    public void processWhen() throws Exception {
        WithdrawContext context = this.getFirstContextBean();
        BigDecimal profit = BigDecimal.ZERO;;
        if (context.getWinOrLostAmount().compareTo(BigDecimal.ZERO) != 0 && context.getValidAccount().compareTo(BigDecimal.ZERO) > 0) {
            profit = context.getWinOrLostAmount().multiply(new BigDecimal(100)).divide(context.getValidAccount(), 2, RoundingMode.HALF_UP);
        }
        context.setProfit(profit);
    }
}
