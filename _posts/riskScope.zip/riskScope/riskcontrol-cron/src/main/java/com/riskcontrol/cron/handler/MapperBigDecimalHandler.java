package com.riskcontrol.cron.handler;

import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedTypes;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@MappedTypes({String.class, BigDecimal.class})
public class MapperBigDecimalHandler extends BaseTypeHandler<String> {

    @Override
    public String getNullableResult(ResultSet resultSet, String s) throws SQLException {
        return convertDecimalStr(resultSet.getBigDecimal(s));
    }

    @Override
    public String getNullableResult(ResultSet resultSet, int i) throws SQLException {
        return convertDecimalStr(resultSet.getBigDecimal(i));
    }

    @Override
    public String getNullableResult(CallableStatement callableStatement, int i) throws SQLException {
        return convertDecimalStr(callableStatement.getBigDecimal(i));
    }

    @Override
    public void setNonNullParameter(PreparedStatement preparedStatement, int i, String s, JdbcType jdbcType) throws SQLException {

    }

    @Override
    public String getResult(ResultSet rs, String columnName) throws SQLException {
        String r = super.getResult(rs, columnName);
        return StringUtils.isEmpty(r) ? BigDecimal.ZERO.toPlainString() : r;
    }

    @Override
    public String getResult(ResultSet rs, int columnIndex) throws SQLException {
        String r = super.getResult(rs, columnIndex);
        return StringUtils.isEmpty(r) ? BigDecimal.ZERO.toPlainString() : r;
    }

    @Override
    public String getResult(CallableStatement cs, int columnIndex) throws SQLException {
        String r = super.getResult(cs, columnIndex);
        return StringUtils.isEmpty(r) ? BigDecimal.ZERO.toPlainString() : r;
    }

    /**
     * 转换big decimal
     *
     * @param val
     * @return
     */
    private String convertDecimalStr(BigDecimal val) {
        try {
            return StringUtils.isEmpty(val) ? BigDecimal.ZERO.toPlainString() : val.toPlainString();
        } catch (Exception e) {
            return BigDecimal.ZERO.toPlainString();
        }

    }
}
