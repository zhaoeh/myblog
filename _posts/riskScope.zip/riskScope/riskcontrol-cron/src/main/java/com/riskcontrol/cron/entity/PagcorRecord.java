package com.riskcontrol.cron.entity;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

import java.util.Date;

/**
 * @author: sanji
 * @desc: pagcor 黑名单数据
 * @date: 2024/6/5 15:18
 */
@Data
public class PagcorRecord {
    private String lastName;
    private String middleName;
    private String firstName;
    private String isBanned; //是否封禁
    @JSONField(format = "M/d/yyyy hh:mm:ss")
    private Date birthDate;
    private String dateCreated;
    private String guestExtId;
    private String source;
    /**
     * {
     *         "BirthDate": "9/18/1983 12:00:00 AM",
     *         "LastName": "De Guzman",
     *         "IsBanned": "False",
     *         "DateLastEntry": "4/18/2017 8:08:52 AM",
     *         "Source": "Banned",
     *         "EnrolledBranch": "Rafael A. Tabora 03 (T2 RAF Electronic Gaming Station)",
     *         "DateCreated": "4/18/2017 8:08:52 AM",
     *         "GuestExtId": "LAG0210-17-023570",
     *         "MiddleName": "Rodavia",
     *         "FirstName": "Joniefer",
     *         "GuestIdx": "23570"
     *     },
     */
}
