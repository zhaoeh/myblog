package com.riskcontrol.cron.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.riskcontrol.cron.entity.TPbcCrawlerResult;

public interface TPbcCrawlerResultMapper extends BaseMapper<TPbcCrawlerResult> {
}