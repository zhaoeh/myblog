package com.riskcontrol.cron.controller;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @description:
 * @author: ErHu.Zhao
 * @create: 2024-09-19
 **/
@Data
@Builder
public class TestWithDrawVO {

    private String exchange;
    private String routingKey;
    private String productId;
    @NotBlank
    private String requestIds;
}
