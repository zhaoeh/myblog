package com.riskcontrol.cron.config;

import com.riskcontrol.cron.constants.CronConstant;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.support.ConsumerTagStrategy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

/**
 * @author Dominik.X
 * @description
 * @date 2018/12/12 15:46
 */
@Configuration
@Conditional(ConditonOnExcludeThirdpart.class)
public class RabbitConfig {

    private static final String VIRTUAL_HOST = "/";

    @Value("${spring.rabbitmq.username}")
    private String userName;

    @Value("${spring.rabbitmq.password}")
    private String password;

    @Value("${spring.rabbitmq.host}")
    private String url;

    @Value("${spring.rabbitmq.port}")
    private int port;
    @Value("${spring.rabbitmq.checkTimeout:10000}")
    private int checkTimeout;
    @Value("${spring.rabbitmq.chaheSize:50}")
    private int chaheSize;

    @Value("${spring.rabbitmq.ttl:5}")
    private int messageTtl;


    @Bean
    public ConnectionFactory rabbitConnectionFactory() {
        CachingConnectionFactory connectionFactory = new CachingConnectionFactory();
        connectionFactory.setPort(port);
        connectionFactory.setHost(url);
        connectionFactory.setUsername(userName);
        connectionFactory.setPassword(password);
        connectionFactory.setVirtualHost(VIRTUAL_HOST);
        connectionFactory.setChannelCacheSize(chaheSize);
        connectionFactory.setChannelCheckoutTimeout(checkTimeout);
        connectionFactory.setPublisherConfirms(true);
        return connectionFactory;
    }

    @Bean("rabbitMq")
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public RabbitTemplate rabbitTemplate(ConnectionFactory rabbitConnectionFactory) {
        return new RabbitTemplate(rabbitConnectionFactory);
    }

    @Bean
    public RabbitAdmin rabbitAdmin(ConnectionFactory rabbitConnectionFactory) {
        RabbitAdmin rabbitAdmin = new RabbitAdmin(rabbitConnectionFactory);
        rabbitAdmin.setIgnoreDeclarationExceptions(true);
        return rabbitAdmin;
    }

    /**
     * 创建分发交换器
     */
    @Bean("exchange_withdraw_apply")
    public Exchange withdrawApplyExchange() {
        return ExchangeBuilder.topicExchange("exchange_withdraw_apply").durable(true).build();
    }

    /**
     * 不配置这个容器，启动项目时候，rabbitmq的管控台看不到动作
     *
     * @param factory
     * @return
     */
    @Bean
    public SimpleMessageListenerContainer container(ConnectionFactory factory) {
        SimpleMessageListenerContainer container = new SimpleMessageListenerContainer(factory);
        container.setConsumerTagStrategy(new ConsumerTagStrategy() {

            @Override
            public String createConsumerTag(String queue) {
                return null;
            }
        });
        return container;
    }

    /**
     * 死信队列
     */
    @Bean
    @Deprecated
    public Queue dlxQueue() {
        // 消息TTL 5分钟，转发重试队列
        return QueueBuilder.durable(CronConstant.MqConstants.DLX_QUEUE)
                .withArgument("x-message-ttl", messageTtl * 60 * 1000)
                .withArgument("x-dead-letter-exchange", CronConstant.MqConstants.RETRY_EXCHANGE)
                .withArgument("x-dead-letter-routing-key", CronConstant.MqConstants.RETRY_ROUTING_KEY)
                .build();
    }

    /**
     * 死信交换机
     */
    @Bean
    @Deprecated
    public DirectExchange dlxExchange() {
        return ExchangeBuilder.directExchange(CronConstant.MqConstants.DLX_EXCHANGE).durable(true).build();
    }

    /**
     * 绑定死信队列
     */
    @Bean
    @Deprecated
    public Binding dlxBinding() {
        return BindingBuilder.bind(dlxQueue()).to(dlxExchange()).with(CronConstant.MqConstants.DLX_ROUTING_KEY);
    }

}
