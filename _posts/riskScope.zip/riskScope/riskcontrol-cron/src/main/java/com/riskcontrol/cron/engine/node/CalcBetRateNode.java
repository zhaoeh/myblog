package com.riskcontrol.cron.engine.node;

import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.engine.WithdrawContext;
import com.yomahub.liteflow.annotation.LiteflowComponent;
import com.yomahub.liteflow.core.NodeComponent;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.math.RoundingMode;

@LiteflowComponent("calcBetRateNode")
@Slf4j
public class CalcBetRateNode extends AbstractWhenNode {
    @Override
    public void processWhen() throws Exception {
        WithdrawContext context = this.getFirstContextBean();
        BigDecimal betRate;
        if (context.getSumAmount().compareTo(BigDecimal.ZERO) > 0 && context.getValidAccount().compareTo(BigDecimal.ZERO) > 0) {
            betRate = context.getSumAmount().multiply(new BigDecimal(100)).divide(context.getValidAccount(), 2, RoundingMode.HALF_UP);
        } else {
            betRate = BigDecimal.ZERO;
        }
        context.setBetRate(betRate);
    }
}
