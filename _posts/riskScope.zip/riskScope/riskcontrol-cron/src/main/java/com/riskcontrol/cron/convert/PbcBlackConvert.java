package com.riskcontrol.cron.convert;

import com.cn.schema.customers.WSCustomers;
import com.riskcontrol.common.entity.pojo.Ekyc;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.cron.convert.component.MappingConditions;
import com.riskcontrol.cron.entity.TRiskBlack;
import org.mapstruct.*;
import org.mapstruct.factory.Mappers;

/**
 * @description: 转换器
 * @author: ErHu.Zhao
 * @create: 2024-09-24
 **/
@Mapper(uses = MappingConditions.class, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface PbcBlackConvert {

    PbcBlackConvert INSTANT = Mappers.getMapper(PbcBlackConvert.class);

    /**
     * 将source转换为TRiskBlack
     *
     * @param source 源对象
     * @return 转换后的对象
     */
    @Mappings({
            @Mapping(target = "id", ignore = true),
            @Mapping(target = "phoneMd5", ignore = true),
            @Mapping(source = "loginName", target = "loginName", ignore = true),
            @Mapping(source = "firstName", target = "firstName", ignore = true),
            @Mapping(source = "middleName", target = "middleName", ignore = true),
            @Mapping(source = "lastName", target = "lastName", ignore = true),
            @Mapping(source = "birthday", target = "birthday", ignore = true),
            @Mapping(source = "ipAddress", target = "registerIp"),
            @Mapping(source = "lastLoginIp", target = "loginIp"),
            @Mapping(source = "firstIdType", target = "idType", defaultValue = "0"),
            @Mapping(source = "firstNoType", target = "idNo"),
            @Mapping(source = "phone", target = "phoneNumber"),
            @Mapping(source = "email", target = "email"),
            @Mapping(target = "bankAccountNo", ignore = true)
    })
    void copyValidatedProperties(WSCustomers source, @MappingTarget TRiskBlack target);


    /**
     * 将source转换为TRiskBlack*
     *
     * @param source
     * @return
     */
    @Mappings({
            @Mapping(target = "id", ignore = true),
            @Mapping(source = "loginName", target = "loginName"),
            @Mapping(source = "firstName", target = "firstName"),
            @Mapping(source = "middleName", target = "middleName"),
            @Mapping(source = "lastName", target = "lastName"),
            @Mapping(source = "birthday", target = "birthday"),
            @Mapping(target = "createDate", ignore = true),
            @Mapping(target = "createBy", ignore = true),
            @Mapping(target = "updateDate", ignore = true),
            @Mapping(target = "updateBy", ignore = true),
            @Mapping(target = "remark", ignore = true),
            @Mapping(target = "status", ignore = true)
    })
    void copyValidatedProperties(Ekyc source, @MappingTarget TRiskBlack target);

    /**
     * 将source转换为TRiskBlack*
     *
     * @param source
     * @return
     */
    @Mappings({
            @Mapping(target = "id", ignore = true),
            @Mapping(source = "loginName", target = "loginName"),
            @Mapping(source = "firstName", target = "firstName"),
            @Mapping(source = "middleName", target = "middleName"),
            @Mapping(source = "lastName", target = "lastName"),
            @Mapping(source = "birthday", target = "birthday"),
            @Mapping(target = "createDate", ignore = true),
            @Mapping(target = "createBy", ignore = true),
            @Mapping(target = "updateDate", ignore = true),
            @Mapping(target = "updateBy", ignore = true),
            @Mapping(target = "remark", ignore = true),
            @Mapping(target = "status", ignore = true)
    })
    void copyValidatedProperties(KycRequest source, @MappingTarget TRiskBlack target);


}
