package com.riskcontrol.cron.kafka;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.common.annotation.LogUUID;
import com.riskcontrol.cron.constants.CronConstant;
import com.riskcontrol.cron.entity.TLogRecord;
import com.riskcontrol.cron.service.LogRecordService;
import com.riskcontrol.cron.service.MessageRecordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/8/14 17:31
 */
@Component
@Slf4j
public class PhoneNumberBlackListListener {
    @Resource
    private MessageRecordService messageRecordService;

    @Resource
    private LogRecordService logRecordService;


    @KafkaListener(topics = {KafkaTopic.UPDATE_CUSTOMER_INFO_TOPIC},groupId = "group_risk_customer_info",
            containerFactory = "batchFactory",  errorHandler = "myConsumerAwareErrorHandler")
    @LogUUID
    public void phoneNumberBlacklistListener(JSONObject msgContentObj, Acknowledgment ack) {
        if (msgContentObj == null) {
            log.info("手机号码更新消息为空");
            return;
        }
        log.info("phoneNumberBlacklistListener kafka msgBody={}", msgContentObj.toJSONString());
        String flagStr = "flag";
        String flag = null;
        JSONObject msg = new JSONObject();
        msg.put("msgContent",msgContentObj);
        try {

            flag = msgContentObj.getString(flagStr);
//            if (StrUtil.isNotBlank(uuid)){
//                TMessageRecord messageRecord = messageRecordService.getMessageRecordByUUID(uuid);
//                if (messageRecord != null) {
//                    // 消息中的uuid已存在消息表中，将记录加入日志表
//                    saveLogRecord(LogRecordTypeEnum.WARN.getValue(), msg.toJSONString(), uuid,"uuid exist", null);
//                    log.info("phoneNumberBlacklistListener msgContentUUID={} exist ", uuid);
//                } else {
//                    messageRecordService.saveMessageRecord(msg.toJSONString());
//                }
//            }
            log.info("phoneNumberBlacklistListener  flag={} start", flag);
            if ("17".equals(flag)) { //修改手机号
                messageRecordService.checkMessageRecord(msg.toJSONString());
            }
        } catch (Exception e) {
//            messageRecordService.updateStatusByUUID(uuid, MessageRecordStatusEnum.CONSUMPTION_FAILURE.getValue());
//            saveLogRecord(LogRecordTypeEnum.ERROR.getValue(), msg.toJSONString(), uuid, "exception", e.toString());
            log.info("phoneNumberBlacklistListener 手机号码消息数据异常，处理失败, error={}", e.toString());
        }finally {
            ack.acknowledge();
        }
        log.info("phoneNumberBlacklistListener uuid={}， flag={} end", flag);
    }


    /**
     * 记录日志 *
     *
     * @param logRecordType 日志记录类型
     * @param receiveParam  接收参数
     * @param uuid          消息中的uuid，用于检查时快速匹配数据
     * @param remark        日志备注
     * @param logMsg        logMsg
     */
    private void saveLogRecord(String logRecordType, String receiveParam, String uuid, String remark, String logMsg) {
        // 消息中的uuid已存在消息表中，将记录加入日志表
        TLogRecord tLogRecord = new TLogRecord();
        tLogRecord.setModuleName(CronConstant.DOMAIN_NAME)
                .setLocation("PhoneNumberBlacklistListener")
                .setType(logRecordType)
                .setReceiveParam(receiveParam)
                .setLogMessage(logMsg)
                .setRemark(remark + ", UUID：" + uuid);
        logRecordService.save(tLogRecord);
    }
}
