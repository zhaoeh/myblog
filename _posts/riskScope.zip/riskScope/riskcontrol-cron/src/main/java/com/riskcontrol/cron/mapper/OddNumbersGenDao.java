package com.riskcontrol.cron.mapper;

import com.cn.schema.request.WSOddNumbersGen;
import com.cn.schema.request.WSQueryOddNumbersGen;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 单号生成数据访问层
 *
 * @author wade
 * @date 2019-02-22 14:24:01.
 */
@Repository
public interface OddNumbersGenDao {

    /**
     * 查询符合条件的数量
     *
     * @param query 查询条件
     * @return Integer 符合条件的数量
     * @throws Exception
     */
    Integer countOddNumbersGenByCondition(WSQueryOddNumbersGen query);

    /**
     * 查询符合条件的信息分页
     *
     * @param query 查询条件
     * @return List<WSOddNumbersGen> 单号生成列表
     * @throws Exception
     */
    List<WSOddNumbersGen> queryPageOddNumbersGenByCondition(WSQueryOddNumbersGen query);

    /**
     * 根据ID查询信息
     *
     * @param id 主键
     * @return WSOddNumbersGen
     * @throws Exception
     */
    WSOddNumbersGen loadOddNumbersGenById(@Param("id") String id);

    /**
     * 修改信息.返回操作结果
     *
     * @param bean 单号生成
     * @return Integer
     * @throws Exception
     */
    Integer modifyOddNumbersGen(WSOddNumbersGen bean);

    /**
     * 新增信息.返回操作结果
     *
     * @param bean 单号生成
     * @return Integer
     * @throws Exception
     */
    Integer createOddNumbersGen(WSOddNumbersGen bean);

    /**
     * 根据类型查询记录
     *
     * @param productId   产品ID
     * @param requestType 请求类型:01、02
     * @param serialType  单号类型：1=提案类单号；2=转账类单号
     * @return
     */
    WSOddNumbersGen lockAndLoadOddNumbersGenByType(@Param("productId") String productId, @Param("requestType") String requestType, @Param("serialType") String serialType);

    /**
     * 根据类型查询记录
     *
     * @param productId   产品ID
     * @param requestType 请求类型:01、02
     * @param serialType  单号类型：1=提案类单号；2=转账类单号
     * @return
     */
    WSOddNumbersGen loadOddNumbersGenByType(@Param("productId") String productId, @Param("requestType") String requestType, @Param("serialType") String serialType);
}