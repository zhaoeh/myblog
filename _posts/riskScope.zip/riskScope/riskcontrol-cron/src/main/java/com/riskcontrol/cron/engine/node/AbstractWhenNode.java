package com.riskcontrol.cron.engine.node;

import com.riskcontrol.cron.engine.WithdrawContext;
import com.yomahub.liteflow.core.NodeComponent;
import org.slf4j.MDC;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/6/4 14:33
 */
public abstract class  AbstractWhenNode extends NodeComponent {

    @Override
    public void process() throws Exception {
        WithdrawContext context = this.getFirstContextBean();
        MDC.put("uuid",context.getUuid());
        this.processWhen();
    }

    public abstract void processWhen() throws Exception;
}
