package com.riskcontrol.cron.engine.node;

import com.riskcontrol.cron.engine.OriWithdrawReq;
import com.riskcontrol.cron.engine.WithdrawContext;
import com.riskcontrol.cron.enums.WithdrawFilterEnum;
import com.yomahub.liteflow.annotation.LiteflowComponent;
import com.yomahub.liteflow.core.NodeIfComponent;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@LiteflowComponent("globleCheckNode")
@Slf4j
public class GlobleCheckNode extends NodeIfComponent {
    @Override
    public boolean processIf() throws Exception{
        WithdrawContext context = this.getFirstContextBean();
        OriWithdrawReq req = context.getReq();
        String parentLoginName = req.getParent();


        boolean isTestCustomer = "a000001".equals(parentLoginName);
        boolean bool = context.isWithdrawRiskKey() && !"98".equals(req.getCatalog()) && !isTestCustomer;
        if (!bool){
            // 开关关闭情况前端特殊处理，仅传入Type信息，不需要传入filterMsg信息！！！不要设置context.setExceptionPrompt
            context.setExceptionPromptType(WithdrawFilterEnum.WITHDRAW_RISK_CLOSE.getType());
            log.info("取款风控JMS_WITHDRAW_RISK开关:"+context.isWithdrawRiskKey()+";catalog:"+req.getCatalog()+";是否测试用户："+isTestCustomer);
//        }else{
//            //判断是否在90天内
//            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
//            LocalDate sd = LocalDate.parse(req.getLastWithDrawalDate(), dateTimeFormatter);
//            LocalDate ed = LocalDate.parse(req.getCreatedDate(), dateTimeFormatter);
//            bool = ed.toEpochDay() - sd.toEpochDay() < 90;
//            if (!bool){
//                context.setExceptionPromptType(WithdrawFilterEnum.THEN_90_DAY.getType());
//                context.setExceptionPrompt(WithdrawFilterEnum.THEN_90_DAY.getFilterMsg());
//            }
        }
        return bool;
    }
}
