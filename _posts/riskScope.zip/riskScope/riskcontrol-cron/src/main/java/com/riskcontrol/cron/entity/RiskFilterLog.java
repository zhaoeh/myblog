package com.riskcontrol.cron.entity;

import java.io.Serializable;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import java.util.Date;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * 风控拦截日志表(t_risk_filter_log)实体类
 *
 * @author dante
 * @since 2024-04-18 16:45:29
 * @description 由 Mybatisplus Code Generator 创建
 */
@Data
@NoArgsConstructor
@Accessors(chain = true)
@TableName("t_risk_filter_log")
@ApiModel(value = "RiskFilterLog对象", description = "风控拦截日志表")
public class RiskFilterLog extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 拦截类型
     */
    private String filterType;
    /**
     * 拦截状态 0初始 1已放行 2待审核 3已拦截
     */
    private Integer status;
    /**
     * 风控决策（风控决策）
     */
    private String riskRuleAction;
    /**
     * 拦截原因
     */
    private String filterReason;
    /**
     * 拦截来源
     */
    private String source;
    /**
     * 通知状态 0未通知 1已通知
     */
    private Integer notifyStatus;
    /**
     * 审核时间
     */
    private Date auditTime;
    /**
     * 通知完成时间
     */
    private Date completeTime;
    /**
     * 异常信息
     */
    private String errorMsg;
    /**
     * 拦截对象
     */
    private String requestJson;
    /**
     * 请求id
     */
    private String requestId;
    /**
     * 重试次数
     */
    private Integer retryNum;

}