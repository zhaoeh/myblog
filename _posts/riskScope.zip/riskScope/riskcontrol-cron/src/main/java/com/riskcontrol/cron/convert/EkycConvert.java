package com.riskcontrol.cron.convert;

import com.riskcontrol.common.entity.pojo.Ekyc;
import com.riskcontrol.common.entity.pojo.EkycRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycExtendRequest;
import com.riskcontrol.cron.convert.component.MappingConditions;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.factory.Mappers;

/**
 * @description: ekyc实体属性转换器
 * @author: ErHu.Zhao
 * @create: 2024-10-24
 **/
@Mapper(uses = MappingConditions.class, nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface EkycConvert {

    EkycConvert INSTANT = Mappers.getMapper(EkycConvert.class);

    /**
     * 拷贝源对象中有效属性给目标对象*
     *
     * @param source 源对象
     * @param target 目标对象
     */
    void copyValidatedProperties(EkycExtendRequest source, @MappingTarget Ekyc target);


    /**
     * 拷贝源对象中有效属性给目标对象*
     *
     * @param source 源对象
     * @param target 目标对象
     */
    void copyValidatedProperties(EkycRequest source, @MappingTarget Ekyc target);

}
