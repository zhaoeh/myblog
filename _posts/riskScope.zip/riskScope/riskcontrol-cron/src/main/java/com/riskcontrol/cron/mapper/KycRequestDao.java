package com.riskcontrol.cron.mapper;

import com.cn.schema.customers.QueryKycByConditionRequest;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequest;
import com.riskcontrol.cron.entity.RiskKycRequest;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * @program: riskcontrol-cron
 * @description:
 * @author: Erhu.Zhao
 * @create: 2023-10-04 15:51
 **/
@Repository
public interface KycRequestDao{

    Integer countByCondition(RiskQueryKycRequest query);

    Integer countOfQueryPageByCondition(RiskQueryKycRequest query);

    Integer countOfQueryPageByConditionNotLike(RiskQueryKycRequest query);

    List<KycRequest> queryPageByCondition(RiskQueryKycRequest query);

    int insert(@Param("cid") KycRequest cid);

    int update(RiskKycRequest bean);

    int updateKyc(RiskKycRequest bean);

    /**
     * 统计分配给该用户等待审核的数量
     *
     * @param assignee
     * @return
     */
    int countWaitingPendingByAssignee(@Param("assignee") String assignee);

    /**
     * 修改dispatch状态
     *
     * @param status
     * @param requests
     * @return
     */
    int modifyDispatchStatus(@Param("status") Integer status, @Param("requests") List<KycRequest> requests);

    /**
     * 重置dispatch 状态
     *
     * @param userLoginName
     * @return
     */
    int modifyResetDispatchStatus(@Param("loginName") String userLoginName);

    int countKycByCondition(RiskQueryKycRequest params);

    /**
     * 统计Kyc重复数量-允许middle_name为 null *
     * @param params
     * @return
     */
    int countByConditionKyc(RiskQueryKycRequest params);

    int countByConditionKycNotLike(RiskQueryKycRequest params);

    int countKycPbcByCondition(RiskQueryKycRequest kycParams);

    List<KycRequest> queryKycPbcPageByCondition(RiskQueryKycRequest kycParams);

    KycRequest queryByCondition(QueryKycByConditionRequest request);

    KycRequest queryByConditionWithDesc(Map<String,Object> request);

    List<KycRequest> queryKycByIds(List<String> ids);

    int modifyAssigneeBy(@Param("loginName") String loginName,@Param("ids") List<String> ids);

    Integer countEndingRequest(@Param("productId") String productId, @Param("loginName") String loginName);

    KycRequest queryKycById(@Param("id")String id);
    List<Integer> queryKycStatusByCustomerId(RiskQueryKycRequest params);

    KycRequest queryCurrentKycRequest(RiskQueryKycRequest query);

    List<KycRequest> queryKycForPbcByCondition(@Param("firstNameParam") String firstName, @Param("middleNameParam") String middleName, @Param("lastNameParam") String lastName, @Param("birthDateParam") String birthDate, @Param("statusParam") int status);
}
