package com.riskcontrol.cron.config;

import cn.hutool.core.thread.BlockPolicy;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @description: 异步线程池配置
 * @author: ErHu.Zhao
 * @create: 2024-10-16
 **/
@Configuration
@Slf4j
public class AsyncTaskConfig {

    @Autowired
    private AsyncPropertiesConfig config;

    /**
     * 自定义线程池*
     *
     * @return
     */
    @Bean("customizedExecutorService")
    public ThreadPoolExecutor businessPoolExecutor() {
        return new ThreadPoolExecutor(config.getCorePoolSize(), config.getMaximumPoolSize(),
                0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<Runnable>(config.getBlockQueueSize()), new BlockPolicy());

    }


    @Configuration
    @RefreshScope
    @Data
    public class AsyncPropertiesConfig {

        /**
         * 核心线程数
         */
        @Value("${customized.thread.core-pool-size:5}")
        private int corePoolSize;

        /**
         * 最大线程数
         */
        @Value("${customized.thread.maximum-pool-size:20}")
        private int maximumPoolSize;

        /**
         * 阻塞队列大小
         */
        @Value("${customized.thread.block-queue-size:100}")
        private int blockQueueSize;

    }

}
