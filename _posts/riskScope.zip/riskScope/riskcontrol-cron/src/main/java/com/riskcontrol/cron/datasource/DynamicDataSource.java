package com.riskcontrol.cron.datasource;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

/**
 * 通过继承 AbstractRoutingDataSource 实现动态数据源路由,
 * 基于 DataSourceContextHolder 来选择数据源。
 *
 * @author dante
 */
public class DynamicDataSource extends AbstractRoutingDataSource {

    @Override
    protected Object determineCurrentLookupKey() {
        String x = DbContextHolder.getDbType();
        if (DataSourceType.SLAVE.getName().equals(x)) {
            logger.info("正在使用备库查询数据源:" + x);
        }
        return x;
    }
}