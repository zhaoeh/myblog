//package com.riskcontrol.cron.engine.node;
//
//import cn.hutool.core.date.DateUtil;
//import cn.hutool.core.date.TimeInterval;
//import com.cn.schema.creditlogs.QueryDepositTransWithCheckResponse;
//import com.cn.schema.creditlogs.WSCreditLogs;
//import com.cn.schema.creditlogs.WSQueryDepositTrans;
//import com.cn.schema.request.QueryWithdrawalRequestsResponse;
//import com.cn.schema.request.WSQueryCountPAmount;
//import com.cn.schema.request.WSQueryPromotionRequests;
//import com.cn.schema.request.WSQueryWithdrawalRequests;
//import com.cn.schema.request.WSWithdrawalRequests;
//import com.gw.datacenter.vo.order.OrderReq;
//import com.gw.datacenter.vo.order.OrderSummaryNew;
//import com.gw.datacenter.vo.pagainate.QueryResult;
//import com.gw.datacenter.vo.pagainate.QueryResultWrapper;
//import com.riskcontrol.cron.engine.OriWithdrawReq;
//import com.riskcontrol.cron.engine.WithdrawContext;
//import com.riskcontrol.cron.service.CreditLogService;
//import com.riskcontrol.cron.service.DataCenterService;
//import com.riskcontrol.cron.service.RequestService;
//import com.yomahub.liteflow.annotation.LiteflowComponent;
//import com.yomahub.liteflow.core.NodeComponent;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import java.math.BigDecimal;
//import java.time.LocalDate;
//import java.time.LocalDateTime;
//import java.time.LocalTime;
//import java.time.format.DateTimeFormatter;
//import java.util.ArrayList;
//import java.util.Comparator;
//import java.util.List;
//import java.util.Objects;
//import java.util.stream.Collectors;
//
//@LiteflowComponent("calcBaseDataNode")
//@Slf4j
//public class CalcBaseDataNode extends NodeComponent {
//
//
//    @Autowired
//    private RequestService requestService;
//    @Autowired
//    private CreditLogService creditLogService;
//    @Autowired
//    private DataCenterService centerService;
//
//    @Override
//    public void process() throws Exception {
//        WithdrawContext context = this.getFirstContextBean();
//        OriWithdrawReq req = context.getReq();
//        WSWithdrawalRequests wsWithdrawalRequests = context.getResp();
//
//
//        //查询取款交易记录
//        WSQueryDepositTrans wsQueryDepositTrans = new WSQueryDepositTrans();
//        wsQueryDepositTrans.setProductId(req.getProductId());
//        wsQueryDepositTrans.setLoginName(req.getLoginName());
//        wsQueryDepositTrans.setLastUpdateBegin(req.getLastWithDrawalDate());
//        wsQueryDepositTrans.setLastUpdateEnd(req.getCreatedDate());
//        wsQueryDepositTrans.setDeleteFlag("0");
//        wsQueryDepositTrans.setStatus("2");
//
//        TimeInterval timer = DateUtil.timer();
//        QueryDepositTransWithCheckResponse queryDepositTransWithCheckResponse = requestService.queryDepositTransRecord(wsQueryDepositTrans);
//        log.info("取款申请withdrawRisk loginName:{} queryDepositTransRecord Timer {} ms", req.getLoginName(), timer.intervalRestart());
//        BigDecimal sumAmount = BigDecimal.ZERO;//时间段内总存款额
//        if (queryDepositTransWithCheckResponse != null && StringUtils.isNotBlank(queryDepositTransWithCheckResponse.getAmount())) {
//            sumAmount = new BigDecimal(queryDepositTransWithCheckResponse.getAmount());
//        }
//        BigDecimal dstAmount = BigDecimal.ZERO;
//        BigDecimal fixAmount = BigDecimal.ZERO;
//
//        com.cn.schema.creditlogs.WSQueryCreditLogs creditLogs = new com.cn.schema.creditlogs.WSQueryCreditLogs();
//        creditLogs.setProductId(req.getProductId());
//        creditLogs.setLoginName(req.getLoginName());
//        creditLogs.setReferenceId(req.getRequestId());
//
//        List<WSCreditLogs> creditLogsList = creditLogService.getCreditLogs(creditLogs);
//
//        if (creditLogsList != null && creditLogsList.size() == 1) {
//            dstAmount = new BigDecimal(creditLogsList.get(0).getDstAmount());
//        }
//
//        creditLogs = new com.cn.schema.creditlogs.WSQueryCreditLogs();
//        creditLogs.setProductId(req.getProductId());
//        creditLogs.setLoginName(req.getLoginName());
//        creditLogs.setCreatedDateBegin(req.getLastWithDrawalDate());
//        creditLogs.setCreatedDateEnd(req.getCreatedDate());
//        creditLogs.setTransCode("111301;111300");
//        creditLogs.setPageSize(5000);
//
//        creditLogsList = creditLogService.getCreditLogs(creditLogs);
//        log.info("取款申请withdrawRisk loginName:{} getCreditLogs Timer {} ms", req.getLoginName(), timer.intervalRestart());
//        for (WSCreditLogs creditLog : creditLogsList) {
//            if (creditLog.getTransCode().equals("111301")) {
//                fixAmount = fixAmount.add(new BigDecimal(creditLog.getAmount()));
//            }
//            if (creditLog.getTransCode().equals("111300")) {
//                fixAmount = fixAmount.subtract(new BigDecimal(creditLog.getAmount()));
//            }
//        }
//
//
//        WSQueryPromotionRequests wsQueryPromotionRequest = new WSQueryPromotionRequests();
//        wsQueryPromotionRequest.setProductId(req.getProductId());
//        wsQueryPromotionRequest.setLoginName(req.getLoginName());
//        wsQueryPromotionRequest.setDeleteFlag("0");
//        wsQueryPromotionRequest.setLastUpdateBegin(req.getLastWithDrawalDate());
//        wsQueryPromotionRequest.setLastUpdateEnd(req.getCreatedDate());
//        wsQueryPromotionRequest.setFlag("2");
//        WSQueryCountPAmount wsQueryCountPAmount = requestService.getCountReportPromotion(wsQueryPromotionRequest);
//        log.info("取款申请withdrawRisk loginName:{} getCountReportPromotion Timer {} ms", req.getLoginName(), timer.intervalRestart());
//
//        BigDecimal sumPromotionAmount = BigDecimal.ZERO; //优惠总额
//        if (wsQueryCountPAmount != null && StringUtils.isNotBlank(wsQueryCountPAmount.getSumAmount())) {
//            sumPromotionAmount = new BigDecimal(wsQueryCountPAmount.getSumAmount());
//        } else {
//            wsWithdrawalRequests.setExceptionPromptType("-2");
//            wsWithdrawalRequests.setExceptionPrompt("Risk check error");
//        }
//
//        BigDecimal[] decimals = getValidAccountAndWinOrLostAmount(req.getLastWithDrawalDate(), req.getCreatedDate(), req.getProductId(), req.getLoginName());
//        log.info("取款申请withdrawRisk loginName:{} getValidAccountAndWinOrLostAmount Timer {} ms", req.getLoginName(), timer.intervalRestart());
//        BigDecimal validAccount = decimals[0]; //投注额
//        BigDecimal winOrLostAmount = decimals[1];   //盈利率
//        BigDecimal withdrawalRequestsAmount = req.getAmount();
//        WSQueryWithdrawalRequests queryWithdrawalRequests = new WSQueryWithdrawalRequests();
//        queryWithdrawalRequests.setProductId(req.getProductId());
//        queryWithdrawalRequests.setLoginName(req.getLoginName());
//
//        queryWithdrawalRequests.setCatalog("0;11;12;13;14;15");
//        queryWithdrawalRequests.setPageSize(100);
//        QueryWithdrawalRequestsResponse queryWithdrawalRequestsResponse = requestService.queryWithdrawalRequests(queryWithdrawalRequests);
//
//        List<WSWithdrawalRequests> withdrawalRequestsList = queryWithdrawalRequestsResponse.getWSWithdrawalRequests();
//
//        log.info("取款申请withdrawRisk loginName:{} queryCountWithdrawRequest Timer {} ms", req.getLoginName(), timer.intervalRestart());
//
//        BigDecimal todayLimit = BigDecimal.ZERO;
//        BigDecimal totalPassedAmount = BigDecimal.ZERO;
//        BigDecimal totalPassedCount = BigDecimal.ZERO;
//        if (!withdrawalRequestsList.isEmpty()) {
//            BigDecimal withdrawalAmount = BigDecimal.ZERO;
//            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
//            List<WSWithdrawalRequests> collect = withdrawalRequestsList.stream().filter(Objects::nonNull).filter(w -> LocalDate.parse(w.getCreatedDate(), dateTimeFormatter).equals(LocalDate.now()) && ("1".equals(w.getFlag()) || "2".equals(w.getFlag()))).collect(Collectors.toList());
//            if (!collect.isEmpty()) {
//                double sum = collect.stream().mapToDouble(w -> new BigDecimal(w.getAmount()).doubleValue()).sum();
//                if (sum > 0) {
//                    withdrawalAmount = BigDecimal.valueOf(sum);
//                }
//            }
//            todayLimit = todayLimit.add(withdrawalAmount);
//
//            List<WSWithdrawalRequests> collected = withdrawalRequestsList.stream().filter(Objects::nonNull).filter(w -> !"0".equals(w.getFlag())).collect(Collectors.toList());
//            if (!collected.isEmpty()) {
//                List<WSWithdrawalRequests> sortedWithdrawal = collected.stream().filter(Objects::nonNull).sorted(Comparator.comparing(WSWithdrawalRequests::getCreatedDate).reversed()).collect(Collectors.toList());
//                List<WSWithdrawalRequests> passedList = new ArrayList<>();
//
//                for (WSWithdrawalRequests withdrawalRequests : sortedWithdrawal) {
//                    if ("0".equals(withdrawalRequests.getExceptionPromptType())) {
//                        passedList.add(withdrawalRequests);
//                    } else {
//                        break;
//                    }
//                }
//                totalPassedCount = new BigDecimal(passedList.size());
//                totalPassedAmount = BigDecimal.valueOf(passedList.stream().mapToDouble(w -> Double.parseDouble(w.getAmount())).sum());
//            }
//        }
//        todayLimit = todayLimit.add(req.getAmount());
//
//        context.setSumAmount(sumAmount);
//        context.setTotalPassedAmount(totalPassedAmount);
//        context.setTotalPassedCount(totalPassedCount);
//        context.setTodayLimit(todayLimit);
//        context.setSumPromotionAmount(sumPromotionAmount);
//        context.setWinOrLostAmount(winOrLostAmount);
//        context.setValidAccount(validAccount);
//        context.setFixAmount(fixAmount);
//        context.setDstAmount(dstAmount);
//        context.setWithdrawalRequestsAmount(withdrawalRequestsAmount);
//
//
//        log.info("loginName={} requestId={} withdrawRisk： lastWithDrawlBalance={},lastWithDrawlDate={},sumAmount={},sumPromotionAmount={},winOrLostAmount={},validAccount={},fixAmount={},dstAmount={},todayLimit={}", req.getLoginName(), req.getRequestId(), req.getLastWithDrawalDate(), req.getLastWithDrawalDate(), sumAmount, sumPromotionAmount, winOrLostAmount, validAccount, fixAmount, dstAmount, todayLimit);
//
//    }
//
//    private BigDecimal[] getValidAccountAndWinOrLostAmount(String startTime, String endTime, String productId, String loginName) {
//        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
//        LocalDate start = LocalDate.parse(startTime, dateTimeFormatter);
//        LocalDate end = LocalDate.parse(endTime, dateTimeFormatter);
//        BigDecimal validAccount = BigDecimal.ZERO;
//        BigDecimal winOrLostAmount = BigDecimal.ZERO;
//
//        if (end.toEpochDay() - start.toEpochDay() > 3) {
//            String startToday = LocalDateTime.of(start, LocalTime.MAX).format(dateTimeFormatter);
//            String endToday = LocalDateTime.of(end.minusDays(1), LocalTime.MIN).format(dateTimeFormatter);
//
//
//            OrderReq orderReq = new OrderReq();
//            orderReq.setProductId(productId);
//            orderReq.setLoginName(new String[]{loginName});
//            orderReq.setBeginReckonTime(startTime);
//            orderReq.setEndReckonTime(startToday);
//            QueryResultWrapper result = centerService.getCountTotalStrRecordAndSummaryV2(orderReq);
//            if (result != null && result.getUtilArray() != null) {
//                String[] utilArray = result.getUtilArray();
//                winOrLostAmount = winOrLostAmount.add(new BigDecimal(utilArray[3]));
//                validAccount = validAccount.add(new BigDecimal(utilArray[2]));
//            }
//
//            orderReq.setBeginReckonTime(endToday);
//            orderReq.setEndReckonTime(endTime);
//            QueryResultWrapper result1 = centerService.getCountTotalStrRecordAndSummaryV2(orderReq);
//
//            if (result != null && result1.getUtilArray() != null) {
//                String[] utilArray = result1.getUtilArray();
//                winOrLostAmount = winOrLostAmount.add(new BigDecimal(utilArray[3]));
//                validAccount = validAccount.add(new BigDecimal(utilArray[2]));
//            }
//
//            QueryResult<OrderSummaryNew> summaryNewByLoginName = centerService.getSummaryNewByLoginName(productId, loginName, LocalDateTime.of(start.plusDays(1), LocalTime.MIN).format(dateTimeFormatter), LocalDateTime.of(end.minusDays(2), LocalTime.MIN).format(dateTimeFormatter));
//
//            log.info("summaryNewByLoginName： loginName={}  winOrLostAmount={},validAccount={}", loginName, winOrLostAmount, validAccount);
//
//            if (summaryNewByLoginName != null
//                    && summaryNewByLoginName.getTotalResult() != null
//                    && summaryNewByLoginName.getTotalResult().getTotalWinLostAmount() != null
//                    && summaryNewByLoginName.getTotalResult().getTotalValidAmount() != null) {
//                winOrLostAmount = winOrLostAmount.add(summaryNewByLoginName.getTotalResult().getTotalWinLostAmount());
//                validAccount = validAccount.add(summaryNewByLoginName.getTotalResult().getTotalValidAmount());
//            }
//
//        } else {
//            OrderReq orderReq = new OrderReq();
//            orderReq.setProductId(productId);
//            orderReq.setLoginName(new String[]{loginName});
//            orderReq.setBeginReckonTime(startTime);
//            orderReq.setEndReckonTime(endTime);
//            QueryResultWrapper result = centerService.getCountTotalStrRecordAndSummaryV2(orderReq);
//            if (result != null && result.getUtilArray() != null) {
//                String[] utilArray = result.getUtilArray();
//                winOrLostAmount = winOrLostAmount.add(new BigDecimal(utilArray[3]));
//                validAccount = validAccount.add(new BigDecimal(utilArray[2]));
//            }
//        }
//        return new BigDecimal[]{validAccount, winOrLostAmount};
//    }
//}
