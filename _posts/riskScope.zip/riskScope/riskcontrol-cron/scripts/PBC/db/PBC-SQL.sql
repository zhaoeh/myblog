DROP TABLE IF EXISTS `t_pbc_deploy`;
CREATE TABLE `t_pbc_deploy` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
    `system_id` varchar(20) NOT NULL COMMENT '抓取系统id',
    `system_name` varchar(200) NOT NULL COMMENT '抓取系统名称',
    `main_address` varchar(200) NOT NULL COMMENT '域名地址',
    `sub_address` varchar(200) NOT NULL COMMENT '二级域名地址',
    `user_name` varchar(20) NOT NULL COMMENT '用户名',
    `password` varchar(20) NOT NULL COMMENT '密码',
    `start_time` time DEFAULT NULL COMMENT '开始时间',
    `end_time` time DEFAULT NULL COMMENT '停止时间',
    `frequency` int NOT NULL COMMENT '抓取频率',
    `status` int NOT NULL DEFAULT '1' COMMENT '配置状态 1 enable  0 disable',
    `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `create_by` varchar(64) NOT NULL DEFAULT 'SYSTEM' COMMENT '创建修改人',
    `update_date` datetime NOT NULL COMMENT '修改时间',
    `update_by` varchar(64) DEFAULT NULL COMMENT '最后修改人',
    `delete_date` datetime DEFAULT NULL COMMENT '修改时间',
    `delete_by` varchar(64) DEFAULT NULL COMMENT '删除人',
    `is_valid` varchar(1) NOT NULL DEFAULT 'Y' COMMENT '是否有效Y 有效 N无效',
    PRIMARY KEY (`id`,`system_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4  COMMENT='pbc配置文件';

INSERT INTO `t_pbc_deploy`(`id`, `system_id`, `system_name`, `main_address`, `sub_address`, `user_name`, `password`, `start_time`, `end_time`, `frequency`, `status`, `create_date`, `create_by`, `update_date`, `update_by`, `delete_date`, `delete_by`, `is_valid`) VALUES (1, 'PBC', '风控PBC', 'ndrp.pagcor.ph', 'https://ndrp.pagcor.ph/wfLoginPage.aspx', '19-0000114305', 'Aprillee03!', '10:00:00', '19:00:00', 300, 1, '2023-11-16 11:00:00', 'SYSTEM', '2023-11-16 11:00:00', 'SYSTEM', NULL, '', 'Y');


DROP TABLE IF EXISTS `t_pbc_crawler_result`;
CREATE TABLE `t_pbc_crawler_result` (
    `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `source_id` bigint unsigned DEFAULT NULL COMMENT '查询关键字主键',
    `url` varchar(1024)  DEFAULT NULL COMMENT '地址',
    `user_id` varchar(225)  DEFAULT NULL COMMENT '用户ID',
    `user_name` varchar(225)  DEFAULT NULL COMMENT '用户名',
    `birth_date` varchar(225)  DEFAULT NULL COMMENT '生日',
    `banned_lifted_by` varchar(225)  DEFAULT NULL,
    `registered_on` varchar(225)  DEFAULT NULL,
    `banned_lifted_on` varchar(225)  DEFAULT NULL,
    `create_date` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `modify_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='结果';

