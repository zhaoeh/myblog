-- risk_control_cron.t_risk_label_relationship definition

-- 创建标签关系表
CREATE TABLE `t_risk_label_relationship` (
   `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
   `product_id` varchar(3) DEFAULT NULL COMMENT '所属产品',
   `customer_id` bigint NOT NULL COMMENT '用户ID',
   `risk_label_id` bigint NOT NULL COMMENT '标签ID',
   `risk_label_name` varchar(50) DEFAULT NULL COMMENT '风控标签名称',
   `risk_label_key` varchar(50) NOT NULL COMMENT '风控标签Key',
   `login_name` varchar(30) NOT NULL COMMENT '用户登录名',
   `remark` varchar(150) DEFAULT NULL COMMENT '备注',
   `create_by` varchar(64) DEFAULT NULL COMMENT '创建人',
   `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
   `update_by` varchar(64) DEFAULT NULL COMMENT '最后修改人',
   `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
   PRIMARY KEY (`id`),
   KEY `idx_risk_label_relationship_customer_id` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4  COMMENT='用户标签绑定关系表';

