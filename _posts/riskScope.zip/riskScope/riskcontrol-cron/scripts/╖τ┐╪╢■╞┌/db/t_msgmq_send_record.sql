-- risk_control_cron.t_msgmq_send_record definition

CREATE TABLE `t_msgmq_send_record` (
    `id` bigint NOT NULL AUTO_INCREMENT,
    `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `product_id` varchar(3)  DEFAULT NULL,
    `msg_data` varchar(600)  DEFAULT NULL,
    `msg_type` bigint DEFAULT NULL,
    `jms_queue_name` varchar(50)  DEFAULT NULL,
    `rabbit_exchange_name` varchar(50)  DEFAULT NULL,
    `flag` bigint NOT NULL DEFAULT '0',
    `re_send_times` bigint NOT NULL DEFAULT '0',
    `last_update_date` datetime DEFAULT NULL,
    `remarks` varchar(500)  DEFAULT NULL,
    PRIMARY KEY (`id`),
    CONSTRAINT `SYS_C0011639` CHECK ((`created_date` is not null)),
    CONSTRAINT `SYS_C0011640` CHECK ((`flag` is not null)),
    CONSTRAINT `SYS_C0011641` CHECK ((`re_send_times` is not null))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4  COMMENT='MQ发送记录表';


ALTER TABLE t_msgmq_send_record MODIFY COLUMN id bigint auto_increment NOT NULL COMMENT '主键';
ALTER TABLE t_msgmq_send_record MODIFY COLUMN created_date datetime DEFAULT CURRENT_TIMESTAMP  on update CURRENT_TIMESTAMP NOT NULL COMMENT '创建时间';
ALTER TABLE t_msgmq_send_record MODIFY COLUMN product_id varchar(3)  NULL COMMENT '产品ID';
ALTER TABLE t_msgmq_send_record MODIFY COLUMN msg_data varchar(600)  NULL COMMENT '消息内容';
ALTER TABLE t_msgmq_send_record MODIFY COLUMN msg_type bigint NULL COMMENT '消息类型：1=jms;2=RabbitMQ';
ALTER TABLE t_msgmq_send_record MODIFY COLUMN jms_queue_name varchar(50)  NULL COMMENT 'jms队列名';
ALTER TABLE t_msgmq_send_record MODIFY COLUMN rabbit_exchange_name varchar(50)  NULL COMMENT 'rabbit routing名';
ALTER TABLE t_msgmq_send_record MODIFY COLUMN flag bigint DEFAULT 0 NOT NULL COMMENT '状态：0=等待重发；1=已重发，发送失败；2=已重发，发送成功';
ALTER TABLE t_msgmq_send_record MODIFY COLUMN re_send_times bigint DEFAULT 0 NOT NULL COMMENT '重发次数';
ALTER TABLE t_msgmq_send_record MODIFY COLUMN last_update_date datetime NULL COMMENT '最后更新时间';