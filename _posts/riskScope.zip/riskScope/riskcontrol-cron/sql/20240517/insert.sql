--升级前执行sql
INSERT INTO `t_risk_constants` (`id`, `product_id`, `p_key`, `p_value`, `p_type`, `remarks`, `ip_address`, `is_enable`, `is_deleted`, `create_by`, `create_time`, `update_by`, `update_time`) VALUES (8, 'C66', 'RISK_ACCOUNT_MEDIUM', 'Account medium risk', '0101', '信息安全-中风险用户', '127.0.0.1', 1, 0, 'system', '2024-05-16 17:21:46', NULL, '2024-05-17 09:18:53');
INSERT INTO `t_risk_constants` (`id`, `product_id`, `p_key`, `p_value`, `p_type`, `remarks`, `ip_address`, `is_enable`, `is_deleted`, `create_by`, `create_time`, `update_by`, `update_time`) VALUES (9, 'C66', 'RISK_ACCOUNT_HIGH', 'Account high risk', '0101', '信息安全-高风险用户', '127.0.0.1', 1, 0, 'system', '2024-05-16 17:21:46', NULL, '2024-05-17 09:18:55');



--版本升级完后，同步数据(临时表名以线上为准)
INSERT INTO `t_risk_label_relationship` ( `product_id`, `customer_id`, `risk_label_id`, `risk_label_name`, `risk_label_key`, `login_name`, `remark`, `create_by`, `update_by` )
select t.product_id, t.customer_id, t.risk_label_id, t.risk_label_name, t.risk_label_key, t.login_name, t.remark, t.create_by, t.update_by  from cust_H t