package com.riskcontrol.api.controller;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import com.riskcontrol.api.entity.request.RiskLabelHighDowngradeRequest;
import com.riskcontrol.api.service.RiskConstantsService;
import com.riskcontrol.api.service.RiskLabelService;
import com.riskcontrol.common.entity.request.label.RiskLabelByCustomerIdRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelListRequest;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.api.RiskConstantsRsp;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelRsp;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @program: riskcontrol-api
 * @description: 风控标签
 * @author: Colson
 * @create: 2024-01-11 18:28
 */
@RestController
@RequestMapping("/risk/label")
@Api("风控标签相关接口")
public class RiskLabelController {

    @Resource
    private RiskLabelService riskLabelService;

    @Resource
    private RiskConstantsService riskConstantsService;

    @PostMapping(value = "/queryLabelList")
    @ApiOperation(value = "查询用户标签列表")
    public Response<List<RiskConstantsRsp>> queryLabelList() {
        return Response.body(riskConstantsService.queryRiskLabelAllList());
    }

    @PostMapping("customer/list")
    @ApiOperation(value = "批量查询用户风控标签")
    public Response<List<CustomerRiskLabelRsp>> listCustomerRiskLabel(@Valid @RequestBody RiskLabelListRequest request) {
        return Response.body(riskLabelService.listCustomerRiskLabel(request));
    }

    @PostMapping("customer/detail")
    @ApiOperation(value = "用户风控标签详情")
    @SentinelResource(value = "label_detail", blockHandler = "blockHandler")
    public Response<CustomerRiskLabelRsp> detail(@Valid @RequestBody RiskLabelByCustomerIdRequest request) {
        return Response.body(riskLabelService.getRiskLabelDetail(request));
    }

    @PostMapping("customer/removeLabel")
    @ApiOperation(value = "用户风控标签-高风险标签降级(临时使用)")
    public Response<Boolean> removeLabel(@Valid @RequestBody RiskLabelHighDowngradeRequest request) {
        return Response.body(riskLabelService.removeLabel(request));
    }

}
