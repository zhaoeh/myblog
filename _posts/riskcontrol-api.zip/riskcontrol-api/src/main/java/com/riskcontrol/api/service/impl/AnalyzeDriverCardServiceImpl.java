package com.riskcontrol.api.service.impl;


import com.alibaba.nacos.common.utils.CollectionUtils;
import com.riskcontrol.api.entity.CustomerCard;
import com.riskcontrol.api.service.AnalyzeCardService;
import com.riskcontrol.api.utils.DateUtil;
import com.riskcontrol.api.utils.OCRDataProcessUtils;
import com.riskcontrol.common.enums.CardTypeEnum;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @Auther: yannis
 * @Date: 2023/3/31 17:40
 * @Description: 驾照解析
 */
@Service("driverLicenseService")
public class AnalyzeDriverCardServiceImpl implements AnalyzeCardService {
    private static final Logger logger = LoggerFactory.getLogger(AnalyzeDriverCardServiceImpl.class);
    static final List<String> titleList = Arrays.asList("DRIVER'S LICENSE", "Last Name. First Name. Middle Name", "Sex",
            "Date of Birth", "License No.", "Expiration Date");
    private final String NAMES = "Last Name";
    private final String SEX = "Sex";
    private final String BIRTH_DATE = "Date of Birth";
    private final String ADDRESS = "ADDRESS";
    private final String LICENSE_NO = "License No";


    @Override
    public CustomerCard getRecognitionData(List<String> textList, CardTypeEnum cardTypeEnum) {
        if (CollectionUtils.isEmpty(textList)) {
            return null;
        }
        logger.info("DRIVER'S LICENSE start parsing .....");
        if (CollectionUtils.isEmpty(textList)) {
            return null;
        }
        CustomerCard card = new CustomerCard();
        card.setIdType(cardTypeEnum.getCode());
        int sexTitleIndex = -1;
        int birthTitleIndex = -1;
        int noTitleIndex = -1;
        int nameTitleIndex = -1;


        List<String> valueList = new ArrayList<>();
        for (int i = 0; i < textList.size(); i++) {
            String text = textList.get(i);
            //姓名
            OCRDataProcessUtils.ConvertEntity nameEntity = OCRDataProcessUtils.convertByCategory(text, NAMES, nameTitleIndex, i, null, titleList, valueList, true);
            if (nameEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(nameEntity.getText())) {
                    String names = nameEntity.getText().toUpperCase();
                    OCRDataProcessUtils.ConvertEntity namesConvert = OCRDataProcessUtils.getNamesConvert(names);
                    card.setFirstName(namesConvert.getFirstName());
                    card.setMiddleName(namesConvert.getMiddleName());
                    card.setLastName(namesConvert.getLastName());
                }
                nameTitleIndex = nameEntity.getTitalIndex();
            }
            //性别
            OCRDataProcessUtils.ConvertEntity sexEntity = OCRDataProcessUtils.convertByCategory(text, SEX, sexTitleIndex, i, OCRDataProcessUtils.REGEX_SEX, titleList, valueList);
            if (sexEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(sexEntity.getText())) {
                    String sex = OCRDataProcessUtils.convertBySex(sexEntity.getText());
                    card.setGender(sex);
                }
                sexTitleIndex = sexEntity.getTitalIndex();
            }
            //生日
            OCRDataProcessUtils.ConvertEntity birthEntity = OCRDataProcessUtils.categoryConvertByDate(text, BIRTH_DATE, birthTitleIndex, i, valueList, textList.size());
            if (birthEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(birthEntity.getText())) {
                    Date brithDate = DateUtil.getDateFromString(birthEntity.getText(), birthEntity.getDateFormat(), Locale.ENGLISH);
                    card.setBirthday(brithDate);
                }
                birthTitleIndex = birthEntity.getTitalIndex();
            }
            //号码
            OCRDataProcessUtils.ConvertEntity noEntity = OCRDataProcessUtils.convertByCategory(text, LICENSE_NO, noTitleIndex, i, "\\w\\d{2}-\\d{2}-\\d{6}", titleList, valueList);
            if (noEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(noEntity.getText())) {
                    card.setIdNo(noEntity.getText());
                }
                noTitleIndex = noEntity.getTitalIndex();
            }
            if (text.toUpperCase().contains(ADDRESS)) {
                //地址
                if (textList.size() >= (i + 2)) {
                    String address1 = textList.get(i + 1);
                    String address2 = textList.get(i + 2);
                    card.setAddress(address1 + " " + address2);
                }
            }
        }
        return card;
    }

}
