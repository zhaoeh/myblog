package com.riskcontrol.api.controller;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.api.service.RedisOperationService;
import com.riskcontrol.common.entity.response.Response;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @program: riskcontrol-api
 * @description: 基于redis常见操作的控制器
 * @author: Erhu.Zhao
 * @create: 2023-11-17 11:02
 */
@Slf4j
@RestController
@RequestMapping(value = "redis", method = RequestMethod.POST)
public class RedisOperationController {

    @Autowired
    private RedisOperationService redisOperationService;

    @ApiOperation(value = "redis操作配置", notes = "redis操作配置", httpMethod = "POST")
    @PostMapping(value = "operationForRedis")
    @ResponseBody
    public Response<JSONObject> operationForRedis(@RequestBody JSONObject req) {
        Response response = new Response();
        response.setBody(redisOperationService.operationForRedis(req));
        return response;
    }
}