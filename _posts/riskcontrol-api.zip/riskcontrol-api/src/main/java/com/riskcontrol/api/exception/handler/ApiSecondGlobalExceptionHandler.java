package com.riskcontrol.api.exception.handler;

import com.riskcontrol.api.exception.ApiBusinessException;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.enums.ResultEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @ClassName GlobalExceptionHandler
 * @Description 全局捕获异常
 * @Author TJSAlex
 * @Date 2023/5/19 12:12
 * @Version 1.0
 **/
@ControllerAdvice
@Slf4j
public class ApiSecondGlobalExceptionHandler {
    /**
     * 处理自定义业务异常
     *
     * @param e -
     * @return
     */
    @ExceptionHandler(value = ApiBusinessException.class)
    @ResponseBody
    public Response businessExceptionHandler(ApiBusinessException e) {
        Response response = new Response();
        log.info("发生业务异常！原因是：{}", e.getMessage());
        String code = ObjectUtils.isEmpty(e.getCode()) ? ResultEnum.FAIL.getCode() : e.getCode();
        response.setHead(code, e.getMessage());
        return response;
    }

    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    @ResponseBody
    public Response MethodArgumentNotValidExceptionHandler(MethodArgumentNotValidException exception) {
        Response response = new Response();
        BindingResult result = exception.getBindingResult();
        StringBuilder errorMsg = new StringBuilder();
        if (result.hasErrors()) {
            List<FieldError> fieldErrors = result.getFieldErrors();
            fieldErrors.forEach(error -> {
                errorMsg.append(error.getDefaultMessage()).append("!");
            });
        }
        log.error("参数校验错误！原因是：{}", errorMsg);
        response.setHead(ResultEnum.BAD_REQUEST.getCode(), errorMsg.toString());
        return response;
    }

    /**
     * 处理参数校验异常
     *
     * @param e BindException
     * @return Result
     */
    @ExceptionHandler(BindException.class)
    @ResponseBody
    public Response handleValidationException(BindException e) {
        Response response = new Response();
        BindingResult bindingResult = e.getBindingResult();
        if (bindingResult.hasErrors()) {
            String errorMessage = bindingResult.getFieldErrors().stream()
                    .map(FieldError::getDefaultMessage).collect(Collectors.joining("/"));
            log.error("参数校验错误！原因是：{}", errorMessage);
            response.setHead(ResultEnum.BAD_REQUEST.getCode(), errorMessage);
            return response;
        }
        log.error("参数校验错误！原因是：{}", ResultEnum.BAD_REQUEST.getMessage());
        response.setHead(ResultEnum.BAD_REQUEST.getCode(), ResultEnum.BAD_REQUEST.getMessage());
        return response;
    }

    @ResponseBody
    @ExceptionHandler(ConstraintViolationException.class)
    public Response handleValidationErrors(ConstraintViolationException ex) {
        Response response = new Response();
        List<String> errors = ex.getConstraintViolations()
                .stream().map(e -> e.getMessage()).collect(Collectors.toList());
        log.error("参数校验错误！原因是：{}", String.join(",", errors));
        response.setHead(ResultEnum.FAIL.getCode(), String.join(",", errors));
        return response;
    }

    /**
     * 全局异常 TODO 开发阶段暂时关闭
     *
     * @param req HttpServletRequest
     * @param e   ConstraintViolationException
     * @return Result
     */
//    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public Response allExceptionHandler(HttpServletRequest req, Exception e) {
        log.error("未捕捉异常！", e);
        Response response = new Response();
        response.setHead(ResultEnum.UNEXPECTED_FAIL.getCode(), ResultEnum.UNEXPECTED_FAIL.getMessage());
        return response;
    }
}