package com.riskcontrol.api.config;

import com.zoloz.api.sdk.client.OpenApiClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/10/7 13:41
 */
@Component
public class ZolozConfig {
    @Value("${zoloz.url:}")
    private String hostUrl;
    @Value("${zoloz.client.id:}")
    private String clientId;
    @Value("${zoloz.merchant.private.key:}")
    private String merchantPrivateKey;
    @Value("${zoloz.public.key:}")
    private String zolozPublicKey;
    @Bean
    public OpenApiClient init(){
        OpenApiClient client = new OpenApiClient();  // 用默认签名和加密构建
        client.setHostUrl(hostUrl);
        client.setClientId(clientId);
        client.setMerchantPrivateKey(merchantPrivateKey);
        client.setOpenApiPublicKey(zolozPublicKey);
        return client;
    }
}
