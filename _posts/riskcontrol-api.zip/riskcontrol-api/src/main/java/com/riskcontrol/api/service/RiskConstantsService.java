package com.riskcontrol.api.service;

import com.riskcontrol.common.entity.request.api.QueryRiskConstants;
import com.riskcontrol.common.entity.response.api.RiskConstantsRsp;

import java.util.List;

/**
 * @Description: 风控字典服务类
 * @Auther: yannis
 * @create: 2024-01-12
 */
public interface RiskConstantsService {

    List<RiskConstantsRsp> queryLabelList(QueryRiskConstants request);

    List<RiskConstantsRsp> queryRiskLabelAllList();

}
