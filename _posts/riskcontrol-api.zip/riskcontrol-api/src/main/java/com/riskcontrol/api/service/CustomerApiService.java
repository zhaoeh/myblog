package com.riskcontrol.api.service;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.customers.*;
import com.cn.schema.request.QueryCountResponse;
import com.gw.datacenter.vo.pagainate.PageModel;
import com.riskcontrol.api.entity.request.*;
import com.riskcontrol.api.entity.request.KycDispatchConfirmReq;
import com.riskcontrol.api.entity.response.OcrIdentifyRsp;
import com.riskcontrol.api.entity.response.PageModelExt;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.request.ApiQueryCustomersRequest;
import com.riskcontrol.common.entity.request.BaseReq;
import com.riskcontrol.common.entity.request.kyc.*;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.kyc.RiskQueryKycRequestResponse;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.List;


/**
 * @author Colson
 */
public interface CustomerApiService {


    /**
     * 完善用户信息*
     *
     * @param req 请求参数
     * @return
     */
    Boolean improveUserProfile(ImproveCustomerProfileReq req);

    /**
     * ocr识别*
     *
     * @param req 请求参数
     * @return
     */
    OcrIdentifyRsp ocrIdentify(OcrIdentifyReq req);

    /**
     * 审核KYC*
     *
     * @param req 请求参数
     * @return true
     */
    Boolean updateKycRequest(UpdateKycRequestReq req);


//    /**
//     * 获取ws产品常量*
//     *
//     * @param key  key
//     * @param type type
//     * @return 常量配置
//     */
//    String getProductConstants(String key, String type);

    Boolean updatePbcRequest(UpdateKycRequestReq req);

    Response<PageModel<WSKycSheetRequest>> queryKycSheetRequests(QueryKycRequestReq req) throws Exception;

    Response<List<WSKycRequest>> uploadPBCInfoBatchNew(MultipartFile files, HttpServletRequest request) throws Exception;

    Response queryPageByKycRequestId(QueryPageByKycRequestId req);
	
	PageModelExt<KycRequest> kycDispatch(BaseReq req);

    Boolean kycDispatchConfirm(KycDispatchConfirmReq req);


    Response<PageModel<WSKycRequestGw>> queryKycRequestsNew(QueryKycRequestReq req);

    Response<RiskQueryKycRequestResponse> queryKycRequest(RiskQueryKycRequestRequest req);

    Response<Integer> queryKycRequestFlag(RiskQueryKycRequest req);

    JSONObject modifyCustomConfiguration(JSONObject request);

    /**
     * 加载客户信息
     *
     * @param req 请求
     * @return 响应
     */
    List<WSCustomers> loadCustomers(ApiQueryCustomersRequest req);

    /**
     * 自动通过KYC和PBC *
     * @param req
     * @return
     */
    Response<ModifyKycRequestResponse> autoApproveKycAndPbc(RiskUpdateKycRequestRequest req);

    /**
     * 创建KYC *
     * @param req -
     * @return -
     */
    Response<CreateKycRequestResponse> addKycRequest(RiskCreateKycRequestRequest req);

    /**
     * cron更新kyc*
     * @param req -
     * @return
     */
    Response<ModifyKycRequestResponse> updateKycRequest(RiskUpdateKycRequestRequest req);

    /**
     * PBC修改状态 *
     * @param req -
     * @return
     */
    Response<ModifyKycRequestResponse> pbcModifyStatus(RiskUpdateKycRequestRequest req);


    Response<QueryCountResponse> queryWaitPendingCount(KycRequest req);
    boolean validKycIdAndType(ValidKycIdReq req);
    Response<KycRequest> queryKycByLoginNameOrderOne(RiskQueryKycRequest query);
    Response<ModifyKycRequestResponse> updateKycExt(KycExtUpdateReq req);
}
