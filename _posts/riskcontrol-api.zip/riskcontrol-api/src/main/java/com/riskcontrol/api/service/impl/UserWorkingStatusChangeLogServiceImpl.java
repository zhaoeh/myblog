package com.riskcontrol.api.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.products.WSProductConstants;
import com.cn.schema.urf.*;
import com.cn.schema.urf.common.USER_WORKING_STATUS;
import com.riskcontrol.api.constants.Constants;
import com.riskcontrol.api.constants.exception.ApiResultBaseEnum;
import com.riskcontrol.api.entity.request.UserCustomConfigReq;
import com.riskcontrol.api.entity.request.UserWorkingStatusChangeReq;
import com.riskcontrol.api.service.BaseService;
import com.riskcontrol.api.service.IDispatchService;
import com.riskcontrol.api.service.UserWorkingStatusChangeLogService;
import com.riskcontrol.api.utils.ProductConstantsUtil;
import com.riskcontrol.common.entity.request.BaseReq;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.service.WsFeignTemplate;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.*;

/**
 * @author ：zeus
 * @description：TODO
 * @date ：2023/03/15 18:02
 */
@Service
public class UserWorkingStatusChangeLogServiceImpl extends BaseService implements UserWorkingStatusChangeLogService {

    private static final Logger logger = LoggerFactory.getLogger(UserWorkingStatusChangeLogServiceImpl.class);
    //用户最新状态缓存
    final static String USER_LAST_STATUS = "USER_LAST_STATUS";
    //没有confim的用户缓存   noresponse状态
    final static String USER_STATUS_TIMER_ZSET = "USER_STATUS_TIMER_ZSET";
    //个性化配置
    final static String USER_CONFIG_CONFIG_MAP = "USER_CONFIG_CONFIG_MAP_";
    @Autowired
    IDispatchService iDispatchService;
    @Resource
    private RedisTemplate<Serializable, Object> redisTemplate;
    @Resource
    private WsFeignTemplate wsFeignTemplate;


    @Override
    public JSONObject modifyWorkingStatus(UserWorkingStatusChangeReq userWorkingStatusChangeReq) {
        logger.info("用户状态变更  params-{}", userWorkingStatusChangeReq);
        JSONObject responseData = new JSONObject();
        if (Objects.isNull(userWorkingStatusChangeReq.getLoginName())) {
            return responseData;
        }

        if (Strings.isBlank(userWorkingStatusChangeReq.getStatus()) ||
                !USER_WORKING_STATUS.isValidEnum(userWorkingStatusChangeReq.getStatus())) {
            return responseData;
        }
        QueryUserLastWorkingStatusRequest queryUserLastWorkingStatusRequest = new QueryUserLastWorkingStatusRequest();
        queryUserLastWorkingStatusRequest.setLoginName(userWorkingStatusChangeReq.getLoginName());
        queryUserLastWorkingStatusRequest.setInfProductId(userWorkingStatusChangeReq.getProductId());
        QueryUserLastWorkingStatusResponse queryUserLastWorkingStatusResponse = wsFeignTemplate.querLastWorkingStatus(queryUserLastWorkingStatusRequest);
        if (queryUserLastWorkingStatusResponse == null || queryUserLastWorkingStatusResponse.getUserWorkingStatusChangeLog() == null) {
            return responseData;
        }
        UserWorkingStatusChangeLog userWorkingStatusChangeLog = queryUserLastWorkingStatusResponse.getUserWorkingStatusChangeLog();

        if (userWorkingStatusChangeReq.getStatus().equals(queryUserLastWorkingStatusResponse.getUserWorkingStatusChangeLog().getAferStatus())) {
            UserWorkingStatusChangeLog userWorkingStatusChangeLogCatch = (UserWorkingStatusChangeLog) redisTemplate.opsForValue().get(USER_LAST_STATUS + userWorkingStatusChangeReq.getLoginName());

            if (userWorkingStatusChangeLogCatch != null &&
                    userWorkingStatusChangeLogCatch.getAferStatus().equals(queryUserLastWorkingStatusResponse.getUserWorkingStatusChangeLog().getAferStatus())) {
                return responseData.fluentPut("data", queryUserLastWorkingStatusResponse.getUserWorkingStatusChangeLog());
            }

        }
        //工作状态检查订单完成
        if (userWorkingStatusChangeLog.getAferStatus().equals(USER_WORKING_STATUS.INPROCESS.getName())) {
            boolean orderFlag = iDispatchService.hasPendingRequest(userWorkingStatusChangeReq);
            if (orderFlag) {
                //检查上个状态是否有未处理完订单
                throw new BusinessException(ApiResultBaseEnum.ERROR_PENDING_ORDER);
            }

        }
        //检查是否有没处理的订单
        if (userWorkingStatusChangeReq.getStatus().equals(USER_WORKING_STATUS.BREAK.getName())) {
            Long l = redisTemplate.opsForZSet().rank(USER_STATUS_TIMER_ZSET, userWorkingStatusChangeReq.getLoginName());
            if (l != null && l > -1) {
                deleteCatchAndNoticeDispatch(userWorkingStatusChangeReq.getProductId(), userWorkingStatusChangeReq.getLoginName());
            }

        }
        //显示available切换到break状态时的备注内容，break切  换  为avaiable就显示 Systemchange
        if (userWorkingStatusChangeReq.getStatus().equals(USER_WORKING_STATUS.AVAILABLE.getName()) && userWorkingStatusChangeLog.getAferStatus().equals(USER_WORKING_STATUS.BREAK.getName())) {
            userWorkingStatusChangeReq.setRemark("Systemchange");
        }
        //工作状态和noreponse 必须从AVAILABLE
        if (userWorkingStatusChangeReq.getStatus().equals(USER_WORKING_STATUS.INPROCESS.getName()) || userWorkingStatusChangeReq.getStatus().equals(USER_WORKING_STATUS.NORESPONSE.getName())) {
            if (!userWorkingStatusChangeLog.getAferStatus().equals(USER_WORKING_STATUS.AVAILABLE.getName())) {
                throw new BusinessException(ApiResultBaseEnum.ERROR_PARAM_OUT_RANGE);
            }
            if (Strings.isBlank(userWorkingStatusChangeReq.getOrderStyle())) {
                UserWorkingStatusChangeLog userWorkingStatusChangeLogCatch = (UserWorkingStatusChangeLog) redisTemplate.opsForValue().get(USER_LAST_STATUS + userWorkingStatusChangeReq.getLoginName());
                userWorkingStatusChangeReq.setOrderStyle(userWorkingStatusChangeLogCatch.getOrderStyle());
            }
            if (userWorkingStatusChangeReq.getStatus().equals(USER_WORKING_STATUS.NORESPONSE.getName())) {
                Long rank = redisTemplate.opsForZSet().rank(USER_STATUS_TIMER_ZSET, userWorkingStatusChangeReq.getLoginName());
                if (rank != null && rank > -1) {
                    deleteCatchAndNoticeDispatch(userWorkingStatusChangeReq.getProductId(), userWorkingStatusChangeReq.getLoginName());
                }
            }
        }


        if (userWorkingStatusChangeReq.getStatus().equals(USER_WORKING_STATUS.LOGOUT.getName())) {
            //删除状态缓存
            redisTemplate.delete(USER_LAST_STATUS + userWorkingStatusChangeReq.getLoginName());
        }

        if (Strings.isBlank(userWorkingStatusChangeReq.getOrderStyle()) && (
                userWorkingStatusChangeLog.getAferStatus().equals(USER_WORKING_STATUS.INPROCESS.getName())
                        || userWorkingStatusChangeLog.getAferStatus().equals(USER_WORKING_STATUS.NORESPONSE.getName()))) {
            userWorkingStatusChangeReq.setOrderStyle(userWorkingStatusChangeLog.getOrderStyle());
        }

        UpdateUserWorkingStatusRequest updateUserWorkingStatusRequest = new UpdateUserWorkingStatusRequest();
        updateUserWorkingStatusRequest.setStatus(userWorkingStatusChangeReq.getStatus());
        updateUserWorkingStatusRequest.setInfProductId(userWorkingStatusChangeReq.getProductId());
        updateUserWorkingStatusRequest.setLoginName(userWorkingStatusChangeReq.getLoginName());
        updateUserWorkingStatusRequest.setRemark(userWorkingStatusChangeReq.getRemark());
        updateUserWorkingStatusRequest.setOrderStyle(userWorkingStatusChangeReq.getOrderStyle());
        updateUserWorkingStatusRequest.setInfProductId(userWorkingStatusChangeReq.getProductId());
        UpdateUserWorkingStatusResponse updateUserWorkingStatusResponse = wsFeignTemplate.updateWorkingStatus(updateUserWorkingStatusRequest);

        if (updateUserWorkingStatusResponse.isSuccess()) {
            QueryUserLastWorkingStatusResponse userLastWorkingStatusResponse = wsFeignTemplate.querLastWorkingStatus(queryUserLastWorkingStatusRequest);
            redisTemplate.opsForValue().set(USER_LAST_STATUS + userWorkingStatusChangeReq.getLoginName(), userLastWorkingStatusResponse.getUserWorkingStatusChangeLog());
            return responseData.fluentPut("data", userLastWorkingStatusResponse.getUserWorkingStatusChangeLog());
        }
        throw new BusinessException(ApiResultBaseEnum.ERROR_UNKNOWN);
    }

    @Override
    public boolean checkUserCanSendOrder(BaseReq baseReq) {
        if (Strings.isBlank(baseReq.getLoginName())) {
            logger.error("checkUserCanSendOrder login name is null --{}", baseReq);
            return false;
        }
        checkExpiredUserWorkingStatus(baseReq);
        UserWorkingStatusChangeLog userWorkingStatusChangeLogCatch = (UserWorkingStatusChangeLog) redisTemplate.opsForValue().get(USER_LAST_STATUS + baseReq.getLoginName());
        if (userWorkingStatusChangeLogCatch != null && userWorkingStatusChangeLogCatch.getAferStatus().equals(USER_WORKING_STATUS.AVAILABLE.getName())) {
            Double score = redisTemplate.opsForZSet().score(USER_STATUS_TIMER_ZSET, baseReq.getLoginName());
            logger.info("[checkUserCanSendOrder method] score is {}, or is null ? {}", score, (Objects.isNull(score)));
            //不存在noresponse 队列里
            return score == null;
        }
        return false;
    }

    @Override
    public JSONObject selectCustomConfiguration(BaseReq baseReq) {
        if (Objects.isNull(baseReq.getLoginName())) {
            throw new BusinessException(ApiResultBaseEnum.ERROR_LOGINNAME_EMPTY);
        }
//        WSProductConstants wsProductConstants = wsFeignTemplate.getProductConstants(baseReq.getProductId(), "0016", "KYC_WITHDRAW_IS_OPEN");
        WSProductConstants wsProductConstants =  ProductConstantsUtil.obtainProductConstants(baseReq.getProductId(), "0016", "KYC_WITHDRAW_IS_OPEN");
        if (Objects.isNull(wsProductConstants)) {
            throw new BusinessException(ApiResultBaseEnum.NOT_FOUND_CONFIG_ERROR);
        }
        logger.info("{} wsProductConstants 系统变量 KYC_WITHDRAW_IS_OPEN={}", new Date(), wsProductConstants);
        //pay5开关
        String isOpened = wsProductConstants.getValue();
        if (StringUtils.isBlank(isOpened) || isOpened.equals("0")) {
            Map<String, Integer> map = new HashMap<>();
            map.put("KYC", 0);
            map.put("WITHDRAW", 0);
            return new JSONObject().fluentPut("data", map);
        }
        //默认全不选
        if (!redisTemplate.hasKey(USER_CONFIG_CONFIG_MAP + baseReq.getLoginName())) {
            redisTemplate.opsForHash().put(USER_CONFIG_CONFIG_MAP + baseReq.getLoginName(), "KYC", 0);
            redisTemplate.opsForHash().put(USER_CONFIG_CONFIG_MAP + baseReq.getLoginName(), "WITHDRAW", 0);
        }

        Map config = redisTemplate.opsForHash().entries(USER_CONFIG_CONFIG_MAP + baseReq.getLoginName());
        return new JSONObject().fluentPut("data", config);
    }

    @Override
    public Integer selectCustomConfigByType(String loginName, String type) {
        Object obj = redisTemplate.opsForHash().get(USER_CONFIG_CONFIG_MAP + loginName, type);
        if (obj == null) {
            return 0;
        }
        return (Integer) obj;
    }

    @Override
    public JSONObject modifyCustomConfiguration(UserCustomConfigReq baseReq) {
        logger.info("modifyCustomConfiguration--{}", baseReq);
        if (Objects.isNull(baseReq.getLoginName())) {
            throw new BusinessException(ApiResultBaseEnum.ERROR_LOGINNAME_EMPTY);
        }
        if (baseReq.getKycOption() != null) {
            redisTemplate.opsForHash().put(USER_CONFIG_CONFIG_MAP + baseReq.getLoginName(), "KYC", baseReq.getKycOption());
        }
        if (baseReq.getWithdrawOption() != null) {
            redisTemplate.opsForHash().put(USER_CONFIG_CONFIG_MAP + baseReq.getLoginName(), "WITHDRAW", baseReq.getWithdrawOption());
        }
        Map config = redisTemplate.opsForHash().entries(USER_CONFIG_CONFIG_MAP + baseReq.getLoginName());
        return new JSONObject().fluentPut("data", config);
    }

    @Override
    public JSONObject modifyCustomConfigurationClose(String loginName) {
        UserCustomConfigReq configReq = new UserCustomConfigReq();
        configReq.setKycOption(0);
        configReq.setLoginName(loginName);
        configReq.setWithdrawOption(0);
        logger.info("modifyCustomConfigurationClose 默认设置为全关 --{}", configReq);
        return modifyCustomConfiguration(configReq);
    }

    @Override
    public boolean workStatusProcessConfirmation(BaseReq baseReq, int type, String orderStyle) {
        logger.info("workStatusProcessConfirmation--{}--{}", baseReq, orderStyle);
        if (Strings.isBlank(baseReq.getLoginName())) {
            logger.error("workStatusProcessConfirmation login name is null --{}--,{}", baseReq, orderStyle);
            return false;
        }
        UserWorkingStatusChangeLog userWorkingStatusChangeLogCatch = (UserWorkingStatusChangeLog) redisTemplate.opsForValue().get(USER_LAST_STATUS + baseReq.getLoginName());
        if (Objects.isNull(userWorkingStatusChangeLogCatch)) {
            return false;
        }
        if (type == 0) {
//            WSProductConstants wsProductConstants = wsFeignTemplate.getProductConstants(baseReq.getProductId(), "0016", "ORDER_ACCEPT_TIME");
            WSProductConstants wsProductConstants = ProductConstantsUtil.obtainProductConstants(baseReq.getProductId(), "0016", "ORDER_ACCEPT_TIME");
            if (Objects.isNull(wsProductConstants)) {
                throw new BusinessException(ApiResultBaseEnum.NOT_FOUND_CONFIG_ERROR);
            }
            logger.info("wsProductConstants 系统变量{}", JSONObject.toJSONString(wsProductConstants));
            String second = wsProductConstants.getValue();
            if (StringUtils.isBlank(second)) {
                logger.error("ORDER_ACCEPT_TIME 系统变量缺失");
                second = "10";
            }
            //更新状态
            if (userWorkingStatusChangeLogCatch != null) {
                userWorkingStatusChangeLogCatch.setOrderStyle(orderStyle);
                redisTemplate.opsForValue().set(USER_LAST_STATUS + baseReq.getLoginName(), userWorkingStatusChangeLogCatch);
            }
            logger.info("[workStatusProcessConfirmation method] begin to init USER_STATUS_TIMER_ZSET");
            long nowTime = System.currentTimeMillis() + Integer.parseInt(second) * 1000L;
            redisTemplate.opsForZSet().add(USER_STATUS_TIMER_ZSET, baseReq.getLoginName(), nowTime);
            logger.info("[workStatusProcessConfirmation method] end to init USER_STATUS_TIMER_ZSET");
            return true;
        } else if (type == 1) {

            redisTemplate.opsForZSet().remove(USER_STATUS_TIMER_ZSET, baseReq.getLoginName());
            modifyWorkingStatus(new UserWorkingStatusChangeReq(USER_WORKING_STATUS.INPROCESS, baseReq.getLoginName(), baseReq.getProductId(), orderStyle));
            return true;
        }
        return false;
    }


    public void checkExpiredUserWorkingStatus(BaseReq req) {
        if (!redisTemplate.hasKey(USER_STATUS_TIMER_ZSET)) {
            return;
        }
        Set loginNames = redisTemplate.opsForZSet().rangeByScore(USER_STATUS_TIMER_ZSET, 0, System.currentTimeMillis());

        if (loginNames != null && loginNames.size() > 0) {
            //修改订单状态
            loginNames.forEach(e -> {
                UserWorkingStatusChangeLog userWorkingStatusChangeLogCatch = (UserWorkingStatusChangeLog) redisTemplate.opsForValue().get(USER_LAST_STATUS + e);
                logger.info("checkExpiredUserWorkingStatus 状态过期用户-{},{}", loginNames, userWorkingStatusChangeLogCatch.getOrderStyle());
                modifyWorkingStatus(new UserWorkingStatusChangeReq(USER_WORKING_STATUS.NORESPONSE, String.valueOf(e), req.getProductId(), userWorkingStatusChangeLogCatch.getOrderStyle()));
                deleteCatchAndNoticeDispatch(req.getProductId(), String.valueOf(e));
            });

        }
    }

    private void deleteCatchAndNoticeDispatch(String productId, String loginName) {
        logger.info("deleteCatchAndNoticeDispatch--{}--{}", productId, loginName);
        BaseReq baseReq = new BaseReq();
        baseReq.setLoginName(loginName);
        baseReq.setProductId(productId);
        iDispatchService.dispatchNoResponse(Constants.DISPATCH_ORDER_WITHDRAW, baseReq);
        iDispatchService.dispatchNoResponse(Constants.DISPATCH_ORDER_KYC, baseReq);
        redisTemplate.opsForZSet().remove(USER_STATUS_TIMER_ZSET, loginName);
    }

    @Override
    public void removeUserStatusTime(String loginName) {
        logger.info("removeUserStatusTime key:USER_STATUS_TIMER_ZSET --{}", loginName);
        if (redisTemplate.hasKey(USER_STATUS_TIMER_ZSET)) {
            redisTemplate.opsForZSet().remove(USER_STATUS_TIMER_ZSET, loginName);
        }
    }

    @Override
    public UserWorkingStatusChangeLog getLastWorkingStatus(UserWorkingStatusChangeReq statusChangeReq) {
        checkExpiredUserWorkingStatus(statusChangeReq);
        UserWorkingStatusChangeLog userWorkingStatusChangeLogCatch = (UserWorkingStatusChangeLog) redisTemplate.opsForValue().get(USER_LAST_STATUS + statusChangeReq.getLoginName());
        if (userWorkingStatusChangeLogCatch == null) {
            QueryUserLastWorkingStatusRequest queryUserLastWorkingStatusRequest = new QueryUserLastWorkingStatusRequest();
            queryUserLastWorkingStatusRequest.setLoginName(statusChangeReq.getLoginName());
            queryUserLastWorkingStatusRequest.setInfProductId(statusChangeReq.getProductId());
            userWorkingStatusChangeLogCatch = wsFeignTemplate.querLastWorkingStatus(queryUserLastWorkingStatusRequest).getUserWorkingStatusChangeLog();
            redisTemplate.opsForValue().set(USER_LAST_STATUS + statusChangeReq.getLoginName(), userWorkingStatusChangeLogCatch);
        }

        return userWorkingStatusChangeLogCatch;
    }

}
