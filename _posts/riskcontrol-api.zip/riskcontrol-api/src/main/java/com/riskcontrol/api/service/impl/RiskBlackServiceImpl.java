package com.riskcontrol.api.service.impl;

import com.riskcontrol.api.service.RiskBlackService;
import com.riskcontrol.common.client.RiskEkycFeign;
import com.riskcontrol.common.helper.ResponseHelper;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

import static com.riskcontrol.common.constants.Constant.RISK_IS_BLACK_KEY;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/10/30 14:41
 */
@Service
@Slf4j
public class RiskBlackServiceImpl implements RiskBlackService {
    @Autowired
    RedissonClient redissonClient;
    @Autowired
    RiskEkycFeign riskEkycFeign;
    /**
     * 查询用户是否在黑名单中（优先缓存）
     * @return
     */
    @Override
    public boolean getBlackStatus(String loginName) {
        String key = String.format(RISK_IS_BLACK_KEY, loginName);
        RBucket<Boolean> bucketEkyc = redissonClient.getBucket(key);
        if(Objects.isNull(bucketEkyc.get())){
            Boolean isBlack = ResponseHelper.pullData(riskEkycFeign.getBlackStatus(loginName));
            if(null == isBlack){
                isBlack = false;
            }
            bucketEkyc.set(isBlack,30, TimeUnit.MINUTES);
            return isBlack;
        }else{
            return bucketEkyc.get();
        }
    }
}
