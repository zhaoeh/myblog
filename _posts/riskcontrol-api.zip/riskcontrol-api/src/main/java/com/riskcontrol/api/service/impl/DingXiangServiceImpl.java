package com.riskcontrol.api.service.impl;

import com.riskcontrol.api.service.DingXiangService;
import com.riskcontrol.api.template.DingXiangTemplate;
import com.riskcontrol.api.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

/**
 * @description: 顶象服务impl
 * @author: ErHu.Zhao
 * @create: 2024-11-13
 **/
@Service
@Slf4j
public class DingXiangServiceImpl implements DingXiangService {

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private DingXiangTemplate dingXiangTemplate;

    @Override
    public Map<String, String> getDeviceInfo(String token) throws Exception {
        return getDeviceInfo(t -> StringUtils.length(token) < 100, token);
    }

    @Override
    public Map<String, String> getDeviceInfo(Predicate<String> cacheCondition, String token) throws Exception {
        Boolean useCache = false;
        if (Objects.nonNull(cacheCondition)) {
            useCache = cacheCondition.test(token);
        }
        log.info("查询设备信息，是否使用缓存：{}，token：{}", useCache, token);
        return BooleanUtils.isTrue(useCache) ? getDeviceInfo(token, 30 * 60, TimeUnit.SECONDS) : dingXiangTemplate.obtainDeviceInfoIgnoreCache(token);
    }

    @Override
    public Map<String, String> getDeviceInfo(String token, Integer expireTime, TimeUnit unit) throws Exception {
        return dingXiangTemplate.obtainDeviceInfoWithCache(token, this::formatDeviceKey, k -> redisUtil.get(k),
                (k, v) -> redisUtil.set(k, v, expireTime, unit));
    }

    /**
     * 格式化设备key*
     *
     * @param token
     * @return
     */
    private String formatDeviceKey(String token) {
        return String.format("risk:device:%s", token);
    }
}
