package com.riskcontrol.api.service;

import com.alibaba.fastjson.JSONObject;
import com.cn.schema.urf.UserWorkingStatusChangeLog;
import com.riskcontrol.api.entity.request.UserCustomConfigReq;
import com.riskcontrol.api.entity.request.UserWorkingStatusChangeReq;
import com.riskcontrol.common.entity.request.BaseReq;

public interface UserWorkingStatusChangeLogService {

    /**
     * 修改用户工作状态，
     *
     * @param userWorkingStatusChangeReq
     * @return
     */
    JSONObject modifyWorkingStatus(UserWorkingStatusChangeReq userWorkingStatusChangeReq);

    /**
     * 用户派单步骤
     *
     * @param baseReq
     * @param type      0：noresponse 前置 1：noresponse 确认接单
     * @return
     */
    boolean workStatusProcessConfirmation(BaseReq baseReq, int type, String orderStyle);

    /**
     * 检查派单未confim，并更改noresponse。并通知修改订单状态
     *
     * @param baseReq
     */
    void checkExpiredUserWorkingStatus(BaseReq baseReq);
    /**
     * 检查用户是否可以接单
     *
     * @param baseReq
     * @param
     * @return false 不可接单，true 可以
     */
    boolean checkUserCanSendOrder(BaseReq baseReq);


    /**
     * 自定配置
     * @param baseReq
     * @return
     */
    JSONObject selectCustomConfiguration(BaseReq baseReq);
    /**
     * 自定配置
     * @param userCustomConfigReq
     * @return
     */
    JSONObject modifyCustomConfiguration(UserCustomConfigReq userCustomConfigReq);

    /**
     * 配置设成关闭状态
     * @param loginName
     */
    JSONObject modifyCustomConfigurationClose(String loginName);

    /**
     * 按照类型查询用户的配置
     * @param loginName
     * @param type
     * @return
     */
    Integer selectCustomConfigByType(String loginName,String type);

    /**
     * 清除该用户超时状态的缓存
     * @param loginName
     */
    void removeUserStatusTime(String loginName);

    UserWorkingStatusChangeLog getLastWorkingStatus(UserWorkingStatusChangeReq statusChangeReq);
}
