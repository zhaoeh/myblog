package com.riskcontrol.api.constants.exception;

import com.riskcontrol.common.enums.ResultCode;

public enum ApiResultBaseEnum implements ResultCode{

    // 基本异常枚举
    SUCCESS(Boolean.TRUE, "200", "Request Success"),
    BAD_REQUEST(Boolean.FALSE, "400", "Parameter Error"),
    UNAUTHORIZED(Boolean.FALSE, "401", "Unauthorized, illegal access"),
    FORBIDDEN(Boolean.FALSE, "403", "No permission to access"),
    NOT_EXIST(Boolean.FALSE, "404", "Access address does not exist"),
    FAIL(Boolean.FALSE, "500", "Business exception, request failed"),

    UNEXPECTED_FAIL(Boolean.FALSE, "501", "UNEXPECTED_FAIL"),

    DATA_IS_NULL(Boolean.FALSE, "502", "DATA_IS_NULL"),
    OUT_SYSTEM_ERROR(Boolean.FALSE, "503", "OUT_SYSTEM_ERROR"),

    EXCEL_EXPORT_IO_ERROR(Boolean.FALSE, "504", "EXCEL_EXPORT_IO_ERROR"),
    ENCRYPT_DECRYPT_ERROR(Boolean.FALSE, "505", "encrypt/decrypt error"),

    FRAMEWORK_ERROR(Boolean.FALSE, "506", "Framework error"),

    WS_EXCEPTION(Boolean.FALSE, "507", "Call WS failed! Please check if the ws service is ok!"),
    CRON_EXCEPTION(Boolean.FALSE, "507", "Call RiskCron failed! Please check if the cron service is ok!"),
    UC_EXCEPTION(Boolean.FALSE, "507", "Call userCenter failed! Please check if the userCenter service is ok!"),
    GATEWAY_EXCEPTION(Boolean.FALSE, "507", "Call gateway api failed! Please check if the gateway api is ok!"),


    /*=======400000=========risk control api模块异常枚举==END========================*/

    WS_TEMPLATE_PRODUCT_ID_ERROR(Boolean.FALSE, "400101", "template productId Error"),
    PWD_DECRYPT_ERROR(Boolean.FALSE, "400102", "^password decrypt Error"),
    EMAIL_INVALID_ERROR(Boolean.FALSE, "400103", "email invalid Error"),
    BIND_EMAIL_USED_ERROR(Boolean.FALSE, "400104", "bind email used Error"),
    BIND_EMAIL_EXIST_ERROR(Boolean.FALSE, "400105", "bind email exist Error"),
    LOGIN_NAME_EMPTY_ERROR(Boolean.FALSE, "400106", "login name empty Error"),
    LOGIN_NAME_NOT_EXIST_ERROR(Boolean.FALSE, "400107", "login name not exist Error"),
    CUSTOMER_ID_NOT_EXIST_ERROR(Boolean.FALSE, "400108", "customer id not exist Error"),
    CUSTOMER_ID_TYPE_NOT_FOUND_ERROR(Boolean.FALSE, "400109", "document type not found Error"),
    BIND_EMAIL_ERROR(Boolean.FALSE, "400110", "bind email Error"),
    CUSTOMER_MODIFY_FAILED_ERROR(Boolean.FALSE, "400111", "customer modify failed Error"),
    COMPLETE_PLAYER_INFORMATION_ERROR(Boolean.FALSE, "400112", "complete player information Error"),
    DEPOSIT_TRANS_TRAIL_FORBID_ERROR(Boolean.FALSE, "400113", "deposit trans trail forbid error"),
    LOGIN_NAME_BLACK_ERROR(Boolean.FALSE, "400114", "login name black error"),
    ACCOUNT_NOT_EXIST_ERROR(Boolean.FALSE, "400115", "account not exist Error"),
    PBCSTATUS_REMARK_NOT_MATCH(Boolean.FALSE, "400116", "pubStaus and  remark not match"),
    BIRTH_PLACE_IS_LONG(Boolean.FALSE, "400117", "birth place is too long"),
    EMPLOYERNAME_ARE_NUMBER(Boolean.FALSE, "400118", "employer name can not be a number"),
    EMPLOYERNAME_IS_LONG(Boolean.FALSE, "400119", "employer name can not be a number"),
    FIRST_NAME_EMPTY_ERROR(Boolean.FALSE, "400120", "first name empty Error"),
    LAST_NAME_EMPTY_ERROR(Boolean.FALSE, "400121", "last name empty Error"),
    BIRTHDAY_EMPTY_ERROR(Boolean.FALSE, "400122", "birthday empty Error"),
    BIRTHDAY_INVALID_ERROR(Boolean.FALSE, "400123", "birthday invalid Error"),

    KYC_REVIEWING(Boolean.FALSE, "400201", "KYC information is under review, please wait"),
    KYC_APPROVED(Boolean.FALSE, "400202", "KYC information has been confirmed, can't be mofified"),
    KYC_VERIFICATION_ERROR(Boolean.FALSE, "400203", "KYC verification Error"),
    KYC_SMS_ERROR(Boolean.FALSE, "400204", "KYC send message Error"),
    NOT_FOUND_CONFIG_ERROR(Boolean.FALSE, "400210", "cannot found config Error"),
    SWITCH_READ_ERROR(Boolean.FALSE, "400211", "user switch read Error"),
    // ocr start
    OCR_USER_OVER_AGE_ERROR(Boolean.FALSE, "400301", "OCR user over age Error"),
    OCR_RECOGNITION_ERROR(Boolean.FALSE, "400302", "OCR recognition Error"),
    // ocr end
    UPLOAD_TO_S3_ERROR(Boolean.FALSE, "400401", "upload image Error"), //上传到S3服务失败,
    FACE_API_URL_EMPTY_ERROR(Boolean.FALSE, "400402", "face api url empty Error"),
    FACE_IMG_NOT_EXIST_ERROR(Boolean.FALSE, "400403", "face image not exist Error"),

    USER_WITHOUT_PBD_AUDIT_PERMISSIONS_ERROR(Boolean.FALSE, "400501", "Users without pbc audit permissions Error"),
    ERROR_QUERY_KYC_SHEET_REQUEST_PARAMS_LACK(Boolean.FALSE, "400502", "Select at least 1 query condition"),

    ERROR_PENDING_ORDER(Boolean.FALSE, "910210", "After this order is processed, the next order will enter a resting state."),
    ERROR_PARAM_OUT_RANGE(Boolean.FALSE, "999998", "parameter is not in 222"),
    ERROR_UNKNOWN(Boolean.FALSE, "999999", "system busy, please try again later"),
    ERROR_LOGINNAME_EMPTY(Boolean.FALSE, "890401", "System-Account name can not be empty"),
    ERROR_CREATE_KYC(Boolean.FALSE, "890402", "error create kyc"),
    ;

    /*=======400000=========risk control api模块异常枚举==START========================*/

    private Boolean success;
    private String code;
    private String message;

    ApiResultBaseEnum(Boolean success, String code, String message) {
        this.success = success;
        this.code = code;
        this.message = message;
    }

    @Override
    public Boolean getSuccess(Object... actualParams) {
        return success;
    }

    @Override
    public String getCode(Object... actualParams) {
        return code;
    }

    @Override
    public String getMessage(Object... actualParams) {
        return message;
    }
}
