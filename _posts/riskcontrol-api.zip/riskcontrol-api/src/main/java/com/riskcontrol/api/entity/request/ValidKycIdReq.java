package com.riskcontrol.api.entity.request;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/7/3 13:41
 */
@Data
public class ValidKycIdReq {
    @NotNull(message = "idType can't null")
    private Integer idType;
    @NotBlank(message = "idNo can't null")
    private String idNo;
}
