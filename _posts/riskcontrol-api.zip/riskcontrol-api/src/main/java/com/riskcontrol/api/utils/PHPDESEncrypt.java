package com.riskcontrol.api.utils;

import com.riskcontrol.common.config.UserCenterConstant;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import java.security.SecureRandom;

@Component
public class PHPDESEncrypt {


    private String key;

    private static UserCenterConstant userCenterConstant;


    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public PHPDESEncrypt() {

    }


    @Autowired
    public void setUserCenterConstant(UserCenterConstant userCenterConstant) {
        PHPDESEncrypt.userCenterConstant = userCenterConstant;
    }



    /**
     * 根据类型实例化加密类
     *
     * @param productId
     * @param type      01:真实姓名 02:地址 03:电话 04:邮件 05:网络联系方式 06:帐户名 07:帐号 08:存款人
     *                  (预留校验码以真实姓名加密,身份证以电话加密,问题答案以地址加密)
     * @author sky.x
     */
    public PHPDESEncrypt(String productId, String type) {
        StringBuilder tempKey = new StringBuilder();
        if (null == type || "".equals(type)) {
            tempKey.append(productId).append(productId).append(productId);
        }
        String productKey = userCenterConstant.getConstantValue(type);

        // 01:真实姓名
        if ("01".equals(type)) {
            tempKey.append(productId).append("R_01").append(productKey, 1, productKey.length() - 1);
        }
        // 02:地址
        if ("02".equals(type)) {
            tempKey.append(productId).append("A_02").append(productKey, 2, productKey.length() - 2);
        }
        // 03:电话
        if ("03".equals(type)) {
            tempKey.append(productId).append("P_03").append(productKey, 1, productKey.length() - 1);
        }
        // 04:邮件
        if ("04".equals(type)) {
            tempKey.append(productId).append("E_04").append(productKey, 1, productKey.length() - 2);
        }
        // 05:网络联系方式
        if ("05".equals(type)) {
            tempKey.append(productId).append("O_05").append(productKey, 3, productKey.length() - 3);
        }
        // 06:帐户名
        if ("06".equals(type)) {
            tempKey.append(productId).append("AN_06").append(productKey, 1, productKey.length() - 2);
        }
        // 07:帐号
        if ("07".equals(type)) {
            tempKey.append(productId).append("AN_07").append(productKey, 2, productKey.length() - 1);
        }
        // 08:存款人
        if ("08".equals(type)) {
            tempKey.append(productId).append("D_08").append(productKey, 2, productKey.length() - 2);
        }
        this.key = tempKey.toString();
    }


    public byte[] desDecrypt(byte[] encryptText) {
        try {
            SecureRandom sr = new SecureRandom();
            DESKeySpec dks = new DESKeySpec(key.getBytes());
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
            SecretKey key = keyFactory.generateSecret(dks);
            Cipher cipher = Cipher.getInstance("DES");
            cipher.init(Cipher.DECRYPT_MODE, key, sr);
            return cipher.doFinal(encryptText);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    /**
     * 解密
     *
     * @param input
     * @return String
     * @author sky.x
     */
    public String decrypt(String input) {
        if (null == input || "".equals(input.trim())) {
            return input;
        }
        input = input.substring(3, input.length() - 4);
        byte[] result = base64Decode(input);
        return new String(desDecrypt(result));
    }


    public byte[] base64Decode(String s) {
        if (s == null) {
            return null;
        }
        return Base64.decodeBase64(s);
    }



}
