package com.riskcontrol.api.controller;

import com.google.cloud.vision.v1.AnnotateImageResponse;
import com.riskcontrol.api.ocr.OcrClient;
import com.riskcontrol.common.client.CronFeign;
import com.riskcontrol.common.client.RiskEkycFeign;
import com.riskcontrol.common.entity.pojo.Ekyc;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.response.Response;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.constraints.NotEmpty;
import java.io.IOException;

@RestController
@RequestMapping("/ocr/test")
@Api("测试接口")
public class TestController {
    @Resource
    private OcrClient ocrClient;

    @Autowired
    private RiskEkycFeign riskEkycFeign;


    @PostMapping(value = "/orcTest")
    @ApiOperation(value = "测试orc")
    public void testOrc(String path) throws IOException {
        if (StringUtils.isNotBlank(path)) {
            AnnotateImageResponse response = ocrClient.analyzeImage(path);
            System.out.printf("image=======" + response.toString());
        } else {
            AnnotateImageResponse response = ocrClient.analyzeImage("http://10.30.46.15:9002/c66/6dd4ded1-3ef0-4b1c-a63c-4d05de40c016.jpg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=minioadmin%2F20240429%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20240429T031151Z&X-Amz-Expires=604800&X-Amz-SignedHeaders=host&X-Amz-Signature=9b03a0c81740f85b2d9b0308fa6a2a44981037d5dfbf4be7711f8be2d7dd4acd");
            System.out.printf("image=======" + response.toString());
        }
    }


    @GetMapping(value = "/queryStatus/{loginName}")
    @ResponseBody
    public Response<Ekyc> queryStatus(@PathVariable String loginName) {
        return Response.body(riskEkycFeign.queryStatus(loginName));
    }

    @GetMapping(value = "/queryCurrentKycRequest/{loginName}")
    @ResponseBody
    public Response<KycRequest> queryCurrentKycRequest(@PathVariable String loginName) {
        return Response.body(riskEkycFeign.queryCurrentKycRequest(loginName));
    }

}