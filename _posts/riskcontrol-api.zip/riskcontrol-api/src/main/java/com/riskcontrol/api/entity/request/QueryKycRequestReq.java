package com.riskcontrol.api.entity.request;

 import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel("查询玩家详细列表请求参数")
@Data
public class QueryKycRequestReq extends BaseQueryReq {


    @ApiModelProperty(value = "玩家账号")
    private String customerName;

    @ApiModelProperty("分配人")
    private String assigneeBy;

    @ApiModelProperty(value = "assignee Begin", example = "")
    private String assigneeDateBegin;

    @ApiModelProperty(value = "assignee End", example = "")
    private String assigneeDateEnd;

    @ApiModelProperty(value = "createdDate Begin", example = "")
    private String createdDateBegin;

    @ApiModelProperty(value = "createdDate End", example = "")
    private String createdDateEnd;

    @ApiModelProperty(value = "审核状态", example = "")
    private Integer processType;
    @ApiModelProperty(value = "pbc提案单号", example = "")
    private String billNo;
    @ApiModelProperty(value = "产品", example = "")
    private String product;
    @ApiModelProperty(value = "渠道", example = "")
    private String channel;

}
