package com.riskcontrol.api.service.impl;

import com.riskcontrol.api.constants.Product;
import com.riskcontrol.api.constants.RiskDisConstants;
import com.riskcontrol.api.service.RiskConstantsService;
import com.riskcontrol.api.template.CronFeignTemplate;
import com.riskcontrol.common.entity.request.api.QueryRiskConstants;
import com.riskcontrol.common.entity.response.api.RiskConstantsRsp;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Description: 风控字典服务类
 * @Auther: yannis
 * @create: 2024-01-12
 */
@Service
public class RiskConstantsServiceImpl implements RiskConstantsService {
    @Resource
    private CronFeignTemplate cronFeignTemplate;

    /**
     * 根据条件查询标签列表
     * @param request
     * @return
     */
    @Override
    public List<RiskConstantsRsp> queryLabelList(QueryRiskConstants request) {
        request.setPType(RiskDisConstants.TYPE_LABLE);
        if(StringUtils.isEmpty(request.getProductId())){
            request.setProductId(Product.Ids.C66.name());
        }
        List<RiskConstantsRsp> riskConstants = queryRiskConstantsList(request);
        return riskConstants;
    }

    /**
     * 没有参数，默认查所有用户标签
     * @return
     */
    @Override
    public List<RiskConstantsRsp> queryRiskLabelAllList() {
        QueryRiskConstants request = new QueryRiskConstants();
        request.setPType(RiskDisConstants.TYPE_LABLE);
        request.setProductId(Product.Ids.C66.name());
        return queryRiskConstantsList(request);
    }

    /**
     * 根据条件查询风控常量列表
     * @param request
     * @return
     */
    public List<RiskConstantsRsp> queryRiskConstantsList(QueryRiskConstants request) {
        return cronFeignTemplate.queryRiskConstantsList(request);
    }

}
