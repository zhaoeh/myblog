package com.riskcontrol.api.entity.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/10/7 15:23
 */
@ApiModel("发起ekyc流程返回结果")
@Data
public class InitEKycRsp {
    @ApiModelProperty(value = "执行步骤1:执行初始化,2:执行完善信息" )
    private String step;
    @ApiModelProperty(value = "客户端配置信息，包括SDK连接和行为参数。step=1时才有" )
    private String clientCfg;
    @ApiModelProperty(value = "ekyc识别信息，step=2时才有" )
    private EkycResult ekycResult;

}
