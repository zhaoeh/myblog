package com.riskcontrol.api.service.impl;


import com.alibaba.nacos.common.utils.CollectionUtils;
import com.riskcontrol.common.enums.CardTypeEnum;
import com.riskcontrol.api.entity.CustomerCard;
import com.riskcontrol.api.service.AnalyzeCardService;
import com.riskcontrol.api.utils.DateUtil;
import com.riskcontrol.api.utils.OCRDataProcessUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @Auther: yannis
 * @Date: 2023/3/31 17:40
 * @Description: Tax Identification
 */
@Service("TINService")
public class AnalyzeTINServiceImpl implements AnalyzeCardService {
    private static final Logger logger = LoggerFactory.getLogger(AnalyzeTINServiceImpl.class);

    static final List<String> titleList = Arrays.asList("REPUBLIC OF THE PHILIPPINES", "DEPARTMENT OF FINANCE", "BUREAU OF INTERNAL REVENUE");

    private final String BIRTH_DATE = "BIRTH DATE";
    private final String CARD_NO = "TIN";

    @Override
    public CustomerCard getRecognitionData(List<String> textList, CardTypeEnum cardTypeEnum) {
        logger.info("Tax Identification start parsing.....");
        if (CollectionUtils.isEmpty(textList)) {
            return null;
        }
        CustomerCard card = new CustomerCard();
        card.setIdType(cardTypeEnum.getCode());
        int birthTitleIndex = -1;
        int noTitleIndex = 1;
        List<String> valueList = new ArrayList<>();
        for (int i = 0; i < textList.size(); i++) {
            String text = textList.get(i);

            //姓名
            String names = OCRDataProcessUtils.takeColumnarRegexData(text, noTitleIndex, i, "\\w+,\\s+\\w+(?:\\s+\\w+)?(?:\\s+\\w+)?");
            if (StringUtils.isNotEmpty(names)) {
                OCRDataProcessUtils.ConvertEntity namesConvert = OCRDataProcessUtils.getNamesConvert(names);
                card.setFirstName(namesConvert.getFirstName());
                card.setMiddleName(namesConvert.getMiddleName());
                card.setLastName(namesConvert.getLastName());
            }
            //生日
            OCRDataProcessUtils.ConvertEntity birthEntity = OCRDataProcessUtils.categoryConvertByDate(text, BIRTH_DATE, birthTitleIndex, i, valueList, "MM/dd/yyyy");
            if (birthEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(birthEntity.getText())) {
                    Date brithDate = DateUtil.getDateFromString(birthEntity.getText(), birthEntity.getDateFormat(), Locale.ENGLISH);
                    card.setBirthday(brithDate);
                }
                birthTitleIndex = birthEntity.getTitalIndex();
            }
            //号码
            String cardNo = OCRDataProcessUtils.takeColumnarRegexData(text, noTitleIndex, i, textList.size(), "\\d{3}-\\d{3}-\\d{3}-\\d{3}|\\d{3}");
            if (StringUtils.isNotEmpty(cardNo)) {
                noTitleIndex = 0;
                card.setIdNo(cardNo);
            }

        }
        return card;
    }

}
