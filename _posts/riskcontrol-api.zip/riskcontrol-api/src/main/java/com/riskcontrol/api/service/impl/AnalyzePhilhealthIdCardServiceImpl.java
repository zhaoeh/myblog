package com.riskcontrol.api.service.impl;


import com.alibaba.nacos.common.utils.CollectionUtils;
import com.riskcontrol.api.constants.CardTypeEnum;
import com.riskcontrol.api.entity.CustomerCard;
import com.riskcontrol.api.service.AnalyzeCardService;
import com.riskcontrol.api.utils.DateUtil;
import com.riskcontrol.api.utils.OCRDataProcessUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @Auther: yannis
 * @Date: 2023/3/31 17:40
 * @Description: PhilHealth
 */
@Service("philHealthIdService")
public class AnalyzePhilhealthIdCardServiceImpl implements AnalyzeCardService {
    private static final Logger logger = LoggerFactory.getLogger(AnalyzePhilhealthIdCardServiceImpl.class);
    static final List<String> titleList = Arrays.asList("REPUBLIC OF THE PHILIPPINE", "Philippine Health Insurance Corporation", "PhilHealth");
    public static final String NAMES = "Name";
    public static final String SEX = "Gender";
    public static final String BIRTH_DATE = "Date of Birth";
    private final String CARD_NO = "Number";

    @Override
    public CustomerCard getRecognitionData(List<String> textList, CardTypeEnum cardTypeEnum) {
        logger.info("PhilHealth Id start parsing.....");
        if (CollectionUtils.isEmpty(textList)) {
            return null;
        }
        CustomerCard card = new CustomerCard();
        card.setIdType(cardTypeEnum.getCode());

        int birthTitleIndex = 1;
        int noTitleIndex = 0;
        int namesTitleIndex = 0;
        int sexIndex = 0;

        List<String> valueList = new ArrayList<>();
        for (int i = 0; i < textList.size(); i++) {
            String text = textList.get(i);
            //号码
            String cardNo = OCRDataProcessUtils.takeColumnarRegexData(text, 1, i, "\\d{2}-\\d{9}-\\d{1}");
            if (StringUtils.isNotEmpty(cardNo)) {
                noTitleIndex = i;
                card.setIdNo(cardNo.trim());
            }

            //姓名
            String names = OCRDataProcessUtils.takeColumnarRegexData(text, noTitleIndex, i, "\\w+,\\s+\\w+(?:\\s+\\w+)?(?:\\s+\\w+)?");
            if (StringUtils.isNotEmpty(names)) {
                noTitleIndex = -1;
                namesTitleIndex = i;
                OCRDataProcessUtils.ConvertEntity namesConvert = OCRDataProcessUtils.getNamesConvert(names);
                card.setFirstName(namesConvert.getFirstName());
                card.setMiddleName(namesConvert.getMiddleName());
                card.setLastName(namesConvert.getLastName());

            }
            if (StringUtils.isEmpty(card.getMiddleName()) && i == (namesTitleIndex + 1)) {
                //判断下一行是否是日期类型，如果不是则为名字
                String dataText = OCRDataProcessUtils.getTextByRegex(text, OCRDataProcessUtils.ENDLISH_DATE_REGEX);
                if (StringUtils.isEmpty(dataText)) {
                    String middleName = OCRDataProcessUtils.takeColumnarRegexData(text, namesTitleIndex, i, 1, "\\w+");
                    if (StringUtils.isNotEmpty(middleName)) {
                        card.setMiddleName(middleName);
                    }
                }
            }
            //生日
            OCRDataProcessUtils.ConvertEntity birthEntity = OCRDataProcessUtils.categoryConvertByDate(text, null, birthTitleIndex, i, valueList, textList.size());
            if (birthEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(birthEntity.getText())) {
                    Date brithDate = DateUtil.getDateFromString(birthEntity.getText(), birthEntity.getDateFormat(), Locale.ENGLISH);
                    card.setBirthday(brithDate);
                }
                sexIndex = i;
                birthTitleIndex = birthEntity.getTitalIndex();
            }
            //性别
            String sex = OCRDataProcessUtils.takeColumnarRegexData(text, sexIndex, i, "FEMALE|MALE");
            if (StringUtils.isNotEmpty(sex)) {
                String sexCode = OCRDataProcessUtils.convertBySex(sex);
                card.setGender(sexCode);
            }
        }
        return card;
    }
}
