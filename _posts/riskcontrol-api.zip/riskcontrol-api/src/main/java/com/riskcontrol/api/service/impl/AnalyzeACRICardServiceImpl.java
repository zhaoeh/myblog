package com.riskcontrol.api.service.impl;

import com.alibaba.nacos.common.utils.CollectionUtils;
import com.riskcontrol.api.constants.CardTypeEnum;
import com.riskcontrol.api.entity.CustomerCard;
import com.riskcontrol.api.service.AnalyzeCardService;
import com.riskcontrol.api.utils.DateUtil;
import com.riskcontrol.api.utils.OCRDataProcessUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @Auther: yannis
 * @Date: 2023/3/31 17:40
 * @Description: ACR I-Card 外国人身份登记卡 Alien Certificate of Registration / Immigrant Certificate of Registration
 */
@Service("acrCardService")
public class AnalyzeACRICardServiceImpl implements AnalyzeCardService {
    private static final Logger logger = LoggerFactory.getLogger(AnalyzeACRICardServiceImpl.class);

    static final List<String> titleList = Arrays.asList("ALIEN CERTIFICATE OF REGISTRATION", "REPUBLIC OF THE PHURRNES", "Given Name:",
            "Other Name:", "Surname:", "Citizenship:", "Date of Birth:", "SSRN", "Citizenships");
    public static final String LAST_NAME = "Surname";
    public static final String FIRST_NAME = "Given Name";
    public static final String MIDDLE_NAME = "Other Name";
    public static final String SEX = "Sex";
    public static final String BIRTH_DATE = "Date of Birth";
    private static final String CARD_NO = "SSRN";

    @Override
    public CustomerCard getRecognitionData(List<String> textList, CardTypeEnum cardTypeEnum) {
        logger.info("ACR I-Card start parsing.....");
        if (CollectionUtils.isEmpty(textList)) {
            return null;
        }
        CustomerCard card = new CustomerCard();
        card.setIdType(cardTypeEnum.getCode());
        int sexTitleIndex = -1;
        int birthTitleIndex = -1;
        int lastNameTitleIndex = -1;
        int firstNameTitleIndex = -1;
        int middleNameTitleIndex = -1;
        int noTitleIndex = 1;

        List<String> valueList = new ArrayList<>();
        for (int i = 0; i < textList.size(); i++) {
            String text = textList.get(i);
            //姓名
            OCRDataProcessUtils.ConvertEntity lastNameEntity = OCRDataProcessUtils.convertByCategory(text, LAST_NAME, lastNameTitleIndex, i, null, titleList, valueList, 1, true);
            if (lastNameEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(lastNameEntity.getText())) {
                    card.setLastName(lastNameEntity.getText().toUpperCase());
                }
                lastNameTitleIndex = lastNameEntity.getTitalIndex();
            }

            OCRDataProcessUtils.ConvertEntity firstNameEntity = OCRDataProcessUtils.convertByCategory(text, FIRST_NAME, firstNameTitleIndex, i, null, titleList, valueList, 1, true);
            if (firstNameEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(firstNameEntity.getText())) {
                    card.setFirstName(firstNameEntity.getText().toUpperCase());
                }
                firstNameTitleIndex = firstNameEntity.getTitalIndex();
            }
            //中间名
            OCRDataProcessUtils.ConvertEntity middleNameEntity = OCRDataProcessUtils.convertByCategory(text, MIDDLE_NAME, middleNameTitleIndex, i, null, titleList, valueList, 1, true);
            if (middleNameEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(middleNameEntity.getText())) {
                    card.setMiddleName(middleNameEntity.getText().toUpperCase());
                }
                middleNameTitleIndex = middleNameEntity.getTitalIndex();
            }
            //性别
            OCRDataProcessUtils.ConvertEntity sexEntity = OCRDataProcessUtils.convertByCategory(text, SEX, sexTitleIndex, i, OCRDataProcessUtils.REGEX_SEX, titleList, valueList, 1, true);
            if (sexEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(sexEntity.getText())) {
                    String sex = OCRDataProcessUtils.convertBySex(sexEntity.getText());
                    card.setGender(sex);
                }
                sexTitleIndex = sexEntity.getTitalIndex();
            }
            //生日
            OCRDataProcessUtils.ConvertEntity birthEntity = OCRDataProcessUtils.categoryConvertByDate(text, BIRTH_DATE, birthTitleIndex, i, valueList);
            if (birthEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(birthEntity.getText())) {
                    Date brithDate = DateUtil.getDateFromString(birthEntity.getText(), birthEntity.getDateFormat(), Locale.ENGLISH);
                    card.setBirthday(brithDate);
                }
                birthTitleIndex = birthEntity.getTitalIndex();
            }
            //号码
            OCRDataProcessUtils.ConvertEntity noEntity = OCRDataProcessUtils.convertByNoCategory(text, noTitleIndex, "\\d{5}(\\w{2}|\\w+-)\\d{10}", titleList, valueList);
            if (null != noEntity && noEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(noEntity.getText())) {
                    card.setIdNo(noEntity.getText());
                }
                noTitleIndex = noEntity.getTitalIndex();
            }
        }

        return card;
    }

}
