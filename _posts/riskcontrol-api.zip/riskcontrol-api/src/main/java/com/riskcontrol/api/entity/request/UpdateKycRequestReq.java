package com.riskcontrol.api.entity.request;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@ApiModel
@Data
public class UpdateKycRequestReq extends BaseReq {

    @ApiModelProperty("Id, primary Key")
    private String id;
    @ApiModelProperty("customerId")
    private String customerId;
    @ApiModelProperty("customer Login Name")
    private String loginName;
    @ApiModelProperty("productId")
    private String productId;
    @ApiModelProperty("created Date")
    private String createdDate;
    @ApiModelProperty("open Date")
    private String openDate;
    @ApiModelProperty("created By")
    private String createdBy;
    @ApiModelProperty("update By")
    private String updateDate;
    @ApiModelProperty("update By")
    private String updateBy;
    @ApiModelProperty("id Type")
    private String idType;
    @ApiModelProperty("id Number")
    private String idNo;
    @ApiModelProperty("firstName")
    private String firstName;
    @ApiModelProperty("middleName")
    private String middleName;
    @ApiModelProperty("lastName")
    private String lastName;
    @ApiModelProperty("id snapshot storage address")
    private String idScan;
    @ApiModelProperty("id status")
    private String status;
    @ApiModelProperty("remark")
    private String remark;
    @ApiModelProperty("sex")
    private String sex;
    @ApiModelProperty("address")
    private String address;
    @ApiModelProperty("country")
    private String country;
    @ApiModelProperty("pbcStatus")
    private String pbcStatus;
    @ApiModelProperty("birthday")
    private String birthday;
}
