package com.riskcontrol.api.service.impl;

import com.cn.schema.request.QueryCountResponse;
import com.riskcontrol.api.constants.Constants;
import com.riskcontrol.api.service.IDispatchService;
import com.riskcontrol.api.template.CronFeignTemplate;
import com.riskcontrol.common.entity.request.BaseReq;
import com.riskcontrol.common.service.WsFeignTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class DispatchServiceImpl implements IDispatchService {

    @Autowired
    private WsFeignTemplate wsFeignTemplate;

    @Autowired
    private CronFeignTemplate cronFeignTemplate;

    private static final Logger logger = LoggerFactory.getLogger(DispatchServiceImpl.class);


    @Override
    public boolean dispatchNoResponse(String orderStyle, BaseReq request) {
        if (Constants.DISPATCH_ORDER_WITHDRAW.equals(orderStyle)) {
            return wsFeignTemplate.dispatchWithdrawalCancel(request);
        } else if (Constants.DISPATCH_ORDER_KYC.equals(orderStyle)) {
            return cronFeignTemplate.dispatchKycRequestCancel(request);
        } else {
            logger.error("un known orderStyle {}", orderStyle);
            return false;
        }
    }

    @Override
    public boolean hasPendingRequest(BaseReq request) {
        return getRequestPendingCount(request) > 0;
    }

    private int getRequestPendingCount(BaseReq request) {
//        Boolean switchFlag = wsFeignTemplate.getRiskApiWsSwitch();
//        if (switchFlag) {
        int kycCount = cronFeignTemplate.dispatchRequestPendingCount(request);
        int withdrawalCount = Optional.ofNullable(wsFeignTemplate.queryWithdrawalRequestPendingCount(request)).map(QueryCountResponse::getCount).orElse(0);
        return kycCount + withdrawalCount;
//        }
//        return wsFeignTemplate.dispatchRequestPendingCount(request);
    }
}
