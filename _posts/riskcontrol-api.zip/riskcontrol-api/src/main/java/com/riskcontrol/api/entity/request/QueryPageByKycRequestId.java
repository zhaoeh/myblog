package com.riskcontrol.api.entity.request;


import io.swagger.annotations.ApiModelProperty;

public class QueryPageByKycRequestId  extends BalanceReq {
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @ApiModelProperty(required = true, value = "KYC ID列表， KYC ID list", example = "")
    private String id;


}
