package com.riskcontrol.api;

import com.riskcontrol.common.annotation.EnableRiskCommon;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Slf4j
@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
@EnableFeignClients(basePackages = {"com.riskcontrol.*.client"})
@EnableSwagger2
@EnableRiskCommon
public class RiskControlApiApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        ConfigurableApplicationContext context = SpringApplication.run(RiskControlApiApplication.class, args);
        Environment environment = context.getBean(Environment.class);
        String port = environment.getProperty("local.server.port");
        log.info("[riskcontrol-api服务启动！ port:{} ]",port);
    }
}
