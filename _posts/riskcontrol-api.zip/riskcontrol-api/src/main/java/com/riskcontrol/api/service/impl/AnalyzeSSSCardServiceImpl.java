package com.riskcontrol.api.service.impl;


import com.alibaba.nacos.common.utils.CollectionUtils;
import com.riskcontrol.api.constants.CardTypeEnum;
import com.riskcontrol.api.entity.CustomerCard;
import com.riskcontrol.api.service.AnalyzeCardService;
import com.riskcontrol.api.utils.DateUtil;
import com.riskcontrol.api.utils.OCRDataProcessUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @Auther: yannis
 * @Date: 2023/3/31 17:40
 * @Description: Social Security System (SSS) Card
 */
@Service("sssCordService")
public class AnalyzeSSSCardServiceImpl implements AnalyzeCardService {
    private static final Logger logger = LoggerFactory.getLogger(AnalyzeSSSCardServiceImpl.class);

    static final List<String> titleList = Arrays.asList("Republic of the Philippines", "Social Security System", "PROUD TO BE A FILIPINO");

    @Override
    public CustomerCard getRecognitionData(List<String> textList, CardTypeEnum cardTypeEnum) {
        logger.info("Social Security System (SSS) Card start parsing.....");
        if (CollectionUtils.isEmpty(textList)) {
            return null;
        }
        CustomerCard card = new CustomerCard();
        card.setIdType(cardTypeEnum.getCode());
        int nameTitleIndex = 1;

        List<String> valueList = new ArrayList<>();
        for (int i = 0; i < textList.size(); i++) {
            String text = textList.get(i);
            //姓名
            OCRDataProcessUtils.ConvertEntity nameEntity = OCRDataProcessUtils.convertByNoCategory(text, nameTitleIndex, "\\w+\\s+\\w+(?:\\s+\\w+)?", titleList, valueList);
            if (null != nameEntity && nameEntity.isMatchText()) {
                nameTitleIndex = nameEntity.getTitalIndex();
                String names = nameEntity.getText().toUpperCase();
                OCRDataProcessUtils.ConvertEntity namesConvert = OCRDataProcessUtils.getNamesConvert(names);
                card.setFirstName(namesConvert.getFirstName());
                card.setMiddleName(namesConvert.getMiddleName());
                card.setLastName(namesConvert.getLastName());
            }
            //号码
            OCRDataProcessUtils.ConvertEntity noEntity = OCRDataProcessUtils.convertByRegex(text, "\\d{2}-\\d{7}-\\d{1}", titleList, valueList);
            if (null != noEntity && noEntity.isMatchText()) {
                card.setIdNo(noEntity.getText());
            }
            //生日
            OCRDataProcessUtils.ConvertEntity birthEntity = OCRDataProcessUtils.convertByRegex(text, OCRDataProcessUtils.ENDLISH_DATE_REGEX, titleList, valueList);
            if (null != birthEntity && birthEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(birthEntity.getText())) {
                    Date brithDate = DateUtil.getDateFromString(birthEntity.getText(), DateUtil.FORMAT_MMM_DD_YYYY, Locale.ENGLISH);
                    card.setBirthday(brithDate);
                }
            }
        }

        return card;
    }

}
