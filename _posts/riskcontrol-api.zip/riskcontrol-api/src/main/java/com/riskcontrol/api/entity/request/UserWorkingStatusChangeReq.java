package com.riskcontrol.api.entity.request;

import com.cn.schema.urf.common.USER_WORKING_STATUS;
import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author ：zeus
 * @description：TODO
 * @date ：2023/03/14 13:59
 */
@Data
@ApiModel
public class UserWorkingStatusChangeReq extends BaseReq {

    @ApiModelProperty(value = "工作状态", example = "Available")
    private String status;

    @ApiModelProperty(value = "备注")
    private String remark;
    @ApiModelProperty(value = "提案类型")
    private String orderStyle;


    public String getOrderStyle() {
        return orderStyle;
    }

    public void setOrderStyle(String orderStyle) {
        this.orderStyle = orderStyle;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public UserWorkingStatusChangeReq() {
    }

    public UserWorkingStatusChangeReq(USER_WORKING_STATUS status, String loginName, String productId, String orderStyle) {
        this.status = status.getName();
        super.setLoginName(loginName);
        super.setProductId(productId);
        this.orderStyle = orderStyle;
    }

    @Override
    public String toString() {
        return "UserWorkingStatusChangeReq{" +
                "status='" + status + '\'' +
                ", remark='" + remark + '\'' +
                ", orderStyle='" + orderStyle + '\'' +
                ", LoginName='" + getLoginName() + '\'' +
                '}';
    }
}
