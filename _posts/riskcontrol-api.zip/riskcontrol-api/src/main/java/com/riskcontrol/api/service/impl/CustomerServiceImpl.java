package com.riskcontrol.api.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.nacos.common.utils.CollectionUtils;
import com.cn.schema.customers.*;
import com.cn.schema.products.WSProductConstants;
import com.cn.schema.request.QueryCountResponse;
import com.cn.schema.request.WSBond;
import com.cn.schema.request.WSQueryBondRequests;
import com.cn.schema.urf.*;
import com.cn.schema.urf.common.USER_WORKING_STATUS;
import com.google.api.gax.rpc.DeadlineExceededException;
import com.google.cloud.vision.v1.AnnotateImageResponse;
import com.google.cloud.vision.v1.EntityAnnotation;
import com.google.common.base.Splitter;
import com.gw.datacenter.vo.pagainate.PageModel;
import com.riskcontrol.api.constants.*;
import com.riskcontrol.api.constants.exception.ApiResultBaseEnum;
import com.riskcontrol.api.entity.CustomerCard;
import com.riskcontrol.api.entity.request.KycDispatchConfirmReq;
import com.riskcontrol.api.entity.request.*;
import com.riskcontrol.api.entity.response.OcrIdentifyRsp;
import com.riskcontrol.api.entity.response.PageModelExt;
import com.riskcontrol.api.exception.ApiBusinessException;
import com.riskcontrol.api.ocr.OcrCardFactory;
import com.riskcontrol.api.ocr.OcrClient;
import com.riskcontrol.api.service.AnalyzeCardService;
import com.riskcontrol.api.service.BaseService;
import com.riskcontrol.api.service.CustomerApiService;
import com.riskcontrol.api.service.UserWorkingStatusChangeLogService;
import com.riskcontrol.api.template.CronFeignTemplate;
import com.riskcontrol.api.utils.*;
import com.riskcontrol.common.config.C66Config;
import com.riskcontrol.common.config.UserCenterConstant;
import com.riskcontrol.common.config.UserCenterSwitch;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.pojo.KycRequest;
import com.riskcontrol.common.entity.request.ApiQueryCustomersRequest;
import com.riskcontrol.common.entity.request.BaseReq;
import com.riskcontrol.common.entity.request.kyc.*;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.kyc.RiskQueryKycRequestResponse;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import com.riskcontrol.common.service.UserCenterTemplate;
import com.riskcontrol.common.service.WsFeignTemplate;
import com.riskcontrol.common.utils.LogUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.util.Strings;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.time.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static com.riskcontrol.api.constants.Constants.DATE_TIME_FORMATTER;
import static com.riskcontrol.api.constants.Constants.PRODUCT_ID;

@Service("apiCustomerService")
@Slf4j
public class CustomerServiceImpl extends BaseService implements CustomerApiService {

    @Resource
    private WsFeignTemplate wsFeignTemplate;

    @Resource
    private CronFeignTemplate cronFeignTemplate;

    @Resource
    private UserCenterTemplate userCenterTemplate;

    @Resource
    private AWSS3Util awss3Util;

    @Autowired
    private OcrCardFactory ocrCardFactory;

    @Autowired
    private OcrClient ocrClient;

    @Autowired
    private RedisUtil redisUtil;


    @Resource
    private C66Config c66Config;


    @Resource
    private UserCenterConstant userCenterConstant;

    @Resource
    private UserWorkingStatusChangeLogService statusChangeLogService;

    public static final String DEMO_IMAGE = "http://inter-csoffice-fat-c66.k8s-fat.com/static/img/C66.png";

    @Value("${constant.gp.gli-gp-data:}")
    private String gpData;
    /**
     * kycId重复校验开关
     */
    @Value("${kyc.id.valid.enable:}")
    private String kycIdValidEnable;

    private final ExecutorService FIXED_THREAD_SERVICE = Executors.newFixedThreadPool(10);
    //ocr识别缓存key
    private final static String OCR_IDENTIFY_VALID_KEY = "KYC:OCR_IDENTIFY:%s";

    @Override
    public Boolean improveUserProfile(ImproveCustomerProfileReq req) {
        log.info("improveUserProfile req={}", req);
        if (StringUtils.isBlank(req.getLoginName())) {
            throw new BusinessException(ApiResultBaseEnum.LOGIN_NAME_EMPTY_ERROR);
        }
        WSCustomers dbWsCustomer;
        if (UserCenterSwitch.getSwitch()) {
            dbWsCustomer = userCenterTemplate.getCustomerByCustomerId(req.getProductId(), req.getCustomerId());
        } else {
            dbWsCustomer = wsFeignTemplate.getCustomerByLoginName(req.getProductId(), req.getLoginName());
        }
        if (Objects.isNull(dbWsCustomer)) {
            throw new BusinessException(ApiResultBaseEnum.LOGIN_NAME_NOT_EXIST_ERROR);
        }
        if (Objects.isNull(req.getBirthday())) {
            throw new BusinessException(ApiResultBaseEnum.BIRTHDAY_EMPTY_ERROR);
        }
        //add 年龄没有超过21岁则返回错误信息
        if (req.getBirthday() != null) {
            LocalDate birthDate = req.getBirthday().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            // 获取当前日期
            LocalDate currentDate = LocalDate.now();
            Period period = Period.between(birthDate, currentDate);
            if (period.getYears() < 21) {
                throw new BusinessException(ApiResultBaseEnum.OCR_USER_OVER_AGE_ERROR);
            }
        }
        if (!StringUtils.isBlank(req.getBirthPlace())) {
            if (req.getBirthPlace().length() > 300) {
                log.error("出生地址长度过长");
                throw new BusinessException(ApiResultBaseEnum.BIRTH_PLACE_IS_LONG);
            }
        }

        if (!StringUtils.isBlank(req.getEmployerName())) {
            if (isNumber(req.getEmployerName())) {
                throw new BusinessException(ApiResultBaseEnum.EMPLOYERNAME_ARE_NUMBER);
            } else if (req.getEmployerName().length() > 300) {
                log.error("雇主名长度过长");
                throw new BusinessException(ApiResultBaseEnum.EMPLOYERNAME_IS_LONG);
            }
        }
        //血缘标识是否启用证件号重复校验
        validKycIdNoExists(req.getTenant(), req.getFirstIdType(), req.getFirstIdNo());

        WSCustomers wsCustomer = new WSCustomers();
        req.setBranchCode(dbWsCustomer.getBranchCode());
        /** 邮箱相关开始**/
        String plainEmailNo;
        if (req.getEmail() != null) {
            plainEmailNo = this.decrypt(req, req.getEmail());
            processCustomerEmail(wsCustomer, req, plainEmailNo);
        } else {
            plainEmailNo = null;
        }
        /** 邮箱相关结束**/

        /* 拼装WSCustomers */
        wsCustomer.setLoginName(req.getLoginName());
        wsCustomer.setProductId(dbWsCustomer.getProductId());
        if (req.getBirthday() != null) {
            Instant instant = req.getBirthday().toInstant();
            LocalDateTime birthday = instant.atZone(ZoneId.systemDefault()).toLocalDateTime();
            wsCustomer.setBirthDate(birthday.format(DATE_TIME_FORMATTER)); // 生日格式为yyyy-MM-dd HH:mm:ss
            wsCustomer.setBirthday(birthday.format(DATE_TIME_FORMATTER)); // 生日格式为yyyy-MM-dd
        }
        boolean isOcrApproved;
        log.info("req.getFirstIdType() = {}", req.getFirstIdType());
        if (req.getFirstIdType() != null && req.getFirstIdScan() != null) {
            log.info("req.getFirstIdType() != null: {}", req.getFirstIdType());
            isOcrApproved = processFirstType(wsCustomer, req, dbWsCustomer);
        } else {
            isOcrApproved = false;
        }
        log.info("improveUserProfile processFirstType checkOcrIdentify isOcrApproved={}", isOcrApproved);
        long starTime = System.currentTimeMillis();
        Map<String, String> mdcContextMap = LogUtils.getMDCContextMap();
        CompletableFuture.runAsync(() -> {
            LogUtils.setMDCContextMap(mdcContextMap);
            dealWithWs(req, wsCustomer, plainEmailNo, isOcrApproved, dbWsCustomer);
        }, FIXED_THREAD_SERVICE);
        log.info("improveUserProfile processFirstType checkOcrIdentify 耗时={}", (System.currentTimeMillis() - starTime));
        return true;//默认返回true，主流程不通过抛异常出去
    }

    private void dealWithWs(ImproveCustomerProfileReq req, WSCustomers wsCustomer, String plainEmailNo, boolean isOcrApproved, WSCustomers dbWsCustomer) {
        processType2AndOtherField(wsCustomer, req);

        WSCustomers result = null;//看代码只是标识，用于是否要请求ws绑定手机或邮箱
        if (StringUtils.isBlank(req.getAddress()) && StringUtils.isBlank(req.getProvince()) && StringUtils.isBlank(req.getCity())
                && StringUtils.isBlank(req.getPostalCode()) && StringUtils.isBlank(req.getSourceOfIncome()) && StringUtils.isBlank(req.getOccupation())
                && StringUtils.isBlank(req.getGender()) && StringUtils.isBlank(req.getMiddleName()) && StringUtils.isBlank(req.getLastName()) && StringUtils.isBlank(req.getFirstName())
                && StringUtils.isBlank(req.getSecondIdType()) && StringUtils.isBlank(req.getFirstIdType()) && req.getBirthday() == null && StringUtils.isBlank(plainEmailNo)) {
            result = new WSCustomers();
        } else if (StringUtils.isAllBlank(req.getAddress(), req.getProvince(), req.getCity(), req.getPostalCode(), req.getSourceOfIncome(), req.getOccupation(),
                req.getGender(), req.getMiddleName(), req.getLastName(), req.getFirstName(), req.getSecondIdType(), plainEmailNo)
                && req.getBirthday() == null && StringUtils.isNoneBlank(req.getFirstIdScan(), req.getFirstIdType())) {
            // 如果是前端上传kyc证件的请求 不更新T_CUSTOMERS
            log.info("improveUserProfile 前端上传kyc证件的请求 不更新T_CUSTOMERS");
        } else if (!isOcrApproved) {
            //如果是自动KYC审核没有通过 不更新T_CUSTOMERS
            log.info("improveUserProfile 自动KYC审核没有通过 不更新T_CUSTOMERS");
        } else {
            log.info("improveUserProfile 更新T_CUSTOMERS start");
            if (UserCenterSwitch.getSwitch()) {
                log.info("improveUserProfile userCenterTemplate更新T_CUSTOMERS");
                wsCustomer.setCustomerId(dbWsCustomer.getCustomerId());
                result = userCenterTemplate.completeCustomer(wsCustomer);
            } else {
                log.info("improveUserProfile wsFeignTemplate更新T_CUSTOMERS");
                result = wsFeignTemplate.completeCustomer(wsCustomer);
            }
            log.info("improveUserProfile 更新T_CUSTOMERS end");
        }

        if (result != null) {
            if (StringUtils.equalsIgnoreCase(req.getProductId(), Product.getPidC68()) && StringUtils.isNotBlank(plainEmailNo)) {
                // 绑定邮箱
                WSBond wsBond = new WSBond();
                wsBond.setCustomerAppId(req.getAppId());
                wsBond.setProductId(req.getProductId());
                wsBond.setLoginName(req.getLoginName());
                wsBond.setVerifyCodeId(Constants.ZERO_STR); //不能为空；但同时WS未对正确性做校验
                wsBond.setBondType(Constants.TWO_STR);
                wsBond.setBondStatus(Constants.ONE_STR);
                wsBond.setBondContext(plainEmailNo);
                wsBond.setIpAddress(req.getIpAddress());
                wsBond.setCreatedBy(req.getLoginName());
                wsBond.setCreatedDate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
                wsBond.setCustomerId(req.getCustomerId());

                if (UserCenterSwitch.getSwitch()) {
                    userCenterTemplate.bindMobileNoOrEmail(wsBond);
                } else {
                    wsFeignTemplate.bindMobileNoOrEmail(wsBond);
                }
            }
        }
    }


    /**
     * 处理用户邮箱信息*
     *
     * @param wsCustomer   wsCustomer
     * @param req          req
     * @param plainEmailNo plainEmailNo
     */
    private void processCustomerEmail(WSCustomers wsCustomer, ImproveCustomerProfileReq req, String plainEmailNo) {
        if (!this.isEmail(plainEmailNo, req)) {
            throw new BusinessException(ApiResultBaseEnum.EMAIL_INVALID_ERROR);
        }
        if (Constants.ONE_STR.equals(userCenterConstant.getConstantValue(Constants.CREATE_REAL_CUSTOMER_CHECK_EMAIL))) {
            if (StringUtils.isBlank(req.getEmail())) {
                throw new BusinessException(ApiResultBaseEnum.EMAIL_INVALID_ERROR);
            }

            if (UserCenterSwitch.getSwitch()) {
                boolean wsCustomers = userCenterTemplate.checkCustomerInfo(req.getProductId(), Constants.SIX_INT, plainEmailNo);
                if (wsCustomers) {
                    throw new BusinessException(ApiResultBaseEnum.BIND_EMAIL_USED_ERROR);
                }
            } else {
                WSQueryCustomers wsQueryCustomers = new WSQueryCustomers();
                wsQueryCustomers.setEmail(plainEmailNo);
                WSCustomers wsCustomers = wsFeignTemplate.checkCustomerV2(wsQueryCustomers, Constants.SIX_STR, req.getProductId());
                if (Objects.isNull(wsCustomers)) {
                    throw new BusinessException(ApiResultBaseEnum.BIND_EMAIL_USED_ERROR);
                }
            }
        }
        if (StringUtils.equalsIgnoreCase(req.getProductId(), CustomerOcrCardReq.Product.getPidC68()) && StringUtils.isNotBlank(plainEmailNo)) {
            // 查询该用户是否已绑定
            WSQueryBondRequests wsQueryBondRequest = new WSQueryBondRequests();
            wsQueryBondRequest.setProductId(req.getProductId());
            wsQueryBondRequest.setLoginName(req.getLoginName());
            wsQueryBondRequest.setCustomerId(req.getCustomerId());
            wsQueryBondRequest.setBondType(Constants.TWO_STR);
            wsQueryBondRequest.setBondStatus(Constants.ONE_STR);

            if (UserCenterSwitch.getSwitch()) {
                List<WSBond> bondList = userCenterTemplate.queryBondRequest(wsQueryBondRequest);
                if (bondList != null && bondList.size() > 0) {
                    throw new BusinessException(ApiResultBaseEnum.BIND_EMAIL_EXIST_ERROR);
                }
            } else {
                int size = wsFeignTemplate.queryCountBondRequest(wsQueryBondRequest);
                if (size > 0) {
                    throw new BusinessException(ApiResultBaseEnum.BIND_EMAIL_EXIST_ERROR);
                }
            }
            // 查邮箱绑定次数限制
            int bindLimit = 1;
            // nacos获取
            String x1 = c66Config.getSameEmailBindTimes();
            if (StringUtils.isNotBlank(x1) && NumberUtils.isDigits(x1)) {
                bindLimit = Integer.parseInt(x1);
            }
            // 判断邮箱是否超过绑定限制
            wsQueryBondRequest = new WSQueryBondRequests();
            wsQueryBondRequest.setProductId(req.getProductId());
            wsQueryBondRequest.setBondContext(plainEmailNo);  // 不需加密
            wsQueryBondRequest.setBondType(Constants.TWO_STR); // 1=手機號, 2=郵箱
            wsQueryBondRequest.setBondStatus(Constants.ONE_STR); // 0=沒綁定, 1=綁定
            wsQueryBondRequest.setQueryAllAccount(Constants.ONE_STR);
            List<WSBond> wsBondList;
            if (UserCenterSwitch.getSwitch()) {
                wsBondList = userCenterTemplate.queryBondRequest(wsQueryBondRequest);
            } else {
                wsBondList = wsFeignTemplate.queryBondRequest(wsQueryBondRequest);
            }
            if (CollectionUtils.isNotEmpty(wsBondList) && wsBondList.size() >= bindLimit) {
                log.error("达到绑定上限，目标邮箱被绑定次数:[{}]，可绑定次数为[{}],", wsBondList.size(), bindLimit);
                throw new BusinessException(ApiResultBaseEnum.BIND_EMAIL_USED_ERROR);
            }
        }
        wsCustomer.setEmail(plainEmailNo);
        wsCustomer.setEmailMd5(DigestUtils.md5Hex(plainEmailNo));
    }

    /**
     * 设置证件照1类型*
     *
     * @param wsCustomer   wsCustomer
     * @param req          req
     * @param dbWsCustomer dbWsCustomer
     */
    private Boolean processFirstType(WSCustomers wsCustomer, ImproveCustomerProfileReq req, WSCustomers dbWsCustomer) {
        boolean isOcrApprovedTemp = false;
        // 这里改成给kyc提案表写入数据
        RiskQueryKycRequest kycRequestQuery = new RiskQueryKycRequest();
        kycRequestQuery.setProductId(dbWsCustomer.getProductId());
        kycRequestQuery.setLoginName(dbWsCustomer.getLoginName());
        kycRequestQuery.setCustomerId(dbWsCustomer.getCustomerId());

        kycRequestQuery.setPageNum(1);
        kycRequestQuery.setPageSize(1);

        RiskQueryKycRequestResponse kycRequestResponse = cronFeignTemplate.queryKycRequest(kycRequestQuery);

        String phone = new PHPDESEncrypt(dbWsCustomer.getProductId(), "03").decrypt(dbWsCustomer.getPhone());
        KycRequest kycRequest = CollectionUtils.isEmpty(kycRequestResponse.getData()) ? null : kycRequestResponse.getData().get(0);
        // kyc 数据 用户可在在无提案或者拒绝状态可修改,这里都是新增kyc提案
        String kycStatus = kycRequest == null ? null : kycRequest.getStatus();
        if (StringUtils.equals(kycStatus, Constants.ZERO_STR)) {
            // 待审核时返回
            throw new BusinessException(ApiResultBaseEnum.KYC_REVIEWING);
        } else if (StringUtils.equals(kycStatus, Constants.ONE_STR)) {
            // 已审核时返回提示
            throw new BusinessException(ApiResultBaseEnum.KYC_APPROVED);
        }
        kycRequest = new KycRequest();
        BeanUtils.copyProperties(req, kycRequest);

        //add 如果是ocr识别的则校验是否修改
        String identifyId = req.getIdentifyId();

        if (StringUtils.isNotEmpty(identifyId)) {
            OcrIdentifyRsp ocrIdentify = redisUtil.get(String.format(OCR_IDENTIFY_VALID_KEY, req.getCustomerId()));
            //血缘标识来源校验开关是否开启
            String[] enableStr = kycIdValidEnable.split(Constants.COMMA_SYMBOL);
            boolean validIdNo = true;
            if (Arrays.asList(enableStr).contains(req.getTenant())) {
                 validIdNo = StrUtil.equals(ocrIdentify.getIdNo(), req.getFirstIdNo());
                log.info("processFirstType checkOcrIdentify validIdNo={}", validIdNo);
            }
            // 临时开关控制是否直接走人工
            boolean needManual = false;
            String kycManual = ProductConstantsUtil.obtainProductConstant(PRODUCT_ID, "0016", "WEBSITE_KYC_MANUAL");
            if(StringUtils.isNotBlank(kycManual) && StringUtils.isNotBlank(req.getTenant())
                    && Arrays.asList(kycManual.split(",")).contains(req.getTenant())){
                needManual = true;
            }
            //校验ocr数据是否修改过
            isOcrApprovedTemp = validIdNo
                    && req.getBirthday().equals(ocrIdentify.getBirthday())
                    && StrUtil.equalsIgnoreCase(ocrIdentify.getFirstName(),req.getFirstName())
                    && StrUtil.equalsIgnoreCase(ocrIdentify.getMiddleName(),req.getMiddleName())
                    && StrUtil.equalsIgnoreCase(ocrIdentify.getLastName(),req.getLastName())
                    && !needManual;
            //校验是否修改
//                CustomerOcrCardReq ocrCardReq = new CustomerOcrCardReq();
//                BeanUtils.copyProperties(req, ocrCardReq);
//                //没有修改ocr识别结果，自动审核通过
//                isOcrApprovedTemp = wsFeignTemplate.checkOcrIdentify(ocrCardReq);
            log.info("processFirstType checkOcrIdentify isOcrApprovedTemp={}", isOcrApprovedTemp);
        }
        verifyKyc(kycRequest, req.getFirstIdType(), req.getFirstIdScan(), req.getFirstIdNo(), phone, req.getDomainName(), isOcrApprovedTemp);
        // 自动审核通过时kyc重复标记、年龄超过100标记start
        if (StrUtil.equals(kycRequest.getStatus(), Constants.ONE_STR)) {
            // kyc 年龄标记 start
            LocalDate birthDate = req.getBirthday().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            // 获取当前日期，用于计算年龄
            LocalDate currentDateTemp = LocalDate.now();
            Period period = Period.between(birthDate, currentDateTemp);
            log.info("processFirstType 自动审核通过, 年龄标记 req.getBirthday={}, period years={} , days={}", req.getBirthday(), period.getYears(), period.getDays());
            if (period.getYears() > Constants.KYC_FLAG_AGE_100 || (period.getYears() == Constants.KYC_FLAG_AGE_100 && period.getDays() > 0)) {
                kycRequest.setDoubtful(Constants.ONE_STR);
            }
            // kyc 年龄标记 end

            log.info("processFirstType 自动审核通过, kyc重复标记 req.getCustomerId={} ", req.getCustomerId());
            String birthdayStr = DateUtil.getCurrentDateString(req.getBirthday(), DateUtil.YYMMDD);
            RiskQueryKycRequest kycRequestQueryCount = new RiskQueryKycRequest();
            kycRequestQueryCount.setProductId(req.getProductId());
            kycRequestQueryCount.setSex(req.getGender());
            kycRequestQueryCount.setBirthday(birthdayStr);
            kycRequestQueryCount.setFirstName(req.getFirstName());
            kycRequestQueryCount.setMiddleName(req.getMiddleName());
            kycRequestQueryCount.setLastName(req.getLastName());
            kycRequestQueryCount.setStatusList("1;");

            int countKYC = cronFeignTemplate.countKycRequest(kycRequestQueryCount, req.getProductId());
            log.info("processFirstType countKYC={}", countKYC);
            if (countKYC > 0) {
                kycRequest.setRepetation(Constants.ONE_STR);
            }
        }
        // 自动审核通过时kyc重复标记、年龄超过100标记end
        kycRequest.setCustomerId(dbWsCustomer.getCustomerId());
        kycRequest.setCreatedBy(BizTypes.OPERATER_SYS);
        kycRequest.setUpdateBy(BizTypes.OPERATER_SYS);
        String currentDate = DateUtil.getCurrentDate();
        kycRequest.setCreatedDate(currentDate);
        kycRequest.setUpdateDate(currentDate);
        //性别，兼容之前性别传空的情况
        kycRequest.setSex(StringUtils.isEmpty(req.getGender()) ? "M" : req.getGender());
        //kyc添加生日
        if (null != req.getBirthday()) {
            String birthdayStr = DateUtil.getCurrentDateString(req.getBirthday(), DateUtil.YYMMDD);
            kycRequest.setBirthday(birthdayStr);
        }
        kycRequest.setCountry("Philippines");
        // product 设置血缘字段
        log.info("processFirstType req.getTenant={} ,dbWs.getTenant={}", req.getTenant(), dbWsCustomer.getTenant());
        kycRequest.setProduct(req.getTenant());
        // PAY-27 设置渠道
        kycRequest.setChannel(ChannelEnum.WEBSITE.getType());
        log.info("调用 cronFeignTemplate addKycRequest {}", JSONObject.toJSONString(kycRequest.toString()));
        CreateKycRequestResponse cronResponse = cronFeignTemplate.addKycRequest(kycRequest, dbWsCustomer.getProductId());
        if (cronResponse.getCount() < 1) {
            // 已审核时返回提示
            throw new BusinessException(ApiResultBaseEnum.ERROR_CREATE_KYC);
        }
        // 證件 1
        wsCustomer.setFirstIdType(req.getFirstIdType());//1.UM ID 2.TIN ID 3.SSS ID 4.Driver License 5.Passport 6.Voter ID
        wsCustomer.setFirstNoType(req.getFirstIdNo());
        wsCustomer.setFirstIdScan(kycRequest.getIdScan());
        return isOcrApprovedTemp;
    }


    /**
     * 设置证件照2类型和其他字段*
     *
     * @param wsCustomer wsCustomer
     * @param req        req
     */
    private void processType2AndOtherField(WSCustomers wsCustomer, ImproveCustomerProfileReq req) {
        if (req.getSecondIdType() != null && req.getSecondIdNo() != null && req.getSecondIdScan() != null) {
            // 證件 2
            wsCustomer.setSecondIdType(req.getSecondIdType());//1.UM ID 2.TIN ID 3.SSS ID 4.Driver License 5.Passport 6.Voter ID
            wsCustomer.setSecondNoType(req.getSecondIdNo());
            // 测试环境上传静态图片, 其他环境上传证件照至OSS云存储
            if (isSkipEnvironment(req.getProductId())) {
                wsCustomer.setSecondIdScan(UUID.randomUUID().toString());
            } else {
                // 前端先調用圖片上傳後返回key, 再將key傳回
                wsCustomer.setSecondIdScan(req.getSecondIdScan());
            }
        }

        if (StringUtils.isNotBlank(req.getFirstName())) {
            wsCustomer.setFirstName(req.getFirstName().trim());
        }
        if (StringUtils.isNotBlank(req.getLastName())) {
            wsCustomer.setLastName(req.getLastName().trim());
        }
        if (StringUtils.isNotBlank(req.getMiddleName())) {
            wsCustomer.setMiddleName(req.getMiddleName().trim());
        }
        if (StringUtils.isNotBlank(req.getGender())) {
            wsCustomer.setSex(req.getGender());
        }

        // Pagcor第四期需求新增字段
        if (StringUtils.isNotBlank(req.getOccupation())) {
            wsCustomer.setOccupation(req.getOccupation());
        }
        if (StringUtils.isNotBlank(req.getSourceOfIncome())) {
            wsCustomer.setSourceOfIncome(req.getSourceOfIncome());
        }
        if (StringUtils.isNotBlank(req.getAddress())) {
            wsCustomer.setAddress(req.getAddress());
        }
        if (StringUtils.isNotBlank(req.getProvince())) {
            wsCustomer.setProvince(req.getProvince());
        }
        if (StringUtils.isNotBlank(req.getCity())) {
            wsCustomer.setCity(req.getCity());
        }
        if (StringUtils.isNotBlank(req.getPostalCode())) {
            wsCustomer.setPostalCode(req.getPostalCode());
        }
    }


    private void verifyKyc(KycRequest kycRequest, String firstIdType, String firstIdScan, String firstIdNo, String phone, String domainName, boolean isOcrResult) {
        try {
            // TODO linux环境需要挂载依赖库
            boolean isNameMatched = false;
            boolean isIDNoMatched = false;
            // 姓名 和ID 全匹配成功 KYC setting提案自动通过 ,否则待审核
            if (isOcrResult) {
                String currentDate = DateUtil.getCurrentDate();
                kycRequest.setStatus(Constants.ONE_STR); // 通过
                kycRequest.setApprovedBy(BizTypes.AUTO_REVIEWER);
                kycRequest.setApprovedDate(currentDate);
                kycRequest.setDispatchStatus(2);//已确认
                kycRequest.setAssigneeTime(currentDate);
                kycRequest.setAssigneeBy(BizTypes.AUTO_REVIEWER);
//                sendSMS(kycRequest.getProductId(), Constants.CUSTOMER_KYC_SUCCESS_SMS_TYPE, kycRequest.getLoginName(), phone, domainName);
            } else {
                // 暂改为待审核状态
                kycRequest.setStatus(Constants.ZERO_STR);
            }
        } catch (Exception ex) {
            kycRequest.setStatus(Constants.ZERO_STR); // 待审核
            log.error("kyc证件识别异常：", ex);
            throw new BusinessException(ApiResultBaseEnum.KYC_VERIFICATION_ERROR);
        }
        kycRequest.setIdType(firstIdType);
        kycRequest.setIdNo(firstIdNo);
        if (isSkipEnvironment(kycRequest.getProductId())) {
            kycRequest.setIdScan(UUID.randomUUID().toString());
        } else {
            log.info("证件照 key1：{} ", firstIdScan);
            // 前端先調用圖片上傳後返回key, 再將key傳回
            kycRequest.setIdScan(firstIdScan);
        }
    }


    /**
     * ocr识别证件信息并返回识别内容
     *
     * @param req
     * @return
     */
    @Override
    public OcrIdentifyRsp ocrIdentify(OcrIdentifyReq req) {
        log.info("ocrIdentify start CustomerId:{}, req={}", req.getCustomerId(), req);
        OcrIdentifyRsp resp = new OcrIdentifyRsp();
        CustomerOcrCardReq ocrCardReq = new CustomerOcrCardReq();
        BeanUtil.copyProperties(req, ocrCardReq);

        CardTypeEnum cardTypeEnum = CardTypeEnum.findEnumByCode(req.getIdType());
        if (cardTypeEnum == null) {
            //OCR证件类型没有找到
            log.error("document type not found. type:{}", req.getIdType());
            throw new BusinessException(ApiResultBaseEnum.CUSTOMER_ID_TYPE_NOT_FOUND_ERROR);
        }
        String imageUrl = "";
        try {
            imageUrl = req.getIdScan().contains("_md5") ? awss3Util.s3GetTxtUrl(req.getIdScan()) : awss3Util.s3GetUrl(req.getIdScan());
        } catch (Exception e) {
            log.error("證件資訊轉換時發生錯誤, {}", ExceptionUtils.getStackTrace(e));
            throw new BusinessException(ApiResultBaseEnum.OCR_RECOGNITION_ERROR);
        }
        try {
            if (StringUtils.isEmpty(imageUrl)) {
                log.error("ocrIdentify ocr文件不存在,idScan={}", req.getIdScan());
                throw new BusinessException(ApiResultBaseEnum.OCR_RECOGNITION_ERROR);
            }
            //解析证件信息
            resp = identifyImage(imageUrl, req.getIdType(), cardTypeEnum);

        } catch (DeadlineExceededException e) {
            log.error("ocrIdentify ocr识别超时, {}", ExceptionUtils.getStackTrace(e));
            throw new BusinessException(ApiResultBaseEnum.OCR_RECOGNITION_ERROR);
        }
        //保存到表中
        BeanUtils.copyProperties(resp, ocrCardReq);
//        OcrIdentify ocrIdentify = wsFeignTemplate.saveOcrIdentify(ocrCardReq);//不再保存到ws
        //缓存orc识别信息
        String identifyId = String.format(OCR_IDENTIFY_VALID_KEY, req.getCustomerId());
        redisUtil.set(identifyId, resp, 1, TimeUnit.DAYS);
        resp.setIdentifyId(identifyId);
        log.info("ocrIdentify  resp={}", JSONObject.toJSONString(resp));
        return resp;
    }


    @Override
    @Transactional
    public Boolean updateKycRequest(UpdateKycRequestReq req) {
        log.info("updateKycRequest req={}", req);
        if (StringUtils.isBlank(req.getOperator())) {
            throw new BusinessException(ApiResultBaseEnum.LOGIN_NAME_EMPTY_ERROR);
        }

        WSCustomers dbCustomer;
        if (UserCenterSwitch.getSwitch()) {
            dbCustomer = userCenterTemplate.getSimpleCustomerByLoginName(req.getProductId(), req.getLoginName());
        } else {
            dbCustomer = wsFeignTemplate.getCustomerByLoginName(req.getProductId(), req.getLoginName());
        }
        if (Objects.isNull(dbCustomer)) {
            throw new BusinessException(ApiResultBaseEnum.ACCOUNT_NOT_EXIST_ERROR);
        }
//        Boolean switchFlag = wsFeignTemplate.getRiskApiWsSwitch();
        KycRequest wsKycRequest = getWSKycRequest(req);

        RiskQueryKycRequest query = new RiskQueryKycRequest();
        query.setCustomerId(dbCustomer.getCustomerId());
        query.setLoginName(dbCustomer.getLoginName());
        query.setProductId(dbCustomer.getProductId());
        query.setId(req.getId());
        query.setPageSize(1);
        query.setPageNum(1);

        RiskQueryKycRequestResponse kycRequestResponse = cronFeignTemplate.queryKycRequest(query);
        log.info("  wsFeignTemplate.queryKycRequest  kycRequestResponse:{}", JSONObject.toJSONString(kycRequestResponse));
        KycRequest dbKycRequest = kycRequestResponse.getData().get(0);
        //这里是需要修改
        if (!StringUtils.equals(dbKycRequest.getStatus(), Constants.ZERO_STR)) {
            throw new BusinessException(ApiResultBaseEnum.CUSTOMER_MODIFY_FAILED_ERROR);
        }
        //存在证件id和证件类型情况下判断是否有修改
        if (StringUtils.isNotEmpty(req.getIdType()) && StringUtils.isNotEmpty(req.getIdNo())) {
            //与获取到的数据不一致时，才做校验
            if (!StrUtil.equals(dbKycRequest.getIdType(), req.getIdType()) || !StrUtil.equals(dbKycRequest.getIdNo(), req.getIdNo())) {
                Boolean exists = cronFeignTemplate.validKycIdAndType(Integer.valueOf(req.getIdType()), req.getIdNo());
                if (exists) {
                    throw new BusinessException(ResultEnum.ERROR_VALID_KYC_ID);
                }
                wsKycRequest.setIdType(req.getIdType());
                wsKycRequest.setIdNo(req.getIdNo());
            }
        }
        String phone = new PHPDESEncrypt(dbCustomer.getProductId(), "03").decrypt(dbCustomer.getPhone());
        if (StringUtils.equals(wsKycRequest.getStatus(), Constants.ONE_STR)) {
            // 通过
            // 修改客户表证件信息
            dbCustomer.setPhone(null);
            dbCustomer.setEmail(null);
            dbCustomer.setLastUpdatedBy(req.getOperator());
            dbCustomer.setLastUpdate(DateUtil.getCurrentDate());
            dbCustomer.setFirstIdScan(dbKycRequest.getIdScan());
            dbCustomer.setFirstNoType(wsKycRequest.getIdNo());
            //把idType存入到t_customers表中
            dbCustomer.setFirstIdType(wsKycRequest.getIdType() == null ? dbKycRequest.getIdType() : wsKycRequest.getIdType());
            dbCustomer.setFirstName(wsKycRequest.getFirstName());
            dbCustomer.setLastName(wsKycRequest.getLastName());
            dbCustomer.setMiddleName(wsKycRequest.getMiddleName());
            dbCustomer.setSex(wsKycRequest.getSex());
            dbCustomer.setAddress(wsKycRequest.getAddress());
            dbCustomer.setNationality(wsKycRequest.getCountry());
            dbCustomer.setBirthDate(wsKycRequest.getBirthday());
            // 设置职业、收入来源 随机填入 + 年收入
            dbCustomer.setOccupation(Constants.OCCUPATION_ARRAY[(int) (Math.random() * Constants.OCCUPATION_ARRAY.length)]);
            dbCustomer.setSourceOfIncome(Constants.SOURCE_OF_INCOME_ARRAY[(int) (Math.random() * Constants.SOURCE_OF_INCOME_ARRAY.length)]);
            dbCustomer.setAnnualIncome(Constants.ANNUAL_INCOME_ARRAY[(int) (Math.random() * Constants.ANNUAL_INCOME_ARRAY.length)]);
            // SLDBUG-1228 【h5-pc-2.0】kyc-门店端待实现功能列表 - 根据门店 会获取 省市和邮编
            if (StringUtils.isAllBlank(dbCustomer.getCity(), dbCustomer.getProvince(), dbCustomer.getPostalCode())) {
                dbCustomer.getBranchName();
                WSQueryBranch queryBranch = new WSQueryBranch();
                queryBranch.setBranchCode(dbCustomer.getBranchCode());
                queryBranch.setPageNum(1);
                queryBranch.setPageSize(1);
                QueryBranchResponse branchResponse = wsFeignTemplate.queryBranchList(dbCustomer.getProductId(), queryBranch);
                if (CollectionUtils.isNotEmpty(branchResponse.getData())) {
                    WSBranch branch = branchResponse.getData().get(0);
                    String city = branch.getCity();
                    dbCustomer.setCity(city);
                    Constants.CITY_POSTAL_CODE_JSON.keySet().forEach(province -> {
                        JSONObject cities = Constants.CITY_POSTAL_CODE_JSON.getJSONObject(province);
                        if (cities.containsKey(city)) {
                            dbCustomer.setProvince(province);
                            dbCustomer.setPostalCode(cities.getString(city));
                        }
                    });
                }
            }
            ModifyAccountResponse modifyAccountResponse;
            if (UserCenterSwitch.getSwitch()) {
                log.info("userCenterTemplate modifyAccount..........");
                modifyAccountResponse = userCenterTemplate.modifyAccount(dbCustomer, Constants.ONE_STR);
            } else {
                log.info("wsFeignTemplate modifyAccount.......");
                modifyAccountResponse = wsFeignTemplate.modifyAccount(dbCustomer, Constants.ONE_STR);
            }

            if (StringUtils.isNotBlank(modifyAccountResponse.getWsErrorMsg())) {
                throw new BusinessException(ApiResultBaseEnum.WS_EXCEPTION);
            }
            // kyc审批通过时 如果客户 非激活 就给激活
            if (StringUtils.equals(dbCustomer.getActivation(), Constants.ZERO_STR)) {
                CustomerActivationReq activationReq = new CustomerActivationReq();
                BeanUtils.copyProperties(dbCustomer, activationReq);
                activationReq.setActivation(Constants.ONE_STR);
                activationReq.setCustomerName(dbCustomer.getLoginName());
                activationReq.setLoginName(req.getOperator());
                customerActivation(activationReq);
            }
//            FunctionHelper.doIt(switchFlag, cronFeignTemplate::updateKycRequest, wsFeignTemplate::updateKycRequest, wsKycRequest, req.getProductId());
            cronFeignTemplate.updateKycRequest(wsKycRequest, req.getProductId());
//            修改kyc调度状态，调度派单功能不需要了
//            KycRequest wsPbcRequest = new KycRequest();
//            wsPbcRequest.setId(req.getId());
//            wsPbcRequest.setProductId(req.getProductId());
//            wsPbcRequest.setLoginName(req.getLoginName());
//            wsPbcRequest.setCustomerId(req.getCustomerId());
//            wsPbcRequest.setDispatchStatus(4);
//            wsPbcRequest.setAssigneeTime(this.buildTimeEx(new Date()));
//            wsPbcRequest.setAssigneeBy(req.getOperator());
//            wsPbcRequest.setApprovedBy(req.getOperator());
//            wsPbcRequest.setMiddleName(req.getMiddleName());
//            cronFeignTemplate.pbcDispatch(wsPbcRequest, req.getProductId());
        } else if (StringUtils.equals(wsKycRequest.getStatus(), Constants.THREE_STR)) {
            // 拒绝
//            ModifyKycRequestResponse result = FunctionHelper.doIt(switchFlag, cronFeignTemplate::updateKycRequest, wsFeignTemplate::updateKycRequest, wsKycRequest, req.getProductId());
            ModifyKycRequestResponse result = cronFeignTemplate.updateKycRequest(wsKycRequest, req.getProductId());
            // todo 暂时注释 发送短信功能
//            sendSMS(req.getProductId(), Constants.CUSTOMER_KYC_FAIL_SMS_TYPE, req.getLoginName(), dbCustomer.getSiteId(), phone, wsKycRequest.getRemark());
        }
        return true;
    }


    @Override
    @Transactional
    public Boolean updatePbcRequest(UpdateKycRequestReq req) {

        if (StringUtils.isEmpty(req.getLoginName())) {
            throw new ApiBusinessException(ApiResultBaseEnum.LOGIN_NAME_EMPTY_ERROR);
        }
        if (StringUtils.isBlank(req.getOperator())) {
            throw new ApiBusinessException(ApiResultBaseEnum.LOGIN_NAME_EMPTY_ERROR);

        }

        WSCustomers dbCustomer;
        if (StringUtils.equals(Constants.ONE_STR, c66Config.getUserCenterCallSwitch())) {
            dbCustomer = userCenterTemplate.getSimpleCustomerByLoginName(req.getProductId(), req.getLoginName());
        } else {
            dbCustomer = wsFeignTemplate.getCustomerByLoginName(req.getProductId(), req.getLoginName());
        }
        if (Objects.isNull(dbCustomer)) {
            throw new ApiBusinessException(ApiResultBaseEnum.ACCOUNT_NOT_EXIST_ERROR);

        }

        RiskQueryKycRequest query = new RiskQueryKycRequest();
        query.setCustomerId(dbCustomer.getCustomerId());
        query.setLoginName(dbCustomer.getLoginName());
        query.setProductId(dbCustomer.getProductId());
        query.setPageSize(1);
        query.setPageNum(1);
        query.setPbcStatus("0");
        query.setStatusList(StringUtils.join("1", ";"));

        /**
         * 原 ws 接口
         */
        //QueryKycRequestResponse kycRequestResponse = wsFeignTemplate.queryKycRequest(query, dbCustomer.getProductId());

        /**
         * 新 cron 接口
         */
        RiskQueryKycRequestResponse kycRequestResponse = cronFeignTemplate.queryKycRequest(query);

        if (kycRequestResponse.getData().size() == 0) {
            throw new ApiBusinessException(ApiResultBaseEnum.CUSTOMER_MODIFY_FAILED_ERROR);

        }
        KycRequest dbKycRequest = kycRequestResponse.getData().get(0);

        if (!StringUtils.equals(dbKycRequest.getStatus(), Constants.ONE_STR)) {
            throw new ApiBusinessException(ApiResultBaseEnum.CUSTOMER_MODIFY_FAILED_ERROR);
        }
        KycRequest wsKycRequest = new KycRequest();
        wsKycRequest.setId(req.getId());
        wsKycRequest.setProductId(req.getProductId());
        wsKycRequest.setLoginName(req.getLoginName());
        wsKycRequest.setCustomerId(req.getCustomerId());
        wsKycRequest.setUpdateBy(req.getOperator());
        wsKycRequest.setUpdateDate(DateUtil.getCurrentDate());
        wsKycRequest.setApprovedDate(DateUtil.getCurrentDate());
        wsKycRequest.setApprovedBy(req.getOperator());
        wsKycRequest.setPbcStatus(Integer.parseInt(req.getPbcStatus()));

        if (StringUtils.isNotBlank(req.getFirstName())) {
            wsKycRequest.setFirstName(req.getFirstName());
        } else {
            throw new ApiBusinessException(ApiResultBaseEnum.FIRST_NAME_EMPTY_ERROR);
        }
        if (StringUtils.isNotBlank(req.getMiddleName())) {
            wsKycRequest.setMiddleName(req.getMiddleName());
        }
        if (StringUtils.isNotBlank(req.getLastName())) {
            wsKycRequest.setLastName(req.getLastName());
        } else {
            throw new ApiBusinessException(ApiResultBaseEnum.LAST_NAME_EMPTY_ERROR);
        }
        if (StringUtils.isNotBlank(req.getSex())) {
            wsKycRequest.setSex(req.getSex());
        }
        if (StringUtils.isNotBlank(req.getBirthday())) {
            try {
                LocalDate.parse(req.getBirthday());
            } catch (Exception e) {
                throw new ApiBusinessException(ApiResultBaseEnum.BIRTHDAY_INVALID_ERROR);
            }
            wsKycRequest.setBirthday(req.getBirthday());
        } else {
            throw new ApiBusinessException(ApiResultBaseEnum.BIRTHDAY_EMPTY_ERROR);
        }

        if (StringUtils.isNotBlank(req.getPbcStatus()) && ("1".equals(req.getPbcStatus()) || ("3".equals(req.getPbcStatus()) && !Strings.isBlank(req.getRemark())))) {
            wsKycRequest.setPbcStatus(Integer.parseInt(req.getPbcStatus()));
            wsKycRequest.setRemark(req.getRemark());
        } else {
            log.info("当前请求数据:{}", JSON.toJSONString(req));

            throw new ApiBusinessException(ApiResultBaseEnum.PBCSTATUS_REMARK_NOT_MATCH);

        }

        if (1 == wsKycRequest.getPbcStatus()) {
            // 通过,修改客户表证件信息,修改t_customers表
            dbCustomer.setPhone(null);
            dbCustomer.setEmail(null);
            dbCustomer.setLastUpdatedBy(req.getOperator());
            dbCustomer.setLastUpdate(DateUtil.getCurrentDate());
            dbCustomer.setFirstName(wsKycRequest.getFirstName());
            dbCustomer.setLastName(wsKycRequest.getLastName());
            dbCustomer.setMiddleName(wsKycRequest.getMiddleName());
            dbCustomer.setSex(wsKycRequest.getSex());
            dbCustomer.setBirthDate(wsKycRequest.getBirthday());
            log.info("修改客户表信息 updatePbcRequest dbCustomer={}", JSON.toJSONString(dbCustomer));
            ModifyAccountResponse modifyAccountResponse = Optional.ofNullable(UserCenterSwitch.getSwitch()).filter(Boolean::booleanValue).
                    map(e -> userCenterTemplate.modifyAccount(dbCustomer, Constants.ONE_STR)).
                    orElseGet(() -> wsFeignTemplate.modifyAccount(dbCustomer, Constants.ONE_STR));
            if (StringUtils.isNotBlank(modifyAccountResponse.getWsErrorMsg())) {
                throw new ApiBusinessException(ApiResultBaseEnum.CUSTOMER_MODIFY_FAILED_ERROR);

            }
        }
        cronFeignTemplate.pbcModifyStatus(wsKycRequest, req.getProductId());

        return true;
    }

    @Override
    public Response<PageModel<WSKycSheetRequest>> queryKycSheetRequests(QueryKycRequestReq req) throws Exception {

        Response<PageModel<WSKycSheetRequest>> result = new Response<PageModel<WSKycSheetRequest>>();
        if (null == req.getPageNo()){
            req.setPageNo(1);
        }
        if (null == req.getPageSize()){

            req.setPageSize(100);
        }

        Response<PageModel<KycRequest>> data = queryKycRequestsNew2(req);

        PageModel<WSKycSheetRequest> pages = new PageModel<>(0, req.getPageNo(), req.getPageSize());
        List<WSKycSheetRequest> result2 = new ArrayList<>();
        if (data.getBody().getData().size() > 0) {
            for (KycRequest wsKycRequest : data.getBody().getData()) {
                WSKycSheetRequest o = new WSKycSheetRequest();
                BeanUtils.copyProperties(wsKycRequest, o);
                o.setBillNo("\t" + o.getBillNo());

                o.setRealName(wsKycRequest.getFirstName() + (wsKycRequest.getMiddleName() == null ? " " : (" " + wsKycRequest.getMiddleName() + " ")) + wsKycRequest.getLastName());

                if ((wsKycRequest.getStatus().equals("1") && wsKycRequest.getPbcStatus() == 0) || wsKycRequest.getPbcStatus() == null) {
                    o.setPbcStatus("");
                } else {
                    o.setPbcStatus(PBCStatusEnum.getPbcEnumByStatus(wsKycRequest.getPbcStatus()).getPbcStatusString());
                }

                result2.add(o);
            }
            pages.setTotalRow(data.getBody().getTotalRow());
            pages.setTotalPage(data.getBody().getTotalPage());
        }
        pages.setData(result2);
        result.setBody(pages);
        return result;
    }

    private Response<PageModel<KycRequest>> queryKycRequestsNew2(QueryKycRequestReq req) {

        Response<PageModel<KycRequest>> response = new Response<>();

        RiskQueryKycRequest query = new RiskQueryKycRequest();
        BeanUtils.copyProperties(req, query);
        query.setIsExport(true);//导出参数，影响排序效果
        query.setPageNum(req.getPageNo());
        query.setPageSize(req.getPageSize());
        query.setLoginName(req.getCustomerName());

        WSQueryUsers wsQueryUsers = new WSQueryUsers();
        wsQueryUsers.setLoginName(req.getLoginName());
        wsQueryUsers.setProductId(req.getProductId());

        //通过用户登录名查询用户信息,包括角色信息
        query.setCreatedDateBegin(req.getCreatedDateBegin());
        query.setCreatedDateEnd(req.getCreatedDateEnd());
        query.setAssigneeDateBegin(req.getAssigneeDateBegin());
        query.setAssigneeDateEnd(req.getAssigneeDateEnd());
        query.setBillNo(req.getBillNo());

        if (req.getProcessType() != null) {
            if (req.getProcessType() > 3) {
                query.setPbcStatus(String.valueOf(req.getProcessType() - 4));
                query.setStatusList("1;");
            }
            if (req.getProcessType() <= 3) {
                if (req.getProcessType() == 3) {
                    query.setStatusList(StringUtils.join(req.getProcessType(), ";", 2, ";"));
                } else {
                    query.setStatusList(StringUtils.join(req.getProcessType(), ";"));
                }
            }
        }
        int count = cronFeignTemplate.countKycPbcRequest(query, req.getProductId());

        RiskQueryKycRequestResponse kycRequestResponse = cronFeignTemplate.queryKycPbcRequest(query, req.getProductId());


        if (CollectionUtils.isNotEmpty(kycRequestResponse.getData())) {
            kycRequestResponse.getData().forEach(kycRequest -> {
                if (isSkipEnvironment(kycRequest.getProductId())) {
                    kycRequest.setIdScan(DEMO_IMAGE);
                } else {
                    try {
                        if (!StringUtils.isBlank(kycRequest.getStatus())) {
                            if (kycRequest.getStatus().equals(String.valueOf(KYCStatusEnum.DISTRIBUTED.getKycStatus()))) {
//                                kycRequest.setStatus(null);
                            } else {
                                kycRequest.setStatus(KYCStatusEnum.getKYCEnumByStatus(Integer.valueOf(kycRequest.getStatus())).getKycStatusString());
                            }
                        }
                        if (StringUtils.isNotBlank(kycRequest.getIdScan())) {
                            // 脏数据处理
                            if (JSON.isValid(kycRequest.getIdScan())) {
                                String imageKey = JSON.parseObject(kycRequest.getIdScan()).getString("imageKey");
                                //kycRequest.setIdScan(imageKey.startsWith("http")?imageKey:awss3Util.s3GetUrl(imageKey));DESUtil.encrypt(subIdScan.startsWith("http")?subIdScan:awss3Util.s3GetUrl(subIdScan),"jhs#%!fde")
                                kycRequest.setIdScanImagekey(imageKey);
                                kycRequest.setIdScan(imageKey.startsWith("http") ? imageKey : imageKey.contains("_md5") ? awss3Util.s3GetTxtUrl(imageKey) : awss3Util.s3GetUrl(imageKey));
                                //kycRequest.setIdScanV2(DESUtil.encrypt(imageKey.startsWith("http")?imageKey:awss3Util.s3GetUrl(imageKey),"jhs#%!fde"));
                                kycRequest.setIdScanV2(AESCrypt.encryptCBC(imageKey.startsWith("http") ? imageKey : imageKey.contains("_md5") ? awss3Util.s3GetTxtUrl(imageKey) : awss3Util.s3GetUrl(imageKey), "20230103aes00001", "aes0000120230103"));

                            } else {
                                // kycRequest.setIdScan(kycRequest.getIdScan().startsWith("http") ? kycRequest.getIdScan() : awss3Util.s3GetUrl(kycRequest.getIdScan()));
                                kycRequest.setIdScanImagekey(kycRequest.getIdScan());
                                kycRequest.setIdScan(kycRequest.getIdScan().startsWith("http") ? kycRequest.getIdScan() : kycRequest.getIdScan().contains("_md5") ? awss3Util.s3GetTxtUrl(kycRequest.getIdScan()) : awss3Util.s3GetUrl(kycRequest.getIdScan()));
                                //kycRequest.setIdScanV2(DESUtil.encrypt(kycRequest.getIdScan().startsWith("http") ? kycRequest.getIdScan() : awss3Util.s3GetUrl(kycRequest.getIdScan()),"jhs#%!fde"));
                                kycRequest.setIdScanV2(AESCrypt.encryptCBC(kycRequest.getIdScan().startsWith("http") ? kycRequest.getIdScan() : kycRequest.getIdScan().contains("_md5") ? awss3Util.s3GetTxtUrl(kycRequest.getIdScan()) : awss3Util.s3GetUrl(kycRequest.getIdScan()), "20230103aes00001", "aes0000120230103"));
                            }
                        }
                    } catch (Exception e) {
                        log.info("查询用户{}的证件照失败:{}", kycRequest.getLoginName(), e);
                    }
                }

                // PAY-27 增加产品和渠道

            });
        }

        try {
            PageModel<KycRequest> pageModel = new PageModel<>(count, req.getPageNo(), req.getPageSize());
            pageModel.setData(kycRequestResponse.getData());
            response.setBody(pageModel);
        } catch (Exception e) {
            log.error("CustomerServiceImpl 类里面  queryKycRequestsNew方法出异常了");
            e.printStackTrace();
        }
        return response;
    }

    private String generateRedisKeyByDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        return "C66:uploadPbcBatch:" + sdf.format(new Date());
    }

    @Override
    public Response<List<WSKycRequest>> uploadPBCInfoBatchNew(MultipartFile files, HttpServletRequest request) throws Exception {

        Response resp = new Response<>();
        //执行失败的数据添加到该list集合，然后返回到前端
        String redisCommonKey = generateRedisKeyByDate();
        if (files == null) {
            throw new ApiBusinessException(ApiResultBaseEnum.ACCOUNT_NOT_EXIST_ERROR);

        }
        MultipartFile multipartFile = files;
        if (Objects.isNull(multipartFile)) {
            throw new ApiBusinessException(ApiResultBaseEnum.ACCOUNT_NOT_EXIST_ERROR);
        }
        String fileSuffix = multipartFile.getOriginalFilename().substring(multipartFile.getOriginalFilename().lastIndexOf("."));
        if (!(".xlsx".equals(fileSuffix) || ".xls".equals(fileSuffix))) {
            throw new ApiBusinessException(ApiResultBaseEnum.ACCOUNT_NOT_EXIST_ERROR);
        }
        String operator = request.getParameter("operator");
        if (StringUtils.isBlank(operator)) {
            throw new ApiBusinessException(ApiResultBaseEnum.ACCOUNT_NOT_EXIST_ERROR);
        }
        InputStream input = null;
        Workbook book = null;
        try {
            input = multipartFile.getInputStream();
            book = new XSSFWorkbook(input);
        } catch (IOException e) {
            e.printStackTrace();
            log.error("ERROR_UPLOAD_PBC_INFO_BATCH : getInputStream Something went wrong, The specific information is:{}", e.getMessage());
        } finally {
            if (input != null) {
                input.close();
            }
        }
        Sheet sheet = book.getSheetAt(0);
        int physicalNumberOfRows = sheet.getPhysicalNumberOfRows();
        if (physicalNumberOfRows <= 1) {
            //行数据少于1行
            throw new ApiBusinessException(ApiResultBaseEnum.ACCOUNT_NOT_EXIST_ERROR);
        } else if (physicalNumberOfRows > 10001) {
            //行数据不能多于10000行
            throw new ApiBusinessException(ApiResultBaseEnum.ACCOUNT_NOT_EXIST_ERROR);
        }
        for (int j = 1; j < physicalNumberOfRows; j++) {
            Row row = sheet.getRow(j);// 获得当前行数据
            //提案编号（唯一）
            Cell billNo = row.getCell(1);
            if (billNo == null) {
                //billNo不能为空
                throw new ApiBusinessException(ApiResultBaseEnum.ACCOUNT_NOT_EXIST_ERROR);
            }
        }
        String productId = request.getParameter("productId");
        log.info("{}  productId={}", new Date(), productId);
        if (StringUtils.isBlank(productId)) {
            productId = "C66";
        }
        try {
            //将要批量审核得数据
            List<WSKycSheetRequest> kycSheetList = new ArrayList<>();
            for (int j = 1; j < physicalNumberOfRows; j++) {
                Row row = sheet.getRow(j);// 获得当前行数据
                WSKycSheetRequest kycSheet = new WSKycSheetRequest();
                kycSheet.setBillNo(row.getCell(1).getStringCellValue().replaceAll("\t", ""));  // 有换行去掉换行
                Cell pbcOperation = row.getCell(17);  // 更新 选择第17列
                PBCStatusEnum pbcStatusEnum = (pbcOperation == null ? null : PBCStatusEnum.getPbcEnumByStr(pbcOperation.getCellType() == Cell.CELL_TYPE_STRING ? pbcOperation.getStringCellValue().toLowerCase() : null));
                kycSheet.setPbcStatus(pbcOperation == null ? null : pbcStatusEnum == null ? null : String.valueOf(pbcStatusEnum.getPbcStatus()));
                // kycSheet.setProductId(productId);
                kycSheet.setLoginName(row.getCell(2) == null ? null : row.getCell(2).getStringCellValue());
                Cell idTypeCell = row.getCell(3);
                /**
                 * 此处有修改 开始
                 */
                String idType = null;
                if (idTypeCell != null) {
                    if (idTypeCell.getCellType() == Cell.CELL_TYPE_NUMERIC) { // 数字
                        idType = String.valueOf(idTypeCell.getNumericCellValue());
                    } else {
                        idType = idTypeCell.getStringCellValue();
                    }
                }
/**
 * 此处有修改 结束
 */
                kycSheet.setIdType(idType);
                kycSheet.setIdScan(row.getCell(4) == null ? null : row.getCell(4).getStringCellValue());
                //kycSheet.setBirthday(row.getCell(6)==null?null:String.valueOf(row.getCell(6).getDateCellValue()));
                kycSheet.setAddress(row.getCell(8) == null ? null : row.getCell(8).getStringCellValue());
                // kycSheet.setAssigneeTime(row.getCell(9)==null?null:String.valueOf(row.getCell(9).getDateCellValue()));
                kycSheet.setAssigneeBy(row.getCell(9) == null ? null : row.getCell(9).getStringCellValue());
                kycSheet.setAssigneeTime(row.getCell(10) == null ? null : row.getCell(10).getStringCellValue());
                kycSheet.setCreatedDate(row.getCell(11) == null ? null : row.getCell(11).getStringCellValue());
                kycSheet.setStatus(row.getCell(12) == null ? null : row.getCell(12).getStringCellValue());
                kycSheet.setProcessLog(row.getCell(14) == null ? null : row.getCell(14).getStringCellValue());
                kycSheetList.add(kycSheet);
            }
            BatchModifyPbcRequestResponse res = cronFeignTemplate.bactchModifyPbcStatus(kycSheetList, productId, operator);
            if (res == null) {
                return resp;
            } else {
                int successTotalCount = res.getCount();
                //如果成功执行得行数少于上传得行数据，则返回执行失败得数据
                if (successTotalCount < physicalNumberOfRows - 1) {
                    resp.setBody(res.getFailKycSheetList());
                } else {
                    resp.setBody(res.getCount());
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            log.error("{}   uploadPBCInfoBatch 出异常了. redisCommonKey={}, 异常信息:{}", new Date(), redisCommonKey, e.getMessage());
        }
        return resp;
    }

    @Override
    public Response queryPageByKycRequestId(QueryPageByKycRequestId req) {

        log.info("进入queryPageByKycRequestId={}", new Date());
        Response result = new Response();
        QueryKycRequestProcessLogResponse queryKycRequestProcessLogResponse = cronFeignTemplate.queryPageByKycRequestId(req);

        List<WSKycRequestProcessLog> list = queryKycRequestProcessLogResponse.getData();
        Map<String, Object> bodys = new HashMap<>();
        List<Map<String, Object>> maps = new ArrayList<>();
        bodys.put("count", queryKycRequestProcessLogResponse.getCount());

        for (WSKycRequestProcessLog log : list) {
            Map<String, Object> map = new HashMap<>();
            map.put("kycRequestId", log.getKycRequestId());
            map.put("createTime", getDateString(log.getCreateTime()));
            map.put("dispatchBy", log.getDispatchBy());
            map.put("id", log.getId());
            map.put("lastStauts", log.getLastStauts());
            map.put("remark", log.getRemark());
            map.put("type", log.getType());
            maps.add(map);

        }
        bodys.put("data", maps);


        result.setBody(new JSONObject().fluentPut("data", bodys));
        return result;
    }

    private String getDateString(Date createTime) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(createTime);
//        calendar.add(Calendar.HOUR_OF_DAY,-1);
        return DateUtil.getDateString2(calendar.getTime(), "yyyy-MM-dd HH:mm:ss");
    }


    /**
     * 获取kyc请求参数*
     *
     * @param req
     * @return WSKycRequest
     */
    private KycRequest getWSKycRequest(UpdateKycRequestReq req) {
        KycRequest wsKycRequest = new KycRequest();
        wsKycRequest.setId(req.getId());
        wsKycRequest.setProductId(req.getProductId());
        wsKycRequest.setLoginName(req.getLoginName());
        wsKycRequest.setCustomerId(req.getCustomerId());
        wsKycRequest.setUpdateBy(req.getOperator());
        wsKycRequest.setUpdateDate(DateUtil.getCurrentDate());
        wsKycRequest.setApprovedDate(DateUtil.getCurrentDate());
        wsKycRequest.setApprovedBy(req.getOperator());
        if (StringUtils.isNotBlank(req.getOpenDate())) {
            wsKycRequest.setOpenDate(req.getOpenDate());
        }
        if (StringUtils.isNotBlank(req.getStatus())) {
            wsKycRequest.setStatus(req.getStatus());
        }
        if (StringUtils.isNotBlank(req.getFirstName())) {
            wsKycRequest.setFirstName(req.getFirstName());
        } else {
            throw new ApiBusinessException(ApiResultBaseEnum.FIRST_NAME_EMPTY_ERROR);
        }
        if (StringUtils.isNotBlank(req.getMiddleName())) {
            wsKycRequest.setMiddleName(req.getMiddleName());
        }
        if (StringUtils.isNotBlank(req.getLastName())) {
            wsKycRequest.setLastName(req.getLastName());
        } else {
            throw new ApiBusinessException(ApiResultBaseEnum.LAST_NAME_EMPTY_ERROR);
        }
        if (StringUtils.isNotBlank(req.getSex())) {
            wsKycRequest.setSex(req.getSex());
        }
        log.info("px-gw-api  req.getSex()={}-------------------------------------------------------------------------", req.getSex());
        if (StringUtils.isNotBlank(req.getBirthday())) {
            try {
                LocalDate.parse(req.getBirthday());
            } catch (Exception e) {
                throw new ApiBusinessException(ApiResultBaseEnum.BIRTHDAY_INVALID_ERROR);
            }
            wsKycRequest.setBirthday(req.getBirthday());
        } else {
            throw new ApiBusinessException(ApiResultBaseEnum.BIRTHDAY_EMPTY_ERROR);
        }
        log.info("px-gw-api  req.getBirthday()={}-------------------------------------------------------------------------", req.getBirthday());
        if (StringUtils.isNotBlank(req.getRemark())) {
            wsKycRequest.setRemark(req.getRemark());
        }
        // kyc 年龄标记 start
        LocalDate birthDate = LocalDate.parse(req.getBirthday());
        // 获取当前日期，用于计算年龄
        LocalDate currentDateTemp = LocalDate.now();
        Period period = Period.between(birthDate, currentDateTemp);

        if (period.getYears() > Constants.KYC_FLAG_AGE_100 || (period.getYears() == Constants.KYC_FLAG_AGE_100 && period.getDays() > 0)) {
            wsKycRequest.setDoubtful(Constants.ONE_STR);
        } else {
            wsKycRequest.setDoubtful(null);
        }
        // kyc 年龄标记 end
        // kyc 重复标记 start 审核通过时标记是否重复
        if (StringUtils.equals(req.getStatus(), Constants.ONE_STR)) {
            // kyc重复标记
            if (checkWSKycRequestRepetition(req)) {
                wsKycRequest.setRepetation(Constants.ONE_STR);
            }
        }
        // kyc 重复标记 end
        return wsKycRequest;
    }

    /**
     * 根据姓名、生日、性别检查是否存在重复数据*
     *
     * @param req -
     * @return true：存在重复kyc信息，false：kyc不重复
     */
    private boolean checkWSKycRequestRepetition(UpdateKycRequestReq req) {
        RiskQueryKycRequest kycRequestQuery = new RiskQueryKycRequest();
        kycRequestQuery.setProductId(req.getProductId());
        kycRequestQuery.setSex(req.getSex());
        kycRequestQuery.setBirthday(req.getBirthday());
        kycRequestQuery.setFirstName(req.getFirstName());
        kycRequestQuery.setMiddleName(req.getMiddleName());
        kycRequestQuery.setLastName(req.getLastName());
        kycRequestQuery.setStatusList("1;");
//        int countKYC = FunctionHelper.doIt(switchFlag, cronFeignTemplate::countKycRequest, wsFeignTemplate::countKycRequest, kycRequestQuery, req.getProductId());
        int countKYC = cronFeignTemplate.countKycRequest(kycRequestQuery, req.getProductId());
        return countKYC > 0;
    }

    private void customerActivation(CustomerActivationReq req) {
        if (StringUtils.isEmpty(req.getCustomerName())) {
            throw new BusinessException(ApiResultBaseEnum.LOGIN_NAME_EMPTY_ERROR);
        }

        WSCustomers dbCustomer = getWSCustomerInfo(req.getProductId(), req.getCustomerName());
        if (Objects.isNull(dbCustomer)) {
            throw new BusinessException(ApiResultBaseEnum.LOGIN_NAME_NOT_EXIST_ERROR);
        }

        if (dbCustomer.getLoginName().contains(Constants.LOGIN_NAME_PREFIX) && StringUtils.isEmpty(dbCustomer.getLastGame())) {
            throw new BusinessException(ApiResultBaseEnum.COMPLETE_PLAYER_INFORMATION_ERROR);
        }
        String dbPhone = new PHPDESEncrypt(req.getProductId(), "03").decrypt(dbCustomer.getPhone());
        // 激活短信实体
        WSCustomers wsCustomersSms = new WSCustomers();
        wsCustomersSms.setProductId(req.getProductId());
        wsCustomersSms.setLoginName(dbCustomer.getLoginName());
        wsCustomersSms.setPhone(dbPhone);

        int registerFromType = dbCustomer.getRegisterFromType();
        WSCustomers wsCustomer = new WSCustomers();
        if (registerFromType == 3) {  //官网过来
            wsCustomer.setFirstIdType(req.getFirstIdType());
            wsCustomer.setFirstNoType(req.getFirstNoType());
            if (StringUtils.isNotBlank(req.getFirstIdScan())) {
                wsCustomer.setFirstIdScan(req.getFirstIdScan()); // 证件1  前端先調用接口上傳圖片, 這邊僅儲存key
            }

            wsCustomer.setSecondIdType(req.getSecondIdType());
            wsCustomer.setSecondNoType(req.getSecondNoType());
            if (StringUtils.isNotBlank(req.getSecondIdScan())) {
                wsCustomer.setSecondIdScan(req.getSecondIdScan()); // 證件2 前端先調用接口上傳圖片, 這邊僅儲存key
            }

            if (StringUtils.isNotEmpty(req.getPhone())) {
                String decryptPhoneRsp = this.decrypt(req, req.getPhone());

                if (StringUtils.isNotBlank(req.getPhone()) && !dbPhone.equals(decryptPhoneRsp)) {
                    wsCustomer.setPhone(decryptPhoneRsp);
                    wsCustomer.setPhoneMd5(DigestUtils.md5Hex(decryptPhoneRsp));
                    ModifyAccountResponse res;
                    if (UserCenterSwitch.getSwitch()) {
                        wsCustomer.setCustomerId(dbCustomer.getCustomerId());
                        res = userCenterTemplate.modifyAccount(wsCustomer, "17");
                    } else {
                        res = wsFeignTemplate.modifyAccount(wsCustomer, "17");
                    }

                    if (null != res.getWSCustomers()) {
                        wsCustomer.setPhone(null);
                        wsCustomer.setPhoneMd5(null);
                        wsCustomersSms.setPhone(decryptPhoneRsp);
                    }
                }
            }

        } else if (registerFromType == 1) {  // 既有门店导入
            wsCustomer.setNationality(req.getNationality());
            wsCustomer.setBranchCode(req.getBranchCode());
        }

        if (StringUtils.isNotBlank(req.getBirthDate())) {
            wsCustomer.setBirthDate(req.getBirthDate().trim());  // 生日
        }
        if (StringUtils.isNotBlank(req.getFirstName())) {
            wsCustomer.setFirstName(req.getFirstName().trim());
        }
        if (StringUtils.isNotBlank(req.getMiddleName())) {
            wsCustomer.setMiddleName(req.getMiddleName().trim());
        }
        if (StringUtils.isNotBlank(req.getLastName())) {
            wsCustomer.setLastName(req.getLastName().trim());
        }

        wsCustomer.setOccupation(req.getOccupation());
        wsCustomer.setSourceOfIncome(req.getSourceOfIncome());
        wsCustomer.setViber(req.getViber());
        wsCustomer.setMessager(req.getMessager());
        wsCustomer.setAddress(req.getAddress());  // 地址
        wsCustomer.setSex(req.getSex());  // 性別
        wsCustomer.setProvince(req.getProvince());
        wsCustomer.setCity(req.getCity());
        wsCustomer.setPostalCode(req.getPostalCode());
        wsCustomer.setLastUpdatedBy(req.getLoginName());
        wsCustomer.setActivation(req.getActivation());
        wsCustomer.setCurrency(req.getCurrency());
        if (Constants.ONE_STR.equalsIgnoreCase(req.getActivation())) {
            wsCustomer.setActivitionTime(DateUtil.getCurrentDate());
        }
        wsCustomer.setDomainName(req.getDomainName());
        wsCustomer.setIpAddress(req.getIpAddress());
        wsCustomer.setProductId(req.getProductId());
        wsCustomer.setLoginName(req.getCustomerName());
        wsCustomer.setPhonePrefix(req.getPhonePrefix());
        if (StringUtils.isNotBlank(req.getEmail()) && StringUtils.isBlank(dbCustomer.getEmail())) {  //邮箱
            String plainEmailNo = this.decrypt(req, req.getEmail());
            wsCustomer.setEmail(plainEmailNo);
            wsCustomer.setEmailMd5(DigestUtils.md5Hex(plainEmailNo));
        }

        // 更新faceId
        WSCustomerFace wsCustomerFace = new WSCustomerFace();
        wsCustomerFace.setLoginName(req.getCustomerName());
        wsCustomerFace.setLastUpdatedBy(req.getOperator());
        wsCustomerFace.setUpdateBranchCode(req.getBranchCode());
        wsCustomerFace.setProductId(req.getProductId());
        updateFaceIdByLocal(wsCustomerFace, req.getFaceId());

        //激活
        if (UserCenterSwitch.getSwitch()) {
            wsCustomer.setCustomerId(dbCustomer.getCustomerId());
            userCenterTemplate.modifyAccount(wsCustomer, Constants.ONE_STR);
        } else {
            wsFeignTemplate.modifyAccount(wsCustomer, Constants.ONE_STR);
        }

        //添加截图
        String screenshot = req.getScreenshot();
        if (StringUtils.isNotEmpty(screenshot)) {
            CreateCustomerRemarkReq remarkReq = new CreateCustomerRemarkReq();
            remarkReq.setScreenshot(screenshot);
            remarkReq.setRemarks(req.getScreenshotRemarks());
            remarkReq.setCustomerName(req.getCustomerName());
            remarkReq.setProductId(req.getProductId());
            remarkReq.setLoginName(req.getLoginName());
            remarkReq.setIpAddress(req.getIpAddress());
            createCustomerRemark(remarkReq);
        }

        // 发送激活短信
        //redis 拆分，调研只有发送短信有用，但是短信发送功能已注释，且脱敏对象也不一致，注释此代码
//        Map<String, Integer> hidewaymap = new HashMap<>();
//        hidewaymap.put(SENSITIVE_TYPE.PHONE_NO.getCode(), 3);
//        hidewaymap.put(SENSITIVE_TYPE.EMAIL.getCode(), 3);
//        hidewaymap.put(SENSITIVE_TYPE.MSG_VIBER.getCode(), 3);
//        try {
//            encryptUtil.getHideSensitiveCustomers(dbCustomer, hidewaymap, req.getProductId());
//        } catch (Exception e) {
//            log.error("encryptUtil.getHideSensitiveCustomers");
//        }
        //激活短信 todo 暂时注释 发送短信功能
//        sendActivateAccountSms(wsCustomersSms);
    }


    /**
     * 更新fadeId 图片
     *
     * @param wsCustomerFace
     * @param newFaceId
     */
    private void updateFaceIdByLocal(WSCustomerFace wsCustomerFace, String newFaceId) {
        try {
//            String objectResponse = faceApiTemplate.faceRecognition(awss3Util.s3GetObject(newFaceId));
            String objectResponse = awss3Util.s3GetObject(newFaceId);
            if (objectResponse != null) {
                wsCustomerFace.setLastUpdate(LocalDateTime.now().format(DATE_TIME_FORMATTER));
                wsCustomerFace.setFacePicUrl(Constants.ONE_STR);
                ModifyCustomerFaceResponse res = wsFeignTemplate.updateCustomerFace(wsCustomerFace);
                if (null != res.getWSCustomerFace()) {
                    awss3Util.s3PutObject(awss3Util.s3GetObject(newFaceId), wsCustomerFace.getLoginName());
                    awss3Util.s3PutObject(Base64.getDecoder().decode(objectResponse), wsCustomerFace.getLoginName() + "faceFeature");
                }
            } else {
                log.error("updateFaceIdByLocal未检测到人脸，loginName={}", wsCustomerFace.getLoginName());
                throw new BusinessException(ApiResultBaseEnum.FACE_IMG_NOT_EXIST_ERROR);
            }
        } catch (Exception e) {
            log.error("上传到S3服务失败，loginName={}", wsCustomerFace.getLoginName(), e);
            throw new BusinessException(ApiResultBaseEnum.UPLOAD_TO_S3_ERROR);
        }
    }

    private void createCustomerRemark(CreateCustomerRemarkReq req) {
        WSCustomers wsCustomers;
        if (UserCenterSwitch.getSwitch()) {
            wsCustomers = userCenterTemplate.getSimpleCustomerByLoginName(req.getProductId(), req.getCustomerName());
        } else {
            wsCustomers = wsFeignTemplate.getCustomerByLoginName(req.getProductId(), req.getCustomerName());
        }
        if (Objects.isNull(wsCustomers)) {
            throw new BusinessException(ApiResultBaseEnum.LOGIN_NAME_NOT_EXIST_ERROR);
        }

        if (StringUtils.equals(Constants.ZERO_STR, wsCustomers.getCustomerType())) {
            throw new BusinessException(ApiResultBaseEnum.DEPOSIT_TRANS_TRAIL_FORBID_ERROR);
        }

        //黑名单判断
        if (isBlackDisallowed(wsCustomers, Constants.OperationType.DEPOSIT)) {
            throw new BusinessException(ApiResultBaseEnum.LOGIN_NAME_BLACK_ERROR);
        }
        WSCustomersRemarks wsCustomersRemarks = new WSCustomersRemarks();
        wsCustomersRemarks.setProductId(req.getProductId());
        wsCustomersRemarks.setLoginName(req.getCustomerName());
        wsCustomersRemarks.setCustomerId(wsCustomers.getCustomerId());
        wsCustomersRemarks.setRemarks(req.getRemarks());
        wsCustomersRemarks.setOrderType(Constants.TWO_STR);
        wsCustomersRemarks.setCreatedBy(req.getLoginName());
        wsCustomersRemarks.setIpAddress(req.getIpAddress());

        // 测试环境上传静态图片, 其他环境上传备注照至OSS云存储
        if (isSkipEnvironment(req.getProductId())) {
            wsCustomersRemarks.setScreenshot(UUID.randomUUID().toString());
        } else {
            log.info("备注截图 ：{}", req.getScreenshot());
            // 前端先調用圖片上傳後返回key, 再將key傳回
            wsCustomersRemarks.setScreenshot(req.getScreenshot());
        }
        wsFeignTemplate.createCustomerRemark(wsCustomersRemarks);
    }

    private WSCustomers getWSCustomerInfo(String productId, String loginName) {
        WSQueryCustomers wsQueryCustomer = new WSQueryCustomers();
        wsQueryCustomer.setProductId(productId);
        wsQueryCustomer.setLoginName(loginName);
        wsQueryCustomer.setCustomerType(Constants.ONE_STR);
        List<WSCustomers> wsCustomers = wsFeignTemplate.queryCustomers(wsQueryCustomer);
        if (wsCustomers != null && !wsCustomers.isEmpty()) {
            return wsCustomers.get(0);
        }
        return null;
    }


    /**
     * 解析证件信息
     *
     * @param imageUrl
     * @param idType
     * @return
     */
    public OcrIdentifyRsp identifyImage(String imageUrl, String idType, CardTypeEnum cardTypeEnum) {

        OcrIdentifyRsp resp = new OcrIdentifyRsp();
        try {
            //从图像中提取文本并将结果作为字符串返回
            log.info("Ocr Identify start....");
            AnnotateImageResponse imageResponse = ocrClient.analyzeImage(imageUrl);
            if (imageResponse != null) {
                if (imageResponse.hasError()) {
                    //OCR识别失败
                    log.error("ocr file parsing failed  msg is{}", imageResponse.getError().getMessage());
                    throw new BusinessException(ApiResultBaseEnum.OCR_RECOGNITION_ERROR);
                }
                //读取到的数据
                List<EntityAnnotation> textAnnotationsList = imageResponse.getTextAnnotationsList();
                if (CollectionUtils.isNotEmpty(textAnnotationsList)) {
                    //获取到识别文本信息
                    EntityAnnotation entityAnnotation = textAnnotationsList.get(0);
                    String description = entityAnnotation.getDescription();
                    log.info("Ocr Identify description is: {}", description);
                    //根据不同的证件解析出数据
                    if (StringUtils.isEmpty(description)) {
                        //没有解析出数据
                        log.error("no text message. type:{}", idType);
                        throw new BusinessException(ApiResultBaseEnum.OCR_RECOGNITION_ERROR);
                    }
                    //查验证件类型是否正确
                    if (!description.contains(cardTypeEnum.getCardName())) {
                        log.error("wrong document type. type:{} ,typeName:{}", idType, cardTypeEnum.getCardName());
                        throw new BusinessException(ApiResultBaseEnum.OCR_RECOGNITION_ERROR);
                    }

                    // 将文本内容解析成对应的证件数据
                    CardTypeEnum enumByCode = CardTypeEnum.findEnumByCode(idType);
                    AnalyzeCardService card = ocrCardFactory.getCard(enumByCode.getServiceName());
                    List<String> textList = Arrays.asList(description.split("[\\n\\r]+"));
                    CustomerCard customerCard = card.getRecognitionData(textList, enumByCode);
                    log.info("解析出数据 imageUrl={}, customerCard={}", imageUrl, customerCard);
                    BeanUtils.copyProperties(customerCard, resp);
                    //计算年龄
                    if (customerCard.getBirthday() != null) {
                        LocalDate birthDate = customerCard.getBirthday().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                        // 获取当前日期
                        LocalDate currentDate = LocalDate.now();
                        Period period = Period.between(birthDate, currentDate);
                        resp.setAge(String.valueOf(period.getYears()));
                    }
                    return resp;
                }
            }
        } catch (IOException e) {
            log.error("ocr识别时发生错误, {}", ExceptionUtils.getStackTrace(e));
            throw new BusinessException(ApiResultBaseEnum.OCR_RECOGNITION_ERROR);
        }
        return resp;
    }


    /**
     * 判断黑名单用户是否允许做特定操作
     *
     * @param operation 操作类型
     */
    protected boolean isBlackDisallowed(WSCustomers wsCustomer, Constants.OperationType operation) {
        String blackLevels = c66Config.getBlackDepositLevels();
        if (StringUtils.isBlank(blackLevels)) {
            return false;
        }
        if (Splitter.on(",").trimResults().omitEmptyStrings().splitToList(blackLevels).contains(wsCustomer.getDepositLevel())) {
            String disallowedOps = c66Config.getBlackDisallowedOps();
            if (StringUtils.isBlank(disallowedOps)) {
                return false;
            }
            return Splitter.on(",").trimResults().splitToList(disallowedOps).contains(operation.name());
        }
        return false;
    }


    @Override
    public PageModelExt<KycRequest> kycDispatch(BaseReq req) {
//        Boolean switchFlag = wsFeignTemplate.getRiskApiWsSwitch();
        //查询等待审核的订单数
//        QueryCountResponse queryCountResponse = FunctionHelper.doIt(switchFlag, cronFeignTemplate::queryKycRequestPendingCount, wsFeignTemplate::queryKycRequestPendingCount, req);
        QueryCountResponse queryCountResponse = cronFeignTemplate.queryKycRequestPendingCount(req);
        PageModelExt<KycRequest> page = new PageModelExt<>(1, 50);
//        String orderAcceptTime = wsFeignTemplate.getProductConstantValue(req.getProductId(), "0016", "ORDER_ACCEPT_TIME");
        String orderAcceptTime = ProductConstantsUtil.obtainProductConstant(req.getProductId(), "0016", "ORDER_ACCEPT_TIME");
        Map<String, Object> statics = new HashMap<>();

//        WSProductConstants wsProductConstants = wsFeignTemplate.getProductConstants(req.getProductId(), "0016", "KYC_WITHDRAW_IS_OPEN");
        WSProductConstants wsProductConstants = ProductConstantsUtil.obtainProductConstants(req.getProductId(), "0016", "KYC_WITHDRAW_IS_OPEN");
        if (Objects.isNull(wsProductConstants)) {
            throw new BusinessException(ApiResultBaseEnum.NOT_FOUND_CONFIG_ERROR);
        }
        log.info("{} wsProductConstants 系统变量  KYC_WITHDRAW_IS_OPEN={}", new Date(), JSONObject.toJSONString(wsProductConstants));
        //pay5开关
        String isOpened = wsProductConstants.getValue();
        log.info("kycDispatch() pay5开关 isOpened={}, loginName={}", isOpened, req.getLoginName());
        if (StringUtils.isBlank(isOpened) || "0".equals(isOpened)) {
            statics.put("count", 0);
            statics.put("orderAcceptTime", "10");
            page.setStatistics(statics);
            return page;
        }
        //kyc接单权限开关
        Integer kycIsOpened = statusChangeLogService.selectCustomConfigByType(req.getLoginName(), "KYC");
        log.info("riskcontrol-api 项目 kycDispatch() kyc接单权限开关 kycIsOpened={}, loginName={}", kycIsOpened, req.getLoginName());
        if (0 == kycIsOpened) {
            statics.put("count", 0);
            statics.put("orderAcceptTime", "10");
            page.setStatistics(statics);
            return page;
        }
        statics.put("count", queryCountResponse.getCount());
        statics.put("orderAcceptTime", orderAcceptTime);
        page.setStatistics(statics);
        // 查询当前用户是否可分配订单
        if (!statusChangeLogService.checkUserCanSendOrder(req)) {
            log.debug("user:{} dispatchKyc canSend false", req.getLoginName());
            return page;
        }
        // 请求派单
//        List<WSKycRequest> wsKycRequests = FunctionHelper.doIt(switchFlag, cronFeignTemplate::dispatchKycRequest, wsFeignTemplate::dispatchKycRequest, req);
        List<KycRequest> wsKycRequests = cronFeignTemplate.dispatchKycRequest(req);
        log.info("kycDispatch wsKycRequests--{}", wsKycRequests);
        if (wsKycRequests == null || wsKycRequests.isEmpty()) {
            return page;
        }
        page.setData(wsKycRequests);
        // 通知派单成功
        statusChangeLogService.workStatusProcessConfirmation(req, 0, Constants.DISPATCH_ORDER_KYC);
        // 组装结果
        return page;
    }


    @Override
    public Boolean kycDispatchConfirm(KycDispatchConfirmReq req) {
        Boolean response = false;
        // 检查当前状态
        UserWorkingStatusChangeReq statusChangeReq = new UserWorkingStatusChangeReq();
        statusChangeReq.setLoginName(req.getLoginName());
        statusChangeReq.setProductId(req.getProductId());
        UserWorkingStatusChangeLog lastWorkingStatus = statusChangeLogService.getLastWorkingStatus(statusChangeReq);
        if (lastWorkingStatus != null && !USER_WORKING_STATUS.AVAILABLE.getName().equalsIgnoreCase(lastWorkingStatus.getAferStatus())) {
            log.error("KYC订单已被其他人接接单 ids={}", req.getIds().toString());

            return response;
        }
        //校验订单已被其他人接接单
        Boolean checkDispatch = cronFeignTemplate.checkDispatchConfirm(req);
        if (!checkDispatch) {
            //清除该用户超时没接单状态的缓存
            statusChangeLogService.removeUserStatusTime(req.getLoginName());
            log.error("KYC订单已被其他人接接单 ids={}", req.getIds().toString());

            return response;
        }
        // 确认接单修改assign 字段
        Boolean confirmResult = cronFeignTemplate.dispatchKycRequestConfirm(req);
        response = (confirmResult);
        if (confirmResult) {
            // 告知状态
            statusChangeLogService.workStatusProcessConfirmation(req, 1, Constants.DISPATCH_ORDER_KYC);
        }
        // 返回结果
        return response;
    }

    @Override
    public Response<PageModel<WSKycRequestGw>> queryKycRequestsNew(QueryKycRequestReq req) {
        Response<PageModel<WSKycRequestGw>> response = new Response<>();
        if (null == req.getPageNo()) {
            req.setPageNo(1);
        }
        if (null == req.getPageSize()) {
            req.setPageSize(20);
        }


        RiskQueryKycRequest query = new RiskQueryKycRequest();
        BeanUtils.copyProperties(req, query);
        query.setPageNum(req.getPageNo());
        query.setPageSize(req.getPageSize());
        query.setLoginName(req.getCustomerName());

        WSQueryUsers wsQueryUsers = new WSQueryUsers();
        wsQueryUsers.setLoginName(req.getLoginName());
        wsQueryUsers.setProductId(req.getProductId());

        query.setCreatedDateBegin(req.getCreatedDateBegin());
        query.setCreatedDateEnd(req.getCreatedDateEnd());
        query.setAssigneeDateBegin(req.getAssigneeDateBegin());
        query.setAssigneeDateEnd(req.getAssigneeDateEnd());
        query.setBillNo(req.getBillNo());

        if (req.getProcessType() != null) {
            if (req.getProcessType() > 3) {
                query.setPbcStatus(String.valueOf(req.getProcessType() - 4));
                query.setStatusList("1;");
            }
            if (req.getProcessType() <= 3) {
                if (req.getProcessType() == 3) {
                    query.setStatusList(StringUtils.join(req.getProcessType(), ";", 2, ";"));
                } else {
                    query.setStatusList(StringUtils.join(req.getProcessType(), ";"));
                }
            }
        }
        int count = cronFeignTemplate.countKycPbcRequest(query, req.getProductId());

        RiskQueryKycRequestResponse kycRequestResponse = cronFeignTemplate.queryKycPbcRequest(query, req.getProductId());

        List<WSKycRequestGw> wsKycRequestGws = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(kycRequestResponse.getData())) {
            kycRequestResponse.getData().forEach(kycRequest -> {


                if (isSkipEnvironment(kycRequest.getProductId())) {
                    kycRequest.setIdScan(DEMO_IMAGE);
                } else {
                    try {
                        if (StringUtils.isNotBlank(kycRequest.getIdScan())) {
                            // 脏数据处理
                            if (JSON.isValid(kycRequest.getIdScan())) {
                                String imageKey = JSON.parseObject(kycRequest.getIdScan()).getString("imageKey");
                                //kycRequest.setIdScan(imageKey.startsWith("http")?imageKey:awss3Util.s3GetUrl(imageKey));DESUtil.encrypt(subIdScan.startsWith("http")?subIdScan:awss3Util.s3GetUrl(subIdScan),"jhs#%!fde")
                                kycRequest.setIdScanImagekey(imageKey);
                                kycRequest.setIdScan(imageKey.startsWith("http") ? imageKey : imageKey.contains("_md5") ? awss3Util.s3GetTxtUrl(imageKey) : awss3Util.s3GetUrl(imageKey));
                                //kycRequest.setIdScanV2(DESUtil.encrypt(imageKey.startsWith("http")?imageKey:awss3Util.s3GetUrl(imageKey),"jhs#%!fde"));
                                kycRequest.setIdScanV2(AESCrypt.encryptCBC(imageKey.startsWith("http") ? imageKey : imageKey.contains("_md5") ? awss3Util.s3GetTxtUrl(imageKey) : awss3Util.s3GetUrl(imageKey), "20230103aes00001", "aes0000120230103"));

                            } else {
                                // kycRequest.setIdScan(kycRequest.getIdScan().startsWith("http") ? kycRequest.getIdScan() : awss3Util.s3GetUrl(kycRequest.getIdScan()));
                                kycRequest.setIdScanImagekey(kycRequest.getIdScan());
                                kycRequest.setIdScan(kycRequest.getIdScan().startsWith("http") ? kycRequest.getIdScan() : kycRequest.getIdScan().contains("_md5") ? awss3Util.s3GetTxtUrl(kycRequest.getIdScan()) : awss3Util.s3GetUrl(kycRequest.getIdScan()));
                                //kycRequest.setIdScanV2(DESUtil.encrypt(kycRequest.getIdScan().startsWith("http") ? kycRequest.getIdScan() : awss3Util.s3GetUrl(kycRequest.getIdScan()),"jhs#%!fde"));
                                kycRequest.setIdScanV2(AESCrypt.encryptCBC(kycRequest.getIdScan().startsWith("http") ? kycRequest.getIdScan() : kycRequest.getIdScan().contains("_md5") ? awss3Util.s3GetTxtUrl(kycRequest.getIdScan()) : awss3Util.s3GetUrl(kycRequest.getIdScan()), "20230103aes00001", "aes0000120230103"));
                            }
                        }
                        if (StringUtils.isNotBlank(kycRequest.getImgUrl())) {
                            String imageKey = kycRequest.getImgUrl();
                            kycRequest.setImgUrl(imageKey.startsWith("http") ? imageKey : imageKey.contains("_md5") ? awss3Util.s3GetTxtUrl(imageKey) : awss3Util.s3GetUrl(imageKey));
                        }
                    } catch (Exception e) {
                        log.info("查询用户{}的证件照失败:{}", kycRequest.getLoginName(), e);
                    }
                }

                // PAY-27 增加产品和渠道
                if (StringUtils.isNotBlank(kycRequest.getChannel())) {
                    ChannelEnum channelEnum = ChannelEnum.getNameByType(kycRequest.getChannel());
                    log.info("CustomerServiceImpl 类里面  查询产品渠道为空,原始渠道为={}", kycRequest.getChannel());
                    if (channelEnum != null) {
                        kycRequest.setChannel(channelEnum.getName());
                    }
                }
                WSKycRequestGw wsKycRequestGw = new WSKycRequestGw();
                BeanUtils.copyProperties(kycRequest, wsKycRequestGw);
                if (StringUtils.equals("1", gpData)) {
                    WSCustomers wsCustomers = userCenterTemplate.getSimpleCustomerByLoginName(req.getProductId(), req.getLoginName());
                    wsKycRequestGw.setProvince(wsCustomers.getProvince());
                    wsKycRequestGw.setReserve2(wsCustomers.getReserve2());
                    wsKycRequestGw.setReserve4(wsCustomers.getReserve4());
                }
                wsKycRequestGws.add(wsKycRequestGw);
            });
        }

        try {
            PageModel<WSKycRequestGw> pageModel = new PageModel<>(count, req.getPageNo(), req.getPageSize());
            pageModel.setData(wsKycRequestGws);
            response.setBody(pageModel);
        } catch (Exception e) {
            log.error("CustomerServiceImpl 类里面  queryKycRequestsNew方法出异常了");
            e.printStackTrace();
        }
        return response;
    }

    @Override
    public Response<RiskQueryKycRequestResponse> queryKycRequest(RiskQueryKycRequestRequest req) {
        Response response = new Response();
        response.setBody(cronFeignTemplate.queryKycRequest(req));
        return response;
    }

    @Override
    public Response<Integer> queryKycRequestFlag(RiskQueryKycRequest req) {
        Response response = new Response();
        String key = String.format(Constant.RISK_KYC_FLAG_KEY, req.getCustomerId());
        Object obj = redisUtil.get(key);
        Integer status = -1;
        if (Objects.isNull(obj)) {
            List<Integer> statusList = cronFeignTemplate.queryKycStatusByCustomerId(req);
            if (CollectionUtils.isNotEmpty(statusList)) {
                if (statusList.contains(1)) {
                    status = 1;
                } else if (statusList.contains(0)) {
                    status = 0;
                } else {
                    status = -1;
                }
            } else {
                WSCustomers dbCustomer;
                if (UserCenterSwitch.getSwitch()) {
                    dbCustomer = userCenterTemplate.getSimpleCustomerByLoginName(req.getProductId(), req.getLoginName());
                } else {
                    dbCustomer = wsFeignTemplate.getCustomerByLoginName(req.getProductId(), req.getLoginName());
                }
                if (dbCustomer != null) {
                    /**
                     * 判断是否老用户，是的默认通过kyc
                     */
                    if (StringUtils.isNoneBlank(dbCustomer.getFirstIdType(), dbCustomer.getFirstNoType())) {
                        status = 1;
                    }
                }
            }
        } else {
            status = (int) obj;
        }
        if (status == 1) {
            redisUtil.set(key, status, 3, TimeUnit.DAYS);
        }
        response.setBody(status);
        return response;
    }

    @Override
    public JSONObject modifyCustomConfiguration(JSONObject request) {
        return cronFeignTemplate.modifyCustomConfiguration(request);
    }

    @Override
    public List<WSCustomers> loadCustomers(ApiQueryCustomersRequest req) {
        return Optional.ofNullable(UserCenterSwitch.getSwitch()).filter(Boolean::booleanValue).map(e -> {
            log.info("[loadCustomers] begin to call userCenterTemplate to load customers.");
            List<WSCustomers> result = new ArrayList<>();
            result.add(userCenterTemplate.queryCustomersBySingle(req));
            return result;
        }).orElseGet(() -> {
            log.info("[loadCustomers] begin to call wsFeignTemplate to load customers.");
            return wsFeignTemplate.queryCustomersBySingle(req);
        });
    }

    @Override
    public Response<ModifyKycRequestResponse> autoApproveKycAndPbc(RiskUpdateKycRequestRequest req) {
        return cronFeignTemplate.autoApproveKycAndPbc(req);
    }

    @Override
    public Response<CreateKycRequestResponse> addKycRequest(RiskCreateKycRequestRequest req) {
        //校验证件id开关是否启用
        validKycIdNoExists(req.getWsKycRequest().getTenant(), req.getWsKycRequest().getIdType(), req.getWsKycRequest().getIdNo());
        Response<CreateKycRequestResponse> response = new Response<>();
        CreateKycRequestResponse createKycRequestResponse = cronFeignTemplate.addKycRequestCron(req);
        response.setBody(createKycRequestResponse);
        return response;
    }

    @Override
    public Response<ModifyKycRequestResponse> updateKycRequest(RiskUpdateKycRequestRequest req) {
        validKycIdNoExists(req.getWsKycRequest().getTenant(), req.getWsKycRequest().getIdType(), req.getWsKycRequest().getIdNo());
        Response<ModifyKycRequestResponse> response = new Response<>();
        response.setBody(cronFeignTemplate.updateKycRequest(req));
        return response;
    }

    private void validKycIdNoExists(String tenant, String idType, String idNo) {
        if (!StringUtils.isBlank(tenant)) {
            String[] enableStr = kycIdValidEnable.split(Constants.COMMA_SYMBOL);
            if (Arrays.asList(enableStr).contains(tenant)) {
                if (StringUtils.isEmpty(idNo)){
                    throw new BusinessException("idNO empty Error","400206");
                }
                Boolean exists = cronFeignTemplate.validKycIdAndType(Integer.valueOf(idType), idNo);
                if (exists) {
                    throw new BusinessException(ResultEnum.ERROR_VALID_KYC_ID);
                }
            }
        }
    }

    @Override
    public Response<ModifyKycRequestResponse> pbcModifyStatus(RiskUpdateKycRequestRequest req) {
        Response<ModifyKycRequestResponse> response = new Response<>();
        response.setBody(cronFeignTemplate.pbcModifyStatus(req));
        return response;
    }

    @Override
    public Response<QueryCountResponse> queryWaitPendingCount(KycRequest req) {
        Response<QueryCountResponse> response = new Response<>();
        response.setBody(cronFeignTemplate.queryKycRequestPendingCount(req));
        return response;
    }


    public static boolean isNumber(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }

    }

    @Override
    public boolean validKycIdAndType(ValidKycIdReq req) {
        return cronFeignTemplate.validKycIdAndType(req.getIdType(), req.getIdNo());
    }

    @Override
    public Response<KycRequest> queryKycByLoginNameOrderOne(RiskQueryKycRequest query) {

        return Response.body(cronFeignTemplate.queryKycByLoginNameOrderOne(query));
    }

    @Override
    public Response<ModifyKycRequestResponse> updateKycExt(KycExtUpdateReq req) {
        Response<ModifyKycRequestResponse> response = new Response<>();
        RiskUpdateKycRequestRequest updateKyc = new RiskUpdateKycRequestRequest();
        KycRequest kycRequest = new KycRequest();
        BeanUtils.copyProperties(req,kycRequest);
        kycRequest.setStatus(Strings.EMPTY);//为空字符串，不更新状态
        kycRequest.setRemark("update additional By "+req.getApprovedBy());
        kycRequest.setType("update additional information");
        updateKyc.setWsKycRequest(kycRequest);
        response.setBody(cronFeignTemplate.updateKycRequest(updateKyc));
        return response;
    }
}