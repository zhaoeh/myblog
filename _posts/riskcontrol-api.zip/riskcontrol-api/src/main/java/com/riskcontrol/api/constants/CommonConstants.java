package com.riskcontrol.api.constants;

import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 基础的常量类
 */
public class CommonConstants {


    //系统支持的 游戏厅
    public static final String[] SupportPlateFormIds = new String[]{"003", "073", "097","098", "094","099", "100", "103", "104", "105", "106", "107", "108", "109","116","079","179"};
    //用户类型
    public static final String USER_TYPE_ACCOUNT = "0";//系统管理员。
    public static final String USER_TYPE_CUSTOMER = "1";//玩家
    public static final String USER_TYPE_MARK = "userType";//用户类型标识
    public static final String USER_TYPE_STORE_WEBSITE = "USER_TYPE_STORE_WEBSITE" ;//门店内容系统权限

    //token状态
    public static final int TOKEN_STATUS_INVALID = 0;//会话失效
    public static final int TOKEN_STATUS_ACTIVE= 1;//在线
    public static final int TOKEN_STATUS_KNOCKED_OUT = 2;//同一个账号在线，被剔除
    public static final int TOKEN_STATUS_SUSPEND = 3;//用户角色被禁用
    public static final int TOKEN_STATUS_MODIFY = 4;//账户被修改
    public static final int TOKEN_STATUS_ACCOUNT_SUSPEND = 5;//账户被禁用

    //优惠类别
    public static final String ONE_PROMOTION_CATEGORY = "one";//
    public static final String WEEK_PROMOTION_CATEGORY = "week";//

    //有效数字
    public static final String YES_NUM = "0";//有效
    public static final String NO_NUM = "1";//无效

    //图片格式
    public static String JPG = "FFD8FF";
    public static String PNG = "89504E47";

    /**
     * 系统用户 system
     */
    public static final String USER_SYSTEM = "system";
    public static final String USER_TYPE = "U";
    public static final String CUSTOMER_TYPE = "C";
    public static final String SERVER_TYPE = "SE";

    public static final String INTER_GATEWAY = "inter_gateway";//网关标识
    //1. 查询用户拥有最大投注额的厅（不区分游戏种类）
    public static final String TOTAL_BET_AMOUNT_TYPE = "1";
    //2. 查询用户投注额及有效投注额
    public static final String MAX_BET_AMOUNT_TYPE = "2";
    //3. 查询用户拥有最大投注额的厅（区分游戏种类）
    public static final String GAME_BET_AMOUNT_TYPE = "3";
    public static final String POSITIVE_BET_AMOUNT_TYPE = "0";
    //4.添加resultType为4，按照用户名，游戏大类分组，将捕鱼gamekind8和gamekind5的统一返回
    public static final String GAME_KIND_BET_AMOUNT_TYPE = "4";
    public static final Integer REBATE_PAGE_SIZE = 300;
    public static final String SEPARATOR = ",";
    public static final String ZERO = "0";
    public static final String ONE = "1";
    public static final String TWO = "2";


    public static final String ONLINE_FIRST_DEPOSIT = "XSSCYH";
    public static final String TEAM_FIGHTING_TIGER = "TDDH";
    public static final String ACT_BONUS_AMOUNT = "1000";
    public static final String SQL_DEPOSIT_ORDER = "d.created_date desc";

    //拥有查看所有kyc权限的角色列表。统一小写
    public static final String[] ALL_KYC_ROLES = {"admin","f.manager","o.specialist","o.operation","o.leader", "O.Operator"};

    /**
     * 三方系统响应code字段名称
     */
    public static final String CODE = "code";

    /**
     * 三方系统响应message字段名称
     */
    public static final String MESSAGE = "message";

    /**
     * 三方系统响应业务userInfo字段名称
     */
    public static final String USERINFO = "userInfo";

    public static final String format(Date date) {
        if (date == null) {
            return null;
        }
        return new SimpleDateFormat("yyyy-MM-dd").format(date);
    }


    public static final String formatFormat(Date date,String pattern) {
        if(StringUtils.isEmpty(pattern))
            pattern = "yyyy-MM-dd HH:mm:ss";
        return new SimpleDateFormat(pattern).format(date);
    }


    public static Date parseDateString(String date,String format) {
        try {
            if(StringUtils.isEmpty(format)){
                return new SimpleDateFormat("yyyy-MM-dd").parse(date);
            }else{
                return new SimpleDateFormat(format).parse(date);
            }
        } catch (Exception e) {
            return null;
        }
    }


    /**
     * endTime比startTime多的天数
     * @param startTime
     * @param endTime
     * @return
     */
    public static int differentDays(Date startTime, Date endTime){
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(startTime);

        Calendar cal2 = Calendar.getInstance();
        cal2.setTime(endTime);
        int day1= cal1.get(Calendar.DAY_OF_YEAR);
        int day2 = cal2.get(Calendar.DAY_OF_YEAR);

        int year1 = cal1.get(Calendar.YEAR);
        int year2 = cal2.get(Calendar.YEAR);
        if(year1 != year2)   //同一年
        {
            int timeDistance = 0 ;
            for(int i = year1 ; i < year2 ; i ++)
            {
                if(i%4==0 && i%100!=0 || i%400==0)    //闰年
                {
                    timeDistance += 366;
                }
                else    //不是闰年
                {
                    timeDistance += 365;
                }
            }

            return timeDistance + (day2-day1) ;
        }
        else    //不同年
        {

            return day2-day1;
        }
    }

}

