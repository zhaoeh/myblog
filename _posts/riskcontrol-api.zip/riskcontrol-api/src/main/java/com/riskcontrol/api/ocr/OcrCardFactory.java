package com.riskcontrol.api.ocr;

import com.riskcontrol.api.service.AnalyzeCardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @Auther: yannis
 * @Date: 2023/3/31 16:45
 * @Description: ocr识别证件工厂
 */
@Component
public class OcrCardFactory {
    @Autowired
    private final Map<String, AnalyzeCardService> cardMap = new ConcurrentHashMap<>();

    public AnalyzeCardService getCard(String cardName) {
        return cardMap.get(cardName);
    }
}
