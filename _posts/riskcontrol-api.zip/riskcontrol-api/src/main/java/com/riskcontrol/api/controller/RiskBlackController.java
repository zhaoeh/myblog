package com.riskcontrol.api.controller;

import com.riskcontrol.api.service.RiskBlackService;
import com.riskcontrol.common.entity.response.Response;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.constraints.NotEmpty;

/**
 * @author Heng.zhang
 */
@RestController
@Api("风控黑名单")
@RequestMapping("/riskBlack")
@Slf4j
public class RiskBlackController {

    @Resource
    private RiskBlackService riskBlackService;

    @GetMapping(value = "/getBlackStatus/{loginName}")
    @ResponseBody
    @ApiOperation(value = "查询用户是否在黑名单中 true：是黑名单")
    public Response<Boolean> getBlackStatus(@PathVariable @Validated @NotEmpty String loginName) {
        return Response.body(riskBlackService.getBlackStatus(loginName));
    }

}
