package com.riskcontrol.api.constants;

import org.springframework.stereotype.Component;

@Component
public class Product {
    /**
     * 產品編號
     */
    public enum Ids {
        C66
    }


    /**
     * 取得C68產品編號
     * @return
     */
    // todo laurent 保留该方法，但是返回C66的Id，方便后续找调用该方法做特殊处理的代码
    public static String getPidC68() {
        return Ids.C66.name();
    }
}
