package com.riskcontrol.api.entity.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @Description: kyc更新扩展信息对象
 */
@Data
public class KycExtUpdateReq implements Serializable {
    @NotBlank(message = "id can't blank")
    private String id;
    @ApiModelProperty("Permanent Address")
    private String address;
    @ApiModelProperty("Place Of Birth")
    private String birthPlace;
    @ApiModelProperty("现住地址")
    private String presentAddress;
    @ApiModelProperty("国籍")
    private String nationality;
    @ApiModelProperty("收入来源")
    private String sourceOfIncome;
    @ApiModelProperty("工作性质")
    private String natureOfWork;
    @ApiModelProperty("employerName")
    private String employerName;
    @ApiModelProperty("操作人: BP_IOS")
    @NotBlank(message = "approvedBy can't blank")
    private String approvedBy;
}
