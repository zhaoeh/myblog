package com.riskcontrol.api.service.impl;

import com.riskcontrol.api.entity.request.RiskLabelHighDowngradeRequest;
import com.riskcontrol.api.service.RiskLabelService;
import com.riskcontrol.api.template.CronFeignTemplate;
import com.riskcontrol.common.entity.request.label.RiskLabelBindingRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelByCustomerIdRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelListRequest;
import com.riskcontrol.common.entity.request.label.RiskLabelRemoveBindingRequest;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelDetailRsp;
import com.riskcontrol.common.entity.response.label.CustomerRiskLabelRsp;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @program: riskcontrol-api
 * @description:
 * @author: Colson
 * @create: 2024-01-16 10:04
 */
@Slf4j
@Service
public class RiskLabelServiceImpl implements RiskLabelService {

    @Resource
    private CronFeignTemplate cronFeignTemplate;

    @Override
    public List<CustomerRiskLabelRsp> listCustomerRiskLabel(RiskLabelListRequest request) {
        return cronFeignTemplate.listCustomerRiskLabel(request);
    }

    @Override
    public Boolean bindingCustomerRiskLabel(RiskLabelBindingRequest request) {
        return cronFeignTemplate.bindingCustomerRiskLabel(request);
    }

    @Override
    public CustomerRiskLabelRsp getRiskLabelDetail(RiskLabelByCustomerIdRequest request) {
        return cronFeignTemplate.getRiskLabelDetail(request);
    }

    @Override
    public Boolean removeLabel(RiskLabelHighDowngradeRequest request) {
        RiskLabelByCustomerIdRequest query = new RiskLabelByCustomerIdRequest();
        query.setCustomerId(request.getCustomerId());
        CustomerRiskLabelRsp riskLabelDetail = cronFeignTemplate.getRiskLabelDetail(query);
        if(null != riskLabelDetail && CollectionUtils.isNotEmpty(riskLabelDetail.getRiskLabels())){
            List<CustomerRiskLabelDetailRsp> riskLabels = riskLabelDetail.getRiskLabels();
            for(CustomerRiskLabelDetailRsp riskLabel : riskLabels){
                if(riskLabel.getRiskLabelKey().equals("RISK_ACCOUNT_HIGH") || riskLabel.getRiskLabelKey().equals("RISK_ACCOUNT_MEDIUM")){
                    RiskLabelRemoveBindingRequest deleteReq = new RiskLabelRemoveBindingRequest();
                    BeanUtils.copyProperties(request,deleteReq);
                    deleteReq.setLabelKey(riskLabel.getRiskLabelKey());
                    cronFeignTemplate.removeLabel(deleteReq);
                }
            }
        }
        return true;
    }
}
