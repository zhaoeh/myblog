package com.riskcontrol.api.utils;

import com.riskcontrol.common.entity.request.BaseReq;

import java.util.HashMap;
import java.util.Map;

/**
 * 请求上下文，避免所有请求中都通过参数传递BaseReq或者相关对象
 * <pre>
 *     set只在框架代码中做
 *     get业务代码随意
 * </pre>
 */
public class ReqHolder {

    private static final ThreadLocal<BaseReq> baseReqTL = new ThreadLocal<>();
    private static final ThreadLocal<Map<String,String>> basicInfo = new ThreadLocal<>();
    private static final String POST_BODY = "postBody";
    private static final String LOGGER_SWITCH = "loggerSwitch";

    public static BaseReq getBaseReq() {
        return baseReqTL.get();
    }

    public static void setBaseReq(BaseReq baseReq) {
        baseReqTL.set(baseReq);
    }

    public static void setPostBody(String postBody){
        Map<String, String> basicInfo = getBasicInfo();
        basicInfo.put(POST_BODY, postBody);
    }

    public static String getPostBody(){
        Map<String, String> basicInfo = getBasicInfo();
        return basicInfo.get(POST_BODY);
    }

    public static void setLoggerSwitch(String loggerSwitch){
        Map<String, String> basicInfo = getBasicInfo();
        basicInfo.put(LOGGER_SWITCH, loggerSwitch);
    }

    public static String getLoggerSwitch(){
        Map<String, String> basicInfo = getBasicInfo();
        return basicInfo.get(LOGGER_SWITCH);
    }

    private static Map<String, String> getBasicInfo() {
        Map<String, String> map = basicInfo.get();
        if(null == map){
            basicInfo.set(new HashMap<String,String>());
        }
        return basicInfo.get();
    }

    public static void clear() {
        baseReqTL.remove();
    }
    public static void clearBasicInfo() {
        basicInfo.remove();
    }
}
