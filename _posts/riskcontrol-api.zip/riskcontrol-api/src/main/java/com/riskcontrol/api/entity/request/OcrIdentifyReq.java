package com.riskcontrol.api.entity.request;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.annotations.ApiModelProperty;

/**
 * @Auther: yannis
 * @Date: 2023/3/31 14:20
 * @Description: ocr识别入参
 */

public class OcrIdentifyReq extends BaseReq {
    @ApiModelProperty("证件照id")
    private  String idScan;

    @ApiModelProperty("用户id")
    private String customerId;

    @ApiModelProperty("证件类型")
    private String idType;

    public String getIdScan() {
        return idScan;
    }

    public void setIdScan(String idScan) {
        this.idScan = idScan;
    }

    @Override
    public String getCustomerId() {
        return customerId;
    }

    @Override
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }
}
