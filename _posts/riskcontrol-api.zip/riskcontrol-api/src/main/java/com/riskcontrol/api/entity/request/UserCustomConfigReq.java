package com.riskcontrol.api.entity.request;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author ：zeus
 * @description：TODO
 * @date ：2023/03/27 16:16
 */
@Data
@ApiModel
public class UserCustomConfigReq extends BaseReq {

    @ApiModelProperty(value = "kyc开关")
    private Integer kycOption;
    @ApiModelProperty(value = "withdraw开关")
    private Integer withdrawOption;

}
