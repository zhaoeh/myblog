package com.riskcontrol.api.service;

import com.riskcontrol.common.entity.request.BaseReq;

public interface IDispatchService {

    /**
     * 派单无响应时调用此接口
     *
     * @param orderStyle
     * @param request
     * @return
     */
    boolean dispatchNoResponse(String orderStyle, BaseReq request);

    /**
     * 是否还有分配未审核的订单
     *
     * @param request
     * @return
     */
    boolean hasPendingRequest(BaseReq request);

}
