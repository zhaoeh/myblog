package com.riskcontrol.api.service.impl;

import com.google.common.io.ByteStreams;
import com.riskcontrol.api.config.OssProperties;
import com.riskcontrol.api.service.OssService;
import com.riskcontrol.api.utils.LocalCacheUtils;
import com.riskcontrol.common.config.C66Config;
import lombok.extern.slf4j.Slf4j;
import net.coobird.thumbnailator.Thumbnails;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.bouncycastle.util.encoders.Base64;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.ObjectCannedACL;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.GetObjectPresignRequest;
import software.amazon.awssdk.services.s3.presigner.model.PresignedGetObjectRequest;

import javax.annotation.Resource;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.time.Duration;
import java.util.Objects;


/**
 * 亚马逊s3
 */
//@Service
@Slf4j
public class AwsServiceImpl implements OssService {

    /**
     * minioClient
     */
    private OssProperties ossProperties;

    private GenericObjectPool<S3Client> s3ClientObjectPool;

    @Resource
    private C66Config c66Config;


    public AwsServiceImpl(OssProperties ossProperties) {
        this.ossProperties = ossProperties;


        // 环境中没有配置亚马逊云存储参数时，跳过初始化
        // logger.info("AWSS3Util 配置初始化,aws.s3.bucketName:{},aws.s3.region:{},aws.s3.accessKeyId:{},aws.s3.secretAccessKey:{}.",ossProperties.getBucketName(),ossProperties.getRegion(),ossProperties.getAccessKeyId(),ossProperties.getSecretAccessKey());

        GenericObjectPoolConfig poolConfig = new GenericObjectPoolConfig();
        poolConfig.setMaxIdle(50);
        poolConfig.setMaxTotal(50);
        poolConfig.setMinIdle(50);

        AwsBasicCredentials credentials = AwsBasicCredentials.create(ossProperties.getAccessKeyId(), ossProperties.getSecretAccessKey());
        S3Client s3 = S3Client.builder().credentialsProvider(StaticCredentialsProvider.create(credentials)).region(Region.of(ossProperties.getRegion())).build();

//        s3ClientObjectPool = new GenericObjectPool<S3Client>(new S3ClientFactory(ossProperties.getAccessKeyId(), ossProperties.getSecretAccessKey(), ossProperties.getRegion()), poolConfig);
        s3ClientObjectPool = new GenericObjectPool<S3Client>(new S3ClientFactory(ossProperties.getAccessKeyId(), ossProperties.getSecretAccessKey(), ossProperties.getRegion()), poolConfig);
    }

    class S3ClientFactory extends BasePooledObjectFactory<S3Client> {

        private String regionStr;

        private String accessKeyId;

        private String secretAccessKey;


        public S3ClientFactory(String accessKeyId, String secretAccessKey, String regionStr) {
            this.accessKeyId = accessKeyId;
            this.secretAccessKey = secretAccessKey;
            this.regionStr = regionStr;
        }


        @Override
        public S3Client create() throws Exception {
            AwsBasicCredentials credentials = AwsBasicCredentials.create(accessKeyId, secretAccessKey);
            S3Client s3 = S3Client.builder().credentialsProvider(StaticCredentialsProvider.create(credentials)).region(Region.of(regionStr)).build();
            return s3;
        }

        @Override
        public PooledObject<S3Client> wrap(S3Client s3Client) {
            return new DefaultPooledObject<>(s3Client);
        }


    }


    @Override
    public String uploadFile(String bucketName, InputStream stream, String contentType, String fileName) throws Exception {
        // 上传文件路径
        S3Client s3Client = null;
        try {
            // 上传文件
            s3Client = s3ClientObjectPool.borrowObject();
            if (Objects.isNull(s3Client)) {
                log.error("s3Client is null:{}", s3Client);
                return "";
            }
            s3Client.putObject(PutObjectRequest.builder().bucket(bucketName).acl(ObjectCannedACL.PUBLIC_READ).contentType(contentType).key(fileName).build(),
                    RequestBody.fromInputStream(stream, stream.available()));
            return fileName;
        } catch (Exception e) {
            log.error("{}文件上传失败", fileName, e);
            return "";
        } finally {
            if (s3Client != null) {
                s3ClientObjectPool.returnObject(s3Client);
            }
        }
    }

    @Override
    public InputStream getFile(String bucketName, String objectName) {
        S3Client s3Client = null;
        try {
            // 获取文件
            s3Client = s3ClientObjectPool.borrowObject();
            GetObjectRequest getObjectRequest = GetObjectRequest.builder().bucket(bucketName).key(objectName).build();
            return s3Client.getObject(getObjectRequest);
        } catch (Exception e) {
            log.error("{}文件获取失败", objectName, e);
            return null;
        } finally {
            if (s3Client != null) {
                s3ClientObjectPool.returnObject(s3Client);
            }
        }
    }

    @Override
    public String getFileBase64(String bucketName, String key) {
        S3Client s3Client = null;
        try {
            s3Client = s3ClientObjectPool.borrowObject();
            GetObjectRequest req = GetObjectRequest.builder().bucket(bucketName).key(key).build();
            ResponseInputStream<GetObjectResponse> object = s3Client.getObject(req);
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            Thumbnails.of(object).scale(1f).toOutputStream(outputStream);

            return java.util.Base64.getEncoder().encodeToString(outputStream.toByteArray());
        } catch (Exception e) {
            log.error("S3读取失败", e);
            return "";
        } finally {
            if (s3Client != null) {
                s3ClientObjectPool.returnObject(s3Client);
            }
        }
    }


    @Override
    public void putObject(String bucketName, String base64Img, String key) {
        S3Client s3Client = null;
        try {
//            Instant start = Instant.now();
            s3Client = s3ClientObjectPool.borrowObject();

            File f = new File(key + ".jpg");

            Thumbnails.of(new ByteArrayInputStream(Base64.decode(base64Process(base64Img)))).scale(1f).toFile(f);

            //Put a file into the bucket
            s3Client.putObject(PutObjectRequest.builder().bucket(bucketName).key(key).build(),
                    RequestBody.fromFile(f)
            );
        } catch (Exception e) {
            log.error("S3上传失败", e);
        } finally {
            if (s3Client != null) {
                s3ClientObjectPool.returnObject(s3Client);
            }
        }
    }

    // 注意: 敏感数据请勿使用public
    @Override
    public String putObject(String bucketName, File base64Img, String key, boolean isPublic) {
        S3Client s3Client = null;
        try {

            s3Client = s3ClientObjectPool.borrowObject();
            //Put a file into the bucket
            PutObjectRequest.Builder requestBuilder = PutObjectRequest.builder().bucket(bucketName).key(key);
            if (isPublic) {
                requestBuilder.acl(ObjectCannedACL.PUBLIC_READ);
            }
            s3Client.putObject(requestBuilder.build(),
                    RequestBody.fromFile(base64Img)
            );

            return key;
        } catch (Exception e) {
            e.printStackTrace();
            log.error("S3上传失败 {}，{}", key, e);
            return "";
        } finally {
            if (s3Client != null) {
                s3ClientObjectPool.returnObject(s3Client);
            }
        }
    }

    @Override
    public void putObject(String bucketName, byte[] base64Img, String key) {
        S3Client s3Client = null;
        try {
            s3Client = s3ClientObjectPool.borrowObject();
            //Put a file into the bucket
            s3Client.putObject(PutObjectRequest.builder().bucket(bucketName).key(key).build(),
                    RequestBody.fromBytes(base64Img)
            );
        } catch (Exception e) {
            log.error("S3上传失败", e);
        } finally {
            if (s3Client != null) {
                s3ClientObjectPool.returnObject(s3Client);
            }
        }
    }

    @Override
    public byte[] getFileByte(String bucketName, String key) {
        S3Client s3Client = null;
        try {
            s3Client = s3ClientObjectPool.borrowObject();
            GetObjectRequest req = GetObjectRequest.builder().bucket(bucketName).key(key).build();
            ResponseInputStream<GetObjectResponse> object = s3Client.getObject(req);

            return ByteStreams.toByteArray(object);
        } catch (Exception e) {
            log.error("S3读取失败", e);
            return null;
        } finally {
            if (s3Client != null) {
                s3ClientObjectPool.returnObject(s3Client);
            }
        }
    }

    @Override
    public String getFileUrl(String bucketName, String key) {
        if (StringUtils.isBlank(key))
            return "";
        String fileUrl = LocalCacheUtils.getFileUrl(bucketName + "_" + key);
        if (StringUtils.isBlank(fileUrl)) {
            GetObjectRequest getObjectRequest = GetObjectRequest.builder().bucket(bucketName).key(key).build();
            GetObjectPresignRequest getObjectPresignRequest = GetObjectPresignRequest.builder().signatureDuration(Duration.ofDays(1)).getObjectRequest(getObjectRequest).build();
            AwsBasicCredentials credentials = AwsBasicCredentials.create(ossProperties.getAccessKeyId(), ossProperties.getSecretAccessKey());
            S3Presigner presigner = S3Presigner.builder().credentialsProvider(StaticCredentialsProvider.create(credentials)).region(Region.of(ossProperties.getRegion())).build();

            // Generate the presigned request
            PresignedGetObjectRequest presignedGetObjectRequest = presigner.presignGetObject(getObjectPresignRequest);
            fileUrl = presignedGetObjectRequest.url() + "";
            LocalCacheUtils.putFileUrl(bucketName + "_" + key, fileUrl);
        }
        return fileUrl;
    }

    @Override
    public String getFileTxtUrl(String bucketName, String key) {
        if (StringUtils.isBlank(key)) {
            return "";
        }
        String fileUrl= LocalCacheUtils.getFileUrl(bucketName + "_" + key);
        if (StringUtils.isBlank(fileUrl)) {
            GetObjectRequest getObjectRequest = GetObjectRequest.builder().bucket(bucketName).key(key).build();
            GetObjectPresignRequest getObjectPresignRequest = GetObjectPresignRequest.builder().signatureDuration(Duration.ofDays(1)).getObjectRequest(getObjectRequest).build();
            AwsBasicCredentials credentials = AwsBasicCredentials.create(ossProperties.getAccessKeyId(), ossProperties.getSecretAccessKey());
            S3Presigner presigner = S3Presigner.builder().credentialsProvider(StaticCredentialsProvider.create(credentials)).region(Region.of(ossProperties.getRegion())).build();

            // Generate the presigned request
            PresignedGetObjectRequest presignedGetObjectRequest = presigner.presignGetObject(getObjectPresignRequest);
            fileUrl = presignedGetObjectRequest.url() + "";
            LocalCacheUtils.putFileUrl(bucketName + "_" + key,fileUrl);
        }
        return fileUrl;
    }

    @Override
    public String getFileUrl(String bucketName, String key, String suffix) {
        return getFileUrl(bucketName, key);
    }

    @Override
    public String putObject(String bucketName, File base64Img, String key, String suffix, boolean isPublic) {
        return this.putObject(bucketName, base64Img, key, isPublic);
    }


    private String base64Process(String base64Str) {
        if (!org.springframework.util.StringUtils.isEmpty(base64Str)) {
            String photoBase64 = base64Str.substring(0, 30).toLowerCase();
            int indexOf = photoBase64.indexOf("base64,");
            if (indexOf > 0) {
                base64Str = base64Str.substring(indexOf + 7);
            }

            return base64Str;
        } else {
            return "";
        }
    }

    @Override
    public String getPublicUrl(String key) {
        return "https://" + ossProperties.getBucketName() + ".s3." + ossProperties.getRegion() + ".amazonaws.com/" + key;
    }

}
