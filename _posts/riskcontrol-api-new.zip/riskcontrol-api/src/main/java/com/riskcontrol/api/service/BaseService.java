package com.riskcontrol.api.service;

import com.riskcontrol.api.constants.Constants;
import com.riskcontrol.api.constants.exception.ApiResultBaseEnum;
import com.riskcontrol.api.utils.DESUtil;
import com.riskcontrol.api.utils.RSATool;
import com.riskcontrol.common.config.C66Config;
import com.riskcontrol.common.config.UserCenterConstant;
import com.riskcontrol.common.entity.request.BaseReq;
import com.riskcontrol.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

@Component
@Slf4j
public class BaseService {

    private static final String[] weekDays = {"星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"};

    @Resource
    private C66Config c66Config;


    @Resource
    private UserCenterConstant userCenterConstant;


    /**
     *
     * @param baseReq
     * @param x
     * @return
     */
    protected String decrypt(BaseReq baseReq, String x) {

        String privateKey = DESUtil.decrypt(userCenterConstant.getConstantValue(Constants.X3_KEY), userCenterConstant.getConstantValue(Constants.X2_KEY));
        String x1;
        if (NumberUtils.INTEGER_TWO.equals(c66Config.getAppType())) {
            x1 = RSATool.decrypt(x, privateKey, 1);
        } else {
            try {
                x1 = RSATool.decrypt(x, privateKey);
            } catch (Exception ex) {
                log.warn("尝试RSA解密失败，使用type=1的解密方式", ex);
                x1 = RSATool.decrypt(x, privateKey, 1);
            }
        }
        if (StringUtils.isBlank(x1)) {
            throw new BusinessException(ApiResultBaseEnum.PWD_DECRYPT_ERROR);
        }
        return x1;
    }

    public boolean isSkipEnvironment(String productId) {
        String isSkip = userCenterConstant.getConstantValue(Constants.CURRENT_ENVIRONMENT);
        return "TEST".equalsIgnoreCase(isSkip);
    }

    protected boolean isEmail(String s, BaseReq req) {
        if (StringUtils.isBlank(s)) {
            return false;
        }
        return s.indexOf("@") > 0;
    }


    protected String buildTimeEx(Date dt) {
        Date now = new Date();
        // 小于1小时,显示分钟
        if (now.compareTo(DateUtils.addMinutes(dt, 59)) < 0) {
            long x = (now.getTime() - dt.getTime()) / (60 * 1000);
            if (x <= 1) {
                x = 1;
            }
            return x + "分钟前";
        }
        // 同日则显示今天
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        if (sdf.format(now).equals(sdf.format(dt))) {
            sdf.applyPattern("HH:mm");
            return "今天 " + sdf.format(dt);
        }
        // 同周则显示星期
        if (getWeekOfYear(dt) == getWeekOfYear(now)) {
            sdf.applyPattern("HH:mm");
            return this.getWeekOfDate(dt) + " " + sdf.format(dt);
        }
        // 显示年月日
        sdf.applyPattern("yyyy-MM-dd HH:mm");
        return sdf.format(dt);
    }

    private int getWeekOfYear(Date dt) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(dt);
        return cal.get(Calendar.WEEK_OF_YEAR);
    }

    private String getWeekOfDate(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (w < 0) {
            w = 0;
        }
        return weekDays[w];
    }


}
