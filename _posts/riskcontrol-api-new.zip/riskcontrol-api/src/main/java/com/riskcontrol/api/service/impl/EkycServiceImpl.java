package com.riskcontrol.api.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.api.constants.exception.ApiResultBaseEnum;
import com.riskcontrol.api.entity.request.CheckResultReq;
import com.riskcontrol.api.entity.request.EkcyQueryReq;
import com.riskcontrol.api.entity.request.InitRealIDReq;
import com.riskcontrol.api.entity.response.EkycResult;
import com.riskcontrol.api.entity.response.EkycStatusRsp;
import com.riskcontrol.api.entity.response.InitEKycRsp;
import com.riskcontrol.api.exception.ApiBusinessException;
import com.riskcontrol.api.service.CustomerApiService;
import com.riskcontrol.api.service.EkycService;
import com.riskcontrol.api.service.RiskBlackService;
import com.riskcontrol.api.utils.AWSS3Util;
import com.riskcontrol.api.utils.ProductConstantsUtil;
import com.riskcontrol.api.utils.RedisUtil;
import com.riskcontrol.common.client.RiskEkycFeign;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.pojo.Ekyc;
import com.riskcontrol.common.entity.pojo.EkycRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycCreateRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycExtendRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycUpdateRequest;
import com.riskcontrol.common.entity.request.ekyc.EkycZolozErrorRequest;
import com.riskcontrol.common.entity.request.kyc.RiskQueryKycRequest;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.zoloz.InitRealIDBean;
import com.riskcontrol.common.entity.zoloz.InitRealIdResult;
import com.riskcontrol.common.entity.zoloz.RealIDResult;
import com.riskcontrol.common.entity.zoloz.ResultStatusStr;
import com.riskcontrol.common.enums.CardTypeEnum;
import com.riskcontrol.common.enums.EkycStatusEnum;
import com.riskcontrol.common.helper.ResponseHelper;
import com.riskcontrol.common.utils.BillNoUtil;
import com.riskcontrol.common.utils.DateUtils;
import com.zoloz.api.sdk.client.OpenApiClient;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.util.Strings;
import org.redisson.api.RAtomicLong;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import static com.riskcontrol.common.constants.Constant.*;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/10/7 18:30
 */
@Service
@Slf4j
public class EkycServiceImpl implements EkycService {
    private final static String  EKYC_INIT_LOCK = "risk:ekyc:init:lock:%s";
    private final static String  EKYC_UPDATE_EX_REQ_LOCK = "risk:ekyc:update:ex:lock:%s";
    @Autowired
    private OpenApiClient openApiClient;

    @Value("${zoloz.service.level:REALID0001}")
    private String serviceLevel;
    @Value("${zoloz.check.max.retry.time:3}")
    private int maxRetryTime;
    @Autowired
    private AWSS3Util awss3Util;
    @Autowired
    private CustomerApiService customerService;
    @Autowired
    RedissonClient redissonClient;
    @Autowired
    RiskEkycFeign riskEkycFeign;
    @Autowired
    RedisUtil redisUtil;
    @Autowired
    RiskBlackService riskBlackService;

    /**
     * 获取ekyc状态
     * @param req
     * @return
     */
    @Override
    public Response<EkycStatusRsp> queryStatus(@RequestBody EkcyQueryReq req) {
        Response<EkycStatusRsp> response = new Response<>();
        EkycStatusRsp ekycStatusRsp = new EkycStatusRsp();
        //获取ekyc状态
        Ekyc ekyc = this.getEkyc(req.getLoginName());
        ekycStatusRsp.setEkycStatus(ekyc.getStatus());
        if(ekyc.getStatus() == EkycStatusEnum.REJECTED_MANUAL.getEkycStatus()
                || ekyc.getStatus() == EkycStatusEnum.REJECTED_AUTO.getEkycStatus()){
            ekycStatusRsp.setRejectReason(ekyc.getRejectReason());
        }
        //查询是否在黑名单中
        ekycStatusRsp.setBlack(riskBlackService.getBlackStatus(req.getLoginName()));
        //获取老kyc状态
        if(req.isNeedOldKycStatus()){
            if(EkycStatusEnum.APPROVAL.getEkycStatus() == ekyc.getStatus()){
                ekycStatusRsp.setOldKycStatus(EkycStatusEnum.APPROVAL.getEkycStatus());
            }else{//如果ekyc状态是通过，老kyc不用去查询，直接赋值1
                RiskQueryKycRequest oldKycRequest = new RiskQueryKycRequest();
                oldKycRequest.setProductId("C66");
                oldKycRequest.setCustomerId(req.getCustomerId());
                oldKycRequest.setLoginName(req.getLoginName());
                Response<Integer> oldKycStatus = customerService.queryKycRequestFlag(oldKycRequest);
                ekycStatusRsp.setOldKycStatus(oldKycStatus.getBody());
            }
        }
        if(!req.isNoNeedEx()){
            //计算今日可尝试kyc次数
            long canTryTime = getCanTryTime(req.getLoginName());
            ekycStatusRsp.setCanKycTime(canTryTime);
            //人工拒绝后是否可以提交ekyc（1:禁止：其他状态或关闭不限制）
            String refuseKeyFlag = ProductConstantsUtil.obtainProductConstant(C66_PRODUCT_ID, "0018", "EKYC_REFUSE_TRY_FLAG");
            if(StringUtils.isNotBlank(refuseKeyFlag) && refuseKeyFlag.equals("1")){
                ekycStatusRsp.setRefuseInitFlag(true);
            }
        }
        response.setBody(ekycStatusRsp);
        return response;
    }

    /**
     * 获取ekyc 状态（优先缓存）
     * @return
     */
    private Ekyc getEkyc(String loginName) {
        String key = String.format(RISK_EKYC_STATUS_KEY, loginName);
        RBucket<Ekyc> bucketEkyc = redissonClient.getBucket(key);
        if(Objects.isNull(bucketEkyc.get())){
            Ekyc ekyc = ResponseHelper.pullData(riskEkycFeign.queryStatus(loginName));
            if(null == ekyc){
                ekyc = new Ekyc();
                ekyc.setStatus(EkycStatusEnum.INIT_0.getEkycStatus());
            }
            bucketEkyc.set(ekyc,30,TimeUnit.MINUTES);
            return ekyc;
        }else{
            return bucketEkyc.get();
        }
    }


    /**
     * 计算今日可提交ekyc次数
     * @param loginName
     * @return
     */
    private long getCanTryTime(String loginName) {
        String tryLimitCount = ProductConstantsUtil.obtainProductConstant(C66_PRODUCT_ID, "0018", "EKYC_DAY_TRY_COUNT");
        long limitCount = 3;
        if(StringUtils.isNotBlank(tryLimitCount)){
            limitCount = Integer.parseInt(tryLimitCount);
        }
        int dayOfDate = DateUtils.getDayOfDate(new Date());
        String countKey = String.format(RISK_EKYC_DAY_COUNT, loginName, dayOfDate);
        long atomicLong = redissonClient.getAtomicLong(countKey).get();
        long canTryTime = limitCount - atomicLong;
        return canTryTime;
    }

    /**
     * 初始化ekyc流程
     * @param req
     * @return
     */
    @Override
    public Response<InitEKycRsp> h5RealIdInit(@RequestBody InitRealIDReq req) {
        log.info("h5RealIdInit 请求参数：{}", JSONObject.toJSONString(req));
        Response<InitEKycRsp> response = new Response<>();
        String lockKey = String.format(EKYC_INIT_LOCK,req.getLoginName());
        boolean lockd =false;
        try {
            lockd = redisUtil.tryLock(lockKey, 30, -1, TimeUnit.SECONDS);
            if(lockd){
                Ekyc ekyc = this.getEkyc(req.getLoginName());
                if(ekyc.getStatus() == EkycStatusEnum.APPROVAL.getEkycStatus()){
                    throw new ApiBusinessException(ApiResultBaseEnum.ERROR_EKYC_IS_APPROVE);
                }

                if(ekyc.getStatus() == EkycStatusEnum.REJECTED_MANUAL.getEkycStatus()){
                    //人工拒绝后是否可以提交ekyc（1:禁止：其他状态或关闭不限制）
                    String refuseKeyFlag = ProductConstantsUtil.obtainProductConstant(C66_PRODUCT_ID, "0018", "EKYC_REFUSE_TRY_FLAG");
                    if(StringUtils.isNotBlank(refuseKeyFlag) && refuseKeyFlag.equals("1")){
                        throw new ApiBusinessException(ApiResultBaseEnum.ERROR_REJECTED_MANUAL);
                    }
                }
                InitEKycRsp initEKycRsp = new InitEKycRsp();
                //查询用户最近一笔t_ekyc_req提案，不含人工
                EkycRequest oldEkycRequest =  riskEkycFeign.queryCurrentKycRequest(req.getLoginName()).getBody();
                //人工拒绝后是否可以提交ekyc（1:禁止：其他状态或关闭不限制）
                String refuseKeyFlag = ProductConstantsUtil.obtainProductConstant(C66_PRODUCT_ID, "0018", "EKYC_REFUSE_TRY_FLAG");
                if(Objects.isNull(oldEkycRequest) || oldEkycRequest.getStatus() == EkycStatusEnum.REJECTED_AUTO.getEKycReqStatus()
                        || (oldEkycRequest.getStatus() == EkycStatusEnum.REJECTED_MANUAL.getEKycReqStatus() && !"1".equals(refuseKeyFlag))
                        || oldEkycRequest.getStatus() == EkycStatusEnum.FAILURE.getEKycReqStatus()){//无等待结果和审批的提案，可以初始化
                    initEKycRsp = initH5RealIdAndCreateRequest(req,true);
                    initEKycRsp.setStep("1");
                }else if(oldEkycRequest.getStatus() == EkycStatusEnum.INIT_0.getEKycReqStatus()){//有提案记录，但没获取过ekyc结果
                    CheckResultReq checkResultReq = new CheckResultReq();
                    checkResultReq.setTransactionId(oldEkycRequest.getEkycTransactionId());
                    checkResultReq.setRequestId(oldEkycRequest.getId());
                    checkResultReq.setBizId(BillNoUtil.getBillNo());
                    checkResultReq.setLoginName(oldEkycRequest.getLoginName());
                    EkycResult realIdCheck = getRealIdCheck(checkResultReq, 0);
                    if(Objects.isNull(realIdCheck)){//结果为VoidCancelled、VoidTimeout，重新初始化
                        initEKycRsp = initH5RealIdAndCreateRequest(req, false);
                    }else if("InProcess".equals(realIdCheck.getResult())){
                        CardTypeEnum enumByZolozType = CardTypeEnum.findEnumByZolozType(req.getDocType());
                        if(!oldEkycRequest.getIdType().equals(enumByZolozType.getCode())){
                            log.info("已存在提案和本次请求证件类型不一致，取消上一笔订单，重新初始化zoloz");
                            EkycZolozErrorRequest errorRequest = EkycZolozErrorRequest.builder().ekycResult(ResultStatusStr.RISK_SYSTEM_CANCELLED)
                                    .loginName(req.getLoginName()).requestId(oldEkycRequest.getId()).ekycResultDate(new Date())
                                    .build();
                            //调用cron 更新提案和主表状态
                            Response<Boolean> cancelRespon = riskEkycFeign.updateEkycStatus(errorRequest);
                            if(cancelRespon.success() && BooleanUtils.isTrue(cancelRespon.getBody())){
                                initEKycRsp = initH5RealIdAndCreateRequest(req,false);
                            }
                        }else{
                            //如果该笔查询后还未提交，去缓存重新获取上次初始化链接
                            String zolozInitKey = String.format(RISK_EKYC_INIT_KEY, req.getLoginName());
                            RBucket<Object> zolozBucket = redissonClient.getBucket(zolozInitKey);
                            if(Objects.nonNull(zolozBucket.get())){
                                initEKycRsp.setStep("1");
                                initEKycRsp.setClientCfg(zolozBucket.get().toString());
                            }else{//如过期后，重新初始化
                                initEKycRsp = initH5RealIdAndCreateRequest(req,false);
                            }
                        }

                    }else{
                        realIdCheck.setRequestId(String.valueOf(oldEkycRequest.getId()));
                        initEKycRsp.setEkycResult(realIdCheck);
                        initEKycRsp.setStep("2");
                    }
                }else if(oldEkycRequest.getStatus() == EkycStatusEnum.INIT_1.getEKycReqStatus()){//有提案记录，并获取到ekyc结果，待完善信息
                    EkycResult ekycReslut = new EkycResult();
                    BeanUtils.copyProperties(oldEkycRequest,ekycReslut);
                    ekycReslut.setRequestId(String.valueOf(oldEkycRequest.getId()));
                    initEKycRsp.setStep("2");
                    initEKycRsp.setEkycResult(ekycReslut);
                }else{//状态非法
                    throw new ApiBusinessException(ApiResultBaseEnum.ERROR_EKYC_STATUS_ERROR);
                }
                response.setBody(initEKycRsp);
            }else{
                throw new ApiBusinessException(ApiResultBaseEnum.ERROR_NOT_REPEAT);
            }
        }finally {
            if(lockd){
                redisUtil.unLock(lockKey);
            }
        }
        return response;
    }

    /**
     * 初始化ekyc流程，并创建提案记录请求id
     * @param req
     * @param addTimes 是否记录使用次数
     * @return
     */
    private InitEKycRsp initH5RealIdAndCreateRequest(InitRealIDReq req,boolean addTimes) {
        //校验是否可以创建kyc
        long canTryTime = getCanTryTime(req.getLoginName());
        if(canTryTime <= 0){
            throw new ApiBusinessException(ApiResultBaseEnum.ERROR_EKYC_TRY_MAX);
        }
        InitEKycRsp rsp = new InitEKycRsp();
        //初始化ekyc
        InitRealIdResult initRealIdResult = initH5RealId(req);

        EkycCreateRequest createRequest = EkycCreateRequest.builder()
                .loginName(req.getLoginName()).customerId(Long.valueOf(req.getCustomerId())).tenant(req.getTenant())
                .transactionId(initRealIdResult.getTransactionId()).channel(req.getChannel()).billNo(req.getBizId())
                .idType(Integer.valueOf(CardTypeEnum.findEnumByZolozType(req.getDocType()).getCode()))
                .build();
        //调用cron 写入t_ekyc_request
        Boolean result = ResponseHelper.pullData(riskEkycFeign.createEkycRequest(createRequest));
        if(result){
            //初始化的链接缓存25分钟
            String zolozInitKey = String.format(RISK_EKYC_INIT_KEY, req.getLoginName());
            RBucket<Object> zolozBucket = redissonClient.getBucket(zolozInitKey);
            zolozBucket.set(initRealIdResult.getClientCfg(),25,TimeUnit.MINUTES);//zoloz 半小时过期，设置25分超时
            if(addTimes){
                //记录当日初始次数缓存
                int dayOfDate = DateUtils.getDayOfDate(new Date());
                String countKey = String.format(RISK_EKYC_DAY_COUNT, req.getLoginName(), dayOfDate);
                RAtomicLong atomicLong = redissonClient.getAtomicLong(countKey);
                atomicLong.incrementAndGet();
                atomicLong.expire(1, TimeUnit.DAYS);
            }
            rsp.setStep("1");
            rsp.setClientCfg(initRealIdResult.getClientCfg());
            return rsp;
        }else{
            throw new ApiBusinessException(ApiResultBaseEnum.ERROR_EKYC_CREATE_ERROR);
        }
    }

    public InitRealIdResult initH5RealId(InitRealIDReq req) {


        req.setBizId(BillNoUtil.getBillNo());
        req.setSceneCode("riskVerify");
        req.setUserId(req.getCustomerId());
        req.setServiceLevel(serviceLevel);
        String docType = req.getDocType();
        CardTypeEnum enumByZolozType = CardTypeEnum.findEnumByZolozType(docType);
        if(null == enumByZolozType){
            throw new ApiBusinessException(ApiResultBaseEnum.ERROR_EKYC_ID_TYPE_FAIL);
        }

        //暂时移除
//        if(req.getFlowType().equals("H5_REALIDLITE_KYC")){
//            if(null == req.getH5ModeConfig()
//                    || StringUtils.isAnyBlank(req.getH5ModeConfig().getCompleteCallbackUrl(),
//                    req.getH5ModeConfig().getInterruptCallbackUrl())){
//                throw new ApiBusinessException(ApiResultBaseEnum.ERROR_EKYC_H5_PARAMETER_ERROR);
//            }
//        }

        InitRealIDBean initRealIDBean = new InitRealIDBean();
        BeanUtils.copyProperties(req,initRealIDBean);
        if(CardTypeEnum.TIN.getCode().equals(enumByZolozType.getCode())){
            initRealIDBean.setDocType(null);
            initRealIDBean.setAutoDocTypes(List.of(CardTypeEnum.TIN.getZolozType().split(Constant.SPLIT_SYMBOL)));
        }
        log.info("h5initialize 初始化参数：{}",JSONObject.toJSONString(initRealIDBean));
        String apiRespStr = openApiClient.callOpenApi(
                "v1.zoloz.realid.initialize",
                JSONObject.toJSONString(initRealIDBean)
        );
        log.info("response=" + apiRespStr);
        InitRealIdResult initRealIdResult = JSONObject.parseObject(apiRespStr, InitRealIdResult.class);
        if(Objects.isNull(initRealIdResult.getResult()) ||
                !("S").equals(initRealIdResult.getResult().getResultStatus())){
            throw new ApiBusinessException(ApiResultBaseEnum.ERROR_EKYC_INIT_ERROR);
        }
        return initRealIdResult;
    }

    /**
     * 获取zoloz认证结果并组装数据
     * @param req
     * @param retryTime
     * @return
     */
    private EkycResult getRealIdCheck(CheckResultReq req, int retryTime) {
        EkycResult ekycReslut = new EkycResult();
        log.info("realIdCheck zoloz 查询参数：{}",JSONObject.toJSONString(req));
        String apiRespStr = openApiClient.callOpenApi(
                "v1.zoloz.realid.checkresult",
                JSONObject.toJSONString(req)
        );
        log.info("realIdCheck zoloz transactionId:{},返回结果：{}",req.getTransactionId(),StringUtils.substring(apiRespStr,0,300));
        RealIDResult result = JSONObject.parseObject(apiRespStr, RealIDResult.class);
        if(Objects.isNull(result.getResult()) ||
                !("S").equals(result.getResult().getResultStatus())){
            throw new ApiBusinessException(ApiResultBaseEnum.ERROR_EKYC_INIT_ERROR);
        }
        String transactionId = req.getTransactionId();
        switch (result.getEkycResult()){
            case ResultStatusStr.SUCCESS:
            case ResultStatusStr.FAILURE:
            case ResultStatusStr.PENDING:
                //赋值
                RealIDResult.ExtIdInfo.OcrResult  ocrResult = result.getExtIdInfo().getOcrResult();
                log.info("realIdCheck zoloz transactionId:{},转换结果：{}",req.getTransactionId(),JSONObject.toJSONString(ocrResult));

                EkycUpdateRequest updateRequest = EkycUpdateRequest.builder().id(req.getRequestId())
                        .loginName(req.getLoginName()).idNo(ocrResult.getIdNumber()).firstName(ocrResult.getFirstName())
                        .middleName(ocrResult.getMiddleName()).lastName(ocrResult.getLastName())
                        .ekycResultDate(new Date()).ekycResult(result.getEkycResult())
                        .build();

                if(result.getExtIdInfo().getEkycResultDoc().equals(ResultStatusStr.SUCCESS)
                        && result.getExtFaceInfo().getEkycResultFace().equals(ResultStatusStr.SUCCESS)
                        && result.getExtRiskInfo().getEkycResultRisk().equals(ResultStatusStr.PENDING)){
                    //风控状态不通过，原因可能是相同人脸等风险原因，可以转人工
                    if("ID_NETWORK_HIGH_RISK".equals(result.getExtRiskInfo().getStrategyPassResult())){
                        updateRequest.setEkycResult(ResultStatusStr.RISK_SAME_FACE_OR_ID);
                    }else{
                        updateRequest.setEkycResult(ResultStatusStr.RISK_PENDING);
                    }
                }
                String sex = StringUtils.EMPTY;//性别处理
                if(StringUtils.isNotBlank(ocrResult.getSex())){
                    if(ocrResult.getSex().length() > 1 ){
                        String sexTmp = Strings.toUpperCase(ocrResult.getSex().substring(0,1));
                        if("M".equals(sexTmp) || "F".equals(sexTmp)){
                            sex = sexTmp;
                        }
                    }else{
                        sex = Strings.toUpperCase(ocrResult.getSex());
                    }
                }
                updateRequest.setSex(sex);
                //照片上传到aws
                processImg(result, updateRequest, transactionId);
                if(StringUtils.isNotBlank(ocrResult.getBirthDay())){
                    updateRequest.setBirthday(ocrResult.getBirthDay().replaceAll("/","-"));
                }
                //调用cron，更新提案表
                riskEkycFeign.saveVerificationInfo(updateRequest);
                BeanUtils.copyProperties(updateRequest,ekycReslut);
                return ekycReslut;
            case "InProcess":
                if(retryTime++ >= maxRetryTime){
                    log.error("realIdCheck 尝试{}次获取返回结果，仍在执行中，中断执行",retryTime);
                    ekycReslut.setResult(result.getEkycResult());
                    return ekycReslut;
                }
                log.warn("realIdCheck 第{}次查询，正在验证中,等待1秒后重试",retryTime);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                return getRealIdCheck(req,retryTime);
            case "VoidCancelled":
            case "VoidTimeout":
            default:
                log.warn("realIdCheck 用户取消了身份验证或验证超时");
                EkycZolozErrorRequest errorRequest = EkycZolozErrorRequest.builder().ekycResult(result.getEkycResult())
                        .loginName(req.getLoginName()).requestId(req.getRequestId()).ekycResultDate(new Date())
                        .build();
                //调用cron 更新提案和主表状态
                riskEkycFeign.updateEkycStatus(errorRequest);
                return null;
        }
    }

    /**
     * 照片上传到aws
     * @param result
     * @param updateRequest
     * @param transactionId
     */
    private void processImg(RealIDResult result, EkycUpdateRequest updateRequest, String transactionId) {
        try {
            String frontPageImg = result.getExtIdInfo().getFrontPageImg();//正面照片
            if(StringUtils.isNotBlank(frontPageImg)){
                updateRequest.setIdFrontImg(transactionId +"-front");
                awss3Util.s3PutObject(frontPageImg, updateRequest.getIdFrontImg());
            }
        } catch (Exception e) {
            log.error("上传证件正面照异常",e);
        }
        try {
            String backPageImg = result.getExtIdInfo().getBackPageImg();//背面照片,可能为空
            if(StringUtils.isNotBlank(backPageImg)){
                updateRequest.setIdBackImg(transactionId +"-face");
                awss3Util.s3PutObject(backPageImg, updateRequest.getIdBackImg());
            }
        } catch (Exception e) {
            log.error("上传证件背面照异常",e);
        }
        try {
            String faceImg = result.getExtFaceInfo().getFaceImg();//自拍照
            if(StringUtils.isNotBlank(faceImg)){
                updateRequest.setFaceImg(transactionId +"-face");
                awss3Util.s3PutObject(faceImg, updateRequest.getFaceImg());
            }
        } catch (Exception e) {
            log.error("上传人脸照片异常",e);
        }
    }

    /**
     * 完善ekyc信息
     * @param req
     * @return
     */
    @Override
    public Response<Boolean> modifyEkycRequest(EkycExtendRequest req) {
        String lockKey = String.format(EKYC_UPDATE_EX_REQ_LOCK,req.getRequestId());
        boolean lockd =false;
        try {
            lockd = redisUtil.tryLock(lockKey, 30, -1, TimeUnit.SECONDS);
            if(lockd){
                return riskEkycFeign.modifyEkycRequest(req);
            }else{
                throw new ApiBusinessException(ApiResultBaseEnum.ERROR_NOT_REPEAT);
            }
        }finally {
            if(lockd){
                redisUtil.unLock(lockKey);
            }
        }
    }


}
