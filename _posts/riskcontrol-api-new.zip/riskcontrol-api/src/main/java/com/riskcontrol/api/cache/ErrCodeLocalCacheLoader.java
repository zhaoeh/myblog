package com.riskcontrol.api.cache;

import com.riskcontrol.api.template.CronFeignTemplate;
import com.riskcontrol.common.cache.LocalCacheLoader;
import com.riskcontrol.common.constants.Constant;
import com.riskcontrol.common.entity.response.ErrResponse;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.function.Supplier;

/**
 * 错误码本地缓存加载器
 */
@Component
@Slf4j
public class ErrCodeLocalCacheLoader implements LocalCacheLoader<Map<String, ErrResponse>> {


    private CronFeignTemplate cronFeignTemplate;

    public ErrCodeLocalCacheLoader(CronFeignTemplate cronFeignTemplate) {
        this.cronFeignTemplate = cronFeignTemplate;
    }

    @Override
    public String getDataCategory() {
        return Constant.ERROR_CODE_CACHE;
    }

    @Override
    public Supplier<Map<String, ErrResponse>> getValueSupplier() {
        return this::initErrMap;
    }

    /**
     * 初始化系统所用到的error信息
     *
     * @return 错误码信息映射
     */
    private Map<String, ErrResponse> initErrMap() {
        Response<Object> localCacheResult;
        try {
            localCacheResult = cronFeignTemplate.loadLocalCacheInfoByKeyFromCron(getDataCategory());
        } catch (BusinessException e) {
            return null;
        }
        Object localCacheData = localCacheResult.success() ? localCacheResult.getBody() : null;
        if (localCacheData instanceof Map) {
            Map<String, ErrResponse> errMap = (Map<String, ErrResponse>) localCacheData;
            log.info(" 刷新当前缓存类别为 {} ,其数量为 {}", getDataCategory(), errMap.size());
            return errMap;
        }
        return null;
    }
}
