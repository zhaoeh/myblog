package com.riskcontrol.api.controller;

import com.riskcontrol.api.entity.request.EkcyQueryReq;
import com.riskcontrol.api.entity.request.InitRealIDReq;
import com.riskcontrol.api.entity.response.EkycStatusRsp;
import com.riskcontrol.api.entity.response.InitEKycRsp;
import com.riskcontrol.api.service.EkycService;
import com.riskcontrol.common.entity.request.ekyc.EkycExtendRequest;
import com.riskcontrol.common.entity.response.Response;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/10/4 10:02
 */
@RestController
@RequestMapping("/ekyc")
@Api("风控标签相关接口")
@Slf4j
public class EkycController {
    @Autowired
    private EkycService ekycService;

    @PostMapping(value = "/queryStatus")
    @ApiOperation(value = "查询用户ekyc状态")
    public Response<EkycStatusRsp> queryStatus(@RequestBody @Validated EkcyQueryReq req) {
        return ekycService.queryStatus(req);
    }

    @PostMapping(value = "/h5RealIdInit")
    @ApiOperation(value = "初始化ekyc流程")
    public Response<InitEKycRsp> h5RealIdInit(@RequestBody @Validated InitRealIDReq req) {
        return ekycService.h5RealIdInit(req);
    }

    @PostMapping(value = "/modifyEkycRequest")
    @ApiOperation(value = "更新提案扩展信息")
    public Response<Boolean> modifyEkycRequest(@RequestBody @Validated EkycExtendRequest req) {
        return ekycService.modifyEkycRequest(req);
    }
}
