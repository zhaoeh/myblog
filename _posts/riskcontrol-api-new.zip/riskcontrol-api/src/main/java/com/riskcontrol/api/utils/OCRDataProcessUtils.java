package com.riskcontrol.api.utils;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @Description: OCR 数据处理方式
 */
public class OCRDataProcessUtils {

    public static String ENDLISH_DATE_REGEX = "(?:(?:\\d{1,2}(?:st|nd|rd|th)?\\s+)?(?i)(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\\s+(?:\\d{1,2}(?:st|nd|rd|th)?[,\\s]\\s*)?\\d{2,4})";
    public static String REGEX_DDMMMYYYY = "(?i)(?:\\d{1,2}\\s+(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\\s+\\d{2,4})";
    public static String REGEX_MMM_DD_YYYY_COMMA = "(?:(?i)(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\\s+(?:\\d{1,2}\\,\\s*)\\d{2,4})";
    public static String REGEX_MMM_DD_YYYY_POINT = "(?:(?i)(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\\s+(?:\\d{1,2}\\.\\s*)\\d{2,4})";
    public static String REGEX_DD_MMM_YYYY_SLASH = "(?i)(?:\\d{1,2}/(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)/\\d{2,4})";
    public static String REGEX_DD_MMM_YYYY_POINT = "(?i)(?:\\d{1,2}\\.(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\\.\\d{2,4})";

    public static String REGEX_DD_MMM_YYYY_BAR = "(?i)(?:\\d{1,2}-(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)-\\d{2,4})";
    public static String REGEX_DDMMM_YYYY_BAR = "(?i)(?:\\d{1,2}\\s+(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)-\\d{2,4})";

    // 日/月/年 只有时间大于12的时候能区分日期和月份
    public static String REGEX_DD_MM_YYYY_SLASH = "(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[012])/((19|20)\\d\\d)";
    // 月/日/年 只有时间大于12的时候能区分日期和月份
    public static String REGEX_MM_DD_YYYY_SLASH = "(0[1-9]|1[012])/(0[1-9]|[12][0-9]|3[01])/((19|20)\\d\\d)";
    public static String REGEX_YYYY_MM_DD_SLASH = "\\d{4}/\\d{2}/\\d{2}";
    public static String REGEX_YYYY_MM_DD_BAR = "\\d{4}-\\d{2}-\\d{2}";
    // dd MM yy
    public static String REGEX_DDMMYYYY = "(0[1-9]|[12][0-9]|3[01])\\s+(0[1-9]|1[012])\\s+((19|20)\\d\\d)";
    //判断日期和月份是否是数字且都为两位数
    public static String REGEX_TWODIGITS_DDMM = "(?:\\d{4}[,\\s+/-])?\\d{2}[,\\s+/-]\\d{2}(?:[,\\s+/-]\\d{4})?";

    public static String REGEX_SEX = "FEMALE|MALE|M|F";
    //默认匹配范围
    public static int MATCH_SCOPE_DEFAULT = 4;


    /**
     * 根据正则规则匹配数据,返回已匹配的数据，默认匹配范围
     *
     * @param text
     * @param titleIndex
     * @param currentIndex
     * @param regex
     * @return
     */
    public static String takeColumnarRegexData(String text, int titleIndex, int currentIndex, String regex) {
        return takeColumnarRegexData(text, titleIndex, currentIndex, MATCH_SCOPE_DEFAULT, regex);
    }

    /**
     * 根据正则规则匹配数据
     *
     * @param text
     * @param titleIndex
     * @param currentIndex
     * @param scope
     * @param regex
     * @return
     */
    public static String takeColumnarRegexData(String text, int titleIndex, int currentIndex, int scope, String regex) {
        if (titleIndex > 0 && currentIndex <= (titleIndex + scope)) {
            if (StringUtils.isNotEmpty(regex)) {
                return getTextByRegex(text, regex);
            }
        }
        return null;
    }

    /**
     * 带类型标题，提取数据
     * 匹配范围默认，类型标题和数据在一行
     *
     * @param text         待匹配字符串
     * @param category     类型名称
     * @param titalIndex   类型角标
     * @param currentIndex 当前数据的角标
     * @param regex        正则规则
     * @param titalList    标题集合
     * @param valueList    数据集合
     * @return
     */
    public static ConvertEntity convertByCategory(String text, String category, int titalIndex, int currentIndex, String regex, List<String> titalList, List<String> valueList) {
        return convertByCategory(text, category, titalIndex, currentIndex, regex, titalList, valueList, MATCH_SCOPE_DEFAULT, false);
    }

    /**
     * 带类型标题，提取数据
     * 匹配范围默认
     *
     * @param text            待匹配字符串
     * @param category        类型名称
     * @param titalIndex      类型角标
     * @param currentIndex    当前数据的角标
     * @param regex           正则规则
     * @param titalList       标题集合
     * @param valueList       数据集合
     * @param isTitleValueSep 类型标题和数据是否分开，不在一行： true-不在一行
     * @return
     */
    public static ConvertEntity convertByCategory(String text, String category, int titalIndex, int currentIndex, String regex, List<String> titalList, List<String> valueList, boolean isTitleValueSep) {
        return convertByCategory(text, category, titalIndex, currentIndex, regex, titalList, valueList, MATCH_SCOPE_DEFAULT, isTitleValueSep);
    }

    /**
     * 带类型标题，提取数据
     * 可设置匹配范围
     *
     * @param text         待匹配字符串
     * @param category     类型名称
     * @param titalIndex   类型角标
     * @param currentIndex 当前数据的角标
     * @param regex        正则规则
     * @param titalList    标题集合
     * @param valueList    数据集合
     * @param scope        匹配范围
     * @return
     */
    public static ConvertEntity convertByCategory(String text, String category, int titalIndex, int currentIndex, String regex, List<String> titalList, List<String> valueList, int scope) {
        return convertByCategory(text, category, titalIndex, currentIndex, regex, titalList, valueList, scope, false);
    }

    /**
     * 带类型标题，提取数据
     * 从titalIndex开始匹配,向下查scope个
     *
     * @param text
     * @param category
     * @param titleIndex
     * @param currentIndex
     * @param regex
     * @param valueList
     * @return
     */
    public static ConvertEntity convertByCategory(String text, String category, int titleIndex, int currentIndex, String regex, List<String> titleList, List<String> valueList, int scope, boolean isTitleValueSep) {
        ConvertEntity convert = new ConvertEntity();

        if (titleIndex >= -1 && text.toUpperCase().contains(category.toUpperCase())) {
            titleIndex = currentIndex;
            convert.setTitalIndex(titleIndex);
            convert.setFirstTitalIndex(titleIndex);
            convert.setMatchText(true);
            if (isTitleValueSep) {
                return convert;
            }
        }
        if (titleIndex >= 0 && !titleList.contains(text) && !valueList.contains(text) && currentIndex <= (titleIndex + scope)) {
            text = text.replace(category, "");
            if (regex != null) {
                String matcherText = getTextByRegex(text, regex);
                if (!StringUtils.isEmpty(matcherText)) {
                    titleIndex = -2;
                    valueList.add(matcherText);

                    convert.setText(matcherText);
                    convert.setTitalIndex(titleIndex);
                    convert.setMatchText(true);
                }
            } else {
                titleIndex = -2;
                valueList.add(text);
                convert.setText(text.trim());
                convert.setTitalIndex(titleIndex);
                convert.setMatchText(true);
            }
            return convert;
        }


        return convert;
    }

    /**
     * 无标题类型，只有一行数据进行匹配，支持正则和没有正则的情况
     * 指定数据行
     *
     * @param text
     * @param dataIndex
     * @param regex
     * @param titalList
     * @param valueList
     * @return
     */
    public static ConvertEntity convertByNoCategory(String text, int dataIndex, String regex, int currentIndex, List<String> titalList, List<String> valueList) {
        if (currentIndex >= 0 && currentIndex != dataIndex) {
            return null;
        }
        return convertByNoCategory(text, dataIndex, regex, titalList, valueList);
    }

    /**
     * 无标题类型，只有一行数据进行匹配，支持正则和没有正则的情况
     *
     * @param text
     * @param titleIndex
     * @param regex
     * @param titalList
     * @param valueList
     * @return
     */
    public static ConvertEntity convertByNoCategory(String text, int titleIndex, String regex, List<String> titalList, List<String> valueList) {
        if (titleIndex >= 0 && !titalList.contains(text) && !valueList.contains(text)) {
            ConvertEntity convert = new ConvertEntity();
            if (regex != null) {
                String matcherText = getTextByRegex(text, regex);
                if (!StringUtils.isEmpty(matcherText)) {
                    titleIndex = -1;
                    valueList.add(matcherText);
                    convert.setText(matcherText);
                    convert.setTitalIndex(titleIndex);
                    convert.setMatchText(true);
                }
            } else {
                titleIndex = -1;
                valueList.add(text);
                convert.setText(text.trim());
                convert.setTitalIndex(titleIndex);
                convert.setMatchText(true);
            }
            return convert;
        }
        return null;
    }

    /**
     * 根据正则规则进行匹配，提取数据
     * 根据正则规则进行全文匹配
     *
     * @param text
     * @param regex
     * @param titleList
     * @param valueList
     * @return
     */
    public static ConvertEntity convertByRegex(String text, String regex, List<String> titleList, List<String> valueList) {
        if (!valueList.contains(text)) {
            boolean isTital = titleList.stream().anyMatch(s -> s.contains(text));
            if (isTital) {
                return null;
            }
            String matcherText = getTextByRegex(text, regex);
            if (!StringUtils.isEmpty(matcherText)) {
                ConvertEntity convert = new ConvertEntity();
                valueList.add(matcherText);
                convert.setText(matcherText.trim());
                convert.setMatchText(true);
                return convert;
            }
        }
        return null;
    }

    /**
     * 提取日期数据
     * 从titalIndex开始匹配
     *
     * @param text
     * @param category
     * @param titleIndex
     * @param currentIndex
     * @param valueList
     * @return
     */
    public static ConvertEntity categoryConvertByDate(String text, String category, int titleIndex, int currentIndex, List<String> valueList) {
        return categoryConvertByDate(text, category, titleIndex, currentIndex, valueList, MATCH_SCOPE_DEFAULT);
    }

    public static ConvertEntity categoryConvertByDate(String text, String category, int titleIndex, int currentIndex, List<String> valueList, String dateFormatDefault) {
        return categoryConvertByDate(text, category, titleIndex, currentIndex, valueList, MATCH_SCOPE_DEFAULT, dateFormatDefault);
    }

    /**
     * 提取日期数据
     * 从titalIndex开始匹配,匹配范围为scope
     *
     * @param text
     * @param category
     * @param titleIndex
     * @param currentIndex
     * @param valueList
     * @param scope
     * @return
     */
    public static ConvertEntity categoryConvertByDate(String text, String category, int titleIndex, int currentIndex, List<String> valueList, int scope) {
        ConvertEntity convert = new ConvertEntity();
        if (StringUtils.isNotEmpty(category) && text.toUpperCase().contains(category.toUpperCase())) {
            titleIndex = currentIndex;
            convert.setTitalIndex(titleIndex);
            convert.setMatchText(true);
        }
        if (titleIndex >= 0 && !valueList.contains(text) && currentIndex <= (titleIndex + scope)) {
            //匹配日期格式
            ConvertEntity entity = getDateRegex(text);
            if (entity != null) {
                if (StringUtils.isNotEmpty(entity.getText())) {
                    Date brithDate = DateUtil.getDateFromString(entity.getText(), entity.getDateFormat(), Locale.ENGLISH);
                    if (new Date().getTime() <= brithDate.getTime()) {
                        return convert;
                    }
                }
                titleIndex = -1;
                valueList.add(entity.getText());
                convert.setTitalIndex(titleIndex);
                convert.setText(entity.getText());
                convert.setDateFormat(entity.getDateFormat());
                convert.setMatchText(true);
                return convert;
            }
        }
        return convert;
    }

    /**
     * 提取日期数据
     * 从titalIndex开始匹配,匹配范围为scope,默认日期格式dateFormatDefault
     *
     * @param text
     * @param category
     * @param titleIndex
     * @param currentIndex
     * @param valueList
     * @param scope
     * @param dateFormatDefault
     * @return
     */
    public static ConvertEntity categoryConvertByDate(String text, String category, int titleIndex, int currentIndex, List<String> valueList, int scope, String dateFormatDefault) {
        ConvertEntity convert = new ConvertEntity();
        if (StringUtils.isNotEmpty(category) && text.toUpperCase().contains(category.toUpperCase())) {
            titleIndex = currentIndex;
            convert.setTitalIndex(titleIndex);
            convert.setMatchText(true);
        }
        if (titleIndex >= 0 && !valueList.contains(text) && currentIndex <= (titleIndex + scope)) {
            //匹配日期格式
            ConvertEntity entity = getDateRegex(text);

            if (entity != null) {
                if (StringUtils.isNotEmpty(entity.getText())) {
                    //日期和月份都为两位数字时，且都小于12无法区分时，根据传的默认格式进行转换
                    boolean isTwoDigits = Pattern.compile(REGEX_TWODIGITS_DDMM).matcher(entity.getText()).matches();
                    if (StringUtils.isNotEmpty(dateFormatDefault) && isTwoDigits) {
                        entity.setDateFormat(dateFormatDefault);
                    }
                    Date brithDate = DateUtil.getDateFromString(entity.getText(), entity.getDateFormat(), Locale.ENGLISH);
                    if (new Date().getTime() <= brithDate.getTime()) {
                        return convert;
                    }
                }
                titleIndex = -1;
                valueList.add(entity.getText());
                convert.setTitalIndex(titleIndex);
                convert.setText(entity.getText());
                convert.setDateFormat(entity.getDateFormat());
                convert.setMatchText(true);
                return convert;
            }
        }
        return convert;
    }

    /**
     * 根据正则匹配字符串，并返回匹配的字符串
     *
     * @param text  待匹配字符串
     * @param regex 正则
     * @return 匹配上的字符串
     */
    public static String getTextByRegex(String text, String regex) {
        Pattern compile = Pattern.compile(regex);
        Matcher matcher = compile.matcher(text);
        while (matcher.find()) {
            return matcher.group();
        }
        return null;
    }

    /**
     * 获取日期格式
     *
     * @param dateString
     * @return
     */
    public static ConvertEntity getDateRegex(String dateString) {
        Map<String, String> dateFormatMap = new HashMap<>(10);
        dateFormatMap.put(REGEX_YYYY_MM_DD_BAR, "yyyy-MM-dd");
        dateFormatMap.put(REGEX_YYYY_MM_DD_SLASH, "yyyy/MM/dd");
        dateFormatMap.put(REGEX_DDMMMYYYY, "dd MMM yy");
        dateFormatMap.put(REGEX_MMM_DD_YYYY_COMMA, "MMM dd,yyyy");
        dateFormatMap.put(REGEX_MMM_DD_YYYY_POINT, "MMM dd.yyyy");
        dateFormatMap.put(REGEX_DD_MMM_YYYY_SLASH, "dd/MMM/yyyy");
        dateFormatMap.put(REGEX_DD_MMM_YYYY_BAR, "dd-MMM-yyyy");
        dateFormatMap.put(REGEX_DDMMM_YYYY_BAR, "dd MMM-yyyy");
        dateFormatMap.put(REGEX_DD_MM_YYYY_SLASH, "dd/MM/yyyy");
        dateFormatMap.put(REGEX_MM_DD_YYYY_SLASH, "MM/dd/yyyy");

        dateFormatMap.put(REGEX_DD_MMM_YYYY_POINT, "dd.MMM.yyyy");
        dateFormatMap.put(REGEX_DDMMYYYY, "dd MM yy");
        for (Entry<String, String> entry : dateFormatMap.entrySet()) {
            Pattern pattern = Pattern.compile(entry.getKey());
            Matcher matcher = pattern.matcher(dateString);
            String text = null;
            while (matcher.find()) {
                text = matcher.group();
            }
            if (!StringUtils.isEmpty(text)) {
                ConvertEntity entity = new ConvertEntity();
                entity.setDateFormat(entry.getValue());
                entity.setText(text);
                return entity;
            }
        }
        return null;
    }

    /**
     * 性别统一格式
     *
     * @param sex
     * @return
     */
    public static String convertBySex(String sex) {
        if ("FEMALE".equals(sex)) {
            return "F";
        } else if ("MALE".equals(sex)) {
            return "M";
        }
        return sex;
    }

    /**
     * 名字为一行时转换
     *
     * @param names
     * @return
     */
    public static ConvertEntity getNamesConvert(String names) {
        String lfmText = getTextByRegex(names, "\\w+,((?:\\s*[^\\s+,]+)*)");
        if (StringUtils.isNotEmpty(lfmText)) {
            return namesConvertLFM(names);
        }
        return namesConvertFML(names);
    }

    /**
     * 名字为一行时转换为firstName、middleName、laseName
     *
     * @param names
     * @return
     */
    public static ConvertEntity namesConvertFML(String names) {
        ConvertEntity card = new ConvertEntity();
        Pattern compile = Pattern.compile("((?:[^\\s+,]+[\\s+,]+)*)([^\\s+,]+[\\s+,]+)([^\\s+,]+)");
        Matcher matcher = compile.matcher(names);
        while (matcher.find()) {
            if (StringUtils.isNotEmpty(matcher.group(1))) {
                card.setFirstName(matcher.group(1).trim());
                card.setMiddleName(matcher.group(2).trim());
            } else {
                card.setFirstName(matcher.group(2).trim());
            }
            card.setLastName(matcher.group(3).trim());
        }
        return card;
    }


    /**
     * 名字为一行时转换laseName、firstName、middleName
     *
     * @param names 名字字符串
     * @return
     */
    public static ConvertEntity namesConvertLFM(String names) {
        ConvertEntity card = new ConvertEntity();
        Pattern compile = Pattern.compile("^(\\w+)[\\s+,]+((?:[^\\s+,]+[\\s+,]+)*)([^\\s+,]+)$");
        Matcher matcher = compile.matcher(names);
        while (matcher.find()) {
            card.setLastName(matcher.group(1).trim());
            if (StringUtils.isNotEmpty(matcher.group(2))) {
                card.setFirstName(matcher.group(2).trim());
                card.setMiddleName(matcher.group(3).trim());
            } else {
                card.setFirstName(matcher.group(3).trim());
            }
        }
        return card;
    }

    @Data
    public static class ConvertEntity {
        private String text;
        private int titalIndex;

        private int firstTitalIndex;
        private boolean matchText;

        private String dateFormat;

        private String firstName;
        private String lastName;
        private String middleName;

        public ConvertEntity() {
        }

        public ConvertEntity(String text, int titalIndex, boolean matchText) {
            this.text = text;
            this.titalIndex = titalIndex;
            this.matchText = matchText;
        }

    }


}
