package com.riskcontrol.api.constants;

import java.util.Objects;

public interface BizTypes {
    String OPERATER_SYS = "system";
    String SMS_CODE_VALID_TIMES_LIMIT = "SMS_CODE_VALID_TIMES_LIMIT";
    String SMS_CODE_EXPIRED_LIMIT = "SMS_CODE_EXPIRED_LIMIT";
    String TRY_ACCOUNT_INIT_AMOUNT = "TRY_ACCOUNT_INIT_AMOUNT";
    String X0_KEY = "X0_KEY";
    String X1_KEY = "X1_KEY";
    String X2_KEY = "X2_KEY";
    String X3_KEY = "X3_KEY";
    String X4_KEY = "X4_KEY";

    String AUTO_REVIEWER = "c66";

    enum SendSmsCodeSendType {
        SMS("1"),
        EMAIL("2"),
        VOICE_CALL("3");
        private String type;

        SendSmsCodeSendType(String type) {
           this.type = type;
        }
        public String getType() {
            return type;
        }

        public static SendSmsCodeSendType getEnum(String sendType) {
            for (SendSmsCodeSendType sendTypeEnum : values()) {
                if (Objects.equals(sendTypeEnum.type, sendType)) {
                    return sendTypeEnum;
                }
            }
            return null;
        }
    }

    enum SendSmsCodeSourceType {
        OFFICE("1"), WEB("2"), MOBILE("3");
        private String type;

        SendSmsCodeSourceType(String type) {
            this.type = type;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }
    }

    enum BindingType {
        PHONE("1"),
        MAIL("2");

        private final String code;

        BindingType(String code) {
            this.code = code;
        }

        public String getCode() {
            return code;
        }
    }

    enum RequestApproveType{

        /**
         * 提案审批
         * // 01存款审批
         * // 02取款审批
         * // 03优惠审批
         * // 04...XM
         * // 05额度修改审批
         * // 06修改银行资料
         * // 07修改电话
         * // 08修改真实姓名
         * // 09修改等级
         * // 11修改上线
         * // 13修改证件号
         * // 12其他类提案
         * // 14好友推荐提案
         * // 15额度互换提案
         * // 16投诉建议提案
         * // 17转账至游戏审批
         * <p>
         * // 20优惠预存审批
         * // 21积分修改审批
         * // 23修改邮箱
         * // 24修改会员类型提案
         * // 26佣金取款兑换提案
         */
        DepositRequest("01"),
        WithdrawalRequest("02"),
        PromotionRequest("03"),
        RabetRequest("04"),
        ModifyCreditRequest("05"),
        ModifybankRequest("06"),
        PhoneRequest("07"),
        ModifyRealNameRequest("08"),
        ModifyLevelRequest("09"),
        ModifyParentRequest("11"),
        ModifyIndentifyCodeRequest("13"),
        OtherRequest("12"),
        RecommendRequest("14"),
        CreditExchangeRequest("15"),
        SuggestRequest("16"),
        TransferToGameRequest("17"),
        PrompotionPreRequest("20"),
        ModifyIntegralRequest("21"),
        ModifyEmailRequest("23"),
        ModifyCustomerTypeRequest("24"),
        ModifyCommitionWithdrawalRequest("26");

        private String code;

        RequestApproveType(String code) {
            this.code = code;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }
    }

    enum OperatorTypes{
        System("S"),User("U"),Customer("C"),ZJPT("Z");
        private String type;

        OperatorTypes(String type) {
            this.type = type;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }
    }

    enum AccessLimitType{
        /**
         * 请求类型 1:请求次数超过限制,2:签名验证失败,3:登录名不匹配,4:SQL注入异常 5:参数长度异常
         */
        RequestLimit("1"),SignFail("2"),LoginNameNotMatch("3"),SqlInjection("4"),ParamLengthError("5");

        private String type;

        AccessLimitType(String type) {
            this.type = type;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }
    }
}
