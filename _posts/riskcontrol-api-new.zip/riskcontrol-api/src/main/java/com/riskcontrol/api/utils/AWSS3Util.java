package com.riskcontrol.api.utils;

import com.riskcontrol.api.service.OssService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.concurrent.Future;

@Component
@Slf4j
public class AWSS3Util {

    @Value("${aws.s3.bucketName}")
    private String bucketName;

    @Autowired
    private OssService ossService;


    public String s3GetUrl(String key) throws Exception {
        return ossService.getFileUrl(bucketName, key);
    }

    public String s3GetTxtUrl(String key) throws Exception {
        return ossService.getFileTxtUrl(bucketName, key);
    }

    public String s3GetUrl(String key, String suffix) throws Exception {
        return ossService.getFileUrl(bucketName, key, suffix);
    }

    @Async
    public void s3PutObject(String base64Img, String key) throws Exception {
        ossService.putObject(bucketName, base64Img, key);
    }

    @Async
    public Future<String> s3PutObject(File base64Img, String key) throws Exception {
        return new AsyncResult<>(ossService.putObject(bucketName, base64Img, key, false));
    }

    @Async
    public Future<String> s3PutObjectPublic(File base64Img, String key) throws Exception {
        return new AsyncResult<>(ossService.putObject(bucketName, base64Img, key, true));
    }

    @Async
    public void s3PutObject(byte[] base64Img, String key) throws Exception {
        ossService.putObject(bucketName, base64Img, key);
    }

    public String s3PutObject(File base64Img, String key, String suffix) throws Exception {
        return ossService.putObject(bucketName, base64Img, key, suffix, false);
    }

    public String s3GetObject(String key) {
        return ossService.getFileBase64(bucketName, key);
    }



    private String base64Process(String base64Str) {
        if (!org.springframework.util.StringUtils.isEmpty(base64Str)) {
            String photoBase64 = base64Str.substring(0, 30).toLowerCase();
            int indexOf = photoBase64.indexOf("base64,");
            if (indexOf > 0) {
                base64Str = base64Str.substring(indexOf + 7);
            }

            return base64Str;
        } else {
            return "";
        }
    }

    public String getPublicUrl(String key) {
        return ossService.getPublicUrl(key);
    }

}
