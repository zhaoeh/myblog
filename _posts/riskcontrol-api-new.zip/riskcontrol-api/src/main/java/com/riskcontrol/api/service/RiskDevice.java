package com.riskcontrol.api.service;

import com.riskcontrol.common.entity.request.device.LoginCheckRequest;
import com.riskcontrol.common.entity.request.device.RegisterCheckRequest;
import com.riskcontrol.common.entity.request.device.RegisterSaveRequest;
import com.riskcontrol.common.entity.response.device.LoginCheckResponse;
import com.riskcontrol.common.entity.response.device.RegisterCheckResponse;

/**
 * @description: riskDevice
 * @author: ErHu.Zhao
 * @create: 2024-11-14
 **/
public interface RiskDevice {

    /**
     * 注册检查*
     *
     * @param registerCheckRequest request
     * @return response
     */
    RegisterCheckResponse registerCheck(RegisterCheckRequest registerCheckRequest);

    /**
     * 注册保存*
     *
     * @param registerSaveRequest request
     * @return response
     */
    Boolean registerSave(RegisterSaveRequest registerSaveRequest);

    /**
     * 登录检查*
     *
     * @param loginCheckRequest request
     * @return response
     */
    LoginCheckResponse loginCheck(LoginCheckRequest loginCheckRequest);
}
