package com.riskcontrol.api.controller;

import com.riskcontrol.common.client.PBCDeployFeign;
import com.riskcontrol.common.entity.request.api.PBCDeployDisableRequest;
import com.riskcontrol.common.entity.request.api.PBCDeployUpdateRequest;
import com.riskcontrol.common.entity.response.Response;
import com.riskcontrol.common.entity.response.api.PBCDeployRsp;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/*** @program: riskcontrol-cron
 ** @description: PBC配置文件Controller
 ** @author: hongwei
 ** @create: 2023-11-14 12:23
 **/
@RestController
@RequestMapping("/pbc")
@Api("PBC配置文件相关接口")
public class PbcDeployController {


    @Resource
    private PBCDeployFeign pbcDeployFeign;

    @PostMapping("deploy")
    @ApiOperation(value = "查询pbc配置接口")
    public Response<List<PBCDeployRsp>> getDeployList() {
        return pbcDeployFeign.getDeployList();
    }

    @PostMapping("updateDeploy")
    @ApiOperation(value = "修改pbc配置接口")
    public Response updateDeploy(@RequestBody PBCDeployUpdateRequest deployUpdateRequest) {
        return pbcDeployFeign.updateDeploy(deployUpdateRequest);
    }

    @PostMapping("deleteDeploy")
    @ApiOperation(value = "停止pbc抓包配置接口")
    public Response deleteDeploy(@RequestBody PBCDeployDisableRequest deployDisableRequest) {
        return pbcDeployFeign.deleteDeploy(deployDisableRequest);
    }
}
