//package com.riskcontrol.api.utils;
//
//import com.alibaba.nacos.common.utils.CollectionUtils;
//import com.cn.schema.customers.WSCustomers;
//import com.cn.schema.urf.QueryBranchResponse;
//import com.cn.schema.urf.WSBranch;
//import com.riskcontrol.api.template.WsFeignTemplate;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import java.util.Collection;
//import java.util.Optional;
//import java.util.stream.Stream;
//
///**
// * @program: riskcontrol-api
// * @description: 补丁处理工具
// * @author: Erhu.Zhao
// * @create: 2023-11-24 10:56
// */
//@Component
//@Slf4j
//public class BusinessRepair {
//
//    private static WsFeignTemplate wsFeignTemplate;
//
//    public BusinessRepair() {
//    }
//
//    @Autowired
//    public void setWsFeignTemplate(WsFeignTemplate wsFeignTemplate) {
//        BusinessRepair.wsFeignTemplate = wsFeignTemplate;
//    }
//
//    /**
//     * 刷新门店编号（从ws获取有效的门店编号刷新到请求中去，以跳过ws或者userCenter对门店编号的校验）
//     *
//     * @param wsCustomers
//     */
//    public static void refreshBranchCode(WSCustomers wsCustomers) {
//        log.info("[refreshBranchCode] begin to refresh branch code.");
//        Optional<WSBranch> branch = Optional.ofNullable(wsFeignTemplate.queryWsBranchList(wsCustomers)).
//                map(QueryBranchResponse::getData).filter(CollectionUtils::isNotEmpty).
//                map(Collection::stream).flatMap(Stream::findFirst);
//        branch.map(WSBranch::getBranchCode).filter(StringUtils::isNotBlank).
//                ifPresentOrElse(code -> {
//                    log.info("[refreshBranchCode] first branch code from ws is {}", code);
//                    wsCustomers.setBranchCode(code);
//                }, () -> log.error("[refreshBranchCode] query branch code is empty."));
//        log.info("[refreshBranchCode] end to refresh branch code.");
//    }
//}