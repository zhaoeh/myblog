package com.riskcontrol.api.service;

import com.alibaba.fastjson.JSONObject;

/**
 * @program: riskcontrol-api
 * @description: redis常用操作服务
 * @author: Erhu.Zhao
 * @create: 2023-11-17 11:04
 */
public interface RedisOperationService {
    /**
     * 跨服务操作redis
     *
     * @param request request
     * @return response
     */
    JSONObject operationForRedis(JSONObject request);
}