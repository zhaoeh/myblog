package com.riskcontrol.api.entity.request;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.Hidden;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/10/2 16:55
 */
@ApiModel("获取ekyc状态")
@Data
public class EkcyQueryReq extends BaseReq {
    @ApiModelProperty(required = true )
    @NotBlank(message = "loginName can't blank")
    private String loginName;
    @ApiModelProperty(required = true)
    @NotBlank(message = "customerId can't blank")
    private String customerId;
    @ApiModelProperty(required = false, value = "是否要老kyc状态" )
    private boolean needOldKycStatus;
    @ApiModelProperty(required = false, value = "默认都返回，true只返回kyc状态" )
    private boolean noNeedEx;
}
