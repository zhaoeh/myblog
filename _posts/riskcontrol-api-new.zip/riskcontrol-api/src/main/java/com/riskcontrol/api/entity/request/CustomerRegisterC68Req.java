package com.riskcontrol.api.entity.request;

import com.riskcontrol.common.entity.request.BaseReq;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Date;

/**
 * 官网会员注册接口参数实体类
 */
@Data
@ApiModel
public class CustomerRegisterC68Req extends BaseReq {
    @NotBlank(message = "customerName can not be blank")
    @ApiModelProperty(required = true, value = "Account, to lower case")
    private String customerName;

    @NotBlank(message = "password can not be blank")
    @ApiModelProperty(required = true, value = "Password, encrypt by public key")
    private String password
            ;
    @ApiModelProperty(required = false, value = "Password, encrypt by public key")
    private String activate;

    //    @NotBlank(message = "nationality can not be blank")
    @ApiModelProperty( value = "nationality", example = "Philippines")
    private String nationality;

    //    @NotBlank(message = "birthday can not be blank")
    @ApiModelProperty(required = true, value = "BirthDay, Format:yyyy-MM-dd", example = "1990-01-01")
    private Date birthday;

    @NotBlank(message = "firstIdType can not be blank")
    @ApiModelProperty(required = true, value = "First ID type", example = "1")
    private String firstIdType;

    @NotBlank(message = "firstIdNo can not be blank")
    @ApiModelProperty(required = true, value = "First ID No.", example = "9874685213498AE9875")
    private String firstIdNo;

    @NotBlank(message = "firstIdScan can not be blank")
    @ApiModelProperty(required = true, value = "First ID upload key", example = "2749a1257c354e7bae424f3e3eea7f89")
    private String firstIdScan;

    //    @NotBlank(message = "secondIdType not be blank")
    @ApiModelProperty( value = "Second ID type", example = "1")
    private String secondIdType;

    //    @NotBlank(message = "secondIdNo can not be blank")
    @ApiModelProperty( value = "Second ID No.", example = "9874685213498AE9875")
    private String secondIdNo;

    //    @NotBlank(message = "can not be blank")
    @ApiModelProperty( value = "Second ID upload key", example = "2749a1257c354e7bae424f3e3eea7f89")
    private String secondIdScan;

    @NotBlank(message = "firstName can not be blank")
    @ApiModelProperty(required = true, value = "firstName")
    private String firstName;

    @ApiModelProperty(value = "middleName")
    private String middleName;

    @NotBlank(message = "lastName can not be blank")
    @ApiModelProperty(required = true, value = "lastName")
    private String lastName;

    //    @NotBlank(message = "gender can not be blank")
    @ApiModelProperty( value = "Gender: M - Male, F - Female")
    private String gender;

    //    @NotBlank(message = "occupation can not be blank")
    @ApiModelProperty( value = "Occupation:<br/>"
            + "Accounting/Finance<br/>"
            + "Admin/Human Resources<br/>"
            + "Sales/Marketing<br/>"
            + "Arts/Media/Communications<br/>"
            + "Services<br/>"
            + "Hotel/Restaurant<br/>"
            + "Education/Training<br/>"
            + "Computer/Information Technology<br/>"
            + "Engineering<br/>"
            + "Building/Construction<br/>"
            + "Sciences<br/>"
            + "Healthcare<br/>"
            + "Others")
    private String occupation;

    //    @NotBlank(message = "sourceOfIncome can not be blank")
    @ApiModelProperty( value = "Source of Income:<br/>"
            + "Salary/Wages<br/>"
            + "Business<br/>"
            + "Interest/Dividend<br/>"
            + "Retirement<br/>"
            + "Rent/Royalty/Licensing<br/>"
            + "Capital Gain<br/>"
            + "Non-Capital Asset<br/>"
            + "Others")
    private String sourceOfIncome;

    //    @NotBlank(message = "province can not be blank")
    @ApiModelProperty(required = false,value = "雇主名字")
    private String reserve2;

    @ApiModelProperty(required = false ,value = "签名照片id")
    private String reserve3;

    @ApiModelProperty(required = false ,value = "永久居住地")
    private String reserve4;

    @ApiModelProperty( value = "Province")
    private String province;

    //    @NotBlank(message = "city can not be blank")
    @ApiModelProperty( value = "City")
    private String city;

    //@NotBlank(message = "branchCode can not be blank")
    @ApiModelProperty(required = false, value = "Branch", example = "000009")
    private String branchCode;

    //    @NotBlank(message = "postalCode can not be blank")
    @ApiModelProperty(value = "Postal Code")
    private String postalCode;

    //    @NotBlank(message = "address can not be blank")
    @ApiModelProperty(required = false, value = "Address")
    private String address;

    @NotBlank(message = "phone can not be blank")
    @ApiModelProperty(required = true, value = "Phone, encrypt by public key", example = "9272334567")
    private String phone;

    //    @NotBlank(message = "email can not be blank")
    @ApiModelProperty(required = false, value = "Email, encrypt by public key", example = "9272334567@gmail.com")
    private String email;

    @NotBlank(message = "faceId can not be blank")
    @ApiModelProperty(required = true, value = "Face ID")
    private String faceId;

    @Size(max = 255, message = "The length must be 255 digits")
    @ApiModelProperty(value = "Messenger, Messenger and Viber can not be both blank")
    private String messenger;

    @Size(max = 255, message = "The length must be 255 digits")
    @ApiModelProperty(value = "Viber, Messenger and Viber can not be both blank")
    private String viber;

    @NotBlank(message = "smsCode can not be blank")
    @ApiModelProperty(required = true, value = "OTP Code, 6 digit number",example = "823456")
    private String smsCode;

    @ApiModelProperty(value = "reference: parent account id",example = "1000005688")
    private String reference;

    @ApiModelProperty(value = "zoneid")
    private String zoneid;

    @ApiModelProperty(value = "pageNo",example = "1")
    private int pageNo;

    @ApiModelProperty(value = "pageSize",example = "10")
    private int pageSize;
    @ApiModelProperty(value = "ticket", example = "abc")
    private String ticket;
    @ApiModelProperty("广告商推广action")
    private String action;
    @ApiModelProperty("广告商推广参数")
    private String clickid, subid_short, visitor_id, subid, aclid;

    @ApiModelProperty(value = "employerName")
    private String employerName;

    @ApiModelProperty(value = "birthPlace")
    private String birthPlace;

}