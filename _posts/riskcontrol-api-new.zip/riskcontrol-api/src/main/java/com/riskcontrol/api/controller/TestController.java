package com.riskcontrol.api.controller;

import com.google.cloud.vision.v1.AnnotateImageResponse;
import com.riskcontrol.api.ocr.OcrClient;
import com.riskcontrol.api.template.DingXiangTemplate;
import com.riskcontrol.common.entity.response.Response;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.Map;

@RestController
@RequestMapping("/ocr/test")
@Api("测试接口")
public class TestController {
    @Resource
    private OcrClient ocrClient;

    @Autowired
    private DingXiangTemplate dingXiangTemplate;

    @PostMapping(value = "/orcTest")
    @ApiOperation(value = "测试orc")
    public void testOrc(String path) throws IOException {
        if (StringUtils.isNotBlank(path)) {
            AnnotateImageResponse response = ocrClient.analyzeImage(path);
            System.out.printf("image=======" + response.toString());
        } else {
            AnnotateImageResponse response = ocrClient.analyzeImage("http://10.30.46.15:9002/c66/6dd4ded1-3ef0-4b1c-a63c-4d05de40c016.jpg?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=minioadmin%2F20240429%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20240429T031151Z&X-Amz-Expires=604800&X-Amz-SignedHeaders=host&X-Amz-Signature=9b03a0c81740f85b2d9b0308fa6a2a44981037d5dfbf4be7711f8be2d7dd4acd");
            System.out.printf("image=======" + response.toString());
        }
    }

    @PostMapping(value = "/dingXiangTest")
    @ApiOperation(value = "测试dingxiang")
    public Response<String> testDingXiang(@RequestBody Map<String, String> param) throws IOException {
        return Response.body(dingXiangTemplate.obtainDeviceInfo(param.get("token")));
    }

}