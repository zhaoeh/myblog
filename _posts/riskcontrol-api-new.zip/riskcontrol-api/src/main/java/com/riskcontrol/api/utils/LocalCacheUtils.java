package com.riskcontrol.api.utils;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.TimeUnit;

@Slf4j
public class LocalCacheUtils {

    private static LoadingCache<String, String> fileCache = null;

    static {

        CacheLoader<String, Object> loader = new CacheLoader<String, Object>() {
            @Override
            public Object load(String s) throws Exception {
                return null;
            }
        };

        fileCache = CacheBuilder.newBuilder()
                .concurrencyLevel(10)
                .initialCapacity(10000)
                .maximumSize(20000)
                .expireAfterWrite(23, TimeUnit.HOURS)
                .removalListener(notification -> {
                    log.info(notification.getKey() + " " + notification.getValue() + " 被移除,原因:" + notification.getCause());
                })
                .build(new CacheLoader<String, String>() {
                    @Override
                    public String load(String s) throws Exception {
                        return null;
                    }
                });
    }

    public static void putFileUrl(String key, String value) {
        fileCache.put(key, value);
    }

    public static String getFileUrl(String key) {
        return fileCache.getIfPresent(key);
    }

}
