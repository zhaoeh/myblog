package com.riskcontrol.api.entity.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author: sanji
 * @desc: TODO
 * @date: 2024/10/7 18:21
 */
@ApiModel("查询ekyc返回结果")
@Data
public class EkycStatusRsp {
    @ApiModelProperty(value = "1待提交,0待审核，1通过，2自动拒绝，3手动拒绝,4待查询zoloz结果" )
    private int ekycStatus;
    @ApiModelProperty(value = "老kyc状态 -1未通过,待未审批,1:通过" )
    private Integer oldKycStatus;
    @ApiModelProperty(value = "今日可尝试次数" )
    private Long canKycTime;
    @ApiModelProperty(value = "是否在ekyc白名单，暂留字段" )
    private Boolean inEkycWhite;
    @ApiModelProperty(value = "手动拒绝禁止kyc，转人工开关，ekycStatus=3时，refuseInitFlag=true 弹框联系客服" )
    private Boolean refuseInitFlag;
    @ApiModelProperty(value = "拒绝原因" )
    private String rejectReason;
    @ApiModelProperty(value = "是否在黑名单中，true是在黑名单，false 不是" )
    @JsonProperty("isBlack")
    private boolean isBlack;
}
