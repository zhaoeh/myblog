package com.riskcontrol.api.service.impl;


import com.alibaba.nacos.common.utils.CollectionUtils;
import com.riskcontrol.common.enums.CardTypeEnum;
import com.riskcontrol.api.entity.CustomerCard;
import com.riskcontrol.api.service.AnalyzeCardService;
import com.riskcontrol.api.utils.DateUtil;
import com.riskcontrol.api.utils.OCRDataProcessUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @Auther: yannis
 * @Date: 2023/3/31 17:40
 * @Description: Philippine National ID
 */
@Service("voterIdService")
public class AnalyzeVoterIdCardServiceImpl implements AnalyzeCardService {
    private static final Logger logger = LoggerFactory.getLogger(AnalyzeVoterIdCardServiceImpl.class);
    static final List<String> titleList = Arrays.asList("Signature of Voter", "COMMISSION ON ELECTIONS", "Republic of the Philippines", "VIN:");
    private static final String BIRTH_DATE = "DATE OF BIRTH";
    private static final String ADDRESS = "ADDRESS";

    public static final String CODE_NO = "VIN";

    @Override
    public CustomerCard getRecognitionData(List<String> textList, CardTypeEnum cardTypeEnum) {
        logger.info("Philippine National ID start parsing.....");
        if (CollectionUtils.isEmpty(textList)) {
            return null;
        }
        CustomerCard card = new CustomerCard();
        card.setIdType(cardTypeEnum.getCode());
        int birthTitleIndex = 0;
        int noTitleIndex = 1;
        int lastNameIndex = -1;
        int firstNameIndex = -1;
        int middleNameIndex = -1;

        List<String> valueList = new ArrayList<>();
        for (int i = 0; i < textList.size(); i++) {
            String text = textList.get(i);
            //证件号
            OCRDataProcessUtils.ConvertEntity noEntity = OCRDataProcessUtils.convertByCategory(text, CODE_NO, noTitleIndex, i, "\\d{4}-\\d{4}[A-Z]-[A-Z0-9]{8,13}(?:-\\d)?", titleList, valueList);
            if (noEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(noEntity.getText())) {
                    card.setIdNo(noEntity.getText());
                }
                lastNameIndex = noEntity.getFirstTitalIndex() + 1;
                noTitleIndex = noEntity.getTitalIndex();
            }

            //姓名
            OCRDataProcessUtils.ConvertEntity lastNameEntity = OCRDataProcessUtils.convertByNoCategory(text, lastNameIndex, "\\w+", i, titleList, valueList);
            if (null != lastNameEntity && lastNameEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(lastNameEntity.getText())) {
                    card.setLastName(lastNameEntity.getText().toUpperCase());
                }
                firstNameIndex = lastNameIndex + 1;
                lastNameIndex = lastNameEntity.getTitalIndex();
            }
            //姓
            OCRDataProcessUtils.ConvertEntity firstNameEntity = OCRDataProcessUtils.convertByNoCategory(text, firstNameIndex, "\\w+", i, titleList, valueList);
            if (null != firstNameEntity && firstNameEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(firstNameEntity.getText())) {
                    card.setFirstName(firstNameEntity.getText().toUpperCase());
                }
                middleNameIndex = firstNameIndex + 1;
                firstNameIndex = firstNameEntity.getTitalIndex();
            }
            //中间名
            OCRDataProcessUtils.ConvertEntity middleNameEntity = OCRDataProcessUtils.convertByNoCategory(text, middleNameIndex, "\\w+", i, titleList, valueList);
            if (null != middleNameEntity && middleNameEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(middleNameEntity.getText())) {
                    card.setMiddleName(middleNameEntity.getText().toUpperCase());
                }
                middleNameIndex = middleNameEntity.getTitalIndex();
            }

            //生日
            OCRDataProcessUtils.ConvertEntity birthEntity = OCRDataProcessUtils.categoryConvertByDate(text, BIRTH_DATE, birthTitleIndex, i, valueList, textList.size());
            if (birthEntity.isMatchText()) {
                if (StringUtils.isNotEmpty(birthEntity.getText())) {
                    Date brithDate = DateUtil.getDateFromString(birthEntity.getText(), birthEntity.getDateFormat(), Locale.ENGLISH);
                    card.setBirthday(brithDate);
                }
                birthTitleIndex = birthEntity.getTitalIndex();
            }
            //地址
            if (text.toUpperCase().contains(ADDRESS)) {
                if (textList.size() >= (i + 1)) {
                    String address = textList.get(i + 1);
                    card.setAddress(address);
                }
            }
        }
        return card;
    }

}
