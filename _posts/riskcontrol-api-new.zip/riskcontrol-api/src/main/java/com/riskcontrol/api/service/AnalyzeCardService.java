package com.riskcontrol.api.service;


import com.riskcontrol.api.entity.CustomerCard;
import com.riskcontrol.common.enums.CardTypeEnum;

import java.util.List;

/**
 * @Auther: yannis
 * @Date: 2023/3/31 17:37
 * @Description: 解析证件信息
 */
public interface AnalyzeCardService {
    /**
     * 对ocr识别的字符串进行解析，并返回解析结果
     */
    CustomerCard getRecognitionData(List<String> description, CardTypeEnum cardTypeEnum);
}
