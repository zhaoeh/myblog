package com.riskcontrol.api.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.api.service.RedisOperationService;
import com.riskcontrol.api.template.CronFeignTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @program: riskcontrol-api
 * @description: redis基本操作服务实现
 * @author: Erhu.Zhao
 * @create: 2023-11-17 11:06
 */
@Service
public class RedisOperationServiceImpl implements RedisOperationService {

    @Resource
    private CronFeignTemplate cronFeignTemplate;

    @Override
    public JSONObject operationForRedis(JSONObject request) {
        return cronFeignTemplate.doOperationForRedis(request);
    }
}