package com.riskcontrol.api.utils;

import cn.hutool.core.util.StrUtil;
import com.cn.schema.products.WSProductConstants;
import com.cn.schema.products.WSQueryProductConstants;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * @program: riskcontrol-api
 * @description: 产品常量工具类
 * @author: Erhu.Zhao
 * @create: 2023-10-27 14:11
 */
@Component
public class ProductConstantsUtil {
    private static RedisUtil redisUtil;
//    private static CronFeign cronFeign;
//
//    public ProductConstantsUtil(CronFeign cronFeign) {
//        ProductConstantsUtil.cronFeign = cronFeign;
//    }

    public ProductConstantsUtil(RedisUtil redisUtil) {
        ProductConstantsUtil.redisUtil = redisUtil;
    }
    /**
     * 从cron服务查询产品常量列表
     *
     * @param request 请求
     * @return 产品常量列表
     */
    public static List<WSProductConstants> queryProductConstantsList(WSQueryProductConstants request) {
        String typeHash="r-"+request.getType();
        Map<String,String> constMap = redisUtil.entries(typeHash);
        List<WSProductConstants> productConstantsList = new ArrayList<>();
        if (MapUtils.isNotEmpty(constMap)) {
            if (StringUtils.isNotEmpty(request.getKey())&&!constMap.containsKey(replaceCenterLineUnderlineLower(request.getKey()))) {
                return productConstantsList;
            }
            if (StringUtils.isNotEmpty(request.getKey())&&constMap.containsKey(replaceCenterLineUnderlineLower(request.getKey()))) {
                WSProductConstants productConstants = new WSProductConstants();
                productConstants.setValue(constMap.get(replaceCenterLineUnderlineLower(request.getKey())));
                productConstants.setProductId(request.getProductId());
                productConstants.setKey(request.getKey());
                productConstants.setType(typeHash);
                productConstantsList.add(productConstants);
                return productConstantsList;
            }
            constMap.forEach((k, v) -> {
                WSProductConstants productConstants = new WSProductConstants();
                productConstants.setValue(v);
                productConstants.setProductId(request.getProductId());
                productConstants.setKey(replaceCenterLine2Underline(k));
                productConstants.setType(typeHash);
                productConstantsList.add(productConstants);
            });
        }
        return productConstantsList;
    }
    private static String replaceCenterLine2Underline(String source) {
        return source.replace("-", "_").toUpperCase();
    }
    /**
     * 根据指定条件从cron服务查询一个产品常量值
     *
     * @param productId 产品id
     * @param type      type
     * @param key       key
     * @return 该组合条件对应的value值
     */
    public static String obtainProductConstant(String productId, String type, String key) {
        WSProductConstants wsProductConstants = obtainProductConstants(productId, type, key);
        if (Objects.isNull(wsProductConstants)){
            return StrUtil.EMPTY;
        }else {
            return wsProductConstants.getValue();
        }
    }

    /**
     * 根据指定条件从cron服务查询一个产品常量对象
     *
     * @param productId 产品id
     * @param type      type
     * @param key       key
     * @return 产品常量对象
     */
    public static WSProductConstants obtainProductConstants(String productId, String type, String key) {
        WSQueryProductConstants request = new WSQueryProductConstants();
        request.setProductId(productId);
        request.setType(type);
        request.setKey(key);
        List<WSProductConstants> wsProductConstants = queryProductConstantsList(request);
        if(CollectionUtils.isEmpty(wsProductConstants)){
            return null;
        }else{
            return wsProductConstants.get(0);
        }
    }
    private static String replaceCenterLineUnderlineLower(String source) {
        return source.replace("_","-").toLowerCase();
    }
}