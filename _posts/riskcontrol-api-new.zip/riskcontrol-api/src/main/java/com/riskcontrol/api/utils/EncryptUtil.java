package com.riskcontrol.api.utils;

import com.cn.schema.customers.WSCustomers;
import com.cn.schema.urf.WSRoles;
import com.cn.schema.urf.WSUsers;
import com.riskcontrol.api.constants.ENCRYPT_TYPE;
import com.riskcontrol.api.constants.SENSITIVE_TYPE;
import com.riskcontrol.common.config.UserCenterConstant;
import com.riskcontrol.common.enums.ResultEnum;
import com.riskcontrol.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @ClassName EncryptUtil
 * @Description TODO
 * @Author bartley
 * @Date 2020/3/3 13:59
 * @Version v1.0
 **/
@Component
@Slf4j
public class EncryptUtil {



    private static UserCenterConstant userCenterConstant;


    /**
     * 敏感信息 显示方式
     */
    public static final Integer SENSITIVE_SHOW_ALL_STATUS = 3;
    public static final Integer SENSITIVE_SHOW_HALF_STATUS = 2;
    public static final Integer SENSITIVE_HIDE_ALL_STATUS = 1;


    public static final Integer SHOW_REPORT_DISABLE = 0;
    public static final Integer SHOW_REPORT_SHOW = 1;
    public static final String ADMIN = "admin";

    public static final String REGEX_EMAIL = "(\\w+([-+.]\\w+)*)(@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*)";

    private static final ThreadLocal<String> MSG_VIBER_CONSTANT = new ThreadLocal<>();

    /**
     * 敏感信息遮蔽的字符
     */
    public static final String HIDE_CHAR = "*";

    /**
     * 敏感信息遮蔽的占位符
     */
    public static final String HIDE_PLACEHOLDER = "A";


    @Autowired
    public void setUserCenterConstant(UserCenterConstant userCenterConstant) {
        EncryptUtil.userCenterConstant = userCenterConstant;
    }

    /**
     * 传入文本内容，返回 SHA-256 串
     *
     * @param strText
     * @return
     */
    public static String SHA256(final String strText) {
        return SHA(strText, "SHA-256");
    }

    /**
     * 传入文本内容，返回 SHA-512 串
     *
     * @param strText
     * @return
     */
    public static String SHA512(final String strText) {
        return SHA(strText, "SHA-512");
    }

    /**
     * 字符串 SHA 加密
     *
     * @param strText
     * @param strType
     * @return
     */
    private static String SHA(final String strText, final String strType) {
        // 返回值
        String strResult = null;
        // 是否是有效字符串
        if (strText != null && strText.length() > 0) {
            try {
                // SHA 加密开始
                // 创建加密对象 并傳入加密類型
                MessageDigest messageDigest = MessageDigest.getInstance(strType);
                // 传入要加密的字符串
                messageDigest.update(strText.getBytes());
                // 得到 byte 類型结果
                byte[] byteBuffer = messageDigest.digest();
                // 將 byte 轉換爲 string
                StringBuffer strHexString = new StringBuffer();
                // 遍歷 byte buffer
                for (int i = 0; i < byteBuffer.length; i++) {
                    String hex = Integer.toHexString(0xff & byteBuffer[i]);
                    if (hex.length() == 1) {
                        strHexString.append('0');
                    }
                    strHexString.append(hex);
                }
                // 得到返回結果
                strResult = strHexString.toString();
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
        }

        return strResult;
    }


    /**
     * 遮盖敏感信息
     *
     * @param wsCustomers 2：手机号码；4：邮箱
     * @return
     */


    /**
     * 解密WSCustomers物件里面的参数
     */
    public static WSCustomers getDecryptCustomers(WSCustomers wsCustomers, String productId) {
        if (ObjectUtils.allNotNull(wsCustomers)) {
            wsCustomers.setAddress(decryptPropertyIfNotEmpty(wsCustomers.getAddress(), productId, ENCRYPT_TYPE.ADDRESS));
            wsCustomers.setPhonePrefix(decryptPropertyIfNotEmpty(wsCustomers.getPhonePrefix(), productId, ENCRYPT_TYPE.PHONE));
            wsCustomers.setPhone(decryptPropertyIfNotEmpty(wsCustomers.getPhone(), productId, ENCRYPT_TYPE.PHONE));
            wsCustomers.setMessager(decryptPropertyIfNotEmpty(wsCustomers.getMessager(), productId, ENCRYPT_TYPE.PHONE));
            wsCustomers.setViber(decryptPropertyIfNotEmpty(wsCustomers.getViber(), productId, ENCRYPT_TYPE.PHONE));
            wsCustomers.setEmail(decryptPropertyIfNotEmpty(wsCustomers.getEmail(), productId, ENCRYPT_TYPE.EMAIL));
        }
        return wsCustomers;
    }


    /**
     * 解密参数
     */
    public static String decryptPropertyIfNotEmpty(String property, String productId, ENCRYPT_TYPE encryptType) {
        if (StringUtils.isNotBlank(property) && property.length() > 6) {
            try {
                return decryptByProductAndType(property, productId, encryptType);
            } catch (Exception ex) {
                log.error(ex.getMessage(), ex);
                throw new BusinessException(ResultEnum.ENCRYPT_DECRYPT_ERROR);
            }
        } else {
            return "";
        }
    }


    /**
     * 解密
     *
     * @param input
     * @return
     * @throws Exception
     */
    public static String decrypt(String input, String key) throws Exception {
        if (null == input || "".equals(input.trim())) {
            return input;
        }
        input = input.substring(3, input.length() - 4);
        byte[] result = base64Decode(input);
        return new String(desDecrypt(result, key), StandardCharsets.UTF_8);
    }


    public static byte[] desDecrypt(byte[] encryptText, String key) throws Exception {
        SecureRandom sr = new SecureRandom();
        DESKeySpec dks = new DESKeySpec(key.getBytes());
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
        SecretKey secretKey = keyFactory.generateSecret(dks);
        Cipher cipher = Cipher.getInstance("DES");
        cipher.init(Cipher.DECRYPT_MODE, secretKey, sr);
        byte[] encryptedData = encryptText;
        byte[] decryptedData = cipher.doFinal(encryptedData);
        return decryptedData;
    }


    /**
     * 根据产品和业务类型解密
     *
     * @param input
     * @return
     * @throws Exception
     */
    private static String decryptByProductAndType(String input, String productId, ENCRYPT_TYPE encryptType) {
        try {
            return decrypt(input, getEncryptKeyByProductAndType(productId, encryptType));
        } catch (Exception e) {
            log.error(String.format("解密失败:参数input={%s},productId={%s},encryptType={%s}", input, productId, encryptType), e);
        }
        return null;
    }


    /**
     * 依据传入类型取得加密key
     */
    private static String getEncryptKeyByProductAndType(String productId, ENCRYPT_TYPE encryptType) {
        StringBuilder tempKeyBuilder = new StringBuilder();
        if (encryptType == null) {
            tempKeyBuilder.append(productId).append(productId).append(productId).toString();
            return tempKeyBuilder.toString();
        }
        String productKey = userCenterConstant.getConstantValue(encryptType.getType());

        tempKeyBuilder
                .append(productId)
                .append(encryptType.getPrefix())
                .append(encryptType.getType())
                .append(productKey, encryptType.getMixNo1(), productKey.length() - encryptType.getMixNo2());
        return tempKeyBuilder.toString();
    }


    public static byte[] base64Decode(String s) throws IOException {
        if (s == null) {
            return null;
        }
        Base64.Decoder decoder = Base64.getDecoder();
        byte[] b = decoder.decode(s);
        return b;
    }


    /**
     * 遮盖敏感信息
     *
     * @param wsCustomer
     * @param phoneStatus
     * @param emailStatus
     * @throws Exception
     */
    public static WSCustomers getHideSensitiveCustomer(WSCustomers wsCustomer, int phoneStatus, int emailStatus, int msgViberstatus,
                                                       String msgVibersHideway) {
        // 根据角色判断隐藏方式
        if (wsCustomer != null) {

            if (phoneStatus == SENSITIVE_SHOW_HALF_STATUS) { //电话半遮盖
                wsCustomer.setPhone(halfHideMobile(wsCustomer.getPhone()));
            } else if (phoneStatus == SENSITIVE_HIDE_ALL_STATUS) { //电话全遮盖
                wsCustomer.setPhone(allHideSensitive(wsCustomer.getPhone()));
            }

            if (emailStatus == SENSITIVE_SHOW_HALF_STATUS) { //邮箱半遮盖
                wsCustomer.setEmail(halfHideEmail(wsCustomer.getEmail()));
            } else if (emailStatus == SENSITIVE_HIDE_ALL_STATUS) { //邮箱全遮盖
                wsCustomer.setEmail(allHideSensitive(wsCustomer.getEmail()));
            }

            if (msgViberstatus == SENSITIVE_SHOW_HALF_STATUS) { // Messenger/Viber半遮盖
                wsCustomer.setViber(halfHideMsgViber(wsCustomer.getViber()));
                wsCustomer.setMessager(halfHideMsgViber(wsCustomer.getMessager()));
            } else if (msgViberstatus == SENSITIVE_HIDE_ALL_STATUS) { //Messenger/Viber全遮盖
                wsCustomer.setViber(allHideSensitive(wsCustomer.getViber()));
                wsCustomer.setMessager(allHideSensitive(wsCustomer.getMessager()));
            }

        }
        return wsCustomer;
    }


    /**
     * 隐藏敏感信息
     *
     * @param hideway 遮蔽方式：前二后一AA*A
     * @param value   需要遮蔽的字符串
     * @return
     */

    public static String halfHideSensitive(String hideway, String value) throws Exception {
        if (StringUtils.isEmpty(hideway) || StringUtils.isEmpty(value)) {
            return "";
        }

        // 如果是邮箱
        String suffix = "";
        Matcher m = Pattern.compile(REGEX_EMAIL).matcher(value);
        //为了修复BTC钱包地址屏蔽卡死问题，这里做个判断，非邮箱地址不要进入find()方法  ---by Alex 2018.01.09
        if (value.contains("@") && m.find()) {
            value = m.group(1);
            suffix = m.group(3);
        }

        if (value != null && hideway.length() > value.length()) {
            return allHideSensitive(value) + suffix;
        }

        String res = "";
        Pattern p1 = Pattern.compile("^(" + HIDE_PLACEHOLDER + "{1,})\\*");
        Pattern p2 = Pattern.compile("\\*(" + HIDE_PLACEHOLDER + "{1,})\\*");
        Pattern p3 = Pattern.compile("\\*(" + HIDE_PLACEHOLDER + "{1,})$");
        Matcher m1 = p1.matcher(hideway);
        Matcher m2 = p2.matcher(hideway);
        Matcher m3 = p3.matcher(hideway);

        int start = m1.find() ? m1.group(1).length() : 0;
        int mid = m2.find() ? m2.group(1).length() : 0;
        int end = m3.find() ? m3.group(1).length() : 0;

        char[] textarr = value.toCharArray();
        for (int i = 0; i < textarr.length; i++) {
            if (start > 0 && i < start) {
                res += textarr[i];
            } else if (mid > 0 && i > textarr.length / 2 - mid / 2 && i <= textarr.length / 2 + (mid % 2 == 0 ? mid / 2 : mid / 2 + 1)) {
                res += textarr[i];
            } else if (end > 0 && i >= textarr.length - end) {
                res += textarr[i];
            } else {
                res += HIDE_CHAR;
            }
        }

        return res + suffix;
    }


    public static String allHideSensitive(String text) {
        String res = "";
        if (StringUtils.isEmpty(text)) {
            return res;
        }
        for (String str : text.split("")) {
            res += HIDE_CHAR;
        }
        return res;

    }


    /**
     * 获取当前用户角色的敏感信息查看权限
     * key：敏感信息的类型：1=真实姓名；2=电话号码；3=银行卡；4=邮箱地址 5=验证码 6 地址 7 钱包地址
     * value ： 当前敏感信息的显示类型：1=全隐藏；2=半隐藏；3=全显示
     *
     * @return Map<String, Integer>
     */
    public static Map<String, Integer> getCurrentUserShowStatusByType(WSUsers user) throws Exception {
        Map<String, Integer> hidetypeMap = new HashMap<>(6);
        // 默认半隐藏
        hidetypeMap.put(SENSITIVE_TYPE.PHONE_NO.getCode(), SENSITIVE_SHOW_HALF_STATUS);
        hidetypeMap.put(SENSITIVE_TYPE.EMAIL.getCode(), SENSITIVE_SHOW_HALF_STATUS);
        hidetypeMap.put(SENSITIVE_TYPE.MSG_VIBER.getCode(), SENSITIVE_SHOW_HALF_STATUS);

        if (user == null) {
            return hidetypeMap;
        }
        List<WSRoles> roles = user.getWSRoles();
        if (roles == null || roles.size() == 0) {
            return hidetypeMap;
        }

        for (WSRoles role : roles) {
            // 超级管理员角色，默认全显示 废除超级管理员全显示逻辑
            Integer phoneStatus = Integer.parseInt(StringUtils.isNotBlank(role.getPhoneStatus()) ? role.getPhoneStatus() : "2");
            Integer emailStatus = Integer.parseInt(StringUtils.isNotBlank(role.getEmailStatus()) ? role.getEmailStatus() : "2");
            Integer msgViberstatus = Integer.parseInt(StringUtils.isNotBlank(role.getMsgViberstatus()) ? role.getMsgViberstatus() : "2");

            //验证码遮盖默认全显示
            hidetypeMap.put(SENSITIVE_TYPE.PHONE_NO.getCode(), phoneStatus);
            hidetypeMap.put(SENSITIVE_TYPE.EMAIL.getCode(), emailStatus);
            hidetypeMap.put(SENSITIVE_TYPE.MSG_VIBER.getCode(), msgViberstatus);
        }
        return hidetypeMap;
    }


    /**
     * 半隐藏邮箱
     *
     * @param email
     * @return
     */
    public static String halfHideEmail(String email) {
        try {
            if (StringUtils.isEmpty(email)) {
                return "";
            }

            String[] data = email.split("@");
            // 頭尾保留三位, 中間皆隱蔽
            String mail = data[0];
            String mail2 = "@" + data[1];
            String hide = "***"; // 中间一律***  是三个*
            if (mail.length() < 4) {
                return mail + hide + mail + mail2;
            } else {
                String s1 = mail.substring(0, 3);
                String s2 = mail.substring(mail.length() - 3);
                return s1 + hide + s2 + mail2;
            }
        } catch (Exception var4) {
            var4.printStackTrace();
            return "";
        }
    }

    /**
     * 半隐藏手机
     *
     * @param s
     * @return
     */
    public static String halfHideMobile(String s) {
        try {
            if (StringUtils.isEmpty(s)) {
                return "";
            }

            // 頭尾保留三位, 中間皆隱蔽
            String s1 = s.substring(0, 3);
            String s2 = s.substring(s.length() - 3);
            String hide = "***"; // 中间一律***  是三个*
            return s1 + hide + s2;
        } catch (Exception var4) {
            var4.printStackTrace();
            return "";
        }
    }


    /**
     * 半隐藏  Messenger/Viber
     *
     * @param msgViber
     * @return
     */
    public static String halfHideMsgViber(String msgViber) {
        try {
            if (StringUtils.isEmpty(msgViber)) {
                return "";
            }

            String hide = "***"; // 中间一律***  是三个*
            if (msgViber.length() < 4) {
                return msgViber + hide + msgViber;
            } else {
                String s1 = msgViber.substring(0, 3);
                String s2 = msgViber.substring(msgViber.length() - 3);
                return s1 + hide + s2;
            }
        } catch (Exception var4) {
            var4.printStackTrace();
            return null;
        }
    }



}
