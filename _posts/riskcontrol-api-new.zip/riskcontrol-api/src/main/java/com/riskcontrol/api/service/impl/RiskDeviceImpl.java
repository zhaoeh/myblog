package com.riskcontrol.api.service.impl;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONObject;
import com.riskcontrol.api.constants.exception.ApiResultBaseEnum;
import com.riskcontrol.api.service.DingXiangService;
import com.riskcontrol.api.service.RiskDevice;
import com.riskcontrol.api.template.CronFeignTemplate;
import com.riskcontrol.api.template.DingXiangTemplate;
import com.riskcontrol.common.entity.request.device.LoginCheckRequest;
import com.riskcontrol.common.entity.request.device.RegisterCheckRequest;
import com.riskcontrol.common.entity.request.device.RegisterSaveRequest;
import com.riskcontrol.common.entity.response.device.LoginCheckResponse;
import com.riskcontrol.common.entity.response.device.RegisterCheckResponse;
import com.riskcontrol.common.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static com.riskcontrol.api.template.DingXiangTemplate.BUSINESS_EXCEPTION_KEY;

/**
 * @description: RiskDevice impl
 * @author: ErHu.Zhao
 * @create: 2024-11-14
 **/
@Service
@Slf4j
public class RiskDeviceImpl implements RiskDevice {

    @Autowired
    private CronFeignTemplate cronFeignTemplate;

    @Autowired
    private DingXiangService dingXiangService;

    @Value("${risk.device.enableBusinessCheck:false}")
    private Boolean enableBusinessCheck;

    private Map<String, Runnable> businessTrigger;

    @PostConstruct
    public void initBusiness() {
        if (BooleanUtils.isTrue(enableBusinessCheck)) {
            if (Objects.isNull(businessTrigger)) {
                businessTrigger = new HashMap<>(8);
            }
            businessTrigger.put("-10001", () -> {
                throw new BusinessException(ApiResultBaseEnum.APPID_ERROR);
            });
            businessTrigger.put("-10002", () -> {
                throw new BusinessException(ApiResultBaseEnum.SIGN_ERROR);
            });
            businessTrigger.put("-10003", () -> {
                throw new BusinessException(ApiResultBaseEnum.TOKEN_INVALIDATE);
            });
            businessTrigger.put("-10004", () -> {
                throw new BusinessException(ApiResultBaseEnum.TOKEN_EXPIRED);
            });
            businessTrigger.put("-10005", () -> {
                throw new BusinessException(ApiResultBaseEnum.SERVER_INTER_ERROR);
            });
            businessTrigger.put("-10006", () -> {
                throw new BusinessException(ApiResultBaseEnum.CER_EXPIRED);
            });
            businessTrigger.put("-10007", () -> {
                throw new BusinessException(ApiResultBaseEnum.SERVER_CURRENT_LIMIT);
            });
            log.info("businessTrigger 初始化完毕，总个数：{}", businessTrigger.size());
        }
    }

    @Override
    public RegisterCheckResponse registerCheck(RegisterCheckRequest registerCheckRequest) {
        Map<String, String> result = new HashMap<>(2);
        String deviceCache;
        String token = registerCheckRequest.getDeviceFingerprintToken();
        try {
            result = dingXiangService.getDeviceInfo(token);
            deviceCache = result.get(DingXiangTemplate.DEVICE_CACHE_KEY);
        } catch (Exception e) {
            log.info("registerCheck调用顶象失败，token:{}，result：{}", token, result);
            deviceCache = "";
        }
        tryTriggerBusinessException(result.get(BUSINESS_EXCEPTION_KEY));
        registerCheckRequest.setDeviceFingerprint(Objects.isNull(deviceCache) ? StrUtil.EMPTY : deviceCache);
        registerCheckRequest.setDeviceInfo(result.get(DingXiangTemplate.DEVICE_INFO_KEY));
        return cronFeignTemplate.registerCheck(registerCheckRequest);
    }

    @Override
    public Boolean registerSave(RegisterSaveRequest registerSaveRequest) {
        return cronFeignTemplate.registerSave(registerSaveRequest);
    }

    @Override
    public LoginCheckResponse loginCheck(LoginCheckRequest loginCheckRequest) {
        Map<String, String> result = new HashMap<>(2);
        String deviceCache;
        String token = loginCheckRequest.getDeviceFingerprintToken();
        try {
            result = dingXiangService.getDeviceInfo(token);
            deviceCache = result.get(DingXiangTemplate.DEVICE_CACHE_KEY);
        } catch (Exception e) {
            log.info("loginCheck调用顶象失败，token:{}，result：{}", token, result);
            deviceCache = "";
        }
        tryTriggerBusinessException(result.get(BUSINESS_EXCEPTION_KEY));
        loginCheckRequest.setDeviceFingerprint(Objects.isNull(deviceCache) ? StrUtil.EMPTY : deviceCache);
        loginCheckRequest.setDeviceInfo(result.get(DingXiangTemplate.DEVICE_INFO_KEY));
        return cronFeignTemplate.loginCheck(loginCheckRequest);
    }

    /**
     * 尝试触发异常*
     *
     * @param errorMsgInfo
     */
    private void tryTriggerBusinessException(String errorMsgInfo) {
        if (StringUtils.isBlank(errorMsgInfo)) {
            return;
        }
        JSONObject error = JSONObject.parseObject(errorMsgInfo);
        String stateCode = error.getString("stateCode");
        Optional.ofNullable(businessTrigger).map(i -> i.get(stateCode)).ifPresent(task -> {
            task.run();
        });

    }
}
