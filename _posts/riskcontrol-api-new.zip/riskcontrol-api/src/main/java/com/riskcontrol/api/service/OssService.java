package com.riskcontrol.api.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;

/**
 * 文件服务接口
 */
public interface OssService {


    /**
     * 上传文件
     *
     * @param stream
     * @param fileName
     * @return java.lang.String
     * @throws
     * @author wliduo[i@dolyw.com]
     * @date 2020/2/6 16:04
     */
    String uploadFile(String bucketName, InputStream stream, String contentType, String fileName) throws Exception;

    /**
     * 获取文件
     *
     * @param objectName
     * @return java.io.InputStream
     * @throws
     * @author wliduo[i@dolyw.com]
     * @date 2020/2/6 16:05
     */
    InputStream getFile(String bucketName, String objectName);

    /**
     * 获取外链
     *
     * @param objectName
     * @return java.lang.String
     * @throws
     * @author wliduo[i@dolyw.com]
     * @date 2020/2/6 16:04
     */
    String getFileUrl(String bucketName, String objectName);

    String getFileTxtUrl(String bucketName,String objectName);

    String getFileUrl(String bucketName, String objectName, String suffix);

    String getFileBase64(String bucketName, String objectName);

    byte[] getFileByte(String bucketName, String objectName);

    void putObject(String bucketName,String base64Img, String key);

    String putObject(String bucketName, File base64Img, String key, boolean isPublic) throws FileNotFoundException;

    void putObject(String bucketName,byte[] base64Img, String key);

    /**
     *
     * @param bucketName S3 桶名
     * @param base64Img 图像Base64
     * @param key 对象KEY
     * @param suffix 对象后缀
     * @param isPublic 是否Public访问， 注意! 敏感数据请勿用此方法
     * @return
     */
    String putObject(String bucketName, File base64Img, String key, String suffix, boolean isPublic);

    String getPublicUrl(String key);
}
